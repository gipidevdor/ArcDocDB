(:SOURCE-CONSISTENCY :STABLE :SOURCE-BLOBS-AFTER
 ((:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "0241da912be93fdf70b9a9749b759efc17aca329")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "30f2e951591f8822ce780f77cfa9c4ab93f0a98b")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "8f682f6ff22f6a0c1847b71be3994e628d399a77")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "d654f504cacdfbe7e144a074e0c2aba5ff2f4b31")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "b239b5187a2649125b7429273cb0fe4f4cba673b")
  (:PATH ".gitignore" :GIT-BLOB "19bf1ab91a6ed3c89cfff48070fb170b09679360")
  (:PATH "CHANGELOG.md" :GIT-BLOB "71a5b18bae29351cc2ff4c119e6dcbeb0e6c4e98")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bb642c10cc99a2a8d62cc101ec1c6e9903ec1441")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "5820eb0ee2f06bc024e238afe12106b0e74275dc")
  (:PATH "README.md" :GIT-BLOB "99958454de32ddbc01794b0817781c287cf4c0d6")
  (:PATH "SECURITY.md" :GIT-BLOB "27fb94691a84b389d72184838e38d2e43a8fcfbb")
  (:PATH "arcdocdb.asd" :GIT-BLOB "3623493fdc52c3342c4068f52ab850ae6e56e7e1")
  (:PATH "assets/README.md" :GIT-BLOB
   "933cfee445a3fe85c8b9ca8c7c4e48afda9bdc95")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "0e9fe71b160f4ff7fcc61c9695159b00e352b12e")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "de51c5d5d625caf2ba89581880a7e932a86d2556")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "9ac19a17e0c095ed711eeb2a9da52b4965d3c481")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "b6dcf61865707b01724190e83c4987aa5d98762f")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "0c81882c35757d460e55f808fc6d2370f845550d")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "d65d5b12f248347430260c6671017a0894ebd3eb")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "2713de877ed961857868b53bcc346fe62088ec0e")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "b0e2afc520b8ea9a540f0605f682c1182b5af3ab")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "2e83c526df9864f1c3d2373fd313e4ea61d29fde")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "39cf33413347ccc9d91478efc1c08355908c23c9")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "3eab0ad4c56c1744c456579c8e773c5d7fe7493a")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "6616ed0cfadc71596ae3162affdef4f75f608de5")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "0f702230f39f3b4761886499d99b2eb431514908")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "07b5adf23d044b552d5e038adacf194774dfcf40")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "b92eea4011a182108002786370c8330e8271e356")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "db87b7732e2e42f22c711a89f5deae97f5f00757")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "1b845787d56dbc1296e7283f809e1be1bd0d3b80")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "826a6f1d12e37dd26893598caca3889010be7480")
  (:PATH "docs/README.md" :GIT-BLOB "303b4a009be18ad5f03ef990156ca0e145914fb2")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "88eeb77497b6d6124010ad65a71b98e08743131e")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "a4d7157123f6cad4b92d3722e136bd02f15fa138")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "fe20638b50dffc66f5d5b3497f00e5f526ea046a")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "2b9f1e16b289ec754c0ac0de79e7823852c4815a")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "4af05ad11f846d733b3485bfdabac47535f41415")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "ac6e1e0f042e6ce5622c0b579ff8d0419a707980")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "ad70fc5e177886b0be609ebc0234c0c7c2fbab90")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "7e6590a619252983120f8ef9b5b3fba5bf24659f")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "5ae6feb439b1d182febe27d16e6d485183150d6a")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "18de49d285e52d25e055397f47c829ba7db45500")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "2f04c342ca714f0638dfdf2bed17fe48de54edc9")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "1a86df3d58358950d8b658b6b8194563288fd0c8")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "99ca666f07f0f04168af74c55459ca76a6f421c7")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "3ca2df1c7beddedd65511d9282a547294cabbff4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "87931cd80f665581fc43a2b02fc6738ea3d57fb3")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "001950113b1fc347642e1939ef060d93a54096e5")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "5a442b2aeb665be3f23da887ff615bef889e167d")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "250c272e2ddaa4b062b956d5ab3eb66ce610b44a")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "be9686df1c7ecb762bebac602bab12010d73d0b9")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "6fff5ed7db6d11a51f12b167636b7a23a3750068")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "83c6cae3eb56b9edfda572533258d8438132e0ae")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "81823c873cf52abafd86a3e8ab35df2e161d1034")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "623209aef44929e1b8397b1f8470dffc20d9bbf8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "bc3d2144b30022e7ab239c561b6986a18e10ec8c")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "470ef1b7f52d571ea5af046ccf06896729a06a13")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "24235615cfaab3821cc38bc9b9979a9928c6dee9")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "8c29d6d4d55cbc7226c2df7361a3d7220c103f8f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "225aa16313ca4b54a04da07851f0824c2494543a")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "506080464430c1b9e5f2b09816d186ca95e3fcc9")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "328152db463a6e5796435ccd3867d8838429df15")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "b9dae81c93e124b6db129e90fb641c85ca349c93")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "dc8228d1c2dc5e01fa6a5cb6c69ec9e8648427d2")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "fc947bb28bdf5a015d7b353f56e0d6fb86a524c6")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "4646cd378729d3841b8419b3681477b4e1a80816")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "dfeef8dd42d465d1c97830bd6f8304d3f8579416")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "eb3138e9017cc95b7f71fb29ec3a21e4bc44a3c3")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "d4140bc0d14bee6ca7480e94fa96bd8c79e656fd")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "aadf427743cc9b511c4fac4952ec1335005b5568")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "fce6228c1a393557b2475a7600cc998246de97d0")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "c347b791cfa1e13319894e5c2a9c3c20527a7047")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "77640ef6687df0ba7a570b682000bd4b2fa042cc")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c571f195148361a34fa6bc9d1c6f35836742ab11")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "ba7550dfd1890a483f313610cadc808142bdddeb")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "1f07f3d9c4a9a1b6a0c1250dc09923966b2081d3")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "3ada528fa148db73ca09df933265ff82a5e0dd6b")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "75301c4284016be1da4f6f7a9e4b8a1c00b1fe8c")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2ebb221d1f2e8666fa62910f561728eb6ee0a9f3")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "4c11a9e20d9d7bf315bf7623740addd876019d77")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "f36aeeeab161774fce91906d1ba5d47e6b1a8636")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "47b35236825274bd340b61e4c30b7b38d8349d5a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "f393c09cc917be5e4a123befca7bdd3f238ad8eb")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "123524e58806fe8cee2727e5ada0b00561583a76")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "817f3f72a09e74d142b160bd8da172b459f327f9")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "0cb9800d4e89438f0ba2e9ecdf763245f0768196")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "83dd5fe0d9323805d7e97e6814129d16841efb80")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "c031db7bad8fa2f115938e3699e6ce01bc436bec")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "fdb928d6caf051a0341c162d537ca5d6351acfd9")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "61f400316607e9c47904680e6730c3034ba5897a")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "ebb3e21821c8b3d53a40a3bb6594b5c9ae20fc50")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "7800931fe3bc4c8204cd873ccc0ec8ed42af8b50")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "7028bc0b2b30b0ad17f9bbae81590519d3775e73")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "13ec9283f25316675f7bbbc2e95d80ed18469da1")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "80f4576d4e5afecdabdc3620771fc573e4ca9c4a")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "7137f05ec0a8e6cd345a00fda62be573855da3b4")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "2d883ca7e34a8b31f88930e0d266ec0a094e6b0a")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "10857a0489e16c0f7de3415b872b0c9a6002c1b7")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "00a1f025a375559acf548fb855c59d42e4a21642")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "173b91ac893a1bafe8d16ddb91b99dd6341c1a01")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c8182641591fa6f24bddedca56f92145a3c7a038")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "b8b2b37a18cb4d01815e07df5e64e763f273a9d0")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "325784adbb5cff4121559fd3d50a1ef943443434")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "bc95228574813d37b27882f24713e4d834788dd2")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "69bf38c64b527b5aeec011f9fe49d9fd3c31d253")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "9eb64c8428b638f6c0c1f0aaa80c4dbfd0f900b7")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "e39571136cad9d563a933aa608c011b887f17260")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "a83c5cc798dfb87750030781d015eeda260c4ac0")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "245f95c99a4735fd40a1d9694b4a5826f5ccb5d6")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "9f6526bf5c135cf43289127c4c1bc5dfdcbb8114")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "162cd32188a030d6cc3c5d16585054aa36055175")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "4af8109f8d01f1107791836371720802876ae775")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "2a9e7f0bf30460b3b7dbbbc1c7776c9259fe545d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "3935fc5225836a0669664701921ad1bfff3d443e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "8ba7e4ba06ca958c0be9a5e1128c63419aa7577a")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "a83375d3c09898353fc0173f3171884f92319d73")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "d379ed246db14204b7632b7b3c31266bfcd46b1e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "ba4d2ed61bf06d0504bb1e0067c8741ef45cc4e0")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "8966ac0cdf66fcefd616201cc97017d384b3f0a8")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "cd2f1ef9dfcd3f9029549430c21ec553509a62fc")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "81675040c1c6155f7e3efa669ca62ed4b8a63064")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "d8b22e42e7ab906488cef72d935b71d4a83ba499")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "6b4a59954e2d48cc30a044b57cfe43b0b91ae1e8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "7d44d58d7de6c62b2206a8e35be398bc34811663")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "9605de0679e062361f80c5654c5fbb8028765008")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "8b79dfa3b7cf5011b66534d02c2a4551232d503c")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "e9007f26d323a1ffd2993c461c3f84ad2aee90bc")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "a25b46457201e1a7885cc9b21cfb3e66267ec12c")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "a9e2e9dc6d0d4b968a9940d78abf8ca2de825e98")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "0a3a2123e618a8ff39e86dbbb70db36ccf51b133")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "2df0a214fc5cfe64ceb239aab4f7d2a2d1827305")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "1c1d617e19c0d74199ef11a56105d3ed90eb0ec0")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "56342dae95caf8705e0b28b3c0ea7ac86fdd8fa0")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "90bac509af0aff7b7085a2239de6e9dfddfc70ba")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "cbcfdba7c5967d5d36e5d9487f6a7b1ab0300a53")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "278d9413eab7578c99a07b1c614db37c83141097")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "8e1b0d0d6066669e1ffb65d95900a3b1aa385c51")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "c9808d48a01444ff6faddf2d8389673f91598db4")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "6b2909a5f56212947dea864584d2f96252fe1b1a")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "f0a2791f988b0d0c513629824f75ce1842fe059a")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "cebaf33e7e7cde4efbcbc2ada22fd494577c9e81")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "7b22c788ecf0d69f84316f39d2f580bfadb7b91f")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "76509dd8d44a61eff9129d08fb19c289d57fd1e8")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "93f1366c17eca13f37f63927d64779f7afeae658")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "a48d5b525d2c78fef0399666ebb14c6f8a2342e8")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "8dfa1cf8533764fdd89014f31cac59d02b248e2e")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "759b72a96a099d18fd353ef8936d63481e25129c")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "b28934a0a4eac77562b07fa8db796c167176ef36")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4a2c524c6b1c7be1c1b5d7e43d35d385ee7f5b1d")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "f6cadf13877cab21d869993f33e485f1af116806")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "8dbbd94b11ca62b266df8e1b58ef8b15487dde9f")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "2e1d7abdfe9b4880682ff1da97b526e180d01370")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "0264c59fce79fd2a9f34d05f85c8dfff5fed69be")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "a2a8d5bba2c3da3ad6977d6a6f750e468d229693")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "1aafc63fa8904a8504ec6fd42d34b606d6505677")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "ac23ebc4c1d6ab57116def02bf4ad7df115394d1")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "8fe4debab581640b3d1db74b6fa43610c8e547d2")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "a3d67947dafc891946df3ea19706d32d67b24a80")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "bc99cae302da8bb90c208cfc0d5def111e945269")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "79755fdc3fcc8cdc8459d0cf3d108d06e577bf3f")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "c3467fd1f58d977797821581ff127bfb2cfdd5cf")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "a0953cd3789ec80e22ec33f445510db6769ad2ed")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "4474e5ced93e129bae0ae13255e2c56363334f20")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "5f8fa54b5df938dc51ea2053298baa58413d7e5a")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "4434a2412cbcc6bab1bc5292331eb2c2eeabeb6a")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "ae05757ce562c9b2eb5632765cc9da4db8c2fe56")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "96a9d6be3614715a434ecfec5808375e06ff6468")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "a64f148cb2254e87c649bb16e7bee39aa45eb40d")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "a1631f582d8b3ecaa177cccead8c1e3d0051a822")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "a1adf2c6d8f6f13b0c583451ac732b439e58eda2")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "69e50510426fa53d230b64b89da9e64fdc5c6efa")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "542584f7ea490cc7b4639ee42969c17f52a8e559")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "204a995d2152620792e923275de5abcc5e29bfb3")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "efdcf79210060603b8b7982057933f7b57a3c220")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "ee84732af73d4d753b211bd9cd33f9c7dd1d2a3f")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "3932b391102e3b7e0ead521a1fb223ef5ca2129a")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "058623adabd6a98f7d7617c4c1ac4fd0b7bce825")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "30f47c1882108bc0c2180c5e51a67b4ad23eee11")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "acc39ebcd47f56d31d5ddcf9843ebf8543424f22")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "a6b480a9726002150f65443b9a3c97c9039f2012")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "c799f6cd5399c37daa1687cd0d154ebcfac2cb39")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "d9de17c5fcd7e7f21555c68db8f3eaa7d7e1b158")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "b7c4c84c6d688015a43f81b476e58744fbf5d467")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "f103ded38e6cb575820d7fb89d72e47b9fc16693")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "d09dc4f0914935805770cf148cfab99b1ca30eb1")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "ac29588884b2f12f2bd67a72f04504d88c2d44a0")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "d4382b97ee69a12235f4c1d445b9b13dd5440684")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "4dc9aa9bdfdd5e21a2ef2bf6ab6fc8d2e111a586")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "c88785115dfda86f3e6ce425487638fe514f0e3b")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "1950d3f3b38736f7d32e1c3a24fb217bd1dffc86")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "a220b68f94b35c81b9bca4420453c4057eded097")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "37ff4f5316483960508fa78df1f890ebaff8942e")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "27cb98d6bf753515b880d7b09e8069302a0e72d2")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "476e35fca8858a4a4eed163e4a3a42c7ce38bd4a")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "550c69493fdb363631b83dea4fff765119b6ad5f")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "04674e8a8b7434d1008a0e62176db98fe54e0ac0")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "656e8162bd3833268a6243e136c2e46b39e548f5")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "f779f81d41748e3e9b10596dc9af12b334d4dc23")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "f755abc620aaad10470143418702e883baf2493a")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "6b39b77b28e576610308a9d98e540df64e28555d")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "cb473b09149385d5d32bb44db1478e5ba7da7640")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "23966839673d2e5931f1822c0c2e0302a189911a")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "1b746fefc25d8cd1be1bb44611c7ac5f98e8acb1")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "c451a24e86e98a2dd3a75cfbae55260625b33dc8")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "096b16489aa910182fe01349aa5552ccc1ccd446")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "f77e4acc65f3582d76bee6867e7a728757a98d4c")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "b6c4a6992ef5ca707c19e08dfbdc7d1e01e1e900")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "6fbe1f002e3e18df09a964292f27c3657bb46004")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "b275c083f9705d1ed32b4cf282fd0c12c39d98a2")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "3c2423f187253e7c2c83b3848c7efbd43d269641")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "c7780a6798cec4964badc6a5529508898ae4945c")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "bbc3431b5872adfdee0e23d566caf7d2172a971a")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "8101b2da12ae1a60a0663b11ab70590a96c5bcf2")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "99cf34e5c5c3875ed97414c30ec9b7bef96d30b4")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "0a534e557a3fe8216e0d5fbfc84c354255d081ac")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "d17e9e45a1d4896249d11f2bd474aa05af5222cb")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "805c6b231d9fd7223ef1b149e75e9c3be0dd0859")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "d6e2ad12c278d5bb26050c056df4342671c590f5")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "77d0c406a967ebe97f81781f9dd4cc9d68488ee4")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "1798cdf9b8916ba74b21d1d86442a49874938e41")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "bc3121e6274d610f56155a1e159d0a8948ee87c5")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "73bfef0b478f57c9441a6d0e2ab59c0e7f223fef")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "89a767f226693292d6a934970010d6dc5f13bbe7")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "d7e1f6e6fd5baa3c0c345507b8c3cd7a71e47f33")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "497b96ba252c1d223b91c7a958af3a1de6e6bba9")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "4b9535873216af6a4ede0b3d6d31e80c466ad395")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "6c46cebd54cacfe7b366932d1be6bd2132346087")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "c9ec2a33ac47f9811f152032cc6232fb1ccb941a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "9cfa2d91655890f50c7a0d83cb14f0bbae650f21")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "08c866115be68fd9e88c2d30fd111017851bbb53")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "df02aed3cd659b1b09e746d8315f54e32f526965")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "2d2ffb30c9051c58fd7f9b7efb27a487d1c0fd8e")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "76b2e79d012ebffcdde4477af9b19fb2e1e54e67")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "7e470b27c01de9fbfb4d4b532136760ec18afdad")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "5f0636cde6711769dc13bdaabefb55e6af843147")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "f6eb25d050854b65daa7766d203b3e177dbc8f4a")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "04f64ce2d33e27cc5d40482765223aa6dec062ea")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "e4fa3bae3e265d1ca702c1ecc6aa8e44c676155e")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "f76d0c995da17ae17ef8ccc6c68a3045ea461a73")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "a92e30d229b4d76f6220a96ded2c46f4054544a4")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "c04cfa11a0b9edaf4b73a251845690cdbb3ee98c")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "caafe0a8685e4faf2215bebe5f37fd1a80683f93")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "1f01809c914084c4773dd184439d1cf599710f09")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "ef2ed1ac671dec6c7904174152fdd90dd03c4589")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "dfd353b4f7544d41a04d916abdb4a0aedaac2c3d")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "b94583da79c1834c306118ebcc013c795b286ce1")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "4d6ff67e6e78c550986e2e953ed8a9a5d8b4ee20")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "db7e38f078621af681d9b5e523f4c91bf4801c6d")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ffd1c9ac47dcab5ab8c1c0301c0c04c3e2686b6e")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "01109f06ce875665dffb11263b80f68a2d3c07ba")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "3249fbcd44f2f2e76a14195461a3a4e43b3031ec")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "a12ac9c53969f6755c8cb0de21212f06e7e03e4b")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "f500b01def047de7973851144c8196036abf36bb")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "2e58b4d0e459495430a6cd1e9540994d8a25a0da")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "f134e4c3c3cfda195b324e7bb362948b67aa1fd5")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "5ebf0d1098584b8ea8dd380b92a9b913980f2285")
  (:PATH "docs/limiti.md" :GIT-BLOB "dd24577016d7a14379ebbbc35a1e86a0d23a4295")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "4bd3d55870e1b05b12a4a2287de6b5186f2d3b5d")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "f27f1e9ecbf711aaa240bb7697f6b06f553bac2f")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "2b56cf1d8636aede273e4cd12165ec78a6ba73f0")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "742c9309d02efe4238c859a3a7c6cd577240cdf2")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "70d45ea89536739989e90f7815ed8e89fc1544c6")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "51ef103f889daf79bfea015244af11bdfea3c3c6")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "52300ff2ab7310e14b02fce2dc414b56a08c8f6c")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "2004d712f3755c501fd2b506b8f729ce6297707e")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "c5b7d4f08337ce5b0fa7096b872e21ca8c94462e")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "2709ceddf253b8a53c7726f2fcf33fc0c8d2ecff")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "2ed70c7629bc15b9b7803135fa000168ca818cbe")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "989474478f9330b3f8d731cc34c190c229850217")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "cac1621bcd068d757ea86d25ce1da1d5d1f254e9")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "0fa9272a2986414342a107ae4c1e5fbde3720958")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "9647505f8a2ae9cf74348487e9648a6c0dd5d252")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "25d94d78061e6c68007e4316aca4cdc60f9de610")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "a95cb4392328411d9f17c334c149d9c029535102")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "679e74cf6c8051dd57ea1f2fa0584c46aaef47e2")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "e8af15a00e7178168116c0138027e820c07e598c")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "139d030b0125b61aad567263b7b7db95e830e927")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "108872e995b0def43475138c76e11fdb5d578ceb")
  (:PATH "spikes/README.md" :GIT-BLOB
   "14250504c27c786cd83174a7cca53bf273af2125")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "81c46b7e0a82ca474857d5e5de01dc43c0572bf1")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "1683f3951361ad60dea42821451a4bea35147b6c")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "19840c3a15271323546259e5c0aafd7d13489681")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "54a1982bd08ac27197c3266bb2f883aab405f705")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "f7d9674884267ad4d22f962c762e1995b749fb44")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "f8480d84bb8e932e0a17719c779ea54709c3c3f4")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "1c6ae01e442bd3c4d8c829006647aaa59ae1a185")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "91732544806c231b77dcbddc9a2e4460a12873ec")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "16ebc31ba682d36cf3520086d43f35a310159bec")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "e5d56bb99d2bae3867cacd19d18711f35e6ff8db")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "2eca7df2fd82994b4ad13ff58f72ab5efb9edc3a")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "ea4feea4edb0e4a1dd7ad357419b6bf97b415f50")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "51be4a3beb85262d453bd6b283a3b31378615fe7")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "f23f9ecd889437c83c946c88f2bf56a45a73f3ab")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "bbeac271ff79f96c0f69d22c60a045a4bfec8f09")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "9d97ed258355e5afd21edfc1820ee6d68137a02c")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "729f3500b4f427612b39c02f210c4ac25f45c805")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "a6bd28dd37f149b2b47cedfdbbb7b4c11fa1bf6d")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "648bd776767e4be914a2470069afced14bc1c1e5")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "a813fbeb55cd03980b2215c99fc3170d6afa4d92")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "a05614fee1df43315393f048efbbfe9a948bee9c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "6b3bc87d5700e52ca6b861fa562c2b7958248887")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "9e9121e124a6af86e9ccb8a253f69e1db584e873")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "e6b80fa0165026cd1a89c58786ec35d240bdc6c5")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "a1fdf6705a10fcca3926f40e26051fe7b6df5bf0")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "5755794e6b6afeed6f00a698cb337cf4b18730a4")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "cb5452eab513ddab4db6eb2955603a0c133d4e77")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "8c83b0067a0481759f14733e3c60ca888c6d01d8")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69fb5930c2722871c30056b41c13f7919058bfcb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "b5cc04cfdf8ff989a5eb6081dd100f8c506b081d")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "e3ebc7594ca6b1ae269579e5e9c7f9fef1b14300")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "45255a912edb4300b1f22c9505d09be5177d1d4b")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "5aca4d48de7bf0d849eafe87ae89f6e7800282d8")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9ab280c17b61b8f98f8299cbfae676942bb3ae47")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "5f4f08a4609bd264fa058ec25ba8f6a516c162c8")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "b335ea1d241672a3989da65b9a7ec516e7533347")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "bcd7de80241f809dcfce472741f120a61ac787b4")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "ca6215b30010d3d2eb90eaa6fd09dd5a9ac7778f")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "db635a50678f2712ec9516be335717ea254d4d09")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "761302dad1073c841397f6c88d595b114af8d9ef")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "12d573ec29468f1fdae3e674a494d786a390c33e")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "57ffc48cc688a4de8ebec5cb14c1e69c4209704a")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "70272936e323b3e0cb05173c9fb68cb2b614c355")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "f1afe79c7a4d49abd6a6e5f6975dec830ef7b1f6")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "c574e87af5e195ddf3f596a4ae527e69c7a3c6a6")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "e3d7d77407046338d23e26eb0b8a2e8fdc3d699d")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "a8330e50a77b52a6b9044ebbb48f62bb4b3222a3")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a2c5c77dd51bff760bff4508e998d94370921eda")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "61f0d6e2783e4790ed7e19a45bba6407d6e5b3de")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "807939c0fbc5d149bc7c8c1e29c7864ef7be991d")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "26726c45555ae8490e0dff31f61f70735183acc7")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "9eb660cca8f097e25ca3c1535cace8c20bc1e238")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "80cb600f6c6d724cf1eaec25c3d2742c8c320906")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "9388a84a1beb35cfa2bf016471389c881ad38628")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "a3dfde4a4780554b88e6e037ab4f70731f9c884a")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "57235763cf556ecd7633a0052f265ce3eb2b0462")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "f0f1cd22e87892119a4b7768b4efe5e519925dff")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "909dfdbc901c4cbdeae5b47faf52480350372524")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "34c8add62a6df92446be5234ef013893ebcf6879")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "bb4d4d6f222aa360ec64ef2f45ee6ba0524dd2f0")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "58981c7e41ce2694dbfcaed99010a3a53e3c1dea")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "5b3c26f78d5c4aa53ca200abdd3e0f753f926b54")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "4119f86231b7d8698fc3558868ff8a5bcbdf3090")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "720f16e96203f00e308727b430b66b28689dc7bb")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "4f34d18152d77fbf63bf708ebd0aabac178c3ac1")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "65a3f3c9e84c83b900c1dd8c9cc2fc21cec36c52")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "6d36e1f64d79f24c95209fd70551953e40c62335")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8e5102497f628796fa8faffa2085a165496af230")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "2cbd40c539b13dd80070eedf4af82bd1b26f4b28")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "2d514f6fe2e81eecb29fa53de611fa5e28696904")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "edbe5eaa88c50dc13af8e367b73f7f41fd7bd724")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "f9c691d28620427099d1d89a89a1ff5d04cbe257")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "bca6808e75e144ac7e9643df07a1cc6df4f70ed3")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "09185339cab38ab937045b40c52bb1b9092ffb8e")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "f1a1a37ccd59a81e7ff91fcb36009d5953d7edd5")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "951e5efdd1977c18a5bd90a1e4b3199d60e92d38")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "1d93461227b222a8effc53ec9344c5dab0b531fe")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "ec99839d234468298b553e331873a320c8ece53f")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "14bb99d6529c3d741f60472d2c3e822dbb0f590e")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "70341c7c32b364603d38bdc42e8b3af1cc631773")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "bd75d3a4b7483900689417ae3eb2dd65e76c8468")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "49bbcd30fdf96963702148cd675d5d3066189309")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "5ae454c03e8a9b9196653c8b28df0727e480d142")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "17e5ad4e2206e280c3f7324adc5c8a1e50e232e0")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "956b6c7145a25dc64a7247f2e14321876ac08f15")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "55028dae42a3ce1050d6872665c3c3ba6aa3f74d")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1177496e5baca7f7c698156e196c60fe1fe2566a")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "e1bf83fbcc737b55eaa71bd6b41a912a901178ce")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "6f54751adb255f49582ff1da62f951965c3860a1")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "9cbbdb6200af813bc9595d0ef964628a9ba0368f")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "53438f156d3e1e15f3732ec840223231b308a7a5")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "cb426426eac6e923224bc57c1dd602405f4bc040")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "23f16c3039b71be0bd46d6bf92f05791e444683e")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "5a105a141b43f5585f8e79c2965d59e96cd35ac6")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "cf168c44bfe5aedd2e34180ce4f766a6a89500a7")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "c9b8488d0a1aa7643a6ab1570765ec870aa7c9e4")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "032ad088b19ec3498a7c80a5e4b96d7777257dad")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "0d8e799b889df829aeb46054ef100377845dd0e0")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "f115b63c6089960e9857469475f821f3035a5ef2")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "6d43b042d7d9018f8aa48e88fc58c24b5a089cdf")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "a83ee5a2d8903538f8ba977ef0f5ddbe3a357d6b")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "6d05b467aee412f447308eb697daa7f4f5ec6f0d")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "5627b4179b115c008379aa3e60a4724e63f9657b")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "20de8a35a4deaa830348a6db5b5bb033a82c81d2")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "aa80e1b0b6af77379cfe2f2bd12c0b17e5c6851b")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "20d4b57b2a7c4b9f11205e753b92301f74f56cfc")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "1d7969c842b1f9a4cd0b9eba2ea3496cf914a2c4")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "aacbb9975ad3795d848c4523d178af31d34aa7b2")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "f36b55b9e2d9002ed2ce203a0289c92984c89ac9")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "b5b8243bc40b44af8c34ba76a5ab732675690af5")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "2282593c0a431f3f73fb47cdfc7a8e530e704ce7")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "b8009b8313054c9abebb70de8f8223fb1df708f3")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "5db1d132d91fa11be2b2624ed4c0c8d5405ce591")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "abfdeb5397f8be1d390cbdf47f4f02cd2f36bf91")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "77df997ef72008e7758899a348ae07695bce0b38")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "8555e14347d05182c99b756a312207019e2f904f")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "79d794b102c3ebf50679426e7cebbf49f02683ce")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "321ae3d1fdcda8e34efbdaac4b10dfc08fe9d9a5")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "012c8cff2c265aa7f0daa909a9a0dd01adf7ca3b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "3c7cd919b94dd9458422143c18075dd7498fda1f")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "a8088783354d2e4e5048d6ac7a3bee7afff92719")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "80156ca526a341c845fc43fc9963097f8669e65a")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "ba31b07379219fa8fd80fca169d43a053d28063b")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "0b93448ffe9c6dd4f3a0a2f3f35d5cd656700bd7")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "1b6fe64ea7145f33bcf08c02e8550034ebd6a40c")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "6b840a0eb039afa7e55304bffba309f0ab72acdc")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "93acbd608b1af475aa505a6a7dedceb3b15e8d4b")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "b496c1df87108127da568a1fb7b0fd32856afcc5")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "01875b76743c514ef07346a32587f4dc5c34d2f8")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "48372f6f09a54cfcee793ac03ec321fca6ad18f5")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "25d93efc7c604042d09dc84e31baf1f4e2c4c45e")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "09d73425a6e571c8fac6669b14b98e3ceeb7c96b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "c9cadaabf755add3671cd1cc0408c3ff216df2a5")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "bf80277418243422144cf6ee71eef83d7eff6da5")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "3d0181717e3f334580bab9a6a507e2dfe57261ff")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "132e44c138e209d3f8840b098cca0424853d09c3")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "b3601060197a27c6e8a2aaee22b5576c6b0c6e5a")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "b30795fb7efad5f5313198d345ffabb43249e3fa")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "87cc54024e59757c16e20f3025970b1699b11662")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "878fd1afdcbf035a232166ef87066af4420e1aae")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "a6ce94b8be3c8c84043abfd6441599f9780b2c11")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "e58176890a26751bf5767582b279cb667a29744e")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "b133ea00a3b8063e9e934a1b41f10cad024471ae")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "0dbb2b3bdfbf5447a5904ce0fa6e4a97337a6827")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "60057f6a50c657f016bee3c21c21911b582f86fe")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47810fb2944b4b5c18d9a9c8e60dfdc1c5f19db4")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "68c357d2d522fcabe79284c540c2631e5fa87780")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "e74b806f5116db46f3a385821515c317b2dcb452")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "ae5b8e4677fdd1dcee2f2a1baf293f49d9ce2972")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "eaddc83c63dce2fde59227e0416917bbc766e325")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "5405bd515df8b26b792bd0430c9ec3dbadce63e7")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "55e56d621129d1637eac1a787bad60dd0f0405b1")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "e062c804e68a8f62eddadd5c87db0e7af392744f")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "7ad6b7541397611f1ecbda7dffdda98c4453dbf1")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "63fb4a20faeedceb47b8cd550262f1bdca497c06")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "128fe9650a741541b46d1ad0887b872cb2e85012")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "7352a27581b8e2e68407611e65e46773efdc333c")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "0cccb1f1b9bb8f63a308352d64426a420bd1e283")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "48a789494e731732ae0b378347e133d50daacfe4")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "7f91ca22b7f2f339b450db0f4c26c97f86906c58")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "fc42b51a0f8606687881e239ba650a9f1bb58124")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "6fbe5e4720187be3bcada2dcc9fc40026267da07")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "f280c35e8f7ed283d30e8f4a43bbf2f172600816")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "e350df4e2fdc2f651ffbdb136bdbb266ccafcb1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "a0def7fc9452d291e2e60dbeff26a56a2b06e3a3")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "acc9f6ea83a8ef2774b41bdb114165b6bfb54949")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "02c219d556a8cd807a0e322667dfb401d8b06fb6")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "39f28974f3fae098d32d4ad1a056a45b06f777a6")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "233556c366a99b7b263af1c7bc19b47ceaebf940")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "7980cac6cc8070836b9aa49fc8a0d6fb42630749")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "fc942f1c8e30e637abaf13dc26343d40417fc72f")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "fde8608e6ad3fe062937c48bdcb7d2d5870207bf")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0012eaf90064c4cc2949834a60e83c9db8ba6308")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "6cbbb89f681965173e9b1b95edf3f7f870af1eca")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "f1d99b205b1ea5e6ad059ecd7971d3633411b040")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "6d30698383477880c693954314bab03ca8affe24")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "f65662b4dea8ef04e4e59ce38b29a94fecea4f6c")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "edc8ce7474365e0885925d557a378779655d2e70")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "8245bc10cedafbff8665489fbced6833f078a373")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "ad1b1356eeb10248526f15ac31d2cc9b59811fc5")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "10c4b1949994d01cb9ed231f66a69cf81f1ea062")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "56318b1632a7a0ae11f2987cdf0d4bec68e465cb")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "e613ea025c2a886cdae7fd5e119cf80593c6b72e")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "e45437a508fc7893c4df06f3129ab064d3a4dbdd")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "33c7e6a9a0d6bbd551d4171ece6681b66bf87657")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "3624e1dde5f5a484a117f4c783d4e6b88027cc89")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "720d80c6dd5a962dc724835c1421635ba289b7ef")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "878f0fa10825ae3d49e9cac2f94d9992c06f2d20")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "dc9ea34945c3a8c52d5c62062951674d27becd5a")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "4212f8cc4be686e923cdbec9ded24f42f1da74ba")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ff6df200a7ace3af204b622969a387ce7a1e1504")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "24543b1595fbd12972e7073680fde062337b8417")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "51351fe8bb7b748fdbd7e8af9efdff1a8fa9eb56")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "0f706343bab19794f90df89400b1e94aead1db38")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "3cea6b1438f8ef7095726c592a991028e203da32")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "55b8fabbec5c66417e16b34caa5f73b0f24b1e46")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "13b367549c38c5fff1b826944df658ad1ee0a7c3")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "8d0ed3547f0dd71e7d74af31ce0ded585d7bb436")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "f2209f6ba53f7140069b42151995bfe312907561")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "93a40af0b228460656d9ad48f4c123e7b6c842d3")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "362141c30925f7bb8a3936743454326ddc510dbe")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "cdd7fd230964796e716a452d8e4210719108782b")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "fd285d0ae73d312d7234a2a142d16897c9adbcf7")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "d684d832fc90ed4ecd685cb956570820a806bbb4")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "be5fc283b3c06bc60548ea32c240ebf8d9ecafc2")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "4e84645950948a15caf27e4f9c5f18fa030efcd0")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "2e7364821e345b8b8714856a6a2f03c684140320")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "9421994e3c9883b423f6f17311d1b26c094ee991")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :WALL-SECONDS 32.700487d0 :FINISHED-AT-UNIVERSAL-TIME 4000716033
 :SCHEMA-VERSION 1 :KIND :COMMAND-VERIFICATION :ENVIRONMENT
 (:LISP #A((4) BASE-CHAR . "SBCL") :VERSION #A((5) BASE-CHAR . "2.6.9") :OS
  #A((6) BASE-CHAR . "Darwin") :OS-VERSION #A((6) BASE-CHAR . "27.0.0")
  :MACHINE #A((5) BASE-CHAR . "ARM64") :CPU "Apple M4" :MEMORY-BYTES
  17179869184 :LOGICAL-CPUS 10 :EXTERNAL-LOAD-STATUS :UNCONTROLLED
  :LOAD-AVERAGE "{ 3.69 5.52 5.75 }" :COMMIT
  "27191804e535dcaa10d5325aa4d51c05f226cf38" :WORKING-TREE "" :CWD
  #A((61) BASE-CHAR
     . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/")
  :DATE-UNIVERSAL-TIME 4000716001)
 :COMMAND
 (#A((4) BASE-CHAR . "sbcl") #A((10) BASE-CHAR . "--noinform")
  #A((13) BASE-CHAR . "--no-userinit") #A((12) BASE-CHAR . "--no-sysinit")
  #A((8) BASE-CHAR . "--script")
  #A((33) BASE-CHAR . "tools/get-directory-mutation.lisp")
  #A((7) BASE-CHAR . "--check")
  #A((37) BASE-CHAR . "spikes/out/get-directory-mutations-d/"))
 :STATUS :OK :STARTED-AT-UNIVERSAL-TIME 4000716001 :SOURCE-BLOBS-BEFORE
 ((:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "0241da912be93fdf70b9a9749b759efc17aca329")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "30f2e951591f8822ce780f77cfa9c4ab93f0a98b")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "8f682f6ff22f6a0c1847b71be3994e628d399a77")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "d654f504cacdfbe7e144a074e0c2aba5ff2f4b31")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "b239b5187a2649125b7429273cb0fe4f4cba673b")
  (:PATH ".gitignore" :GIT-BLOB "19bf1ab91a6ed3c89cfff48070fb170b09679360")
  (:PATH "CHANGELOG.md" :GIT-BLOB "71a5b18bae29351cc2ff4c119e6dcbeb0e6c4e98")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bb642c10cc99a2a8d62cc101ec1c6e9903ec1441")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "5820eb0ee2f06bc024e238afe12106b0e74275dc")
  (:PATH "README.md" :GIT-BLOB "99958454de32ddbc01794b0817781c287cf4c0d6")
  (:PATH "SECURITY.md" :GIT-BLOB "27fb94691a84b389d72184838e38d2e43a8fcfbb")
  (:PATH "arcdocdb.asd" :GIT-BLOB "3623493fdc52c3342c4068f52ab850ae6e56e7e1")
  (:PATH "assets/README.md" :GIT-BLOB
   "933cfee445a3fe85c8b9ca8c7c4e48afda9bdc95")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "0e9fe71b160f4ff7fcc61c9695159b00e352b12e")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "de51c5d5d625caf2ba89581880a7e932a86d2556")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "9ac19a17e0c095ed711eeb2a9da52b4965d3c481")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "b6dcf61865707b01724190e83c4987aa5d98762f")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "0c81882c35757d460e55f808fc6d2370f845550d")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "d65d5b12f248347430260c6671017a0894ebd3eb")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "2713de877ed961857868b53bcc346fe62088ec0e")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "b0e2afc520b8ea9a540f0605f682c1182b5af3ab")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "2e83c526df9864f1c3d2373fd313e4ea61d29fde")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "39cf33413347ccc9d91478efc1c08355908c23c9")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "3eab0ad4c56c1744c456579c8e773c5d7fe7493a")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "6616ed0cfadc71596ae3162affdef4f75f608de5")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "0f702230f39f3b4761886499d99b2eb431514908")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "07b5adf23d044b552d5e038adacf194774dfcf40")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "b92eea4011a182108002786370c8330e8271e356")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "db87b7732e2e42f22c711a89f5deae97f5f00757")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "1b845787d56dbc1296e7283f809e1be1bd0d3b80")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "826a6f1d12e37dd26893598caca3889010be7480")
  (:PATH "docs/README.md" :GIT-BLOB "303b4a009be18ad5f03ef990156ca0e145914fb2")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "88eeb77497b6d6124010ad65a71b98e08743131e")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "a4d7157123f6cad4b92d3722e136bd02f15fa138")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "fe20638b50dffc66f5d5b3497f00e5f526ea046a")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "2b9f1e16b289ec754c0ac0de79e7823852c4815a")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "4af05ad11f846d733b3485bfdabac47535f41415")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "ac6e1e0f042e6ce5622c0b579ff8d0419a707980")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "ad70fc5e177886b0be609ebc0234c0c7c2fbab90")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "7e6590a619252983120f8ef9b5b3fba5bf24659f")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "5ae6feb439b1d182febe27d16e6d485183150d6a")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "18de49d285e52d25e055397f47c829ba7db45500")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "2f04c342ca714f0638dfdf2bed17fe48de54edc9")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "1a86df3d58358950d8b658b6b8194563288fd0c8")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "99ca666f07f0f04168af74c55459ca76a6f421c7")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "3ca2df1c7beddedd65511d9282a547294cabbff4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "87931cd80f665581fc43a2b02fc6738ea3d57fb3")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "001950113b1fc347642e1939ef060d93a54096e5")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "5a442b2aeb665be3f23da887ff615bef889e167d")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "250c272e2ddaa4b062b956d5ab3eb66ce610b44a")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "be9686df1c7ecb762bebac602bab12010d73d0b9")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "6fff5ed7db6d11a51f12b167636b7a23a3750068")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "83c6cae3eb56b9edfda572533258d8438132e0ae")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "81823c873cf52abafd86a3e8ab35df2e161d1034")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "623209aef44929e1b8397b1f8470dffc20d9bbf8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "bc3d2144b30022e7ab239c561b6986a18e10ec8c")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "470ef1b7f52d571ea5af046ccf06896729a06a13")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "24235615cfaab3821cc38bc9b9979a9928c6dee9")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "8c29d6d4d55cbc7226c2df7361a3d7220c103f8f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "225aa16313ca4b54a04da07851f0824c2494543a")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "506080464430c1b9e5f2b09816d186ca95e3fcc9")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "328152db463a6e5796435ccd3867d8838429df15")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "b9dae81c93e124b6db129e90fb641c85ca349c93")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "dc8228d1c2dc5e01fa6a5cb6c69ec9e8648427d2")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "fc947bb28bdf5a015d7b353f56e0d6fb86a524c6")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "4646cd378729d3841b8419b3681477b4e1a80816")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "dfeef8dd42d465d1c97830bd6f8304d3f8579416")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "eb3138e9017cc95b7f71fb29ec3a21e4bc44a3c3")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "d4140bc0d14bee6ca7480e94fa96bd8c79e656fd")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "aadf427743cc9b511c4fac4952ec1335005b5568")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "fce6228c1a393557b2475a7600cc998246de97d0")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "c347b791cfa1e13319894e5c2a9c3c20527a7047")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "77640ef6687df0ba7a570b682000bd4b2fa042cc")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c571f195148361a34fa6bc9d1c6f35836742ab11")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "ba7550dfd1890a483f313610cadc808142bdddeb")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "1f07f3d9c4a9a1b6a0c1250dc09923966b2081d3")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "3ada528fa148db73ca09df933265ff82a5e0dd6b")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "75301c4284016be1da4f6f7a9e4b8a1c00b1fe8c")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2ebb221d1f2e8666fa62910f561728eb6ee0a9f3")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "4c11a9e20d9d7bf315bf7623740addd876019d77")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "f36aeeeab161774fce91906d1ba5d47e6b1a8636")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "47b35236825274bd340b61e4c30b7b38d8349d5a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "f393c09cc917be5e4a123befca7bdd3f238ad8eb")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "123524e58806fe8cee2727e5ada0b00561583a76")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "817f3f72a09e74d142b160bd8da172b459f327f9")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "0cb9800d4e89438f0ba2e9ecdf763245f0768196")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "83dd5fe0d9323805d7e97e6814129d16841efb80")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "c031db7bad8fa2f115938e3699e6ce01bc436bec")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "fdb928d6caf051a0341c162d537ca5d6351acfd9")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "61f400316607e9c47904680e6730c3034ba5897a")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "ebb3e21821c8b3d53a40a3bb6594b5c9ae20fc50")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "7800931fe3bc4c8204cd873ccc0ec8ed42af8b50")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "7028bc0b2b30b0ad17f9bbae81590519d3775e73")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "13ec9283f25316675f7bbbc2e95d80ed18469da1")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "80f4576d4e5afecdabdc3620771fc573e4ca9c4a")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "7137f05ec0a8e6cd345a00fda62be573855da3b4")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "2d883ca7e34a8b31f88930e0d266ec0a094e6b0a")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "10857a0489e16c0f7de3415b872b0c9a6002c1b7")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "00a1f025a375559acf548fb855c59d42e4a21642")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "173b91ac893a1bafe8d16ddb91b99dd6341c1a01")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c8182641591fa6f24bddedca56f92145a3c7a038")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "b8b2b37a18cb4d01815e07df5e64e763f273a9d0")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "325784adbb5cff4121559fd3d50a1ef943443434")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "bc95228574813d37b27882f24713e4d834788dd2")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "69bf38c64b527b5aeec011f9fe49d9fd3c31d253")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "9eb64c8428b638f6c0c1f0aaa80c4dbfd0f900b7")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "e39571136cad9d563a933aa608c011b887f17260")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "a83c5cc798dfb87750030781d015eeda260c4ac0")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "245f95c99a4735fd40a1d9694b4a5826f5ccb5d6")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "9f6526bf5c135cf43289127c4c1bc5dfdcbb8114")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "162cd32188a030d6cc3c5d16585054aa36055175")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "4af8109f8d01f1107791836371720802876ae775")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "2a9e7f0bf30460b3b7dbbbc1c7776c9259fe545d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "3935fc5225836a0669664701921ad1bfff3d443e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "8ba7e4ba06ca958c0be9a5e1128c63419aa7577a")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "a83375d3c09898353fc0173f3171884f92319d73")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "d379ed246db14204b7632b7b3c31266bfcd46b1e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "ba4d2ed61bf06d0504bb1e0067c8741ef45cc4e0")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "8966ac0cdf66fcefd616201cc97017d384b3f0a8")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "cd2f1ef9dfcd3f9029549430c21ec553509a62fc")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "81675040c1c6155f7e3efa669ca62ed4b8a63064")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "d8b22e42e7ab906488cef72d935b71d4a83ba499")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "6b4a59954e2d48cc30a044b57cfe43b0b91ae1e8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "7d44d58d7de6c62b2206a8e35be398bc34811663")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "9605de0679e062361f80c5654c5fbb8028765008")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "8b79dfa3b7cf5011b66534d02c2a4551232d503c")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "e9007f26d323a1ffd2993c461c3f84ad2aee90bc")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "a25b46457201e1a7885cc9b21cfb3e66267ec12c")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "a9e2e9dc6d0d4b968a9940d78abf8ca2de825e98")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "0a3a2123e618a8ff39e86dbbb70db36ccf51b133")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "2df0a214fc5cfe64ceb239aab4f7d2a2d1827305")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "1c1d617e19c0d74199ef11a56105d3ed90eb0ec0")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "56342dae95caf8705e0b28b3c0ea7ac86fdd8fa0")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "90bac509af0aff7b7085a2239de6e9dfddfc70ba")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "cbcfdba7c5967d5d36e5d9487f6a7b1ab0300a53")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "278d9413eab7578c99a07b1c614db37c83141097")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "8e1b0d0d6066669e1ffb65d95900a3b1aa385c51")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "c9808d48a01444ff6faddf2d8389673f91598db4")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "6b2909a5f56212947dea864584d2f96252fe1b1a")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "f0a2791f988b0d0c513629824f75ce1842fe059a")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "cebaf33e7e7cde4efbcbc2ada22fd494577c9e81")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "7b22c788ecf0d69f84316f39d2f580bfadb7b91f")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "76509dd8d44a61eff9129d08fb19c289d57fd1e8")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "93f1366c17eca13f37f63927d64779f7afeae658")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "a48d5b525d2c78fef0399666ebb14c6f8a2342e8")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "8dfa1cf8533764fdd89014f31cac59d02b248e2e")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "759b72a96a099d18fd353ef8936d63481e25129c")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "b28934a0a4eac77562b07fa8db796c167176ef36")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4a2c524c6b1c7be1c1b5d7e43d35d385ee7f5b1d")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "f6cadf13877cab21d869993f33e485f1af116806")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "8dbbd94b11ca62b266df8e1b58ef8b15487dde9f")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "2e1d7abdfe9b4880682ff1da97b526e180d01370")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "0264c59fce79fd2a9f34d05f85c8dfff5fed69be")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "a2a8d5bba2c3da3ad6977d6a6f750e468d229693")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "1aafc63fa8904a8504ec6fd42d34b606d6505677")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "ac23ebc4c1d6ab57116def02bf4ad7df115394d1")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "8fe4debab581640b3d1db74b6fa43610c8e547d2")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "a3d67947dafc891946df3ea19706d32d67b24a80")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "bc99cae302da8bb90c208cfc0d5def111e945269")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "79755fdc3fcc8cdc8459d0cf3d108d06e577bf3f")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "c3467fd1f58d977797821581ff127bfb2cfdd5cf")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "a0953cd3789ec80e22ec33f445510db6769ad2ed")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "4474e5ced93e129bae0ae13255e2c56363334f20")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "5f8fa54b5df938dc51ea2053298baa58413d7e5a")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "4434a2412cbcc6bab1bc5292331eb2c2eeabeb6a")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "ae05757ce562c9b2eb5632765cc9da4db8c2fe56")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "96a9d6be3614715a434ecfec5808375e06ff6468")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "a64f148cb2254e87c649bb16e7bee39aa45eb40d")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "a1631f582d8b3ecaa177cccead8c1e3d0051a822")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "a1adf2c6d8f6f13b0c583451ac732b439e58eda2")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "69e50510426fa53d230b64b89da9e64fdc5c6efa")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "542584f7ea490cc7b4639ee42969c17f52a8e559")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "204a995d2152620792e923275de5abcc5e29bfb3")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "efdcf79210060603b8b7982057933f7b57a3c220")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "ee84732af73d4d753b211bd9cd33f9c7dd1d2a3f")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "3932b391102e3b7e0ead521a1fb223ef5ca2129a")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "058623adabd6a98f7d7617c4c1ac4fd0b7bce825")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "30f47c1882108bc0c2180c5e51a67b4ad23eee11")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "acc39ebcd47f56d31d5ddcf9843ebf8543424f22")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "a6b480a9726002150f65443b9a3c97c9039f2012")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "c799f6cd5399c37daa1687cd0d154ebcfac2cb39")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "d9de17c5fcd7e7f21555c68db8f3eaa7d7e1b158")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "b7c4c84c6d688015a43f81b476e58744fbf5d467")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "f103ded38e6cb575820d7fb89d72e47b9fc16693")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "d09dc4f0914935805770cf148cfab99b1ca30eb1")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "ac29588884b2f12f2bd67a72f04504d88c2d44a0")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "d4382b97ee69a12235f4c1d445b9b13dd5440684")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "4dc9aa9bdfdd5e21a2ef2bf6ab6fc8d2e111a586")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "c88785115dfda86f3e6ce425487638fe514f0e3b")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "1950d3f3b38736f7d32e1c3a24fb217bd1dffc86")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "a220b68f94b35c81b9bca4420453c4057eded097")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "37ff4f5316483960508fa78df1f890ebaff8942e")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "27cb98d6bf753515b880d7b09e8069302a0e72d2")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "476e35fca8858a4a4eed163e4a3a42c7ce38bd4a")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "550c69493fdb363631b83dea4fff765119b6ad5f")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "04674e8a8b7434d1008a0e62176db98fe54e0ac0")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "656e8162bd3833268a6243e136c2e46b39e548f5")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "f779f81d41748e3e9b10596dc9af12b334d4dc23")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "f755abc620aaad10470143418702e883baf2493a")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "6b39b77b28e576610308a9d98e540df64e28555d")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "cb473b09149385d5d32bb44db1478e5ba7da7640")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "23966839673d2e5931f1822c0c2e0302a189911a")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "1b746fefc25d8cd1be1bb44611c7ac5f98e8acb1")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "c451a24e86e98a2dd3a75cfbae55260625b33dc8")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "096b16489aa910182fe01349aa5552ccc1ccd446")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "f77e4acc65f3582d76bee6867e7a728757a98d4c")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "b6c4a6992ef5ca707c19e08dfbdc7d1e01e1e900")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "6fbe1f002e3e18df09a964292f27c3657bb46004")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "b275c083f9705d1ed32b4cf282fd0c12c39d98a2")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "3c2423f187253e7c2c83b3848c7efbd43d269641")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "c7780a6798cec4964badc6a5529508898ae4945c")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "bbc3431b5872adfdee0e23d566caf7d2172a971a")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "8101b2da12ae1a60a0663b11ab70590a96c5bcf2")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "99cf34e5c5c3875ed97414c30ec9b7bef96d30b4")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "0a534e557a3fe8216e0d5fbfc84c354255d081ac")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "d17e9e45a1d4896249d11f2bd474aa05af5222cb")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "805c6b231d9fd7223ef1b149e75e9c3be0dd0859")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "d6e2ad12c278d5bb26050c056df4342671c590f5")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "77d0c406a967ebe97f81781f9dd4cc9d68488ee4")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "1798cdf9b8916ba74b21d1d86442a49874938e41")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "bc3121e6274d610f56155a1e159d0a8948ee87c5")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "73bfef0b478f57c9441a6d0e2ab59c0e7f223fef")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "89a767f226693292d6a934970010d6dc5f13bbe7")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "d7e1f6e6fd5baa3c0c345507b8c3cd7a71e47f33")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "497b96ba252c1d223b91c7a958af3a1de6e6bba9")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "4b9535873216af6a4ede0b3d6d31e80c466ad395")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "6c46cebd54cacfe7b366932d1be6bd2132346087")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "c9ec2a33ac47f9811f152032cc6232fb1ccb941a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "9cfa2d91655890f50c7a0d83cb14f0bbae650f21")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "08c866115be68fd9e88c2d30fd111017851bbb53")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "df02aed3cd659b1b09e746d8315f54e32f526965")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "2d2ffb30c9051c58fd7f9b7efb27a487d1c0fd8e")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "76b2e79d012ebffcdde4477af9b19fb2e1e54e67")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "7e470b27c01de9fbfb4d4b532136760ec18afdad")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "5f0636cde6711769dc13bdaabefb55e6af843147")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "f6eb25d050854b65daa7766d203b3e177dbc8f4a")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "04f64ce2d33e27cc5d40482765223aa6dec062ea")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "e4fa3bae3e265d1ca702c1ecc6aa8e44c676155e")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "f76d0c995da17ae17ef8ccc6c68a3045ea461a73")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "a92e30d229b4d76f6220a96ded2c46f4054544a4")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "c04cfa11a0b9edaf4b73a251845690cdbb3ee98c")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "caafe0a8685e4faf2215bebe5f37fd1a80683f93")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "1f01809c914084c4773dd184439d1cf599710f09")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "ef2ed1ac671dec6c7904174152fdd90dd03c4589")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "dfd353b4f7544d41a04d916abdb4a0aedaac2c3d")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "b94583da79c1834c306118ebcc013c795b286ce1")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "4d6ff67e6e78c550986e2e953ed8a9a5d8b4ee20")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "db7e38f078621af681d9b5e523f4c91bf4801c6d")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ffd1c9ac47dcab5ab8c1c0301c0c04c3e2686b6e")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "01109f06ce875665dffb11263b80f68a2d3c07ba")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "3249fbcd44f2f2e76a14195461a3a4e43b3031ec")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "a12ac9c53969f6755c8cb0de21212f06e7e03e4b")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "f500b01def047de7973851144c8196036abf36bb")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "2e58b4d0e459495430a6cd1e9540994d8a25a0da")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "f134e4c3c3cfda195b324e7bb362948b67aa1fd5")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "5ebf0d1098584b8ea8dd380b92a9b913980f2285")
  (:PATH "docs/limiti.md" :GIT-BLOB "dd24577016d7a14379ebbbc35a1e86a0d23a4295")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "4bd3d55870e1b05b12a4a2287de6b5186f2d3b5d")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "f27f1e9ecbf711aaa240bb7697f6b06f553bac2f")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "2b56cf1d8636aede273e4cd12165ec78a6ba73f0")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "742c9309d02efe4238c859a3a7c6cd577240cdf2")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "70d45ea89536739989e90f7815ed8e89fc1544c6")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "51ef103f889daf79bfea015244af11bdfea3c3c6")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "52300ff2ab7310e14b02fce2dc414b56a08c8f6c")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "2004d712f3755c501fd2b506b8f729ce6297707e")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "c5b7d4f08337ce5b0fa7096b872e21ca8c94462e")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "2709ceddf253b8a53c7726f2fcf33fc0c8d2ecff")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "2ed70c7629bc15b9b7803135fa000168ca818cbe")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "989474478f9330b3f8d731cc34c190c229850217")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "cac1621bcd068d757ea86d25ce1da1d5d1f254e9")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "0fa9272a2986414342a107ae4c1e5fbde3720958")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "9647505f8a2ae9cf74348487e9648a6c0dd5d252")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "25d94d78061e6c68007e4316aca4cdc60f9de610")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "a95cb4392328411d9f17c334c149d9c029535102")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "679e74cf6c8051dd57ea1f2fa0584c46aaef47e2")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "e8af15a00e7178168116c0138027e820c07e598c")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "139d030b0125b61aad567263b7b7db95e830e927")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "108872e995b0def43475138c76e11fdb5d578ceb")
  (:PATH "spikes/README.md" :GIT-BLOB
   "14250504c27c786cd83174a7cca53bf273af2125")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "81c46b7e0a82ca474857d5e5de01dc43c0572bf1")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "1683f3951361ad60dea42821451a4bea35147b6c")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "19840c3a15271323546259e5c0aafd7d13489681")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "54a1982bd08ac27197c3266bb2f883aab405f705")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "f7d9674884267ad4d22f962c762e1995b749fb44")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "f8480d84bb8e932e0a17719c779ea54709c3c3f4")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "1c6ae01e442bd3c4d8c829006647aaa59ae1a185")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "91732544806c231b77dcbddc9a2e4460a12873ec")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "16ebc31ba682d36cf3520086d43f35a310159bec")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "e5d56bb99d2bae3867cacd19d18711f35e6ff8db")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "2eca7df2fd82994b4ad13ff58f72ab5efb9edc3a")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "ea4feea4edb0e4a1dd7ad357419b6bf97b415f50")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "51be4a3beb85262d453bd6b283a3b31378615fe7")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "f23f9ecd889437c83c946c88f2bf56a45a73f3ab")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "bbeac271ff79f96c0f69d22c60a045a4bfec8f09")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "9d97ed258355e5afd21edfc1820ee6d68137a02c")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "729f3500b4f427612b39c02f210c4ac25f45c805")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "a6bd28dd37f149b2b47cedfdbbb7b4c11fa1bf6d")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "648bd776767e4be914a2470069afced14bc1c1e5")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "a813fbeb55cd03980b2215c99fc3170d6afa4d92")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "a05614fee1df43315393f048efbbfe9a948bee9c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "6b3bc87d5700e52ca6b861fa562c2b7958248887")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "9e9121e124a6af86e9ccb8a253f69e1db584e873")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "e6b80fa0165026cd1a89c58786ec35d240bdc6c5")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "a1fdf6705a10fcca3926f40e26051fe7b6df5bf0")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "5755794e6b6afeed6f00a698cb337cf4b18730a4")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "cb5452eab513ddab4db6eb2955603a0c133d4e77")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "8c83b0067a0481759f14733e3c60ca888c6d01d8")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69fb5930c2722871c30056b41c13f7919058bfcb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "b5cc04cfdf8ff989a5eb6081dd100f8c506b081d")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "e3ebc7594ca6b1ae269579e5e9c7f9fef1b14300")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "45255a912edb4300b1f22c9505d09be5177d1d4b")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "5aca4d48de7bf0d849eafe87ae89f6e7800282d8")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9ab280c17b61b8f98f8299cbfae676942bb3ae47")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "5f4f08a4609bd264fa058ec25ba8f6a516c162c8")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "b335ea1d241672a3989da65b9a7ec516e7533347")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "bcd7de80241f809dcfce472741f120a61ac787b4")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "ca6215b30010d3d2eb90eaa6fd09dd5a9ac7778f")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "db635a50678f2712ec9516be335717ea254d4d09")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "761302dad1073c841397f6c88d595b114af8d9ef")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "12d573ec29468f1fdae3e674a494d786a390c33e")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "57ffc48cc688a4de8ebec5cb14c1e69c4209704a")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "70272936e323b3e0cb05173c9fb68cb2b614c355")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "f1afe79c7a4d49abd6a6e5f6975dec830ef7b1f6")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "c574e87af5e195ddf3f596a4ae527e69c7a3c6a6")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "e3d7d77407046338d23e26eb0b8a2e8fdc3d699d")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "a8330e50a77b52a6b9044ebbb48f62bb4b3222a3")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a2c5c77dd51bff760bff4508e998d94370921eda")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "61f0d6e2783e4790ed7e19a45bba6407d6e5b3de")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "807939c0fbc5d149bc7c8c1e29c7864ef7be991d")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "26726c45555ae8490e0dff31f61f70735183acc7")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "9eb660cca8f097e25ca3c1535cace8c20bc1e238")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "80cb600f6c6d724cf1eaec25c3d2742c8c320906")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "9388a84a1beb35cfa2bf016471389c881ad38628")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "a3dfde4a4780554b88e6e037ab4f70731f9c884a")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "57235763cf556ecd7633a0052f265ce3eb2b0462")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "f0f1cd22e87892119a4b7768b4efe5e519925dff")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "909dfdbc901c4cbdeae5b47faf52480350372524")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "34c8add62a6df92446be5234ef013893ebcf6879")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "bb4d4d6f222aa360ec64ef2f45ee6ba0524dd2f0")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "58981c7e41ce2694dbfcaed99010a3a53e3c1dea")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "5b3c26f78d5c4aa53ca200abdd3e0f753f926b54")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "4119f86231b7d8698fc3558868ff8a5bcbdf3090")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "720f16e96203f00e308727b430b66b28689dc7bb")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "4f34d18152d77fbf63bf708ebd0aabac178c3ac1")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "65a3f3c9e84c83b900c1dd8c9cc2fc21cec36c52")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "6d36e1f64d79f24c95209fd70551953e40c62335")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8e5102497f628796fa8faffa2085a165496af230")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "2cbd40c539b13dd80070eedf4af82bd1b26f4b28")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "2d514f6fe2e81eecb29fa53de611fa5e28696904")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "edbe5eaa88c50dc13af8e367b73f7f41fd7bd724")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "f9c691d28620427099d1d89a89a1ff5d04cbe257")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "bca6808e75e144ac7e9643df07a1cc6df4f70ed3")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "09185339cab38ab937045b40c52bb1b9092ffb8e")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "f1a1a37ccd59a81e7ff91fcb36009d5953d7edd5")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "951e5efdd1977c18a5bd90a1e4b3199d60e92d38")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "1d93461227b222a8effc53ec9344c5dab0b531fe")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "ec99839d234468298b553e331873a320c8ece53f")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "14bb99d6529c3d741f60472d2c3e822dbb0f590e")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "70341c7c32b364603d38bdc42e8b3af1cc631773")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "bd75d3a4b7483900689417ae3eb2dd65e76c8468")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "49bbcd30fdf96963702148cd675d5d3066189309")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "5ae454c03e8a9b9196653c8b28df0727e480d142")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "17e5ad4e2206e280c3f7324adc5c8a1e50e232e0")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "956b6c7145a25dc64a7247f2e14321876ac08f15")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "55028dae42a3ce1050d6872665c3c3ba6aa3f74d")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1177496e5baca7f7c698156e196c60fe1fe2566a")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "e1bf83fbcc737b55eaa71bd6b41a912a901178ce")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "6f54751adb255f49582ff1da62f951965c3860a1")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "9cbbdb6200af813bc9595d0ef964628a9ba0368f")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "53438f156d3e1e15f3732ec840223231b308a7a5")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "cb426426eac6e923224bc57c1dd602405f4bc040")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "23f16c3039b71be0bd46d6bf92f05791e444683e")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "5a105a141b43f5585f8e79c2965d59e96cd35ac6")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "cf168c44bfe5aedd2e34180ce4f766a6a89500a7")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "c9b8488d0a1aa7643a6ab1570765ec870aa7c9e4")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "032ad088b19ec3498a7c80a5e4b96d7777257dad")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "0d8e799b889df829aeb46054ef100377845dd0e0")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "f115b63c6089960e9857469475f821f3035a5ef2")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "6d43b042d7d9018f8aa48e88fc58c24b5a089cdf")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "a83ee5a2d8903538f8ba977ef0f5ddbe3a357d6b")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "6d05b467aee412f447308eb697daa7f4f5ec6f0d")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "5627b4179b115c008379aa3e60a4724e63f9657b")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "20de8a35a4deaa830348a6db5b5bb033a82c81d2")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "aa80e1b0b6af77379cfe2f2bd12c0b17e5c6851b")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "20d4b57b2a7c4b9f11205e753b92301f74f56cfc")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "1d7969c842b1f9a4cd0b9eba2ea3496cf914a2c4")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "aacbb9975ad3795d848c4523d178af31d34aa7b2")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "f36b55b9e2d9002ed2ce203a0289c92984c89ac9")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "b5b8243bc40b44af8c34ba76a5ab732675690af5")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "2282593c0a431f3f73fb47cdfc7a8e530e704ce7")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "b8009b8313054c9abebb70de8f8223fb1df708f3")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "5db1d132d91fa11be2b2624ed4c0c8d5405ce591")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "abfdeb5397f8be1d390cbdf47f4f02cd2f36bf91")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "77df997ef72008e7758899a348ae07695bce0b38")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "8555e14347d05182c99b756a312207019e2f904f")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "79d794b102c3ebf50679426e7cebbf49f02683ce")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "321ae3d1fdcda8e34efbdaac4b10dfc08fe9d9a5")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "012c8cff2c265aa7f0daa909a9a0dd01adf7ca3b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "3c7cd919b94dd9458422143c18075dd7498fda1f")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "a8088783354d2e4e5048d6ac7a3bee7afff92719")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "80156ca526a341c845fc43fc9963097f8669e65a")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "ba31b07379219fa8fd80fca169d43a053d28063b")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "0b93448ffe9c6dd4f3a0a2f3f35d5cd656700bd7")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "1b6fe64ea7145f33bcf08c02e8550034ebd6a40c")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "6b840a0eb039afa7e55304bffba309f0ab72acdc")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "93acbd608b1af475aa505a6a7dedceb3b15e8d4b")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "b496c1df87108127da568a1fb7b0fd32856afcc5")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "01875b76743c514ef07346a32587f4dc5c34d2f8")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "48372f6f09a54cfcee793ac03ec321fca6ad18f5")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "25d93efc7c604042d09dc84e31baf1f4e2c4c45e")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "09d73425a6e571c8fac6669b14b98e3ceeb7c96b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "c9cadaabf755add3671cd1cc0408c3ff216df2a5")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "bf80277418243422144cf6ee71eef83d7eff6da5")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "3d0181717e3f334580bab9a6a507e2dfe57261ff")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "132e44c138e209d3f8840b098cca0424853d09c3")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "b3601060197a27c6e8a2aaee22b5576c6b0c6e5a")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "b30795fb7efad5f5313198d345ffabb43249e3fa")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "87cc54024e59757c16e20f3025970b1699b11662")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "878fd1afdcbf035a232166ef87066af4420e1aae")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "a6ce94b8be3c8c84043abfd6441599f9780b2c11")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "e58176890a26751bf5767582b279cb667a29744e")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "b133ea00a3b8063e9e934a1b41f10cad024471ae")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "0dbb2b3bdfbf5447a5904ce0fa6e4a97337a6827")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "60057f6a50c657f016bee3c21c21911b582f86fe")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47810fb2944b4b5c18d9a9c8e60dfdc1c5f19db4")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "68c357d2d522fcabe79284c540c2631e5fa87780")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "e74b806f5116db46f3a385821515c317b2dcb452")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "ae5b8e4677fdd1dcee2f2a1baf293f49d9ce2972")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "eaddc83c63dce2fde59227e0416917bbc766e325")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "5405bd515df8b26b792bd0430c9ec3dbadce63e7")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "55e56d621129d1637eac1a787bad60dd0f0405b1")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "e062c804e68a8f62eddadd5c87db0e7af392744f")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "7ad6b7541397611f1ecbda7dffdda98c4453dbf1")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "63fb4a20faeedceb47b8cd550262f1bdca497c06")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "128fe9650a741541b46d1ad0887b872cb2e85012")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "7352a27581b8e2e68407611e65e46773efdc333c")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "0cccb1f1b9bb8f63a308352d64426a420bd1e283")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "48a789494e731732ae0b378347e133d50daacfe4")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "7f91ca22b7f2f339b450db0f4c26c97f86906c58")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "fc42b51a0f8606687881e239ba650a9f1bb58124")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "6fbe5e4720187be3bcada2dcc9fc40026267da07")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "f280c35e8f7ed283d30e8f4a43bbf2f172600816")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "e350df4e2fdc2f651ffbdb136bdbb266ccafcb1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "a0def7fc9452d291e2e60dbeff26a56a2b06e3a3")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "acc9f6ea83a8ef2774b41bdb114165b6bfb54949")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "02c219d556a8cd807a0e322667dfb401d8b06fb6")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "39f28974f3fae098d32d4ad1a056a45b06f777a6")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "233556c366a99b7b263af1c7bc19b47ceaebf940")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "7980cac6cc8070836b9aa49fc8a0d6fb42630749")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "fc942f1c8e30e637abaf13dc26343d40417fc72f")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "fde8608e6ad3fe062937c48bdcb7d2d5870207bf")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0012eaf90064c4cc2949834a60e83c9db8ba6308")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "6cbbb89f681965173e9b1b95edf3f7f870af1eca")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "f1d99b205b1ea5e6ad059ecd7971d3633411b040")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "6d30698383477880c693954314bab03ca8affe24")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "f65662b4dea8ef04e4e59ce38b29a94fecea4f6c")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "edc8ce7474365e0885925d557a378779655d2e70")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "8245bc10cedafbff8665489fbced6833f078a373")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "ad1b1356eeb10248526f15ac31d2cc9b59811fc5")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "10c4b1949994d01cb9ed231f66a69cf81f1ea062")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "56318b1632a7a0ae11f2987cdf0d4bec68e465cb")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "e613ea025c2a886cdae7fd5e119cf80593c6b72e")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "e45437a508fc7893c4df06f3129ab064d3a4dbdd")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "33c7e6a9a0d6bbd551d4171ece6681b66bf87657")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "3624e1dde5f5a484a117f4c783d4e6b88027cc89")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "720d80c6dd5a962dc724835c1421635ba289b7ef")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "878f0fa10825ae3d49e9cac2f94d9992c06f2d20")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "dc9ea34945c3a8c52d5c62062951674d27becd5a")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "4212f8cc4be686e923cdbec9ded24f42f1da74ba")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ff6df200a7ace3af204b622969a387ce7a1e1504")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "24543b1595fbd12972e7073680fde062337b8417")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "51351fe8bb7b748fdbd7e8af9efdff1a8fa9eb56")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "0f706343bab19794f90df89400b1e94aead1db38")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "3cea6b1438f8ef7095726c592a991028e203da32")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "55b8fabbec5c66417e16b34caa5f73b0f24b1e46")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "13b367549c38c5fff1b826944df658ad1ee0a7c3")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "8d0ed3547f0dd71e7d74af31ce0ded585d7bb436")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "f2209f6ba53f7140069b42151995bfe312907561")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "93a40af0b228460656d9ad48f4c123e7b6c842d3")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "362141c30925f7bb8a3936743454326ddc510dbe")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "cdd7fd230964796e716a452d8e4210719108782b")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "fd285d0ae73d312d7234a2a142d16897c9adbcf7")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "d684d832fc90ed4ecd685cb956570820a806bbb4")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "be5fc283b3c06bc60548ea32c240ebf8d9ecafc2")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "4e84645950948a15caf27e4f9c5f18fa030efcd0")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "2e7364821e345b8b8714856a6a2f03c684140320")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "9421994e3c9883b423f6f17311d1b26c094ee991")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :STDOUT "(:ELAPSED-SECONDS 6235617/200000 :SOURCE-FINGERPRINTS-AFTER
 ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . \"692a695f7129e0cc693cffb2983be35b\"))
  (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
  (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
  (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
  (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
  (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
  (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
  (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
  (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
  (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
  (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
  (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"62285b01dc017898fc16588b6522bbbf\"))
  (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
  (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
  (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
  (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
  (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
  (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
  (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
  (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
  (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
  (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
  (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
  (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
  (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
  (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
  (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
  (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
  (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
  (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
  (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
  (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
  (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
  (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
  (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
  (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
  (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
  (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
  (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
  (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
  (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
  (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
  (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
  (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
  (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
  (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
  (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
  (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
  (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
  (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\"))
  (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
  (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
  (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
  (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
  (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
  (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
  (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
  (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
  (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
  (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
  (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
  (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
  (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
  (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
  (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
  (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
  (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
  (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
  (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
  (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
  (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
  (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
  (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
  (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
  (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
  (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
  (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
  (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
  (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
  (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
  (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
  (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
  (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
  (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
  (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
  (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
  (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
  (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
  (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
  (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
  (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
  (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
  (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
  (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
  (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
  (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
  (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
  (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
  (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
  (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
  (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
  (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
  (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
  (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
  (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
  (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
  (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
  (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
  (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
  (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
  (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
  (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
  (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
  (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
  (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
  (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
  (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
  (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
  (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
  (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
  (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
  (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
  (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
  (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
  (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
  (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
  (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
  (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
  (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
  (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
  (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
  (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
  (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
  (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
  (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
  (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
  (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
  (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
  (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
  (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
  (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
  (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
  (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
  (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
  (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
  (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
  (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
  (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
  (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
  (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
  (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
  (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
  (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
  (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
  (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
  (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
  (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
  (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
  (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
  (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
  (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
  (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
  (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
  (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
  (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
  (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
  (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
  (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\"))
  (:FILE \"tools/get-directory-mutation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fe7ec868b29f06eb5e968896d5b431dc\")))
 :FROZEN-MANIFEST
 ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . \"692a695f7129e0cc693cffb2983be35b\"))
  (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
  (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
  (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
  (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
  (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
  (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
  (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
  (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
  (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
  (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
  (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"62285b01dc017898fc16588b6522bbbf\"))
  (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
  (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
  (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
  (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
  (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
  (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
  (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
  (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
  (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
  (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
  (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
  (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
  (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
  (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
  (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
  (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
  (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
  (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
  (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
  (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
  (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
  (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
  (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
  (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
  (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
  (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
  (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
  (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
  (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
  (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
  (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
  (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
  (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
  (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
  (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
  (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
  (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
  (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\"))
  (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
  (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
  (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
  (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
  (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
  (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
  (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
  (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
  (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
  (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
  (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
  (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
  (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
  (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
  (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
  (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
  (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
  (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
  (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
  (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
  (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
  (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
  (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
  (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
  (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
  (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
  (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
  (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
  (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
  (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
  (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
  (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
  (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
  (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
  (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
  (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
  (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
  (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
  (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
  (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
  (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
  (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
  (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
  (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
  (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
  (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
  (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
  (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
  (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
  (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
  (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
  (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
  (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
  (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
  (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
  (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
  (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
  (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
  (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
  (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
  (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
  (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
  (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
  (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
  (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
  (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
  (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
  (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
  (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
  (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
  (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
  (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
  (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
  (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
  (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
  (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
  (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
  (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
  (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
  (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
  (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
  (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
  (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
  (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
  (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
  (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
  (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
  (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
  (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
  (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
  (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
  (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
  (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
  (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
  (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
  (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
  (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
  (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
  (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
  (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
  (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
  (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
  (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
  (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
  (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
  (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
  (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
  (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
  (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
  (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
  (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
  (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
  (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
  (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
  (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
  (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
  (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
  (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
 :SOURCE-FINGERPRINTS-BEFORE
 ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . \"692a695f7129e0cc693cffb2983be35b\"))
  (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
  (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
  (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
  (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
  (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
  (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
  (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
  (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
  (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
  (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
  (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"62285b01dc017898fc16588b6522bbbf\"))
  (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
  (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
  (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
  (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
  (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
  (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
  (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
  (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
  (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
  (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
  (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
  (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
  (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
  (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
  (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
  (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
  (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
  (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
  (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
  (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
  (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
  (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
  (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
  (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
  (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
  (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
  (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
  (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
  (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
  (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
  (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
  (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
  (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
  (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
  (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
  (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
  (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
  (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\"))
  (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
  (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
  (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
  (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
  (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
  (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
  (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
  (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
  (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
  (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
  (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
  (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
  (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
  (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
  (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
  (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
  (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
  (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
  (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
  (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
  (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
  (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
  (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
  (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
  (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
  (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
  (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
  (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
  (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
  (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
  (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
  (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
  (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
  (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
  (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
  (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
  (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
  (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
  (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
  (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
  (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
  (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
  (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
  (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
  (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
  (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
  (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
  (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
  (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
  (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
  (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
  (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
  (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
  (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
  (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
  (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
  (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
  (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
  (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
  (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
  (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
  (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
  (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
  (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
  (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
  (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
  (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
  (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
  (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
  (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
  (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
  (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
  (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
  (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
  (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
  (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
  (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
  (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
  (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
  (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
  (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
  (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
  (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
  (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
  (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
  (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
  (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
  (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
  (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
  (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
  (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
  (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
  (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
  (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
  (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
  (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
  (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
  (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
  (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
  (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
  (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
  (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
  (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
  (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
  (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
  (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
  (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
  (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
  (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
  (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
  (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
  (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
  (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
  (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
  (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
  (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
  (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
  (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\"))
  (:FILE \"tools/get-directory-mutation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fe7ec868b29f06eb5e968896d5b431dc\")))
 :DIRECTORY
 #A((98) BASE-CHAR
    . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/\")
 :SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATIONS :STATUS :OK :RECORDED-AT
 4000716002 :SBCL #A((5) BASE-CHAR . \"2.6.9\") :ARGV
 (#A((48) BASE-CHAR . \"/opt/homebrew/Cellar/sbcl/2.6.9/libexec/bin/sbcl\")
  #A((7) BASE-CHAR . \"--check\")
  #A((37) BASE-CHAR . \"spikes/out/get-directory-mutations-d/\"))
 :CHILD-DEADLINE-SECONDS 120 :CAMPAIGN-DEADLINE-SECONDS 900
 :CLEANUP-DEADLINE-SECONDS 2 :TARGETS
 ((:NAME \"omit-directory-owner\" :FILE \"src/get-directory/build.lisp\" :TEST
   \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\" :BEFORE
   \"(unless (eq view (segmento-get-owner segment))\" :AFTER
   \"(unless (or (eq view (segmento-get-owner segment)) view)\" :EXPECTED-FAILURE
   :FOREIGN-DIRECTORY-ACCEPTED)
  (:NAME \"missing-location-first-map\" :FILE \"src/get-directory/read.lisp\" :TEST
   \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\" :BEFORE
   \"(when (= left right) (guasto-get context :directory-location-absent))\"
   :AFTER \"(when (= left right)
               (if (plusp (length maps))
                   (return-from cerca-mappa-directory-get
                     (the mappa-segmento-get (svref maps 0)))
                   (guasto-get context :directory-location-absent)))\"
   :EXPECTED-FAILURE :MISSING-PUBLISHED-SEGMENT-AUTHORIZED)
  (:NAME \"alias-input-maps\" :FILE \"src/get-directory/build.lisp\" :TEST
   \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\" :BEFORE
   \"(owned (copy-seq maps))\" :AFTER \"(owned maps)\" :EXPECTED-FAILURE
   :CALLER-ARRAY-CHANGES-DIRECTORY)
  (:NAME \"truncate-directory-id\" :FILE \"src/get-directory/read.lisp\" :TEST
   \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\" :BEFORE
   \"(ldb (byte 32 32) location)\" :AFTER \"(ldb (byte 31 32) location)\"
   :EXPECTED-FAILURE :MAX-U32-LOCATION-REJECTED)
  (:NAME \"bypass-closed-resolver\" :FILE \"src/get-directory/read.lisp\" :TEST
   \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\" :BEFORE
   \"(risolvi-candidato-get context (trova-mappa-directory-get context directory))\"
   :AFTER \"(let ((map (trova-mappa-directory-get context directory)))
    (values (mappa-segmento-get-segment map)
            (arcdocdb.get.resolver::mappa-segmento-get-end map) 0 nil))\"
   :EXPECTED-FAILURE :CANDIDATE-SIZE-AND-RESERVED-HIGH-BITS-NOT-CHECKED :LIMIT
   :ONLY-DIRECTORY-RESOLVE-WRAPPER))
 :SELF-TEST
 (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-SELF-TEST :STATUS :OK
  :CLASSIFIER-CASES 39 :NO-PROCESSES T :NO-COMPILATION T
  :NO-PRODUCT-OR-SUITE-LOADED T :PARSER-POSITIVE-AND-NEGATIVE T
  :FIXTURE-AND-PRODUCT-COVERAGE-GUARDS T :COUNTER-COVERAGE T)
 :EXPECTED-SUITE
 (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
  \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
  \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
  \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
  \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
  \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
  \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
  \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
  \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
  \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
  \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
  \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
  \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
  \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
  \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
  \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
  \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
  \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
  \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
  \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
  \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
  \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
  \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
  \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
  \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
  \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
  \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
  \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
  \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
 :BASELINE
 (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME \"baseline\" :FILE
  \"src/get-directory/read.lisp\" :DIRECTORY
  #A((125) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/\")
  :EXPECTED-FAILURE NIL :SUBSTITUTION NIL :STATUS :OK :RESULT :BASELINE-PASSED
  :DIAGNOSTIC NIL :EXPECTED-TESTS
  (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
   \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
   \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
   \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
   \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
   \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
   \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
   \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
   \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
   \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
   \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
   \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
   \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
   \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
   \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
   \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
   \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
   \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
   \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
   \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
   \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
   \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
   \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
   \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
   \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
   \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
   \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
   \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
   \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
  :SOURCE-MANIFEST
  ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
    #A((32) BASE-CHAR . \"692a695f7129e0cc693cffb2983be35b\"))
   (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
   (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
   (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
   (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
   (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
   (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
   (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
   (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
   (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
   (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
   (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"62285b01dc017898fc16588b6522bbbf\"))
   (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
   (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
   (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
   (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
   (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
   (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
   (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
   (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
   (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
   (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
   (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
   (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
   (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
   (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
   (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
   (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
   (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
   (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
   (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
   (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
   (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
   (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
   (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
   (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
   (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
   (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
   (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
   (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
   (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
   (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
   (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
   (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
   (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
   (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
   (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
   (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
   (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
   (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\"))
   (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
   (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
   (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
   (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
   (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
   (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
   (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
   (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
   (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
   (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
   (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
   (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
   (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
   (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
   (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
   (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
   (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
   (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
   (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
   (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
   (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
   (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
   (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
   (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
   (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
   (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
   (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
   (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
   (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
   (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
   (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
   (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
   (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
   (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
   (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
   (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
   (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
   (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
   (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
   (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
   (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
   (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
   (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
   (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
   (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
   (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
   (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
   (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
   (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
   (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
   (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
   (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
   (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
   (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
   (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
   (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
   (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
   (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
   (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
   (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
   (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
   (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
   (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
   (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
   (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
   (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
   (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
   (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
   (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
   (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
   (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
   (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
   (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
   (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
   (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
   (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
   (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
   (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
   (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
   (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
   (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
   (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
   (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
   (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
   (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
   (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
   (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
   (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
   (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
   (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
   (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
   (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
   (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
   (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
   (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
   (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
   (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
   (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
   (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
   (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
   (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
   (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
   (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
   (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
   (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
   (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
   (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
   (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
   (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
   (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
   (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
   (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
   (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
   (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
   (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
   (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
   (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
   (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
  :COMPILED-TARGET
  (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   \"74a694385f1aaf03ec87721545494119\" :FASL
   \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl\"
   :FASL-MD5 \"477cc2d85814737322219ae7a807beea\")
  :EXECUTION
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
   :ARGV
   (\"sbcl\" \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--disable-debugger\"
    \"--script\" \"isolated-build.lisp\")
   :STDOUT-LOG
   #A((135) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/stdout.log\")
   :STDERR-LOG
   #A((135) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/stderr.log\")
   :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 1592629/250000 :EXIT-CODE 0 :SIGNAL
   NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :COMPLETE
    :STATUS :OK :ROOT
    \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/\"
    :SOURCE-MANIFEST
    ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
      \"692a695f7129e0cc693cffb2983be35b\")
     (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5d70197c8b64ad6f20c8be47a60c73ca\")
     (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3546cf7f5c5ed138068548c20064f499\")
     (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"72f3a33ce27ddf94c49c495580520004\")
     (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a1f6a8e7aa4faed88e984b39871d1e53\")
     (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"82f937b7b08bd1696ad9c88da2e1c60c\")
     (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a25648d870eaa4f0b6e1e3b2cf76e28e\")
     (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fc09021f74fb50aac57589614dae04d7\")
     (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bc7a7b176e8cdd361b7c4306a1a4de4b\")
     (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"6e8c6a49314c2f460aa6f8a1759200b6\")
     (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ecd8fe950344059c629927b38fb6e4aa\")
     (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"62285b01dc017898fc16588b6522bbbf\")
     (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f6488e987889432b375254021825dbe5\")
     (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"706c0baa4158bf272c4b0df17c1439d2\")
     (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"987e8ed576a21eb644ac1ef2e06edbda\")
     (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cf1999ddb10f879aeefbeea853742d57\")
     (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0c33aedcdb352e78a3c694cf796e6692\")
     (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c33cdcc45f45218aa3e8bf26ce0ee575\")
     (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b13e92b5f24a42fe283c17b649722b6a\")
     (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"69e77bcd15b5413a815a65c5081229db\")
     (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d885bd2a9860eb60aec1a775e5031d5e\")
     (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0f67dd5c51bf6a63bc292ab4e2a280c2\")
     (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1130012fc5613a5648d22ed8628be0e8\")
     (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a1cdb5661fc54beba5bf00e4765f3235\")
     (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"765d14c88cd288093a77a57930cd6999\")
     (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"875201dfab0a84efd40fe9828cc293c8\")
     (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"975b5f74e0c5a38ce978f4d9c7fcc6b8\")
     (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"036dd02adf87d33c3ae2f40735c733fa\")
     (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"653b974f310c09f6e2224a84acc43bbf\")
     (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"82253491f995f5bc153fb5ebf30d564c\")
     (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"6b85eebe69366e78ed5fc5cc20735f00\")
     (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cb5710d6c111cadb7121a50998a747fa\")
     (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8202843bddb817da4279ac959ae3f3c4\")
     (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"38d26f8c749dd946dfc4b9c57103a892\")
     (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a64d98c9ff429d6103d6e10ee1fd7980\")
     (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2c1892002f0599bb8273093031017520\")
     (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c24065d6c8d80d1be53994a0041743df\")
     (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"babd0a78b4185af24ae1fef870c0fabb\")
     (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"aa34ca6bc07535e35fea723878d99f66\")
     (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0679ee07c46f69db330706303c70d8d2\")
     (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"73019644090e2971f2b54dc36e4491f5\")
     (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ca642ea47e4bff76f78f5b6d7287d6bd\")
     (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a06115175f450776762761dce25acdb8\")
     (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"942b596396c19815290a57830af2121b\")
     (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"4db58e2f48bf77d751f1b83bb9f84b5c\")
     (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5ee593a112958d94163dab17c5aa4ba2\")
     (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\")
     (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cde24b2bf5c5637d5501b95bed47df31\")
     (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"4233eef9d87bdec712d4f690bcb699a9\")
     (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"74a694385f1aaf03ec87721545494119\")
     (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"17c957d6934a31f4ed64313e756de2d2\")
     (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8d26428a4e17ad18990b8ee7d5f5b53a\")
     (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"6d95f29b331d335175843f47ae44a6ea\")
     (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f13d422adb6aa9e8489352884137f25a\")
     (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3da469a7aa1e682dd8f2e516ee451de1\")
     (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d6aaec49504a96f37c8ff1bc182c977b\")
     (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bd7182e9871fe82530d0c828e473ccde\")
     (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bbfb2082103e6712419e180ab972245c\")
     (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cbfb17bf1f65698fb7c7889953d02d1e\")
     (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1339edff0223dbf122f11ff0adbba61c\")
     (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ca9002b81efd0aed9761cd1f78514762\")
     (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"536e9dc4ed51072b8a6d1528d3ec18bf\")
     (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2d869293ba47444c4721713d955c6254\")
     (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9df13bcc6908e9fa601d173a671e1ccf\")
     (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c5cc36884b238221cc13ca0c087ec7c2\")
     (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e70bfeddd694336bbd088e65f8761834\")
     (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"82258ec87aca513a508bc5dee8410dd6\")
     (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c72633d15c3488699072eb610ebde7c8\")
     (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"811869eb6a197d3c4e26af4322e52652\")
     (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1b70dac05d6d2418909eb5105b808e81\")
     (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c394e5684de5e2d938991c7cb348b93c\")
     (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b5c51802e607e3dd22de68204baf64e9\")
     (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bef497b9a267c7306d4100000491c814\")
     (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"886b7c08b9929283e8968831cbe5c039\")
     (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2d9060e41bc5252067d35e59ac70ee06\")
     (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"65076c355c099b5dc73d185948d3bec4\")
     (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"43d2209225707352daec6186ef95a805\")
     (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"45ce41749bc6fa638539815d3f802b96\")
     (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"598a9b65e73151c924b2cdcaf6d96705\")
     (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a319691e3e28b7ea7b927de490cf69ba\")
     (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ff2cfbb865290d7a1510fdf6877c7229\")
     (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fa52433eae199ceeb874bf2bc47afca7\")
     (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1dd67c527257e43f17e006644ecdbd00\")
     (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d65cfce399b04f905bf969929962e59a\")
     (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"699ce3f1615296fc27fcde3e0d63a4bc\")
     (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3f317a0d3c5ee86a73651aad36135cc3\")
     (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5155959766645d3172ae5e73c58cc071\")
     (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a59eab6425a60fa2656f86bf87d5c9ac\")
     (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e8e31e599356e592af29c0cc4604872b\")
     (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5b22b90cfe8534086f6aff96d156713e\")
     (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0417dd41cb3ec1d62dfd913c19f810ad\")
     (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8befbbd00ed5c31c1487a11887eba495\")
     (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1188e7a64a7a5d9482c1233cb9acb452\")
     (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a450cac8071513365267e7024cbe94b0\")
     (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"475dd7d5809a836f01544b447cc8df27\")
     (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5157fd03ee806ee998ad8f0002d56268\")
     (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3384cadf737c7d80c004222022a281f6\")
     (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f0c8c579cd7db466d243ed3ea9f8e8aa\")
     (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"716866194d6b9f076e102e84187229c0\")
     (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"11c7103efbe733bbf0a13927f23c3d34\")
     (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9500cfb800603de002d6d2b24f1bf056\")
     (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c9380ad46a1d7acf41655aaed20db478\")
     (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a5e7108e80664eb3b562fbd7e680801f\")
     (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"db8497f9cff35b1ee261f1f410f46ca6\")
     (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f188d1dbd5d0adb49f53acf09157aef9\")
     (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8bb066aab61a18eff175b9edb11e42a2\")
     (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0e9365e674d1584b111f915ce1f58634\")
     (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ff98aea5cb9a7ae2671f6a887a003725\")
     (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ae3ad96269b5e711a9dbb455f3c0ce48\")
     (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2d5a795bcefd605c75da91c725ae83a2\")
     (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"475517bd7ba04a1c37a82efeb8ff73d9\")
     (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a9bc70eab6720b5c6f8503178e2c966b\")
     (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"becf5c78049c85f2c05cd1ef54454032\")
     (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"4040905f4a64ba704a480d82e87ec748\")
     (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"7d74d9decc5a0bc9f9331d89bd503e21\")
     (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9e0baf22c53329d393e047c669679645\")
     (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9c37ff8237fcc9fe9ae4f44316e854e3\")
     (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1a51ef4a488bb9fde2ff7d47bae01379\")
     (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cbdc30f93109c474e1fc25066c9b9b13\")
     (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f782d1137b8ce342b91c9999cfb7accc\")
     (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"852149de4c289b8e067602780378d87a\")
     (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b33e57a643f2fca810846f6226366253\")
     (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f4433fd19ebc7239dbc2628c39f3ecdb\")
     (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9bd6820c4feba3e552aab1a4edd87861\")
     (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fcea263de1938767772e5b11411ecd5e\")
     (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"78c136d5838dcfe3019d9069643a8d8f\")
     (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bf65b1731eab6e0572461ef5cc60fc40\")
     (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"67975249aaabd751757cdfb9222cc3c4\")
     (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e0d2498db1011e857b7b0daa1934f187\")
     (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"37ace42844c11b52446ee1fc500b8e0b\")
     (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ebd7a54adea2213294a887e6d4db0927\")
     (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"7b1d4054415faca7e5fca59ad83b4d4a\")
     (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\")
     (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fcacd15460db25ea9cc4036065f9f096\")
     (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"32b2156739a6f2ca996abb91df0a2603\")
     (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b6026a8b7bb64b45c37a65effda70d8e\")
     (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"de1aca16a35d34d16aba12ff541c0d2b\")
     (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"59e3c59c90d8d0fc5731b87496a785aa\")
     (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"056d2c6a67c9d9f2bf9fe2d2c348d53c\")
     (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cb0d91405325b508e6b2ab24d178de7a\")
     (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b8e04971b8ad75a1bd0c722997badfd2\")
     (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d6924deff152b941bd49f0bb200b4197\")
     (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e0f987d8767744050ec4d1b3ecb699ed\")
     (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ce649df47dd38888d5103c98345f7e41\")
     (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ab19ec8d15af91511e817858c41cebc8\")
     (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2340e0c9074f7b1bf80c74f774986bc5\")
     (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a93ce2e84e8aee647b5083ad1d2b899b\")
     (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f0fee18adf357bad98e8a3c3e8c70c0c\")
     (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2b23d468be0165fa009c5ebd5d1bbe23\")
     (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1cda77a357ab2147035993b72d135a37\")
     (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cb64f806b8d69eb42d865b4abfff0b27\")
     (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"061147be459d8d3b08c661bd3f91d152\")
     (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b53d27dcc9f4badf18b50519c50bc614\")
     (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f86bd104f20616a76b42c02227f72844\")
     (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8c03f9c01dcb30f2d3970a5694968ecf\")
     (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\")
     (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d6812fa59bf8fd1252fbf85a9bfa3896\")
     (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a229f76f7036f3573a6e528dcd390a19\")
     (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"42b990e3b254e6fb488c0ab91b6a6502\")
     (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c0340924c9130e14d0e8efedeec078f1\")
     (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"7a0e7c99ab70b4720cbb091156560f5e\")
     (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"96c41b1d417135a24fc65659ea3abe11\")
     (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f799f27a8ac1a4c736c04796c1e543f9\")
     (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"758adad069aec2f9dbe0635797314ff6\")
     (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"3f868ebe4307ad4238b314c37eceed9a\")
     (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"1137938073e71d6d8d62c751fbad05d5\")
     (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"d1ab36d05cc1266e4533d27c693f12f4\")
     (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"63dd01c852de1399c2c82274d481d257\"))
    :SUITE-FILES
    (\"tests/foundation/support.lisp\" \"tests/get-directory/support.lisp\"
     \"tests/get-directory/construction.lisp\" \"tests/get-directory/read.lisp\"
     \"tests/get-directory/threads.lisp\")
    :REGISTERED-TESTS
    (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
     \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
     \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
     \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
     \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
     \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
     \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
     \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
     \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
     \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
     \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
     \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
     \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
     \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
     \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
     \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
     \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
     \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
     \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
     \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
     \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
     \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
     \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
     \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
     \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
     \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
     \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
     \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
     \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
    :SELECTED-TEST NIL :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
    (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     \"74a694385f1aaf03ec87721545494119\" :FASL
     \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl\"
     :FASL-MD5 \"477cc2d85814737322219ae7a807beea\")
    :COMPILED-PRODUCT
    ((:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5d70197c8b64ad6f20c8be47a60c73ca\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/build.fasl\"
      :FASL-MD5 \"8ce0e3a1bbbbbf5e0cf5c4141e0875da\")
     (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3546cf7f5c5ed138068548c20064f499\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/clock.fasl\"
      :FASL-MD5 \"965c235ec4a238a01a9ff2c319c684ec\")
     (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"72f3a33ce27ddf94c49c495580520004\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/core.fasl\"
      :FASL-MD5 \"7a8a61bf04752f4f93a5908091af715d\")
     (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a1f6a8e7aa4faed88e984b39871d1e53\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/package.fasl\"
      :FASL-MD5 \"36bc79b15873260ce77d02f8fd88ff43\")
     (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"82f937b7b08bd1696ad9c88da2e1c60c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/read.fasl\"
      :FASL-MD5 \"7179d6ccb8c8c355f4d518b05336c7fb\")
     (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a25648d870eaa4f0b6e1e3b2cf76e28e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/types.fasl\"
      :FASL-MD5 \"32efbbf69bbda31995871929c4ca978f\")
     (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fc09021f74fb50aac57589614dae04d7\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/write.fasl\"
      :FASL-MD5 \"bcca4d0f8aed07c5b67092dd1af5748e\")
     (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bc7a7b176e8cdd361b7c4306a1a4de4b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-float-minimal.fasl\"
      :FASL-MD5 \"0531891e7f8347f0312baf14f3dfda95\")
     (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"6e8c6a49314c2f460aa6f8a1759200b6\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-header.fasl\"
      :FASL-MD5 \"cb84c7ff309ca067182d9a59e36878c2\")
     (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ecd8fe950344059c629927b38fb6e4aa\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-minimal.fasl\"
      :FASL-MD5 \"bace9ac0f352ac05e160601d0b0a42c7\")
     (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"62285b01dc017898fc16588b6522bbbf\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-package.fasl\"
      :FASL-MD5 \"72ed9c6e139f9a55ed2fcb80d74b5d9e\")
     (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f6488e987889432b375254021825dbe5\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-input.fasl\"
      :FASL-MD5 \"1efb55e70ffeec2111b87eb5e9dfed8b\")
     (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"706c0baa4158bf272c4b0df17c1439d2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-items.fasl\"
      :FASL-MD5 \"a07402e22adb9e9494ff89b8d44d88a4\")
     (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"987e8ed576a21eb644ac1ef2e06edbda\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-minimal.fasl\"
      :FASL-MD5 \"6c3e54a2f43612724f9877e9b867d8c6\")
     (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cf1999ddb10f879aeefbeea853742d57\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-stack.fasl\"
      :FASL-MD5 \"16f31e88bfb88bcfcdbc7a5242ba9f4e\")
     (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0c33aedcdb352e78a3c694cf796e6692\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan.fasl\"
      :FASL-MD5 \"6ae096a023e1480a8da1f90143ef4f20\")
     (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c33cdcc45f45218aa3e8bf26ce0ee575\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-space.fasl\"
      :FASL-MD5 \"269cac09a1753b384d291334c681684d\")
     (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b13e92b5f24a42fe283c17b649722b6a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-string-write.fasl\"
      :FASL-MD5 \"60f74619285ac04819867fdd15025701\")
     (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"69e77bcd15b5413a815a65c5081229db\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-write.fasl\"
      :FASL-MD5 \"9d2e32b78d6568c324fb2cc3920c4347\")
     (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d885bd2a9860eb60aec1a775e5031d5e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/package.fasl\"
      :FASL-MD5 \"b46f09c3b997e83442035472c4b35b62\")
     (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0f67dd5c51bf6a63bc292ab4e2a280c2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/utf8.fasl\"
      :FASL-MD5 \"ce2aa4f969799ed103994d6378344090\")
     (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1130012fc5613a5648d22ed8628be0e8\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/csn/package.fasl\"
      :FASL-MD5 \"0ab2001fe00d289e8b2f80cb9fcb854f\")
     (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a1cdb5661fc54beba5bf00e4765f3235\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/csn/registry.fasl\"
      :FASL-MD5 \"613dbc60aecaef0b4ae25b9023276fea\")
     (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"765d14c88cd288093a77a57930cd6999\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/epochs/core.fasl\"
      :FASL-MD5 \"105da12e7208488784d2ffff0f7e7a5b\")
     (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"875201dfab0a84efd40fe9828cc293c8\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/epochs/package.fasl\"
      :FASL-MD5 \"034a6c0e026a8838f5ffbdc3c1d0c4a3\")
     (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"975b5f74e0c5a38ce978f4d9c7fcc6b8\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/epochs/read.fasl\"
      :FASL-MD5 \"5d54eabe17e7651e5fca14677e861839\")
     (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"036dd02adf87d33c3ae2f40735c733fa\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/epochs/reclaim.fasl\"
      :FASL-MD5 \"08046a0ab0bb446e1bac9d9c62177d0f\")
     (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"653b974f310c09f6e2224a84acc43bbf\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/epochs/retire.fasl\"
      :FASL-MD5 \"c4c4ea8ce43f3f2074a4f8de6eded0a8\")
     (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"82253491f995f5bc153fb5ebf30d564c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/epochs/types.fasl\"
      :FASL-MD5 \"d2008b43267cc48989149e6b3d9055cd\")
     (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"6b85eebe69366e78ed5fc5cc20735f00\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/handoff.fasl\"
      :FASL-MD5 \"197e20b58955562651501f7a0294a0d2\")
     (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cb5710d6c111cadb7121a50998a747fa\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/package.fasl\"
      :FASL-MD5 \"734c3ec6b853622f3869491b107be938\")
     (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8202843bddb817da4279ac959ae3f3c4\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/queue.fasl\"
      :FASL-MD5 \"472f0444acf7d3888f483d0db070cfba\")
     (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"38d26f8c749dd946dfc4b9c57103a892\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/ready-recycle.fasl\"
      :FASL-MD5 \"7c1513b89e62ef28a830b3eedac5c426\")
     (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a64d98c9ff429d6103d6e10ee1fd7980\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/ready-types.fasl\"
      :FASL-MD5 \"81442f4d732bac77ebb02c403b91f611\")
     (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2c1892002f0599bb8273093031017520\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/ready.fasl\"
      :FASL-MD5 \"02c6836b720d6f6c7e01e85e0b02c127\")
     (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c24065d6c8d80d1be53994a0041743df\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/worker-boundary.fasl\"
      :FASL-MD5 \"c313da9c54c8f28e61ea093db89dcaa6\")
     (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"babd0a78b4185af24ae1fef870c0fabb\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/worker-claim.fasl\"
      :FASL-MD5 \"c27fd9e1fc5f5adc481ceea5f54b3455\")
     (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"aa34ca6bc07535e35fea723878d99f66\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/worker-run.fasl\"
      :FASL-MD5 \"daa2c492e4b17e2dd32686c44da3eb9d\")
     (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0679ee07c46f69db330706303c70d8d2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/worker-types.fasl\"
      :FASL-MD5 \"e2baa12d56487a65874ad90f961024ce\")
     (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"73019644090e2971f2b54dc36e4491f5\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/writer.fasl\"
      :FASL-MD5 \"104dcce9f952ca1f300434f1024a0bb0\")
     (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ca642ea47e4bff76f78f5b6d7287d6bd\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/foundation/batch.fasl\"
      :FASL-MD5 \"49f41f1eb3d4d97faa4fb69c97c3df9b\")
     (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a06115175f450776762761dce25acdb8\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/foundation/binary.fasl\"
      :FASL-MD5 \"967c5a6aaef42f6890e977aa47fec464\")
     (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"942b596396c19815290a57830af2121b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/foundation/conditions.fasl\"
      :FASL-MD5 \"c11db511dcd2624244ae3cdfdcfe8606\")
     (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"4db58e2f48bf77d751f1b83bb9f84b5c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/foundation/crc32c.fasl\"
      :FASL-MD5 \"b142dd53a5a004fe6f74f54ddb913667\")
     (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5ee593a112958d94163dab17c5aa4ba2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/foundation/package.fasl\"
      :FASL-MD5 \"5e44acbef4bb1a6f726b5447221ebe82\")
     (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/foundation/record.fasl\"
      :FASL-MD5 \"bdab1e0299c38c55b549fb3f5bc77301\")
     (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cde24b2bf5c5637d5501b95bed47df31\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-directory/build.fasl\"
      :FASL-MD5 \"c64b4ce8df03f8b391c7ed485e1572ee\")
     (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"4233eef9d87bdec712d4f690bcb699a9\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-directory/package.fasl\"
      :FASL-MD5 \"491322aea79e4dacc1926a99101873f7\")
     (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"74a694385f1aaf03ec87721545494119\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl\"
      :FASL-MD5 \"477cc2d85814737322219ae7a807beea\")
     (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"17c957d6934a31f4ed64313e756de2d2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-directory/types.fasl\"
      :FASL-MD5 \"6e696767ef5064c9ea5133582b544974\")
     (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8d26428a4e17ad18990b8ee7d5f5b53a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/active-build.fasl\"
      :FASL-MD5 \"5943cdb805eac10f402b2549f9498d5a\")
     (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"6d95f29b331d335175843f47ae44a6ea\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/active-directory.fasl\"
      :FASL-MD5 \"02e7a5bf9e9d77f146bbe267e9263ec5\")
     (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f13d422adb6aa9e8489352884137f25a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/active-preflight.fasl\"
      :FASL-MD5 \"37d393c42f27e9ec79255522316e3541\")
     (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3da469a7aa1e682dd8f2e516ee451de1\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/active-read.fasl\"
      :FASL-MD5 \"fc43c87f1f6e7cc85352073532510c41\")
     (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d6aaec49504a96f37c8ff1bc182c977b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/active-scan.fasl\"
      :FASL-MD5 \"5eea6d927f5eb5759859d56d49e8e3bf\")
     (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bd7182e9871fe82530d0c828e473ccde\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/active-types.fasl\"
      :FASL-MD5 \"ec12216cb2e08d96e9862f1d13fcb99a\")
     (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bbfb2082103e6712419e180ab972245c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/build.fasl\"
      :FASL-MD5 \"d66dd1d825216f5b577b5e5ff645a8bb\")
     (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cbfb17bf1f65698fb7c7889953d02d1e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/package.fasl\"
      :FASL-MD5 \"21f9bbf5031534b85cbc14692848942a\")
     (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1339edff0223dbf122f11ff0adbba61c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/read.fasl\"
      :FASL-MD5 \"c8ba1149c0df2a6ecb5575d51120aaa1\")
     (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ca9002b81efd0aed9761cd1f78514762\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/rows.fasl\"
      :FASL-MD5 \"9ac3432f254e50c28677efb8ce98e666\")
     (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"536e9dc4ed51072b8a6d1528d3ec18bf\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/scan.fasl\"
      :FASL-MD5 \"d022389c9fc891970db17dd67da31520\")
     (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2d869293ba47444c4721713d955c6254\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/sort.fasl\"
      :FASL-MD5 \"c814e75a3f7af58031e6ea31da6b259a\")
     (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9df13bcc6908e9fa601d173a671e1ccf\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/types.fasl\"
      :FASL-MD5 \"9f74706b360d579defc5ab2a82cc524a\")
     (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c5cc36884b238221cc13ca0c087ec7c2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/build.fasl\"
      :FASL-MD5 \"40538bd915634795a5bcff3004a27380\")
     (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e70bfeddd694336bbd088e65f8761834\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/lifecycle.fasl\"
      :FASL-MD5 \"4f65e619612b2a3381177e7a6e176036\")
     (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"82258ec87aca513a508bc5dee8410dd6\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/lookup.fasl\"
      :FASL-MD5 \"15c3c9770c093f5a80ddce2e8d653a92\")
     (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c72633d15c3488699072eb610ebde7c8\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/package.fasl\"
      :FASL-MD5 \"24f926a7ecafa646339a41dd61568152\")
     (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"811869eb6a197d3c4e26af4322e52652\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/segment.fasl\"
      :FASL-MD5 \"49eb3f438f703256f8e4afb02f8cfbea\")
     (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1b70dac05d6d2418909eb5105b808e81\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/target.fasl\"
      :FASL-MD5 \"b29e6b412871c62e6c50168f7375f0a7\")
     (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c394e5684de5e2d938991c7cb348b93c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/types.fasl\"
      :FASL-MD5 \"cf201bfab9f592c114d50684807b53b6\")
     (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b5c51802e607e3dd22de68204baf64e9\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/hash/arithmetic.fasl\"
      :FASL-MD5 \"f7595021562a50c9049ef5b5007056b9\")
     (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bef497b9a267c7306d4100000491c814\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/hash/blocks.fasl\"
      :FASL-MD5 \"c31f4aa7945ad7f280c9b04305c2273b\")
     (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"886b7c08b9929283e8968831cbe5c039\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/hash/hash64.fasl\"
      :FASL-MD5 \"76c887b034ba58a02e03a5e13e9972e0\")
     (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2d9060e41bc5252067d35e59ac70ee06\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/hash/package.fasl\"
      :FASL-MD5 \"4ada3895f040593a66c396e6cb48cbe1\")
     (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"65076c355c099b5dc73d185948d3bec4\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/core.fasl\"
      :FASL-MD5 \"29f472b9a2d9f7320bcc112572a3f9c7\")
     (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"43d2209225707352daec6186ef95a805\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/hash-digests.fasl\"
      :FASL-MD5 \"375ddea6e22a94ce9f931d016f1f05be\")
     (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"45ce41749bc6fa638539815d3f802b96\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/hash-seed.fasl\"
      :FASL-MD5 \"4dbf2fad8994a0e1f697eb3b25a940da\")
     (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"598a9b65e73151c924b2cdcaf6d96705\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/package.fasl\"
      :FASL-MD5 \"f1416a87e2ec8551f1413f7adfd93aa4\")
     (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a319691e3e28b7ea7b927de490cf69ba\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-arena.fasl\"
      :FASL-MD5 \"a7d83e85430ca9b3f67095317754d2a6\")
     (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ff2cfbb865290d7a1510fdf6877c7229\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-build.fasl\"
      :FASL-MD5 \"dfc012dedfbb71a3b020694debea1f17\")
     (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fa52433eae199ceeb874bf2bc47afca7\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-core.fasl\"
      :FASL-MD5 \"68ba62b95d3dc7d57596b4a839349434\")
     (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1dd67c527257e43f17e006644ecdbd00\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-directory.fasl\"
      :FASL-MD5 \"dc38fbb6be73a70fba9b8021b3e57b13\")
     (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d65cfce399b04f905bf969929962e59a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-package.fasl\"
      :FASL-MD5 \"10ab744174c930a4644ec76c18eb3c16\")
     (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"699ce3f1615296fc27fcde3e0d63a4bc\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-probe.fasl\"
      :FASL-MD5 \"bf057aebafa778497c13fdb8cc339fb7\")
     (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3f317a0d3c5ee86a73651aad36135cc3\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-read.fasl\"
      :FASL-MD5 \"49aaf8f52d406d1d28112930edb98ed4\")
     (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5155959766645d3172ae5e73c58cc071\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-relocate.fasl\"
      :FASL-MD5 \"3f5c6eb4839943ba833ebdc0a267758f\")
     (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a59eab6425a60fa2656f86bf87d5c9ac\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-types.fasl\"
      :FASL-MD5 \"05c5259d91384f9d1a0fcf941198fbf3\")
     (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e8e31e599356e592af29c0cc4604872b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-write.fasl\"
      :FASL-MD5 \"4da3bebf8e7bb164c760b97b790d9a00\")
     (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5b22b90cfe8534086f6aff96d156713e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/read.fasl\"
      :FASL-MD5 \"a73d44b6081b3a1fd5918ac4871ce970\")
     (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0417dd41cb3ec1d62dfd913c19f810ad\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/rebuild-budget.fasl\"
      :FASL-MD5 \"41a1615f33a4ca6904cc35600d086049\")
     (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8befbbd00ed5c31c1487a11887eba495\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/rebuild-copy.fasl\"
      :FASL-MD5 \"fc72699d36bdd079c4baedd3cd1c1ebd\")
     (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1188e7a64a7a5d9482c1233cb9acb452\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/rebuild-scan.fasl\"
      :FASL-MD5 \"60f66acd11d6bda00a7cf58f5bc66edb\")
     (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a450cac8071513365267e7024cbe94b0\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/rebuild.fasl\"
      :FASL-MD5 \"3e8f7f6e0991059e992ffc1e2331760c\")
     (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"475dd7d5809a836f01544b447cc8df27\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/relocate.fasl\"
      :FASL-MD5 \"453b186be89a34fd98c74d52166156ce\")
     (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5157fd03ee806ee998ad8f0002d56268\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/types.fasl\"
      :FASL-MD5 \"5e794fe485c03e9680676752e1b8a76a\")
     (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3384cadf737c7d80c004222022a281f6\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/validation.fasl\"
      :FASL-MD5 \"2e16001a53978863c97a9877503641a7\")
     (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f0c8c579cd7db466d243ed3ea9f8e8aa\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/write.fasl\"
      :FASL-MD5 \"77a3a3dbe4de4667af7bab60f40406de\")
     (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"716866194d6b9f076e102e84187229c0\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/io/flush.fasl\"
      :FASL-MD5 \"719bc1d2c6fcdef5f99e6c49c1eaf68e\")
     (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"11c7103efbe733bbf0a13927f23c3d34\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/io/lifecycle.fasl\"
      :FASL-MD5 \"fa960cefe556954c71bfa6143ad635fc\")
     (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9500cfb800603de002d6d2b24f1bf056\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/io/native.fasl\"
      :FASL-MD5 \"b393dad3caf0ccbf69dd67b791454aef\")
     (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c9380ad46a1d7acf41655aaed20db478\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/io/package.fasl\"
      :FASL-MD5 \"dc98df019ca9b7c16dfd04d724709c2b\")
     (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a5e7108e80664eb3b562fbd7e680801f\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/io/transfer.fasl\"
      :FASL-MD5 \"68ac75acf345c9581b8d925318edb802\")
     (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"db8497f9cff35b1ee261f1f410f46ca6\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/io/types.fasl\"
      :FASL-MD5 \"1c5e21b41c87174200ecccd715228b92\")
     (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f188d1dbd5d0adb49f53acf09157aef9\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/package.fasl\"
      :FASL-MD5 \"46e894e8e64b16131866fbdb688ddd8f\")
     (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8bb066aab61a18eff175b9edb11e42a2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-core.fasl\"
      :FASL-MD5 \"15d0cf4b824ea70f6b5aeade7b4b3e72\")
     (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0e9365e674d1584b111f915ce1f58634\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-csn.fasl\"
      :FASL-MD5 \"f3d107d087cb49152089d617f8ebc59f\")
     (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ff98aea5cb9a7ae2671f6a887a003725\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-lifecycle.fasl\"
      :FASL-MD5 \"45a7eaad164f62c3becbebc459ca2af3\")
     (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ae3ad96269b5e711a9dbb455f3c0ce48\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-read.fasl\"
      :FASL-MD5 \"c88b5b5d2800acc1dff7d5ddcc65ee0e\")
     (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2d5a795bcefd605c75da91c725ae83a2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-register.fasl\"
      :FASL-MD5 \"55df280a195754d9bb37b51d72018d4d\")
     (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"475517bd7ba04a1c37a82efeb8ff73d9\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-types.fasl\"
      :FASL-MD5 \"222953b4b1f240420589c3f722ad7bef\")
     (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a9bc70eab6720b5c6f8503178e2c966b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/types.fasl\"
      :FASL-MD5 \"4b73ce15a5de07b85e1f05facf12afd0\")
     (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"becf5c78049c85f2c05cd1ef54454032\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/package.fasl\"
      :FASL-MD5 \"051a9797d764edf0fc8d00535feb855c\")
     (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"4040905f4a64ba704a480d82e87ec748\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/read/core.fasl\"
      :FASL-MD5 \"3eb2b462480475047b783a0689ce261a\")
     (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"7d74d9decc5a0bc9f9331d89bd503e21\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/read/package.fasl\"
      :FASL-MD5 \"6e3fd3c52edc7e6888f36b30264b7c78\")
     (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9e0baf22c53329d393e047c669679645\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/read/task.fasl\"
      :FASL-MD5 \"6af18b2f4f3352d6a66f2442327b7b3d\")
     (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9c37ff8237fcc9fe9ae4f44316e854e3\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/read/types.fasl\"
      :FASL-MD5 \"7cddb4f1a50f776368755d7d737788ea\")
     (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1a51ef4a488bb9fde2ff7d47bae01379\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/decisions-build.fasl\"
      :FASL-MD5 \"aa5594322d0a8bd86a02f29ded7f2d41\")
     (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cbdc30f93109c474e1fc25066c9b9b13\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/decisions-package.fasl\"
      :FASL-MD5 \"1b1393bffd87769284aa779416b1997a\")
     (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f782d1137b8ce342b91c9999cfb7accc\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/decisions-query.fasl\"
      :FASL-MD5 \"6daa4ca950f8a36f204c619d8b8ca8ed\")
     (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"852149de4c289b8e067602780378d87a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/decisions-radix.fasl\"
      :FASL-MD5 \"b766de5741b33b974943e6b2b73fef34\")
     (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b33e57a643f2fca810846f6226366253\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/decisions-sort.fasl\"
      :FASL-MD5 \"567ecb830b8ead49b13a4e2781ef4d1c\")
     (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f4433fd19ebc7239dbc2628c39f3ecdb\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/decisions-types.fasl\"
      :FASL-MD5 \"6bbe78d8f2634b587b3467f28ca685c5\")
     (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9bd6820c4feba3e552aab1a4edd87861\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/inventory-build.fasl\"
      :FASL-MD5 \"529afacadb418d5e9d10dd6c7a7ba7e5\")
     (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fcea263de1938767772e5b11411ecd5e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/inventory-query.fasl\"
      :FASL-MD5 \"9f4edcf59cc3c4b12a8d24b7ce106d6e\")
     (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"78c136d5838dcfe3019d9069643a8d8f\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/inventory-types.fasl\"
      :FASL-MD5 \"d5c47fd3480427f0f080c77bdcee5310\")
     (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bf65b1731eab6e0572461ef5cc60fc40\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/manifest-build.fasl\"
      :FASL-MD5 \"6adbbe889fbda150c100069e36f33fce\")
     (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"67975249aaabd751757cdfb9222cc3c4\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/manifest-decode.fasl\"
      :FASL-MD5 \"7b40f0d2e31cdd15eb1bf4f9a44bcce1\")
     (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e0d2498db1011e857b7b0daa1934f187\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/manifest-fold.fasl\"
      :FASL-MD5 \"4a82e619c6b2e9e5aa860fc075592805\")
     (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"37ace42844c11b52446ee1fc500b8e0b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/manifest-package.fasl\"
      :FASL-MD5 \"70dd1a44a13e77868d992dde50b3d1ba\")
     (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ebd7a54adea2213294a887e6d4db0927\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/manifest-query.fasl\"
      :FASL-MD5 \"b56f5e1532be9538412d1689163b5d28\")
     (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"7b1d4054415faca7e5fca59ad83b4d4a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/manifest-types.fasl\"
      :FASL-MD5 \"6bc94ea8daf7e954ee103f88dd0cf2ae\")
     (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/package.fasl\"
      :FASL-MD5 \"1a25f9d19b12e30928634ec101adbe84\")
     (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fcacd15460db25ea9cc4036065f9f096\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/scan.fasl\"
      :FASL-MD5 \"eb7087bbfbd4f63edbd7d6130d0ec057\")
     (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"32b2156739a6f2ca996abb91df0a2603\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/events.fasl\"
      :FASL-MD5 \"e24860474427ac0ab28197492ff32465\")
     (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b6026a8b7bb64b45c37a65effda70d8e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/io-events.fasl\"
      :FASL-MD5 \"69d5ff84f2070b4b51d688935a186417\")
     (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"de1aca16a35d34d16aba12ff541c0d2b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/ownership.fasl\"
      :FASL-MD5 \"47b73b028842fc42cb447552dc0e75e1\")
     (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"59e3c59c90d8d0fc5731b87496a785aa\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/package.fasl\"
      :FASL-MD5 \"3543558f941967fd11476501dc116753\")
     (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"056d2c6a67c9d9f2bf9fe2d2c348d53c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/publication.fasl\"
      :FASL-MD5 \"bca50867d4624fbfae744c6fb4ee94ab\")
     (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cb0d91405325b508e6b2ab24d178de7a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/query.fasl\"
      :FASL-MD5 \"da919b07b3d7082ad798321d65237187\")
     (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b8e04971b8ad75a1bd0c722997badfd2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/retirement.fasl\"
      :FASL-MD5 \"61c48df4e326db1da6fa22e0635f979f\")
     (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d6924deff152b941bd49f0bb200b4197\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/routing-build.fasl\"
      :FASL-MD5 \"4be9f3a812c4cf9cd5da8f36a930377c\")
     (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e0f987d8767744050ec4d1b3ecb699ed\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/routing-select.fasl\"
      :FASL-MD5 \"b0903e7ab85193de38d6c1516cb4edf5\")
     (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ce649df47dd38888d5103c98345f7e41\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/routing-types.fasl\"
      :FASL-MD5 \"7a76f13448bae5db535658644afb4246\")
     (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ab19ec8d15af91511e817858c41cebc8\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/types.fasl\"
      :FASL-MD5 \"e9b1613210d8a6c126e1869958054466\")
     (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2340e0c9074f7b1bf80c74f774986bc5\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/worker-boundary.fasl\"
      :FASL-MD5 \"6ebebf4e7b9159170b24ac89009d4cfc\")
     (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a93ce2e84e8aee647b5083ad1d2b899b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/worker-package.fasl\"
      :FASL-MD5 \"6bd7a57c7771b6c1ba94534036a6d521\")
     (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f0fee18adf357bad98e8a3c3e8c70c0c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/worker-run.fasl\"
      :FASL-MD5 \"9e007c6a79d4c9ca4365e123a8799e32\")
     (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2b23d468be0165fa009c5ebd5d1bbe23\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/worker-types.fasl\"
      :FASL-MD5 \"5f790449cae7703e00d4a03e4e57aaf4\")
     (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1cda77a357ab2147035993b72d135a37\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/compaction-scan.fasl\"
      :FASL-MD5 \"822e5db2ca6cb1a499ed6fcdf7abc465\")
     (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cb64f806b8d69eb42d865b4abfff0b27\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/control-payload.fasl\"
      :FASL-MD5 \"f645f6277d222f290f3eb9af49319016\")
     (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"061147be459d8d3b08c661bd3f91d152\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/formats.fasl\"
      :FASL-MD5 \"8289e1bac8d35437b9b47b39b271c15f\")
     (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b53d27dcc9f4badf18b50519c50bc614\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/log-header.fasl\"
      :FASL-MD5 \"cd74446016974760c34f9feba8ff11be\")
     (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f86bd104f20616a76b42c02227f72844\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/package.fasl\"
      :FASL-MD5 \"b381e97fce195c49e542a71de98f4850\")
     (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8c03f9c01dcb30f2d3970a5694968ecf\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/payload-record.fasl\"
      :FASL-MD5 \"fdc46906989740c03b79a61cd6f6d4cd\")
     (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/payload-write.fasl\"
      :FASL-MD5 \"5b9e0f059be49959c938a45439bae7e1\")
     (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d6812fa59bf8fd1252fbf85a9bfa3896\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/segment-header.fasl\"
      :FASL-MD5 \"3780d1c9679d940438a85d7229797e24\")
     (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a229f76f7036f3573a6e528dcd390a19\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/wal/builder.fasl\"
      :FASL-MD5 \"5612c337b546713e0a5e09c75cc70116\")
     (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"42b990e3b254e6fb488c0ab91b6a6502\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/wal/csn.fasl\"
      :FASL-MD5 \"eebe745fd6b451521ca7b49a49f50834\")
     (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c0340924c9130e14d0e8efedeec078f1\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/wal/executor.fasl\"
      :FASL-MD5 \"57e45ccce4b9e58271fac5f7398cea31\")
     (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"7a0e7c99ab70b4720cbb091156560f5e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/wal/group.fasl\"
      :FASL-MD5 \"28c167fb62f06521ac5c7e15ebca8a77\")
     (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"96c41b1d417135a24fc65659ea3abe11\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/wal/package.fasl\"
      :FASL-MD5 \"4ed69d0a0c567b1f3971ddcf2ddb4430\")
     (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f799f27a8ac1a4c736c04796c1e543f9\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/wal/types.fasl\"
      :FASL-MD5 \"489ebb7b29b4fb07f0d29e8b524e7857\"))
    :COMPILED-SUITE
    ((:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"758adad069aec2f9dbe0635797314ff6\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/tests/foundation/support.fasl\"
      :FASL-MD5 \"a33de8e447429bfdc19da0a4a2d9d924\")
     (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"3f868ebe4307ad4238b314c37eceed9a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/tests/get-directory/support.fasl\"
      :FASL-MD5 \"2553a74bf9a3d078df55f83748d65fb1\")
     (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"1137938073e71d6d8d62c751fbad05d5\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/tests/get-directory/construction.fasl\"
      :FASL-MD5 \"923e6e5c5a204451ff1e8e59785ae43a\")
     (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"d1ab36d05cc1266e4533d27c693f12f4\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/tests/get-directory/read.fasl\"
      :FASL-MD5 \"9664eb20f13e7d7f6f22c30acbebdd35\")
     (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"63dd01c852de1399c2c82274d481d257\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/tests/get-directory/threads.fasl\"
      :FASL-MD5 \"4adbb02362d26e51e088634c547058b0\"))
    :FAILED-TEST NIL :PASSED-TESTS
    (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
     \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
     \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
     \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
     \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
     \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
     \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
     \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
     \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
     \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
     \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
     \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
     \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
     \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
     \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
     \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
     \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
     \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
     \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
     \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
     \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
     \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
     \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
     \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
     \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
     \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
     \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
     \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
     \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
    :FAILURE-KIND NIL :CONDITION-TYPE NIL :DIAGNOSTIC NIL))
  :DETAIL NIL :RUNNER-MD5
  #A((32) BASE-CHAR . \"5a995d504e7082ff384c2007b729a9ab\") :TARGET-SOURCE-MD5
  #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\") :ARTIFACTS-VERIFIED
  T)
 :MUTANTS
 ((:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   \"omit-directory-owner\" :FILE \"src/get-directory/build.lisp\" :DIRECTORY
   #A((137) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/\")
   :EXPECTED-FAILURE :FOREIGN-DIRECTORY-ACCEPTED :SUBSTITUTION
   (:BEFORE \"(unless (eq view (segmento-get-owner segment))\" :AFTER
    \"(unless (or (eq view (segmento-get-owner segment)) view)\")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   (\"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\")
   :SOURCE-MANIFEST
   ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . \"692a695f7129e0cc693cffb2983be35b\"))
    (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
    (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
    (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
    (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
    (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
    (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
    (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
    (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
    (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
    (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
    (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"62285b01dc017898fc16588b6522bbbf\"))
    (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
    (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
    (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
    (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
    (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
    (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
    (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
    (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
    (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
    (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
    (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
    (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
    (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
    (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
    (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
    (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
    (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
    (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
    (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
    (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
    (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
    (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
    (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
    (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
    (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
    (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
    (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
    (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
    (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
    (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
    (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
    (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
    (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
    (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
    (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
    (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"db58ed1c3877f2d6ea58932d3bc75e56\"))
    (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
    (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\"))
    (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
    (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
    (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
    (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
    (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
    (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
    (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
    (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
    (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
    (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
    (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
    (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
    (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
    (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
    (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
    (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
    (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
    (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
    (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
    (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
    (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
    (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
    (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
    (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
    (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
    (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
    (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
    (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
    (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
    (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
    (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
    (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
    (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
    (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
    (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
    (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
    (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
    (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
    (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
    (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
    (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
    (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
    (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
    (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
    (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
    (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
    (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
    (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
    (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
    (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
    (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
    (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
    (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
    (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
    (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
    (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
    (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
    (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
    (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
    (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
    (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
    (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
    (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
    (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
    (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
    (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
    (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
    (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
    (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
    (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
    (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
    (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
    (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
    (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
    (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
    (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
    (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
    (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
    (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
    (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
    (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
    (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
    (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
    (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
    (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
    (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
    (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
    (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
    (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
    (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
    (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
    (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
    (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
    (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
    (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
    (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
    (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
    (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
    (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
    (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
    (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
    (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
    (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
    (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
    (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
    (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
    (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
    (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
    (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
    (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
    (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
    (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
    (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
    (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
    (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
    (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
    (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
    (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
   :COMPILED-TARGET
   (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    \"db58ed1c3877f2d6ea58932d3bc75e56\" :FASL
    \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl\"
    :FASL-MD5 \"f0308276da0bbaa2d1fa9d1d23dfefdf\")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    (\"sbcl\" \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--disable-debugger\"
     \"--script\" \"isolated-build.lisp\")
    :STDOUT-LOG
    #A((147) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/stdout.log\")
    :STDERR-LOG
    #A((147) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/stderr.log\")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 5129623/1000000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/\"
     :SOURCE-MANIFEST
     ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
       \"692a695f7129e0cc693cffb2983be35b\")
      (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"62285b01dc017898fc16588b6522bbbf\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db58ed1c3877f2d6ea58932d3bc75e56\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"74a694385f1aaf03ec87721545494119\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\")
      (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\"))
     :SUITE-FILES
     (\"tests/foundation/support.lisp\" \"tests/get-directory/support.lisp\"
      \"tests/get-directory/construction.lisp\" \"tests/get-directory/read.lisp\"
      \"tests/get-directory/threads.lisp\")
     :REGISTERED-TESTS
     (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
      \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
      \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
      \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
      \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
      \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
      \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
      \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
      \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
      \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
      \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
      \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
      \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
      \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
      \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
      \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
      \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
      \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
      \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
      \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
      \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
      \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
      \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
      \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
     :SELECTED-TEST
     \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"db58ed1c3877f2d6ea58932d3bc75e56\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl\"
      :FASL-MD5 \"f0308276da0bbaa2d1fa9d1d23dfefdf\")
     :COMPILED-PRODUCT
     ((:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/build.fasl\"
       :FASL-MD5 \"767f8fd7f0ef3255bd731ab1dca64315\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/clock.fasl\"
       :FASL-MD5 \"0e3a41f24ada5cd097db2df2c9634012\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/core.fasl\"
       :FASL-MD5 \"b6daa67e9882d9d9a77fccc991031a09\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/package.fasl\"
       :FASL-MD5 \"1b4f18503fc166f67a03221509dd7f6f\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/read.fasl\"
       :FASL-MD5 \"38fbff367e78ef1ea7daa6f9a536b56f\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/types.fasl\"
       :FASL-MD5 \"62cae088caf6725a9dcd1b53f015c492\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/write.fasl\"
       :FASL-MD5 \"574a482fa28484d367a18ca537632609\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-float-minimal.fasl\"
       :FASL-MD5 \"137df0aeec0c9a452588f14e5a57f381\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-header.fasl\"
       :FASL-MD5 \"4b9a01368b18f18bea2c35cfcff81def\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-minimal.fasl\"
       :FASL-MD5 \"2fdd32d9cdafcaeba80836f4cfc9b7db\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"62285b01dc017898fc16588b6522bbbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-package.fasl\"
       :FASL-MD5 \"116305f7865b48a6262b1bb9c4e70fd8\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-input.fasl\"
       :FASL-MD5 \"c83f811108114982660ff1fd34cb2126\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-items.fasl\"
       :FASL-MD5 \"319c31632d6beaf62a9e3ed9062359b6\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-minimal.fasl\"
       :FASL-MD5 \"555ed42f044d100b65de3324a018ec40\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-stack.fasl\"
       :FASL-MD5 \"f60016d033065bebd0dd7fb5ad3171e7\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan.fasl\"
       :FASL-MD5 \"73fec8ffe339bcbe0b1c42d1d842479d\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-space.fasl\"
       :FASL-MD5 \"733b3ca8327dd19c891cd166006c32d9\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-string-write.fasl\"
       :FASL-MD5 \"ac850b67e61971100cee8555b174189e\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-write.fasl\"
       :FASL-MD5 \"c19476b34b6d8bd484fa87c12440a3fc\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/package.fasl\"
       :FASL-MD5 \"33555c7659a69a00f62394414f851431\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/utf8.fasl\"
       :FASL-MD5 \"5680f42e82b2f0a83b77c7c11d307955\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/csn/package.fasl\"
       :FASL-MD5 \"05206629656657cf6d2cbef961ad1be3\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/csn/registry.fasl\"
       :FASL-MD5 \"4e1086f42065c44b871d3561db6608b8\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/core.fasl\"
       :FASL-MD5 \"dbe331b5ebf04e6bf34a7b30ec2b1f6b\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/package.fasl\"
       :FASL-MD5 \"e1b811d401081018e945dbf796308493\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/read.fasl\"
       :FASL-MD5 \"11190d4b126f511fdd04ce1c285bdf16\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/reclaim.fasl\"
       :FASL-MD5 \"105af02bb8973aa1499c105b1e142a2d\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/retire.fasl\"
       :FASL-MD5 \"71932182172835b52149b573b1881b40\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/types.fasl\"
       :FASL-MD5 \"dbd542308374cb720b935ee03b6662ce\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/handoff.fasl\"
       :FASL-MD5 \"a8f4cc1f55dc7a50c9f6f2c6b627109e\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/package.fasl\"
       :FASL-MD5 \"ba56b24d3b5bf100ba22c7d57fd13a1e\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/queue.fasl\"
       :FASL-MD5 \"7aed3912b657d8cf3d8b5d95522655a3\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready-recycle.fasl\"
       :FASL-MD5 \"4c29e9bdb27a8dd0f5c8081ff842ea77\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready-types.fasl\"
       :FASL-MD5 \"6b5c61f97704b6b4ffffca7d448aad05\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready.fasl\"
       :FASL-MD5 \"ca47067198094ab249bf74df2738acfc\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-boundary.fasl\"
       :FASL-MD5 \"eb52c041e279d5e42c88938b66397143\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-claim.fasl\"
       :FASL-MD5 \"c647c896a1d3d8c775199a6af5808acc\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-run.fasl\"
       :FASL-MD5 \"c6881f8188888f5cf5a45880276d7576\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-types.fasl\"
       :FASL-MD5 \"982430e093c5ad84da740779f43b68dc\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/writer.fasl\"
       :FASL-MD5 \"c0990c177930f681dd19f2516931e2b8\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/batch.fasl\"
       :FASL-MD5 \"b069c98c8c0be5bc84415ac231541dcc\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/binary.fasl\"
       :FASL-MD5 \"654cb4301488f4a8db5baccc128e8b1a\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/conditions.fasl\"
       :FASL-MD5 \"3ed94c5948cd1ae49fed281cc6725e8e\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/crc32c.fasl\"
       :FASL-MD5 \"1df599544fe71b3e05c105c55e104a82\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/package.fasl\"
       :FASL-MD5 \"aa622d8d85091fd7d735cf21250781b6\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/record.fasl\"
       :FASL-MD5 \"fb2ece22ee3f76e9de6ffe9aa8707af3\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db58ed1c3877f2d6ea58932d3bc75e56\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl\"
       :FASL-MD5 \"f0308276da0bbaa2d1fa9d1d23dfefdf\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/package.fasl\"
       :FASL-MD5 \"672837f879102cbbaaf12a96f899290c\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"74a694385f1aaf03ec87721545494119\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/read.fasl\"
       :FASL-MD5 \"fecb430e39bfc7f230a9185636e84e5c\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/types.fasl\"
       :FASL-MD5 \"e6c115cb6ccc33c80cf08ad4b5ae385e\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-build.fasl\"
       :FASL-MD5 \"8a5f446aefe1aa03f1f2e2d0e32a3511\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-directory.fasl\"
       :FASL-MD5 \"a3d90edf26040a6b38b8ac9068e87453\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-preflight.fasl\"
       :FASL-MD5 \"5fc678fed30ad7c108d635b8e1ca25e1\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-read.fasl\"
       :FASL-MD5 \"552edc6926fcad134bce9aecab6fbcab\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-scan.fasl\"
       :FASL-MD5 \"c65b2858d4189efc451cd5ecc38120d7\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-types.fasl\"
       :FASL-MD5 \"55a190b9367176c635662b3cc45c6b2c\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/build.fasl\"
       :FASL-MD5 \"328dda06ff46989de67a5ab36d6ed254\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/package.fasl\"
       :FASL-MD5 \"9f3fae74c3d55d32b28550d863a1a8eb\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/read.fasl\"
       :FASL-MD5 \"00b86b1810b694ce3585ea6d737ae129\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/rows.fasl\"
       :FASL-MD5 \"9938f78ae7f4034b3b47831d6d8b6cb4\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/scan.fasl\"
       :FASL-MD5 \"250a1ca87a8f759cc2c83ef70c352d3e\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/sort.fasl\"
       :FASL-MD5 \"f2217c681fe917c6570a6e08f8f80d27\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/types.fasl\"
       :FASL-MD5 \"bd48638acaba3c5c5ff05c012fb270f9\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/build.fasl\"
       :FASL-MD5 \"a410bf28b20c414e97ca35e08aa2c69d\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/lifecycle.fasl\"
       :FASL-MD5 \"bea1bb0a0bdb257a28dffc75b284235b\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/lookup.fasl\"
       :FASL-MD5 \"b31090d1fea48fc78748b91704ea7481\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/package.fasl\"
       :FASL-MD5 \"7bd5afa309dba76451d43a1888e5bd20\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/segment.fasl\"
       :FASL-MD5 \"8fa952f7eea0cd7af78c63d294232274\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/target.fasl\"
       :FASL-MD5 \"782a3d153b66b5382a138fbf9f406159\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/types.fasl\"
       :FASL-MD5 \"4c31c09f028bd27a293416e319968789\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/hash/arithmetic.fasl\"
       :FASL-MD5 \"e9ae89930440884122292e7db8d46489\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/hash/blocks.fasl\"
       :FASL-MD5 \"b7e4f54e1834f4a0cfa6a694a7588e97\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/hash/hash64.fasl\"
       :FASL-MD5 \"65e1f493cb483b38c0c405b2fd46946e\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/hash/package.fasl\"
       :FASL-MD5 \"3c4054879fefa59454d4065db2cff83a\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/core.fasl\"
       :FASL-MD5 \"af9f1aecb89c4a37e8cf509439d89c73\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/hash-digests.fasl\"
       :FASL-MD5 \"7b6b34de6c26e7447e0aaffd42829482\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/hash-seed.fasl\"
       :FASL-MD5 \"0367e935971f5c8c570e6b578483672f\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/package.fasl\"
       :FASL-MD5 \"a1d17082aef44668aca81e826f00ce82\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-arena.fasl\"
       :FASL-MD5 \"6e7e9551f7dccda6ca0981b0e167f998\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-build.fasl\"
       :FASL-MD5 \"1ec4bb994818306382c082799af6e203\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-core.fasl\"
       :FASL-MD5 \"f28cd70492b052c909e5433c22983e1a\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-directory.fasl\"
       :FASL-MD5 \"460aee2a9eb63649cfd5bfeb5899d1e7\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-package.fasl\"
       :FASL-MD5 \"cbf1a9bf191d38e16dadd81cfeb7fead\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-probe.fasl\"
       :FASL-MD5 \"89585c80c0d9e959cf85cd9049f83e12\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-read.fasl\"
       :FASL-MD5 \"7ef0135ee61702c614fe98d0a3104d37\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-relocate.fasl\"
       :FASL-MD5 \"56a85d48f9aa940cd8b40be8dcaf5481\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-types.fasl\"
       :FASL-MD5 \"195d0ac76f1f6f6af495743ad88657a0\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-write.fasl\"
       :FASL-MD5 \"cd12905a2fc93cb67c31701af358b28c\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/read.fasl\"
       :FASL-MD5 \"0328fc2e9c459c01e8de24f78b33c80d\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-budget.fasl\"
       :FASL-MD5 \"ad00d4ae5478ba6f591d9d4dab17d14b\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-copy.fasl\"
       :FASL-MD5 \"b67f6ea204b505009ab242f5f7dedd53\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-scan.fasl\"
       :FASL-MD5 \"820dae5d18fb89545b4b328f506dcc1c\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild.fasl\"
       :FASL-MD5 \"e58c3c55ea87ada6732bdf62ea6895ad\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/relocate.fasl\"
       :FASL-MD5 \"3015096dddbe9ac5686a4e4e5a3e0c05\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/types.fasl\"
       :FASL-MD5 \"479c61ea588b228e6988f60c225521cb\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/validation.fasl\"
       :FASL-MD5 \"10462934366ba803525675c42fd10b29\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/write.fasl\"
       :FASL-MD5 \"8e8509c31f0ed1a0828a33e819a0cf23\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/io/flush.fasl\"
       :FASL-MD5 \"9b7e1b48a9a7ec01a1f81117c311d335\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/io/lifecycle.fasl\"
       :FASL-MD5 \"12fe9859c8004f72fbb6061b452d95d8\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/io/native.fasl\"
       :FASL-MD5 \"afc070915d9080157f2843717dd62e59\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/io/package.fasl\"
       :FASL-MD5 \"f8e4d1231d6b8681d98ee1fcf27e25e9\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/io/transfer.fasl\"
       :FASL-MD5 \"d929b432d8fdd92ef8a28d06bf06e90c\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/io/types.fasl\"
       :FASL-MD5 \"873b9053ea54355f158fb86e2caf44ba\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/package.fasl\"
       :FASL-MD5 \"cd2971d34bc271842e12afc1b91dd5ad\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-core.fasl\"
       :FASL-MD5 \"a5b9fa45ff5a6a615d3b797e940f29e9\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-csn.fasl\"
       :FASL-MD5 \"03a24324a522d620ca566c6af18dfd09\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-lifecycle.fasl\"
       :FASL-MD5 \"61e3f86cc448fd319d5ef49c47907193\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-read.fasl\"
       :FASL-MD5 \"e1adb2d2bf6e6d43cd569cb4235e133d\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-register.fasl\"
       :FASL-MD5 \"10eedc1912ed36696a0d68e095e15cb6\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-types.fasl\"
       :FASL-MD5 \"b1ddcdf58249555550653bf3c2979a89\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/types.fasl\"
       :FASL-MD5 \"67404ab6930cae50cdc037faf3b00972\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/package.fasl\"
       :FASL-MD5 \"402075a493254eec53ea4e000dd77d6e\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/read/core.fasl\"
       :FASL-MD5 \"9aa891484bcb21f275dc07e4b1501ff3\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/read/package.fasl\"
       :FASL-MD5 \"657bdf4486662c76ce0e65a376b9d30d\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/read/task.fasl\"
       :FASL-MD5 \"0e12747b08fa3b1c04c3052f6e48e37e\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/read/types.fasl\"
       :FASL-MD5 \"b02cb84d492d7c09ce98e2800fed7d96\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-build.fasl\"
       :FASL-MD5 \"68ec9d39af0e4f2b3c81d1ba4a96f284\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-package.fasl\"
       :FASL-MD5 \"8bcb36a03f70b99d51afa91acffa7df5\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-query.fasl\"
       :FASL-MD5 \"47247787df5ecdde2677025ccd034091\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-radix.fasl\"
       :FASL-MD5 \"cfda53eb53c025c275c4ebbd7a02fec3\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-sort.fasl\"
       :FASL-MD5 \"357917aba778945fda4a83dc26162d92\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-types.fasl\"
       :FASL-MD5 \"d2cf664fb15ed1cfa72275ad5b9824ab\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-build.fasl\"
       :FASL-MD5 \"5f1c925ca69fbcea51a140ac325462ea\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-query.fasl\"
       :FASL-MD5 \"467035dc7243e7d172763bd17cbbfaa7\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-types.fasl\"
       :FASL-MD5 \"65321011a5f7d9c5399249a004551e8c\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-build.fasl\"
       :FASL-MD5 \"0d844794961edbb4e090e2dea2974e1b\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-decode.fasl\"
       :FASL-MD5 \"c8fea9dd42727049b2fe756f8e021d24\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-fold.fasl\"
       :FASL-MD5 \"71553830890ecdbae8d9dbc2af6313e0\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-package.fasl\"
       :FASL-MD5 \"4977808839b9ea1111d931dd97dda111\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-query.fasl\"
       :FASL-MD5 \"fee9d5438bc77e61dc2523d52175cba8\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-types.fasl\"
       :FASL-MD5 \"981a64f89cd48c21d72a510607db5498\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/package.fasl\"
       :FASL-MD5 \"59d88338e83401babeab73295840a9ec\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/scan.fasl\"
       :FASL-MD5 \"ca0a18e74257743dec60b76671cc11e6\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/events.fasl\"
       :FASL-MD5 \"a89ceb26cf6fa834c521e7edc73d34d9\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/io-events.fasl\"
       :FASL-MD5 \"ca09d22f2b26f9c2bc69386e9292c326\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/ownership.fasl\"
       :FASL-MD5 \"290cb2d9fdfd838a3f6993f752d598ff\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/package.fasl\"
       :FASL-MD5 \"93144fad7d67e324158ef17fa091d53d\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/publication.fasl\"
       :FASL-MD5 \"e814c8a9ecc9b3e54a9d27424d80305b\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/query.fasl\"
       :FASL-MD5 \"448185cdaf132714d3e626cd29f6784b\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/retirement.fasl\"
       :FASL-MD5 \"5e8650895fc5566d5da921054c475861\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-build.fasl\"
       :FASL-MD5 \"3d4620d535586ab1d953b7f90f47464e\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-select.fasl\"
       :FASL-MD5 \"e27d2399719c34662c4cf6e3639a9dde\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-types.fasl\"
       :FASL-MD5 \"969e1cbbd9639c011afd31bd890b2595\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/types.fasl\"
       :FASL-MD5 \"413f2a3a78a20d4b6e119357b31148a2\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-boundary.fasl\"
       :FASL-MD5 \"1786f75e2223480f9b46ff8b0d808280\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-package.fasl\"
       :FASL-MD5 \"6f5de6756e91ffb24adcc2c891b25b25\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-run.fasl\"
       :FASL-MD5 \"5e5bc6c0cf92dc5242686dd9d3af4f18\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-types.fasl\"
       :FASL-MD5 \"8400c6766edf595f33d1a8abe7a22a75\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/compaction-scan.fasl\"
       :FASL-MD5 \"dd668179ebb1c0e4f832e35a5e05fce3\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/control-payload.fasl\"
       :FASL-MD5 \"a20e37e6b2a5f2bf411715aad6518d22\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/formats.fasl\"
       :FASL-MD5 \"6f69ec582c28da22fd97f52b3a5635b0\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/log-header.fasl\"
       :FASL-MD5 \"088c617c981cc99d23c559dd3be30540\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/package.fasl\"
       :FASL-MD5 \"71d160edce0a207cf401bc335b495b2e\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/payload-record.fasl\"
       :FASL-MD5 \"1af42abb0da048c99a44c2fb65f26697\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/payload-write.fasl\"
       :FASL-MD5 \"628cbf8c05fe3854b9d64344c468a997\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/segment-header.fasl\"
       :FASL-MD5 \"51537a2c0c77bd9422386bc83cf08a5c\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/wal/builder.fasl\"
       :FASL-MD5 \"79deff0e82902134125e067b8467a8b4\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/wal/csn.fasl\"
       :FASL-MD5 \"51444ba63fe16ea8c784c8b99feb4498\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/wal/executor.fasl\"
       :FASL-MD5 \"b5247f2ed9e98fda0877a4a994d2e0b7\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/wal/group.fasl\"
       :FASL-MD5 \"26aa893c3288da2d2624bfcf84daa7bf\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/wal/package.fasl\"
       :FASL-MD5 \"e0a5351a38027fb1a4dd73a7bd72cb78\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/wal/types.fasl\"
       :FASL-MD5 \"215800a3489efc67b60431c0529356d7\"))
     :COMPILED-SUITE
     ((:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/tests/foundation/support.fasl\"
       :FASL-MD5 \"f5e7ddf620c9eab46fe1086e4a8bec10\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/support.fasl\"
       :FASL-MD5 \"9b7cf5637ac11350f98401b521bf320d\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/construction.fasl\"
       :FASL-MD5 \"f19770b94f431e4834b6ed82f0cb9bf2\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/read.fasl\"
       :FASL-MD5 \"fbbadd52f0a2012295b3ca45a77edea9\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/threads.fasl\"
       :FASL-MD5 \"161b709d7b16e288c2b5f21f2b77bc10\"))
     :FAILED-TEST
     \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
     :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE \"SIMPLE-ERROR\"
     :DIAGNOSTIC \"Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (ARCDOCDB.GET.DIRECTORY:CREA-DIRECTORY-GET-SERIE
                       ARCDOCDB.GET.DIRECTORY.TESTS::COPY
                       (ARCDOCDB.GET.DIRECTORY.TESTS:DIRECTORY-FIXTURE-MAPS
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVALID-ARGUMENT (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :DIRECTORY-SOURCE-OWNER)))\"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . \"6edf271e46b6c707e307c54f46fca708\") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . \"db58ed1c3877f2d6ea58932d3bc75e56\") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   \"missing-location-first-map\" :FILE \"src/get-directory/read.lisp\" :DIRECTORY
   #A((143) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/\")
   :EXPECTED-FAILURE :MISSING-PUBLISHED-SEGMENT-AUTHORIZED :SUBSTITUTION
   (:BEFORE
    \"(when (= left right) (guasto-get context :directory-location-absent))\"
    :AFTER \"(when (= left right)
               (if (plusp (length maps))
                   (return-from cerca-mappa-directory-get
                     (the mappa-segmento-get (svref maps 0)))
                   (guasto-get context :directory-location-absent)))\")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   (\"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\")
   :SOURCE-MANIFEST
   ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . \"692a695f7129e0cc693cffb2983be35b\"))
    (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
    (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
    (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
    (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
    (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
    (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
    (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
    (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
    (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
    (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
    (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"62285b01dc017898fc16588b6522bbbf\"))
    (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
    (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
    (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
    (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
    (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
    (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
    (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
    (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
    (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
    (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
    (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
    (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
    (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
    (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
    (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
    (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
    (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
    (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
    (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
    (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
    (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
    (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
    (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
    (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
    (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
    (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
    (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
    (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
    (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
    (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
    (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
    (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
    (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
    (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
    (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
    (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
    (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
    (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd12d0077a79f0c9c2f0a4dd01731f43\"))
    (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
    (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
    (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
    (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
    (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
    (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
    (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
    (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
    (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
    (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
    (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
    (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
    (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
    (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
    (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
    (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
    (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
    (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
    (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
    (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
    (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
    (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
    (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
    (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
    (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
    (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
    (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
    (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
    (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
    (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
    (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
    (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
    (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
    (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
    (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
    (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
    (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
    (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
    (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
    (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
    (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
    (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
    (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
    (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
    (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
    (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
    (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
    (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
    (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
    (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
    (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
    (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
    (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
    (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
    (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
    (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
    (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
    (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
    (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
    (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
    (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
    (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
    (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
    (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
    (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
    (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
    (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
    (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
    (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
    (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
    (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
    (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
    (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
    (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
    (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
    (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
    (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
    (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
    (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
    (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
    (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
    (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
    (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
    (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
    (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
    (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
    (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
    (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
    (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
    (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
    (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
    (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
    (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
    (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
    (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
    (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
    (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
    (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
    (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
    (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
    (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
    (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
    (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
    (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
    (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
    (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
    (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
    (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
    (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
    (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
    (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
    (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
    (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
    (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
    (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
    (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
    (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
    (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
   :COMPILED-TARGET
   (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    \"bd12d0077a79f0c9c2f0a4dd01731f43\" :FASL
    \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl\"
    :FASL-MD5 \"d388e78df967f057078fafd3e5f8f429\")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    (\"sbcl\" \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--disable-debugger\"
     \"--script\" \"isolated-build.lisp\")
    :STDOUT-LOG
    #A((153) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/stdout.log\")
    :STDERR-LOG
    #A((153) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/stderr.log\")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 2392301/500000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/\"
     :SOURCE-MANIFEST
     ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
       \"692a695f7129e0cc693cffb2983be35b\")
      (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"62285b01dc017898fc16588b6522bbbf\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cde24b2bf5c5637d5501b95bed47df31\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd12d0077a79f0c9c2f0a4dd01731f43\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\")
      (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\"))
     :SUITE-FILES
     (\"tests/foundation/support.lisp\" \"tests/get-directory/support.lisp\"
      \"tests/get-directory/construction.lisp\" \"tests/get-directory/read.lisp\"
      \"tests/get-directory/threads.lisp\")
     :REGISTERED-TESTS
     (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
      \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
      \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
      \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
      \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
      \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
      \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
      \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
      \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
      \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
      \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
      \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
      \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
      \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
      \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
      \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
      \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
      \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
      \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
      \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
      \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
      \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
      \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
      \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
     :SELECTED-TEST
     \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bd12d0077a79f0c9c2f0a4dd01731f43\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl\"
      :FASL-MD5 \"d388e78df967f057078fafd3e5f8f429\")
     :COMPILED-PRODUCT
     ((:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/build.fasl\"
       :FASL-MD5 \"0deb1fa35ef22e224d8e5d0b8be06b2b\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/clock.fasl\"
       :FASL-MD5 \"a01aa6fb1fa41bd755b350ba3420af6f\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/core.fasl\"
       :FASL-MD5 \"1308c19d221ed7f25523140123b2ad22\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/package.fasl\"
       :FASL-MD5 \"62d3b0a44280ba3d2c843ad639a778f7\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/read.fasl\"
       :FASL-MD5 \"7ef4879e1382261502f94ec02e94293c\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/types.fasl\"
       :FASL-MD5 \"c5bf65350d01194ff5d5ba2257efdbc2\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/write.fasl\"
       :FASL-MD5 \"8478e60e5ca5e4a0a913b2780b81e816\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-float-minimal.fasl\"
       :FASL-MD5 \"34be2fde8f4c4ff4f69d0dacf26d3856\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-header.fasl\"
       :FASL-MD5 \"8bfcd805d1bced566aa70d8ba5973634\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-minimal.fasl\"
       :FASL-MD5 \"1585bd5fc137c4f0f4368c72e848bc3a\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"62285b01dc017898fc16588b6522bbbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-package.fasl\"
       :FASL-MD5 \"ad8d7c83184b409becde0347d2deb13f\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-input.fasl\"
       :FASL-MD5 \"11bf0136b0b05b43e2ff69609725d5c2\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-items.fasl\"
       :FASL-MD5 \"c9fffe875445c78257974fe6bd91970a\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-minimal.fasl\"
       :FASL-MD5 \"3218b3fc88b2f91aa9e75c70fa4b78cd\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-stack.fasl\"
       :FASL-MD5 \"2383d83a4561104401ef31e8e52e0b74\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan.fasl\"
       :FASL-MD5 \"9bf882088d454ea9f13dcfcacb3dab3a\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-space.fasl\"
       :FASL-MD5 \"2afe2db8024d05d965e22bcc2b251480\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-string-write.fasl\"
       :FASL-MD5 \"3916199f765be575fb05f94f8d641a8c\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-write.fasl\"
       :FASL-MD5 \"af833660588204e589ba0793e84e72d0\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/package.fasl\"
       :FASL-MD5 \"e03cde68ce2199ad90de6f748b297dda\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/utf8.fasl\"
       :FASL-MD5 \"2d98ce8215cf1a7716e739eaeb20d1e6\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/csn/package.fasl\"
       :FASL-MD5 \"1d7571db1622f4b838b8d7ce45fd4db8\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/csn/registry.fasl\"
       :FASL-MD5 \"f733e7076795926e5cd7eff90508cc1a\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/core.fasl\"
       :FASL-MD5 \"b8568b16c6f16ffa1ffd3e0aeee9178d\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/package.fasl\"
       :FASL-MD5 \"d33986b481290136caf2025939fbaaa9\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/read.fasl\"
       :FASL-MD5 \"84505e2a9e5916c484d094ff520fedba\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/reclaim.fasl\"
       :FASL-MD5 \"1c2ce13da6efeb898ab5d73af2cbbb2e\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/retire.fasl\"
       :FASL-MD5 \"17c84467447b4c9de5801257299c1bbe\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/types.fasl\"
       :FASL-MD5 \"fc1d3e7785e2accfd699947b7c555ff9\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/handoff.fasl\"
       :FASL-MD5 \"f77211f8340b0ad932a5c083441c3dc5\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/package.fasl\"
       :FASL-MD5 \"4f071fd619e2fc9c55d5d9fe19d6f394\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/queue.fasl\"
       :FASL-MD5 \"05f67b303fb1b95222c5fad213a698c0\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready-recycle.fasl\"
       :FASL-MD5 \"81cfb9518a80fe40e533b0d735aff8a2\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready-types.fasl\"
       :FASL-MD5 \"22ce37cf369a41452da19d4770607d75\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready.fasl\"
       :FASL-MD5 \"958f6f81619c35946a44427333cf3faa\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-boundary.fasl\"
       :FASL-MD5 \"b8e1b850ff73b0382138ff9e5e5b4736\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-claim.fasl\"
       :FASL-MD5 \"928c1660c5680d23ea3a525c26fe9e30\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-run.fasl\"
       :FASL-MD5 \"81cdcf098b2b9c337bbed88efa147138\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-types.fasl\"
       :FASL-MD5 \"39c5c236a0376c72fc2053a8446d7ad9\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/writer.fasl\"
       :FASL-MD5 \"c8989d533c3cfc729c95fd16f17a648b\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/batch.fasl\"
       :FASL-MD5 \"1f97d7e43060572436ec33fe592358c4\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/binary.fasl\"
       :FASL-MD5 \"5565e9065bda8926f35b8ad5a3e13e22\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/conditions.fasl\"
       :FASL-MD5 \"59981e39ed8a2a535759e2e8871eacd5\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/crc32c.fasl\"
       :FASL-MD5 \"12f649bdf602bf8593c643df4a931f51\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/package.fasl\"
       :FASL-MD5 \"92b8e5285ad30f88bfdabc430afbcd17\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/record.fasl\"
       :FASL-MD5 \"4820f179bf9a19f9096c453b7b31a3a3\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cde24b2bf5c5637d5501b95bed47df31\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/build.fasl\"
       :FASL-MD5 \"c0ea274bf946e0570239c975ae0307fc\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/package.fasl\"
       :FASL-MD5 \"5bf4185cbf369269a2468fcaf35e51c4\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd12d0077a79f0c9c2f0a4dd01731f43\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl\"
       :FASL-MD5 \"d388e78df967f057078fafd3e5f8f429\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/types.fasl\"
       :FASL-MD5 \"38513102550029fff4e70684b043c1d9\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-build.fasl\"
       :FASL-MD5 \"08e8778aca6463e97c7e32c8d079c827\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-directory.fasl\"
       :FASL-MD5 \"84322601c89d79017d4f98f6ac2b8f0d\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-preflight.fasl\"
       :FASL-MD5 \"22a180c50620f025fa333af890f3e549\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-read.fasl\"
       :FASL-MD5 \"888b189a84dacf3885c1a3af457f20e5\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-scan.fasl\"
       :FASL-MD5 \"b4156ced850ccfd5312b14029a3ca340\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-types.fasl\"
       :FASL-MD5 \"f3d2e1d29598842c3ff27f416c4ceb3b\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/build.fasl\"
       :FASL-MD5 \"ed5300e664ccdc84cb6cc606a64c3fa8\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/package.fasl\"
       :FASL-MD5 \"b596ff314d8e6f109e47bc564db7da60\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/read.fasl\"
       :FASL-MD5 \"59c7561a99231f2bbedfce318fa42833\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/rows.fasl\"
       :FASL-MD5 \"438fb9cfc759285588ff678f1561a227\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/scan.fasl\"
       :FASL-MD5 \"8c110a020315a92501e3e0960aeca626\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/sort.fasl\"
       :FASL-MD5 \"9b202d7f4bff245088052c345011f996\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/types.fasl\"
       :FASL-MD5 \"9237cd1a6cdd70ed1bc56d3cf364960a\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/build.fasl\"
       :FASL-MD5 \"08780eb1875258f7a3cb2fa3eb965eba\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/lifecycle.fasl\"
       :FASL-MD5 \"9c6c8b03f1ee18ced58af2eb159a874a\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/lookup.fasl\"
       :FASL-MD5 \"8ad5199157b4fa5bf3cfa9ddd623427b\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/package.fasl\"
       :FASL-MD5 \"65fffdd835e087b770ebaa77725d20ee\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/segment.fasl\"
       :FASL-MD5 \"2d5fa8fd306f640b9b8eb902a3c02543\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/target.fasl\"
       :FASL-MD5 \"db58c8a225775389722547ba61c94c23\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/types.fasl\"
       :FASL-MD5 \"3e642ff24a29febf47b3079fa5960e90\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/hash/arithmetic.fasl\"
       :FASL-MD5 \"726b1a1fa3069e926a57153bcf74605e\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/hash/blocks.fasl\"
       :FASL-MD5 \"d33916a5d6f3faf0f18837fac8e849d0\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/hash/hash64.fasl\"
       :FASL-MD5 \"887c02f3228e2f7860951b38d65f605f\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/hash/package.fasl\"
       :FASL-MD5 \"d422aec5b520a1682dea65d643da07f6\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/core.fasl\"
       :FASL-MD5 \"af6197a105d9db7048da5f52f45f4c77\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/hash-digests.fasl\"
       :FASL-MD5 \"1c0e2535920c667e6d2e34ae37c1a386\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/hash-seed.fasl\"
       :FASL-MD5 \"42afe41bceea5f778934e48defad225d\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/package.fasl\"
       :FASL-MD5 \"b4ba56d7c032410a6ba63cd4fe1f859d\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-arena.fasl\"
       :FASL-MD5 \"0608ff4915e363fcd8adf405755e9a22\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-build.fasl\"
       :FASL-MD5 \"93cffdeff3d7e9ef3e3d2bd8141fde10\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-core.fasl\"
       :FASL-MD5 \"4a4534afa0ceb2defcd2d46dfe1e9e8e\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-directory.fasl\"
       :FASL-MD5 \"e6781e9a6fd89c52d73a8306d571ac97\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-package.fasl\"
       :FASL-MD5 \"94c7c45db752bb94bc7d33c5dcbbc4bd\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-probe.fasl\"
       :FASL-MD5 \"49eccf6447615ce62c2ffea3400e9e6b\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-read.fasl\"
       :FASL-MD5 \"7de4ffdecce7e48a4898eec1befd4097\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-relocate.fasl\"
       :FASL-MD5 \"64c7b41a887434e586765291bf6fb472\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-types.fasl\"
       :FASL-MD5 \"7b3aa62d2e45fb3320f041fbfabf6622\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-write.fasl\"
       :FASL-MD5 \"8d36a0ede70711e9b5a2e17c824ac557\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/read.fasl\"
       :FASL-MD5 \"d6a6832473f46b9bc499bfdfd6efd102\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-budget.fasl\"
       :FASL-MD5 \"0a882d07c33b349f302281b6bfc23099\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-copy.fasl\"
       :FASL-MD5 \"9263fbb8a971b3bf68eb9d02cdcc31d7\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-scan.fasl\"
       :FASL-MD5 \"ce67f1f1e6e49be925432fccd0cbd27d\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild.fasl\"
       :FASL-MD5 \"dbae1eb021526822828c644a0a63758f\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/relocate.fasl\"
       :FASL-MD5 \"6e41425adb621fb6384b7dc5532575ef\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/types.fasl\"
       :FASL-MD5 \"2577ea2665c5308844405b2d83ef5c97\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/validation.fasl\"
       :FASL-MD5 \"22d1e523224f74c4c7cf36579eaf6829\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/write.fasl\"
       :FASL-MD5 \"d0e29ab394973661e145f9e8bfadd8f5\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/io/flush.fasl\"
       :FASL-MD5 \"435f0688dda8099084ebe10e9179c848\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/io/lifecycle.fasl\"
       :FASL-MD5 \"b9a598586af8172af5ce652fac9b2821\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/io/native.fasl\"
       :FASL-MD5 \"994828895140841f1e90dd2d30604773\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/io/package.fasl\"
       :FASL-MD5 \"258730de7744d0e18d9dac588c3d4c8c\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/io/transfer.fasl\"
       :FASL-MD5 \"46ff77a14896780526841a5ca064f3b7\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/io/types.fasl\"
       :FASL-MD5 \"fc876df1861134948d817fee39c374f8\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/package.fasl\"
       :FASL-MD5 \"c4f8addb7ce207b67d5cc9209016ece0\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-core.fasl\"
       :FASL-MD5 \"aed7e4b7638e1d26088acc30a886ea8c\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-csn.fasl\"
       :FASL-MD5 \"c88c01a3bf82a07ec2aafd3688363a9d\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-lifecycle.fasl\"
       :FASL-MD5 \"19d1b5e8e242e406c67ed0c5ed453d4f\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-read.fasl\"
       :FASL-MD5 \"cb5f1195669d266fc393e65588fe2d88\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-register.fasl\"
       :FASL-MD5 \"14ea4df8f6883ae7322d261dfb9c4192\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-types.fasl\"
       :FASL-MD5 \"ce8deb93edb565301b8ebfecc15442a7\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/types.fasl\"
       :FASL-MD5 \"e4b80e56f694c8d6711509eac1616809\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/package.fasl\"
       :FASL-MD5 \"b92d351222e18fd85cff15cd4ae11ff2\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/read/core.fasl\"
       :FASL-MD5 \"7c8f84e7e14fb7af7e7ee5a8deb0296b\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/read/package.fasl\"
       :FASL-MD5 \"c11bd7eb3cd3994cb6dd0fa55d18fc42\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/read/task.fasl\"
       :FASL-MD5 \"c12e3fd59f955f491938168df013bd65\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/read/types.fasl\"
       :FASL-MD5 \"74799a5cf694f0464ae8c0d407f54098\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-build.fasl\"
       :FASL-MD5 \"f813a51eef622e333c54feaeffe8f558\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-package.fasl\"
       :FASL-MD5 \"f14d96dc7f6fb15cbb9764a77cb356db\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-query.fasl\"
       :FASL-MD5 \"ce864e102561e098c0b53edc13051d01\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-radix.fasl\"
       :FASL-MD5 \"bc77862dec5f3199ad5f2c7cc858539b\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-sort.fasl\"
       :FASL-MD5 \"7e047b08614a9ec630f4c0cb77e0953f\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-types.fasl\"
       :FASL-MD5 \"c2d1b847e7af10656708dbc84d817b9a\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-build.fasl\"
       :FASL-MD5 \"ce329fc4e64040d35e621b970c43cbf7\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-query.fasl\"
       :FASL-MD5 \"479d2952d03855105a5a953daf9309b3\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-types.fasl\"
       :FASL-MD5 \"9216ddd1bb0cdb3f1700b9dcc5cb8f03\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-build.fasl\"
       :FASL-MD5 \"1760557e8437957e4ab537856ce5271b\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-decode.fasl\"
       :FASL-MD5 \"0f1da84ff9acf1fc57e00c2fe2562f54\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-fold.fasl\"
       :FASL-MD5 \"076d2fd05d364023ea17aa97e5140051\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-package.fasl\"
       :FASL-MD5 \"f1c0e1b2ab99b9e1505c1e720228534d\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-query.fasl\"
       :FASL-MD5 \"a065a1e6b284a45b1e80f62a627cd180\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-types.fasl\"
       :FASL-MD5 \"e78c33e1fff70abe6c5d7c5b31970f2d\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/package.fasl\"
       :FASL-MD5 \"bd110a9045def8c27c9c7e9d4e729812\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/scan.fasl\"
       :FASL-MD5 \"ad7e383c7f530a73dbb46b71342a9195\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/events.fasl\"
       :FASL-MD5 \"f6dab4b919fdec4c39f5ac04d98f0d70\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/io-events.fasl\"
       :FASL-MD5 \"8eb3958b2832461f0a6856e806b2c622\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/ownership.fasl\"
       :FASL-MD5 \"d032be16253a322556aef403a6156981\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/package.fasl\"
       :FASL-MD5 \"9b279be15ff3b7726162d6a5ba20999b\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/publication.fasl\"
       :FASL-MD5 \"fdc4e2654e27b7f91089870a76bba4fd\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/query.fasl\"
       :FASL-MD5 \"b3357cdf0f1ed64a206d840c7cdd4ea9\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/retirement.fasl\"
       :FASL-MD5 \"b358d0ca44bee19a4054514d2fc9289c\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-build.fasl\"
       :FASL-MD5 \"92f1702af2dfb283da77693c90faa664\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-select.fasl\"
       :FASL-MD5 \"79378bb917a42a7694139262945f8fec\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-types.fasl\"
       :FASL-MD5 \"60dc98131c200df12b94d176aa667880\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/types.fasl\"
       :FASL-MD5 \"29a0b9321000c46aa1f1f55031a6cac6\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-boundary.fasl\"
       :FASL-MD5 \"baaf18b68696eeeeab2cd73f198a30a8\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-package.fasl\"
       :FASL-MD5 \"10e3b5ac496a82513fcc90b2437fd1c2\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-run.fasl\"
       :FASL-MD5 \"1b694a6bc8af4da2b3364ee228bd31a4\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-types.fasl\"
       :FASL-MD5 \"25a2f17627f7f520bbb9f25967576a1f\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/compaction-scan.fasl\"
       :FASL-MD5 \"79ca71e0fae3b01b25f58751b0362b8c\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/control-payload.fasl\"
       :FASL-MD5 \"df97463e8c88c7e1f9a1e190a70e27a4\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/formats.fasl\"
       :FASL-MD5 \"d21c6876743716217363ab58d99f5bec\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/log-header.fasl\"
       :FASL-MD5 \"fd4c542f24d8f29ab0cfb1f18f524153\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/package.fasl\"
       :FASL-MD5 \"65023eb760408329de588e04685f5ab4\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/payload-record.fasl\"
       :FASL-MD5 \"41ecb4ddd0e6f6056fab4ad410110c94\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/payload-write.fasl\"
       :FASL-MD5 \"0856987756240859daa11588c4fbf362\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/segment-header.fasl\"
       :FASL-MD5 \"7692e1dd06be74a0d595d0adff689441\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/wal/builder.fasl\"
       :FASL-MD5 \"a87cff68123dd353afeec5f50bb145ee\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/wal/csn.fasl\"
       :FASL-MD5 \"9e66273e3828acba41dbcb051ac52688\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/wal/executor.fasl\"
       :FASL-MD5 \"ff2b687feed561d2e758601275198923\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/wal/group.fasl\"
       :FASL-MD5 \"a78d2b6e12896988a500e71db2875f82\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/wal/package.fasl\"
       :FASL-MD5 \"45582ed8da5abff26ed0daece4ec62f1\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/wal/types.fasl\"
       :FASL-MD5 \"08cb207fef312ef700c7005eb278dee5\"))
     :COMPILED-SUITE
     ((:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/tests/foundation/support.fasl\"
       :FASL-MD5 \"bc4b74d2612be7c36315973745429874\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/support.fasl\"
       :FASL-MD5 \"eb89f35c1054c99a6b6c755b7ebdaca1\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/construction.fasl\"
       :FASL-MD5 \"240970902a90d6085e41ffdb4ae8e70d\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/read.fasl\"
       :FASL-MD5 \"ca65a9663b9961fcccbd1b62d5d57fcb\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/threads.fasl\"
       :FASL-MD5 \"2cc11422b5762f829a5e48f6a9784f0e\"))
     :FAILED-TEST
     \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
     :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE \"SIMPLE-ERROR\"
     :DIAGNOSTIC \"Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (PROGN
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-CALL-OPERATION
                        ARCDOCDB.GET.DIRECTORY.TESTS::OPERATION
                        ARCDOCDB.GET.DIRECTORY.TESTS::CONTEXT DIRECTORY)
                       (SETF ARCDOCDB.GET.DIRECTORY.TESTS::AUTHORIZED T))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVARIANT-VIOLATION (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :DIRECTORY-LOCATION-ABSENT)))\"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . \"f60caa0347db67d0c2a286997a5f7f54\") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . \"bd12d0077a79f0c9c2f0a4dd01731f43\") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   \"alias-input-maps\" :FILE \"src/get-directory/build.lisp\" :DIRECTORY
   #A((133) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/\")
   :EXPECTED-FAILURE :CALLER-ARRAY-CHANGES-DIRECTORY :SUBSTITUTION
   (:BEFORE \"(owned (copy-seq maps))\" :AFTER \"(owned maps)\") :STATUS :OK
   :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   (\"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\") :SOURCE-MANIFEST
   ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . \"692a695f7129e0cc693cffb2983be35b\"))
    (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
    (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
    (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
    (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
    (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
    (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
    (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
    (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
    (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
    (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
    (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"62285b01dc017898fc16588b6522bbbf\"))
    (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
    (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
    (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
    (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
    (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
    (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
    (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
    (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
    (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
    (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
    (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
    (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
    (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
    (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
    (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
    (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
    (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
    (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
    (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
    (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
    (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
    (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
    (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
    (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
    (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
    (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
    (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
    (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
    (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
    (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
    (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
    (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
    (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
    (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
    (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
    (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd0d166bfeee41dc15f53c57586a3d0d\"))
    (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
    (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\"))
    (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
    (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
    (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
    (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
    (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
    (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
    (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
    (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
    (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
    (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
    (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
    (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
    (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
    (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
    (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
    (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
    (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
    (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
    (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
    (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
    (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
    (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
    (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
    (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
    (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
    (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
    (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
    (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
    (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
    (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
    (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
    (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
    (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
    (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
    (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
    (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
    (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
    (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
    (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
    (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
    (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
    (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
    (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
    (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
    (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
    (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
    (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
    (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
    (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
    (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
    (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
    (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
    (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
    (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
    (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
    (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
    (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
    (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
    (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
    (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
    (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
    (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
    (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
    (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
    (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
    (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
    (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
    (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
    (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
    (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
    (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
    (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
    (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
    (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
    (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
    (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
    (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
    (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
    (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
    (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
    (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
    (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
    (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
    (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
    (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
    (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
    (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
    (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
    (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
    (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
    (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
    (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
    (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
    (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
    (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
    (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
    (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
    (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
    (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
    (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
    (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
    (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
    (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
    (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
    (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
    (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
    (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
    (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
    (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
    (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
    (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
    (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
    (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
    (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
    (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
    (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
    (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
    (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
   :COMPILED-TARGET
   (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    \"bd0d166bfeee41dc15f53c57586a3d0d\" :FASL
    \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/build.fasl\"
    :FASL-MD5 \"775ac262c9271c19f3a147708c02564d\")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    (\"sbcl\" \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--disable-debugger\"
     \"--script\" \"isolated-build.lisp\")
    :STDOUT-LOG
    #A((143) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/stdout.log\")
    :STDERR-LOG
    #A((143) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/stderr.log\")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 4610857/1000000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/\"
     :SOURCE-MANIFEST
     ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
       \"692a695f7129e0cc693cffb2983be35b\")
      (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"62285b01dc017898fc16588b6522bbbf\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd0d166bfeee41dc15f53c57586a3d0d\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"74a694385f1aaf03ec87721545494119\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\")
      (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\"))
     :SUITE-FILES
     (\"tests/foundation/support.lisp\" \"tests/get-directory/support.lisp\"
      \"tests/get-directory/construction.lisp\" \"tests/get-directory/read.lisp\"
      \"tests/get-directory/threads.lisp\")
     :REGISTERED-TESTS
     (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
      \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
      \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
      \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
      \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
      \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
      \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
      \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
      \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
      \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
      \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
      \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
      \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
      \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
      \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
      \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
      \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
      \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
      \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
      \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
      \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
      \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
      \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
      \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
     :SELECTED-TEST \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bd0d166bfeee41dc15f53c57586a3d0d\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/build.fasl\"
      :FASL-MD5 \"775ac262c9271c19f3a147708c02564d\")
     :COMPILED-PRODUCT
     ((:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/build.fasl\"
       :FASL-MD5 \"98ca2b463946ef7634d47dd9fc47441a\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/clock.fasl\"
       :FASL-MD5 \"702914c0a974e3f8633a23227617134b\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/core.fasl\"
       :FASL-MD5 \"a128ed791797fe903df051c022a8150f\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/package.fasl\"
       :FASL-MD5 \"c5afec8b45ef141f8ffad2409b9b6a27\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/read.fasl\"
       :FASL-MD5 \"4d418ac5ff4db7941875d7790a1676a5\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/types.fasl\"
       :FASL-MD5 \"762c454aaf8fa723090b5618b2902849\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/write.fasl\"
       :FASL-MD5 \"93bb0e08c2b00062b908daa817bc9533\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-float-minimal.fasl\"
       :FASL-MD5 \"7450b5fb5ac6ac5f67fbf6aa7a14bf7d\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-header.fasl\"
       :FASL-MD5 \"222947814a54530fef87fc9cf988c85d\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-minimal.fasl\"
       :FASL-MD5 \"85734a8937e76a02ffb2fb451915f301\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"62285b01dc017898fc16588b6522bbbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-package.fasl\"
       :FASL-MD5 \"6f97781f0443b8d3361e1be180afa545\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-input.fasl\"
       :FASL-MD5 \"b2be7ce51cc7f852ef7e991865e06505\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-items.fasl\"
       :FASL-MD5 \"c7c6eb5f62b8862cca4ff7d04df4bc5a\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-minimal.fasl\"
       :FASL-MD5 \"74c55d1ccf9e3cf75f353891ac524c94\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-stack.fasl\"
       :FASL-MD5 \"1cb1b94b55775761c912797ad72b9c25\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan.fasl\"
       :FASL-MD5 \"ea6b9ec34cd0a47f792217413b2ccaaa\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-space.fasl\"
       :FASL-MD5 \"ca616d3ebd68aff2b21c74ce9367d50b\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-string-write.fasl\"
       :FASL-MD5 \"b2cac757a0b17a823c363754fe97835f\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-write.fasl\"
       :FASL-MD5 \"5d68cfb51324f27adedb6d93b19c7c6e\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/package.fasl\"
       :FASL-MD5 \"56fd531bd84e5e47135adf74cbac826f\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/utf8.fasl\"
       :FASL-MD5 \"6f42014aa526e2be330343ae8721d484\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/csn/package.fasl\"
       :FASL-MD5 \"becea9e37821c1256a3198f22ca806d9\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/csn/registry.fasl\"
       :FASL-MD5 \"e392075e05567c053d6ef808fa5b8207\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/epochs/core.fasl\"
       :FASL-MD5 \"16e8dcabc272352fb26c6b61f6e80197\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/epochs/package.fasl\"
       :FASL-MD5 \"b8e388c9a4efcdae3b1de76ad44f1127\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/epochs/read.fasl\"
       :FASL-MD5 \"c92360972b6090085d09712d9cbaa5f3\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/epochs/reclaim.fasl\"
       :FASL-MD5 \"893b06159db39c4b2fbabcf06f97e12c\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/epochs/retire.fasl\"
       :FASL-MD5 \"bd871cf16e0270ee6586e5326acb82fd\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/epochs/types.fasl\"
       :FASL-MD5 \"524a4539014e75fd439fa343878810d1\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/handoff.fasl\"
       :FASL-MD5 \"0ca6df5d26ad815136b7e350fe21f2dc\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/package.fasl\"
       :FASL-MD5 \"aaf6f903fcad7894fd2b494152fde471\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/queue.fasl\"
       :FASL-MD5 \"697b93c56aa5c450fa2091cf4eccfe5b\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/ready-recycle.fasl\"
       :FASL-MD5 \"e64c0b741450b116148d1d0091e273bd\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/ready-types.fasl\"
       :FASL-MD5 \"fcd987e8c5882f299c1f9bcfaeaf9e5f\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/ready.fasl\"
       :FASL-MD5 \"2aa799222f985ea85ce8d19e06ddb8a1\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-boundary.fasl\"
       :FASL-MD5 \"5b1f857ed44415443ff4dfa51a6414ca\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-claim.fasl\"
       :FASL-MD5 \"dfcd6ea685faa5ba4fa8da39ea9b9e81\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-run.fasl\"
       :FASL-MD5 \"13b23a28fb6c30005072e09a4551eed5\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-types.fasl\"
       :FASL-MD5 \"813dddbaeee0f82e21203d3cd3361573\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/writer.fasl\"
       :FASL-MD5 \"e982473e4822a22e577fd8b2efd36080\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/foundation/batch.fasl\"
       :FASL-MD5 \"39621b611cc04be7bb9391576cfb1d50\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/foundation/binary.fasl\"
       :FASL-MD5 \"5bf02ba1a9f2cda71209f7beccc27174\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/foundation/conditions.fasl\"
       :FASL-MD5 \"b9fd52851c82468317d9953f8e0cfebc\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/foundation/crc32c.fasl\"
       :FASL-MD5 \"db2da46f29cfe00d8d8058699f9958d4\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/foundation/package.fasl\"
       :FASL-MD5 \"c868156cf2c95498d646aa3f6b4d085c\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/foundation/record.fasl\"
       :FASL-MD5 \"2dd66672a00556a40cdc9fe9c6657015\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd0d166bfeee41dc15f53c57586a3d0d\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/build.fasl\"
       :FASL-MD5 \"775ac262c9271c19f3a147708c02564d\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/package.fasl\"
       :FASL-MD5 \"2ea63c738a0afcf04abd657348796339\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"74a694385f1aaf03ec87721545494119\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/read.fasl\"
       :FASL-MD5 \"768899e774c98fa5ec9eec2b1a4ec5a5\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/types.fasl\"
       :FASL-MD5 \"fc9ea68243de53ee50a3f89c9e10e8cf\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-build.fasl\"
       :FASL-MD5 \"be992a06155318b2abdfefcefc80c829\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-directory.fasl\"
       :FASL-MD5 \"f2e75a3658a674288a7c41e39fd57d42\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-preflight.fasl\"
       :FASL-MD5 \"146d89c5a468d203cd2d1065586cfb0c\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-read.fasl\"
       :FASL-MD5 \"cc151465dfb75e72601057bb1f703613\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-scan.fasl\"
       :FASL-MD5 \"f9c7b802e6eeca3b7aa80070383bd537\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-types.fasl\"
       :FASL-MD5 \"088c4d913a99c9313aeeb6d29dc9a1ed\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/build.fasl\"
       :FASL-MD5 \"62205476464cbcf91fac3f31ec56a284\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/package.fasl\"
       :FASL-MD5 \"9d80a3354d1e0f9b5c02fe146c74d612\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/read.fasl\"
       :FASL-MD5 \"dac2f4d3eaa13887aa32dd4bad600791\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/rows.fasl\"
       :FASL-MD5 \"924238f561c1fd368a8463a71fb28e45\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/scan.fasl\"
       :FASL-MD5 \"fe8f02ce0c24debb23fa4e5119ebb19f\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/sort.fasl\"
       :FASL-MD5 \"2e7ce3a216b40bb31f5dbd74ad542cb9\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/types.fasl\"
       :FASL-MD5 \"73e635b10567d2f7e8d6acaa7dcff518\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/build.fasl\"
       :FASL-MD5 \"39b7418ad5e99c06f281389b04b91e08\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/lifecycle.fasl\"
       :FASL-MD5 \"d02f9dd9366588d3de8f93a28c3c2eab\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/lookup.fasl\"
       :FASL-MD5 \"eed8e483a9c01dea015ca35a09074a7a\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/package.fasl\"
       :FASL-MD5 \"00a5c713ebea3173d7437a5ad89d7efa\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/segment.fasl\"
       :FASL-MD5 \"4c7e67270a02bf45d9463a14a682980b\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/target.fasl\"
       :FASL-MD5 \"466b05027c8ff4f775f5dfe9a85e4640\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/types.fasl\"
       :FASL-MD5 \"2bf26a2f7e4cbd0b41fa3463fb38c4e0\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/hash/arithmetic.fasl\"
       :FASL-MD5 \"68692b103ec531382517319d6f21a07f\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/hash/blocks.fasl\"
       :FASL-MD5 \"d8a5c5749a99710b09660ed3be4b86a3\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/hash/hash64.fasl\"
       :FASL-MD5 \"6adf5c76d8acc26cd7e8e6a45fe31865\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/hash/package.fasl\"
       :FASL-MD5 \"7990dfda3055006598f6f1f95695e153\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/core.fasl\"
       :FASL-MD5 \"fd152cef84bd2ae9541cb4486ebf6c61\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/hash-digests.fasl\"
       :FASL-MD5 \"61c789bd66843600f7b464b371792e6d\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/hash-seed.fasl\"
       :FASL-MD5 \"bb73bcf196fe0c5dc2b7fb6fab1873a7\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/package.fasl\"
       :FASL-MD5 \"f77afc1abdf843bc470573c8d1d0e2b9\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-arena.fasl\"
       :FASL-MD5 \"8a5765a9be7e9a642a15b0cbd92fe882\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-build.fasl\"
       :FASL-MD5 \"c399428af1cd3a3207af09dc171b6b8f\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-core.fasl\"
       :FASL-MD5 \"bb5b909b36f288fd827ae94577818c9d\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-directory.fasl\"
       :FASL-MD5 \"3ce0dda5dc42c20e3d6448992e797802\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-package.fasl\"
       :FASL-MD5 \"ebf48a5351b7b509bb7b890490a9b8f0\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-probe.fasl\"
       :FASL-MD5 \"4420edcd0abe908445cf5325005a6e7e\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-read.fasl\"
       :FASL-MD5 \"628b9e1407d70f99f4a85d4c7c7d9990\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-relocate.fasl\"
       :FASL-MD5 \"20fe0f5ba7ad1eb9f4811a283718b3d2\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-types.fasl\"
       :FASL-MD5 \"3ccac881002c19ccd35cd92daa615c69\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-write.fasl\"
       :FASL-MD5 \"bd2d3a015ef7703b2a831041764f316b\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/read.fasl\"
       :FASL-MD5 \"68e20911eb02f6b903184a68ea9d97dd\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild-budget.fasl\"
       :FASL-MD5 \"43f665b7709de27281c7000605522bdd\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild-copy.fasl\"
       :FASL-MD5 \"fca9b123c54d6f2e0e72aaf3c31a124d\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild-scan.fasl\"
       :FASL-MD5 \"80a86bca06678ae36d4f25985d1472a9\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild.fasl\"
       :FASL-MD5 \"4bb5b0ffc6f1b71cd4dbc80949807e20\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/relocate.fasl\"
       :FASL-MD5 \"38c94fc4b039a805b24b8d262df4831c\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/types.fasl\"
       :FASL-MD5 \"0201c5559dbc26f489ede086e9c52e5c\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/validation.fasl\"
       :FASL-MD5 \"a4f6c0c3c79d6017de29a875d5063e37\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/write.fasl\"
       :FASL-MD5 \"fa2f7f755c6cdfeaa5cf3bfd4a11306a\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/io/flush.fasl\"
       :FASL-MD5 \"a0a1bbc22eb29c448cb926513901fc50\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/io/lifecycle.fasl\"
       :FASL-MD5 \"190980e4cff4e8c594f79e7b910dbd40\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/io/native.fasl\"
       :FASL-MD5 \"56a2b89948a4b228f44ae5a9f7483dea\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/io/package.fasl\"
       :FASL-MD5 \"ce9280eea66e53c197f9821d1b2a0054\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/io/transfer.fasl\"
       :FASL-MD5 \"4c1dfb773ea97f9602360928fd1cfd11\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/io/types.fasl\"
       :FASL-MD5 \"2992a7b6f937bab784ad022044d77e5f\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/package.fasl\"
       :FASL-MD5 \"7dd441098fc4dfdf18f2d4d152d5c13f\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-core.fasl\"
       :FASL-MD5 \"1a0977f076863cc33596e104a52b98b7\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-csn.fasl\"
       :FASL-MD5 \"9ef8c31e1dd54b1e0b0d47fde6d702b4\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-lifecycle.fasl\"
       :FASL-MD5 \"f8093dbbe20eeb797a8e6c99df89c423\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-read.fasl\"
       :FASL-MD5 \"ab227a88057bcfe392d0c2adbcbd927b\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-register.fasl\"
       :FASL-MD5 \"75e220d1aee2cbb64ea33792b088cd56\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-types.fasl\"
       :FASL-MD5 \"b27e2d393eb482275bd20e157cfe3a78\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/types.fasl\"
       :FASL-MD5 \"5580a6bcc1caa150a2bbe1c43b50a667\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/package.fasl\"
       :FASL-MD5 \"56b5bd9c37ffebed4c95c07c15b84d42\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/read/core.fasl\"
       :FASL-MD5 \"c66e998d3bae90f624237ee34f6913e1\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/read/package.fasl\"
       :FASL-MD5 \"6e52645c5cb2407842bfdb6241ed0ee1\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/read/task.fasl\"
       :FASL-MD5 \"8474e41405bbceaf3c565733473b96e4\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/read/types.fasl\"
       :FASL-MD5 \"18ca600d53f73ae89c9ca482ae4aabd0\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-build.fasl\"
       :FASL-MD5 \"f64ac26c8def467c56cbb8c3f4223e3b\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-package.fasl\"
       :FASL-MD5 \"e50c95afc607f2ac49700899fdcc2c04\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-query.fasl\"
       :FASL-MD5 \"fbb03f87f8a22f0f8c0b64aeace7037f\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-radix.fasl\"
       :FASL-MD5 \"0eb27cf5f2193f5f0188f73318c679fd\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-sort.fasl\"
       :FASL-MD5 \"042faac63912d41750ef23d732b8ee25\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-types.fasl\"
       :FASL-MD5 \"413534450f9fc7f81b8c0d064acdc79d\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/inventory-build.fasl\"
       :FASL-MD5 \"c07605568409c2a116cfefc9814004d0\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/inventory-query.fasl\"
       :FASL-MD5 \"722c863a09c2da6637a8589e49ecd47d\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/inventory-types.fasl\"
       :FASL-MD5 \"c0c10cb5587ae4ca6982006550110dab\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-build.fasl\"
       :FASL-MD5 \"f065d518c408fd35ce466d6da03d0681\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-decode.fasl\"
       :FASL-MD5 \"3c6f5cdeeab5c3570bcb4aea53bca06a\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-fold.fasl\"
       :FASL-MD5 \"940187e91638d4ae9a861617e7f18910\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-package.fasl\"
       :FASL-MD5 \"3838f7d8dbd831a9d540ff0f2e160ada\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-query.fasl\"
       :FASL-MD5 \"a86bf546656dd55a92675f401cbc16fb\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-types.fasl\"
       :FASL-MD5 \"b22b7b7dc6ff4303c844f5f8e3d5ebd8\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/package.fasl\"
       :FASL-MD5 \"7d2c4238189248d1032f76f996ca6734\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/scan.fasl\"
       :FASL-MD5 \"ee999206b7b63f50381a3b71aaee65e9\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/events.fasl\"
       :FASL-MD5 \"153960bd0e33cc586767f80e216a2443\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/io-events.fasl\"
       :FASL-MD5 \"3b34427fd635a99a7f173419d6ac5be3\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/ownership.fasl\"
       :FASL-MD5 \"e7d9469875d782a70e37b809eb9cc5c4\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/package.fasl\"
       :FASL-MD5 \"cf6f87f83636009e45cd231863c913e7\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/publication.fasl\"
       :FASL-MD5 \"2981b235043c2d360a803a4c62b87a5e\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/query.fasl\"
       :FASL-MD5 \"57a3f096f2af17df9f62cb3c6b5a139e\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/retirement.fasl\"
       :FASL-MD5 \"32bfee6ef018455c1a749a3f40144093\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/routing-build.fasl\"
       :FASL-MD5 \"a74cc649c99a964cbf933adb6d698265\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/routing-select.fasl\"
       :FASL-MD5 \"ee684b49f22544af34972074348a6e5a\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/routing-types.fasl\"
       :FASL-MD5 \"5a426f5c2edbd243f976994d840b2e40\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/types.fasl\"
       :FASL-MD5 \"e148e81a762838c6db02f7da73880fbb\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-boundary.fasl\"
       :FASL-MD5 \"d14c8f6c6c72012f93d4aa2289093f99\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-package.fasl\"
       :FASL-MD5 \"0f95111d4ca529b1d3f375525782268b\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-run.fasl\"
       :FASL-MD5 \"f4efbaa32375e61dc2279284313ef3cf\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-types.fasl\"
       :FASL-MD5 \"ca210939332b8aee6a13ab92c39c5686\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/compaction-scan.fasl\"
       :FASL-MD5 \"fdd501b00b7a18082b8c9fb81b7cd889\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/control-payload.fasl\"
       :FASL-MD5 \"365c45a1ee1e40cff75dde5f36e4de94\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/formats.fasl\"
       :FASL-MD5 \"ce4feb13c250f8c7a72893fc05afb6ca\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/log-header.fasl\"
       :FASL-MD5 \"746412ddec759dcf80bd6081b7d0b80c\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/package.fasl\"
       :FASL-MD5 \"4e9c79f05ae4d27f8e94ee0ecb064e01\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/payload-record.fasl\"
       :FASL-MD5 \"1b3321a19af1e109ce1dbad33857c7a0\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/payload-write.fasl\"
       :FASL-MD5 \"44413401c227d1ce4f8bbe89cada407d\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/segment-header.fasl\"
       :FASL-MD5 \"99e7c47ca74a6e8cb379628ee8f59368\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/wal/builder.fasl\"
       :FASL-MD5 \"36b61d3f02169ea725734d7ee84876b5\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/wal/csn.fasl\"
       :FASL-MD5 \"c2d7fce47cf29c50fa0980161bddce86\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/wal/executor.fasl\"
       :FASL-MD5 \"d87a8889d7d93df12075a84b6a1187bf\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/wal/group.fasl\"
       :FASL-MD5 \"6b06f4fcae26188d355ecfcbc32e9777\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/wal/package.fasl\"
       :FASL-MD5 \"f68f78e5af7ebfa20c60e9a30f91b38f\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/wal/types.fasl\"
       :FASL-MD5 \"e61aebce9b40ea00bf47f6d6ce0ae368\"))
     :COMPILED-SUITE
     ((:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/tests/foundation/support.fasl\"
       :FASL-MD5 \"b10aeba8b8ec7c29dc75cdcaa627253b\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/support.fasl\"
       :FASL-MD5 \"1ee1c14d13010204faf478e83a0fe824\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/construction.fasl\"
       :FASL-MD5 \"926bd0f92f6a90bcd68f18692c587d7c\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/read.fasl\"
       :FASL-MD5 \"b1a0342175ead12af06368805643c07a\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/threads.fasl\"
       :FASL-MD5 \"129b247069516796da072974699f71d7\"))
     :FAILED-TEST \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\" :PASSED-TESTS
     NIL :FAILURE-KIND :PRODUCT-CONDITION :CONDITION-TYPE \"INVARIANT-VIOLATION\"
     :DIAGNOSTIC \"ArcDocDB: DIRECTORY-SHAPE\"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . \"fdbdbe9c375b32143df6d8ed6e191b80\") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . \"bd0d166bfeee41dc15f53c57586a3d0d\") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   \"truncate-directory-id\" :FILE \"src/get-directory/read.lisp\" :DIRECTORY
   #A((138) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/\")
   :EXPECTED-FAILURE :MAX-U32-LOCATION-REJECTED :SUBSTITUTION
   (:BEFORE \"(ldb (byte 32 32) location)\" :AFTER \"(ldb (byte 31 32) location)\")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   (\"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\")
   :SOURCE-MANIFEST
   ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . \"692a695f7129e0cc693cffb2983be35b\"))
    (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
    (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
    (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
    (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
    (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
    (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
    (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
    (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
    (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
    (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
    (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"62285b01dc017898fc16588b6522bbbf\"))
    (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
    (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
    (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
    (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
    (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
    (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
    (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
    (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
    (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
    (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
    (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
    (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
    (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
    (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
    (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
    (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
    (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
    (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
    (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
    (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
    (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
    (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
    (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
    (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
    (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
    (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
    (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
    (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
    (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
    (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
    (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
    (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
    (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
    (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
    (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
    (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
    (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
    (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"65ce18f4ca8502f65bf6ee411e9f5fe9\"))
    (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
    (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
    (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
    (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
    (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
    (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
    (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
    (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
    (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
    (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
    (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
    (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
    (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
    (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
    (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
    (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
    (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
    (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
    (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
    (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
    (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
    (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
    (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
    (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
    (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
    (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
    (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
    (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
    (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
    (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
    (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
    (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
    (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
    (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
    (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
    (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
    (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
    (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
    (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
    (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
    (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
    (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
    (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
    (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
    (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
    (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
    (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
    (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
    (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
    (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
    (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
    (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
    (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
    (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
    (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
    (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
    (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
    (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
    (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
    (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
    (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
    (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
    (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
    (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
    (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
    (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
    (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
    (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
    (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
    (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
    (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
    (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
    (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
    (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
    (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
    (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
    (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
    (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
    (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
    (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
    (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
    (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
    (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
    (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
    (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
    (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
    (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
    (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
    (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
    (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
    (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
    (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
    (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
    (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
    (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
    (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
    (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
    (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
    (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
    (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
    (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
    (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
    (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
    (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
    (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
    (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
    (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
    (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
    (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
    (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
    (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
    (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
    (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
    (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
    (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
    (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
    (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
    (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
   :COMPILED-TARGET
   (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    \"65ce18f4ca8502f65bf6ee411e9f5fe9\" :FASL
    \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/read.fasl\"
    :FASL-MD5 \"38f618198dc1382b90692e3d6f857ae5\")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    (\"sbcl\" \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--disable-debugger\"
     \"--script\" \"isolated-build.lisp\")
    :STDOUT-LOG
    #A((148) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/stdout.log\")
    :STDERR-LOG
    #A((148) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/stderr.log\")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 467697/100000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/\"
     :SOURCE-MANIFEST
     ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
       \"692a695f7129e0cc693cffb2983be35b\")
      (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"62285b01dc017898fc16588b6522bbbf\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cde24b2bf5c5637d5501b95bed47df31\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65ce18f4ca8502f65bf6ee411e9f5fe9\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\")
      (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\"))
     :SUITE-FILES
     (\"tests/foundation/support.lisp\" \"tests/get-directory/support.lisp\"
      \"tests/get-directory/construction.lisp\" \"tests/get-directory/read.lisp\"
      \"tests/get-directory/threads.lisp\")
     :REGISTERED-TESTS
     (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
      \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
      \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
      \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
      \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
      \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
      \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
      \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
      \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
      \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
      \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
      \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
      \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
      \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
      \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
      \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
      \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
      \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
      \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
      \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
      \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
      \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
      \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
      \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
     :SELECTED-TEST
     \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"65ce18f4ca8502f65bf6ee411e9f5fe9\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/read.fasl\"
      :FASL-MD5 \"38f618198dc1382b90692e3d6f857ae5\")
     :COMPILED-PRODUCT
     ((:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/build.fasl\"
       :FASL-MD5 \"b05bbf721e9d9be57cac12e7ee925931\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/clock.fasl\"
       :FASL-MD5 \"4df6ace6bdb5f5041c87e25f1d4cfd47\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/core.fasl\"
       :FASL-MD5 \"aed6bc27c670643e4739558a54a06b70\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/package.fasl\"
       :FASL-MD5 \"2323716d534af62fc43f847b94ef92f7\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/read.fasl\"
       :FASL-MD5 \"662a5016cb9413c342785889c47f8868\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/types.fasl\"
       :FASL-MD5 \"af84c827afea18aa92cf60cefad6aa1b\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/write.fasl\"
       :FASL-MD5 \"8f1add68e061388d9d355f263e28f968\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-float-minimal.fasl\"
       :FASL-MD5 \"9f3f3f5f884fbf282477f144ec3fb1fa\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-header.fasl\"
       :FASL-MD5 \"5b29826950281b15edcee79bc9fff4f8\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-minimal.fasl\"
       :FASL-MD5 \"0c11dcdc935a0dcb13dd3f814a3098ce\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"62285b01dc017898fc16588b6522bbbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-package.fasl\"
       :FASL-MD5 \"ebb6a24dc276d2344199a435fb1633bc\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-input.fasl\"
       :FASL-MD5 \"08b465d088831277bc98ab95ce914bbe\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-items.fasl\"
       :FASL-MD5 \"4b7edeb7868eaddddbe31ed6d9af12e8\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-minimal.fasl\"
       :FASL-MD5 \"7820f3bf0743b41dd86f47e92821272a\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-stack.fasl\"
       :FASL-MD5 \"82e122cc047767abb022e79162ab5f87\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan.fasl\"
       :FASL-MD5 \"cb4ff521cd06dbda5124b0bfd17c4a77\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-space.fasl\"
       :FASL-MD5 \"67818d480ae64a153e2080600dc6c340\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-string-write.fasl\"
       :FASL-MD5 \"e56ddfc8814d9436b1bcc2be64e8ae54\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-write.fasl\"
       :FASL-MD5 \"8cde4fedec880bf6e060aad91d1bb3a2\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/package.fasl\"
       :FASL-MD5 \"e0be1a89927442f6341fa5a88fba61b9\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/utf8.fasl\"
       :FASL-MD5 \"1ebd7a2277bc78785f19c5097483a98d\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/csn/package.fasl\"
       :FASL-MD5 \"9326ae39bc3c077fa52e3ea17cb9901f\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/csn/registry.fasl\"
       :FASL-MD5 \"42cbc0b6f7fd947da7869b987b2cc805\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/core.fasl\"
       :FASL-MD5 \"4734fd0bd91ea8a9c65665a591ad99eb\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/package.fasl\"
       :FASL-MD5 \"6188128fee03eea6e1c6091fe489ebf9\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/read.fasl\"
       :FASL-MD5 \"53e6b595cf35a4f778b8cd006212b103\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/reclaim.fasl\"
       :FASL-MD5 \"ba64f12b6bb139418fe1742b0eb8d6b9\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/retire.fasl\"
       :FASL-MD5 \"501caa2b41b6d0aea71b9056cc01c89e\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/types.fasl\"
       :FASL-MD5 \"75a757e9ed2294f50ff1d26e1bb1063a\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/handoff.fasl\"
       :FASL-MD5 \"2b36a3a0898e8fa404b50a8c5b6c6014\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/package.fasl\"
       :FASL-MD5 \"cdf9b72917e99a93ac2fdb2b953196e4\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/queue.fasl\"
       :FASL-MD5 \"7add88e43da71bb51e4fe40aa2197d1d\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/ready-recycle.fasl\"
       :FASL-MD5 \"ccc64dafcbd902537f124c469cba1918\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/ready-types.fasl\"
       :FASL-MD5 \"4bb6123e84978e564a7dc2b22c1ecb11\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/ready.fasl\"
       :FASL-MD5 \"c9c79a2a96ab45b46779f164f1cf3ec2\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-boundary.fasl\"
       :FASL-MD5 \"3cb1c991687701b51d1082419e3a4410\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-claim.fasl\"
       :FASL-MD5 \"8160873e5fec11b91d9fe9ac88d0cfad\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-run.fasl\"
       :FASL-MD5 \"9f63c285fbc5ab866d32297a437ea9b1\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-types.fasl\"
       :FASL-MD5 \"0c5a4555e62c9d337b8823ccda861f83\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/writer.fasl\"
       :FASL-MD5 \"cd6f865798712b74f51192abbccda3b6\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/batch.fasl\"
       :FASL-MD5 \"1e13ae8269623b8368df564c0bb0d1a5\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/binary.fasl\"
       :FASL-MD5 \"87686cc89b819e2795e112f83da07abd\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/conditions.fasl\"
       :FASL-MD5 \"3665d3b05650f3e8a87a49553fafac81\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/crc32c.fasl\"
       :FASL-MD5 \"a9a3fefa5b960661a73146c8087d4697\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/package.fasl\"
       :FASL-MD5 \"36f58eb12fec0890f9ebf4052088a8fa\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/record.fasl\"
       :FASL-MD5 \"33381d692a1b4d58a3970ecfe32af0aa\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cde24b2bf5c5637d5501b95bed47df31\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/build.fasl\"
       :FASL-MD5 \"40d564ed7d9a03b22b53abd96ff282ea\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/package.fasl\"
       :FASL-MD5 \"b1a219972d64d3ce051bbf6d8f5c5c11\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65ce18f4ca8502f65bf6ee411e9f5fe9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/read.fasl\"
       :FASL-MD5 \"38f618198dc1382b90692e3d6f857ae5\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/types.fasl\"
       :FASL-MD5 \"7655d93b94a5c56de28f65884c4d7f54\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-build.fasl\"
       :FASL-MD5 \"c3ceb6e3f22865e824d60fba6ed8971d\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-directory.fasl\"
       :FASL-MD5 \"64475d2d7db3dd11de2037570fdc0d07\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-preflight.fasl\"
       :FASL-MD5 \"898b9592678c0620db53bd31b9182a79\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-read.fasl\"
       :FASL-MD5 \"f93ff7f7a587a2c2cfe0bc3f12aa943b\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-scan.fasl\"
       :FASL-MD5 \"ad0133b2881baf762e83d700143f81e8\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-types.fasl\"
       :FASL-MD5 \"29b5a0c9d020995c4aaadf02934d2cfc\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/build.fasl\"
       :FASL-MD5 \"44db0ca30900313fdf264354bdb812be\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/package.fasl\"
       :FASL-MD5 \"cdcd0e91b77cba603b378318828289a8\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/read.fasl\"
       :FASL-MD5 \"fd0e3c6977f8d58a8394479e5d4ffe9b\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/rows.fasl\"
       :FASL-MD5 \"facc250608567076c96dd32937ec759b\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/scan.fasl\"
       :FASL-MD5 \"b50667f8ba242ae8b838ca562fafe5a1\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/sort.fasl\"
       :FASL-MD5 \"6d54092ee39e4ee69743f4e216908f57\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/types.fasl\"
       :FASL-MD5 \"040aacbd6f5cf9e560dcb0e5f2d443de\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/build.fasl\"
       :FASL-MD5 \"04f56443b9cd88e787cbb543039d0ec5\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/lifecycle.fasl\"
       :FASL-MD5 \"71eb569c1cecf6d6dd266945fb6f52a9\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/lookup.fasl\"
       :FASL-MD5 \"86924f16f5bd3c2dc1967764f2a923eb\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/package.fasl\"
       :FASL-MD5 \"523c637fe9f8d1f8e950494008b93b0c\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/segment.fasl\"
       :FASL-MD5 \"7250ced5b174796f30e5f0422a5994c2\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/target.fasl\"
       :FASL-MD5 \"241567f9558ac64a29b173fea370afb9\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/types.fasl\"
       :FASL-MD5 \"a246f40885b954035a34ce03af72f795\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/hash/arithmetic.fasl\"
       :FASL-MD5 \"acb0244366c7cc423d7467342723b3d7\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/hash/blocks.fasl\"
       :FASL-MD5 \"f7e822abbc983b9578c036d349a6b070\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/hash/hash64.fasl\"
       :FASL-MD5 \"ad7c108b723cecbaebf17b8d0838cf5a\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/hash/package.fasl\"
       :FASL-MD5 \"9b28cc8ddf6acc9e0fcd44060e83d5ab\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/core.fasl\"
       :FASL-MD5 \"907ad30c0035428e3097e79c0889949a\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/hash-digests.fasl\"
       :FASL-MD5 \"827e8b4df8b348594bea03355ba04054\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/hash-seed.fasl\"
       :FASL-MD5 \"462ae13a472483c2ed06b0b3a61acfa4\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/package.fasl\"
       :FASL-MD5 \"6b74c42ef8e1acf7563e68512be7d86d\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-arena.fasl\"
       :FASL-MD5 \"c0a13a72357141521789a6a0abec6f2f\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-build.fasl\"
       :FASL-MD5 \"054d29002287b7ed79d525b47ec51641\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-core.fasl\"
       :FASL-MD5 \"35f6764e2d259ce2b07e750a6bf570d4\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-directory.fasl\"
       :FASL-MD5 \"64dc4fc07646c456b2c44b927f434c27\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-package.fasl\"
       :FASL-MD5 \"af545553bd2ab38353890e3212142d00\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-probe.fasl\"
       :FASL-MD5 \"1c5411483321f29886b3a232c9fbf319\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-read.fasl\"
       :FASL-MD5 \"625ddae47965e8aa6249f1788271991c\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-relocate.fasl\"
       :FASL-MD5 \"0d170e37957b1bf551ad23687cd8a33b\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-types.fasl\"
       :FASL-MD5 \"3c38b11ef949b618e445514f185d4575\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-write.fasl\"
       :FASL-MD5 \"dc499a87a98bf7859f6f64d91f36f85e\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/read.fasl\"
       :FASL-MD5 \"7c29243b02a5a7ca83c59f950198670f\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild-budget.fasl\"
       :FASL-MD5 \"f27c6482937d1003c9cd74241e79af44\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild-copy.fasl\"
       :FASL-MD5 \"e7c227dc881a5b9194896c7c5809f42a\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild-scan.fasl\"
       :FASL-MD5 \"1e92a6dad489cbd821c281325528cda4\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild.fasl\"
       :FASL-MD5 \"de80266ab708c260b9b3c25f4e1e2ae6\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/relocate.fasl\"
       :FASL-MD5 \"1569f537c003cfb58eb8018c2db3da0b\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/types.fasl\"
       :FASL-MD5 \"3bb5d6737581d66c019d2aa042d7b36c\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/validation.fasl\"
       :FASL-MD5 \"3fb7bb299e2418db777ea80f934ceaec\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/write.fasl\"
       :FASL-MD5 \"09d3af5d5bf8874bd3cbc680aac99b20\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/io/flush.fasl\"
       :FASL-MD5 \"9e0d369e00860a6eda55898bfac20147\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/io/lifecycle.fasl\"
       :FASL-MD5 \"ed10200d5c3b4d345f4a3b07cbd9b0eb\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/io/native.fasl\"
       :FASL-MD5 \"298e99b7c229999e9fc93e3a875228aa\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/io/package.fasl\"
       :FASL-MD5 \"636fac6c3371a9bc55ac437da588e4c0\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/io/transfer.fasl\"
       :FASL-MD5 \"f82014dc4706f1b280d16dafe0cb9986\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/io/types.fasl\"
       :FASL-MD5 \"a21a24e2deedb7dd27377a91ef2a7fb4\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/package.fasl\"
       :FASL-MD5 \"21261c54e8cc1f67c17d01417c944687\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-core.fasl\"
       :FASL-MD5 \"3d3e5d8e76483aebb0758e1255b197f3\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-csn.fasl\"
       :FASL-MD5 \"6d8196f915e0a6f5703261ad4cac5107\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-lifecycle.fasl\"
       :FASL-MD5 \"9846301d8af0c4ccb413f425afd63095\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-read.fasl\"
       :FASL-MD5 \"a837e111a5fce513c148e785b8501d11\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-register.fasl\"
       :FASL-MD5 \"9a43eaf19de9c55bc48452e03fe4ad68\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-types.fasl\"
       :FASL-MD5 \"a06e27191047791b589ba2763e85a019\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/types.fasl\"
       :FASL-MD5 \"b13bf6429530160333d8400b6eb07c61\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/package.fasl\"
       :FASL-MD5 \"b2964de08f8053e276ebdb7471a17fb6\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/read/core.fasl\"
       :FASL-MD5 \"155740baba0a4f6b882e7e357852c968\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/read/package.fasl\"
       :FASL-MD5 \"264da09a320097606f259da825d659b5\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/read/task.fasl\"
       :FASL-MD5 \"686353d5a5b09a7af33478e72b3e935b\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/read/types.fasl\"
       :FASL-MD5 \"8c0676159e84f65be6daacd8604533e1\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-build.fasl\"
       :FASL-MD5 \"89c5d6342b28aeaa1f03030074cce264\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-package.fasl\"
       :FASL-MD5 \"4e86cbc0bd7c82d3ef83387ce636aba8\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-query.fasl\"
       :FASL-MD5 \"0d55b4954635b12b2465860c117c36b0\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-radix.fasl\"
       :FASL-MD5 \"6a36659dcff6f29786a40abfc66a6c4e\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-sort.fasl\"
       :FASL-MD5 \"249a342a660bcb35818bc92295324953\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-types.fasl\"
       :FASL-MD5 \"4ab2d8a3a739d5af02ab16d68fa93118\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/inventory-build.fasl\"
       :FASL-MD5 \"5ef91e27a99b02e2b386777deb43af3b\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/inventory-query.fasl\"
       :FASL-MD5 \"12e94b93bbab6299f3c53797bca17620\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/inventory-types.fasl\"
       :FASL-MD5 \"32deb11c53f6dc01a2f6cc250b5c5775\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-build.fasl\"
       :FASL-MD5 \"ba277425244b2a907f307cb9bd8676ad\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-decode.fasl\"
       :FASL-MD5 \"610341d82cdfced946a88b47fe916013\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-fold.fasl\"
       :FASL-MD5 \"704d802562585e1ebc15abaf072d3f81\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-package.fasl\"
       :FASL-MD5 \"3371a2de4b8c70080bac1ab1439967b9\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-query.fasl\"
       :FASL-MD5 \"4558bdc7aa694f1c3ca4752b62c20c5a\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-types.fasl\"
       :FASL-MD5 \"2d4a1f47c8a2cd1e8a1c35d2e21600e3\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/package.fasl\"
       :FASL-MD5 \"889949e55d2311fb828cab9fa6c80ef4\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/scan.fasl\"
       :FASL-MD5 \"fb468e603bed3eb04f83ee9507a9690d\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/events.fasl\"
       :FASL-MD5 \"60353fa67ae0f6b41a6c234afd68fc82\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/io-events.fasl\"
       :FASL-MD5 \"2a707b1425d5b1f9fae7a8e2463f7468\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/ownership.fasl\"
       :FASL-MD5 \"374517178be6219359fd182806e75892\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/package.fasl\"
       :FASL-MD5 \"10d68d5d1fd1cb5c2f78490ac94b38d9\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/publication.fasl\"
       :FASL-MD5 \"57c81e5c4c026decc1a1447d1493b1b6\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/query.fasl\"
       :FASL-MD5 \"ea0c46e0746cb1d51546b5665ed730c7\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/retirement.fasl\"
       :FASL-MD5 \"7e14413378b17f0ca0f00310bf01708c\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/routing-build.fasl\"
       :FASL-MD5 \"ce24dc4df4cfc1ae0d5e847dace74a03\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/routing-select.fasl\"
       :FASL-MD5 \"702da9c50eb3c054998cdd6301b71c64\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/routing-types.fasl\"
       :FASL-MD5 \"22acd51bb446a3d6e9f8f946008455e9\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/types.fasl\"
       :FASL-MD5 \"45af9b0c08602d6120cc228849b628a9\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-boundary.fasl\"
       :FASL-MD5 \"0bb0ba114e8d4d261f0a092600e3fde6\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-package.fasl\"
       :FASL-MD5 \"b287506e0ac59014f9008509ce681aec\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-run.fasl\"
       :FASL-MD5 \"c942e5862a42b71d19bfc11673978f6e\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-types.fasl\"
       :FASL-MD5 \"c3e1c5fd79c8729657c7762fc678778f\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/compaction-scan.fasl\"
       :FASL-MD5 \"8e69627388f65c1773c4b7c92c40728b\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/control-payload.fasl\"
       :FASL-MD5 \"f0d45532cf2ca598f7163b634b4061ae\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/formats.fasl\"
       :FASL-MD5 \"cb8eb733dfd95c4beaf2e109d01cb61f\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/log-header.fasl\"
       :FASL-MD5 \"0ff539ab496c44a0cad42cd5fd505cd1\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/package.fasl\"
       :FASL-MD5 \"0929866f025ad8343cef909a0f13a7cf\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/payload-record.fasl\"
       :FASL-MD5 \"7dd0f4d7caf46480c531fb9645d2746f\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/payload-write.fasl\"
       :FASL-MD5 \"44e4c3e2ab9134892dcb9f7e34c6f58e\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/segment-header.fasl\"
       :FASL-MD5 \"76666b0082f158a7cfd7f7e97574ef57\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/wal/builder.fasl\"
       :FASL-MD5 \"b4ab461a345f3edb1c85e3c787a17697\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/wal/csn.fasl\"
       :FASL-MD5 \"fef96a2e1158628774c7f64ec0ba544c\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/wal/executor.fasl\"
       :FASL-MD5 \"a748c92bcf356fad0f8bc4aad47c9d4d\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/wal/group.fasl\"
       :FASL-MD5 \"0d1263f1dc91b02d35ed4d0a1b33fbcf\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/wal/package.fasl\"
       :FASL-MD5 \"704d9ae5b3fc6fe6f07f823aeadef59e\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/wal/types.fasl\"
       :FASL-MD5 \"2f48cfa18274f05a7c4e8764f05419c0\"))
     :COMPILED-SUITE
     ((:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/tests/foundation/support.fasl\"
       :FASL-MD5 \"3120a93248d7937fd2d9bc71bf809a5d\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/support.fasl\"
       :FASL-MD5 \"746a2ed2939c37e08d0af751a8a52781\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/construction.fasl\"
       :FASL-MD5 \"0cedbab583f31ee3d321dad9322ace3c\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/read.fasl\"
       :FASL-MD5 \"d480ab9f0133e4ab55bd0e9fb835e933\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/threads.fasl\"
       :FASL-MD5 \"b1b5c619ddeff19824588640d99a4ac8\"))
     :FAILED-TEST
     \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
     :PASSED-TESTS NIL :FAILURE-KIND :PRODUCT-CONDITION :CONDITION-TYPE
     \"INVARIANT-VIOLATION\" :DIAGNOSTIC \"ArcDocDB: DIRECTORY-LOCATION-ABSENT\"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . \"dd0d2a3ca3a6afb61b6623658d8eca74\") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . \"65ce18f4ca8502f65bf6ee411e9f5fe9\") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   \"bypass-closed-resolver\" :FILE \"src/get-directory/read.lisp\" :DIRECTORY
   #A((139) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/\")
   :EXPECTED-FAILURE :CANDIDATE-SIZE-AND-RESERVED-HIGH-BITS-NOT-CHECKED
   :SUBSTITUTION
   (:BEFORE
    \"(risolvi-candidato-get context (trova-mappa-directory-get context directory))\"
    :AFTER \"(let ((map (trova-mappa-directory-get context directory)))
    (values (mappa-segmento-get-segment map)
            (arcdocdb.get.resolver::mappa-segmento-get-end map) 0 nil))\")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   (\"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\") :SOURCE-MANIFEST
   ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . \"692a695f7129e0cc693cffb2983be35b\"))
    (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
    (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
    (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
    (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
    (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
    (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
    (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
    (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
    (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
    (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
    (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"62285b01dc017898fc16588b6522bbbf\"))
    (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
    (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
    (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
    (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
    (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
    (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
    (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
    (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
    (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
    (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
    (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
    (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
    (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
    (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
    (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
    (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
    (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
    (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
    (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
    (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
    (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
    (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
    (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
    (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
    (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
    (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
    (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
    (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
    (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
    (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
    (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
    (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
    (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
    (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
    (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
    (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
    (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
    (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"dde814f850eae82069c02ec9348edf34\"))
    (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
    (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
    (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
    (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
    (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
    (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
    (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
    (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
    (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
    (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
    (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
    (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
    (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
    (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
    (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
    (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
    (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
    (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
    (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
    (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
    (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
    (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
    (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
    (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
    (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
    (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
    (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
    (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
    (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
    (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
    (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
    (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
    (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
    (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
    (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
    (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
    (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
    (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
    (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
    (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
    (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
    (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
    (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
    (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
    (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
    (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
    (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
    (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
    (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
    (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
    (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
    (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
    (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
    (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
    (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
    (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
    (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
    (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
    (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
    (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
    (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
    (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
    (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
    (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
    (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
    (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
    (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
    (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
    (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
    (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
    (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
    (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
    (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
    (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
    (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
    (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
    (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
    (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
    (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
    (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
    (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
    (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
    (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
    (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
    (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
    (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
    (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
    (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
    (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
    (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
    (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
    (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
    (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
    (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
    (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
    (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
    (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
    (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
    (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
    (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
    (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
    (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
    (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
    (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
    (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
    (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
    (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
    (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
    (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
    (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
    (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
    (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
    (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
    (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
    (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
    (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
    (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
    (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
   :COMPILED-TARGET
   (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    \"dde814f850eae82069c02ec9348edf34\" :FASL
    \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/read.fasl\"
    :FASL-MD5 \"be6ac580dcc0e877e3f5abf31930db1f\")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    (\"sbcl\" \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--disable-debugger\"
     \"--script\" \"isolated-build.lisp\")
    :STDOUT-LOG
    #A((149) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/stdout.log\")
    :STDERR-LOG
    #A((149) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/stderr.log\")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 2267217/500000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/\"
     :SOURCE-MANIFEST
     ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
       \"692a695f7129e0cc693cffb2983be35b\")
      (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"62285b01dc017898fc16588b6522bbbf\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cde24b2bf5c5637d5501b95bed47df31\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"dde814f850eae82069c02ec9348edf34\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\")
      (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\"))
     :SUITE-FILES
     (\"tests/foundation/support.lisp\" \"tests/get-directory/support.lisp\"
      \"tests/get-directory/construction.lisp\" \"tests/get-directory/read.lisp\"
      \"tests/get-directory/threads.lisp\")
     :REGISTERED-TESTS
     (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
      \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
      \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
      \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
      \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
      \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
      \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
      \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
      \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
      \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
      \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
      \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
      \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
      \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
      \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
      \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
      \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
      \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
      \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
      \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
      \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
      \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
      \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
      \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
     :SELECTED-TEST \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"dde814f850eae82069c02ec9348edf34\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/read.fasl\"
      :FASL-MD5 \"be6ac580dcc0e877e3f5abf31930db1f\")
     :COMPILED-PRODUCT
     ((:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/build.fasl\"
       :FASL-MD5 \"f9a4ea9d11cf536806250c735b3b8aa2\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/clock.fasl\"
       :FASL-MD5 \"448142c936c105a50271e62e5bfc3ed3\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/core.fasl\"
       :FASL-MD5 \"20fec77ee56eba06b63666223b04a0f5\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/package.fasl\"
       :FASL-MD5 \"45c19b70003419fab44dd960224faa8d\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/read.fasl\"
       :FASL-MD5 \"d9230d3815330c2b5661d616e9e9ae99\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/types.fasl\"
       :FASL-MD5 \"6026405572a5425f910856d777b02c9e\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/write.fasl\"
       :FASL-MD5 \"7a3be93fddaa1e21cbe4762a9b8dc167\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-float-minimal.fasl\"
       :FASL-MD5 \"e18a11fa41488ed8fb796326e7d0afae\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-header.fasl\"
       :FASL-MD5 \"371ecfa3ed9f7e02510da5824cc9f430\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-minimal.fasl\"
       :FASL-MD5 \"71f3a46cc044426cb5e127bec8602588\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"62285b01dc017898fc16588b6522bbbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-package.fasl\"
       :FASL-MD5 \"d376330fb83f612df7ffe656873e6ba2\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-input.fasl\"
       :FASL-MD5 \"933a23f0953e3f5e7c8303e29005ea50\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-items.fasl\"
       :FASL-MD5 \"a45f7fe8e98a20fc9c557208b6869121\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-minimal.fasl\"
       :FASL-MD5 \"a013ef2c351d8679013a9a19219f19c8\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-stack.fasl\"
       :FASL-MD5 \"74788e4c5d4782289000a3d2a647919c\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan.fasl\"
       :FASL-MD5 \"4e6d46faf6176e2503e81c7c364b60bb\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-space.fasl\"
       :FASL-MD5 \"2c8a5a04e89e10c106aabf0a42062daa\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-string-write.fasl\"
       :FASL-MD5 \"d65e8fb16ff34ba176bdf558435f480d\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-write.fasl\"
       :FASL-MD5 \"bb4e3cf2ceb2586a271c1f7c86b48ce6\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/package.fasl\"
       :FASL-MD5 \"b4b6b29c07a052aaca3850385897b956\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/utf8.fasl\"
       :FASL-MD5 \"919b455f5c191b726afb934b2d62c754\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/csn/package.fasl\"
       :FASL-MD5 \"a3f94b83046d8ced32ec27d2033076e9\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/csn/registry.fasl\"
       :FASL-MD5 \"99925e6ac7a2a6aebd83e004ac4bf5f4\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/core.fasl\"
       :FASL-MD5 \"4798244441317ef86765e9719a8d81be\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/package.fasl\"
       :FASL-MD5 \"b6704f55f1e019c10516fedfe65b2978\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/read.fasl\"
       :FASL-MD5 \"8b789661feed7afa29aa853c17ff56a7\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/reclaim.fasl\"
       :FASL-MD5 \"829315b46f38176b5adf878c64772521\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/retire.fasl\"
       :FASL-MD5 \"f42a76f7403d1c9e5fef7ad83d399899\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/types.fasl\"
       :FASL-MD5 \"26bb2a1f225fb0abce8de286ad5d5719\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/handoff.fasl\"
       :FASL-MD5 \"af9db626683b62cb2cb063d9c287905b\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/package.fasl\"
       :FASL-MD5 \"fdd2b3b1e3db06dcfab6cd5b5de11f72\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/queue.fasl\"
       :FASL-MD5 \"d16c14e2defc88089a7a1f101034b37f\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/ready-recycle.fasl\"
       :FASL-MD5 \"a220cf9ab5fc0cdd9af8308f1b0dcbd8\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/ready-types.fasl\"
       :FASL-MD5 \"b15224f2e7fb1e4dd5786533b484d605\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/ready.fasl\"
       :FASL-MD5 \"a662c4a780c64b47c97ceb3e1f690385\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-boundary.fasl\"
       :FASL-MD5 \"f70f52d71574b59b649a90b1fdc3e9d3\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-claim.fasl\"
       :FASL-MD5 \"9ee34ec079e472ab97f4dce437a60487\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-run.fasl\"
       :FASL-MD5 \"9559776decb53e2fe99f5f4aad21a1a6\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-types.fasl\"
       :FASL-MD5 \"e5ec53275a0c55ec6bbf5a5cc3c70f75\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/writer.fasl\"
       :FASL-MD5 \"cbf5da87576f80796fe09704d694839b\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/batch.fasl\"
       :FASL-MD5 \"bc277b18ea70a38d8f807459dafd27b5\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/binary.fasl\"
       :FASL-MD5 \"760956279a0d114ddeb66b33584ce979\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/conditions.fasl\"
       :FASL-MD5 \"bc6a16082005e7569c86fba5ffed0e34\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/crc32c.fasl\"
       :FASL-MD5 \"260ebfaa7df9e1fed190fa540bbf7372\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/package.fasl\"
       :FASL-MD5 \"dcaf6f22595dd69b65b1759e871b6972\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/record.fasl\"
       :FASL-MD5 \"b469b1757dfc25b8123e7733353b4b61\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cde24b2bf5c5637d5501b95bed47df31\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/build.fasl\"
       :FASL-MD5 \"23495cf4d23eac7f2542e1ad49238d90\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/package.fasl\"
       :FASL-MD5 \"257ea95f41cdc8cb9ce99ebacbcd70a3\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"dde814f850eae82069c02ec9348edf34\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/read.fasl\"
       :FASL-MD5 \"be6ac580dcc0e877e3f5abf31930db1f\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/types.fasl\"
       :FASL-MD5 \"8b2ae79db1883effb047c033b3837e10\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-build.fasl\"
       :FASL-MD5 \"940af291941eaf99d455259e3843ec17\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-directory.fasl\"
       :FASL-MD5 \"201371df8bc3e0e3d733aaa6902b53ca\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-preflight.fasl\"
       :FASL-MD5 \"0115e615c12013afb78456dc69ba3356\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-read.fasl\"
       :FASL-MD5 \"ddbb444acb4a2a4e2ff1bf7c262beecd\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-scan.fasl\"
       :FASL-MD5 \"ed4c4d754988f8ebf74b7912e1654b70\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-types.fasl\"
       :FASL-MD5 \"b7cab690dd9818b37393cd5d12cd8d04\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/build.fasl\"
       :FASL-MD5 \"d1838f688d1ffb1b3c02603c14b8bb95\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/package.fasl\"
       :FASL-MD5 \"43420f0fc05de49f83fd8b15176a1527\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/read.fasl\"
       :FASL-MD5 \"2328727c8a1670643c7f8bd226a620d5\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/rows.fasl\"
       :FASL-MD5 \"c870370a7052c9154f3629c30eb0bf0f\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/scan.fasl\"
       :FASL-MD5 \"4f9e33600b9e43be5b4c710850cd2961\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/sort.fasl\"
       :FASL-MD5 \"1b1b5068498b9ec3bff88bec6b76c028\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/types.fasl\"
       :FASL-MD5 \"bae516ecc750c3fcb409f1c87c1b1f47\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/build.fasl\"
       :FASL-MD5 \"229fb82bf561dda848090cf0c5c618e7\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/lifecycle.fasl\"
       :FASL-MD5 \"2ef49093ec09727fc5131f677a816467\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/lookup.fasl\"
       :FASL-MD5 \"e190d727a25692f6732a22545d045c96\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/package.fasl\"
       :FASL-MD5 \"6f127d76e5217b9f3f703af401256149\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/segment.fasl\"
       :FASL-MD5 \"24f79df0cde8cf074c4c66cf51a489ec\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/target.fasl\"
       :FASL-MD5 \"83a6b5d6cb3744baf9d1660efc5dae7d\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/types.fasl\"
       :FASL-MD5 \"00f633ef3cce15189fb1e1456d34861e\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/arithmetic.fasl\"
       :FASL-MD5 \"383f003fb0b5c8704617c84681f73c2e\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/blocks.fasl\"
       :FASL-MD5 \"6d41c0a8364cdf752d2d61a7dabcc903\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/hash64.fasl\"
       :FASL-MD5 \"852091abad84be58321f2104c3437115\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/package.fasl\"
       :FASL-MD5 \"dfc632efeeaf6e0c6f16aa3a3a5a64bc\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/core.fasl\"
       :FASL-MD5 \"390a644b487c9d8b362aa0397e3c2530\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/hash-digests.fasl\"
       :FASL-MD5 \"c5a8e3d256ac8661ba71bcacf1ff2662\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/hash-seed.fasl\"
       :FASL-MD5 \"67c1825a3c6392fc91716395a4754bef\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/package.fasl\"
       :FASL-MD5 \"dbcb62d125f2ef6ebadf2f48b0b6c634\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-arena.fasl\"
       :FASL-MD5 \"7f3c287fbcad84440b0d6091e649c668\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-build.fasl\"
       :FASL-MD5 \"c9fe55f0a9971680627c67b42a1f87b8\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-core.fasl\"
       :FASL-MD5 \"28dad47976c59ab58df0973137a8f067\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-directory.fasl\"
       :FASL-MD5 \"686d29fd69a8f0a91fe95a653f10a46f\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-package.fasl\"
       :FASL-MD5 \"05ad034178c4b2991a7367eb6ed3e94a\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-probe.fasl\"
       :FASL-MD5 \"e580172116c98cd61dd47f74c28e8fa2\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-read.fasl\"
       :FASL-MD5 \"fa8135e67df1cb628d96a380455ddd68\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-relocate.fasl\"
       :FASL-MD5 \"31958fc508a336c646135da73f9bc253\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-types.fasl\"
       :FASL-MD5 \"26e4ad5480a38b2433b0d047c4c49690\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-write.fasl\"
       :FASL-MD5 \"586f7a1adc61b68c83a661ed80ffe9b5\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/read.fasl\"
       :FASL-MD5 \"33406936a90cb74b8e60f796714af350\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild-budget.fasl\"
       :FASL-MD5 \"8e7510cbf68538afc5f7087fcc5028fc\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild-copy.fasl\"
       :FASL-MD5 \"0fdb8b50d89893ec88bdc4f551628455\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild-scan.fasl\"
       :FASL-MD5 \"49f27df7e3897a485d3592ab2165cb7d\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild.fasl\"
       :FASL-MD5 \"04d33046c9703cce4b82c7935a0dd5c4\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/relocate.fasl\"
       :FASL-MD5 \"960a21ef7a47c7cfbae7bd6d3f39b2f5\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/types.fasl\"
       :FASL-MD5 \"95eaef7bcdd10842c02efd78f181c148\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/validation.fasl\"
       :FASL-MD5 \"c97f19652b5e5b5c1bc16c4ab9d81ea7\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/write.fasl\"
       :FASL-MD5 \"0f1637f06ebe6617838e486a6e91e77d\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/flush.fasl\"
       :FASL-MD5 \"541b315377f757960926af114aa1cde2\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/lifecycle.fasl\"
       :FASL-MD5 \"cd31c89a703467d878f1dc639f024a31\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/native.fasl\"
       :FASL-MD5 \"7a676356dacebb51bdea95a9aef0539a\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/package.fasl\"
       :FASL-MD5 \"1321f70e8bca179ffb68cde27e80cfb1\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/transfer.fasl\"
       :FASL-MD5 \"61358c87617fd914aa4d83cd32f911d8\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/types.fasl\"
       :FASL-MD5 \"7350e2172fac779e406fe101f80570cb\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/package.fasl\"
       :FASL-MD5 \"355df966a2b880566dfd2b9f3a28b0ad\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-core.fasl\"
       :FASL-MD5 \"7395928115a1f420ebfc65e10daad219\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-csn.fasl\"
       :FASL-MD5 \"af3c1dc2b2cd6fab858751db92ce9380\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-lifecycle.fasl\"
       :FASL-MD5 \"a655f70bfa3463522a91a7a3e6317900\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-read.fasl\"
       :FASL-MD5 \"f5a170002e5a0c4167bfa14f97b64189\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-register.fasl\"
       :FASL-MD5 \"0bf0bc7de0d29875a5ae832b91759039\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-types.fasl\"
       :FASL-MD5 \"1868dbdba01687b9a87af125a8b15aab\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/types.fasl\"
       :FASL-MD5 \"782aac66dbc449f5a170ff39876541e6\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/package.fasl\"
       :FASL-MD5 \"a84177886f3b773bf688ebe34c1a08e1\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/core.fasl\"
       :FASL-MD5 \"78b5c7c27fdf379cfcb9a27014c37bce\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/package.fasl\"
       :FASL-MD5 \"87a3e35537da90e02bf3258a7d2ce9b2\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/task.fasl\"
       :FASL-MD5 \"5d0ec11ddc730f89e0cd4222c281a3e3\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/types.fasl\"
       :FASL-MD5 \"47f0a537f46a27478411159876d40af9\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-build.fasl\"
       :FASL-MD5 \"3fc2e37a81831691bca26a45873081e8\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-package.fasl\"
       :FASL-MD5 \"dbe584fcb8c0fc8bd612e0d69dd0ab6b\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-query.fasl\"
       :FASL-MD5 \"c40b6f25d028feec6c0e7d5df96b44e5\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-radix.fasl\"
       :FASL-MD5 \"6c7aca897b819fbd9396d43ff26833a4\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-sort.fasl\"
       :FASL-MD5 \"673389554a3fe982b83d62a0527bf887\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-types.fasl\"
       :FASL-MD5 \"eac578ad5029ee154f86464712928537\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/inventory-build.fasl\"
       :FASL-MD5 \"99be414a5cb4e856b14744c26210e04d\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/inventory-query.fasl\"
       :FASL-MD5 \"f3e4b6008b1a81a557b868cfa321472c\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/inventory-types.fasl\"
       :FASL-MD5 \"7e935108b8d1799d4b8a063f636b1664\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-build.fasl\"
       :FASL-MD5 \"0cec1d7052aa03e0b7016c2e97536a00\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-decode.fasl\"
       :FASL-MD5 \"59e3183923476773107919037be32d6c\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-fold.fasl\"
       :FASL-MD5 \"6e17764abea4531ff7c5cf3782b08fc6\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-package.fasl\"
       :FASL-MD5 \"e14f38b7f1ae6a50252b176c6bd1391b\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-query.fasl\"
       :FASL-MD5 \"516513b3614ba6cc05514a5cdfd290fb\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-types.fasl\"
       :FASL-MD5 \"10831d8d3d21b8c69120eada74b3a7d9\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/package.fasl\"
       :FASL-MD5 \"094e43234dce0ec852493924fb72ca8f\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/scan.fasl\"
       :FASL-MD5 \"dc7f77fb788e016d2dd1286f7bdf606b\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/events.fasl\"
       :FASL-MD5 \"c1d08e11dfcb781e97007c6aefa6c84d\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/io-events.fasl\"
       :FASL-MD5 \"7929af5ea2a9a7c03845d889bb0eccd4\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/ownership.fasl\"
       :FASL-MD5 \"0e0766b3cceff4b492a7a4fdb8523812\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/package.fasl\"
       :FASL-MD5 \"6e102ed0a32643e5fce230bd54b0d824\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/publication.fasl\"
       :FASL-MD5 \"67db8cf29f626b2779fab9883e80a525\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/query.fasl\"
       :FASL-MD5 \"9cdff0baf70cf4733d8fdbeababf6d4c\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/retirement.fasl\"
       :FASL-MD5 \"28b39910ff5f425676634c32d058d962\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/routing-build.fasl\"
       :FASL-MD5 \"f4ecb41bd82a265c72b22b7eeee07725\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/routing-select.fasl\"
       :FASL-MD5 \"92ecb6af9ce6e3d291ab3ecbba1073f9\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/routing-types.fasl\"
       :FASL-MD5 \"f6325a5dbb5606f6b37f8afd89cfb8c0\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/types.fasl\"
       :FASL-MD5 \"93611c7f6abea2c11fdc92b83d76e969\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-boundary.fasl\"
       :FASL-MD5 \"3eafdfdef44c6055dc6164f5da9206ce\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-package.fasl\"
       :FASL-MD5 \"12461950f8f36e1f5eba847d2e8e3d80\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-run.fasl\"
       :FASL-MD5 \"f461e35de15127b7628bf395f8424054\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-types.fasl\"
       :FASL-MD5 \"9d211172d1ffff26f6cb6e776aeeebc1\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/compaction-scan.fasl\"
       :FASL-MD5 \"b5ff94abfec18b581e004060a68f00c3\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/control-payload.fasl\"
       :FASL-MD5 \"6fd6fdc3cd2e6068733934376db23e13\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/formats.fasl\"
       :FASL-MD5 \"d68ed08220dc98f094c7b6d51be2420e\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/log-header.fasl\"
       :FASL-MD5 \"aad06b529bb381991fb60c49315b6438\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/package.fasl\"
       :FASL-MD5 \"99a536a5abfd4ebda9dc3ad4ed0f9a6f\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/payload-record.fasl\"
       :FASL-MD5 \"2e36612064831738c3adc38f452946cf\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/payload-write.fasl\"
       :FASL-MD5 \"651253dd0af8154eefb7b40fdd4b72df\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/segment-header.fasl\"
       :FASL-MD5 \"54906cd82142821bf08d3ff9644369ef\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/builder.fasl\"
       :FASL-MD5 \"408b3c5d2540f8022c46a125dcb81f5b\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/csn.fasl\"
       :FASL-MD5 \"28041b4091c04f71393ebf97e120ed75\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/executor.fasl\"
       :FASL-MD5 \"42a37556b55d21b8829754bfd4d0df4a\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/group.fasl\"
       :FASL-MD5 \"4df068f003730122e23fe8eb2f929fdc\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/package.fasl\"
       :FASL-MD5 \"ffef9fcccf37555ebbfe2dedeccdde33\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/types.fasl\"
       :FASL-MD5 \"d8c53e1525d649a29b18b0b3cd5f5cac\"))
     :COMPILED-SUITE
     ((:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/tests/foundation/support.fasl\"
       :FASL-MD5 \"fc739ee43f3e3f44811a48a63a498eb3\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/support.fasl\"
       :FASL-MD5 \"e9bb328108301c1ce0dd82b6a5fee018\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/construction.fasl\"
       :FASL-MD5 \"4f70ee540a792db2201d60b3c449353c\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/read.fasl\"
       :FASL-MD5 \"77e61ce35426e350f470bc0de4f73d9a\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/threads.fasl\"
       :FASL-MD5 \"3b8118c1f013a028a962ba6c303c8d50\"))
     :FAILED-TEST \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
     :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE \"SIMPLE-ERROR\"
     :DIAGNOSTIC \"Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (ARCDOCDB.GET.DIRECTORY:RISOLVI-CANDIDATO-DIRECTORY-GET
                       ARCDOCDB.GET.DIRECTORY.TESTS::CONTEXT
                       (ARCDOCDB.GET.DIRECTORY.TESTS:DIRECTORY-FIXTURE-DIRECTORY
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVARIANT-VIOLATION (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :RESOLVER-CANDIDATE-SIZE)))\"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . \"c40df0a53fbe4c0249dc32ff2355cc82\") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . \"dde814f850eae82069c02ec9348edf34\") :ARTIFACTS-VERIFIED
   T))
 :COUNTERS
 (:DETECTED 5 :SURVIVED 0 :BASELINE-PASSED 1 :BASELINE-FAILED 0
  :COMPILATION-ERROR 0 :INFRASTRUCTURE-ERROR 0 :INVALID 0 :NOT-RUN 0 :PENDING
  0)
 :DETECTED 5 :SURVIVED 0 :COMPILATION-ERRORS 0 :INFRASTRUCTURE-ERRORS 0
 :INVALID-RESULTS 0 :SOURCE-CONSISTENCY :STABLE :LIMITS
 (:ONLY-DIRECTORY-BUILD-READ-MUTATED :CLOSED-ONLY
  :ONLY-DIRECTORY-SUITE-EXECUTED :FOUNDATION-SUPPORT-DEFINITIONS-ONLY
  :ALL-PRODUCT-SOURCES-COMPILED :FRESH-CHILD-PRIVATE-ASDF-OUTPUT
  :SOURCE-AND-FASL-MD5-ATTESTATION :ONE-NAMED-TEST-PER-MUTANT
  :ASSERTIONS-AND-PRODUCT-CONDITIONS-SEPARATED
  :COMPILER-FIXTURE-IO-TIMEOUT-CRASH-AND-TYPE-ERRORS-ARE-NOT-KILLS
  :PARTIAL-COPIES-AND-LOGS-RETAINED :BOUNDED-CLEANUP :NO-ENGINE-QUALIFICATION))
"
 :STDERR "" :EXIT-CODE 0 :LIMITS
 (:COMMAND-OUTPUT-IS-RAW :WALL-TIME-INCLUDES-ENTIRE-COMMAND
  :NO-AUTOMATIC-REQUIREMENT-PROMOTION))
