(:SOURCE-CONSISTENCY :STABLE :SOURCE-BLOBS-AFTER
 ((:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "0241da912be93fdf70b9a9749b759efc17aca329")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "30f2e951591f8822ce780f77cfa9c4ab93f0a98b")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "8f682f6ff22f6a0c1847b71be3994e628d399a77")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "d654f504cacdfbe7e144a074e0c2aba5ff2f4b31")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "b239b5187a2649125b7429273cb0fe4f4cba673b")
  (:PATH ".gitignore" :GIT-BLOB "19bf1ab91a6ed3c89cfff48070fb170b09679360")
  (:PATH "CHANGELOG.md" :GIT-BLOB "f5a971fd8121f6c30620f99f3831040b22b59a81")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bb642c10cc99a2a8d62cc101ec1c6e9903ec1441")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "5820eb0ee2f06bc024e238afe12106b0e74275dc")
  (:PATH "README.md" :GIT-BLOB "99958454de32ddbc01794b0817781c287cf4c0d6")
  (:PATH "SECURITY.md" :GIT-BLOB "27fb94691a84b389d72184838e38d2e43a8fcfbb")
  (:PATH "arcdocdb.asd" :GIT-BLOB "0a269c3ccc157009e7bb68936dfe727ce12e2940")
  (:PATH "assets/README.md" :GIT-BLOB
   "933cfee445a3fe85c8b9ca8c7c4e48afda9bdc95")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "0e9fe71b160f4ff7fcc61c9695159b00e352b12e")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "de51c5d5d625caf2ba89581880a7e932a86d2556")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "9ac19a17e0c095ed711eeb2a9da52b4965d3c481")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "b6dcf61865707b01724190e83c4987aa5d98762f")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "0c81882c35757d460e55f808fc6d2370f845550d")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "d65d5b12f248347430260c6671017a0894ebd3eb")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "2713de877ed961857868b53bcc346fe62088ec0e")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "b0e2afc520b8ea9a540f0605f682c1182b5af3ab")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "2e83c526df9864f1c3d2373fd313e4ea61d29fde")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "39cf33413347ccc9d91478efc1c08355908c23c9")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "3eab0ad4c56c1744c456579c8e773c5d7fe7493a")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "6616ed0cfadc71596ae3162affdef4f75f608de5")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "0f702230f39f3b4761886499d99b2eb431514908")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "07b5adf23d044b552d5e038adacf194774dfcf40")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "b92eea4011a182108002786370c8330e8271e356")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "db87b7732e2e42f22c711a89f5deae97f5f00757")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "1b845787d56dbc1296e7283f809e1be1bd0d3b80")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "826a6f1d12e37dd26893598caca3889010be7480")
  (:PATH "docs/README.md" :GIT-BLOB "303b4a009be18ad5f03ef990156ca0e145914fb2")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "88eeb77497b6d6124010ad65a71b98e08743131e")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "a4d7157123f6cad4b92d3722e136bd02f15fa138")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "fe20638b50dffc66f5d5b3497f00e5f526ea046a")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "2b9f1e16b289ec754c0ac0de79e7823852c4815a")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "4af05ad11f846d733b3485bfdabac47535f41415")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "ac6e1e0f042e6ce5622c0b579ff8d0419a707980")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "ad70fc5e177886b0be609ebc0234c0c7c2fbab90")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "7e6590a619252983120f8ef9b5b3fba5bf24659f")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "5ae6feb439b1d182febe27d16e6d485183150d6a")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "18de49d285e52d25e055397f47c829ba7db45500")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "2f04c342ca714f0638dfdf2bed17fe48de54edc9")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "1a86df3d58358950d8b658b6b8194563288fd0c8")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "99ca666f07f0f04168af74c55459ca76a6f421c7")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "3ca2df1c7beddedd65511d9282a547294cabbff4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "87931cd80f665581fc43a2b02fc6738ea3d57fb3")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "001950113b1fc347642e1939ef060d93a54096e5")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "5a442b2aeb665be3f23da887ff615bef889e167d")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "250c272e2ddaa4b062b956d5ab3eb66ce610b44a")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "be9686df1c7ecb762bebac602bab12010d73d0b9")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "6fff5ed7db6d11a51f12b167636b7a23a3750068")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "83c6cae3eb56b9edfda572533258d8438132e0ae")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "81823c873cf52abafd86a3e8ab35df2e161d1034")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "623209aef44929e1b8397b1f8470dffc20d9bbf8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "bc3d2144b30022e7ab239c561b6986a18e10ec8c")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "470ef1b7f52d571ea5af046ccf06896729a06a13")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "24235615cfaab3821cc38bc9b9979a9928c6dee9")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "8c29d6d4d55cbc7226c2df7361a3d7220c103f8f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "225aa16313ca4b54a04da07851f0824c2494543a")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "506080464430c1b9e5f2b09816d186ca95e3fcc9")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "328152db463a6e5796435ccd3867d8838429df15")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "b9dae81c93e124b6db129e90fb641c85ca349c93")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "dc8228d1c2dc5e01fa6a5cb6c69ec9e8648427d2")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "fc947bb28bdf5a015d7b353f56e0d6fb86a524c6")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "4646cd378729d3841b8419b3681477b4e1a80816")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "dfeef8dd42d465d1c97830bd6f8304d3f8579416")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "eb3138e9017cc95b7f71fb29ec3a21e4bc44a3c3")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "d4140bc0d14bee6ca7480e94fa96bd8c79e656fd")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "aadf427743cc9b511c4fac4952ec1335005b5568")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "fce6228c1a393557b2475a7600cc998246de97d0")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "c347b791cfa1e13319894e5c2a9c3c20527a7047")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "77640ef6687df0ba7a570b682000bd4b2fa042cc")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c571f195148361a34fa6bc9d1c6f35836742ab11")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "ba7550dfd1890a483f313610cadc808142bdddeb")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "1f07f3d9c4a9a1b6a0c1250dc09923966b2081d3")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "3ada528fa148db73ca09df933265ff82a5e0dd6b")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "75301c4284016be1da4f6f7a9e4b8a1c00b1fe8c")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2ebb221d1f2e8666fa62910f561728eb6ee0a9f3")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "4c11a9e20d9d7bf315bf7623740addd876019d77")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "f36aeeeab161774fce91906d1ba5d47e6b1a8636")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "47b35236825274bd340b61e4c30b7b38d8349d5a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "f393c09cc917be5e4a123befca7bdd3f238ad8eb")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "123524e58806fe8cee2727e5ada0b00561583a76")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "817f3f72a09e74d142b160bd8da172b459f327f9")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "0cb9800d4e89438f0ba2e9ecdf763245f0768196")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "83dd5fe0d9323805d7e97e6814129d16841efb80")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "c031db7bad8fa2f115938e3699e6ce01bc436bec")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "fdb928d6caf051a0341c162d537ca5d6351acfd9")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "61f400316607e9c47904680e6730c3034ba5897a")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "ebb3e21821c8b3d53a40a3bb6594b5c9ae20fc50")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "7800931fe3bc4c8204cd873ccc0ec8ed42af8b50")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "7028bc0b2b30b0ad17f9bbae81590519d3775e73")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "13ec9283f25316675f7bbbc2e95d80ed18469da1")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "80f4576d4e5afecdabdc3620771fc573e4ca9c4a")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "7137f05ec0a8e6cd345a00fda62be573855da3b4")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "2d883ca7e34a8b31f88930e0d266ec0a094e6b0a")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "29e3243150d1fe288caf2f5855cc5f7d19366130")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "00a1f025a375559acf548fb855c59d42e4a21642")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "173b91ac893a1bafe8d16ddb91b99dd6341c1a01")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c8182641591fa6f24bddedca56f92145a3c7a038")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "b8b2b37a18cb4d01815e07df5e64e763f273a9d0")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "325784adbb5cff4121559fd3d50a1ef943443434")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "bc95228574813d37b27882f24713e4d834788dd2")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "69bf38c64b527b5aeec011f9fe49d9fd3c31d253")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "9eb64c8428b638f6c0c1f0aaa80c4dbfd0f900b7")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "e39571136cad9d563a933aa608c011b887f17260")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "a83c5cc798dfb87750030781d015eeda260c4ac0")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "245f95c99a4735fd40a1d9694b4a5826f5ccb5d6")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "9f6526bf5c135cf43289127c4c1bc5dfdcbb8114")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "162cd32188a030d6cc3c5d16585054aa36055175")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "4af8109f8d01f1107791836371720802876ae775")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "2a9e7f0bf30460b3b7dbbbc1c7776c9259fe545d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "3935fc5225836a0669664701921ad1bfff3d443e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "8ba7e4ba06ca958c0be9a5e1128c63419aa7577a")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "a83375d3c09898353fc0173f3171884f92319d73")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "d379ed246db14204b7632b7b3c31266bfcd46b1e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "ba4d2ed61bf06d0504bb1e0067c8741ef45cc4e0")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "8966ac0cdf66fcefd616201cc97017d384b3f0a8")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "cd2f1ef9dfcd3f9029549430c21ec553509a62fc")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "81675040c1c6155f7e3efa669ca62ed4b8a63064")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "d8b22e42e7ab906488cef72d935b71d4a83ba499")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "6b4a59954e2d48cc30a044b57cfe43b0b91ae1e8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "7d44d58d7de6c62b2206a8e35be398bc34811663")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "9605de0679e062361f80c5654c5fbb8028765008")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "8b79dfa3b7cf5011b66534d02c2a4551232d503c")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "e9007f26d323a1ffd2993c461c3f84ad2aee90bc")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "a25b46457201e1a7885cc9b21cfb3e66267ec12c")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "a9e2e9dc6d0d4b968a9940d78abf8ca2de825e98")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "5d0aacab996dc47e2d479d505604d6eda5d42ea2")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "3ec66f8edebd79a128969e0b398e7700a2b1c5cd")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "46a0480b0bc29938f8654ce8f59cdaee5b720a4a")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e8864f7c0124f86cebdcdbcb2449800e078e1cc8")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "d276363cd59d6d1a914a6055b27edce016122323")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "94d950c644e849103eecb0d74c053df4aa1473dd")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "47cfd5c96e2150c42a2a7b716bef117090b0cd86")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "f5817e4d931148aa4f526b93066ab9d1b4bdf783")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "0a3a2123e618a8ff39e86dbbb70db36ccf51b133")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "2df0a214fc5cfe64ceb239aab4f7d2a2d1827305")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "1c1d617e19c0d74199ef11a56105d3ed90eb0ec0")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "56342dae95caf8705e0b28b3c0ea7ac86fdd8fa0")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "90bac509af0aff7b7085a2239de6e9dfddfc70ba")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "cbcfdba7c5967d5d36e5d9487f6a7b1ab0300a53")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "278d9413eab7578c99a07b1c614db37c83141097")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "8e1b0d0d6066669e1ffb65d95900a3b1aa385c51")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "c9808d48a01444ff6faddf2d8389673f91598db4")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "6b2909a5f56212947dea864584d2f96252fe1b1a")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "f0a2791f988b0d0c513629824f75ce1842fe059a")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "cebaf33e7e7cde4efbcbc2ada22fd494577c9e81")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "7b22c788ecf0d69f84316f39d2f580bfadb7b91f")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "76509dd8d44a61eff9129d08fb19c289d57fd1e8")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "93f1366c17eca13f37f63927d64779f7afeae658")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "a48d5b525d2c78fef0399666ebb14c6f8a2342e8")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "8dfa1cf8533764fdd89014f31cac59d02b248e2e")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "759b72a96a099d18fd353ef8936d63481e25129c")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "b28934a0a4eac77562b07fa8db796c167176ef36")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4a2c524c6b1c7be1c1b5d7e43d35d385ee7f5b1d")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "f6cadf13877cab21d869993f33e485f1af116806")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "8dbbd94b11ca62b266df8e1b58ef8b15487dde9f")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "2e1d7abdfe9b4880682ff1da97b526e180d01370")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "0264c59fce79fd2a9f34d05f85c8dfff5fed69be")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "a2a8d5bba2c3da3ad6977d6a6f750e468d229693")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "1aafc63fa8904a8504ec6fd42d34b606d6505677")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "ac23ebc4c1d6ab57116def02bf4ad7df115394d1")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "8fe4debab581640b3d1db74b6fa43610c8e547d2")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "a3d67947dafc891946df3ea19706d32d67b24a80")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "bc99cae302da8bb90c208cfc0d5def111e945269")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "79755fdc3fcc8cdc8459d0cf3d108d06e577bf3f")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "c3467fd1f58d977797821581ff127bfb2cfdd5cf")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "a0953cd3789ec80e22ec33f445510db6769ad2ed")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "4474e5ced93e129bae0ae13255e2c56363334f20")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "5f8fa54b5df938dc51ea2053298baa58413d7e5a")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "4434a2412cbcc6bab1bc5292331eb2c2eeabeb6a")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "ae05757ce562c9b2eb5632765cc9da4db8c2fe56")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "96a9d6be3614715a434ecfec5808375e06ff6468")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "a64f148cb2254e87c649bb16e7bee39aa45eb40d")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "a1631f582d8b3ecaa177cccead8c1e3d0051a822")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "a1adf2c6d8f6f13b0c583451ac732b439e58eda2")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "69e50510426fa53d230b64b89da9e64fdc5c6efa")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "542584f7ea490cc7b4639ee42969c17f52a8e559")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "204a995d2152620792e923275de5abcc5e29bfb3")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "efdcf79210060603b8b7982057933f7b57a3c220")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "ee84732af73d4d753b211bd9cd33f9c7dd1d2a3f")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "3932b391102e3b7e0ead521a1fb223ef5ca2129a")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "058623adabd6a98f7d7617c4c1ac4fd0b7bce825")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "30f47c1882108bc0c2180c5e51a67b4ad23eee11")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "acc39ebcd47f56d31d5ddcf9843ebf8543424f22")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "a6b480a9726002150f65443b9a3c97c9039f2012")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "c799f6cd5399c37daa1687cd0d154ebcfac2cb39")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "d9de17c5fcd7e7f21555c68db8f3eaa7d7e1b158")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "b7c4c84c6d688015a43f81b476e58744fbf5d467")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "f103ded38e6cb575820d7fb89d72e47b9fc16693")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "d09dc4f0914935805770cf148cfab99b1ca30eb1")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "ac29588884b2f12f2bd67a72f04504d88c2d44a0")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "d4382b97ee69a12235f4c1d445b9b13dd5440684")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "4dc9aa9bdfdd5e21a2ef2bf6ab6fc8d2e111a586")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "c88785115dfda86f3e6ce425487638fe514f0e3b")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "1950d3f3b38736f7d32e1c3a24fb217bd1dffc86")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "a220b68f94b35c81b9bca4420453c4057eded097")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "37ff4f5316483960508fa78df1f890ebaff8942e")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "27cb98d6bf753515b880d7b09e8069302a0e72d2")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "476e35fca8858a4a4eed163e4a3a42c7ce38bd4a")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "550c69493fdb363631b83dea4fff765119b6ad5f")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "04674e8a8b7434d1008a0e62176db98fe54e0ac0")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "656e8162bd3833268a6243e136c2e46b39e548f5")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "f779f81d41748e3e9b10596dc9af12b334d4dc23")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "f755abc620aaad10470143418702e883baf2493a")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "6b39b77b28e576610308a9d98e540df64e28555d")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "cb473b09149385d5d32bb44db1478e5ba7da7640")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "23966839673d2e5931f1822c0c2e0302a189911a")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "1b746fefc25d8cd1be1bb44611c7ac5f98e8acb1")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "c451a24e86e98a2dd3a75cfbae55260625b33dc8")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "096b16489aa910182fe01349aa5552ccc1ccd446")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "f77e4acc65f3582d76bee6867e7a728757a98d4c")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "b6c4a6992ef5ca707c19e08dfbdc7d1e01e1e900")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "6fbe1f002e3e18df09a964292f27c3657bb46004")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "b275c083f9705d1ed32b4cf282fd0c12c39d98a2")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "3c2423f187253e7c2c83b3848c7efbd43d269641")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "c7780a6798cec4964badc6a5529508898ae4945c")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "bbc3431b5872adfdee0e23d566caf7d2172a971a")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "8101b2da12ae1a60a0663b11ab70590a96c5bcf2")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "99cf34e5c5c3875ed97414c30ec9b7bef96d30b4")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "0a534e557a3fe8216e0d5fbfc84c354255d081ac")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "d17e9e45a1d4896249d11f2bd474aa05af5222cb")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "805c6b231d9fd7223ef1b149e75e9c3be0dd0859")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "d6e2ad12c278d5bb26050c056df4342671c590f5")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "77d0c406a967ebe97f81781f9dd4cc9d68488ee4")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "1798cdf9b8916ba74b21d1d86442a49874938e41")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "bc3121e6274d610f56155a1e159d0a8948ee87c5")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "73bfef0b478f57c9441a6d0e2ab59c0e7f223fef")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "89a767f226693292d6a934970010d6dc5f13bbe7")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "d7e1f6e6fd5baa3c0c345507b8c3cd7a71e47f33")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "497b96ba252c1d223b91c7a958af3a1de6e6bba9")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "4b9535873216af6a4ede0b3d6d31e80c466ad395")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "6c46cebd54cacfe7b366932d1be6bd2132346087")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "c9ec2a33ac47f9811f152032cc6232fb1ccb941a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "9cfa2d91655890f50c7a0d83cb14f0bbae650f21")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "08c866115be68fd9e88c2d30fd111017851bbb53")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "df02aed3cd659b1b09e746d8315f54e32f526965")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "2d2ffb30c9051c58fd7f9b7efb27a487d1c0fd8e")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "76b2e79d012ebffcdde4477af9b19fb2e1e54e67")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "7e470b27c01de9fbfb4d4b532136760ec18afdad")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "5f0636cde6711769dc13bdaabefb55e6af843147")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "f6eb25d050854b65daa7766d203b3e177dbc8f4a")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "04f64ce2d33e27cc5d40482765223aa6dec062ea")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "e4fa3bae3e265d1ca702c1ecc6aa8e44c676155e")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "f76d0c995da17ae17ef8ccc6c68a3045ea461a73")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "a92e30d229b4d76f6220a96ded2c46f4054544a4")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "c04cfa11a0b9edaf4b73a251845690cdbb3ee98c")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "caafe0a8685e4faf2215bebe5f37fd1a80683f93")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "1f01809c914084c4773dd184439d1cf599710f09")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "ef2ed1ac671dec6c7904174152fdd90dd03c4589")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "dfd353b4f7544d41a04d916abdb4a0aedaac2c3d")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "b94583da79c1834c306118ebcc013c795b286ce1")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "4d6ff67e6e78c550986e2e953ed8a9a5d8b4ee20")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "db7e38f078621af681d9b5e523f4c91bf4801c6d")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ffd1c9ac47dcab5ab8c1c0301c0c04c3e2686b6e")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "01109f06ce875665dffb11263b80f68a2d3c07ba")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "3249fbcd44f2f2e76a14195461a3a4e43b3031ec")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "a12ac9c53969f6755c8cb0de21212f06e7e03e4b")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "f500b01def047de7973851144c8196036abf36bb")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "2e58b4d0e459495430a6cd1e9540994d8a25a0da")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "f134e4c3c3cfda195b324e7bb362948b67aa1fd5")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "5ebf0d1098584b8ea8dd380b92a9b913980f2285")
  (:PATH "docs/limiti.md" :GIT-BLOB "dd24577016d7a14379ebbbc35a1e86a0d23a4295")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "4bd3d55870e1b05b12a4a2287de6b5186f2d3b5d")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "f27f1e9ecbf711aaa240bb7697f6b06f553bac2f")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "2b56cf1d8636aede273e4cd12165ec78a6ba73f0")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "742c9309d02efe4238c859a3a7c6cd577240cdf2")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "70d45ea89536739989e90f7815ed8e89fc1544c6")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "59aa701b8d0752437db3360aec4551ad6bc9cb0d")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "19223d1767a6b7eebb9636d99cea7d898560cbd2")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "2004d712f3755c501fd2b506b8f729ce6297707e")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "c5b7d4f08337ce5b0fa7096b872e21ca8c94462e")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "2709ceddf253b8a53c7726f2fcf33fc0c8d2ecff")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "2ed70c7629bc15b9b7803135fa000168ca818cbe")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "989474478f9330b3f8d731cc34c190c229850217")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "cac1621bcd068d757ea86d25ce1da1d5d1f254e9")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "0fa9272a2986414342a107ae4c1e5fbde3720958")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "9647505f8a2ae9cf74348487e9648a6c0dd5d252")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "25d94d78061e6c68007e4316aca4cdc60f9de610")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "a95cb4392328411d9f17c334c149d9c029535102")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "679e74cf6c8051dd57ea1f2fa0584c46aaef47e2")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "e8af15a00e7178168116c0138027e820c07e598c")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "139d030b0125b61aad567263b7b7db95e830e927")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "108872e995b0def43475138c76e11fdb5d578ceb")
  (:PATH "spikes/README.md" :GIT-BLOB
   "14250504c27c786cd83174a7cca53bf273af2125")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "81c46b7e0a82ca474857d5e5de01dc43c0572bf1")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "1683f3951361ad60dea42821451a4bea35147b6c")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "19840c3a15271323546259e5c0aafd7d13489681")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "54a1982bd08ac27197c3266bb2f883aab405f705")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "f7d9674884267ad4d22f962c762e1995b749fb44")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "f8480d84bb8e932e0a17719c779ea54709c3c3f4")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "1c6ae01e442bd3c4d8c829006647aaa59ae1a185")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "91732544806c231b77dcbddc9a2e4460a12873ec")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "16ebc31ba682d36cf3520086d43f35a310159bec")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "e5d56bb99d2bae3867cacd19d18711f35e6ff8db")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "2eca7df2fd82994b4ad13ff58f72ab5efb9edc3a")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "ea4feea4edb0e4a1dd7ad357419b6bf97b415f50")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "51be4a3beb85262d453bd6b283a3b31378615fe7")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "f23f9ecd889437c83c946c88f2bf56a45a73f3ab")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "bbeac271ff79f96c0f69d22c60a045a4bfec8f09")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "9d97ed258355e5afd21edfc1820ee6d68137a02c")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "729f3500b4f427612b39c02f210c4ac25f45c805")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "a6bd28dd37f149b2b47cedfdbbb7b4c11fa1bf6d")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "648bd776767e4be914a2470069afced14bc1c1e5")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "a813fbeb55cd03980b2215c99fc3170d6afa4d92")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "a05614fee1df43315393f048efbbfe9a948bee9c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "6b3bc87d5700e52ca6b861fa562c2b7958248887")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "9e9121e124a6af86e9ccb8a253f69e1db584e873")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "e6b80fa0165026cd1a89c58786ec35d240bdc6c5")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "a1fdf6705a10fcca3926f40e26051fe7b6df5bf0")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "5755794e6b6afeed6f00a698cb337cf4b18730a4")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "cb5452eab513ddab4db6eb2955603a0c133d4e77")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "8c83b0067a0481759f14733e3c60ca888c6d01d8")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69fb5930c2722871c30056b41c13f7919058bfcb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "b5cc04cfdf8ff989a5eb6081dd100f8c506b081d")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "e3ebc7594ca6b1ae269579e5e9c7f9fef1b14300")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "45255a912edb4300b1f22c9505d09be5177d1d4b")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "5aca4d48de7bf0d849eafe87ae89f6e7800282d8")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9ab280c17b61b8f98f8299cbfae676942bb3ae47")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "5f4f08a4609bd264fa058ec25ba8f6a516c162c8")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "b335ea1d241672a3989da65b9a7ec516e7533347")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "bcd7de80241f809dcfce472741f120a61ac787b4")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "ca6215b30010d3d2eb90eaa6fd09dd5a9ac7778f")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "db635a50678f2712ec9516be335717ea254d4d09")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "761302dad1073c841397f6c88d595b114af8d9ef")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "0a75ef778c3d5ea490ec0a61f11bf6c65a3183ee")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "57ffc48cc688a4de8ebec5cb14c1e69c4209704a")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "70272936e323b3e0cb05173c9fb68cb2b614c355")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "f1afe79c7a4d49abd6a6e5f6975dec830ef7b1f6")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "c574e87af5e195ddf3f596a4ae527e69c7a3c6a6")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "e3d7d77407046338d23e26eb0b8a2e8fdc3d699d")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "58c7a3a040ec814fae2dfe636f569b5623cba8f0")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "a8330e50a77b52a6b9044ebbb48f62bb4b3222a3")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a2c5c77dd51bff760bff4508e998d94370921eda")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "61f0d6e2783e4790ed7e19a45bba6407d6e5b3de")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "807939c0fbc5d149bc7c8c1e29c7864ef7be991d")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "26726c45555ae8490e0dff31f61f70735183acc7")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "9eb660cca8f097e25ca3c1535cace8c20bc1e238")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "80cb600f6c6d724cf1eaec25c3d2742c8c320906")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "9388a84a1beb35cfa2bf016471389c881ad38628")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "a3dfde4a4780554b88e6e037ab4f70731f9c884a")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "57235763cf556ecd7633a0052f265ce3eb2b0462")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "f0f1cd22e87892119a4b7768b4efe5e519925dff")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "909dfdbc901c4cbdeae5b47faf52480350372524")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "34c8add62a6df92446be5234ef013893ebcf6879")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "bb4d4d6f222aa360ec64ef2f45ee6ba0524dd2f0")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "58981c7e41ce2694dbfcaed99010a3a53e3c1dea")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "5b3c26f78d5c4aa53ca200abdd3e0f753f926b54")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "4119f86231b7d8698fc3558868ff8a5bcbdf3090")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "720f16e96203f00e308727b430b66b28689dc7bb")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "4f34d18152d77fbf63bf708ebd0aabac178c3ac1")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "65a3f3c9e84c83b900c1dd8c9cc2fc21cec36c52")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "6d36e1f64d79f24c95209fd70551953e40c62335")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8e5102497f628796fa8faffa2085a165496af230")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "2cbd40c539b13dd80070eedf4af82bd1b26f4b28")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "2d514f6fe2e81eecb29fa53de611fa5e28696904")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "edbe5eaa88c50dc13af8e367b73f7f41fd7bd724")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "f9c691d28620427099d1d89a89a1ff5d04cbe257")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "bca6808e75e144ac7e9643df07a1cc6df4f70ed3")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "09185339cab38ab937045b40c52bb1b9092ffb8e")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "f1a1a37ccd59a81e7ff91fcb36009d5953d7edd5")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "951e5efdd1977c18a5bd90a1e4b3199d60e92d38")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "1d93461227b222a8effc53ec9344c5dab0b531fe")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "ec99839d234468298b553e331873a320c8ece53f")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "14bb99d6529c3d741f60472d2c3e822dbb0f590e")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "70341c7c32b364603d38bdc42e8b3af1cc631773")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "bd75d3a4b7483900689417ae3eb2dd65e76c8468")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "49bbcd30fdf96963702148cd675d5d3066189309")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "5ae454c03e8a9b9196653c8b28df0727e480d142")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "17e5ad4e2206e280c3f7324adc5c8a1e50e232e0")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "956b6c7145a25dc64a7247f2e14321876ac08f15")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "55028dae42a3ce1050d6872665c3c3ba6aa3f74d")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1177496e5baca7f7c698156e196c60fe1fe2566a")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "e1bf83fbcc737b55eaa71bd6b41a912a901178ce")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "6f54751adb255f49582ff1da62f951965c3860a1")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "9cbbdb6200af813bc9595d0ef964628a9ba0368f")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "53438f156d3e1e15f3732ec840223231b308a7a5")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "cb426426eac6e923224bc57c1dd602405f4bc040")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "23f16c3039b71be0bd46d6bf92f05791e444683e")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "5a105a141b43f5585f8e79c2965d59e96cd35ac6")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "cf168c44bfe5aedd2e34180ce4f766a6a89500a7")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "c9b8488d0a1aa7643a6ab1570765ec870aa7c9e4")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "032ad088b19ec3498a7c80a5e4b96d7777257dad")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "0d8e799b889df829aeb46054ef100377845dd0e0")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "f115b63c6089960e9857469475f821f3035a5ef2")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "6d43b042d7d9018f8aa48e88fc58c24b5a089cdf")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "a83ee5a2d8903538f8ba977ef0f5ddbe3a357d6b")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "6d05b467aee412f447308eb697daa7f4f5ec6f0d")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "5627b4179b115c008379aa3e60a4724e63f9657b")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "20de8a35a4deaa830348a6db5b5bb033a82c81d2")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "aa80e1b0b6af77379cfe2f2bd12c0b17e5c6851b")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "20d4b57b2a7c4b9f11205e753b92301f74f56cfc")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "1d7969c842b1f9a4cd0b9eba2ea3496cf914a2c4")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "aacbb9975ad3795d848c4523d178af31d34aa7b2")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "f36b55b9e2d9002ed2ce203a0289c92984c89ac9")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "b5b8243bc40b44af8c34ba76a5ab732675690af5")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "2282593c0a431f3f73fb47cdfc7a8e530e704ce7")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "b8009b8313054c9abebb70de8f8223fb1df708f3")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "5db1d132d91fa11be2b2624ed4c0c8d5405ce591")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "abfdeb5397f8be1d390cbdf47f4f02cd2f36bf91")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "77df997ef72008e7758899a348ae07695bce0b38")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "8555e14347d05182c99b756a312207019e2f904f")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "79d794b102c3ebf50679426e7cebbf49f02683ce")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "321ae3d1fdcda8e34efbdaac4b10dfc08fe9d9a5")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "012c8cff2c265aa7f0daa909a9a0dd01adf7ca3b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "3c7cd919b94dd9458422143c18075dd7498fda1f")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "a8088783354d2e4e5048d6ac7a3bee7afff92719")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "80156ca526a341c845fc43fc9963097f8669e65a")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "ba31b07379219fa8fd80fca169d43a053d28063b")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "0b93448ffe9c6dd4f3a0a2f3f35d5cd656700bd7")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "1b6fe64ea7145f33bcf08c02e8550034ebd6a40c")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "6b840a0eb039afa7e55304bffba309f0ab72acdc")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "93acbd608b1af475aa505a6a7dedceb3b15e8d4b")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "b496c1df87108127da568a1fb7b0fd32856afcc5")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "01875b76743c514ef07346a32587f4dc5c34d2f8")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "48372f6f09a54cfcee793ac03ec321fca6ad18f5")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "25d93efc7c604042d09dc84e31baf1f4e2c4c45e")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "09d73425a6e571c8fac6669b14b98e3ceeb7c96b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "c9cadaabf755add3671cd1cc0408c3ff216df2a5")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "bf80277418243422144cf6ee71eef83d7eff6da5")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "3d0181717e3f334580bab9a6a507e2dfe57261ff")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "132e44c138e209d3f8840b098cca0424853d09c3")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "b3601060197a27c6e8a2aaee22b5576c6b0c6e5a")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "b30795fb7efad5f5313198d345ffabb43249e3fa")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "87cc54024e59757c16e20f3025970b1699b11662")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "878fd1afdcbf035a232166ef87066af4420e1aae")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "a6ce94b8be3c8c84043abfd6441599f9780b2c11")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "e58176890a26751bf5767582b279cb667a29744e")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "b133ea00a3b8063e9e934a1b41f10cad024471ae")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "0dbb2b3bdfbf5447a5904ce0fa6e4a97337a6827")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "60057f6a50c657f016bee3c21c21911b582f86fe")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47810fb2944b4b5c18d9a9c8e60dfdc1c5f19db4")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "68c357d2d522fcabe79284c540c2631e5fa87780")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "e74b806f5116db46f3a385821515c317b2dcb452")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "ae5b8e4677fdd1dcee2f2a1baf293f49d9ce2972")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "eaddc83c63dce2fde59227e0416917bbc766e325")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "5405bd515df8b26b792bd0430c9ec3dbadce63e7")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "55e56d621129d1637eac1a787bad60dd0f0405b1")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "e062c804e68a8f62eddadd5c87db0e7af392744f")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "7ad6b7541397611f1ecbda7dffdda98c4453dbf1")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "63fb4a20faeedceb47b8cd550262f1bdca497c06")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "128fe9650a741541b46d1ad0887b872cb2e85012")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "7352a27581b8e2e68407611e65e46773efdc333c")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "0cccb1f1b9bb8f63a308352d64426a420bd1e283")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "48a789494e731732ae0b378347e133d50daacfe4")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "7f91ca22b7f2f339b450db0f4c26c97f86906c58")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "fc42b51a0f8606687881e239ba650a9f1bb58124")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "6fbe5e4720187be3bcada2dcc9fc40026267da07")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "f280c35e8f7ed283d30e8f4a43bbf2f172600816")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "e350df4e2fdc2f651ffbdb136bdbb266ccafcb1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "a0def7fc9452d291e2e60dbeff26a56a2b06e3a3")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "acc9f6ea83a8ef2774b41bdb114165b6bfb54949")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "02c219d556a8cd807a0e322667dfb401d8b06fb6")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "39f28974f3fae098d32d4ad1a056a45b06f777a6")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "233556c366a99b7b263af1c7bc19b47ceaebf940")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "7980cac6cc8070836b9aa49fc8a0d6fb42630749")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "fc942f1c8e30e637abaf13dc26343d40417fc72f")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "fde8608e6ad3fe062937c48bdcb7d2d5870207bf")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0012eaf90064c4cc2949834a60e83c9db8ba6308")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "6cbbb89f681965173e9b1b95edf3f7f870af1eca")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "f1d99b205b1ea5e6ad059ecd7971d3633411b040")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "6d30698383477880c693954314bab03ca8affe24")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "f65662b4dea8ef04e4e59ce38b29a94fecea4f6c")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "edc8ce7474365e0885925d557a378779655d2e70")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "8245bc10cedafbff8665489fbced6833f078a373")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "ad1b1356eeb10248526f15ac31d2cc9b59811fc5")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "10c4b1949994d01cb9ed231f66a69cf81f1ea062")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "56318b1632a7a0ae11f2987cdf0d4bec68e465cb")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "e613ea025c2a886cdae7fd5e119cf80593c6b72e")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "10979b4a89af0b00d48abbc7bf6760afc3b5aa9b")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "a7bee65793fc3a3e0c89c9c73871d7c183669a3e")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "5a7f38de22be659787305441b65c689de4bd6dba")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "43c4b1ffe8c3dee1a37e9f7b07f655ec3959896b")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "3624e1dde5f5a484a117f4c783d4e6b88027cc89")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "720d80c6dd5a962dc724835c1421635ba289b7ef")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "878f0fa10825ae3d49e9cac2f94d9992c06f2d20")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "dc9ea34945c3a8c52d5c62062951674d27becd5a")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "4212f8cc4be686e923cdbec9ded24f42f1da74ba")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ff6df200a7ace3af204b622969a387ce7a1e1504")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "24543b1595fbd12972e7073680fde062337b8417")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "51351fe8bb7b748fdbd7e8af9efdff1a8fa9eb56")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "0f706343bab19794f90df89400b1e94aead1db38")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "3cea6b1438f8ef7095726c592a991028e203da32")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "55b8fabbec5c66417e16b34caa5f73b0f24b1e46")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "13b367549c38c5fff1b826944df658ad1ee0a7c3")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "8d0ed3547f0dd71e7d74af31ce0ded585d7bb436")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "f2209f6ba53f7140069b42151995bfe312907561")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "93a40af0b228460656d9ad48f4c123e7b6c842d3")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "362141c30925f7bb8a3936743454326ddc510dbe")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "559faf78f736ae6b4d1770cc70ee5204c45a4896")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "fd285d0ae73d312d7234a2a142d16897c9adbcf7")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "be5fc283b3c06bc60548ea32c240ebf8d9ecafc2")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "4e84645950948a15caf27e4f9c5f18fa030efcd0")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "2e7364821e345b8b8714856a6a2f03c684140320")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "9421994e3c9883b423f6f17311d1b26c094ee991")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :WALL-SECONDS 39.849455d0 :FINISHED-AT-UNIVERSAL-TIME 4000716425
 :SCHEMA-VERSION 1 :KIND :COMMAND-VERIFICATION :ENVIRONMENT
 (:LISP #A((4) BASE-CHAR . "SBCL") :VERSION #A((5) BASE-CHAR . "2.6.9") :OS
  #A((6) BASE-CHAR . "Darwin") :OS-VERSION #A((6) BASE-CHAR . "27.0.0")
  :MACHINE #A((5) BASE-CHAR . "ARM64") :CPU "Apple M4" :MEMORY-BYTES
  17179869184 :LOGICAL-CPUS 10 :EXTERNAL-LOAD-STATUS :UNCONTROLLED
  :LOAD-AVERAGE "{ 20.34 11.47 8.24 }" :COMMIT
  "7a9158e7b9aaec01fbca1beec6d7c8c724573456" :WORKING-TREE
  "?? spikes/results/2026-10-11-get-directory/assemble-manifest.lisp" :CWD
  #A((61) BASE-CHAR
     . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/")
  :DATE-UNIVERSAL-TIME 4000716387)
 :COMMAND
 (#A((4) BASE-CHAR . "sbcl") #A((10) BASE-CHAR . "--noinform")
  #A((13) BASE-CHAR . "--no-userinit") #A((12) BASE-CHAR . "--no-sysinit")
  #A((8) BASE-CHAR . "--script")
  #A((33) BASE-CHAR . "tools/get-directory-mutation.lisp")
  #A((7) BASE-CHAR . "--check")
  #A((37) BASE-CHAR . "spikes/out/get-directory-mutations-g/"))
 :STATUS :OK :STARTED-AT-UNIVERSAL-TIME 4000716387 :SOURCE-BLOBS-BEFORE
 ((:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "0241da912be93fdf70b9a9749b759efc17aca329")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "30f2e951591f8822ce780f77cfa9c4ab93f0a98b")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "8f682f6ff22f6a0c1847b71be3994e628d399a77")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "d654f504cacdfbe7e144a074e0c2aba5ff2f4b31")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "b239b5187a2649125b7429273cb0fe4f4cba673b")
  (:PATH ".gitignore" :GIT-BLOB "19bf1ab91a6ed3c89cfff48070fb170b09679360")
  (:PATH "CHANGELOG.md" :GIT-BLOB "f5a971fd8121f6c30620f99f3831040b22b59a81")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bb642c10cc99a2a8d62cc101ec1c6e9903ec1441")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "5820eb0ee2f06bc024e238afe12106b0e74275dc")
  (:PATH "README.md" :GIT-BLOB "99958454de32ddbc01794b0817781c287cf4c0d6")
  (:PATH "SECURITY.md" :GIT-BLOB "27fb94691a84b389d72184838e38d2e43a8fcfbb")
  (:PATH "arcdocdb.asd" :GIT-BLOB "0a269c3ccc157009e7bb68936dfe727ce12e2940")
  (:PATH "assets/README.md" :GIT-BLOB
   "933cfee445a3fe85c8b9ca8c7c4e48afda9bdc95")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "0e9fe71b160f4ff7fcc61c9695159b00e352b12e")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "de51c5d5d625caf2ba89581880a7e932a86d2556")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "9ac19a17e0c095ed711eeb2a9da52b4965d3c481")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "b6dcf61865707b01724190e83c4987aa5d98762f")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "0c81882c35757d460e55f808fc6d2370f845550d")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "d65d5b12f248347430260c6671017a0894ebd3eb")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "2713de877ed961857868b53bcc346fe62088ec0e")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "b0e2afc520b8ea9a540f0605f682c1182b5af3ab")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "2e83c526df9864f1c3d2373fd313e4ea61d29fde")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "39cf33413347ccc9d91478efc1c08355908c23c9")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "3eab0ad4c56c1744c456579c8e773c5d7fe7493a")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "6616ed0cfadc71596ae3162affdef4f75f608de5")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "0f702230f39f3b4761886499d99b2eb431514908")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "07b5adf23d044b552d5e038adacf194774dfcf40")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "b92eea4011a182108002786370c8330e8271e356")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "db87b7732e2e42f22c711a89f5deae97f5f00757")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "1b845787d56dbc1296e7283f809e1be1bd0d3b80")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "826a6f1d12e37dd26893598caca3889010be7480")
  (:PATH "docs/README.md" :GIT-BLOB "303b4a009be18ad5f03ef990156ca0e145914fb2")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "88eeb77497b6d6124010ad65a71b98e08743131e")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "a4d7157123f6cad4b92d3722e136bd02f15fa138")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "fe20638b50dffc66f5d5b3497f00e5f526ea046a")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "2b9f1e16b289ec754c0ac0de79e7823852c4815a")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "4af05ad11f846d733b3485bfdabac47535f41415")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "ac6e1e0f042e6ce5622c0b579ff8d0419a707980")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "ad70fc5e177886b0be609ebc0234c0c7c2fbab90")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "7e6590a619252983120f8ef9b5b3fba5bf24659f")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "5ae6feb439b1d182febe27d16e6d485183150d6a")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "18de49d285e52d25e055397f47c829ba7db45500")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "2f04c342ca714f0638dfdf2bed17fe48de54edc9")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "1a86df3d58358950d8b658b6b8194563288fd0c8")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "99ca666f07f0f04168af74c55459ca76a6f421c7")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "3ca2df1c7beddedd65511d9282a547294cabbff4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "87931cd80f665581fc43a2b02fc6738ea3d57fb3")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "001950113b1fc347642e1939ef060d93a54096e5")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "5a442b2aeb665be3f23da887ff615bef889e167d")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "250c272e2ddaa4b062b956d5ab3eb66ce610b44a")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "be9686df1c7ecb762bebac602bab12010d73d0b9")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "6fff5ed7db6d11a51f12b167636b7a23a3750068")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "83c6cae3eb56b9edfda572533258d8438132e0ae")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "81823c873cf52abafd86a3e8ab35df2e161d1034")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "623209aef44929e1b8397b1f8470dffc20d9bbf8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "bc3d2144b30022e7ab239c561b6986a18e10ec8c")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "470ef1b7f52d571ea5af046ccf06896729a06a13")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "24235615cfaab3821cc38bc9b9979a9928c6dee9")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "8c29d6d4d55cbc7226c2df7361a3d7220c103f8f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "225aa16313ca4b54a04da07851f0824c2494543a")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "506080464430c1b9e5f2b09816d186ca95e3fcc9")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "328152db463a6e5796435ccd3867d8838429df15")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "b9dae81c93e124b6db129e90fb641c85ca349c93")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "dc8228d1c2dc5e01fa6a5cb6c69ec9e8648427d2")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "fc947bb28bdf5a015d7b353f56e0d6fb86a524c6")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "4646cd378729d3841b8419b3681477b4e1a80816")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "dfeef8dd42d465d1c97830bd6f8304d3f8579416")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "eb3138e9017cc95b7f71fb29ec3a21e4bc44a3c3")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "d4140bc0d14bee6ca7480e94fa96bd8c79e656fd")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "aadf427743cc9b511c4fac4952ec1335005b5568")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "fce6228c1a393557b2475a7600cc998246de97d0")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "c347b791cfa1e13319894e5c2a9c3c20527a7047")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "77640ef6687df0ba7a570b682000bd4b2fa042cc")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c571f195148361a34fa6bc9d1c6f35836742ab11")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "ba7550dfd1890a483f313610cadc808142bdddeb")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "1f07f3d9c4a9a1b6a0c1250dc09923966b2081d3")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "3ada528fa148db73ca09df933265ff82a5e0dd6b")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "75301c4284016be1da4f6f7a9e4b8a1c00b1fe8c")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2ebb221d1f2e8666fa62910f561728eb6ee0a9f3")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "4c11a9e20d9d7bf315bf7623740addd876019d77")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "f36aeeeab161774fce91906d1ba5d47e6b1a8636")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "47b35236825274bd340b61e4c30b7b38d8349d5a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "f393c09cc917be5e4a123befca7bdd3f238ad8eb")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "123524e58806fe8cee2727e5ada0b00561583a76")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "817f3f72a09e74d142b160bd8da172b459f327f9")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "0cb9800d4e89438f0ba2e9ecdf763245f0768196")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "83dd5fe0d9323805d7e97e6814129d16841efb80")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "c031db7bad8fa2f115938e3699e6ce01bc436bec")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "fdb928d6caf051a0341c162d537ca5d6351acfd9")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "61f400316607e9c47904680e6730c3034ba5897a")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "ebb3e21821c8b3d53a40a3bb6594b5c9ae20fc50")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "7800931fe3bc4c8204cd873ccc0ec8ed42af8b50")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "7028bc0b2b30b0ad17f9bbae81590519d3775e73")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "13ec9283f25316675f7bbbc2e95d80ed18469da1")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "80f4576d4e5afecdabdc3620771fc573e4ca9c4a")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "7137f05ec0a8e6cd345a00fda62be573855da3b4")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "2d883ca7e34a8b31f88930e0d266ec0a094e6b0a")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "29e3243150d1fe288caf2f5855cc5f7d19366130")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "00a1f025a375559acf548fb855c59d42e4a21642")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "173b91ac893a1bafe8d16ddb91b99dd6341c1a01")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c8182641591fa6f24bddedca56f92145a3c7a038")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "b8b2b37a18cb4d01815e07df5e64e763f273a9d0")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "325784adbb5cff4121559fd3d50a1ef943443434")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "bc95228574813d37b27882f24713e4d834788dd2")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "69bf38c64b527b5aeec011f9fe49d9fd3c31d253")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "9eb64c8428b638f6c0c1f0aaa80c4dbfd0f900b7")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "e39571136cad9d563a933aa608c011b887f17260")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "a83c5cc798dfb87750030781d015eeda260c4ac0")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "245f95c99a4735fd40a1d9694b4a5826f5ccb5d6")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "9f6526bf5c135cf43289127c4c1bc5dfdcbb8114")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "162cd32188a030d6cc3c5d16585054aa36055175")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "4af8109f8d01f1107791836371720802876ae775")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "2a9e7f0bf30460b3b7dbbbc1c7776c9259fe545d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "3935fc5225836a0669664701921ad1bfff3d443e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "8ba7e4ba06ca958c0be9a5e1128c63419aa7577a")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "a83375d3c09898353fc0173f3171884f92319d73")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "d379ed246db14204b7632b7b3c31266bfcd46b1e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "ba4d2ed61bf06d0504bb1e0067c8741ef45cc4e0")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "8966ac0cdf66fcefd616201cc97017d384b3f0a8")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "cd2f1ef9dfcd3f9029549430c21ec553509a62fc")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "81675040c1c6155f7e3efa669ca62ed4b8a63064")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "d8b22e42e7ab906488cef72d935b71d4a83ba499")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "6b4a59954e2d48cc30a044b57cfe43b0b91ae1e8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "7d44d58d7de6c62b2206a8e35be398bc34811663")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "9605de0679e062361f80c5654c5fbb8028765008")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "8b79dfa3b7cf5011b66534d02c2a4551232d503c")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "e9007f26d323a1ffd2993c461c3f84ad2aee90bc")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "a25b46457201e1a7885cc9b21cfb3e66267ec12c")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "a9e2e9dc6d0d4b968a9940d78abf8ca2de825e98")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "5d0aacab996dc47e2d479d505604d6eda5d42ea2")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "3ec66f8edebd79a128969e0b398e7700a2b1c5cd")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "46a0480b0bc29938f8654ce8f59cdaee5b720a4a")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e8864f7c0124f86cebdcdbcb2449800e078e1cc8")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "d276363cd59d6d1a914a6055b27edce016122323")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "94d950c644e849103eecb0d74c053df4aa1473dd")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "47cfd5c96e2150c42a2a7b716bef117090b0cd86")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "f5817e4d931148aa4f526b93066ab9d1b4bdf783")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "0a3a2123e618a8ff39e86dbbb70db36ccf51b133")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "2df0a214fc5cfe64ceb239aab4f7d2a2d1827305")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "1c1d617e19c0d74199ef11a56105d3ed90eb0ec0")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "56342dae95caf8705e0b28b3c0ea7ac86fdd8fa0")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "90bac509af0aff7b7085a2239de6e9dfddfc70ba")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "cbcfdba7c5967d5d36e5d9487f6a7b1ab0300a53")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "278d9413eab7578c99a07b1c614db37c83141097")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "8e1b0d0d6066669e1ffb65d95900a3b1aa385c51")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "c9808d48a01444ff6faddf2d8389673f91598db4")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "6b2909a5f56212947dea864584d2f96252fe1b1a")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "f0a2791f988b0d0c513629824f75ce1842fe059a")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "cebaf33e7e7cde4efbcbc2ada22fd494577c9e81")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "7b22c788ecf0d69f84316f39d2f580bfadb7b91f")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "76509dd8d44a61eff9129d08fb19c289d57fd1e8")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "93f1366c17eca13f37f63927d64779f7afeae658")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "a48d5b525d2c78fef0399666ebb14c6f8a2342e8")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "8dfa1cf8533764fdd89014f31cac59d02b248e2e")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "759b72a96a099d18fd353ef8936d63481e25129c")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "b28934a0a4eac77562b07fa8db796c167176ef36")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4a2c524c6b1c7be1c1b5d7e43d35d385ee7f5b1d")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "f6cadf13877cab21d869993f33e485f1af116806")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "8dbbd94b11ca62b266df8e1b58ef8b15487dde9f")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "2e1d7abdfe9b4880682ff1da97b526e180d01370")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "0264c59fce79fd2a9f34d05f85c8dfff5fed69be")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "a2a8d5bba2c3da3ad6977d6a6f750e468d229693")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "1aafc63fa8904a8504ec6fd42d34b606d6505677")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "ac23ebc4c1d6ab57116def02bf4ad7df115394d1")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "8fe4debab581640b3d1db74b6fa43610c8e547d2")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "a3d67947dafc891946df3ea19706d32d67b24a80")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "bc99cae302da8bb90c208cfc0d5def111e945269")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "79755fdc3fcc8cdc8459d0cf3d108d06e577bf3f")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "c3467fd1f58d977797821581ff127bfb2cfdd5cf")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "a0953cd3789ec80e22ec33f445510db6769ad2ed")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "4474e5ced93e129bae0ae13255e2c56363334f20")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "5f8fa54b5df938dc51ea2053298baa58413d7e5a")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "4434a2412cbcc6bab1bc5292331eb2c2eeabeb6a")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "ae05757ce562c9b2eb5632765cc9da4db8c2fe56")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "96a9d6be3614715a434ecfec5808375e06ff6468")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "a64f148cb2254e87c649bb16e7bee39aa45eb40d")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "a1631f582d8b3ecaa177cccead8c1e3d0051a822")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "a1adf2c6d8f6f13b0c583451ac732b439e58eda2")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "69e50510426fa53d230b64b89da9e64fdc5c6efa")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "542584f7ea490cc7b4639ee42969c17f52a8e559")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "204a995d2152620792e923275de5abcc5e29bfb3")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "efdcf79210060603b8b7982057933f7b57a3c220")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "ee84732af73d4d753b211bd9cd33f9c7dd1d2a3f")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "3932b391102e3b7e0ead521a1fb223ef5ca2129a")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "058623adabd6a98f7d7617c4c1ac4fd0b7bce825")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "30f47c1882108bc0c2180c5e51a67b4ad23eee11")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "acc39ebcd47f56d31d5ddcf9843ebf8543424f22")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "a6b480a9726002150f65443b9a3c97c9039f2012")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "c799f6cd5399c37daa1687cd0d154ebcfac2cb39")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "d9de17c5fcd7e7f21555c68db8f3eaa7d7e1b158")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "b7c4c84c6d688015a43f81b476e58744fbf5d467")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "f103ded38e6cb575820d7fb89d72e47b9fc16693")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "d09dc4f0914935805770cf148cfab99b1ca30eb1")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "ac29588884b2f12f2bd67a72f04504d88c2d44a0")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "d4382b97ee69a12235f4c1d445b9b13dd5440684")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "4dc9aa9bdfdd5e21a2ef2bf6ab6fc8d2e111a586")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "c88785115dfda86f3e6ce425487638fe514f0e3b")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "1950d3f3b38736f7d32e1c3a24fb217bd1dffc86")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "a220b68f94b35c81b9bca4420453c4057eded097")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "37ff4f5316483960508fa78df1f890ebaff8942e")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "27cb98d6bf753515b880d7b09e8069302a0e72d2")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "476e35fca8858a4a4eed163e4a3a42c7ce38bd4a")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "550c69493fdb363631b83dea4fff765119b6ad5f")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "04674e8a8b7434d1008a0e62176db98fe54e0ac0")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "656e8162bd3833268a6243e136c2e46b39e548f5")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "f779f81d41748e3e9b10596dc9af12b334d4dc23")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "f755abc620aaad10470143418702e883baf2493a")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "6b39b77b28e576610308a9d98e540df64e28555d")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "cb473b09149385d5d32bb44db1478e5ba7da7640")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "23966839673d2e5931f1822c0c2e0302a189911a")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "1b746fefc25d8cd1be1bb44611c7ac5f98e8acb1")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "c451a24e86e98a2dd3a75cfbae55260625b33dc8")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "096b16489aa910182fe01349aa5552ccc1ccd446")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "f77e4acc65f3582d76bee6867e7a728757a98d4c")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "b6c4a6992ef5ca707c19e08dfbdc7d1e01e1e900")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "6fbe1f002e3e18df09a964292f27c3657bb46004")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "b275c083f9705d1ed32b4cf282fd0c12c39d98a2")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "3c2423f187253e7c2c83b3848c7efbd43d269641")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "c7780a6798cec4964badc6a5529508898ae4945c")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "bbc3431b5872adfdee0e23d566caf7d2172a971a")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "8101b2da12ae1a60a0663b11ab70590a96c5bcf2")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "99cf34e5c5c3875ed97414c30ec9b7bef96d30b4")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "0a534e557a3fe8216e0d5fbfc84c354255d081ac")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "d17e9e45a1d4896249d11f2bd474aa05af5222cb")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "805c6b231d9fd7223ef1b149e75e9c3be0dd0859")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "d6e2ad12c278d5bb26050c056df4342671c590f5")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "77d0c406a967ebe97f81781f9dd4cc9d68488ee4")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "1798cdf9b8916ba74b21d1d86442a49874938e41")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "bc3121e6274d610f56155a1e159d0a8948ee87c5")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "73bfef0b478f57c9441a6d0e2ab59c0e7f223fef")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "89a767f226693292d6a934970010d6dc5f13bbe7")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "d7e1f6e6fd5baa3c0c345507b8c3cd7a71e47f33")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "497b96ba252c1d223b91c7a958af3a1de6e6bba9")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "4b9535873216af6a4ede0b3d6d31e80c466ad395")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "6c46cebd54cacfe7b366932d1be6bd2132346087")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "c9ec2a33ac47f9811f152032cc6232fb1ccb941a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "9cfa2d91655890f50c7a0d83cb14f0bbae650f21")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "08c866115be68fd9e88c2d30fd111017851bbb53")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "df02aed3cd659b1b09e746d8315f54e32f526965")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "2d2ffb30c9051c58fd7f9b7efb27a487d1c0fd8e")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "76b2e79d012ebffcdde4477af9b19fb2e1e54e67")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "7e470b27c01de9fbfb4d4b532136760ec18afdad")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "5f0636cde6711769dc13bdaabefb55e6af843147")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "f6eb25d050854b65daa7766d203b3e177dbc8f4a")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "04f64ce2d33e27cc5d40482765223aa6dec062ea")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "e4fa3bae3e265d1ca702c1ecc6aa8e44c676155e")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "f76d0c995da17ae17ef8ccc6c68a3045ea461a73")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "a92e30d229b4d76f6220a96ded2c46f4054544a4")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "c04cfa11a0b9edaf4b73a251845690cdbb3ee98c")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "caafe0a8685e4faf2215bebe5f37fd1a80683f93")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "1f01809c914084c4773dd184439d1cf599710f09")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "ef2ed1ac671dec6c7904174152fdd90dd03c4589")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "dfd353b4f7544d41a04d916abdb4a0aedaac2c3d")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "b94583da79c1834c306118ebcc013c795b286ce1")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "4d6ff67e6e78c550986e2e953ed8a9a5d8b4ee20")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "db7e38f078621af681d9b5e523f4c91bf4801c6d")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ffd1c9ac47dcab5ab8c1c0301c0c04c3e2686b6e")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "01109f06ce875665dffb11263b80f68a2d3c07ba")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "3249fbcd44f2f2e76a14195461a3a4e43b3031ec")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "a12ac9c53969f6755c8cb0de21212f06e7e03e4b")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "f500b01def047de7973851144c8196036abf36bb")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "2e58b4d0e459495430a6cd1e9540994d8a25a0da")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "f134e4c3c3cfda195b324e7bb362948b67aa1fd5")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "5ebf0d1098584b8ea8dd380b92a9b913980f2285")
  (:PATH "docs/limiti.md" :GIT-BLOB "dd24577016d7a14379ebbbc35a1e86a0d23a4295")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "4bd3d55870e1b05b12a4a2287de6b5186f2d3b5d")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "f27f1e9ecbf711aaa240bb7697f6b06f553bac2f")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "2b56cf1d8636aede273e4cd12165ec78a6ba73f0")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "742c9309d02efe4238c859a3a7c6cd577240cdf2")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "70d45ea89536739989e90f7815ed8e89fc1544c6")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "59aa701b8d0752437db3360aec4551ad6bc9cb0d")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "19223d1767a6b7eebb9636d99cea7d898560cbd2")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "2004d712f3755c501fd2b506b8f729ce6297707e")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "c5b7d4f08337ce5b0fa7096b872e21ca8c94462e")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "2709ceddf253b8a53c7726f2fcf33fc0c8d2ecff")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "2ed70c7629bc15b9b7803135fa000168ca818cbe")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "989474478f9330b3f8d731cc34c190c229850217")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "cac1621bcd068d757ea86d25ce1da1d5d1f254e9")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "0fa9272a2986414342a107ae4c1e5fbde3720958")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "9647505f8a2ae9cf74348487e9648a6c0dd5d252")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "25d94d78061e6c68007e4316aca4cdc60f9de610")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "a95cb4392328411d9f17c334c149d9c029535102")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "679e74cf6c8051dd57ea1f2fa0584c46aaef47e2")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "e8af15a00e7178168116c0138027e820c07e598c")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "139d030b0125b61aad567263b7b7db95e830e927")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "108872e995b0def43475138c76e11fdb5d578ceb")
  (:PATH "spikes/README.md" :GIT-BLOB
   "14250504c27c786cd83174a7cca53bf273af2125")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "81c46b7e0a82ca474857d5e5de01dc43c0572bf1")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "1683f3951361ad60dea42821451a4bea35147b6c")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "19840c3a15271323546259e5c0aafd7d13489681")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "54a1982bd08ac27197c3266bb2f883aab405f705")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "f7d9674884267ad4d22f962c762e1995b749fb44")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "f8480d84bb8e932e0a17719c779ea54709c3c3f4")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "1c6ae01e442bd3c4d8c829006647aaa59ae1a185")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "91732544806c231b77dcbddc9a2e4460a12873ec")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "16ebc31ba682d36cf3520086d43f35a310159bec")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "e5d56bb99d2bae3867cacd19d18711f35e6ff8db")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "2eca7df2fd82994b4ad13ff58f72ab5efb9edc3a")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "ea4feea4edb0e4a1dd7ad357419b6bf97b415f50")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "51be4a3beb85262d453bd6b283a3b31378615fe7")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "f23f9ecd889437c83c946c88f2bf56a45a73f3ab")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "bbeac271ff79f96c0f69d22c60a045a4bfec8f09")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "9d97ed258355e5afd21edfc1820ee6d68137a02c")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "729f3500b4f427612b39c02f210c4ac25f45c805")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "a6bd28dd37f149b2b47cedfdbbb7b4c11fa1bf6d")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "648bd776767e4be914a2470069afced14bc1c1e5")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "a813fbeb55cd03980b2215c99fc3170d6afa4d92")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "a05614fee1df43315393f048efbbfe9a948bee9c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "6b3bc87d5700e52ca6b861fa562c2b7958248887")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "9e9121e124a6af86e9ccb8a253f69e1db584e873")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "e6b80fa0165026cd1a89c58786ec35d240bdc6c5")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "a1fdf6705a10fcca3926f40e26051fe7b6df5bf0")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "5755794e6b6afeed6f00a698cb337cf4b18730a4")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "cb5452eab513ddab4db6eb2955603a0c133d4e77")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "8c83b0067a0481759f14733e3c60ca888c6d01d8")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69fb5930c2722871c30056b41c13f7919058bfcb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "b5cc04cfdf8ff989a5eb6081dd100f8c506b081d")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "e3ebc7594ca6b1ae269579e5e9c7f9fef1b14300")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "45255a912edb4300b1f22c9505d09be5177d1d4b")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "5aca4d48de7bf0d849eafe87ae89f6e7800282d8")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9ab280c17b61b8f98f8299cbfae676942bb3ae47")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "5f4f08a4609bd264fa058ec25ba8f6a516c162c8")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "b335ea1d241672a3989da65b9a7ec516e7533347")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "bcd7de80241f809dcfce472741f120a61ac787b4")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "ca6215b30010d3d2eb90eaa6fd09dd5a9ac7778f")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "db635a50678f2712ec9516be335717ea254d4d09")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "761302dad1073c841397f6c88d595b114af8d9ef")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "0a75ef778c3d5ea490ec0a61f11bf6c65a3183ee")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "57ffc48cc688a4de8ebec5cb14c1e69c4209704a")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "70272936e323b3e0cb05173c9fb68cb2b614c355")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "f1afe79c7a4d49abd6a6e5f6975dec830ef7b1f6")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "c574e87af5e195ddf3f596a4ae527e69c7a3c6a6")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "e3d7d77407046338d23e26eb0b8a2e8fdc3d699d")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "58c7a3a040ec814fae2dfe636f569b5623cba8f0")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "a8330e50a77b52a6b9044ebbb48f62bb4b3222a3")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a2c5c77dd51bff760bff4508e998d94370921eda")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "61f0d6e2783e4790ed7e19a45bba6407d6e5b3de")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "807939c0fbc5d149bc7c8c1e29c7864ef7be991d")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "26726c45555ae8490e0dff31f61f70735183acc7")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "9eb660cca8f097e25ca3c1535cace8c20bc1e238")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "80cb600f6c6d724cf1eaec25c3d2742c8c320906")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "9388a84a1beb35cfa2bf016471389c881ad38628")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "a3dfde4a4780554b88e6e037ab4f70731f9c884a")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "57235763cf556ecd7633a0052f265ce3eb2b0462")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "f0f1cd22e87892119a4b7768b4efe5e519925dff")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "909dfdbc901c4cbdeae5b47faf52480350372524")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "34c8add62a6df92446be5234ef013893ebcf6879")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "bb4d4d6f222aa360ec64ef2f45ee6ba0524dd2f0")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "58981c7e41ce2694dbfcaed99010a3a53e3c1dea")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "5b3c26f78d5c4aa53ca200abdd3e0f753f926b54")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "4119f86231b7d8698fc3558868ff8a5bcbdf3090")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "720f16e96203f00e308727b430b66b28689dc7bb")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "4f34d18152d77fbf63bf708ebd0aabac178c3ac1")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "65a3f3c9e84c83b900c1dd8c9cc2fc21cec36c52")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "6d36e1f64d79f24c95209fd70551953e40c62335")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8e5102497f628796fa8faffa2085a165496af230")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "2cbd40c539b13dd80070eedf4af82bd1b26f4b28")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "2d514f6fe2e81eecb29fa53de611fa5e28696904")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "edbe5eaa88c50dc13af8e367b73f7f41fd7bd724")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "f9c691d28620427099d1d89a89a1ff5d04cbe257")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "bca6808e75e144ac7e9643df07a1cc6df4f70ed3")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "09185339cab38ab937045b40c52bb1b9092ffb8e")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "f1a1a37ccd59a81e7ff91fcb36009d5953d7edd5")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "951e5efdd1977c18a5bd90a1e4b3199d60e92d38")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "1d93461227b222a8effc53ec9344c5dab0b531fe")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "ec99839d234468298b553e331873a320c8ece53f")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "14bb99d6529c3d741f60472d2c3e822dbb0f590e")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "70341c7c32b364603d38bdc42e8b3af1cc631773")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "bd75d3a4b7483900689417ae3eb2dd65e76c8468")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "49bbcd30fdf96963702148cd675d5d3066189309")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "5ae454c03e8a9b9196653c8b28df0727e480d142")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "17e5ad4e2206e280c3f7324adc5c8a1e50e232e0")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "956b6c7145a25dc64a7247f2e14321876ac08f15")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "55028dae42a3ce1050d6872665c3c3ba6aa3f74d")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1177496e5baca7f7c698156e196c60fe1fe2566a")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "e1bf83fbcc737b55eaa71bd6b41a912a901178ce")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "6f54751adb255f49582ff1da62f951965c3860a1")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "9cbbdb6200af813bc9595d0ef964628a9ba0368f")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "53438f156d3e1e15f3732ec840223231b308a7a5")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "cb426426eac6e923224bc57c1dd602405f4bc040")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "23f16c3039b71be0bd46d6bf92f05791e444683e")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "5a105a141b43f5585f8e79c2965d59e96cd35ac6")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "cf168c44bfe5aedd2e34180ce4f766a6a89500a7")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "c9b8488d0a1aa7643a6ab1570765ec870aa7c9e4")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "032ad088b19ec3498a7c80a5e4b96d7777257dad")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "0d8e799b889df829aeb46054ef100377845dd0e0")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "f115b63c6089960e9857469475f821f3035a5ef2")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "6d43b042d7d9018f8aa48e88fc58c24b5a089cdf")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "a83ee5a2d8903538f8ba977ef0f5ddbe3a357d6b")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "6d05b467aee412f447308eb697daa7f4f5ec6f0d")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "5627b4179b115c008379aa3e60a4724e63f9657b")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "20de8a35a4deaa830348a6db5b5bb033a82c81d2")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "aa80e1b0b6af77379cfe2f2bd12c0b17e5c6851b")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "20d4b57b2a7c4b9f11205e753b92301f74f56cfc")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "1d7969c842b1f9a4cd0b9eba2ea3496cf914a2c4")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "aacbb9975ad3795d848c4523d178af31d34aa7b2")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "f36b55b9e2d9002ed2ce203a0289c92984c89ac9")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "b5b8243bc40b44af8c34ba76a5ab732675690af5")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "2282593c0a431f3f73fb47cdfc7a8e530e704ce7")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "b8009b8313054c9abebb70de8f8223fb1df708f3")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "5db1d132d91fa11be2b2624ed4c0c8d5405ce591")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "abfdeb5397f8be1d390cbdf47f4f02cd2f36bf91")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "77df997ef72008e7758899a348ae07695bce0b38")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "8555e14347d05182c99b756a312207019e2f904f")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "79d794b102c3ebf50679426e7cebbf49f02683ce")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "321ae3d1fdcda8e34efbdaac4b10dfc08fe9d9a5")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "012c8cff2c265aa7f0daa909a9a0dd01adf7ca3b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "3c7cd919b94dd9458422143c18075dd7498fda1f")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "a8088783354d2e4e5048d6ac7a3bee7afff92719")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "80156ca526a341c845fc43fc9963097f8669e65a")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "ba31b07379219fa8fd80fca169d43a053d28063b")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "0b93448ffe9c6dd4f3a0a2f3f35d5cd656700bd7")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "1b6fe64ea7145f33bcf08c02e8550034ebd6a40c")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "6b840a0eb039afa7e55304bffba309f0ab72acdc")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "93acbd608b1af475aa505a6a7dedceb3b15e8d4b")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "b496c1df87108127da568a1fb7b0fd32856afcc5")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "01875b76743c514ef07346a32587f4dc5c34d2f8")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "48372f6f09a54cfcee793ac03ec321fca6ad18f5")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "25d93efc7c604042d09dc84e31baf1f4e2c4c45e")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "09d73425a6e571c8fac6669b14b98e3ceeb7c96b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "c9cadaabf755add3671cd1cc0408c3ff216df2a5")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "bf80277418243422144cf6ee71eef83d7eff6da5")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "3d0181717e3f334580bab9a6a507e2dfe57261ff")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "132e44c138e209d3f8840b098cca0424853d09c3")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "b3601060197a27c6e8a2aaee22b5576c6b0c6e5a")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "b30795fb7efad5f5313198d345ffabb43249e3fa")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "87cc54024e59757c16e20f3025970b1699b11662")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "878fd1afdcbf035a232166ef87066af4420e1aae")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "a6ce94b8be3c8c84043abfd6441599f9780b2c11")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "e58176890a26751bf5767582b279cb667a29744e")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "b133ea00a3b8063e9e934a1b41f10cad024471ae")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "0dbb2b3bdfbf5447a5904ce0fa6e4a97337a6827")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "60057f6a50c657f016bee3c21c21911b582f86fe")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47810fb2944b4b5c18d9a9c8e60dfdc1c5f19db4")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "68c357d2d522fcabe79284c540c2631e5fa87780")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "e74b806f5116db46f3a385821515c317b2dcb452")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "ae5b8e4677fdd1dcee2f2a1baf293f49d9ce2972")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "eaddc83c63dce2fde59227e0416917bbc766e325")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "5405bd515df8b26b792bd0430c9ec3dbadce63e7")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "55e56d621129d1637eac1a787bad60dd0f0405b1")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "e062c804e68a8f62eddadd5c87db0e7af392744f")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "7ad6b7541397611f1ecbda7dffdda98c4453dbf1")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "63fb4a20faeedceb47b8cd550262f1bdca497c06")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "128fe9650a741541b46d1ad0887b872cb2e85012")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "7352a27581b8e2e68407611e65e46773efdc333c")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "0cccb1f1b9bb8f63a308352d64426a420bd1e283")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "48a789494e731732ae0b378347e133d50daacfe4")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "7f91ca22b7f2f339b450db0f4c26c97f86906c58")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "fc42b51a0f8606687881e239ba650a9f1bb58124")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "6fbe5e4720187be3bcada2dcc9fc40026267da07")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "f280c35e8f7ed283d30e8f4a43bbf2f172600816")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "e350df4e2fdc2f651ffbdb136bdbb266ccafcb1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "a0def7fc9452d291e2e60dbeff26a56a2b06e3a3")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "acc9f6ea83a8ef2774b41bdb114165b6bfb54949")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "02c219d556a8cd807a0e322667dfb401d8b06fb6")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "39f28974f3fae098d32d4ad1a056a45b06f777a6")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "233556c366a99b7b263af1c7bc19b47ceaebf940")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "7980cac6cc8070836b9aa49fc8a0d6fb42630749")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "fc942f1c8e30e637abaf13dc26343d40417fc72f")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "fde8608e6ad3fe062937c48bdcb7d2d5870207bf")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0012eaf90064c4cc2949834a60e83c9db8ba6308")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "6cbbb89f681965173e9b1b95edf3f7f870af1eca")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "f1d99b205b1ea5e6ad059ecd7971d3633411b040")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "6d30698383477880c693954314bab03ca8affe24")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "f65662b4dea8ef04e4e59ce38b29a94fecea4f6c")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "edc8ce7474365e0885925d557a378779655d2e70")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "8245bc10cedafbff8665489fbced6833f078a373")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "ad1b1356eeb10248526f15ac31d2cc9b59811fc5")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "10c4b1949994d01cb9ed231f66a69cf81f1ea062")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "56318b1632a7a0ae11f2987cdf0d4bec68e465cb")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "e613ea025c2a886cdae7fd5e119cf80593c6b72e")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "10979b4a89af0b00d48abbc7bf6760afc3b5aa9b")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "a7bee65793fc3a3e0c89c9c73871d7c183669a3e")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "5a7f38de22be659787305441b65c689de4bd6dba")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "43c4b1ffe8c3dee1a37e9f7b07f655ec3959896b")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "3624e1dde5f5a484a117f4c783d4e6b88027cc89")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "720d80c6dd5a962dc724835c1421635ba289b7ef")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "878f0fa10825ae3d49e9cac2f94d9992c06f2d20")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "dc9ea34945c3a8c52d5c62062951674d27becd5a")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "4212f8cc4be686e923cdbec9ded24f42f1da74ba")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ff6df200a7ace3af204b622969a387ce7a1e1504")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "24543b1595fbd12972e7073680fde062337b8417")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "51351fe8bb7b748fdbd7e8af9efdff1a8fa9eb56")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "0f706343bab19794f90df89400b1e94aead1db38")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "3cea6b1438f8ef7095726c592a991028e203da32")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "55b8fabbec5c66417e16b34caa5f73b0f24b1e46")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "13b367549c38c5fff1b826944df658ad1ee0a7c3")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "8d0ed3547f0dd71e7d74af31ce0ded585d7bb436")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "f2209f6ba53f7140069b42151995bfe312907561")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "93a40af0b228460656d9ad48f4c123e7b6c842d3")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "362141c30925f7bb8a3936743454326ddc510dbe")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "559faf78f736ae6b4d1770cc70ee5204c45a4896")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "fd285d0ae73d312d7234a2a142d16897c9adbcf7")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "be5fc283b3c06bc60548ea32c240ebf8d9ecafc2")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "4e84645950948a15caf27e4f9c5f18fa030efcd0")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "2e7364821e345b8b8714856a6a2f03c684140320")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "9421994e3c9883b423f6f17311d1b26c094ee991")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :STDOUT "(:ELAPSED-SECONDS 38069043/1000000 :SOURCE-FINGERPRINTS-AFTER
 ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . \"b5e1e1260d8364e7eb1549db37153364\"))
  (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
  (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
  (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
  (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
  (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
  (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
  (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
  (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
  (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
  (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
  (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c3f19ffb4aacfdfe502c5e8b12a234f2\"))
  (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
  (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
  (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
  (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
  (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
  (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"200373402e6e082dd8c7afde305302bb\"))
  (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
  (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
  (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
  (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
  (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
  (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
  (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
  (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
  (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
  (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
  (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
  (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
  (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
  (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
  (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
  (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
  (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
  (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
  (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
  (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
  (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
  (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
  (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
  (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
  (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
  (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
  (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
  (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
  (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
  (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
  (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
  (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
  (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\"))
  (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
  (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
  (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
  (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
  (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
  (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
  (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
  (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
  (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
  (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
  (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
  (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
  (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
  (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
  (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
  (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
  (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
  (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
  (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
  (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
  (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
  (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
  (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
  (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
  (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
  (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
  (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
  (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
  (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
  (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
  (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
  (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
  (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
  (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
  (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
  (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
  (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
  (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
  (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
  (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
  (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
  (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
  (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
  (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
  (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
  (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
  (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
  (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
  (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
  (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
  (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
  (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
  (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
  (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
  (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
  (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
  (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
  (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
  (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
  (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
  (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
  (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
  (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
  (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
  (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
  (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
  (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
  (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
  (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
  (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
  (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
  (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
  (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
  (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
  (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
  (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
  (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
  (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
  (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
  (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
  (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
  (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
  (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
  (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
  (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
  (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
  (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
  (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
  (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
  (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
  (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
  (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
  (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
  (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
  (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
  (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
  (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
  (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
  (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
  (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
  (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
  (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
  (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
  (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
  (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
  (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
  (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
  (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
  (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
  (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
  (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
  (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
  (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
  (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
  (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
  (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
  (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
  (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\"))
  (:FILE \"tools/get-directory-mutation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fe7ec868b29f06eb5e968896d5b431dc\")))
 :FROZEN-MANIFEST
 ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . \"b5e1e1260d8364e7eb1549db37153364\"))
  (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
  (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
  (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
  (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
  (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
  (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
  (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
  (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
  (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
  (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
  (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c3f19ffb4aacfdfe502c5e8b12a234f2\"))
  (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
  (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
  (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
  (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
  (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
  (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"200373402e6e082dd8c7afde305302bb\"))
  (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
  (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
  (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
  (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
  (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
  (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
  (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
  (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
  (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
  (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
  (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
  (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
  (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
  (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
  (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
  (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
  (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
  (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
  (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
  (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
  (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
  (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
  (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
  (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
  (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
  (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
  (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
  (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
  (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
  (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
  (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
  (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
  (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\"))
  (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
  (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
  (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
  (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
  (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
  (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
  (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
  (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
  (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
  (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
  (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
  (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
  (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
  (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
  (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
  (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
  (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
  (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
  (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
  (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
  (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
  (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
  (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
  (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
  (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
  (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
  (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
  (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
  (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
  (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
  (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
  (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
  (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
  (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
  (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
  (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
  (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
  (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
  (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
  (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
  (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
  (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
  (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
  (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
  (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
  (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
  (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
  (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
  (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
  (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
  (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
  (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
  (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
  (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
  (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
  (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
  (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
  (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
  (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
  (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
  (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
  (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
  (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
  (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
  (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
  (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
  (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
  (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
  (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
  (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
  (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
  (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
  (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
  (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
  (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
  (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
  (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
  (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
  (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
  (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
  (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
  (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
  (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
  (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
  (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
  (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
  (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
  (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
  (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
  (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
  (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
  (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
  (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
  (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
  (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
  (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
  (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
  (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
  (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
  (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
  (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
  (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
  (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
  (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
  (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
  (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
  (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
  (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
  (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
  (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
  (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
  (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
  (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
  (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
  (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
  (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
  (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
  (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
 :SOURCE-FINGERPRINTS-BEFORE
 ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . \"b5e1e1260d8364e7eb1549db37153364\"))
  (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
  (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
  (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
  (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
  (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
  (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
  (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
  (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
  (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
  (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
  (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c3f19ffb4aacfdfe502c5e8b12a234f2\"))
  (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
  (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
  (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
  (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
  (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
  (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"200373402e6e082dd8c7afde305302bb\"))
  (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
  (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
  (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
  (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
  (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
  (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
  (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
  (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
  (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
  (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
  (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
  (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
  (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
  (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
  (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
  (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
  (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
  (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
  (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
  (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
  (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
  (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
  (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
  (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
  (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
  (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
  (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
  (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
  (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
  (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
  (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
  (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
  (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\"))
  (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
  (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
  (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
  (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
  (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
  (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
  (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
  (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
  (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
  (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
  (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
  (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
  (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
  (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
  (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
  (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
  (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
  (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
  (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
  (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
  (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
  (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
  (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
  (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
  (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
  (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
  (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
  (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
  (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
  (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
  (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
  (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
  (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
  (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
  (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
  (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
  (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
  (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
  (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
  (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
  (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
  (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
  (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
  (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
  (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
  (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
  (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
  (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
  (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
  (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
  (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
  (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
  (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
  (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
  (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
  (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
  (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
  (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
  (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
  (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
  (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
  (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
  (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
  (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
  (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
  (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
  (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
  (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
  (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
  (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
  (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
  (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
  (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
  (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
  (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
  (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
  (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
  (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
  (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
  (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
  (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
  (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
  (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
  (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
  (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
  (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
  (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
  (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
  (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
  (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
  (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
  (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
  (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
  (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
  (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
  (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
  (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
  (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
  (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
  (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
  (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
  (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
  (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
  (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
  (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
  (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
  (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
  (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
  (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
  (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
  (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
  (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
  (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
  (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
  (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
  (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
  (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
  (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\"))
  (:FILE \"tools/get-directory-mutation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . \"fe7ec868b29f06eb5e968896d5b431dc\")))
 :DIRECTORY
 #A((98) BASE-CHAR
    . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/\")
 :SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATIONS :STATUS :OK :RECORDED-AT
 4000716387 :SBCL #A((5) BASE-CHAR . \"2.6.9\") :ARGV
 (#A((48) BASE-CHAR . \"/opt/homebrew/Cellar/sbcl/2.6.9/libexec/bin/sbcl\")
  #A((7) BASE-CHAR . \"--check\")
  #A((37) BASE-CHAR . \"spikes/out/get-directory-mutations-g/\"))
 :CHILD-DEADLINE-SECONDS 120 :CAMPAIGN-DEADLINE-SECONDS 900
 :CLEANUP-DEADLINE-SECONDS 2 :TARGETS
 ((:NAME \"omit-directory-owner\" :FILE \"src/get-directory/build.lisp\" :TEST
   \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\" :BEFORE
   \"(unless (eq view (segmento-get-owner segment))\" :AFTER
   \"(unless (or (eq view (segmento-get-owner segment)) view)\" :EXPECTED-FAILURE
   :FOREIGN-DIRECTORY-ACCEPTED)
  (:NAME \"missing-location-first-map\" :FILE \"src/get-directory/read.lisp\" :TEST
   \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\" :BEFORE
   \"(when (= left right) (guasto-get context :directory-location-absent))\"
   :AFTER \"(when (= left right)
               (if (plusp (length maps))
                   (return-from cerca-mappa-directory-get
                     (the mappa-segmento-get (svref maps 0)))
                   (guasto-get context :directory-location-absent)))\"
   :EXPECTED-FAILURE :MISSING-PUBLISHED-SEGMENT-AUTHORIZED)
  (:NAME \"alias-input-maps\" :FILE \"src/get-directory/build.lisp\" :TEST
   \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\" :BEFORE
   \"(owned (copy-seq maps))\" :AFTER \"(owned maps)\" :EXPECTED-FAILURE
   :CALLER-ARRAY-CHANGES-DIRECTORY)
  (:NAME \"truncate-directory-id\" :FILE \"src/get-directory/read.lisp\" :TEST
   \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\" :BEFORE
   \"(ldb (byte 32 32) location)\" :AFTER \"(ldb (byte 31 32) location)\"
   :EXPECTED-FAILURE :MAX-U32-LOCATION-REJECTED)
  (:NAME \"bypass-closed-resolver\" :FILE \"src/get-directory/read.lisp\" :TEST
   \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\" :BEFORE
   \"(risolvi-candidato-get context (trova-mappa-directory-get context directory))\"
   :AFTER \"(let ((map (trova-mappa-directory-get context directory)))
    (values (mappa-segmento-get-segment map)
            (arcdocdb.get.resolver::mappa-segmento-get-end map) 0 nil))\"
   :EXPECTED-FAILURE :CANDIDATE-SIZE-AND-RESERVED-HIGH-BITS-NOT-CHECKED :LIMIT
   :ONLY-DIRECTORY-RESOLVE-WRAPPER))
 :SELF-TEST
 (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-SELF-TEST :STATUS :OK
  :CLASSIFIER-CASES 39 :NO-PROCESSES T :NO-COMPILATION T
  :NO-PRODUCT-OR-SUITE-LOADED T :PARSER-POSITIVE-AND-NEGATIVE T
  :FIXTURE-AND-PRODUCT-COVERAGE-GUARDS T :COUNTER-COVERAGE T)
 :EXPECTED-SUITE
 (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
  \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
  \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
  \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
  \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
  \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
  \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
  \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
  \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
  \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
  \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
  \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
  \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
  \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
  \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
  \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
  \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
  \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
  \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
  \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
  \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
  \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
  \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
  \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
  \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
  \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
  \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
  \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
  \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
 :BASELINE
 (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME \"baseline\" :FILE
  \"src/get-directory/read.lisp\" :DIRECTORY
  #A((125) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/\")
  :EXPECTED-FAILURE NIL :SUBSTITUTION NIL :STATUS :OK :RESULT :BASELINE-PASSED
  :DIAGNOSTIC NIL :EXPECTED-TESTS
  (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
   \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
   \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
   \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
   \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
   \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
   \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
   \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
   \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
   \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
   \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
   \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
   \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
   \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
   \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
   \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
   \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
   \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
   \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
   \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
   \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
   \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
   \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
   \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
   \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
   \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
   \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
   \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
   \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
  :SOURCE-MANIFEST
  ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
    #A((32) BASE-CHAR . \"b5e1e1260d8364e7eb1549db37153364\"))
   (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
   (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
   (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
   (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
   (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
   (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
   (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
   (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
   (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
   (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
   (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c3f19ffb4aacfdfe502c5e8b12a234f2\"))
   (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
   (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
   (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
   (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
   (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
   (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"200373402e6e082dd8c7afde305302bb\"))
   (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
   (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
   (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
   (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
   (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
   (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
   (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
   (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
   (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
   (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
   (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
   (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
   (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
   (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
   (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
   (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
   (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
   (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
   (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
   (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
   (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
   (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
   (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
   (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
   (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
   (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
   (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
   (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
   (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
   (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
   (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
   (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
   (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\"))
   (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
   (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
   (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
   (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
   (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
   (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
   (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
   (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
   (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
   (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
   (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
   (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
   (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
   (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
   (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
   (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
   (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
   (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
   (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
   (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
   (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
   (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
   (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
   (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
   (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
   (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
   (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
   (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
   (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
   (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
   (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
   (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
   (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
   (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
   (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
   (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
   (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
   (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
   (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
   (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
   (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
   (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
   (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
   (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
   (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
   (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
   (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
   (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
   (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
   (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
   (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
   (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
   (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
   (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
   (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
   (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
   (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
   (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
   (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
   (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
   (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
   (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
   (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
   (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
   (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
   (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
   (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
   (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
   (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
   (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
   (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
   (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
   (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
   (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
   (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
   (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
   (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
   (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
   (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
   (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
   (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
   (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
   (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
   (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
   (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
   (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
   (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
   (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
   (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
   (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
   (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
   (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
   (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
   (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
   (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
   (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
   (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
   (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
   (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
   (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
   (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
   (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
   (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
   (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
   (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
   (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
   (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
   (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
   (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
   (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
   (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
   (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
   (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
   (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
   (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
   (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
   (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
   (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
  :COMPILED-TARGET
  (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
   \"74a694385f1aaf03ec87721545494119\" :FASL
   \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl\"
   :FASL-MD5 \"ac89f55ce12b5f522620c844ff0007f9\")
  :EXECUTION
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
   :ARGV
   (\"sbcl\" \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--disable-debugger\"
    \"--script\" \"isolated-build.lisp\")
   :STDOUT-LOG
   #A((135) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/stdout.log\")
   :STDERR-LOG
   #A((135) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/stderr.log\")
   :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 744167/100000 :EXIT-CODE 0 :SIGNAL
   NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :COMPLETE
    :STATUS :OK :ROOT
    \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/\"
    :SOURCE-MANIFEST
    ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
      \"b5e1e1260d8364e7eb1549db37153364\")
     (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5d70197c8b64ad6f20c8be47a60c73ca\")
     (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3546cf7f5c5ed138068548c20064f499\")
     (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"72f3a33ce27ddf94c49c495580520004\")
     (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a1f6a8e7aa4faed88e984b39871d1e53\")
     (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"82f937b7b08bd1696ad9c88da2e1c60c\")
     (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a25648d870eaa4f0b6e1e3b2cf76e28e\")
     (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fc09021f74fb50aac57589614dae04d7\")
     (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bc7a7b176e8cdd361b7c4306a1a4de4b\")
     (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"6e8c6a49314c2f460aa6f8a1759200b6\")
     (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ecd8fe950344059c629927b38fb6e4aa\")
     (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c3f19ffb4aacfdfe502c5e8b12a234f2\")
     (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f6488e987889432b375254021825dbe5\")
     (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"706c0baa4158bf272c4b0df17c1439d2\")
     (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"987e8ed576a21eb644ac1ef2e06edbda\")
     (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cf1999ddb10f879aeefbeea853742d57\")
     (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0c33aedcdb352e78a3c694cf796e6692\")
     (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"200373402e6e082dd8c7afde305302bb\")
     (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c33cdcc45f45218aa3e8bf26ce0ee575\")
     (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b13e92b5f24a42fe283c17b649722b6a\")
     (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"69e77bcd15b5413a815a65c5081229db\")
     (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d885bd2a9860eb60aec1a775e5031d5e\")
     (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0f67dd5c51bf6a63bc292ab4e2a280c2\")
     (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1130012fc5613a5648d22ed8628be0e8\")
     (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a1cdb5661fc54beba5bf00e4765f3235\")
     (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"765d14c88cd288093a77a57930cd6999\")
     (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"875201dfab0a84efd40fe9828cc293c8\")
     (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"975b5f74e0c5a38ce978f4d9c7fcc6b8\")
     (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"036dd02adf87d33c3ae2f40735c733fa\")
     (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"653b974f310c09f6e2224a84acc43bbf\")
     (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"82253491f995f5bc153fb5ebf30d564c\")
     (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"6b85eebe69366e78ed5fc5cc20735f00\")
     (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cb5710d6c111cadb7121a50998a747fa\")
     (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8202843bddb817da4279ac959ae3f3c4\")
     (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"38d26f8c749dd946dfc4b9c57103a892\")
     (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a64d98c9ff429d6103d6e10ee1fd7980\")
     (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2c1892002f0599bb8273093031017520\")
     (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c24065d6c8d80d1be53994a0041743df\")
     (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"babd0a78b4185af24ae1fef870c0fabb\")
     (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"aa34ca6bc07535e35fea723878d99f66\")
     (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0679ee07c46f69db330706303c70d8d2\")
     (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"73019644090e2971f2b54dc36e4491f5\")
     (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ca642ea47e4bff76f78f5b6d7287d6bd\")
     (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a06115175f450776762761dce25acdb8\")
     (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"942b596396c19815290a57830af2121b\")
     (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"4db58e2f48bf77d751f1b83bb9f84b5c\")
     (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5ee593a112958d94163dab17c5aa4ba2\")
     (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\")
     (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cde24b2bf5c5637d5501b95bed47df31\")
     (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"4233eef9d87bdec712d4f690bcb699a9\")
     (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"74a694385f1aaf03ec87721545494119\")
     (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"17c957d6934a31f4ed64313e756de2d2\")
     (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8d26428a4e17ad18990b8ee7d5f5b53a\")
     (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"6d95f29b331d335175843f47ae44a6ea\")
     (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f13d422adb6aa9e8489352884137f25a\")
     (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3da469a7aa1e682dd8f2e516ee451de1\")
     (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d6aaec49504a96f37c8ff1bc182c977b\")
     (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bd7182e9871fe82530d0c828e473ccde\")
     (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bbfb2082103e6712419e180ab972245c\")
     (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cbfb17bf1f65698fb7c7889953d02d1e\")
     (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1339edff0223dbf122f11ff0adbba61c\")
     (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ca9002b81efd0aed9761cd1f78514762\")
     (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"536e9dc4ed51072b8a6d1528d3ec18bf\")
     (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2d869293ba47444c4721713d955c6254\")
     (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9df13bcc6908e9fa601d173a671e1ccf\")
     (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c5cc36884b238221cc13ca0c087ec7c2\")
     (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e70bfeddd694336bbd088e65f8761834\")
     (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"82258ec87aca513a508bc5dee8410dd6\")
     (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c72633d15c3488699072eb610ebde7c8\")
     (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"811869eb6a197d3c4e26af4322e52652\")
     (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1b70dac05d6d2418909eb5105b808e81\")
     (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c394e5684de5e2d938991c7cb348b93c\")
     (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b5c51802e607e3dd22de68204baf64e9\")
     (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bef497b9a267c7306d4100000491c814\")
     (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"886b7c08b9929283e8968831cbe5c039\")
     (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2d9060e41bc5252067d35e59ac70ee06\")
     (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"65076c355c099b5dc73d185948d3bec4\")
     (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"43d2209225707352daec6186ef95a805\")
     (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"45ce41749bc6fa638539815d3f802b96\")
     (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"598a9b65e73151c924b2cdcaf6d96705\")
     (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a319691e3e28b7ea7b927de490cf69ba\")
     (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ff2cfbb865290d7a1510fdf6877c7229\")
     (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fa52433eae199ceeb874bf2bc47afca7\")
     (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1dd67c527257e43f17e006644ecdbd00\")
     (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d65cfce399b04f905bf969929962e59a\")
     (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"699ce3f1615296fc27fcde3e0d63a4bc\")
     (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3f317a0d3c5ee86a73651aad36135cc3\")
     (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5155959766645d3172ae5e73c58cc071\")
     (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a59eab6425a60fa2656f86bf87d5c9ac\")
     (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e8e31e599356e592af29c0cc4604872b\")
     (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5b22b90cfe8534086f6aff96d156713e\")
     (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0417dd41cb3ec1d62dfd913c19f810ad\")
     (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8befbbd00ed5c31c1487a11887eba495\")
     (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1188e7a64a7a5d9482c1233cb9acb452\")
     (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a450cac8071513365267e7024cbe94b0\")
     (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"475dd7d5809a836f01544b447cc8df27\")
     (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5157fd03ee806ee998ad8f0002d56268\")
     (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3384cadf737c7d80c004222022a281f6\")
     (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f0c8c579cd7db466d243ed3ea9f8e8aa\")
     (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"716866194d6b9f076e102e84187229c0\")
     (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"11c7103efbe733bbf0a13927f23c3d34\")
     (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9500cfb800603de002d6d2b24f1bf056\")
     (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c9380ad46a1d7acf41655aaed20db478\")
     (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a5e7108e80664eb3b562fbd7e680801f\")
     (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"db8497f9cff35b1ee261f1f410f46ca6\")
     (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f188d1dbd5d0adb49f53acf09157aef9\")
     (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8bb066aab61a18eff175b9edb11e42a2\")
     (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0e9365e674d1584b111f915ce1f58634\")
     (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ff98aea5cb9a7ae2671f6a887a003725\")
     (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ae3ad96269b5e711a9dbb455f3c0ce48\")
     (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2d5a795bcefd605c75da91c725ae83a2\")
     (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"475517bd7ba04a1c37a82efeb8ff73d9\")
     (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a9bc70eab6720b5c6f8503178e2c966b\")
     (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"becf5c78049c85f2c05cd1ef54454032\")
     (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"4040905f4a64ba704a480d82e87ec748\")
     (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"7d74d9decc5a0bc9f9331d89bd503e21\")
     (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9e0baf22c53329d393e047c669679645\")
     (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9c37ff8237fcc9fe9ae4f44316e854e3\")
     (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1a51ef4a488bb9fde2ff7d47bae01379\")
     (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cbdc30f93109c474e1fc25066c9b9b13\")
     (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f782d1137b8ce342b91c9999cfb7accc\")
     (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"852149de4c289b8e067602780378d87a\")
     (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b33e57a643f2fca810846f6226366253\")
     (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f4433fd19ebc7239dbc2628c39f3ecdb\")
     (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9bd6820c4feba3e552aab1a4edd87861\")
     (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fcea263de1938767772e5b11411ecd5e\")
     (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"78c136d5838dcfe3019d9069643a8d8f\")
     (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bf65b1731eab6e0572461ef5cc60fc40\")
     (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"67975249aaabd751757cdfb9222cc3c4\")
     (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e0d2498db1011e857b7b0daa1934f187\")
     (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"37ace42844c11b52446ee1fc500b8e0b\")
     (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ebd7a54adea2213294a887e6d4db0927\")
     (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"7b1d4054415faca7e5fca59ad83b4d4a\")
     (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\")
     (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fcacd15460db25ea9cc4036065f9f096\")
     (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"32b2156739a6f2ca996abb91df0a2603\")
     (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b6026a8b7bb64b45c37a65effda70d8e\")
     (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"de1aca16a35d34d16aba12ff541c0d2b\")
     (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"59e3c59c90d8d0fc5731b87496a785aa\")
     (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"056d2c6a67c9d9f2bf9fe2d2c348d53c\")
     (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cb0d91405325b508e6b2ab24d178de7a\")
     (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b8e04971b8ad75a1bd0c722997badfd2\")
     (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d6924deff152b941bd49f0bb200b4197\")
     (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e0f987d8767744050ec4d1b3ecb699ed\")
     (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ce649df47dd38888d5103c98345f7e41\")
     (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ab19ec8d15af91511e817858c41cebc8\")
     (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2340e0c9074f7b1bf80c74f774986bc5\")
     (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a93ce2e84e8aee647b5083ad1d2b899b\")
     (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f0fee18adf357bad98e8a3c3e8c70c0c\")
     (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2b23d468be0165fa009c5ebd5d1bbe23\")
     (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1cda77a357ab2147035993b72d135a37\")
     (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cb64f806b8d69eb42d865b4abfff0b27\")
     (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"061147be459d8d3b08c661bd3f91d152\")
     (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b53d27dcc9f4badf18b50519c50bc614\")
     (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f86bd104f20616a76b42c02227f72844\")
     (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8c03f9c01dcb30f2d3970a5694968ecf\")
     (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\")
     (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d6812fa59bf8fd1252fbf85a9bfa3896\")
     (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a229f76f7036f3573a6e528dcd390a19\")
     (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"42b990e3b254e6fb488c0ab91b6a6502\")
     (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c0340924c9130e14d0e8efedeec078f1\")
     (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"7a0e7c99ab70b4720cbb091156560f5e\")
     (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"96c41b1d417135a24fc65659ea3abe11\")
     (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f799f27a8ac1a4c736c04796c1e543f9\")
     (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"758adad069aec2f9dbe0635797314ff6\")
     (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"3f868ebe4307ad4238b314c37eceed9a\")
     (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"1137938073e71d6d8d62c751fbad05d5\")
     (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"d1ab36d05cc1266e4533d27c693f12f4\")
     (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"63dd01c852de1399c2c82274d481d257\"))
    :SUITE-FILES
    (\"tests/foundation/support.lisp\" \"tests/get-directory/support.lisp\"
     \"tests/get-directory/construction.lisp\" \"tests/get-directory/read.lisp\"
     \"tests/get-directory/threads.lisp\")
    :REGISTERED-TESTS
    (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
     \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
     \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
     \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
     \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
     \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
     \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
     \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
     \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
     \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
     \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
     \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
     \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
     \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
     \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
     \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
     \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
     \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
     \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
     \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
     \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
     \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
     \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
     \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
     \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
     \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
     \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
     \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
     \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
    :SELECTED-TEST NIL :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
    (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     \"74a694385f1aaf03ec87721545494119\" :FASL
     \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl\"
     :FASL-MD5 \"ac89f55ce12b5f522620c844ff0007f9\")
    :COMPILED-PRODUCT
    ((:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5d70197c8b64ad6f20c8be47a60c73ca\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/build.fasl\"
      :FASL-MD5 \"bbd833102442ca4e82e972a7aa6053fc\")
     (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3546cf7f5c5ed138068548c20064f499\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/clock.fasl\"
      :FASL-MD5 \"007969e000b0a88a07e3b37bae0cdba2\")
     (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"72f3a33ce27ddf94c49c495580520004\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/core.fasl\"
      :FASL-MD5 \"d7db298ef5e838edf34f6a9edf1fa9c4\")
     (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a1f6a8e7aa4faed88e984b39871d1e53\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/package.fasl\"
      :FASL-MD5 \"3dddcc10eb7875bf1f7f4867f0c985d7\")
     (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"82f937b7b08bd1696ad9c88da2e1c60c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/read.fasl\"
      :FASL-MD5 \"df0e76486ed1891a460b86744924d1b5\")
     (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a25648d870eaa4f0b6e1e3b2cf76e28e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/types.fasl\"
      :FASL-MD5 \"f59b79c3db9b697da2b9c5bcbc8c54ef\")
     (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fc09021f74fb50aac57589614dae04d7\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/write.fasl\"
      :FASL-MD5 \"b986d213bc8acd3375b3e42facfb00f9\")
     (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bc7a7b176e8cdd361b7c4306a1a4de4b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-float-minimal.fasl\"
      :FASL-MD5 \"2bb20ee3b6ace69a9dd0d8ef59771c79\")
     (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"6e8c6a49314c2f460aa6f8a1759200b6\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-header.fasl\"
      :FASL-MD5 \"9add0df37e7855416c789741aaf33d48\")
     (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ecd8fe950344059c629927b38fb6e4aa\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-minimal.fasl\"
      :FASL-MD5 \"b5250c05c4b25eaa2bf3cd9bde72476a\")
     (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c3f19ffb4aacfdfe502c5e8b12a234f2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-package.fasl\"
      :FASL-MD5 \"3610a07c58a0b7907e05198cb32e8928\")
     (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f6488e987889432b375254021825dbe5\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-input.fasl\"
      :FASL-MD5 \"152cdf6ae118eccb172eb402b210d5c3\")
     (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"706c0baa4158bf272c4b0df17c1439d2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-items.fasl\"
      :FASL-MD5 \"e0ce89e4c6a6cf8c5b5a0f66cb32bcc4\")
     (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"987e8ed576a21eb644ac1ef2e06edbda\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-minimal.fasl\"
      :FASL-MD5 \"54e030cc0c926edfb0e93006b2605090\")
     (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cf1999ddb10f879aeefbeea853742d57\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-stack.fasl\"
      :FASL-MD5 \"ac7e1baac058aa7fc2e012008c2b53f6\")
     (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0c33aedcdb352e78a3c694cf796e6692\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan.fasl\"
      :FASL-MD5 \"8669e36909c83066564df2fe6627855c\")
     (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"200373402e6e082dd8c7afde305302bb\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-simple-write.fasl\"
      :FASL-MD5 \"c7cfbaa1a72ef7d425f44446381f78e6\")
     (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c33cdcc45f45218aa3e8bf26ce0ee575\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-space.fasl\"
      :FASL-MD5 \"3111c65b34bc57e95493900b453f1a5e\")
     (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b13e92b5f24a42fe283c17b649722b6a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-string-write.fasl\"
      :FASL-MD5 \"9c559a149257df6d50e62cbb02bc7e4c\")
     (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"69e77bcd15b5413a815a65c5081229db\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-write.fasl\"
      :FASL-MD5 \"1c81a37f6afd0faa1fc04eb156dd0df9\")
     (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d885bd2a9860eb60aec1a775e5031d5e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/package.fasl\"
      :FASL-MD5 \"a97c3a4d35caa50bca6d9544ce8743ce\")
     (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0f67dd5c51bf6a63bc292ab4e2a280c2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/utf8.fasl\"
      :FASL-MD5 \"fa7eaafda5fdac2d93ef494ed6ecb832\")
     (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1130012fc5613a5648d22ed8628be0e8\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/csn/package.fasl\"
      :FASL-MD5 \"4142843e3041292c259b1724166d5459\")
     (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a1cdb5661fc54beba5bf00e4765f3235\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/csn/registry.fasl\"
      :FASL-MD5 \"99cc7490a6da92e51a8c9a74bb4ed880\")
     (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"765d14c88cd288093a77a57930cd6999\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/core.fasl\"
      :FASL-MD5 \"fa3bfa1fb41da87f33b7ada2be662349\")
     (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"875201dfab0a84efd40fe9828cc293c8\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/package.fasl\"
      :FASL-MD5 \"fe3313387253a617abe9bd2d70d9f48e\")
     (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"975b5f74e0c5a38ce978f4d9c7fcc6b8\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/read.fasl\"
      :FASL-MD5 \"03e54285332b4a30cdb474404e0b024d\")
     (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"036dd02adf87d33c3ae2f40735c733fa\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/reclaim.fasl\"
      :FASL-MD5 \"80152638829ecb54a8e9fa62949d6663\")
     (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"653b974f310c09f6e2224a84acc43bbf\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/retire.fasl\"
      :FASL-MD5 \"3b2a18d8ccbb2100b55fc597b89cdf44\")
     (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"82253491f995f5bc153fb5ebf30d564c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/types.fasl\"
      :FASL-MD5 \"061b3814c11ac2a4b1340f7d8e876106\")
     (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"6b85eebe69366e78ed5fc5cc20735f00\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/handoff.fasl\"
      :FASL-MD5 \"c7c88ac1ab88084434980ae8b22b4a5f\")
     (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cb5710d6c111cadb7121a50998a747fa\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/package.fasl\"
      :FASL-MD5 \"3f9161b2f8dee3c393f6dc62a239959b\")
     (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8202843bddb817da4279ac959ae3f3c4\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/queue.fasl\"
      :FASL-MD5 \"5ce72de093f48e8898a602dcfeb961ce\")
     (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"38d26f8c749dd946dfc4b9c57103a892\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/ready-recycle.fasl\"
      :FASL-MD5 \"e5b499b9f823d900ee50fe7bb9b069ad\")
     (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a64d98c9ff429d6103d6e10ee1fd7980\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/ready-types.fasl\"
      :FASL-MD5 \"6411144a936b25795be2485d14fcc360\")
     (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2c1892002f0599bb8273093031017520\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/ready.fasl\"
      :FASL-MD5 \"5fc796ec1a6e3f6fe015034c16d55ea8\")
     (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c24065d6c8d80d1be53994a0041743df\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/worker-boundary.fasl\"
      :FASL-MD5 \"e4ec7d200fa9fe03ff3364d40144c73d\")
     (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"babd0a78b4185af24ae1fef870c0fabb\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/worker-claim.fasl\"
      :FASL-MD5 \"efc91aaa680ca127ddc2227e26789627\")
     (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"aa34ca6bc07535e35fea723878d99f66\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/worker-run.fasl\"
      :FASL-MD5 \"6a236c36f4211f1caf2dc9054d52b1f5\")
     (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0679ee07c46f69db330706303c70d8d2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/worker-types.fasl\"
      :FASL-MD5 \"6d66883e0fe466914843704591661cc2\")
     (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"73019644090e2971f2b54dc36e4491f5\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/writer.fasl\"
      :FASL-MD5 \"777a5ac286215c4a51c353ea48b2c6f0\")
     (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ca642ea47e4bff76f78f5b6d7287d6bd\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/batch.fasl\"
      :FASL-MD5 \"7553386ee4024f2c3c00f21f8e1fc340\")
     (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a06115175f450776762761dce25acdb8\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/binary.fasl\"
      :FASL-MD5 \"10ad7d7087282db7f2aa41f6bf71f10e\")
     (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"942b596396c19815290a57830af2121b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/conditions.fasl\"
      :FASL-MD5 \"919e8b6dd095439b412bf2fc742d686a\")
     (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"4db58e2f48bf77d751f1b83bb9f84b5c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/crc32c.fasl\"
      :FASL-MD5 \"e910f172c594136b50f5c604e597a847\")
     (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5ee593a112958d94163dab17c5aa4ba2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/package.fasl\"
      :FASL-MD5 \"d3577a1c353a0797c2be2775912c96c8\")
     (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/record.fasl\"
      :FASL-MD5 \"8f28339c4bbeda765e3364bfb0dc9a6d\")
     (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cde24b2bf5c5637d5501b95bed47df31\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/build.fasl\"
      :FASL-MD5 \"19a46300b89ce4c0658873de45c42282\")
     (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"4233eef9d87bdec712d4f690bcb699a9\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/package.fasl\"
      :FASL-MD5 \"d385bf02825483e5966d7b83e5c07988\")
     (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"74a694385f1aaf03ec87721545494119\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl\"
      :FASL-MD5 \"ac89f55ce12b5f522620c844ff0007f9\")
     (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"17c957d6934a31f4ed64313e756de2d2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/types.fasl\"
      :FASL-MD5 \"a3f7c0fd3cb208d747fd2190a9e8c427\")
     (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8d26428a4e17ad18990b8ee7d5f5b53a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-build.fasl\"
      :FASL-MD5 \"0a1a6c2e1803cf444a9e1abb260c79a6\")
     (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"6d95f29b331d335175843f47ae44a6ea\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-directory.fasl\"
      :FASL-MD5 \"f70d66508f1db43f4a8ab9b680d26eeb\")
     (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f13d422adb6aa9e8489352884137f25a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-preflight.fasl\"
      :FASL-MD5 \"2eee01d8495e7519825d005cd1385ffc\")
     (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3da469a7aa1e682dd8f2e516ee451de1\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-read.fasl\"
      :FASL-MD5 \"0e9658c92ab0924cc86f2d9503603ac3\")
     (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d6aaec49504a96f37c8ff1bc182c977b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-scan.fasl\"
      :FASL-MD5 \"5aa905c544adf5d9065a1f31e86be9fe\")
     (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bd7182e9871fe82530d0c828e473ccde\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-types.fasl\"
      :FASL-MD5 \"5e097d0ecb1a2124e4c934f330f487d6\")
     (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bbfb2082103e6712419e180ab972245c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/build.fasl\"
      :FASL-MD5 \"64406a5ace6c4c138421feaedc1c92e9\")
     (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cbfb17bf1f65698fb7c7889953d02d1e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/package.fasl\"
      :FASL-MD5 \"a2b8f7ce2f2e7879aa3566a28ab4673b\")
     (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1339edff0223dbf122f11ff0adbba61c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/read.fasl\"
      :FASL-MD5 \"d1d648b75c9b9c8df5d5656c5b0db71f\")
     (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ca9002b81efd0aed9761cd1f78514762\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/rows.fasl\"
      :FASL-MD5 \"07607ddef3f11ea6ffcf52bfe09ca1aa\")
     (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"536e9dc4ed51072b8a6d1528d3ec18bf\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/scan.fasl\"
      :FASL-MD5 \"b0f92ef9aa79bf516736bb02cfb5fae2\")
     (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2d869293ba47444c4721713d955c6254\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/sort.fasl\"
      :FASL-MD5 \"03b0d60e8036e293aceeea6eb6616920\")
     (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9df13bcc6908e9fa601d173a671e1ccf\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/types.fasl\"
      :FASL-MD5 \"6169185b2104eb7a5ca310cb73c19bb3\")
     (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c5cc36884b238221cc13ca0c087ec7c2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/build.fasl\"
      :FASL-MD5 \"614545f9bff6ef65513266c352f9d277\")
     (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e70bfeddd694336bbd088e65f8761834\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/lifecycle.fasl\"
      :FASL-MD5 \"3364131aa3d9a9bc8e33f7349d4eb412\")
     (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"82258ec87aca513a508bc5dee8410dd6\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/lookup.fasl\"
      :FASL-MD5 \"415dc2f056881eb7da662fcb3b36bd95\")
     (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c72633d15c3488699072eb610ebde7c8\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/package.fasl\"
      :FASL-MD5 \"b480bd53a98a07aef1e9790eb027e74f\")
     (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"811869eb6a197d3c4e26af4322e52652\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/segment.fasl\"
      :FASL-MD5 \"d1eb26a97078c20bd17aefb891babfde\")
     (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1b70dac05d6d2418909eb5105b808e81\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/target.fasl\"
      :FASL-MD5 \"e459c7ad4045188e3388682ec9476d3b\")
     (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c394e5684de5e2d938991c7cb348b93c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/types.fasl\"
      :FASL-MD5 \"8869cf33ab049e65a2a47845c12292fc\")
     (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b5c51802e607e3dd22de68204baf64e9\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/hash/arithmetic.fasl\"
      :FASL-MD5 \"9927d280cd1f443dfc31a20107476a84\")
     (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bef497b9a267c7306d4100000491c814\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/hash/blocks.fasl\"
      :FASL-MD5 \"6a12d1b65c6dc1ea53b5c3f3c5905170\")
     (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"886b7c08b9929283e8968831cbe5c039\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/hash/hash64.fasl\"
      :FASL-MD5 \"85a3f40fca41017964b0c835fd087228\")
     (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2d9060e41bc5252067d35e59ac70ee06\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/hash/package.fasl\"
      :FASL-MD5 \"d14c80dd77525969e8faa80cfdc56a70\")
     (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"65076c355c099b5dc73d185948d3bec4\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/core.fasl\"
      :FASL-MD5 \"0cd4724c62fac042d865a1dafe6380c9\")
     (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"43d2209225707352daec6186ef95a805\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/hash-digests.fasl\"
      :FASL-MD5 \"9ed63fc2bde881b9a42f0ae547861af2\")
     (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"45ce41749bc6fa638539815d3f802b96\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/hash-seed.fasl\"
      :FASL-MD5 \"1a59b622785857910b0d01d6145a7f13\")
     (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"598a9b65e73151c924b2cdcaf6d96705\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/package.fasl\"
      :FASL-MD5 \"cd8652ec9490fb2fbb797d50fe2b983b\")
     (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a319691e3e28b7ea7b927de490cf69ba\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-arena.fasl\"
      :FASL-MD5 \"4adf5a8607476aae37088dd5566cb55c\")
     (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ff2cfbb865290d7a1510fdf6877c7229\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-build.fasl\"
      :FASL-MD5 \"e255905a8d714c5867971a3bee0b1022\")
     (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fa52433eae199ceeb874bf2bc47afca7\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-core.fasl\"
      :FASL-MD5 \"b4dc0978f6967794bf9cb38d15741ab0\")
     (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1dd67c527257e43f17e006644ecdbd00\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-directory.fasl\"
      :FASL-MD5 \"8a035986cafc80ecb5f07f1c6f345ac6\")
     (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d65cfce399b04f905bf969929962e59a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-package.fasl\"
      :FASL-MD5 \"4fdcf33fb345e1aea3eed0ed3d1fd980\")
     (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"699ce3f1615296fc27fcde3e0d63a4bc\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-probe.fasl\"
      :FASL-MD5 \"daadf693b35bef1c9553bd96885086da\")
     (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3f317a0d3c5ee86a73651aad36135cc3\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-read.fasl\"
      :FASL-MD5 \"501ebac287d069b87eef03ddd3f13247\")
     (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5155959766645d3172ae5e73c58cc071\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-relocate.fasl\"
      :FASL-MD5 \"0bf8a29bfa9b5d4f24730b6227bc9a84\")
     (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a59eab6425a60fa2656f86bf87d5c9ac\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-types.fasl\"
      :FASL-MD5 \"b236652958d716e209da8c916d6022ff\")
     (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e8e31e599356e592af29c0cc4604872b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-write.fasl\"
      :FASL-MD5 \"279e70eb91f0f6199e2161e655864350\")
     (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5b22b90cfe8534086f6aff96d156713e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/read.fasl\"
      :FASL-MD5 \"ef8e4af0af244268c0b44dc540b6cc2e\")
     (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0417dd41cb3ec1d62dfd913c19f810ad\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/rebuild-budget.fasl\"
      :FASL-MD5 \"edae82f86e32816a8fd28287d5a923d7\")
     (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8befbbd00ed5c31c1487a11887eba495\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/rebuild-copy.fasl\"
      :FASL-MD5 \"8298d877352056e8bf3c03eb62954523\")
     (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1188e7a64a7a5d9482c1233cb9acb452\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/rebuild-scan.fasl\"
      :FASL-MD5 \"584ac889a9928e12d94ed4b6167b5d22\")
     (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a450cac8071513365267e7024cbe94b0\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/rebuild.fasl\"
      :FASL-MD5 \"43a72659bb69405cf8eee496fd7f3a25\")
     (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"475dd7d5809a836f01544b447cc8df27\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/relocate.fasl\"
      :FASL-MD5 \"1edbc74769fb0508fab2062cdf2e9426\")
     (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"5157fd03ee806ee998ad8f0002d56268\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/types.fasl\"
      :FASL-MD5 \"0f61594dc09fc4586f85c6f57b50909a\")
     (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"3384cadf737c7d80c004222022a281f6\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/validation.fasl\"
      :FASL-MD5 \"51021f30a670fcc3b5bb82c5ade445a8\")
     (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f0c8c579cd7db466d243ed3ea9f8e8aa\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/write.fasl\"
      :FASL-MD5 \"0b964dc0aa30fbd6c803091d1af6ca47\")
     (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"716866194d6b9f076e102e84187229c0\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/io/flush.fasl\"
      :FASL-MD5 \"92b2fc6d6fd66f0bca16e4839606bf51\")
     (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"11c7103efbe733bbf0a13927f23c3d34\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/io/lifecycle.fasl\"
      :FASL-MD5 \"5a80d8f73e5821d2ae6868e92a8de605\")
     (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9500cfb800603de002d6d2b24f1bf056\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/io/native.fasl\"
      :FASL-MD5 \"bc1db7d4995f4d9bac4c2b9af3202a18\")
     (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c9380ad46a1d7acf41655aaed20db478\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/io/package.fasl\"
      :FASL-MD5 \"106ee1c3edcbe7d2e9fcfb811d47355c\")
     (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a5e7108e80664eb3b562fbd7e680801f\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/io/transfer.fasl\"
      :FASL-MD5 \"0a06a42a0544a4189c4efd360f6b6c51\")
     (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"db8497f9cff35b1ee261f1f410f46ca6\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/io/types.fasl\"
      :FASL-MD5 \"8e00c6fe437c53ee76905d7af36b90ba\")
     (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f188d1dbd5d0adb49f53acf09157aef9\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/package.fasl\"
      :FASL-MD5 \"ab5f950a0f0db125aef199ba1d143b87\")
     (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8bb066aab61a18eff175b9edb11e42a2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-core.fasl\"
      :FASL-MD5 \"2795f698d6c42641975636c35eb589bf\")
     (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"0e9365e674d1584b111f915ce1f58634\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-csn.fasl\"
      :FASL-MD5 \"730d3db84b014e20ee27b27a90e54296\")
     (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ff98aea5cb9a7ae2671f6a887a003725\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-lifecycle.fasl\"
      :FASL-MD5 \"154ee04bebdab11da7ec61136fa86fb1\")
     (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ae3ad96269b5e711a9dbb455f3c0ce48\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-read.fasl\"
      :FASL-MD5 \"8457d11177b42db24c4c6ca481bf1e4a\")
     (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2d5a795bcefd605c75da91c725ae83a2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-register.fasl\"
      :FASL-MD5 \"4006db9e991ac27550253a72a48d60ac\")
     (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"475517bd7ba04a1c37a82efeb8ff73d9\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-types.fasl\"
      :FASL-MD5 \"5d11dc1722a20b30b255d9e221b3dbc8\")
     (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a9bc70eab6720b5c6f8503178e2c966b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/types.fasl\"
      :FASL-MD5 \"9b2af16a74cf0f074326eb0992c93020\")
     (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"becf5c78049c85f2c05cd1ef54454032\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/package.fasl\"
      :FASL-MD5 \"d5b21fd6d986b5cc703b9e74e8596031\")
     (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"4040905f4a64ba704a480d82e87ec748\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/read/core.fasl\"
      :FASL-MD5 \"aa1457123ec168985f7a8fd0887c9d29\")
     (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"7d74d9decc5a0bc9f9331d89bd503e21\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/read/package.fasl\"
      :FASL-MD5 \"03ddd022cd5d84637183eb1da9161a64\")
     (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9e0baf22c53329d393e047c669679645\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/read/task.fasl\"
      :FASL-MD5 \"0cecff86b52e81425f01701181263b28\")
     (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9c37ff8237fcc9fe9ae4f44316e854e3\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/read/types.fasl\"
      :FASL-MD5 \"37311adc7f918f33a4490a661b38ff28\")
     (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1a51ef4a488bb9fde2ff7d47bae01379\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-build.fasl\"
      :FASL-MD5 \"cd1199bc5c960b9c7aa16e6b0ea3efaa\")
     (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cbdc30f93109c474e1fc25066c9b9b13\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-package.fasl\"
      :FASL-MD5 \"bfa292582a3d817d5472f918c245afc3\")
     (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f782d1137b8ce342b91c9999cfb7accc\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-query.fasl\"
      :FASL-MD5 \"ac05f4e6e6664ec79c739295c349bb46\")
     (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"852149de4c289b8e067602780378d87a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-radix.fasl\"
      :FASL-MD5 \"2e6b48455f479b23a7cc5106619d6a17\")
     (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b33e57a643f2fca810846f6226366253\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-sort.fasl\"
      :FASL-MD5 \"63cf64ffd222d37dbe7749cb4c2cd5d0\")
     (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f4433fd19ebc7239dbc2628c39f3ecdb\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-types.fasl\"
      :FASL-MD5 \"f9d095a076972c54013bb38673f97fc5\")
     (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"9bd6820c4feba3e552aab1a4edd87861\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/inventory-build.fasl\"
      :FASL-MD5 \"4d8b00891bc43cf1e1b5837b24e6fd83\")
     (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fcea263de1938767772e5b11411ecd5e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/inventory-query.fasl\"
      :FASL-MD5 \"d189d68311fdd4a84691240e42ec4895\")
     (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"78c136d5838dcfe3019d9069643a8d8f\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/inventory-types.fasl\"
      :FASL-MD5 \"74debeedd4eb1eec41f96dada54919af\")
     (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bf65b1731eab6e0572461ef5cc60fc40\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-build.fasl\"
      :FASL-MD5 \"b1b8b60c2fa43b0f0351df55e4ebc6f2\")
     (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"67975249aaabd751757cdfb9222cc3c4\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-decode.fasl\"
      :FASL-MD5 \"cd0e0a018bc9746c7b212021c84a8b9c\")
     (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e0d2498db1011e857b7b0daa1934f187\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-fold.fasl\"
      :FASL-MD5 \"e9578dcba01aa49321ab6ca3d6dcb3f3\")
     (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"37ace42844c11b52446ee1fc500b8e0b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-package.fasl\"
      :FASL-MD5 \"252c688ced885cf36f2aa0949ea544a9\")
     (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ebd7a54adea2213294a887e6d4db0927\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-query.fasl\"
      :FASL-MD5 \"d0caf5832e64b7812a482f2ff9a9e8d7\")
     (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"7b1d4054415faca7e5fca59ad83b4d4a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-types.fasl\"
      :FASL-MD5 \"c57e84128c782898db9d0d2b9d6a5f52\")
     (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/package.fasl\"
      :FASL-MD5 \"a94c2a0743134e88fdf7f8fa208156f0\")
     (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"fcacd15460db25ea9cc4036065f9f096\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/scan.fasl\"
      :FASL-MD5 \"9d3090e6493f13e81f35fac706dc8a19\")
     (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"32b2156739a6f2ca996abb91df0a2603\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/events.fasl\"
      :FASL-MD5 \"60283a044f163c15b885339e35bbe103\")
     (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b6026a8b7bb64b45c37a65effda70d8e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/io-events.fasl\"
      :FASL-MD5 \"fe71b322a7cbe1e64aa091b416d1f9d8\")
     (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"de1aca16a35d34d16aba12ff541c0d2b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/ownership.fasl\"
      :FASL-MD5 \"7a59c386a70cc892f0770b414da4e619\")
     (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"59e3c59c90d8d0fc5731b87496a785aa\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/package.fasl\"
      :FASL-MD5 \"82a7835f42c342bf57081772b748c92e\")
     (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"056d2c6a67c9d9f2bf9fe2d2c348d53c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/publication.fasl\"
      :FASL-MD5 \"036b8055f63905ec6063b057605c323f\")
     (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cb0d91405325b508e6b2ab24d178de7a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/query.fasl\"
      :FASL-MD5 \"130f45bbf07445a57719a03f344281e2\")
     (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b8e04971b8ad75a1bd0c722997badfd2\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/retirement.fasl\"
      :FASL-MD5 \"355af37289f6a90dfa6acb152f9381a8\")
     (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d6924deff152b941bd49f0bb200b4197\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/routing-build.fasl\"
      :FASL-MD5 \"9d5d9544e4710985d4c540734fbc8438\")
     (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"e0f987d8767744050ec4d1b3ecb699ed\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/routing-select.fasl\"
      :FASL-MD5 \"9c6f42643ebb772d0d2210ad5318912e\")
     (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ce649df47dd38888d5103c98345f7e41\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/routing-types.fasl\"
      :FASL-MD5 \"8780e3c901224072467ed049a1e8fc67\")
     (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"ab19ec8d15af91511e817858c41cebc8\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/types.fasl\"
      :FASL-MD5 \"61274dc37195aeb0e4cb759772620c2d\")
     (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2340e0c9074f7b1bf80c74f774986bc5\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/worker-boundary.fasl\"
      :FASL-MD5 \"f832397be042ec2b8c9b4c35ac2d9dd7\")
     (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a93ce2e84e8aee647b5083ad1d2b899b\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/worker-package.fasl\"
      :FASL-MD5 \"c6ee734416a8d627a51ccd58c3afdcf0\")
     (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f0fee18adf357bad98e8a3c3e8c70c0c\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/worker-run.fasl\"
      :FASL-MD5 \"ae50edf03c34e0caf8caa12c6dc5869e\")
     (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"2b23d468be0165fa009c5ebd5d1bbe23\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/worker-types.fasl\"
      :FASL-MD5 \"cb70d470c766a0cb5af6535b14ba051c\")
     (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"1cda77a357ab2147035993b72d135a37\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/compaction-scan.fasl\"
      :FASL-MD5 \"b609fca930e3f66b53e251d7e53ab40d\")
     (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"cb64f806b8d69eb42d865b4abfff0b27\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/control-payload.fasl\"
      :FASL-MD5 \"ec25dcaa4840ee7ac8e7911dd913b33a\")
     (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"061147be459d8d3b08c661bd3f91d152\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/formats.fasl\"
      :FASL-MD5 \"ab43f475185fc1f4d6d6edb66279c723\")
     (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"b53d27dcc9f4badf18b50519c50bc614\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/log-header.fasl\"
      :FASL-MD5 \"b1dbb0f8b1860b0a1170310b7caf07fb\")
     (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f86bd104f20616a76b42c02227f72844\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/package.fasl\"
      :FASL-MD5 \"0340ff56f1c9010bbb21ffb7f76f6ade\")
     (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"8c03f9c01dcb30f2d3970a5694968ecf\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/payload-record.fasl\"
      :FASL-MD5 \"0240c1aa4e93fe8a4a553f791ce0c873\")
     (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/payload-write.fasl\"
      :FASL-MD5 \"3ab931c250deab52546c0285e6dc194d\")
     (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"d6812fa59bf8fd1252fbf85a9bfa3896\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/segment-header.fasl\"
      :FASL-MD5 \"cffbd5254a9f2b594f0a9886b03e7777\")
     (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"a229f76f7036f3573a6e528dcd390a19\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/builder.fasl\"
      :FASL-MD5 \"3ada27c8ebd5a47ce9e0d955333bd86a\")
     (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"42b990e3b254e6fb488c0ab91b6a6502\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/csn.fasl\"
      :FASL-MD5 \"e5b35e04d79a5eee8dd93afc0671eac4\")
     (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"c0340924c9130e14d0e8efedeec078f1\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/executor.fasl\"
      :FASL-MD5 \"2eb9fe096b305ef749618182e2a11cb6\")
     (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"7a0e7c99ab70b4720cbb091156560f5e\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/group.fasl\"
      :FASL-MD5 \"943cf6f850bb3c58f67abbdc3e2acdd3\")
     (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"96c41b1d417135a24fc65659ea3abe11\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/package.fasl\"
      :FASL-MD5 \"a499f0e60c86ebd2870b4e868124de75\")
     (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"f799f27a8ac1a4c736c04796c1e543f9\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/types.fasl\"
      :FASL-MD5 \"a8cbe334cc19468a0b3caa37f4f6c01f\"))
    :COMPILED-SUITE
    ((:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"758adad069aec2f9dbe0635797314ff6\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/tests/foundation/support.fasl\"
      :FASL-MD5 \"804cf3fb444171d50e2b72a78450dcb1\")
     (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"3f868ebe4307ad4238b314c37eceed9a\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/support.fasl\"
      :FASL-MD5 \"2c0562ac23a6122dd5b5c89abbf3399c\")
     (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"1137938073e71d6d8d62c751fbad05d5\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/construction.fasl\"
      :FASL-MD5 \"b3ece450ad1bcec53000b9ad61362680\")
     (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"d1ab36d05cc1266e4533d27c693f12f4\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/read.fasl\"
      :FASL-MD5 \"7c487bd512131f97514450cda50e4355\")
     (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
      \"63dd01c852de1399c2c82274d481d257\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/threads.fasl\"
      :FASL-MD5 \"5f76d2297b116aac8a02952dd0e07ff3\"))
    :FAILED-TEST NIL :PASSED-TESTS
    (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
     \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
     \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
     \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
     \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
     \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
     \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
     \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
     \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
     \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
     \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
     \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
     \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
     \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
     \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
     \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
     \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
     \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
     \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
     \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
     \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
     \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
     \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
     \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
     \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
     \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
     \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
     \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
     \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
    :FAILURE-KIND NIL :CONDITION-TYPE NIL :DIAGNOSTIC NIL))
  :DETAIL NIL :RUNNER-MD5
  #A((32) BASE-CHAR . \"91fc95b39dc283bbfd03f087486bc903\") :TARGET-SOURCE-MD5
  #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\") :ARTIFACTS-VERIFIED
  T)
 :MUTANTS
 ((:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   \"omit-directory-owner\" :FILE \"src/get-directory/build.lisp\" :DIRECTORY
   #A((137) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/\")
   :EXPECTED-FAILURE :FOREIGN-DIRECTORY-ACCEPTED :SUBSTITUTION
   (:BEFORE \"(unless (eq view (segmento-get-owner segment))\" :AFTER
    \"(unless (or (eq view (segmento-get-owner segment)) view)\")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   (\"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\")
   :SOURCE-MANIFEST
   ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5e1e1260d8364e7eb1549db37153364\"))
    (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
    (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
    (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
    (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
    (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
    (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
    (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
    (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
    (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
    (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
    (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3f19ffb4aacfdfe502c5e8b12a234f2\"))
    (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
    (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
    (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
    (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
    (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
    (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"200373402e6e082dd8c7afde305302bb\"))
    (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
    (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
    (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
    (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
    (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
    (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
    (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
    (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
    (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
    (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
    (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
    (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
    (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
    (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
    (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
    (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
    (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
    (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
    (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
    (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
    (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
    (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
    (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
    (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
    (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
    (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
    (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
    (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
    (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
    (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
    (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"db58ed1c3877f2d6ea58932d3bc75e56\"))
    (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
    (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\"))
    (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
    (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
    (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
    (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
    (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
    (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
    (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
    (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
    (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
    (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
    (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
    (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
    (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
    (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
    (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
    (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
    (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
    (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
    (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
    (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
    (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
    (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
    (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
    (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
    (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
    (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
    (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
    (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
    (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
    (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
    (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
    (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
    (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
    (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
    (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
    (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
    (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
    (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
    (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
    (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
    (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
    (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
    (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
    (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
    (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
    (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
    (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
    (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
    (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
    (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
    (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
    (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
    (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
    (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
    (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
    (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
    (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
    (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
    (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
    (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
    (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
    (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
    (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
    (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
    (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
    (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
    (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
    (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
    (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
    (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
    (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
    (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
    (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
    (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
    (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
    (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
    (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
    (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
    (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
    (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
    (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
    (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
    (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
    (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
    (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
    (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
    (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
    (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
    (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
    (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
    (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
    (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
    (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
    (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
    (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
    (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
    (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
    (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
    (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
    (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
    (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
    (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
    (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
    (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
    (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
    (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
    (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
    (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
    (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
    (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
    (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
    (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
    (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
    (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
    (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
    (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
    (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
    (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
   :COMPILED-TARGET
   (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    \"db58ed1c3877f2d6ea58932d3bc75e56\" :FASL
    \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl\"
    :FASL-MD5 \"98b1ee25f2ed929e1eb124933d284801\")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    (\"sbcl\" \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--disable-debugger\"
     \"--script\" \"isolated-build.lisp\")
    :STDOUT-LOG
    #A((147) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/stdout.log\")
    :STDERR-LOG
    #A((147) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/stderr.log\")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 1622631/250000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/\"
     :SOURCE-MANIFEST
     ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
       \"b5e1e1260d8364e7eb1549db37153364\")
      (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3f19ffb4aacfdfe502c5e8b12a234f2\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\")
      (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"200373402e6e082dd8c7afde305302bb\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db58ed1c3877f2d6ea58932d3bc75e56\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"74a694385f1aaf03ec87721545494119\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\")
      (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\"))
     :SUITE-FILES
     (\"tests/foundation/support.lisp\" \"tests/get-directory/support.lisp\"
      \"tests/get-directory/construction.lisp\" \"tests/get-directory/read.lisp\"
      \"tests/get-directory/threads.lisp\")
     :REGISTERED-TESTS
     (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
      \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
      \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
      \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
      \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
      \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
      \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
      \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
      \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
      \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
      \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
      \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
      \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
      \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
      \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
      \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
      \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
      \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
      \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
      \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
      \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
      \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
      \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
      \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
     :SELECTED-TEST
     \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"db58ed1c3877f2d6ea58932d3bc75e56\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl\"
      :FASL-MD5 \"98b1ee25f2ed929e1eb124933d284801\")
     :COMPILED-PRODUCT
     ((:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/build.fasl\"
       :FASL-MD5 \"a46eb0512e34427d96eb900faf741568\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/clock.fasl\"
       :FASL-MD5 \"94438278583432e9a2e2448d8275deb7\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/core.fasl\"
       :FASL-MD5 \"10ad9452d0467e930c0398f2dbbe4875\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/package.fasl\"
       :FASL-MD5 \"2d91b12ab632b52d88333c27a5b4d5ce\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/read.fasl\"
       :FASL-MD5 \"2d5f38cc7c7a158b7d442feb1fb761af\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/types.fasl\"
       :FASL-MD5 \"cce242ae3a521ac0af73e2b3669dd7b9\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/write.fasl\"
       :FASL-MD5 \"c6808f1d01a2f2ad06cc77479fb1652c\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-float-minimal.fasl\"
       :FASL-MD5 \"6b82254db4da9979869c639b6b8a3064\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-header.fasl\"
       :FASL-MD5 \"b179d0a19016ed4048696c4710304184\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-minimal.fasl\"
       :FASL-MD5 \"a3de22c7c6e65bf77018da240e12f488\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3f19ffb4aacfdfe502c5e8b12a234f2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-package.fasl\"
       :FASL-MD5 \"d31a08b7517d1921770afc5bc2f928b1\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-input.fasl\"
       :FASL-MD5 \"5b4dd81d7b95c6f71c13e2fa30c3f2b6\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-items.fasl\"
       :FASL-MD5 \"f5036c95c3b33d5e530e04b9da197af1\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-minimal.fasl\"
       :FASL-MD5 \"17780fb906a50dbb269fe001ed248654\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-stack.fasl\"
       :FASL-MD5 \"943b6523f99af6c6df17cf4803bc6f28\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan.fasl\"
       :FASL-MD5 \"f2cf245c86c17a038e4ce2cdf34e5e35\")
      (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"200373402e6e082dd8c7afde305302bb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-simple-write.fasl\"
       :FASL-MD5 \"437a12135e24b92689c3f5a82cfb9bb6\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-space.fasl\"
       :FASL-MD5 \"545107778fdd782beaaaac095897f55e\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-string-write.fasl\"
       :FASL-MD5 \"fe05ccfa98e4130bf5f6af316249c1c7\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-write.fasl\"
       :FASL-MD5 \"10cdc1163af54561a5eb05b28eafbf44\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/package.fasl\"
       :FASL-MD5 \"1cadbe58e27343c38a7cab48d552d3ff\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/utf8.fasl\"
       :FASL-MD5 \"f6b1ee7ff4cf194295d13afad61b44ef\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/csn/package.fasl\"
       :FASL-MD5 \"65b0d87d46b8d61f61000935d8fe5576\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/csn/registry.fasl\"
       :FASL-MD5 \"2bc5ac49660b958216f62b88a4a321c0\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/core.fasl\"
       :FASL-MD5 \"dca740c3c2b07273fbe25e7cce8a7d1d\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/package.fasl\"
       :FASL-MD5 \"7b459d1099d26e57689823fe9efeebc5\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/read.fasl\"
       :FASL-MD5 \"e75a692d3b0f8514422125a0ce8abab1\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/reclaim.fasl\"
       :FASL-MD5 \"afd4008b54a9cf502343bf6d43952007\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/retire.fasl\"
       :FASL-MD5 \"a402a70bee5bc0f2e3bb1d206b25b3a9\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/types.fasl\"
       :FASL-MD5 \"dde99f548c07c6d25a0da70e960c9eba\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/handoff.fasl\"
       :FASL-MD5 \"9fff751b1260a4b0a9f6b9b6f0f8bb54\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/package.fasl\"
       :FASL-MD5 \"b88e7f9ac7e18d08c430f254c168c4f5\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/queue.fasl\"
       :FASL-MD5 \"e71f2bb5ae163881ae50618457512a7a\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready-recycle.fasl\"
       :FASL-MD5 \"fbe63a64d45621529995d98477e3aa4c\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready-types.fasl\"
       :FASL-MD5 \"cc9d1fc1a28add04841f1ab46fd8d224\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready.fasl\"
       :FASL-MD5 \"ca741bfcd91ed7edafdac2e2e2e54a53\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-boundary.fasl\"
       :FASL-MD5 \"8368d441f5fb8abff6fa9df949a6fb08\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-claim.fasl\"
       :FASL-MD5 \"dd26a114b23fb9b25a5f6041dbcb061e\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-run.fasl\"
       :FASL-MD5 \"ca780ea252acd63e69d7d80e8e8f8946\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-types.fasl\"
       :FASL-MD5 \"9bbb71a6cee1b8c21047024660c08038\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/writer.fasl\"
       :FASL-MD5 \"6185c6cffb21ab8ebb2863b2c4b2946a\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/batch.fasl\"
       :FASL-MD5 \"4ff4e0e661c6528460b0ac30ba98a7fa\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/binary.fasl\"
       :FASL-MD5 \"ef5f120eef374f0c0c797dba595143c3\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/conditions.fasl\"
       :FASL-MD5 \"ab5ddb67c86e71c62a7758302887da9a\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/crc32c.fasl\"
       :FASL-MD5 \"f001bfd9365d0145759e50790daafab1\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/package.fasl\"
       :FASL-MD5 \"45c085bdb91fdf79bf0d34b49694fc11\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/record.fasl\"
       :FASL-MD5 \"2681b5a9fa5cd9f92c619a39a3c45463\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db58ed1c3877f2d6ea58932d3bc75e56\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl\"
       :FASL-MD5 \"98b1ee25f2ed929e1eb124933d284801\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/package.fasl\"
       :FASL-MD5 \"af22d1bc38ea6029ad91f6d568276c3e\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"74a694385f1aaf03ec87721545494119\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/read.fasl\"
       :FASL-MD5 \"3d9e9385fc14ca4387df41c79c3cbb44\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/types.fasl\"
       :FASL-MD5 \"e88f5b897f4c3df7e2ccc943eef9b713\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-build.fasl\"
       :FASL-MD5 \"96b4a1143a316c6b2078b1a2b5e23bcf\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-directory.fasl\"
       :FASL-MD5 \"9e6b380b809e70553a3532230d211118\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-preflight.fasl\"
       :FASL-MD5 \"4281483199b879624ec34ba3a5476057\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-read.fasl\"
       :FASL-MD5 \"7c176eef5dc63d5396e8e821c0705253\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-scan.fasl\"
       :FASL-MD5 \"7eabeaef345faa90ebf90947b64c52d9\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-types.fasl\"
       :FASL-MD5 \"7cbbfc95a006e89db579fede7dd05224\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/build.fasl\"
       :FASL-MD5 \"d3a7b649e2d46f5a4dcf771ba0556d52\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/package.fasl\"
       :FASL-MD5 \"c950a25ca3de782f8f22dfc9158c0c4e\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/read.fasl\"
       :FASL-MD5 \"c3ea4ed2987b79200881fc03bfb58ad0\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/rows.fasl\"
       :FASL-MD5 \"18b3eb844530ac9fc4ca065aecce6b8d\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/scan.fasl\"
       :FASL-MD5 \"c287690291ad1a217a43f8ea4b5a1efc\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/sort.fasl\"
       :FASL-MD5 \"07cdce2b2b0f8b1f58c8ebb310a006a6\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/types.fasl\"
       :FASL-MD5 \"5da04d8828701c49f3a85cc27c131a6b\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/build.fasl\"
       :FASL-MD5 \"d159286342acbffebb713cfd51a0eae9\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/lifecycle.fasl\"
       :FASL-MD5 \"8db03100c0257e38241b87749f6d9717\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/lookup.fasl\"
       :FASL-MD5 \"edeffe0153cda13a112fc23373f63806\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/package.fasl\"
       :FASL-MD5 \"a84679081523c1ebe65d46fb220f9d14\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/segment.fasl\"
       :FASL-MD5 \"791740211e919ad7ac66ca404d420f04\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/target.fasl\"
       :FASL-MD5 \"b866c1e76ce062463bf5218a839622ba\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/types.fasl\"
       :FASL-MD5 \"fb198a3d79587e9241d9e167af86baf7\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/hash/arithmetic.fasl\"
       :FASL-MD5 \"2c49fa5f0dfe624592ba0c0a6a129219\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/hash/blocks.fasl\"
       :FASL-MD5 \"1b23b6b7298e967d09ead03484723eae\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/hash/hash64.fasl\"
       :FASL-MD5 \"669a2537398b418ac4e505eaddd30a0c\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/hash/package.fasl\"
       :FASL-MD5 \"9b64498249d2904e2de5f06a3f62719b\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/core.fasl\"
       :FASL-MD5 \"a47381778e14c05db34402233efeb349\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/hash-digests.fasl\"
       :FASL-MD5 \"879a85ddab901bfbcffdccf708482fed\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/hash-seed.fasl\"
       :FASL-MD5 \"09f15d0af5456904c82518a8c9a8852a\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/package.fasl\"
       :FASL-MD5 \"f1ea80f501127ffc19a588227179f07b\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-arena.fasl\"
       :FASL-MD5 \"3975b387cdc450c2c289e3fcd9137de8\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-build.fasl\"
       :FASL-MD5 \"ff5a02973d67ff748bf091f851669174\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-core.fasl\"
       :FASL-MD5 \"fd6dc9048a529b42f0a99283b18ca2ab\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-directory.fasl\"
       :FASL-MD5 \"4872d7d17f31829e0714c6ac379150f9\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-package.fasl\"
       :FASL-MD5 \"b0529e9281d9c22766b312548594a9f1\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-probe.fasl\"
       :FASL-MD5 \"ad468028b7b335f754a89c09f8593b8c\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-read.fasl\"
       :FASL-MD5 \"face36fbe90f41a1e18d83c40c14162b\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-relocate.fasl\"
       :FASL-MD5 \"7e8ba32ddcdaf5c41c63595b8fe469d9\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-types.fasl\"
       :FASL-MD5 \"6b6237d115a1ebf074181c6868eebd09\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-write.fasl\"
       :FASL-MD5 \"08aa1188c4338534a4e7d9ba7467d3ee\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/read.fasl\"
       :FASL-MD5 \"a9c82c2f693fec4bda8e0c1a43c35dbc\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-budget.fasl\"
       :FASL-MD5 \"5c400b1fc7d41d335b82fc1e9c4d978b\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-copy.fasl\"
       :FASL-MD5 \"1695fdeae49657f25cbe5c832fdb9864\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-scan.fasl\"
       :FASL-MD5 \"3de612a0363386e9c69339c91722f31b\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild.fasl\"
       :FASL-MD5 \"6636206e8869615bda474fa5ffdb91f3\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/relocate.fasl\"
       :FASL-MD5 \"f687db2117d66ce8027c9951fe32477c\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/types.fasl\"
       :FASL-MD5 \"cef9c3875afed939258fd8a4a1235d77\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/validation.fasl\"
       :FASL-MD5 \"a4e8edf93ce35dfc8c4a88e1d27282f6\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/write.fasl\"
       :FASL-MD5 \"b156bdd74fa4163b7f8ee5a677aa4cd9\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/flush.fasl\"
       :FASL-MD5 \"d8bae15eafff2f26253ca9b5ee4480e9\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/lifecycle.fasl\"
       :FASL-MD5 \"d85ac349a8f6074d3759437c619a8b59\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/native.fasl\"
       :FASL-MD5 \"28ecf767f8fb7d07ff1db7602c909b78\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/package.fasl\"
       :FASL-MD5 \"5392379c2bcd3a3dd80c82c9823d168d\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/transfer.fasl\"
       :FASL-MD5 \"3e23a71d3c562fe20abebbc0a15dc4b1\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/types.fasl\"
       :FASL-MD5 \"5cba7c87122f972f57f3d9e0d8dcb7bb\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/package.fasl\"
       :FASL-MD5 \"95a71e0cc68dd454df034fe8101ecf45\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-core.fasl\"
       :FASL-MD5 \"b9a6877d1df7fdff94322438af9a7158\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-csn.fasl\"
       :FASL-MD5 \"7e611afc01d7d15e20c74ab9af6df128\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-lifecycle.fasl\"
       :FASL-MD5 \"ce3ed58f1457b3536a8d39facb7f8e28\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-read.fasl\"
       :FASL-MD5 \"a9ebed892d8df0e62e3962ebc027fca5\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-register.fasl\"
       :FASL-MD5 \"e004caf96659b9562ba5b2c25fd341da\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-types.fasl\"
       :FASL-MD5 \"6dd39a2d36b581c9293950aa10becfc3\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/types.fasl\"
       :FASL-MD5 \"feb0d0b8409af6ddcd004d9c3652e7dc\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/package.fasl\"
       :FASL-MD5 \"d023e5b1e69cbe7691002e74ca632319\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/read/core.fasl\"
       :FASL-MD5 \"5b7b0f5d3748bd81ba92b865c1fa06ab\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/read/package.fasl\"
       :FASL-MD5 \"ef46f7ad417e9142ba52ac9494f64cce\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/read/task.fasl\"
       :FASL-MD5 \"c43b294eddae9ea9095dce8c80cff44b\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/read/types.fasl\"
       :FASL-MD5 \"d9fbb7c0e0d564d4d92984b48a849228\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-build.fasl\"
       :FASL-MD5 \"3d5011ef2a52ae2d8ac4eb566e575ad3\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-package.fasl\"
       :FASL-MD5 \"779f34c64ae07b58896c573e4dfbcdf4\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-query.fasl\"
       :FASL-MD5 \"bcd49d6c1b482ef65ffd32fdb39542fe\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-radix.fasl\"
       :FASL-MD5 \"4c827639429b332529b93c2d44fd79f4\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-sort.fasl\"
       :FASL-MD5 \"133bd60c58b2c4296ba2ea705b603602\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-types.fasl\"
       :FASL-MD5 \"b7f7dbc30263f5a107ba76b6f679ad49\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-build.fasl\"
       :FASL-MD5 \"e36117b44447aa66aa213ca6aba50734\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-query.fasl\"
       :FASL-MD5 \"a2a1b2aea8f729fa6f7a3ceb4b080c21\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-types.fasl\"
       :FASL-MD5 \"a2d054ce03254124b23192f3f4407aef\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-build.fasl\"
       :FASL-MD5 \"49b4f3ed06229c22bb598fbec42e2d5a\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-decode.fasl\"
       :FASL-MD5 \"4c1da374d7d82466eb6df19897891639\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-fold.fasl\"
       :FASL-MD5 \"12d258f6c0572a17e8c4c671c64d61e1\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-package.fasl\"
       :FASL-MD5 \"90aa5c281a788143792ecbc36cd05e6f\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-query.fasl\"
       :FASL-MD5 \"5706223e272467aab2e6d25d88e49a06\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-types.fasl\"
       :FASL-MD5 \"f27ae049d3d0ab5a6ebdca2ea9a6cfeb\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/package.fasl\"
       :FASL-MD5 \"a774f4eaef0dbb44bea2fb0f118d6ce0\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/scan.fasl\"
       :FASL-MD5 \"8e232cbc429feac53ffdcb4562d52c5d\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/events.fasl\"
       :FASL-MD5 \"a9b23a54d0552f71a0c627124a855782\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/io-events.fasl\"
       :FASL-MD5 \"34c997b9fc34680e87ae78ef444aca08\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/ownership.fasl\"
       :FASL-MD5 \"87be9aa09170427efec2f91f23f50ac9\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/package.fasl\"
       :FASL-MD5 \"0fb9caa52bb3aff4dd205cd37d893f16\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/publication.fasl\"
       :FASL-MD5 \"12c7ea2f7ea03ca3636d018aec1f6fe2\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/query.fasl\"
       :FASL-MD5 \"7925c97ba7283740c4f52b0c5a29b33a\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/retirement.fasl\"
       :FASL-MD5 \"3f2370a9cb4332d73ec726b4c2b42995\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-build.fasl\"
       :FASL-MD5 \"5778ec621451c3250a75fef973cffade\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-select.fasl\"
       :FASL-MD5 \"8d65dd623d44559c3462c368d5faf3cd\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-types.fasl\"
       :FASL-MD5 \"721d3a6624f41b65f009075d44db81cb\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/types.fasl\"
       :FASL-MD5 \"9f4ecfbe9fe6bf635774a3bbde550036\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-boundary.fasl\"
       :FASL-MD5 \"257af64dd67fd3e1b2c892d01213ab03\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-package.fasl\"
       :FASL-MD5 \"f263fc786d6553e9717eecb7534c6190\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-run.fasl\"
       :FASL-MD5 \"9b3a9ba2c6ddac51de732354f14d922c\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-types.fasl\"
       :FASL-MD5 \"aa17a8a541f9147f07a80c18e7dcbd42\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/compaction-scan.fasl\"
       :FASL-MD5 \"38a8f2dab98e9c2a95100e4c26c96dc1\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/control-payload.fasl\"
       :FASL-MD5 \"3644b8af966f6ca9ebae7488699b733c\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/formats.fasl\"
       :FASL-MD5 \"8f8a26ab4fdd903205a099f9ad7b9363\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/log-header.fasl\"
       :FASL-MD5 \"ac0687e4cc927883e8a8e2a6577c054d\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/package.fasl\"
       :FASL-MD5 \"e8e4a888edc5195b6840091ac488cafb\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/payload-record.fasl\"
       :FASL-MD5 \"4e26316d85cf66bcdba2c31e14fe0b3a\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/payload-write.fasl\"
       :FASL-MD5 \"4b376e3f603b2884ee97d30e2c8d9fba\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/segment-header.fasl\"
       :FASL-MD5 \"b1a2fa08a5c6c01bbe0602de69169a7c\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/builder.fasl\"
       :FASL-MD5 \"e3f7c287eefb65f3335d0a7ef0bcae8b\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/csn.fasl\"
       :FASL-MD5 \"24efb3955a20fafd764efbc25ff236c6\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/executor.fasl\"
       :FASL-MD5 \"c859ef436556ac3b6d76b002258c5d09\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/group.fasl\"
       :FASL-MD5 \"deb7be7ed8350a14f231dbde1060b893\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/package.fasl\"
       :FASL-MD5 \"721f55db54b07b358ba2a056b450e3be\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/types.fasl\"
       :FASL-MD5 \"fb88f3f3347c5aeabbfd29f86fadc035\"))
     :COMPILED-SUITE
     ((:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/foundation/support.fasl\"
       :FASL-MD5 \"6ae3175b59923ba593012660a54c137d\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/support.fasl\"
       :FASL-MD5 \"4c541cd1e5669f2c50af86914ac34aa8\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/construction.fasl\"
       :FASL-MD5 \"2cca0eb4d9c952dad3bf037113cc1e36\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/read.fasl\"
       :FASL-MD5 \"19023583ca4e35cf4c1c6b1cc9aafd2e\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/threads.fasl\"
       :FASL-MD5 \"d8c8b23ba4015b5afe6b233384ce36cf\"))
     :FAILED-TEST
     \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
     :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE \"SIMPLE-ERROR\"
     :DIAGNOSTIC \"Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (ARCDOCDB.GET.DIRECTORY:CREA-DIRECTORY-GET-SERIE
                       ARCDOCDB.GET.DIRECTORY.TESTS::COPY
                       (ARCDOCDB.GET.DIRECTORY.TESTS:DIRECTORY-FIXTURE-MAPS
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVALID-ARGUMENT (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :DIRECTORY-SOURCE-OWNER)))\"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . \"379f516cebb2691c0c32e27ab184b161\") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . \"db58ed1c3877f2d6ea58932d3bc75e56\") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   \"missing-location-first-map\" :FILE \"src/get-directory/read.lisp\" :DIRECTORY
   #A((143) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/\")
   :EXPECTED-FAILURE :MISSING-PUBLISHED-SEGMENT-AUTHORIZED :SUBSTITUTION
   (:BEFORE
    \"(when (= left right) (guasto-get context :directory-location-absent))\"
    :AFTER \"(when (= left right)
               (if (plusp (length maps))
                   (return-from cerca-mappa-directory-get
                     (the mappa-segmento-get (svref maps 0)))
                   (guasto-get context :directory-location-absent)))\")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   (\"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\")
   :SOURCE-MANIFEST
   ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5e1e1260d8364e7eb1549db37153364\"))
    (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
    (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
    (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
    (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
    (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
    (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
    (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
    (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
    (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
    (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
    (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3f19ffb4aacfdfe502c5e8b12a234f2\"))
    (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
    (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
    (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
    (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
    (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
    (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"200373402e6e082dd8c7afde305302bb\"))
    (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
    (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
    (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
    (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
    (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
    (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
    (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
    (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
    (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
    (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
    (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
    (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
    (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
    (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
    (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
    (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
    (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
    (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
    (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
    (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
    (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
    (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
    (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
    (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
    (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
    (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
    (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
    (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
    (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
    (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
    (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
    (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
    (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd12d0077a79f0c9c2f0a4dd01731f43\"))
    (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
    (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
    (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
    (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
    (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
    (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
    (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
    (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
    (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
    (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
    (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
    (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
    (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
    (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
    (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
    (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
    (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
    (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
    (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
    (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
    (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
    (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
    (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
    (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
    (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
    (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
    (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
    (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
    (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
    (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
    (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
    (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
    (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
    (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
    (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
    (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
    (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
    (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
    (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
    (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
    (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
    (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
    (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
    (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
    (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
    (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
    (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
    (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
    (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
    (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
    (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
    (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
    (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
    (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
    (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
    (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
    (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
    (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
    (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
    (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
    (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
    (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
    (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
    (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
    (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
    (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
    (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
    (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
    (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
    (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
    (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
    (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
    (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
    (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
    (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
    (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
    (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
    (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
    (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
    (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
    (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
    (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
    (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
    (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
    (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
    (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
    (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
    (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
    (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
    (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
    (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
    (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
    (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
    (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
    (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
    (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
    (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
    (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
    (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
    (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
    (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
    (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
    (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
    (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
    (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
    (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
    (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
    (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
    (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
    (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
    (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
    (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
    (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
    (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
    (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
    (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
    (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
    (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
   :COMPILED-TARGET
   (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    \"bd12d0077a79f0c9c2f0a4dd01731f43\" :FASL
    \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl\"
    :FASL-MD5 \"811607459e9ab3446a242baa097922eb\")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    (\"sbcl\" \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--disable-debugger\"
     \"--script\" \"isolated-build.lisp\")
    :STDOUT-LOG
    #A((153) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/stdout.log\")
    :STDERR-LOG
    #A((153) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/stderr.log\")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 6511759/1000000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/\"
     :SOURCE-MANIFEST
     ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
       \"b5e1e1260d8364e7eb1549db37153364\")
      (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3f19ffb4aacfdfe502c5e8b12a234f2\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\")
      (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"200373402e6e082dd8c7afde305302bb\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cde24b2bf5c5637d5501b95bed47df31\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd12d0077a79f0c9c2f0a4dd01731f43\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\")
      (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\"))
     :SUITE-FILES
     (\"tests/foundation/support.lisp\" \"tests/get-directory/support.lisp\"
      \"tests/get-directory/construction.lisp\" \"tests/get-directory/read.lisp\"
      \"tests/get-directory/threads.lisp\")
     :REGISTERED-TESTS
     (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
      \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
      \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
      \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
      \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
      \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
      \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
      \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
      \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
      \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
      \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
      \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
      \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
      \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
      \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
      \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
      \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
      \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
      \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
      \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
      \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
      \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
      \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
      \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
     :SELECTED-TEST
     \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bd12d0077a79f0c9c2f0a4dd01731f43\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl\"
      :FASL-MD5 \"811607459e9ab3446a242baa097922eb\")
     :COMPILED-PRODUCT
     ((:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/build.fasl\"
       :FASL-MD5 \"b02d6ca7bb024cf74cd20ac1dbe429d3\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/clock.fasl\"
       :FASL-MD5 \"9bcf8da9ce5742bbd403e20d2f8464f3\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/core.fasl\"
       :FASL-MD5 \"b5c57a3346a246b3e3c754fb94a0f12f\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/package.fasl\"
       :FASL-MD5 \"9911226b6dea70848c306260f0d9011e\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/read.fasl\"
       :FASL-MD5 \"839b62352f383439f27d02f04bb05b30\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/types.fasl\"
       :FASL-MD5 \"9883b14e23650447b16eb2f0e45e83d9\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/write.fasl\"
       :FASL-MD5 \"03ce66722ebeb7b49f96aec2b9613719\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-float-minimal.fasl\"
       :FASL-MD5 \"c83e4b5f6089d5c8f1c4c40138ad1da4\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-header.fasl\"
       :FASL-MD5 \"29fe6e95583fc9f52a2fe10e3e888905\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-minimal.fasl\"
       :FASL-MD5 \"98fb674c2596fd2efffdbbae30651878\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3f19ffb4aacfdfe502c5e8b12a234f2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-package.fasl\"
       :FASL-MD5 \"360e82897ee560169326125516069df7\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-input.fasl\"
       :FASL-MD5 \"8d0cc753b3869d9bcd311de738397086\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-items.fasl\"
       :FASL-MD5 \"33ec8fbadb9267ac8ff5f09ca1b98d34\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-minimal.fasl\"
       :FASL-MD5 \"b1290ae2174162571ed55a01f5c0c13e\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-stack.fasl\"
       :FASL-MD5 \"7e11aae26575717ed37bf8239fc3a7e5\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan.fasl\"
       :FASL-MD5 \"6535296f089bdec31c2993d0347a9eab\")
      (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"200373402e6e082dd8c7afde305302bb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-simple-write.fasl\"
       :FASL-MD5 \"ed2ff333410dcef4fe7d2aa08f57cbcc\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-space.fasl\"
       :FASL-MD5 \"df3ddf573be454579e058fa5bc8e06fa\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-string-write.fasl\"
       :FASL-MD5 \"27bca02e549779951a95bb0a7e787cbf\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-write.fasl\"
       :FASL-MD5 \"b6b33741165eba56e446b41a555952b5\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/package.fasl\"
       :FASL-MD5 \"23a9c67ad2a955fbca1dd58ab10541cc\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/utf8.fasl\"
       :FASL-MD5 \"68566b98480a8b77ee07db4be58b8266\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/csn/package.fasl\"
       :FASL-MD5 \"f625fe6fee7cd3b4e1591c0dec71cfb1\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/csn/registry.fasl\"
       :FASL-MD5 \"658cb95b65e768c97af8abaa67b4ec1c\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/core.fasl\"
       :FASL-MD5 \"889ab14bf558158601e6574c9a6cb451\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/package.fasl\"
       :FASL-MD5 \"cd4c4f673dedf62edf626bad2400632d\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/read.fasl\"
       :FASL-MD5 \"f5f65447b8a0f84f44b7cc500e6d1be7\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/reclaim.fasl\"
       :FASL-MD5 \"44067aca4695eba1d6a3a8153f31e8d2\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/retire.fasl\"
       :FASL-MD5 \"189c29532108fd611320903eb8106388\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/types.fasl\"
       :FASL-MD5 \"1c3f0215973ac536628450a82e735b55\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/handoff.fasl\"
       :FASL-MD5 \"b2aa378528ba8f4275b52173318092b6\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/package.fasl\"
       :FASL-MD5 \"41240eeb18d8bb3f97fb129fe8ea81ad\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/queue.fasl\"
       :FASL-MD5 \"9436642bf9a4853d97a5262b2fff8f3e\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready-recycle.fasl\"
       :FASL-MD5 \"f9643e2f155e69e5d7bc36f54718672f\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready-types.fasl\"
       :FASL-MD5 \"dd3dd6aa6070d7fd7a7f057418dd1b3b\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready.fasl\"
       :FASL-MD5 \"41638343d9270fd3c1a96359c169eda2\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-boundary.fasl\"
       :FASL-MD5 \"b1513f5ebedc9a1766b6153d8d69d21e\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-claim.fasl\"
       :FASL-MD5 \"e165fc474fb9a258f80865ff4f0c47d8\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-run.fasl\"
       :FASL-MD5 \"0243a87f41ad56b392dbae679f66f709\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-types.fasl\"
       :FASL-MD5 \"6ed14c46917c4454d7ef96b914eb1116\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/writer.fasl\"
       :FASL-MD5 \"8c438dd8c6a3cfb2eadd20e730912733\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/batch.fasl\"
       :FASL-MD5 \"79c9719a5036c9181ed6aa57d046b9c8\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/binary.fasl\"
       :FASL-MD5 \"87d2726dc64e746610adb46f352b0737\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/conditions.fasl\"
       :FASL-MD5 \"13e27519d15f4d4d0e57d3292565efa5\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/crc32c.fasl\"
       :FASL-MD5 \"7e906f6696d62005ac5b6a7359c469d8\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/package.fasl\"
       :FASL-MD5 \"b846cc52a0ba94f173c30c962b5a971a\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/record.fasl\"
       :FASL-MD5 \"b317a0cee10a7008caa27fd5793eb975\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cde24b2bf5c5637d5501b95bed47df31\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/build.fasl\"
       :FASL-MD5 \"73a76318fd7fedf37c8a18dc5bce1e56\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/package.fasl\"
       :FASL-MD5 \"60b906439b21437ed7dc57568c15145f\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd12d0077a79f0c9c2f0a4dd01731f43\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl\"
       :FASL-MD5 \"811607459e9ab3446a242baa097922eb\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/types.fasl\"
       :FASL-MD5 \"dc3b0184dcbe1dbd1a605577f5c90aae\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-build.fasl\"
       :FASL-MD5 \"781b11647a66b5f866e323995bdbdef9\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-directory.fasl\"
       :FASL-MD5 \"3eb16449838175cf81ac336e4411dc19\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-preflight.fasl\"
       :FASL-MD5 \"672305d1bb65bf9b5d51aaa649fe4374\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-read.fasl\"
       :FASL-MD5 \"68377524ede71036ae972ac42ae1104b\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-scan.fasl\"
       :FASL-MD5 \"95174d58607ca5411fe017f853d8fe58\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-types.fasl\"
       :FASL-MD5 \"28fda7954b9a8272172228e18b6c0199\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/build.fasl\"
       :FASL-MD5 \"90fc630863a3c20dd05f15a76a353ba5\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/package.fasl\"
       :FASL-MD5 \"4c25278dc9348a16793026667e4c40ce\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/read.fasl\"
       :FASL-MD5 \"e4b07f05e429292520028074b3167d25\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/rows.fasl\"
       :FASL-MD5 \"a92743603873320ae09bbdac00350edf\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/scan.fasl\"
       :FASL-MD5 \"1327a84e8ac23b721fc92a02b3ecaa49\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/sort.fasl\"
       :FASL-MD5 \"24dbb908f03f0f1b3fad07b9b46c1c60\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/types.fasl\"
       :FASL-MD5 \"4785bd0e6ec7dd4147a97672e1bae7c4\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/build.fasl\"
       :FASL-MD5 \"b2c2a8a902aa97e02f5c6529dbcc82d3\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/lifecycle.fasl\"
       :FASL-MD5 \"19c819788a912548f5f06fb35397b148\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/lookup.fasl\"
       :FASL-MD5 \"00378dde1d9fad429a66844d7cfee890\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/package.fasl\"
       :FASL-MD5 \"9bc220d5f2f64bbe0640d4638556a8c7\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/segment.fasl\"
       :FASL-MD5 \"c925f6fdb1b0ccce64093f38b6381bdb\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/target.fasl\"
       :FASL-MD5 \"5be1499b3c703184dcb61ecc1852d033\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/types.fasl\"
       :FASL-MD5 \"5ef76ab8ea86555a8c0c64670f47d6fd\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/hash/arithmetic.fasl\"
       :FASL-MD5 \"c15ffe968e7138bd0beaf879205fd931\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/hash/blocks.fasl\"
       :FASL-MD5 \"e23300ce6cd4e6fa026233b04754d3ba\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/hash/hash64.fasl\"
       :FASL-MD5 \"a6094fbb46bd333ba2d4f8ccb0e16b5e\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/hash/package.fasl\"
       :FASL-MD5 \"f3200a579950303cb33375a3850292c9\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/core.fasl\"
       :FASL-MD5 \"41e25af714b754b100a58ca3826779fe\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/hash-digests.fasl\"
       :FASL-MD5 \"c6b4343071bebcfe7637ca3c7355db3a\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/hash-seed.fasl\"
       :FASL-MD5 \"62504b79fcadd35868e810bacc682819\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/package.fasl\"
       :FASL-MD5 \"aed7bf87558f618e18eb2e33e846d9bf\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-arena.fasl\"
       :FASL-MD5 \"dd2ece60cadb50f4e9a86f85212a0ada\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-build.fasl\"
       :FASL-MD5 \"524bdb9815910bb5110e1a89a75414d4\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-core.fasl\"
       :FASL-MD5 \"5b7d179a29a94e0c96ebd051a64111f1\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-directory.fasl\"
       :FASL-MD5 \"693e8582581b83a8e0e1f898cc834a13\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-package.fasl\"
       :FASL-MD5 \"1e58bd1d815dacfff845c2bcda90e504\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-probe.fasl\"
       :FASL-MD5 \"0d24dbd9d80219644f05f836e96cf77c\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-read.fasl\"
       :FASL-MD5 \"b82b1ee4e70aac544e5c5c72360ddf4b\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-relocate.fasl\"
       :FASL-MD5 \"d6cf783638e810a021bb4f385d335a10\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-types.fasl\"
       :FASL-MD5 \"bdbebc38df9db6a4310bad560afb5240\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-write.fasl\"
       :FASL-MD5 \"a4e4a2b03577117b737a983795708421\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/read.fasl\"
       :FASL-MD5 \"4292af75ea212ebc83ffe42ce9ee277d\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-budget.fasl\"
       :FASL-MD5 \"ac219c0e660517c72f9ed6dfe7ecd670\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-copy.fasl\"
       :FASL-MD5 \"80166c61ce8eb613c2826e85130abc91\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-scan.fasl\"
       :FASL-MD5 \"d8ba12886627fcf097a43c06a72db627\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild.fasl\"
       :FASL-MD5 \"49e09058658872f1cb00f2f8f85e4f53\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/relocate.fasl\"
       :FASL-MD5 \"5868322758b2112a4a277e262b2de5c7\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/types.fasl\"
       :FASL-MD5 \"f126f5fb43c2ce643011e19c523691ae\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/validation.fasl\"
       :FASL-MD5 \"6d27a961aad9478df565da0bbeebcb01\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/write.fasl\"
       :FASL-MD5 \"c94535cb251aa1581fe9dad06e65189f\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/flush.fasl\"
       :FASL-MD5 \"402e073742473cedbad5f5c31ba7c3bc\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/lifecycle.fasl\"
       :FASL-MD5 \"d6c866c25197d4ba7671dc9d4dd00088\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/native.fasl\"
       :FASL-MD5 \"20821dabddd29a21cc93f22e5a47fc23\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/package.fasl\"
       :FASL-MD5 \"c31f97a9a834492338352b54d3cb76fe\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/transfer.fasl\"
       :FASL-MD5 \"47db5dedf281fb57647512fb26195c10\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/types.fasl\"
       :FASL-MD5 \"9b4dc5206b3198dc93477b3da8713c46\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/package.fasl\"
       :FASL-MD5 \"58c591ac71c44a1daa298a958b94188f\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-core.fasl\"
       :FASL-MD5 \"759aee4169e0dfcb9c460589d8de028c\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-csn.fasl\"
       :FASL-MD5 \"b6830456645ab79a179a121119bb219f\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-lifecycle.fasl\"
       :FASL-MD5 \"4e4520cbdc023b7e5b2c5f6f4cf79894\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-read.fasl\"
       :FASL-MD5 \"8c3fbbb0107a22662a14f5fc9ec21838\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-register.fasl\"
       :FASL-MD5 \"f8d7a2c00fef491c1dbd9c9321114ea5\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-types.fasl\"
       :FASL-MD5 \"903e898d2b2434f27902c4e2c53b5f6c\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/types.fasl\"
       :FASL-MD5 \"be0fd75d1d94020bc45f3703ff3734e3\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/package.fasl\"
       :FASL-MD5 \"2a49876705d1a6ca22f2f4625a6236c4\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/read/core.fasl\"
       :FASL-MD5 \"0f186935cac262d817f6134121cfc5f7\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/read/package.fasl\"
       :FASL-MD5 \"0ba6045c6dcbdf5027169f3b93cde3d3\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/read/task.fasl\"
       :FASL-MD5 \"3493dd76978277941aac3fd1c1b529e6\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/read/types.fasl\"
       :FASL-MD5 \"071001eddec42b0ef163989eb4a9a6b5\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-build.fasl\"
       :FASL-MD5 \"39b07191b53c69657b0404e3e24974e1\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-package.fasl\"
       :FASL-MD5 \"c756fa5d37ed7ad9c5594d775042342a\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-query.fasl\"
       :FASL-MD5 \"c9aa10ff7cf3398bd0dcc3d7e3b04b81\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-radix.fasl\"
       :FASL-MD5 \"43dd68a21f1339051100d6cc04b1b47f\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-sort.fasl\"
       :FASL-MD5 \"10200d268e758bae15ba34ff4f50542a\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-types.fasl\"
       :FASL-MD5 \"ee45d51cd5ae03261d71c407b7d88e71\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-build.fasl\"
       :FASL-MD5 \"cf81ca7473efa5d8803d03068cdcab00\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-query.fasl\"
       :FASL-MD5 \"10fdf7973673c5c3413f3d2e831def3a\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-types.fasl\"
       :FASL-MD5 \"b09c78871a371c97d61841172bf91f50\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-build.fasl\"
       :FASL-MD5 \"6b9fe849adb58559151d875837bafee6\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-decode.fasl\"
       :FASL-MD5 \"cd40b2b6c146af32e824ab13226e757b\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-fold.fasl\"
       :FASL-MD5 \"f991ce6510d33ce0189f2b83e361283e\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-package.fasl\"
       :FASL-MD5 \"af0cfd8588703fd513f4e72adcca4ef1\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-query.fasl\"
       :FASL-MD5 \"4d42ab875e7b9c2a53c064cfb6d632ea\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-types.fasl\"
       :FASL-MD5 \"5b3b65133fe97d8d9774af2e4b1da73e\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/package.fasl\"
       :FASL-MD5 \"b1d89ccb71be35451f471f1756bdfc79\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/scan.fasl\"
       :FASL-MD5 \"6d7aae930dec65711516349374a005f4\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/events.fasl\"
       :FASL-MD5 \"3d8c4ddf26ef2065c02b4a198fef33d5\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/io-events.fasl\"
       :FASL-MD5 \"029caea504f3a110c7a9255312f8aab4\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/ownership.fasl\"
       :FASL-MD5 \"7ffa7b8bd63f73aeedd4d6521a16eb8c\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/package.fasl\"
       :FASL-MD5 \"1081449c95d25576e8e41f4f053b84a2\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/publication.fasl\"
       :FASL-MD5 \"606bcac63cfd1f59aa28613800a6ca39\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/query.fasl\"
       :FASL-MD5 \"d30ce85d85088ef55c760b67bd280a6d\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/retirement.fasl\"
       :FASL-MD5 \"9db8cf7707d369d843d6cf69902745ca\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-build.fasl\"
       :FASL-MD5 \"186361beccbca1e94b0ec83df8b35784\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-select.fasl\"
       :FASL-MD5 \"301f1f17d398aa058ee8e6549a64e871\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-types.fasl\"
       :FASL-MD5 \"f78efb658271f5788d02c72bd56bd936\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/types.fasl\"
       :FASL-MD5 \"8fed182069e079a280c55b9aa1ef7864\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-boundary.fasl\"
       :FASL-MD5 \"37e2573f1e5bac1ee6e58b009b830a4a\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-package.fasl\"
       :FASL-MD5 \"1d3b8025cc009e3bb44b0730c4eeac29\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-run.fasl\"
       :FASL-MD5 \"a670c89dea5c1fff2b666237112a456a\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-types.fasl\"
       :FASL-MD5 \"5df7d4e324744540f068dfefc572dea0\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/compaction-scan.fasl\"
       :FASL-MD5 \"7fdca8176434134bdd6c9e5a74e9c26a\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/control-payload.fasl\"
       :FASL-MD5 \"879e72d7229ad32ddd1c0d3df8a4375e\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/formats.fasl\"
       :FASL-MD5 \"85397514b05380cfd53f9a995bd13840\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/log-header.fasl\"
       :FASL-MD5 \"85396ed67ffb7f99ebae994e0d557fa1\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/package.fasl\"
       :FASL-MD5 \"85ec8a80610fd47e8e49044b1fbc4401\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/payload-record.fasl\"
       :FASL-MD5 \"4deea68fc28b458c99aab6cc603d3d8a\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/payload-write.fasl\"
       :FASL-MD5 \"fc935fb86674f44f1dd7db37401c625e\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/segment-header.fasl\"
       :FASL-MD5 \"478253c6723e73f648d98410184931e4\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/builder.fasl\"
       :FASL-MD5 \"07b4def5d4d414a603164d78da914062\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/csn.fasl\"
       :FASL-MD5 \"9eedda7c0fc0869d577c68112096829b\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/executor.fasl\"
       :FASL-MD5 \"a3b615294fdd265be14d70a4a8b3bf5c\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/group.fasl\"
       :FASL-MD5 \"35fd2a7c66852e068b06265d1206cdec\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/package.fasl\"
       :FASL-MD5 \"2d4bc531bb4fa3e246be240698ed3df3\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/types.fasl\"
       :FASL-MD5 \"a4cc525771adc7e60b585ea2f2667344\"))
     :COMPILED-SUITE
     ((:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/foundation/support.fasl\"
       :FASL-MD5 \"b6ca8836931158c5bed41752672b2174\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/support.fasl\"
       :FASL-MD5 \"3535f847c69ed377e089d7202976695e\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/construction.fasl\"
       :FASL-MD5 \"0bda601ec36b6f81d6a4eaa3fbd8a835\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/read.fasl\"
       :FASL-MD5 \"d7f68d7a63df505da55547e058ac19b8\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/threads.fasl\"
       :FASL-MD5 \"d2f8ff497b118b6cb1141e5bde386497\"))
     :FAILED-TEST
     \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
     :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE \"SIMPLE-ERROR\"
     :DIAGNOSTIC \"Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (PROGN
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-CALL-OPERATION
                        ARCDOCDB.GET.DIRECTORY.TESTS::OPERATION
                        ARCDOCDB.GET.DIRECTORY.TESTS::CONTEXT DIRECTORY)
                       (SETF ARCDOCDB.GET.DIRECTORY.TESTS::AUTHORIZED T))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVARIANT-VIOLATION (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :DIRECTORY-LOCATION-ABSENT)))\"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . \"dafc6cdbd71746f79369cd04151fb7d0\") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . \"bd12d0077a79f0c9c2f0a4dd01731f43\") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   \"alias-input-maps\" :FILE \"src/get-directory/build.lisp\" :DIRECTORY
   #A((133) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/\")
   :EXPECTED-FAILURE :CALLER-ARRAY-CHANGES-DIRECTORY :SUBSTITUTION
   (:BEFORE \"(owned (copy-seq maps))\" :AFTER \"(owned maps)\") :STATUS :OK
   :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   (\"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\") :SOURCE-MANIFEST
   ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5e1e1260d8364e7eb1549db37153364\"))
    (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
    (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
    (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
    (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
    (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
    (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
    (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
    (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
    (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
    (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
    (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3f19ffb4aacfdfe502c5e8b12a234f2\"))
    (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
    (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
    (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
    (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
    (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
    (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"200373402e6e082dd8c7afde305302bb\"))
    (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
    (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
    (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
    (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
    (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
    (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
    (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
    (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
    (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
    (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
    (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
    (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
    (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
    (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
    (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
    (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
    (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
    (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
    (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
    (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
    (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
    (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
    (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
    (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
    (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
    (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
    (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
    (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
    (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
    (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
    (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd0d166bfeee41dc15f53c57586a3d0d\"))
    (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
    (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"74a694385f1aaf03ec87721545494119\"))
    (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
    (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
    (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
    (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
    (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
    (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
    (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
    (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
    (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
    (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
    (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
    (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
    (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
    (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
    (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
    (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
    (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
    (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
    (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
    (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
    (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
    (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
    (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
    (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
    (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
    (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
    (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
    (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
    (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
    (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
    (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
    (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
    (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
    (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
    (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
    (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
    (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
    (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
    (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
    (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
    (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
    (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
    (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
    (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
    (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
    (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
    (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
    (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
    (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
    (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
    (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
    (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
    (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
    (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
    (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
    (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
    (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
    (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
    (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
    (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
    (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
    (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
    (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
    (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
    (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
    (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
    (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
    (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
    (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
    (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
    (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
    (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
    (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
    (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
    (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
    (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
    (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
    (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
    (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
    (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
    (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
    (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
    (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
    (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
    (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
    (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
    (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
    (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
    (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
    (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
    (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
    (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
    (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
    (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
    (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
    (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
    (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
    (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
    (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
    (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
    (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
    (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
    (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
    (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
    (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
    (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
    (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
    (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
    (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
    (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
    (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
    (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
    (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
    (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
    (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
    (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
    (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
    (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
   :COMPILED-TARGET
   (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    \"bd0d166bfeee41dc15f53c57586a3d0d\" :FASL
    \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/build.fasl\"
    :FASL-MD5 \"70c53470eed0d0e84519f26ea68f419c\")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    (\"sbcl\" \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--disable-debugger\"
     \"--script\" \"isolated-build.lisp\")
    :STDOUT-LOG
    #A((143) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/stdout.log\")
    :STDERR-LOG
    #A((143) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/stderr.log\")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 5913239/1000000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/\"
     :SOURCE-MANIFEST
     ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
       \"b5e1e1260d8364e7eb1549db37153364\")
      (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3f19ffb4aacfdfe502c5e8b12a234f2\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\")
      (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"200373402e6e082dd8c7afde305302bb\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd0d166bfeee41dc15f53c57586a3d0d\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"74a694385f1aaf03ec87721545494119\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\")
      (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\"))
     :SUITE-FILES
     (\"tests/foundation/support.lisp\" \"tests/get-directory/support.lisp\"
      \"tests/get-directory/construction.lisp\" \"tests/get-directory/read.lisp\"
      \"tests/get-directory/threads.lisp\")
     :REGISTERED-TESTS
     (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
      \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
      \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
      \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
      \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
      \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
      \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
      \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
      \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
      \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
      \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
      \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
      \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
      \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
      \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
      \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
      \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
      \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
      \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
      \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
      \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
      \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
      \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
      \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
     :SELECTED-TEST \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"bd0d166bfeee41dc15f53c57586a3d0d\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/build.fasl\"
      :FASL-MD5 \"70c53470eed0d0e84519f26ea68f419c\")
     :COMPILED-PRODUCT
     ((:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/build.fasl\"
       :FASL-MD5 \"c8699523bc3459b0a77f9f8cecef7203\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/clock.fasl\"
       :FASL-MD5 \"6b55b5904f25bea965b165eb79df6770\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/core.fasl\"
       :FASL-MD5 \"1232f7b038b3f49789029b39c8b3353d\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/package.fasl\"
       :FASL-MD5 \"7426304d94606eb7c47d5558b84b6dd4\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/read.fasl\"
       :FASL-MD5 \"633689bc1f90bc94d6bf71577e1ca0e0\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/types.fasl\"
       :FASL-MD5 \"3848e03b4470ede9a66f7f0bd47f7dfb\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/write.fasl\"
       :FASL-MD5 \"88a016f1f369f407ab6970842204f5a3\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-float-minimal.fasl\"
       :FASL-MD5 \"80a34707e2eb49fa8b05116f85d391ad\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-header.fasl\"
       :FASL-MD5 \"9a0cb3f510cd602c4ba28fa050be9c23\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-minimal.fasl\"
       :FASL-MD5 \"8d69ff3debe1426c1756bc3f7ec7e0dd\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3f19ffb4aacfdfe502c5e8b12a234f2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-package.fasl\"
       :FASL-MD5 \"c200e61a9071ec524c5aaa45ddc94cc7\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-input.fasl\"
       :FASL-MD5 \"bbb05b5df32ba0b275a3873fabf047ed\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-items.fasl\"
       :FASL-MD5 \"85c49369c85e2df1bfc6f7ab96ef9321\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-minimal.fasl\"
       :FASL-MD5 \"7ef9ee4132b667068cdb4db169e26e59\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-stack.fasl\"
       :FASL-MD5 \"6a49f16375d1458819013afddb5b2c3e\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan.fasl\"
       :FASL-MD5 \"cdec575a4f91189369e43dc1ad070f09\")
      (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"200373402e6e082dd8c7afde305302bb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-simple-write.fasl\"
       :FASL-MD5 \"12fc514522f802de24dc6cb19a25b757\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-space.fasl\"
       :FASL-MD5 \"637ca639cbf64e82b1e1047542bcf3f4\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-string-write.fasl\"
       :FASL-MD5 \"75e7cced8e3c46cf2e64c5742450bb57\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-write.fasl\"
       :FASL-MD5 \"82b1f757138dd40c4a44b3f326314204\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/package.fasl\"
       :FASL-MD5 \"3ee314f271d513d7347feee4e6baa629\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/utf8.fasl\"
       :FASL-MD5 \"bb08ba5de6e37afa0cd71c408b53122b\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/csn/package.fasl\"
       :FASL-MD5 \"85ca7ad520306759fa4f45fdcfa4666a\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/csn/registry.fasl\"
       :FASL-MD5 \"ad345a971be234ad4b147a9c43d9231d\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/epochs/core.fasl\"
       :FASL-MD5 \"a633a79a634cae75d393ca38c003c3e9\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/epochs/package.fasl\"
       :FASL-MD5 \"96edc4be9f68f355f767514148cbe1dc\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/epochs/read.fasl\"
       :FASL-MD5 \"e7e6654654fca3794151ca5a666942af\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/epochs/reclaim.fasl\"
       :FASL-MD5 \"50bd72310a0325c0dc3c35a40f13abaa\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/epochs/retire.fasl\"
       :FASL-MD5 \"a1eb0b0a8a009265961ac40d918ae7da\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/epochs/types.fasl\"
       :FASL-MD5 \"327c4749543e73001f1d5daec0dfe41a\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/handoff.fasl\"
       :FASL-MD5 \"c1f3498b260d7b5d8b5d9fef7f4cead4\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/package.fasl\"
       :FASL-MD5 \"93d7d3127ca158aad8b5f2663f8eca3f\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/queue.fasl\"
       :FASL-MD5 \"fb5b6b72beabbbd605b7df5c0683240f\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/ready-recycle.fasl\"
       :FASL-MD5 \"0765f458dbf8864e87d7b5cc9b734196\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/ready-types.fasl\"
       :FASL-MD5 \"6a87e60fbc3f98108f28162e8a2dd919\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/ready.fasl\"
       :FASL-MD5 \"cd439014297cd332ff66d05fcc239a12\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-boundary.fasl\"
       :FASL-MD5 \"33376b886fd2efc6e91f6991fe8422c9\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-claim.fasl\"
       :FASL-MD5 \"2d0342f95aa0fdb388b03a4d64501d2a\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-run.fasl\"
       :FASL-MD5 \"97618c863c4350b6def98ddd3bc162a1\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-types.fasl\"
       :FASL-MD5 \"7ad261513d5e26a574e80651a62cbd4c\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/writer.fasl\"
       :FASL-MD5 \"65f1a0d7bbea718f6768893b30275b44\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/foundation/batch.fasl\"
       :FASL-MD5 \"0ba94e604ffa66ff9cb970cc9de9e7b7\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/foundation/binary.fasl\"
       :FASL-MD5 \"e21812e298276195cefb483aa7464110\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/foundation/conditions.fasl\"
       :FASL-MD5 \"05acf3afdd4166a7d56b95e58178cae4\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/foundation/crc32c.fasl\"
       :FASL-MD5 \"e7a1f08c71ba97d325ca890f8ed18391\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/foundation/package.fasl\"
       :FASL-MD5 \"cb3f265085d8629abb46dd20b7949fa7\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/foundation/record.fasl\"
       :FASL-MD5 \"abb6e9fa8c4a04f914f109bd3112bbf8\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd0d166bfeee41dc15f53c57586a3d0d\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/build.fasl\"
       :FASL-MD5 \"70c53470eed0d0e84519f26ea68f419c\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/package.fasl\"
       :FASL-MD5 \"f531c0bf787750e31f6145671fac6066\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"74a694385f1aaf03ec87721545494119\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/read.fasl\"
       :FASL-MD5 \"5c0bd9e4ad76c168a7d63bd043862ee8\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/types.fasl\"
       :FASL-MD5 \"2e487bdca15b52f1fa69e93aa0fd57cc\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-build.fasl\"
       :FASL-MD5 \"adf608d6a2082e1aedc887688b9760de\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-directory.fasl\"
       :FASL-MD5 \"9d79d001a5e3cffe76eb0fd7464eeab5\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-preflight.fasl\"
       :FASL-MD5 \"5b271de07f19ea8493751116d2db8eb5\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-read.fasl\"
       :FASL-MD5 \"08c4d246abdb276e79dc609125b7a8a8\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-scan.fasl\"
       :FASL-MD5 \"a305ced450a049d240a6cc00e7488dc7\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-types.fasl\"
       :FASL-MD5 \"c6be5fcd818abf1b80ff2bbbbdb35394\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/build.fasl\"
       :FASL-MD5 \"7f1cbabe5b47d6e94aa52f6dac10205f\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/package.fasl\"
       :FASL-MD5 \"68816fc0a7902bf303f9400adb8c9d9d\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/read.fasl\"
       :FASL-MD5 \"2631ddfc7ea4bc9cf1423e4556e8436d\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/rows.fasl\"
       :FASL-MD5 \"cb521035f07b969496b7db65b7e0c2e9\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/scan.fasl\"
       :FASL-MD5 \"cbb3708628109bd3a5da3da30ac8e4c8\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/sort.fasl\"
       :FASL-MD5 \"281c37780b875207e8f24e5d996ba33e\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/types.fasl\"
       :FASL-MD5 \"739334dcf728421140a2e60aed2652ee\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/build.fasl\"
       :FASL-MD5 \"f19319828c98fb47e1fb928ecde6c655\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/lifecycle.fasl\"
       :FASL-MD5 \"4aaa6c422b6fb395e54b497f6ba9b0fe\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/lookup.fasl\"
       :FASL-MD5 \"8bf7e65de31c424164e0af803873a558\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/package.fasl\"
       :FASL-MD5 \"6f94a561b4d69de73fe2f38df9e9d9a7\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/segment.fasl\"
       :FASL-MD5 \"a72ca47e871da35a662132fce593d8ab\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/target.fasl\"
       :FASL-MD5 \"dfb09cf166e6b081c36656aaf32eb77a\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/types.fasl\"
       :FASL-MD5 \"f0e4eb7a547b10e220903e9e1eb188b8\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/hash/arithmetic.fasl\"
       :FASL-MD5 \"1b7e73f087400e80bdd35c6b398b9ab3\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/hash/blocks.fasl\"
       :FASL-MD5 \"636b3f11d0a57c77d9a8bc0583d89278\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/hash/hash64.fasl\"
       :FASL-MD5 \"5a5b734f51febcc19eab80e7c95c4906\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/hash/package.fasl\"
       :FASL-MD5 \"f43410dae712b6a79d0cf6708f6e7f1e\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/core.fasl\"
       :FASL-MD5 \"256c990a30a301a60c5a8eaee2b9c3fd\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/hash-digests.fasl\"
       :FASL-MD5 \"c5901f65c97161199d72c22519a042ce\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/hash-seed.fasl\"
       :FASL-MD5 \"9c908732bc1430ad7fe348b98d1edf69\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/package.fasl\"
       :FASL-MD5 \"5f11bf0a9d4009fc39df142f9d4ea8a2\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-arena.fasl\"
       :FASL-MD5 \"60145d3a9fd3ba4f47c924e45a30fb56\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-build.fasl\"
       :FASL-MD5 \"f3281ae7e3fe3553fba77493c646e1e6\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-core.fasl\"
       :FASL-MD5 \"d3657f8d70ee36683370a628d95a35be\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-directory.fasl\"
       :FASL-MD5 \"122c2d3b3d7b89feda3557dc900faff7\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-package.fasl\"
       :FASL-MD5 \"708233d88d8edf8a8e46555776de4ca1\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-probe.fasl\"
       :FASL-MD5 \"475c45a9ad0ef6aefb451d1000adcffb\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-read.fasl\"
       :FASL-MD5 \"9f9a897734c51acb823162df4e16c27c\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-relocate.fasl\"
       :FASL-MD5 \"03a211ea764a11a4fb8c89490c155da5\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-types.fasl\"
       :FASL-MD5 \"6e8b7bcb0989e75659b555be14a51571\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-write.fasl\"
       :FASL-MD5 \"f0d1c9f9dabcb9de9a95169fa87f5107\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/read.fasl\"
       :FASL-MD5 \"ff8049a54e07314acc8dff3df1e910e1\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild-budget.fasl\"
       :FASL-MD5 \"16fd97f708f60b2a156add50728ca222\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild-copy.fasl\"
       :FASL-MD5 \"dc389f6080c8501198011ce105815288\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild-scan.fasl\"
       :FASL-MD5 \"de2149e3c867d2b63804d2c9d5eb03b6\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild.fasl\"
       :FASL-MD5 \"79bb242251e9da2c476e678ddb6a3da4\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/relocate.fasl\"
       :FASL-MD5 \"7602f17a284a5318b27c2cd64550a419\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/types.fasl\"
       :FASL-MD5 \"84630e0b218674bda738303afd3a4cd3\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/validation.fasl\"
       :FASL-MD5 \"b645ff072dd958576a51a0a59d987c96\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/write.fasl\"
       :FASL-MD5 \"9080b80c7455cf88504c86c2eb127a9a\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/io/flush.fasl\"
       :FASL-MD5 \"c7bdcf51513f8cca5912f7c6e9326b35\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/io/lifecycle.fasl\"
       :FASL-MD5 \"a7f7bf18640f5a1962de0adfca7e58dd\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/io/native.fasl\"
       :FASL-MD5 \"d4cfb48a1ed0265531b37905d1dbf3b1\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/io/package.fasl\"
       :FASL-MD5 \"509a411521953abeb177c885afa9ed3e\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/io/transfer.fasl\"
       :FASL-MD5 \"5fe793788879caf168e1c1975eae17b3\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/io/types.fasl\"
       :FASL-MD5 \"31dfc65c90ed39a8e80ef7d572b39197\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/package.fasl\"
       :FASL-MD5 \"54ff5604a21f83e1087c30267fde4bb8\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-core.fasl\"
       :FASL-MD5 \"07cf8e7468395ec94f02b6ced8427cca\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-csn.fasl\"
       :FASL-MD5 \"b909ac2a3a70712b705503142b16c616\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-lifecycle.fasl\"
       :FASL-MD5 \"2f76e7d583aa57f74591b28f28a74b85\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-read.fasl\"
       :FASL-MD5 \"0b73358f37bf749f1775badaf408ca93\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-register.fasl\"
       :FASL-MD5 \"0182eccc2b5ec43b8cfb5d43640097ee\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-types.fasl\"
       :FASL-MD5 \"1817fce0d10fdc3d4b75dcc3091fa960\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/types.fasl\"
       :FASL-MD5 \"2625601d151d0bfb65811b5e2fb6e997\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/package.fasl\"
       :FASL-MD5 \"e01e8abcaa0c01bfd884c8aabcbe4c07\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/read/core.fasl\"
       :FASL-MD5 \"e0e5c3117ad68c15ca676eda749d433b\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/read/package.fasl\"
       :FASL-MD5 \"59c1c05d234bd49b421eff2232188439\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/read/task.fasl\"
       :FASL-MD5 \"3a3b9bdcfcda8f6e98aa04487d84c16d\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/read/types.fasl\"
       :FASL-MD5 \"6657aa01d6093e44469ebfe35fe7378d\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-build.fasl\"
       :FASL-MD5 \"05d989b183ff88b4fbf900f14688f5d4\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-package.fasl\"
       :FASL-MD5 \"ac2abadb735e6a477f668bbe54bfa44f\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-query.fasl\"
       :FASL-MD5 \"ecfe530f04a92175007a30698c730e61\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-radix.fasl\"
       :FASL-MD5 \"2134e25dd5fdea3306f3809362f99476\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-sort.fasl\"
       :FASL-MD5 \"3cedcb751de37c0de2c618fb888ee547\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-types.fasl\"
       :FASL-MD5 \"5ff32f60d47f58f56cbe5dfab255020f\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/inventory-build.fasl\"
       :FASL-MD5 \"0b5edd146a714491dc0295273cf12564\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/inventory-query.fasl\"
       :FASL-MD5 \"db1058988f7c145c182f7d7e076749f2\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/inventory-types.fasl\"
       :FASL-MD5 \"9ce9b14f1b32f5db53928ac61174fca9\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-build.fasl\"
       :FASL-MD5 \"cb2b05052739a99d7616823e947d3ff9\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-decode.fasl\"
       :FASL-MD5 \"4d3949908112449cf95d1d20c150195d\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-fold.fasl\"
       :FASL-MD5 \"3bc90448dca241c439ed1596cdd0c618\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-package.fasl\"
       :FASL-MD5 \"746e97c8d53034eab57e60c09cd71cd4\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-query.fasl\"
       :FASL-MD5 \"ed63820d6853abae5b71584dd496c6ef\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-types.fasl\"
       :FASL-MD5 \"16a235a566e5ce9a6fc0ae7048ecdea5\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/package.fasl\"
       :FASL-MD5 \"527d9a56fe26fec15ed3436f313c8cfb\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/scan.fasl\"
       :FASL-MD5 \"b2d9ee71e6b4ed1bfec0bbef700da31a\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/events.fasl\"
       :FASL-MD5 \"585eb28c53c5bcc3d34257e71c945b90\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/io-events.fasl\"
       :FASL-MD5 \"2b29c8d2f2dca5704ee745226c53df51\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/ownership.fasl\"
       :FASL-MD5 \"b2b14efbae548dfc64fc9de7e06372d0\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/package.fasl\"
       :FASL-MD5 \"e8b359065e102731bf88ffaff69f2e38\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/publication.fasl\"
       :FASL-MD5 \"e6d96a63c6f2df5ed37dc5a66123ca6b\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/query.fasl\"
       :FASL-MD5 \"c0cd9d4ee7eed3579b3ec3e1cabe547d\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/retirement.fasl\"
       :FASL-MD5 \"ca1257c5251404ea1c7e13e12973c944\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/routing-build.fasl\"
       :FASL-MD5 \"7e9a88b96eac5b56c766c4950c2161e3\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/routing-select.fasl\"
       :FASL-MD5 \"22fe90c3f1756cd1cdb44900b3854a6a\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/routing-types.fasl\"
       :FASL-MD5 \"f877de4f60990aa80fb6848a8748e502\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/types.fasl\"
       :FASL-MD5 \"7d3a1973925b1ca1c33ae76d0fcf6686\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-boundary.fasl\"
       :FASL-MD5 \"91fc422134ea87241376cfa580c3b040\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-package.fasl\"
       :FASL-MD5 \"e2c8f3ca6ad13349be96626540673373\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-run.fasl\"
       :FASL-MD5 \"51057c820bf7593db71c40d49f6d635d\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-types.fasl\"
       :FASL-MD5 \"03b53e3dbddf26df49c54fa2888600b0\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/compaction-scan.fasl\"
       :FASL-MD5 \"049e1465afaeb06ac9adb78154729b99\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/control-payload.fasl\"
       :FASL-MD5 \"a33ff186104cac96ef850f58a69b1bf6\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/formats.fasl\"
       :FASL-MD5 \"a8b4b509e9395e7afe1f326d5668ef3c\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/log-header.fasl\"
       :FASL-MD5 \"83e528c78eeb28bc11b13c4e94a1f185\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/package.fasl\"
       :FASL-MD5 \"77d7e4c4754787412d84b55de6f1f2fd\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/payload-record.fasl\"
       :FASL-MD5 \"b70dafe615090af384a60dcb50f070b3\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/payload-write.fasl\"
       :FASL-MD5 \"72e891c713a96f0c6a22e364433fd590\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/segment-header.fasl\"
       :FASL-MD5 \"9dd46ecf14e64a2adfe3dcb317483dce\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/wal/builder.fasl\"
       :FASL-MD5 \"4bc45b7226af9852c74ca69d329b6272\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/wal/csn.fasl\"
       :FASL-MD5 \"295019c75fe5e873c40b8b84bf791bb2\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/wal/executor.fasl\"
       :FASL-MD5 \"d514061338247b92fb8d70b31942e1b4\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/wal/group.fasl\"
       :FASL-MD5 \"9e4bcb355f4d6b1cbbe869273a5a9fe0\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/wal/package.fasl\"
       :FASL-MD5 \"b047591ba53e93ce851596b5c37f9166\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/wal/types.fasl\"
       :FASL-MD5 \"7f3b071048169d99e3381d0607efaf4d\"))
     :COMPILED-SUITE
     ((:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/tests/foundation/support.fasl\"
       :FASL-MD5 \"bcd8f25457f4c9cc3f5174d2f3e0458c\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/support.fasl\"
       :FASL-MD5 \"46b222ef1e2d42417d4db578d72c0ab6\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/construction.fasl\"
       :FASL-MD5 \"dc3e317ba2b4d43b7f93df2599678ae2\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/read.fasl\"
       :FASL-MD5 \"1c79937545a4914ab7f79801083dc066\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/threads.fasl\"
       :FASL-MD5 \"94943c4668e853456f5759e0eeeae37f\"))
     :FAILED-TEST \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\" :PASSED-TESTS
     NIL :FAILURE-KIND :PRODUCT-CONDITION :CONDITION-TYPE \"INVARIANT-VIOLATION\"
     :DIAGNOSTIC \"ArcDocDB: DIRECTORY-SHAPE\"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . \"1cbcfe2ab10276b9301159fbb87d74c2\") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . \"bd0d166bfeee41dc15f53c57586a3d0d\") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   \"truncate-directory-id\" :FILE \"src/get-directory/read.lisp\" :DIRECTORY
   #A((138) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/\")
   :EXPECTED-FAILURE :MAX-U32-LOCATION-REJECTED :SUBSTITUTION
   (:BEFORE \"(ldb (byte 32 32) location)\" :AFTER \"(ldb (byte 31 32) location)\")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   (\"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\")
   :SOURCE-MANIFEST
   ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5e1e1260d8364e7eb1549db37153364\"))
    (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
    (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
    (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
    (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
    (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
    (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
    (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
    (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
    (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
    (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
    (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3f19ffb4aacfdfe502c5e8b12a234f2\"))
    (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
    (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
    (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
    (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
    (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
    (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"200373402e6e082dd8c7afde305302bb\"))
    (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
    (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
    (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
    (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
    (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
    (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
    (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
    (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
    (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
    (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
    (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
    (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
    (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
    (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
    (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
    (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
    (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
    (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
    (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
    (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
    (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
    (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
    (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
    (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
    (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
    (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
    (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
    (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
    (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
    (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
    (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
    (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
    (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"65ce18f4ca8502f65bf6ee411e9f5fe9\"))
    (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
    (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
    (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
    (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
    (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
    (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
    (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
    (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
    (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
    (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
    (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
    (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
    (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
    (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
    (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
    (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
    (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
    (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
    (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
    (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
    (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
    (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
    (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
    (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
    (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
    (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
    (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
    (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
    (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
    (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
    (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
    (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
    (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
    (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
    (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
    (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
    (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
    (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
    (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
    (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
    (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
    (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
    (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
    (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
    (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
    (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
    (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
    (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
    (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
    (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
    (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
    (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
    (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
    (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
    (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
    (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
    (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
    (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
    (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
    (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
    (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
    (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
    (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
    (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
    (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
    (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
    (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
    (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
    (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
    (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
    (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
    (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
    (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
    (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
    (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
    (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
    (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
    (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
    (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
    (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
    (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
    (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
    (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
    (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
    (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
    (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
    (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
    (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
    (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
    (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
    (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
    (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
    (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
    (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
    (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
    (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
    (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
    (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
    (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
    (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
    (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
    (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
    (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
    (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
    (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
    (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
    (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
    (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
    (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
    (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
    (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
    (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
    (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
    (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
    (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
    (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
    (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
    (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
   :COMPILED-TARGET
   (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    \"65ce18f4ca8502f65bf6ee411e9f5fe9\" :FASL
    \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/read.fasl\"
    :FASL-MD5 \"e38f96a648455c6ee99ed2b15a69092a\")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    (\"sbcl\" \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--disable-debugger\"
     \"--script\" \"isolated-build.lisp\")
    :STDOUT-LOG
    #A((148) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/stdout.log\")
    :STDERR-LOG
    #A((148) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/stderr.log\")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 5707749/1000000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/\"
     :SOURCE-MANIFEST
     ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
       \"b5e1e1260d8364e7eb1549db37153364\")
      (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3f19ffb4aacfdfe502c5e8b12a234f2\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\")
      (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"200373402e6e082dd8c7afde305302bb\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cde24b2bf5c5637d5501b95bed47df31\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65ce18f4ca8502f65bf6ee411e9f5fe9\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\")
      (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\"))
     :SUITE-FILES
     (\"tests/foundation/support.lisp\" \"tests/get-directory/support.lisp\"
      \"tests/get-directory/construction.lisp\" \"tests/get-directory/read.lisp\"
      \"tests/get-directory/threads.lisp\")
     :REGISTERED-TESTS
     (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
      \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
      \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
      \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
      \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
      \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
      \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
      \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
      \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
      \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
      \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
      \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
      \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
      \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
      \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
      \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
      \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
      \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
      \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
      \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
      \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
      \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
      \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
      \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
     :SELECTED-TEST
     \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"65ce18f4ca8502f65bf6ee411e9f5fe9\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/read.fasl\"
      :FASL-MD5 \"e38f96a648455c6ee99ed2b15a69092a\")
     :COMPILED-PRODUCT
     ((:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/build.fasl\"
       :FASL-MD5 \"579de5d3001edde3b15d2c7ee0354e7f\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/clock.fasl\"
       :FASL-MD5 \"3995b30c9eed3b1ce6b52ca6ef778969\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/core.fasl\"
       :FASL-MD5 \"f5bb2b2d9616a2fc37ea606f6c777d9c\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/package.fasl\"
       :FASL-MD5 \"0f3226966358a9948b1ddbaf6c075373\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/read.fasl\"
       :FASL-MD5 \"29a068db5d9622e2a917e55f435361b7\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/types.fasl\"
       :FASL-MD5 \"a45ae2cb181f3a94bbf7d3cc1d0604a7\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/write.fasl\"
       :FASL-MD5 \"557a677e0894cb2463b607334e39482c\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-float-minimal.fasl\"
       :FASL-MD5 \"e06bd528f76a62edbf0fc37d81b0c21e\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-header.fasl\"
       :FASL-MD5 \"c1ee976ee2ec9ff54b1d57cf89777701\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-minimal.fasl\"
       :FASL-MD5 \"2992d936c288bf8230170d16f0e8baeb\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3f19ffb4aacfdfe502c5e8b12a234f2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-package.fasl\"
       :FASL-MD5 \"d786341be7e857bff967f46def6a5ad7\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-input.fasl\"
       :FASL-MD5 \"ea2d88d175979b66530798bd50b39415\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-items.fasl\"
       :FASL-MD5 \"ba9e9c6b8fef29909e418f6421245df6\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-minimal.fasl\"
       :FASL-MD5 \"afd48768f571442620eb1562477d6122\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-stack.fasl\"
       :FASL-MD5 \"181c0b0bf704f500c5a7c99bdcebe5ef\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan.fasl\"
       :FASL-MD5 \"958e60d3767ff4a893089d5fdf726c81\")
      (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"200373402e6e082dd8c7afde305302bb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-simple-write.fasl\"
       :FASL-MD5 \"78fd717745451308b8c29b9ce9bf18f9\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-space.fasl\"
       :FASL-MD5 \"0e06ba38fd0c8a8e4422a3a8f09e86c2\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-string-write.fasl\"
       :FASL-MD5 \"d1e8a8947294bc2a4f7b8f8f505c1a46\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-write.fasl\"
       :FASL-MD5 \"f1ba6cd07a6eacfec0a0a118bd3da09e\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/package.fasl\"
       :FASL-MD5 \"aa8b90cac48737157f2f451551c33ffe\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/utf8.fasl\"
       :FASL-MD5 \"0392bb5988c2b652f4e3beda9143871b\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/csn/package.fasl\"
       :FASL-MD5 \"a9c79d53f89dc39961b5e7b2f7b0f2de\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/csn/registry.fasl\"
       :FASL-MD5 \"55489f82ea2c9a4b38c6ade9b1eeafed\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/core.fasl\"
       :FASL-MD5 \"8e60f1ed8f21851c5be7dbfdfa81c761\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/package.fasl\"
       :FASL-MD5 \"8bc32d692490c900234a1b958c0d98bc\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/read.fasl\"
       :FASL-MD5 \"b3bfba4c127de4f9a35522064783a99f\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/reclaim.fasl\"
       :FASL-MD5 \"9445f335fb504875e57f937c3d3ee22d\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/retire.fasl\"
       :FASL-MD5 \"9e5c79c046095a361c132713ceaf9a50\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/types.fasl\"
       :FASL-MD5 \"542d509a92d0d68ddb8ff2cab1242ba6\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/handoff.fasl\"
       :FASL-MD5 \"42ee2510e0be09d2cd8198834b17523b\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/package.fasl\"
       :FASL-MD5 \"20bdc8610a6a4971320d45e5e1582e5b\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/queue.fasl\"
       :FASL-MD5 \"daee8d0140623406efb3aedf0ed4e1fe\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/ready-recycle.fasl\"
       :FASL-MD5 \"7f70cf49bf97b525e9dce8d160358b2f\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/ready-types.fasl\"
       :FASL-MD5 \"1af640a6ab3d56c839fd014e4d365ab2\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/ready.fasl\"
       :FASL-MD5 \"c420702806bb7e663645129f07ed231e\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-boundary.fasl\"
       :FASL-MD5 \"f970086f1390fb2584c047b8242af423\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-claim.fasl\"
       :FASL-MD5 \"6eddf01e9ae67c08de0b27cdca583ec3\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-run.fasl\"
       :FASL-MD5 \"726c763ca669a104e1d19bed727a0473\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-types.fasl\"
       :FASL-MD5 \"3d5e8109d9d2e68c81bcaeac897be308\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/writer.fasl\"
       :FASL-MD5 \"23f1fbb6e03114a75a66160da0409c7f\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/batch.fasl\"
       :FASL-MD5 \"e1b8d05d90fad7ccf5182c337a82362c\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/binary.fasl\"
       :FASL-MD5 \"b036ec7605c8b85aaaa0e4a387cd2a99\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/conditions.fasl\"
       :FASL-MD5 \"4a18e6a36ea04bc54724330600cf2ce1\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/crc32c.fasl\"
       :FASL-MD5 \"d70f5310bcfc903c408226d6f6d738c0\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/package.fasl\"
       :FASL-MD5 \"747e6c12b2804a22e8b7588c344fd614\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/record.fasl\"
       :FASL-MD5 \"c3037f83c74dd6118bc98ee24d3f0ceb\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cde24b2bf5c5637d5501b95bed47df31\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/build.fasl\"
       :FASL-MD5 \"34c1561a362f0e861871eb50244567da\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/package.fasl\"
       :FASL-MD5 \"5db839db629b34fda7988a08f635e89f\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65ce18f4ca8502f65bf6ee411e9f5fe9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/read.fasl\"
       :FASL-MD5 \"e38f96a648455c6ee99ed2b15a69092a\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/types.fasl\"
       :FASL-MD5 \"8c74aba15d59afc55b8152ea69f647de\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-build.fasl\"
       :FASL-MD5 \"bd3e788ee0f1c95fdd3e103e90074d48\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-directory.fasl\"
       :FASL-MD5 \"271bafd2e884862d7b744f9f1a3848d1\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-preflight.fasl\"
       :FASL-MD5 \"b90e883019683974a4a707a5ffe48731\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-read.fasl\"
       :FASL-MD5 \"7b06a3dca74a3356a25d08478cce730a\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-scan.fasl\"
       :FASL-MD5 \"f6a19e35b499e22328f97c29c89a8df7\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-types.fasl\"
       :FASL-MD5 \"6dd7eb317d50437a04c75897fc84a296\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/build.fasl\"
       :FASL-MD5 \"28a9d80f006f244801d999bed4d1167c\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/package.fasl\"
       :FASL-MD5 \"1818ede181862747713fe1dc76192f98\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/read.fasl\"
       :FASL-MD5 \"5a8769935dff4d10d18ca7500585ff47\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/rows.fasl\"
       :FASL-MD5 \"3db58085edbf0a479d3f64d4d77e52bb\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/scan.fasl\"
       :FASL-MD5 \"d81206c678fb921c95207d4e9cda20b8\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/sort.fasl\"
       :FASL-MD5 \"5147cc2e164d26ca6581fc486e6704b6\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/types.fasl\"
       :FASL-MD5 \"c242d0073ef6d55d83bc1133f4a21e75\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/build.fasl\"
       :FASL-MD5 \"9337a834757ba2c2e86528e60a7dd851\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/lifecycle.fasl\"
       :FASL-MD5 \"1d08256090b03f78626c921fdfed4106\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/lookup.fasl\"
       :FASL-MD5 \"4481c316f231fde80268e6bd15caa47a\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/package.fasl\"
       :FASL-MD5 \"61b6d15ecfda9083d3ca8d03d5de428f\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/segment.fasl\"
       :FASL-MD5 \"881352905b49a4463d81df859bc2a828\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/target.fasl\"
       :FASL-MD5 \"03ad5302593485726d5808d16a648049\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/types.fasl\"
       :FASL-MD5 \"99070f392c23b6735bed829f01e53bb7\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/hash/arithmetic.fasl\"
       :FASL-MD5 \"80ad5d8b7eb25fb4326228afd2c2dc87\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/hash/blocks.fasl\"
       :FASL-MD5 \"f52c76cb54ffeb9d2679591d3c7316fa\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/hash/hash64.fasl\"
       :FASL-MD5 \"4c71090164590e9e83efdf1280cd9c87\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/hash/package.fasl\"
       :FASL-MD5 \"76e873c4fdf0cde4af1dc0d560389e73\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/core.fasl\"
       :FASL-MD5 \"aa3a7085545bd9d52f47147173dedb98\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/hash-digests.fasl\"
       :FASL-MD5 \"4d798fe34b0ecf760def9b8132a27023\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/hash-seed.fasl\"
       :FASL-MD5 \"40f5415b96a5100f18430de2c19b9a61\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/package.fasl\"
       :FASL-MD5 \"592e57e331a74a6f74c5185d80ce08af\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-arena.fasl\"
       :FASL-MD5 \"40d8ae93640f1bca97751ca2816ed3a4\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-build.fasl\"
       :FASL-MD5 \"dfecbd2fbf04b5ea79f047c3f3d4829e\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-core.fasl\"
       :FASL-MD5 \"3b301c78f482d0a137352e205aeba52b\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-directory.fasl\"
       :FASL-MD5 \"d1eb9c4477f6d558cade3251c825575b\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-package.fasl\"
       :FASL-MD5 \"c6bb76322190c73bdc1f20c475ed9eeb\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-probe.fasl\"
       :FASL-MD5 \"5453065ce9d9a260de19fbe5bff4288a\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-read.fasl\"
       :FASL-MD5 \"bbaaa5fcf542f44236eccaec49041f32\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-relocate.fasl\"
       :FASL-MD5 \"f10caeceff5ef76634ff60e630403b25\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-types.fasl\"
       :FASL-MD5 \"08c5e01b12653a45d548a3a2f6d235e1\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-write.fasl\"
       :FASL-MD5 \"a9113dcbf37d91e213423e543ba7114c\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/read.fasl\"
       :FASL-MD5 \"2d0bf5b0880b04c2601c905e7192d4c6\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild-budget.fasl\"
       :FASL-MD5 \"6f3aace77b2568590dab711536dc49eb\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild-copy.fasl\"
       :FASL-MD5 \"0bad4319a0d717c54d2d4d213e416f61\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild-scan.fasl\"
       :FASL-MD5 \"8e1caa5bf7e179e6adb7c4a39661c502\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild.fasl\"
       :FASL-MD5 \"36357fc841716daf2c6a3e66e4140be3\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/relocate.fasl\"
       :FASL-MD5 \"806c78fab893f9b8dc6781ab2ad85d85\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/types.fasl\"
       :FASL-MD5 \"ccbaccc757365e756533c25d7737f725\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/validation.fasl\"
       :FASL-MD5 \"c5250d1004bde92fbd3da0d1977eaec6\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/write.fasl\"
       :FASL-MD5 \"81f71c10edac858e5ce86b3757b35b2f\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/io/flush.fasl\"
       :FASL-MD5 \"648898f49267b2260c0eb0aecc238380\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/io/lifecycle.fasl\"
       :FASL-MD5 \"5fa2fbf4010b38f96021748dd7146fac\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/io/native.fasl\"
       :FASL-MD5 \"611d6fa50a78a7dd5b8dda6a18050224\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/io/package.fasl\"
       :FASL-MD5 \"5516d808a1c6a176a4ba811d453cf239\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/io/transfer.fasl\"
       :FASL-MD5 \"8003942fa0382692dbda89b3a3b3e60c\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/io/types.fasl\"
       :FASL-MD5 \"0049180e98734258d6ea293f943af958\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/package.fasl\"
       :FASL-MD5 \"c4650acc43bca0eab4492df119d26453\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-core.fasl\"
       :FASL-MD5 \"7a50ca3209849fee03c41e76df884ffe\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-csn.fasl\"
       :FASL-MD5 \"0f89dc0778ee3c0ca22fad49bff76883\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-lifecycle.fasl\"
       :FASL-MD5 \"8fcf1396bcf02198778d61286671e0ce\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-read.fasl\"
       :FASL-MD5 \"89a7e8f701f22ccf7763bca3ff32f803\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-register.fasl\"
       :FASL-MD5 \"72165fe1e309cf8cd8b039ccf081c125\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-types.fasl\"
       :FASL-MD5 \"ad735fd9e1ebc5e8a3e004aaed8e1a99\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/types.fasl\"
       :FASL-MD5 \"ff4c1947fe55f1e62cf20be0d4050f49\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/package.fasl\"
       :FASL-MD5 \"7b7f8a6e0d5dbb1f366957b262ce88f9\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/read/core.fasl\"
       :FASL-MD5 \"a864751776714a403aaf7313591209fe\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/read/package.fasl\"
       :FASL-MD5 \"8a7979111837f98676ba2979c6c18932\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/read/task.fasl\"
       :FASL-MD5 \"1a3f5249df7b44522405065415378974\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/read/types.fasl\"
       :FASL-MD5 \"58b9b878e7363d53d4295c1bf2b4dc45\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-build.fasl\"
       :FASL-MD5 \"b187350779e9ebbbd6965949af4ed036\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-package.fasl\"
       :FASL-MD5 \"770db036e33329d1eb53d458f12ac4cf\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-query.fasl\"
       :FASL-MD5 \"77f8746c234a813e3fbe08963ebd84fb\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-radix.fasl\"
       :FASL-MD5 \"004d408b28028cc875471b996e77dc4f\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-sort.fasl\"
       :FASL-MD5 \"b6ae688e8d14d27b26ca9eb78820252a\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-types.fasl\"
       :FASL-MD5 \"9848d8d76bb0ebeed8d569beb5005745\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/inventory-build.fasl\"
       :FASL-MD5 \"cb32760005018a7463865a6d3208865f\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/inventory-query.fasl\"
       :FASL-MD5 \"81e48897269659fb9dd4f63a0e48493e\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/inventory-types.fasl\"
       :FASL-MD5 \"8af2eea33640ed65f5e87f8aa5e2bb61\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-build.fasl\"
       :FASL-MD5 \"3853ea7a33304bfb1ad31559c584916e\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-decode.fasl\"
       :FASL-MD5 \"fa5ba970d84cd03b64a8c5cfee574df2\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-fold.fasl\"
       :FASL-MD5 \"d4de7b438c074f7810733a4cc5798438\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-package.fasl\"
       :FASL-MD5 \"280156bf6be201794a8e38ac14ab371c\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-query.fasl\"
       :FASL-MD5 \"085cc875ff302eb30334f36027fb6a5e\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-types.fasl\"
       :FASL-MD5 \"5df15d4511b20a512797ba118f560094\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/package.fasl\"
       :FASL-MD5 \"23e98933d773484494c2fc3d8f22e206\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/scan.fasl\"
       :FASL-MD5 \"36d45aa4dd10840ab9764019dba0ddae\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/events.fasl\"
       :FASL-MD5 \"fd60a0d997f33f4fc3f0af07e6fe5651\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/io-events.fasl\"
       :FASL-MD5 \"f6efb3b3086c20e943c3fa6e9ef48325\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/ownership.fasl\"
       :FASL-MD5 \"f8454da1f16cc2a9bbe4a3b38738d049\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/package.fasl\"
       :FASL-MD5 \"12d207d73eb789174ad9cf86b94bb970\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/publication.fasl\"
       :FASL-MD5 \"9e963f2e51397458f2e12ce0ae72799e\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/query.fasl\"
       :FASL-MD5 \"3c0e17d58665b3b2903044449ee28720\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/retirement.fasl\"
       :FASL-MD5 \"9a115b68bdc5a6daa05ea52188f89f09\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/routing-build.fasl\"
       :FASL-MD5 \"379f6dcdd96ac01337b1a1f96ea6b7b3\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/routing-select.fasl\"
       :FASL-MD5 \"bd74dd0564546b6900f3a69964c19efb\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/routing-types.fasl\"
       :FASL-MD5 \"791f1f409a50aa4f4647cf3541e6afee\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/types.fasl\"
       :FASL-MD5 \"03b0a93621ecd824d64f8a561f22cb86\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-boundary.fasl\"
       :FASL-MD5 \"96aa65d7de8b0731b91d47f21bc3aece\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-package.fasl\"
       :FASL-MD5 \"c0579cacbf4b959ad529c9c30d3ed9e4\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-run.fasl\"
       :FASL-MD5 \"d6c12d1437f40f4b036976e173900e4d\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-types.fasl\"
       :FASL-MD5 \"9e53bb756d13cd41d03334b011e0254e\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/compaction-scan.fasl\"
       :FASL-MD5 \"73f64d68858697128ec9c6eb2e7bd1ca\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/control-payload.fasl\"
       :FASL-MD5 \"99efe0c8e41e2fa64f743e4ef3387e8d\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/formats.fasl\"
       :FASL-MD5 \"3671c4e0fe59800ce1f0e6d9dec33509\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/log-header.fasl\"
       :FASL-MD5 \"91b3f356a3b3a0d20cf6b5b7855f4542\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/package.fasl\"
       :FASL-MD5 \"a0b9ee3fb3baad2b9d68f2b1a2205fa5\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/payload-record.fasl\"
       :FASL-MD5 \"aebf189d8ed91aa258721056d6f67940\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/payload-write.fasl\"
       :FASL-MD5 \"da2d2bbf7cd4cc1cc0c4b87f0bbf0074\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/segment-header.fasl\"
       :FASL-MD5 \"9baeca2293c4a311f80417c23ed109c9\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/wal/builder.fasl\"
       :FASL-MD5 \"97ef82ecb1ee1724a17ff02af85890bc\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/wal/csn.fasl\"
       :FASL-MD5 \"9b95024c4c14617f7c2fb5e1489fde54\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/wal/executor.fasl\"
       :FASL-MD5 \"01381bd077a8ef8c8414adc7cfe55bf3\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/wal/group.fasl\"
       :FASL-MD5 \"e8498657a67098490978ca44f11cc53d\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/wal/package.fasl\"
       :FASL-MD5 \"3861ddcb25dd2fd080bcbad8ead4c6cf\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/wal/types.fasl\"
       :FASL-MD5 \"daaf626d3f18b806d64af6bf03f4effb\"))
     :COMPILED-SUITE
     ((:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/tests/foundation/support.fasl\"
       :FASL-MD5 \"365bf341bc1559d4b0f264a189bc399b\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/support.fasl\"
       :FASL-MD5 \"38f0dc423d4eeba7f9de0e7c53d1300f\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/construction.fasl\"
       :FASL-MD5 \"0d7d9461bb77822ba83bcd0ab18d8877\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/read.fasl\"
       :FASL-MD5 \"e3c08cd92af313c3c298948ff53ef8e2\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/threads.fasl\"
       :FASL-MD5 \"64b0d17b8f8dad4340e36a2af6edef3b\"))
     :FAILED-TEST
     \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
     :PASSED-TESTS NIL :FAILURE-KIND :PRODUCT-CONDITION :CONDITION-TYPE
     \"INVARIANT-VIOLATION\" :DIAGNOSTIC \"ArcDocDB: DIRECTORY-LOCATION-ABSENT\"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . \"6c9f199953303643f910b20ecb13f8e5\") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . \"65ce18f4ca8502f65bf6ee411e9f5fe9\") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   \"bypass-closed-resolver\" :FILE \"src/get-directory/read.lisp\" :DIRECTORY
   #A((139) BASE-CHAR
      . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/\")
   :EXPECTED-FAILURE :CANDIDATE-SIZE-AND-RESERVED-HIGH-BITS-NOT-CHECKED
   :SUBSTITUTION
   (:BEFORE
    \"(risolvi-candidato-get context (trova-mappa-directory-get context directory))\"
    :AFTER \"(let ((map (trova-mappa-directory-get context directory)))
    (values (mappa-segmento-get-segment map)
            (arcdocdb.get.resolver::mappa-segmento-get-end map) 0 nil))\")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   (\"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\") :SOURCE-MANIFEST
   ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5e1e1260d8364e7eb1549db37153364\"))
    (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5d70197c8b64ad6f20c8be47a60c73ca\"))
    (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3546cf7f5c5ed138068548c20064f499\"))
    (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"72f3a33ce27ddf94c49c495580520004\"))
    (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1f6a8e7aa4faed88e984b39871d1e53\"))
    (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82f937b7b08bd1696ad9c88da2e1c60c\"))
    (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a25648d870eaa4f0b6e1e3b2cf76e28e\"))
    (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fc09021f74fb50aac57589614dae04d7\"))
    (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bc7a7b176e8cdd361b7c4306a1a4de4b\"))
    (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6e8c6a49314c2f460aa6f8a1759200b6\"))
    (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ecd8fe950344059c629927b38fb6e4aa\"))
    (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3f19ffb4aacfdfe502c5e8b12a234f2\"))
    (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f6488e987889432b375254021825dbe5\"))
    (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"706c0baa4158bf272c4b0df17c1439d2\"))
    (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"987e8ed576a21eb644ac1ef2e06edbda\"))
    (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cf1999ddb10f879aeefbeea853742d57\"))
    (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0c33aedcdb352e78a3c694cf796e6692\"))
    (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"200373402e6e082dd8c7afde305302bb\"))
    (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c33cdcc45f45218aa3e8bf26ce0ee575\"))
    (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b13e92b5f24a42fe283c17b649722b6a\"))
    (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"69e77bcd15b5413a815a65c5081229db\"))
    (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d885bd2a9860eb60aec1a775e5031d5e\"))
    (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0f67dd5c51bf6a63bc292ab4e2a280c2\"))
    (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1130012fc5613a5648d22ed8628be0e8\"))
    (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a1cdb5661fc54beba5bf00e4765f3235\"))
    (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"765d14c88cd288093a77a57930cd6999\"))
    (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"875201dfab0a84efd40fe9828cc293c8\"))
    (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"975b5f74e0c5a38ce978f4d9c7fcc6b8\"))
    (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"036dd02adf87d33c3ae2f40735c733fa\"))
    (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"653b974f310c09f6e2224a84acc43bbf\"))
    (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82253491f995f5bc153fb5ebf30d564c\"))
    (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6b85eebe69366e78ed5fc5cc20735f00\"))
    (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb5710d6c111cadb7121a50998a747fa\"))
    (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8202843bddb817da4279ac959ae3f3c4\"))
    (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"38d26f8c749dd946dfc4b9c57103a892\"))
    (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a64d98c9ff429d6103d6e10ee1fd7980\"))
    (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2c1892002f0599bb8273093031017520\"))
    (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c24065d6c8d80d1be53994a0041743df\"))
    (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"babd0a78b4185af24ae1fef870c0fabb\"))
    (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"aa34ca6bc07535e35fea723878d99f66\"))
    (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0679ee07c46f69db330706303c70d8d2\"))
    (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"73019644090e2971f2b54dc36e4491f5\"))
    (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca642ea47e4bff76f78f5b6d7287d6bd\"))
    (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a06115175f450776762761dce25acdb8\"))
    (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"942b596396c19815290a57830af2121b\"))
    (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4db58e2f48bf77d751f1b83bb9f84b5c\"))
    (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5ee593a112958d94163dab17c5aa4ba2\"))
    (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\"))
    (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cde24b2bf5c5637d5501b95bed47df31\"))
    (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4233eef9d87bdec712d4f690bcb699a9\"))
    (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"dde814f850eae82069c02ec9348edf34\"))
    (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"17c957d6934a31f4ed64313e756de2d2\"))
    (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8d26428a4e17ad18990b8ee7d5f5b53a\"))
    (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"6d95f29b331d335175843f47ae44a6ea\"))
    (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f13d422adb6aa9e8489352884137f25a\"))
    (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3da469a7aa1e682dd8f2e516ee451de1\"))
    (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6aaec49504a96f37c8ff1bc182c977b\"))
    (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bd7182e9871fe82530d0c828e473ccde\"))
    (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bbfb2082103e6712419e180ab972245c\"))
    (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbfb17bf1f65698fb7c7889953d02d1e\"))
    (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1339edff0223dbf122f11ff0adbba61c\"))
    (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ca9002b81efd0aed9761cd1f78514762\"))
    (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"536e9dc4ed51072b8a6d1528d3ec18bf\"))
    (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d869293ba47444c4721713d955c6254\"))
    (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9df13bcc6908e9fa601d173a671e1ccf\"))
    (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c5cc36884b238221cc13ca0c087ec7c2\"))
    (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e70bfeddd694336bbd088e65f8761834\"))
    (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"82258ec87aca513a508bc5dee8410dd6\"))
    (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c72633d15c3488699072eb610ebde7c8\"))
    (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"811869eb6a197d3c4e26af4322e52652\"))
    (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1b70dac05d6d2418909eb5105b808e81\"))
    (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c394e5684de5e2d938991c7cb348b93c\"))
    (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b5c51802e607e3dd22de68204baf64e9\"))
    (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bef497b9a267c7306d4100000491c814\"))
    (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"886b7c08b9929283e8968831cbe5c039\"))
    (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d9060e41bc5252067d35e59ac70ee06\"))
    (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"65076c355c099b5dc73d185948d3bec4\"))
    (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"43d2209225707352daec6186ef95a805\"))
    (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"45ce41749bc6fa638539815d3f802b96\"))
    (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"598a9b65e73151c924b2cdcaf6d96705\"))
    (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a319691e3e28b7ea7b927de490cf69ba\"))
    (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff2cfbb865290d7a1510fdf6877c7229\"))
    (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fa52433eae199ceeb874bf2bc47afca7\"))
    (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1dd67c527257e43f17e006644ecdbd00\"))
    (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d65cfce399b04f905bf969929962e59a\"))
    (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"699ce3f1615296fc27fcde3e0d63a4bc\"))
    (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f317a0d3c5ee86a73651aad36135cc3\"))
    (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5155959766645d3172ae5e73c58cc071\"))
    (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a59eab6425a60fa2656f86bf87d5c9ac\"))
    (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e8e31e599356e592af29c0cc4604872b\"))
    (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5b22b90cfe8534086f6aff96d156713e\"))
    (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0417dd41cb3ec1d62dfd913c19f810ad\"))
    (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8befbbd00ed5c31c1487a11887eba495\"))
    (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1188e7a64a7a5d9482c1233cb9acb452\"))
    (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a450cac8071513365267e7024cbe94b0\"))
    (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475dd7d5809a836f01544b447cc8df27\"))
    (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"5157fd03ee806ee998ad8f0002d56268\"))
    (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"3384cadf737c7d80c004222022a281f6\"))
    (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0c8c579cd7db466d243ed3ea9f8e8aa\"))
    (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"716866194d6b9f076e102e84187229c0\"))
    (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"11c7103efbe733bbf0a13927f23c3d34\"))
    (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9500cfb800603de002d6d2b24f1bf056\"))
    (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c9380ad46a1d7acf41655aaed20db478\"))
    (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a5e7108e80664eb3b562fbd7e680801f\"))
    (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"db8497f9cff35b1ee261f1f410f46ca6\"))
    (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f188d1dbd5d0adb49f53acf09157aef9\"))
    (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8bb066aab61a18eff175b9edb11e42a2\"))
    (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"0e9365e674d1584b111f915ce1f58634\"))
    (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ff98aea5cb9a7ae2671f6a887a003725\"))
    (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ae3ad96269b5e711a9dbb455f3c0ce48\"))
    (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2d5a795bcefd605c75da91c725ae83a2\"))
    (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"475517bd7ba04a1c37a82efeb8ff73d9\"))
    (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a9bc70eab6720b5c6f8503178e2c966b\"))
    (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"becf5c78049c85f2c05cd1ef54454032\"))
    (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"4040905f4a64ba704a480d82e87ec748\"))
    (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7d74d9decc5a0bc9f9331d89bd503e21\"))
    (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9e0baf22c53329d393e047c669679645\"))
    (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9c37ff8237fcc9fe9ae4f44316e854e3\"))
    (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1a51ef4a488bb9fde2ff7d47bae01379\"))
    (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cbdc30f93109c474e1fc25066c9b9b13\"))
    (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f782d1137b8ce342b91c9999cfb7accc\"))
    (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"852149de4c289b8e067602780378d87a\"))
    (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b33e57a643f2fca810846f6226366253\"))
    (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f4433fd19ebc7239dbc2628c39f3ecdb\"))
    (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"9bd6820c4feba3e552aab1a4edd87861\"))
    (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcea263de1938767772e5b11411ecd5e\"))
    (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"78c136d5838dcfe3019d9069643a8d8f\"))
    (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"bf65b1731eab6e0572461ef5cc60fc40\"))
    (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"67975249aaabd751757cdfb9222cc3c4\"))
    (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0d2498db1011e857b7b0daa1934f187\"))
    (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"37ace42844c11b52446ee1fc500b8e0b\"))
    (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ebd7a54adea2213294a887e6d4db0927\"))
    (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7b1d4054415faca7e5fca59ad83b4d4a\"))
    (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\"))
    (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"fcacd15460db25ea9cc4036065f9f096\"))
    (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"32b2156739a6f2ca996abb91df0a2603\"))
    (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b6026a8b7bb64b45c37a65effda70d8e\"))
    (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"de1aca16a35d34d16aba12ff541c0d2b\"))
    (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"59e3c59c90d8d0fc5731b87496a785aa\"))
    (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"056d2c6a67c9d9f2bf9fe2d2c348d53c\"))
    (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb0d91405325b508e6b2ab24d178de7a\"))
    (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b8e04971b8ad75a1bd0c722997badfd2\"))
    (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6924deff152b941bd49f0bb200b4197\"))
    (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"e0f987d8767744050ec4d1b3ecb699ed\"))
    (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ce649df47dd38888d5103c98345f7e41\"))
    (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"ab19ec8d15af91511e817858c41cebc8\"))
    (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2340e0c9074f7b1bf80c74f774986bc5\"))
    (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a93ce2e84e8aee647b5083ad1d2b899b\"))
    (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f0fee18adf357bad98e8a3c3e8c70c0c\"))
    (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"2b23d468be0165fa009c5ebd5d1bbe23\"))
    (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"1cda77a357ab2147035993b72d135a37\"))
    (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"cb64f806b8d69eb42d865b4abfff0b27\"))
    (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"061147be459d8d3b08c661bd3f91d152\"))
    (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"b53d27dcc9f4badf18b50519c50bc614\"))
    (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f86bd104f20616a76b42c02227f72844\"))
    (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"8c03f9c01dcb30f2d3970a5694968ecf\"))
    (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\"))
    (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"d6812fa59bf8fd1252fbf85a9bfa3896\"))
    (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"a229f76f7036f3573a6e528dcd390a19\"))
    (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"42b990e3b254e6fb488c0ab91b6a6502\"))
    (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"c0340924c9130e14d0e8efedeec078f1\"))
    (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"7a0e7c99ab70b4720cbb091156560f5e\"))
    (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"96c41b1d417135a24fc65659ea3abe11\"))
    (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . \"f799f27a8ac1a4c736c04796c1e543f9\"))
    (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"758adad069aec2f9dbe0635797314ff6\"))
    (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"3f868ebe4307ad4238b314c37eceed9a\"))
    (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"1137938073e71d6d8d62c751fbad05d5\"))
    (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"d1ab36d05cc1266e4533d27c693f12f4\"))
    (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . \"63dd01c852de1399c2c82274d481d257\")))
   :COMPILED-TARGET
   (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
    \"dde814f850eae82069c02ec9348edf34\" :FASL
    \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/read.fasl\"
    :FASL-MD5 \"46c6f5e85e0427ed069dbd44fb4d8f70\")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    (\"sbcl\" \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--disable-debugger\"
     \"--script\" \"isolated-build.lisp\")
    :STDOUT-LOG
    #A((149) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/stdout.log\")
    :STDERR-LOG
    #A((149) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/stderr.log\")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 953493/200000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/\"
     :SOURCE-MANIFEST
     ((:FILE \"arcdocdb.asd\" :ROLE :SYSTEM :SOURCE-MD5
       \"b5e1e1260d8364e7eb1549db37153364\")
      (:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3f19ffb4aacfdfe502c5e8b12a234f2\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\")
      (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"200373402e6e082dd8c7afde305302bb\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cde24b2bf5c5637d5501b95bed47df31\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"dde814f850eae82069c02ec9348edf34\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\")
      (:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\"))
     :SUITE-FILES
     (\"tests/foundation/support.lisp\" \"tests/get-directory/support.lisp\"
      \"tests/get-directory/construction.lisp\" \"tests/get-directory/read.lisp\"
      \"tests/get-directory/threads.lisp\")
     :REGISTERED-TESTS
     (\"TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START\"
      \"TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N\"
      \"TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT\"
      \"TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS\"
      \"TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED\"
      \"TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER\"
      \"TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER\"
      \"TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME\"
      \"TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17\"
      \"TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID\"
      \"TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT\"
      \"TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK\"
      \"TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT\"
      \"TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL\"
      \"TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP\"
      \"TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH\"
      \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
      \"TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE\"
      \"TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS\"
      \"TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION\"
      \"TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY\"
      \"TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN\"
      \"TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION\"
      \"TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY\"
      \"TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER\"
      \"TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO\"
      \"TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER\")
     :SELECTED-TEST \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
      \"dde814f850eae82069c02ec9348edf34\" :FASL
      \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/read.fasl\"
      :FASL-MD5 \"46c6f5e85e0427ed069dbd44fb4d8f70\")
     :COMPILED-PRODUCT
     ((:FILE \"src/cache/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5d70197c8b64ad6f20c8be47a60c73ca\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/build.fasl\"
       :FASL-MD5 \"4bfe6c9ca40f5d47c20e6c19e31110bb\")
      (:FILE \"src/cache/clock.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3546cf7f5c5ed138068548c20064f499\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/clock.fasl\"
       :FASL-MD5 \"847a21c4ad737dd883c0b616f3a881e3\")
      (:FILE \"src/cache/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"72f3a33ce27ddf94c49c495580520004\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/core.fasl\"
       :FASL-MD5 \"ddd1bbd26bdd94192fa39f06d7530dc5\")
      (:FILE \"src/cache/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1f6a8e7aa4faed88e984b39871d1e53\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/package.fasl\"
       :FASL-MD5 \"751c86c047670c376abcacde753580dc\")
      (:FILE \"src/cache/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82f937b7b08bd1696ad9c88da2e1c60c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/read.fasl\"
       :FASL-MD5 \"82c6bb29b01eee002a5dbfc45b48b18e\")
      (:FILE \"src/cache/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a25648d870eaa4f0b6e1e3b2cf76e28e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/types.fasl\"
       :FASL-MD5 \"c1a048471f33e39e2039bea07c22541c\")
      (:FILE \"src/cache/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fc09021f74fb50aac57589614dae04d7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/write.fasl\"
       :FASL-MD5 \"fb33ef0a491d00498f66c149f5fb6fa8\")
      (:FILE \"src/codec/cbor-float-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bc7a7b176e8cdd361b7c4306a1a4de4b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-float-minimal.fasl\"
       :FASL-MD5 \"47288a60d0170484e1ab9cb70eb4fb2e\")
      (:FILE \"src/codec/cbor-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6e8c6a49314c2f460aa6f8a1759200b6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-header.fasl\"
       :FASL-MD5 \"1f1ad73235f62521ef87e056fe58a89c\")
      (:FILE \"src/codec/cbor-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ecd8fe950344059c629927b38fb6e4aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-minimal.fasl\"
       :FASL-MD5 \"b8a0f2ce887d14479ed9940fb856a760\")
      (:FILE \"src/codec/cbor-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3f19ffb4aacfdfe502c5e8b12a234f2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-package.fasl\"
       :FASL-MD5 \"1da007b9696614510fef8002fa47552c\")
      (:FILE \"src/codec/cbor-scan-input.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f6488e987889432b375254021825dbe5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-input.fasl\"
       :FASL-MD5 \"55eb13c33270eab2eb97fa4e70f24b39\")
      (:FILE \"src/codec/cbor-scan-items.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"706c0baa4158bf272c4b0df17c1439d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-items.fasl\"
       :FASL-MD5 \"1f3fe41a99e7a6c3c215bf96c79fd3a7\")
      (:FILE \"src/codec/cbor-scan-minimal.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"987e8ed576a21eb644ac1ef2e06edbda\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-minimal.fasl\"
       :FASL-MD5 \"d52868d54b819aacb434455001d6689c\")
      (:FILE \"src/codec/cbor-scan-stack.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cf1999ddb10f879aeefbeea853742d57\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-stack.fasl\"
       :FASL-MD5 \"79f6d878dd3999bc723b5d2a226f3e54\")
      (:FILE \"src/codec/cbor-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0c33aedcdb352e78a3c694cf796e6692\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan.fasl\"
       :FASL-MD5 \"7204e374fd7e727f32ed347b1bfa8355\")
      (:FILE \"src/codec/cbor-simple-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"200373402e6e082dd8c7afde305302bb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-simple-write.fasl\"
       :FASL-MD5 \"ca68804128224983b4db0ffa657e15b9\")
      (:FILE \"src/codec/cbor-space.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c33cdcc45f45218aa3e8bf26ce0ee575\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-space.fasl\"
       :FASL-MD5 \"e5fa81ffc7fdabbfaf9e3e880bc35d7f\")
      (:FILE \"src/codec/cbor-string-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b13e92b5f24a42fe283c17b649722b6a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-string-write.fasl\"
       :FASL-MD5 \"87ac44b85909d42d6e04f168267c96fa\")
      (:FILE \"src/codec/cbor-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"69e77bcd15b5413a815a65c5081229db\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-write.fasl\"
       :FASL-MD5 \"9ae0855dbd3a9106516d0cae3d66a6aa\")
      (:FILE \"src/codec/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d885bd2a9860eb60aec1a775e5031d5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/package.fasl\"
       :FASL-MD5 \"0790229752b1212ffad1ba6a0233be44\")
      (:FILE \"src/codec/utf8.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0f67dd5c51bf6a63bc292ab4e2a280c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/utf8.fasl\"
       :FASL-MD5 \"4b0381ae81bc3699f02646c03df0989e\")
      (:FILE \"src/csn/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1130012fc5613a5648d22ed8628be0e8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/csn/package.fasl\"
       :FASL-MD5 \"df89e0f2d8156fa0f6d0365f6df0e1e7\")
      (:FILE \"src/csn/registry.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a1cdb5661fc54beba5bf00e4765f3235\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/csn/registry.fasl\"
       :FASL-MD5 \"271854be397418e55c890473584b474d\")
      (:FILE \"src/epochs/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"765d14c88cd288093a77a57930cd6999\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/core.fasl\"
       :FASL-MD5 \"fb2e1bbb0a90d2908a0be0e595f364b4\")
      (:FILE \"src/epochs/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"875201dfab0a84efd40fe9828cc293c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/package.fasl\"
       :FASL-MD5 \"093d88be07574a710910a81208989ae2\")
      (:FILE \"src/epochs/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"975b5f74e0c5a38ce978f4d9c7fcc6b8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/read.fasl\"
       :FASL-MD5 \"eacfe692cbc9d73719e79eb68ef091fd\")
      (:FILE \"src/epochs/reclaim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"036dd02adf87d33c3ae2f40735c733fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/reclaim.fasl\"
       :FASL-MD5 \"9db400e247921fd13f910509fcfd62da\")
      (:FILE \"src/epochs/retire.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"653b974f310c09f6e2224a84acc43bbf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/retire.fasl\"
       :FASL-MD5 \"6413a610cb96edf1843ac04b603b146c\")
      (:FILE \"src/epochs/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82253491f995f5bc153fb5ebf30d564c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/types.fasl\"
       :FASL-MD5 \"1666f74074ab236986896575aaae8dd6\")
      (:FILE \"src/execution/handoff.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"6b85eebe69366e78ed5fc5cc20735f00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/handoff.fasl\"
       :FASL-MD5 \"790fccb1aea0b1289a87ace23fd2dc95\")
      (:FILE \"src/execution/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb5710d6c111cadb7121a50998a747fa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/package.fasl\"
       :FASL-MD5 \"743f34ad8f74b017c501ba3202d9d139\")
      (:FILE \"src/execution/queue.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8202843bddb817da4279ac959ae3f3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/queue.fasl\"
       :FASL-MD5 \"573416ae14e77f07ba78805b9aeccc74\")
      (:FILE \"src/execution/ready-recycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"38d26f8c749dd946dfc4b9c57103a892\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/ready-recycle.fasl\"
       :FASL-MD5 \"66dc399bf2be711f9b914243bbc20c81\")
      (:FILE \"src/execution/ready-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a64d98c9ff429d6103d6e10ee1fd7980\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/ready-types.fasl\"
       :FASL-MD5 \"2b2483687b78702e9b2b55f7c0cb8d56\")
      (:FILE \"src/execution/ready.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2c1892002f0599bb8273093031017520\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/ready.fasl\"
       :FASL-MD5 \"2dccea81307dbd1e91ad15d264181faa\")
      (:FILE \"src/execution/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c24065d6c8d80d1be53994a0041743df\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-boundary.fasl\"
       :FASL-MD5 \"ff8ef41e65726a8b5d45114bc976328e\")
      (:FILE \"src/execution/worker-claim.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"babd0a78b4185af24ae1fef870c0fabb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-claim.fasl\"
       :FASL-MD5 \"032637bf947c423d539a906e1f654e5d\")
      (:FILE \"src/execution/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"aa34ca6bc07535e35fea723878d99f66\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-run.fasl\"
       :FASL-MD5 \"08df52e201724b4cfb59b2a5d2210748\")
      (:FILE \"src/execution/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0679ee07c46f69db330706303c70d8d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-types.fasl\"
       :FASL-MD5 \"127b3457fa3e24296361b03ca817a19d\")
      (:FILE \"src/execution/writer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"73019644090e2971f2b54dc36e4491f5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/writer.fasl\"
       :FASL-MD5 \"0477b9cffb5b2f32cd41151a1341c6f8\")
      (:FILE \"src/foundation/batch.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca642ea47e4bff76f78f5b6d7287d6bd\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/batch.fasl\"
       :FASL-MD5 \"b58701c5b20756ce8ff50d097f473e39\")
      (:FILE \"src/foundation/binary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a06115175f450776762761dce25acdb8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/binary.fasl\"
       :FASL-MD5 \"84529178db980a7f25996d06ac79bd7e\")
      (:FILE \"src/foundation/conditions.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"942b596396c19815290a57830af2121b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/conditions.fasl\"
       :FASL-MD5 \"cb8436c06179a6df535b6245da165926\")
      (:FILE \"src/foundation/crc32c.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4db58e2f48bf77d751f1b83bb9f84b5c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/crc32c.fasl\"
       :FASL-MD5 \"34ef0b2ccae1ff3cad4c67d417143b5f\")
      (:FILE \"src/foundation/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5ee593a112958d94163dab17c5aa4ba2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/package.fasl\"
       :FASL-MD5 \"57b3060bee62fcfeec42c6d1439ef1c6\")
      (:FILE \"src/foundation/record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c3ed0f09fa3fa6fe20c98e2ed6e69abe\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/record.fasl\"
       :FASL-MD5 \"908c84145efe2fb2604254bd8f2581f9\")
      (:FILE \"src/get-directory/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cde24b2bf5c5637d5501b95bed47df31\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/build.fasl\"
       :FASL-MD5 \"b643567b2f2350cd90e8c395303c7362\")
      (:FILE \"src/get-directory/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4233eef9d87bdec712d4f690bcb699a9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/package.fasl\"
       :FASL-MD5 \"734e41eb14c341823df84fb357a76ebd\")
      (:FILE \"src/get-directory/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"dde814f850eae82069c02ec9348edf34\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/read.fasl\"
       :FASL-MD5 \"46c6f5e85e0427ed069dbd44fb4d8f70\")
      (:FILE \"src/get-directory/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"17c957d6934a31f4ed64313e756de2d2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/types.fasl\"
       :FASL-MD5 \"e3d808ce929cf1f6f20e5d4dceaefd27\")
      (:FILE \"src/get-resolver/active-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8d26428a4e17ad18990b8ee7d5f5b53a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-build.fasl\"
       :FASL-MD5 \"c69b6fc07193795f86b26fb375a49e9c\")
      (:FILE \"src/get-resolver/active-directory.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"6d95f29b331d335175843f47ae44a6ea\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-directory.fasl\"
       :FASL-MD5 \"cb950fcba84d729769bce32d2e4183c3\")
      (:FILE \"src/get-resolver/active-preflight.lisp\" :ROLE :PRODUCT
       :SOURCE-MD5 \"f13d422adb6aa9e8489352884137f25a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-preflight.fasl\"
       :FASL-MD5 \"e530514c89535752027ffa7834aaf22d\")
      (:FILE \"src/get-resolver/active-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3da469a7aa1e682dd8f2e516ee451de1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-read.fasl\"
       :FASL-MD5 \"ec256c826cb68feb2d03c08a4d0c6c6c\")
      (:FILE \"src/get-resolver/active-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6aaec49504a96f37c8ff1bc182c977b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-scan.fasl\"
       :FASL-MD5 \"1f521234d4b767d7ddc6003bf3a819ec\")
      (:FILE \"src/get-resolver/active-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bd7182e9871fe82530d0c828e473ccde\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-types.fasl\"
       :FASL-MD5 \"83de37f2c2035129b7aef868f27fba76\")
      (:FILE \"src/get-resolver/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bbfb2082103e6712419e180ab972245c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/build.fasl\"
       :FASL-MD5 \"7e9a35a6652466c2668c11cc9b624c31\")
      (:FILE \"src/get-resolver/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbfb17bf1f65698fb7c7889953d02d1e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/package.fasl\"
       :FASL-MD5 \"0e859b9bc47447487f955b58ff643a7b\")
      (:FILE \"src/get-resolver/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1339edff0223dbf122f11ff0adbba61c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/read.fasl\"
       :FASL-MD5 \"f6e4a8ec98fbdf8eab87bf4c996a4cde\")
      (:FILE \"src/get-resolver/rows.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ca9002b81efd0aed9761cd1f78514762\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/rows.fasl\"
       :FASL-MD5 \"37c51affe3d26283bbb8d9f96d9fcd89\")
      (:FILE \"src/get-resolver/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"536e9dc4ed51072b8a6d1528d3ec18bf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/scan.fasl\"
       :FASL-MD5 \"57ccec1cda2793de73e2ecad88944ec6\")
      (:FILE \"src/get-resolver/sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d869293ba47444c4721713d955c6254\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/sort.fasl\"
       :FASL-MD5 \"e26a75dc152a99aba73be3f7724b1b13\")
      (:FILE \"src/get-resolver/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9df13bcc6908e9fa601d173a671e1ccf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/types.fasl\"
       :FASL-MD5 \"7a0633935dfc827b03f0342e35a0419e\")
      (:FILE \"src/get/build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c5cc36884b238221cc13ca0c087ec7c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/build.fasl\"
       :FASL-MD5 \"cb1145a83335d158c3ea7d5e599f972c\")
      (:FILE \"src/get/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e70bfeddd694336bbd088e65f8761834\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/lifecycle.fasl\"
       :FASL-MD5 \"5c655cbd98ac17d72bd649f537611c29\")
      (:FILE \"src/get/lookup.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"82258ec87aca513a508bc5dee8410dd6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/lookup.fasl\"
       :FASL-MD5 \"1ece8ad6ef0b702c6763ed7eff186406\")
      (:FILE \"src/get/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c72633d15c3488699072eb610ebde7c8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/package.fasl\"
       :FASL-MD5 \"55c01f6e5efa2b9ff27ee4105c596be1\")
      (:FILE \"src/get/segment.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"811869eb6a197d3c4e26af4322e52652\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/segment.fasl\"
       :FASL-MD5 \"1f965d88ad4e68bc11bd14c094f1b301\")
      (:FILE \"src/get/target.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1b70dac05d6d2418909eb5105b808e81\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/target.fasl\"
       :FASL-MD5 \"1c24bfbe566e2737d94aa83761a4ad7f\")
      (:FILE \"src/get/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c394e5684de5e2d938991c7cb348b93c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/types.fasl\"
       :FASL-MD5 \"4874fdfc158d12864a7c6771ad6f710a\")
      (:FILE \"src/hash/arithmetic.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b5c51802e607e3dd22de68204baf64e9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/arithmetic.fasl\"
       :FASL-MD5 \"210cb3aa288be897aa6fa66994661a8d\")
      (:FILE \"src/hash/blocks.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bef497b9a267c7306d4100000491c814\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/blocks.fasl\"
       :FASL-MD5 \"2e5d597de13e6e97bc176743d7d21032\")
      (:FILE \"src/hash/hash64.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"886b7c08b9929283e8968831cbe5c039\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/hash64.fasl\"
       :FASL-MD5 \"e312cc420bc64c9dfd1a3f884d5a5636\")
      (:FILE \"src/hash/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d9060e41bc5252067d35e59ac70ee06\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/package.fasl\"
       :FASL-MD5 \"8036cba79f427b98e37347a2beec68cd\")
      (:FILE \"src/index/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"65076c355c099b5dc73d185948d3bec4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/core.fasl\"
       :FASL-MD5 \"512e871535d254fca2ba3faa10370638\")
      (:FILE \"src/index/hash-digests.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"43d2209225707352daec6186ef95a805\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/hash-digests.fasl\"
       :FASL-MD5 \"4442b0da7317d01ec46075db1c351afb\")
      (:FILE \"src/index/hash-seed.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"45ce41749bc6fa638539815d3f802b96\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/hash-seed.fasl\"
       :FASL-MD5 \"21b180bc012bed65e08536b1af7bae9d\")
      (:FILE \"src/index/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"598a9b65e73151c924b2cdcaf6d96705\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/package.fasl\"
       :FASL-MD5 \"3468c1803733b0e499b893f324374e94\")
      (:FILE \"src/index/primary-arena.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a319691e3e28b7ea7b927de490cf69ba\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-arena.fasl\"
       :FASL-MD5 \"25e7a843da2bcbcb5082e8669e7991eb\")
      (:FILE \"src/index/primary-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff2cfbb865290d7a1510fdf6877c7229\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-build.fasl\"
       :FASL-MD5 \"8b03ff8fc4fbbb86d7b597aafe64ce90\")
      (:FILE \"src/index/primary-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fa52433eae199ceeb874bf2bc47afca7\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-core.fasl\"
       :FASL-MD5 \"9e7db1beff58eab77dc0fb44f7527dfa\")
      (:FILE \"src/index/primary-directory.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1dd67c527257e43f17e006644ecdbd00\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-directory.fasl\"
       :FASL-MD5 \"f9095c4bf9b930b407266ce170c7640f\")
      (:FILE \"src/index/primary-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d65cfce399b04f905bf969929962e59a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-package.fasl\"
       :FASL-MD5 \"092b72e4e226ea219d03136385cf7f41\")
      (:FILE \"src/index/primary-probe.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"699ce3f1615296fc27fcde3e0d63a4bc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-probe.fasl\"
       :FASL-MD5 \"140d0ef49f81dc8f4179a5ce83224f86\")
      (:FILE \"src/index/primary-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3f317a0d3c5ee86a73651aad36135cc3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-read.fasl\"
       :FASL-MD5 \"9a714be99da10f2aa6c7579e6ce3ab5c\")
      (:FILE \"src/index/primary-relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5155959766645d3172ae5e73c58cc071\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-relocate.fasl\"
       :FASL-MD5 \"9101c7898b1201e4671f139a1c79f358\")
      (:FILE \"src/index/primary-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a59eab6425a60fa2656f86bf87d5c9ac\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-types.fasl\"
       :FASL-MD5 \"d2cd71a94dcbc3af89e2150e0499fff5\")
      (:FILE \"src/index/primary-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e8e31e599356e592af29c0cc4604872b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-write.fasl\"
       :FASL-MD5 \"c005637e592895a5d6258cfcaf3f747d\")
      (:FILE \"src/index/read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5b22b90cfe8534086f6aff96d156713e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/read.fasl\"
       :FASL-MD5 \"d342cef626c9e5d143eeda9beeab77c0\")
      (:FILE \"src/index/rebuild-budget.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0417dd41cb3ec1d62dfd913c19f810ad\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild-budget.fasl\"
       :FASL-MD5 \"36aefe1d623364ed414f03ecdc9705ec\")
      (:FILE \"src/index/rebuild-copy.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8befbbd00ed5c31c1487a11887eba495\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild-copy.fasl\"
       :FASL-MD5 \"d61b826d05a05d4472f1e41cf3e58ddc\")
      (:FILE \"src/index/rebuild-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1188e7a64a7a5d9482c1233cb9acb452\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild-scan.fasl\"
       :FASL-MD5 \"c2a7e9912a4dbccfde82638d1b6fc2e6\")
      (:FILE \"src/index/rebuild.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a450cac8071513365267e7024cbe94b0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild.fasl\"
       :FASL-MD5 \"d83a690d9f3ca330d8335b1211181c3c\")
      (:FILE \"src/index/relocate.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475dd7d5809a836f01544b447cc8df27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/relocate.fasl\"
       :FASL-MD5 \"2fba7739a90d64436367b7035afbb51f\")
      (:FILE \"src/index/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"5157fd03ee806ee998ad8f0002d56268\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/types.fasl\"
       :FASL-MD5 \"0b361fc4b9afabba5c7677ddcf2a2788\")
      (:FILE \"src/index/validation.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"3384cadf737c7d80c004222022a281f6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/validation.fasl\"
       :FASL-MD5 \"29e549e4d8963f98e28a9ae7f9dd56ec\")
      (:FILE \"src/index/write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0c8c579cd7db466d243ed3ea9f8e8aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/write.fasl\"
       :FASL-MD5 \"5a28df9380bba3a081231bfa0582af17\")
      (:FILE \"src/io/flush.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"716866194d6b9f076e102e84187229c0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/flush.fasl\"
       :FASL-MD5 \"c45f65dae49db0bdcbc76af7647a731a\")
      (:FILE \"src/io/lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"11c7103efbe733bbf0a13927f23c3d34\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/lifecycle.fasl\"
       :FASL-MD5 \"777b4c27aa41f84e7eff48f37baab9c7\")
      (:FILE \"src/io/native.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9500cfb800603de002d6d2b24f1bf056\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/native.fasl\"
       :FASL-MD5 \"8eec9ad0419f4ca2bbc59d94b38b7c82\")
      (:FILE \"src/io/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c9380ad46a1d7acf41655aaed20db478\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/package.fasl\"
       :FASL-MD5 \"9a51c6da859f95c5c932a9e9569e9ea2\")
      (:FILE \"src/io/transfer.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a5e7108e80664eb3b562fbd7e680801f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/transfer.fasl\"
       :FASL-MD5 \"e49efb62eae361271ad6994618528b83\")
      (:FILE \"src/io/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"db8497f9cff35b1ee261f1f410f46ca6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/types.fasl\"
       :FASL-MD5 \"097f90cba7c86c097ee04fdd0ae5596b\")
      (:FILE \"src/mvcc/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f188d1dbd5d0adb49f53acf09157aef9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/package.fasl\"
       :FASL-MD5 \"cbbae61dcd0dee8cf26fd56061590caa\")
      (:FILE \"src/mvcc/snapshots-core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8bb066aab61a18eff175b9edb11e42a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-core.fasl\"
       :FASL-MD5 \"ad55c43202a533809b3e75733112bd29\")
      (:FILE \"src/mvcc/snapshots-csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"0e9365e674d1584b111f915ce1f58634\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-csn.fasl\"
       :FASL-MD5 \"b9b3e415f76bd9c03c8861264c6a57ca\")
      (:FILE \"src/mvcc/snapshots-lifecycle.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ff98aea5cb9a7ae2671f6a887a003725\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-lifecycle.fasl\"
       :FASL-MD5 \"bcac2f4606cb6de7a95cadd5556d05ae\")
      (:FILE \"src/mvcc/snapshots-read.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ae3ad96269b5e711a9dbb455f3c0ce48\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-read.fasl\"
       :FASL-MD5 \"47b47c94a15e2c842dd5fc98bd973a82\")
      (:FILE \"src/mvcc/snapshots-register.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2d5a795bcefd605c75da91c725ae83a2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-register.fasl\"
       :FASL-MD5 \"2860e7e94c49efad48ea1e90c05acbd2\")
      (:FILE \"src/mvcc/snapshots-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"475517bd7ba04a1c37a82efeb8ff73d9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-types.fasl\"
       :FASL-MD5 \"695e3f39d4cc4e046443f030eaaea65e\")
      (:FILE \"src/mvcc/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a9bc70eab6720b5c6f8503178e2c966b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/types.fasl\"
       :FASL-MD5 \"f80d43006b5118b7351e4f26d656adf8\")
      (:FILE \"src/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"becf5c78049c85f2c05cd1ef54454032\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/package.fasl\"
       :FASL-MD5 \"1fbf59d226dd3ed20f58be940b2f9638\")
      (:FILE \"src/read/core.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"4040905f4a64ba704a480d82e87ec748\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/core.fasl\"
       :FASL-MD5 \"1f9e545f2238339f210638351b927ed4\")
      (:FILE \"src/read/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7d74d9decc5a0bc9f9331d89bd503e21\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/package.fasl\"
       :FASL-MD5 \"6e3ee417bba0fc7dc70be30babe51b63\")
      (:FILE \"src/read/task.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9e0baf22c53329d393e047c669679645\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/task.fasl\"
       :FASL-MD5 \"c5c3a205d2dffff692ecb7ffe5999870\")
      (:FILE \"src/read/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9c37ff8237fcc9fe9ae4f44316e854e3\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/types.fasl\"
       :FASL-MD5 \"5fffbb0b18e82090d8739868857f9b82\")
      (:FILE \"src/recovery/decisions-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1a51ef4a488bb9fde2ff7d47bae01379\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-build.fasl\"
       :FASL-MD5 \"79cd063a2392225a47494187f53498d8\")
      (:FILE \"src/recovery/decisions-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cbdc30f93109c474e1fc25066c9b9b13\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-package.fasl\"
       :FASL-MD5 \"1da43c3cc7157c18a132126bcf339dd2\")
      (:FILE \"src/recovery/decisions-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f782d1137b8ce342b91c9999cfb7accc\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-query.fasl\"
       :FASL-MD5 \"451697bbae6b6077220fac282ae4f4e4\")
      (:FILE \"src/recovery/decisions-radix.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"852149de4c289b8e067602780378d87a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-radix.fasl\"
       :FASL-MD5 \"c18f9bea49d626a78903d2db3ce6de82\")
      (:FILE \"src/recovery/decisions-sort.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b33e57a643f2fca810846f6226366253\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-sort.fasl\"
       :FASL-MD5 \"485a9ba8109ae9df685c3b7347276655\")
      (:FILE \"src/recovery/decisions-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f4433fd19ebc7239dbc2628c39f3ecdb\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-types.fasl\"
       :FASL-MD5 \"1cce49fa37e590cef03d3f64ef5967df\")
      (:FILE \"src/recovery/inventory-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"9bd6820c4feba3e552aab1a4edd87861\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/inventory-build.fasl\"
       :FASL-MD5 \"877c307aa1ec9ec15d252c3b13a72ea1\")
      (:FILE \"src/recovery/inventory-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcea263de1938767772e5b11411ecd5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/inventory-query.fasl\"
       :FASL-MD5 \"2e151ae56d9805663cff504cf94a60ed\")
      (:FILE \"src/recovery/inventory-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"78c136d5838dcfe3019d9069643a8d8f\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/inventory-types.fasl\"
       :FASL-MD5 \"273cce396631867d9dfb6b91896dc4fd\")
      (:FILE \"src/recovery/manifest-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"bf65b1731eab6e0572461ef5cc60fc40\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-build.fasl\"
       :FASL-MD5 \"8a9ba850ed5ab4def4c1859668baa5d2\")
      (:FILE \"src/recovery/manifest-decode.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"67975249aaabd751757cdfb9222cc3c4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-decode.fasl\"
       :FASL-MD5 \"06decaeebc1b295055e326fdcbc5cac9\")
      (:FILE \"src/recovery/manifest-fold.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0d2498db1011e857b7b0daa1934f187\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-fold.fasl\"
       :FASL-MD5 \"9b49927ad1cac09804b79dcb2d8a39cb\")
      (:FILE \"src/recovery/manifest-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"37ace42844c11b52446ee1fc500b8e0b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-package.fasl\"
       :FASL-MD5 \"a2006c80b0f584d5da029e1de03842fc\")
      (:FILE \"src/recovery/manifest-query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ebd7a54adea2213294a887e6d4db0927\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-query.fasl\"
       :FASL-MD5 \"80bb7dca6dbc6e5d0b701d34781724f6\")
      (:FILE \"src/recovery/manifest-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7b1d4054415faca7e5fca59ad83b4d4a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-types.fasl\"
       :FASL-MD5 \"f5213b6e55425389d99b117f044efa9f\")
      (:FILE \"src/recovery/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1c1c8ad0cd15b1703a2fe19cbf3f13c2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/package.fasl\"
       :FASL-MD5 \"cc7d1d8fad85ce9ecec2dc7f4cc3a258\")
      (:FILE \"src/recovery/scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"fcacd15460db25ea9cc4036065f9f096\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/scan.fasl\"
       :FASL-MD5 \"c043180d3c4877dde6e476b6b74294ad\")
      (:FILE \"src/series/events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"32b2156739a6f2ca996abb91df0a2603\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/events.fasl\"
       :FASL-MD5 \"13bcb02d15386a52c2ae217f148bd243\")
      (:FILE \"src/series/io-events.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b6026a8b7bb64b45c37a65effda70d8e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/io-events.fasl\"
       :FASL-MD5 \"9c372355628d46eff534f120001f7445\")
      (:FILE \"src/series/ownership.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"de1aca16a35d34d16aba12ff541c0d2b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/ownership.fasl\"
       :FASL-MD5 \"40d3ef58a2843ee533a88cb549467d20\")
      (:FILE \"src/series/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"59e3c59c90d8d0fc5731b87496a785aa\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/package.fasl\"
       :FASL-MD5 \"3e399a0a31474150e6c3a07555f80fe2\")
      (:FILE \"src/series/publication.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"056d2c6a67c9d9f2bf9fe2d2c348d53c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/publication.fasl\"
       :FASL-MD5 \"923e9420f9ec613465b50f50bb033e9a\")
      (:FILE \"src/series/query.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb0d91405325b508e6b2ab24d178de7a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/query.fasl\"
       :FASL-MD5 \"812b2011f0aef8e7a81f2ff20eea1e67\")
      (:FILE \"src/series/retirement.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b8e04971b8ad75a1bd0c722997badfd2\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/retirement.fasl\"
       :FASL-MD5 \"8037675dcbb048a36f57d4bea01a557a\")
      (:FILE \"src/series/routing-build.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6924deff152b941bd49f0bb200b4197\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/routing-build.fasl\"
       :FASL-MD5 \"dc274a460f33c3095e2dccb2526a64e4\")
      (:FILE \"src/series/routing-select.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"e0f987d8767744050ec4d1b3ecb699ed\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/routing-select.fasl\"
       :FASL-MD5 \"d93dce82bf7074d5e091ed5775efbae3\")
      (:FILE \"src/series/routing-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ce649df47dd38888d5103c98345f7e41\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/routing-types.fasl\"
       :FASL-MD5 \"190c2d3283db2fc49ce47c33aaf0950f\")
      (:FILE \"src/series/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"ab19ec8d15af91511e817858c41cebc8\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/types.fasl\"
       :FASL-MD5 \"51d47b6777c994823399d4fc1a50cd81\")
      (:FILE \"src/series/worker-boundary.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2340e0c9074f7b1bf80c74f774986bc5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-boundary.fasl\"
       :FASL-MD5 \"d2b0b1913419426953728b7974ed3188\")
      (:FILE \"src/series/worker-package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a93ce2e84e8aee647b5083ad1d2b899b\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-package.fasl\"
       :FASL-MD5 \"899f5066dd98a46e8199b0e33218354b\")
      (:FILE \"src/series/worker-run.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f0fee18adf357bad98e8a3c3e8c70c0c\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-run.fasl\"
       :FASL-MD5 \"9ab78a227872472ddcd06209467cc1c7\")
      (:FILE \"src/series/worker-types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"2b23d468be0165fa009c5ebd5d1bbe23\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-types.fasl\"
       :FASL-MD5 \"c6d49ca15f18a4d7bd25101f2ce26798\")
      (:FILE \"src/storage/compaction-scan.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"1cda77a357ab2147035993b72d135a37\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/compaction-scan.fasl\"
       :FASL-MD5 \"f2460eb373451c70099962915e216beb\")
      (:FILE \"src/storage/control-payload.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"cb64f806b8d69eb42d865b4abfff0b27\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/control-payload.fasl\"
       :FASL-MD5 \"437bc0bb08c6c12a70e25526e825b981\")
      (:FILE \"src/storage/formats.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"061147be459d8d3b08c661bd3f91d152\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/formats.fasl\"
       :FASL-MD5 \"b09ec9d2c4f766b908a711df0ade76b5\")
      (:FILE \"src/storage/log-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"b53d27dcc9f4badf18b50519c50bc614\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/log-header.fasl\"
       :FASL-MD5 \"667c2e773ada0bb636b95d96dc5a63ef\")
      (:FILE \"src/storage/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f86bd104f20616a76b42c02227f72844\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/package.fasl\"
       :FASL-MD5 \"8aab472c42598e5c4e7e27c77f2156dc\")
      (:FILE \"src/storage/payload-record.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"8c03f9c01dcb30f2d3970a5694968ecf\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/payload-record.fasl\"
       :FASL-MD5 \"5f81ec32e737f65c014ca83d02c364c6\")
      (:FILE \"src/storage/payload-write.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c4ece3c4fa8d9492d2a80df7c0a4f5a0\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/payload-write.fasl\"
       :FASL-MD5 \"99376d8d3d16dc69ec90edb1d947c2b7\")
      (:FILE \"src/storage/segment-header.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"d6812fa59bf8fd1252fbf85a9bfa3896\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/segment-header.fasl\"
       :FASL-MD5 \"d31d333b5b38fd8e667b69b164262573\")
      (:FILE \"src/wal/builder.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"a229f76f7036f3573a6e528dcd390a19\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/builder.fasl\"
       :FASL-MD5 \"9205732cf67cbfd873aef516803cc77f\")
      (:FILE \"src/wal/csn.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"42b990e3b254e6fb488c0ab91b6a6502\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/csn.fasl\"
       :FASL-MD5 \"0d4717caea32f54e2aa484a8c94dfe71\")
      (:FILE \"src/wal/executor.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"c0340924c9130e14d0e8efedeec078f1\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/executor.fasl\"
       :FASL-MD5 \"12e66a3f72f728a1cdc29b351acd4162\")
      (:FILE \"src/wal/group.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"7a0e7c99ab70b4720cbb091156560f5e\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/group.fasl\"
       :FASL-MD5 \"72fa5a80283c1fd2744c1b6952eb1e8b\")
      (:FILE \"src/wal/package.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"96c41b1d417135a24fc65659ea3abe11\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/package.fasl\"
       :FASL-MD5 \"2411728a39980c94c6cfd5698f081fdc\")
      (:FILE \"src/wal/types.lisp\" :ROLE :PRODUCT :SOURCE-MD5
       \"f799f27a8ac1a4c736c04796c1e543f9\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/types.fasl\"
       :FASL-MD5 \"8a9af505a0a250812c6602c6a85dd902\"))
     :COMPILED-SUITE
     ((:FILE \"tests/foundation/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"758adad069aec2f9dbe0635797314ff6\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/tests/foundation/support.fasl\"
       :FASL-MD5 \"1835a9ca68c5b3643b4290db2c7def41\")
      (:FILE \"tests/get-directory/support.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"3f868ebe4307ad4238b314c37eceed9a\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/support.fasl\"
       :FASL-MD5 \"3b63b0601dcfd4195759da604e189642\")
      (:FILE \"tests/get-directory/construction.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"1137938073e71d6d8d62c751fbad05d5\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/construction.fasl\"
       :FASL-MD5 \"23bb70339481a8a3e6c05b5b1edb4ba8\")
      (:FILE \"tests/get-directory/read.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"d1ab36d05cc1266e4533d27c693f12f4\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/read.fasl\"
       :FASL-MD5 \"3669fb1f4ef1374f7aa3f121678aabd9\")
      (:FILE \"tests/get-directory/threads.lisp\" :ROLE :SUITE :SOURCE-MD5
       \"63dd01c852de1399c2c82274d481d257\" :FASL
       \"/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/threads.fasl\"
       :FASL-MD5 \"66ab11b2e3c8401ad49fd6b9d985f1ad\"))
     :FAILED-TEST \"TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS\"
     :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE \"SIMPLE-ERROR\"
     :DIAGNOSTIC \"Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (ARCDOCDB.GET.DIRECTORY:RISOLVI-CANDIDATO-DIRECTORY-GET
                       ARCDOCDB.GET.DIRECTORY.TESTS::CONTEXT
                       (ARCDOCDB.GET.DIRECTORY.TESTS:DIRECTORY-FIXTURE-DIRECTORY
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVARIANT-VIOLATION (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :RESOLVER-CANDIDATE-SIZE)))\"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . \"5abd0c88793c21103e61d4c4d326d024\") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . \"dde814f850eae82069c02ec9348edf34\") :ARTIFACTS-VERIFIED
   T))
 :COUNTERS
 (:DETECTED 5 :SURVIVED 0 :BASELINE-PASSED 1 :BASELINE-FAILED 0
  :COMPILATION-ERROR 0 :INFRASTRUCTURE-ERROR 0 :INVALID 0 :NOT-RUN 0 :PENDING
  0)
 :DETECTED 5 :SURVIVED 0 :COMPILATION-ERRORS 0 :INFRASTRUCTURE-ERRORS 0
 :INVALID-RESULTS 0 :SOURCE-CONSISTENCY :STABLE :LIMITS
 (:ONLY-DIRECTORY-BUILD-READ-MUTATED :CLOSED-ONLY
  :ONLY-DIRECTORY-SUITE-EXECUTED :FOUNDATION-SUPPORT-DEFINITIONS-ONLY
  :ALL-PRODUCT-SOURCES-COMPILED :FRESH-CHILD-PRIVATE-ASDF-OUTPUT
  :SOURCE-AND-FASL-MD5-ATTESTATION :ONE-NAMED-TEST-PER-MUTANT
  :ASSERTIONS-AND-PRODUCT-CONDITIONS-SEPARATED
  :COMPILER-FIXTURE-IO-TIMEOUT-CRASH-AND-TYPE-ERRORS-ARE-NOT-KILLS
  :PARTIAL-COPIES-AND-LOGS-RETAINED :BOUNDED-CLEANUP :NO-ENGINE-QUALIFICATION))
"
 :STDERR "" :EXIT-CODE 0 :LIMITS
 (:COMMAND-OUTPUT-IS-RAW :WALL-TIME-INCLUDES-ENTIRE-COMMAND
  :NO-AUTOMATIC-REQUIREMENT-PROMOTION))
