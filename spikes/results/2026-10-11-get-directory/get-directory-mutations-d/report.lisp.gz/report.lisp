(:ELAPSED-SECONDS 6235617/200000 :SOURCE-FINGERPRINTS-AFTER
 ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . "692a695f7129e0cc693cffb2983be35b"))
  (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
  (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
  (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
  (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
  (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
  (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
  (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
  (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
  (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
  (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
  (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "62285b01dc017898fc16588b6522bbbf"))
  (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
  (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
  (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
  (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
  (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
  (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
  (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
  (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
  (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
  (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
  (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
  (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
  (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
  (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
  (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
  (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
  (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
  (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
  (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
  (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
  (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
  (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
  (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
  (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
  (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
  (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
  (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
  (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
  (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
  (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
  (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
  (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
  (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
  (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
  (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
  (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
  (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
  (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119"))
  (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
  (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
  (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
  (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
  (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
  (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
  (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
  (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
  (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
  (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
  (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
  (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
  (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
  (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
  (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
  (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
  (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
  (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
  (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
  (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
  (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
  (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
  (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
  (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
  (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
  (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
  (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
  (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
  (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
  (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
  (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
  (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
  (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
  (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
  (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
  (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
  (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
  (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
  (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
  (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
  (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
  (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
  (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
  (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
  (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
  (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
  (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
  (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
  (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
  (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
  (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
  (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
  (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
  (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
  (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
  (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
  (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
  (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
  (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
  (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
  (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
  (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
  (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
  (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
  (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
  (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
  (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
  (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
  (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
  (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
  (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
  (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
  (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
  (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
  (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
  (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
  (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
  (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
  (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
  (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
  (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
  (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
  (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
  (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
  (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
  (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
  (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
  (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
  (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
  (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
  (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
  (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
  (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
  (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
  (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
  (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
  (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
  (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
  (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
  (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
  (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
  (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
  (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
  (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
  (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
  (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
  (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
  (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
  (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
  (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
  (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
  (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
  (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
  (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
  (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
  (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
  (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257"))
  (:FILE "tools/get-directory-mutation.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fe7ec868b29f06eb5e968896d5b431dc")))
 :FROZEN-MANIFEST
 ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . "692a695f7129e0cc693cffb2983be35b"))
  (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
  (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
  (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
  (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
  (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
  (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
  (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
  (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
  (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
  (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
  (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "62285b01dc017898fc16588b6522bbbf"))
  (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
  (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
  (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
  (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
  (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
  (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
  (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
  (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
  (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
  (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
  (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
  (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
  (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
  (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
  (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
  (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
  (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
  (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
  (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
  (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
  (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
  (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
  (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
  (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
  (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
  (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
  (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
  (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
  (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
  (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
  (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
  (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
  (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
  (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
  (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
  (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
  (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
  (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119"))
  (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
  (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
  (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
  (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
  (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
  (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
  (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
  (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
  (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
  (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
  (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
  (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
  (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
  (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
  (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
  (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
  (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
  (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
  (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
  (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
  (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
  (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
  (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
  (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
  (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
  (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
  (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
  (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
  (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
  (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
  (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
  (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
  (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
  (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
  (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
  (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
  (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
  (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
  (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
  (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
  (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
  (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
  (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
  (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
  (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
  (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
  (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
  (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
  (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
  (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
  (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
  (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
  (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
  (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
  (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
  (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
  (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
  (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
  (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
  (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
  (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
  (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
  (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
  (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
  (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
  (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
  (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
  (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
  (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
  (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
  (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
  (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
  (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
  (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
  (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
  (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
  (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
  (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
  (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
  (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
  (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
  (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
  (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
  (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
  (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
  (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
  (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
  (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
  (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
  (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
  (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
  (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
  (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
  (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
  (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
  (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
  (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
  (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
  (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
  (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
  (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
  (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
  (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
  (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
  (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
  (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
  (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
  (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
  (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
  (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
  (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
  (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
  (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
  (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
  (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
  (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
  (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
 :SOURCE-FINGERPRINTS-BEFORE
 ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . "692a695f7129e0cc693cffb2983be35b"))
  (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
  (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
  (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
  (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
  (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
  (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
  (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
  (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
  (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
  (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
  (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "62285b01dc017898fc16588b6522bbbf"))
  (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
  (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
  (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
  (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
  (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
  (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
  (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
  (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
  (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
  (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
  (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
  (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
  (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
  (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
  (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
  (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
  (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
  (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
  (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
  (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
  (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
  (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
  (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
  (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
  (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
  (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
  (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
  (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
  (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
  (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
  (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
  (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
  (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
  (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
  (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
  (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
  (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
  (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119"))
  (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
  (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
  (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
  (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
  (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
  (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
  (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
  (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
  (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
  (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
  (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
  (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
  (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
  (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
  (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
  (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
  (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
  (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
  (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
  (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
  (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
  (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
  (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
  (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
  (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
  (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
  (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
  (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
  (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
  (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
  (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
  (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
  (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
  (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
  (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
  (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
  (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
  (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
  (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
  (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
  (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
  (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
  (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
  (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
  (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
  (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
  (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
  (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
  (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
  (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
  (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
  (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
  (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
  (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
  (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
  (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
  (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
  (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
  (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
  (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
  (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
  (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
  (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
  (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
  (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
  (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
  (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
  (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
  (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
  (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
  (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
  (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
  (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
  (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
  (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
  (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
  (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
  (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
  (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
  (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
  (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
  (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
  (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
  (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
  (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
  (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
  (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
  (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
  (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
  (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
  (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
  (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
  (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
  (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
  (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
  (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
  (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
  (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
  (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
  (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
  (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
  (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
  (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
  (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
  (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
  (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
  (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
  (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
  (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
  (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
  (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
  (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
  (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
  (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
  (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
  (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
  (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257"))
  (:FILE "tools/get-directory-mutation.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fe7ec868b29f06eb5e968896d5b431dc")))
 :DIRECTORY
 #A((98) BASE-CHAR
    . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/")
 :SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATIONS :STATUS :OK :RECORDED-AT
 4000716002 :SBCL #A((5) BASE-CHAR . "2.6.9") :ARGV
 (#A((48) BASE-CHAR . "/opt/homebrew/Cellar/sbcl/2.6.9/libexec/bin/sbcl")
  #A((7) BASE-CHAR . "--check")
  #A((37) BASE-CHAR . "spikes/out/get-directory-mutations-d/"))
 :CHILD-DEADLINE-SECONDS 120 :CAMPAIGN-DEADLINE-SECONDS 900
 :CLEANUP-DEADLINE-SECONDS 2 :TARGETS
 ((:NAME "omit-directory-owner" :FILE "src/get-directory/build.lisp" :TEST
   "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER" :BEFORE
   "(unless (eq view (segmento-get-owner segment))" :AFTER
   "(unless (or (eq view (segmento-get-owner segment)) view)" :EXPECTED-FAILURE
   :FOREIGN-DIRECTORY-ACCEPTED)
  (:NAME "missing-location-first-map" :FILE "src/get-directory/read.lisp" :TEST
   "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP" :BEFORE
   "(when (= left right) (guasto-get context :directory-location-absent))"
   :AFTER "(when (= left right)
               (if (plusp (length maps))
                   (return-from cerca-mappa-directory-get
                     (the mappa-segmento-get (svref maps 0)))
                   (guasto-get context :directory-location-absent)))"
   :EXPECTED-FAILURE :MISSING-PUBLISHED-SEGMENT-AUTHORIZED)
  (:NAME "alias-input-maps" :FILE "src/get-directory/build.lisp" :TEST
   "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED" :BEFORE
   "(owned (copy-seq maps))" :AFTER "(owned maps)" :EXPECTED-FAILURE
   :CALLER-ARRAY-CHANGES-DIRECTORY)
  (:NAME "truncate-directory-id" :FILE "src/get-directory/read.lisp" :TEST
   "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID" :BEFORE
   "(ldb (byte 32 32) location)" :AFTER "(ldb (byte 31 32) location)"
   :EXPECTED-FAILURE :MAX-U32-LOCATION-REJECTED)
  (:NAME "bypass-closed-resolver" :FILE "src/get-directory/read.lisp" :TEST
   "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS" :BEFORE
   "(risolvi-candidato-get context (trova-mappa-directory-get context directory))"
   :AFTER "(let ((map (trova-mappa-directory-get context directory)))
    (values (mappa-segmento-get-segment map)
            (arcdocdb.get.resolver::mappa-segmento-get-end map) 0 nil))"
   :EXPECTED-FAILURE :CANDIDATE-SIZE-AND-RESERVED-HIGH-BITS-NOT-CHECKED :LIMIT
   :ONLY-DIRECTORY-RESOLVE-WRAPPER))
 :SELF-TEST
 (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-SELF-TEST :STATUS :OK
  :CLASSIFIER-CASES 39 :NO-PROCESSES T :NO-COMPILATION T
  :NO-PRODUCT-OR-SUITE-LOADED T :PARSER-POSITIVE-AND-NEGATIVE T
  :FIXTURE-AND-PRODUCT-COVERAGE-GUARDS T :COUNTER-COVERAGE T)
 :EXPECTED-SUITE
 ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
  "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
  "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
  "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
  "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
  "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
  "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
  "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
  "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
  "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
  "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
  "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
  "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
  "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
  "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
  "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
  "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
  "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
  "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
  "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
  "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
  "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
  "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
  "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
  "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
  "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
  "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
  "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
  "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
 :BASELINE
 (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME "baseline" :FILE
  "src/get-directory/read.lisp" :DIRECTORY
  #A((125) BASE-CHAR
     . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/")
  :EXPECTED-FAILURE NIL :SUBSTITUTION NIL :STATUS :OK :RESULT :BASELINE-PASSED
  :DIAGNOSTIC NIL :EXPECTED-TESTS
  ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
   "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
   "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
   "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
   "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
   "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
   "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
   "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
   "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
   "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
   "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
   "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
   "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
   "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
   "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
   "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
   "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
   "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
   "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
   "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
   "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
   "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
   "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
   "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
   "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
   "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
   "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
   "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
   "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
  :SOURCE-MANIFEST
  ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
    #A((32) BASE-CHAR . "692a695f7129e0cc693cffb2983be35b"))
   (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
   (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
   (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
   (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
   (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
   (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
   (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
   (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
   (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
   (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
   (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "62285b01dc017898fc16588b6522bbbf"))
   (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
   (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
   (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
   (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
   (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
   (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
   (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
   (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
   (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
   (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
   (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
   (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
   (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
   (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
   (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
   (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
   (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
   (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
   (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
   (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
   (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
   (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
   (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
   (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
   (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
   (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
   (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
   (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
   (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
   (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
   (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
   (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
   (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
   (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
   (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
   (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
   (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
   (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119"))
   (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
   (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
   (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
   (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
   (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
   (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
   (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
   (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
   (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
   (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
   (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
   (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
   (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
   (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
   (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
   (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
   (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
   (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
   (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
   (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
   (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
   (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
   (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
   (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
   (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
   (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
   (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
   (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
   (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
   (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
   (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
   (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
   (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
   (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
   (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
   (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
   (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
   (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
   (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
   (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
   (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
   (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
   (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
   (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
   (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
   (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
   (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
   (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
   (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
   (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
   (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
   (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
   (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
   (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
   (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
   (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
   (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
   (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
   (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
   (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
   (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
   (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
   (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
   (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
   (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
   (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
   (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
   (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
   (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
   (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
   (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
   (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
   (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
   (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
   (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
   (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
   (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
   (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
   (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
   (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
   (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
   (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
   (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
   (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
   (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
   (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
   (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
   (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
   (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
   (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
   (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
   (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
   (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
   (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
   (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
   (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
   (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
   (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
   (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
   (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
   (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
   (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
   (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
   (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
   (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
   (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
   (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
   (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
   (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
   (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
   (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
   (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
   (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
   (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
   (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
   (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
   (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
   (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
  :COMPILED-TARGET
  (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "477cc2d85814737322219ae7a807beea")
  :EXECUTION
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
   :ARGV
   ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
    "--script" "isolated-build.lisp")
   :STDOUT-LOG
   #A((135) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/stdout.log")
   :STDERR-LOG
   #A((135) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/stderr.log")
   :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 1592629/250000 :EXIT-CODE 0 :SIGNAL
   NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :COMPLETE
    :STATUS :OK :ROOT
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/"
    :SOURCE-MANIFEST
    ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
      "692a695f7129e0cc693cffb2983be35b")
     (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5d70197c8b64ad6f20c8be47a60c73ca")
     (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3546cf7f5c5ed138068548c20064f499")
     (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "72f3a33ce27ddf94c49c495580520004")
     (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a1f6a8e7aa4faed88e984b39871d1e53")
     (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "82f937b7b08bd1696ad9c88da2e1c60c")
     (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a25648d870eaa4f0b6e1e3b2cf76e28e")
     (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fc09021f74fb50aac57589614dae04d7")
     (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bc7a7b176e8cdd361b7c4306a1a4de4b")
     (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "6e8c6a49314c2f460aa6f8a1759200b6")
     (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ecd8fe950344059c629927b38fb6e4aa")
     (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "62285b01dc017898fc16588b6522bbbf")
     (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f6488e987889432b375254021825dbe5")
     (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "706c0baa4158bf272c4b0df17c1439d2")
     (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "987e8ed576a21eb644ac1ef2e06edbda")
     (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cf1999ddb10f879aeefbeea853742d57")
     (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0c33aedcdb352e78a3c694cf796e6692")
     (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c33cdcc45f45218aa3e8bf26ce0ee575")
     (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b13e92b5f24a42fe283c17b649722b6a")
     (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "69e77bcd15b5413a815a65c5081229db")
     (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d885bd2a9860eb60aec1a775e5031d5e")
     (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0f67dd5c51bf6a63bc292ab4e2a280c2")
     (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1130012fc5613a5648d22ed8628be0e8")
     (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a1cdb5661fc54beba5bf00e4765f3235")
     (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "765d14c88cd288093a77a57930cd6999")
     (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "875201dfab0a84efd40fe9828cc293c8")
     (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "975b5f74e0c5a38ce978f4d9c7fcc6b8")
     (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "036dd02adf87d33c3ae2f40735c733fa")
     (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "653b974f310c09f6e2224a84acc43bbf")
     (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "82253491f995f5bc153fb5ebf30d564c")
     (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "6b85eebe69366e78ed5fc5cc20735f00")
     (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cb5710d6c111cadb7121a50998a747fa")
     (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8202843bddb817da4279ac959ae3f3c4")
     (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "38d26f8c749dd946dfc4b9c57103a892")
     (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a64d98c9ff429d6103d6e10ee1fd7980")
     (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2c1892002f0599bb8273093031017520")
     (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c24065d6c8d80d1be53994a0041743df")
     (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "babd0a78b4185af24ae1fef870c0fabb")
     (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "aa34ca6bc07535e35fea723878d99f66")
     (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0679ee07c46f69db330706303c70d8d2")
     (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "73019644090e2971f2b54dc36e4491f5")
     (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ca642ea47e4bff76f78f5b6d7287d6bd")
     (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a06115175f450776762761dce25acdb8")
     (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "942b596396c19815290a57830af2121b")
     (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "4db58e2f48bf77d751f1b83bb9f84b5c")
     (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5ee593a112958d94163dab17c5aa4ba2")
     (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
     (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cde24b2bf5c5637d5501b95bed47df31")
     (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "4233eef9d87bdec712d4f690bcb699a9")
     (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "74a694385f1aaf03ec87721545494119")
     (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "17c957d6934a31f4ed64313e756de2d2")
     (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8d26428a4e17ad18990b8ee7d5f5b53a")
     (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "6d95f29b331d335175843f47ae44a6ea")
     (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f13d422adb6aa9e8489352884137f25a")
     (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3da469a7aa1e682dd8f2e516ee451de1")
     (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d6aaec49504a96f37c8ff1bc182c977b")
     (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bd7182e9871fe82530d0c828e473ccde")
     (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bbfb2082103e6712419e180ab972245c")
     (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cbfb17bf1f65698fb7c7889953d02d1e")
     (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1339edff0223dbf122f11ff0adbba61c")
     (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ca9002b81efd0aed9761cd1f78514762")
     (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "536e9dc4ed51072b8a6d1528d3ec18bf")
     (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2d869293ba47444c4721713d955c6254")
     (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9df13bcc6908e9fa601d173a671e1ccf")
     (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c5cc36884b238221cc13ca0c087ec7c2")
     (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e70bfeddd694336bbd088e65f8761834")
     (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "82258ec87aca513a508bc5dee8410dd6")
     (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c72633d15c3488699072eb610ebde7c8")
     (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "811869eb6a197d3c4e26af4322e52652")
     (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1b70dac05d6d2418909eb5105b808e81")
     (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c394e5684de5e2d938991c7cb348b93c")
     (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b5c51802e607e3dd22de68204baf64e9")
     (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bef497b9a267c7306d4100000491c814")
     (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "886b7c08b9929283e8968831cbe5c039")
     (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2d9060e41bc5252067d35e59ac70ee06")
     (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "65076c355c099b5dc73d185948d3bec4")
     (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "43d2209225707352daec6186ef95a805")
     (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "45ce41749bc6fa638539815d3f802b96")
     (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "598a9b65e73151c924b2cdcaf6d96705")
     (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a319691e3e28b7ea7b927de490cf69ba")
     (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ff2cfbb865290d7a1510fdf6877c7229")
     (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fa52433eae199ceeb874bf2bc47afca7")
     (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1dd67c527257e43f17e006644ecdbd00")
     (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d65cfce399b04f905bf969929962e59a")
     (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "699ce3f1615296fc27fcde3e0d63a4bc")
     (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3f317a0d3c5ee86a73651aad36135cc3")
     (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5155959766645d3172ae5e73c58cc071")
     (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a59eab6425a60fa2656f86bf87d5c9ac")
     (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e8e31e599356e592af29c0cc4604872b")
     (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5b22b90cfe8534086f6aff96d156713e")
     (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0417dd41cb3ec1d62dfd913c19f810ad")
     (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8befbbd00ed5c31c1487a11887eba495")
     (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1188e7a64a7a5d9482c1233cb9acb452")
     (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a450cac8071513365267e7024cbe94b0")
     (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "475dd7d5809a836f01544b447cc8df27")
     (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5157fd03ee806ee998ad8f0002d56268")
     (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3384cadf737c7d80c004222022a281f6")
     (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f0c8c579cd7db466d243ed3ea9f8e8aa")
     (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "716866194d6b9f076e102e84187229c0")
     (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "11c7103efbe733bbf0a13927f23c3d34")
     (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9500cfb800603de002d6d2b24f1bf056")
     (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c9380ad46a1d7acf41655aaed20db478")
     (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a5e7108e80664eb3b562fbd7e680801f")
     (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "db8497f9cff35b1ee261f1f410f46ca6")
     (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f188d1dbd5d0adb49f53acf09157aef9")
     (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8bb066aab61a18eff175b9edb11e42a2")
     (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0e9365e674d1584b111f915ce1f58634")
     (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ff98aea5cb9a7ae2671f6a887a003725")
     (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ae3ad96269b5e711a9dbb455f3c0ce48")
     (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2d5a795bcefd605c75da91c725ae83a2")
     (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "475517bd7ba04a1c37a82efeb8ff73d9")
     (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a9bc70eab6720b5c6f8503178e2c966b")
     (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "becf5c78049c85f2c05cd1ef54454032")
     (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "4040905f4a64ba704a480d82e87ec748")
     (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "7d74d9decc5a0bc9f9331d89bd503e21")
     (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9e0baf22c53329d393e047c669679645")
     (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9c37ff8237fcc9fe9ae4f44316e854e3")
     (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1a51ef4a488bb9fde2ff7d47bae01379")
     (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cbdc30f93109c474e1fc25066c9b9b13")
     (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f782d1137b8ce342b91c9999cfb7accc")
     (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "852149de4c289b8e067602780378d87a")
     (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b33e57a643f2fca810846f6226366253")
     (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f4433fd19ebc7239dbc2628c39f3ecdb")
     (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9bd6820c4feba3e552aab1a4edd87861")
     (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fcea263de1938767772e5b11411ecd5e")
     (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "78c136d5838dcfe3019d9069643a8d8f")
     (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bf65b1731eab6e0572461ef5cc60fc40")
     (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "67975249aaabd751757cdfb9222cc3c4")
     (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e0d2498db1011e857b7b0daa1934f187")
     (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "37ace42844c11b52446ee1fc500b8e0b")
     (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ebd7a54adea2213294a887e6d4db0927")
     (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "7b1d4054415faca7e5fca59ad83b4d4a")
     (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
     (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fcacd15460db25ea9cc4036065f9f096")
     (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "32b2156739a6f2ca996abb91df0a2603")
     (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b6026a8b7bb64b45c37a65effda70d8e")
     (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "de1aca16a35d34d16aba12ff541c0d2b")
     (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "59e3c59c90d8d0fc5731b87496a785aa")
     (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "056d2c6a67c9d9f2bf9fe2d2c348d53c")
     (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cb0d91405325b508e6b2ab24d178de7a")
     (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b8e04971b8ad75a1bd0c722997badfd2")
     (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d6924deff152b941bd49f0bb200b4197")
     (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e0f987d8767744050ec4d1b3ecb699ed")
     (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ce649df47dd38888d5103c98345f7e41")
     (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ab19ec8d15af91511e817858c41cebc8")
     (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2340e0c9074f7b1bf80c74f774986bc5")
     (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a93ce2e84e8aee647b5083ad1d2b899b")
     (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f0fee18adf357bad98e8a3c3e8c70c0c")
     (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2b23d468be0165fa009c5ebd5d1bbe23")
     (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1cda77a357ab2147035993b72d135a37")
     (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cb64f806b8d69eb42d865b4abfff0b27")
     (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "061147be459d8d3b08c661bd3f91d152")
     (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b53d27dcc9f4badf18b50519c50bc614")
     (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f86bd104f20616a76b42c02227f72844")
     (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8c03f9c01dcb30f2d3970a5694968ecf")
     (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
     (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d6812fa59bf8fd1252fbf85a9bfa3896")
     (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a229f76f7036f3573a6e528dcd390a19")
     (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "42b990e3b254e6fb488c0ab91b6a6502")
     (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c0340924c9130e14d0e8efedeec078f1")
     (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "7a0e7c99ab70b4720cbb091156560f5e")
     (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "96c41b1d417135a24fc65659ea3abe11")
     (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f799f27a8ac1a4c736c04796c1e543f9")
     (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
      "758adad069aec2f9dbe0635797314ff6")
     (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
      "3f868ebe4307ad4238b314c37eceed9a")
     (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
      "1137938073e71d6d8d62c751fbad05d5")
     (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
      "d1ab36d05cc1266e4533d27c693f12f4")
     (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
      "63dd01c852de1399c2c82274d481d257"))
    :SUITE-FILES
    ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
     "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
     "tests/get-directory/threads.lisp")
    :REGISTERED-TESTS
    ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
     "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
     "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
     "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
     "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
     "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
     "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
     "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
     "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
     "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
     "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
     "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
     "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
     "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
     "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
     "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
     "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
     "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
     "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
     "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
     "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
     "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
     "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
     "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
     "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
     "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
     "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
     "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
     "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
    :SELECTED-TEST NIL :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "74a694385f1aaf03ec87721545494119" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl"
     :FASL-MD5 "477cc2d85814737322219ae7a807beea")
    :COMPILED-PRODUCT
    ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/build.fasl"
      :FASL-MD5 "8ce0e3a1bbbbbf5e0cf5c4141e0875da")
     (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3546cf7f5c5ed138068548c20064f499" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/clock.fasl"
      :FASL-MD5 "965c235ec4a238a01a9ff2c319c684ec")
     (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "72f3a33ce27ddf94c49c495580520004" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/core.fasl"
      :FASL-MD5 "7a8a61bf04752f4f93a5908091af715d")
     (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/package.fasl"
      :FASL-MD5 "36bc79b15873260ce77d02f8fd88ff43")
     (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/read.fasl"
      :FASL-MD5 "7179d6ccb8c8c355f4d518b05336c7fb")
     (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/types.fasl"
      :FASL-MD5 "32efbbf69bbda31995871929c4ca978f")
     (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fc09021f74fb50aac57589614dae04d7" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/cache/write.fasl"
      :FASL-MD5 "bcca4d0f8aed07c5b67092dd1af5748e")
     (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-float-minimal.fasl"
      :FASL-MD5 "0531891e7f8347f0312baf14f3dfda95")
     (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-header.fasl"
      :FASL-MD5 "cb84c7ff309ca067182d9a59e36878c2")
     (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ecd8fe950344059c629927b38fb6e4aa" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-minimal.fasl"
      :FASL-MD5 "bace9ac0f352ac05e160601d0b0a42c7")
     (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "62285b01dc017898fc16588b6522bbbf" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-package.fasl"
      :FASL-MD5 "72ed9c6e139f9a55ed2fcb80d74b5d9e")
     (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f6488e987889432b375254021825dbe5" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-input.fasl"
      :FASL-MD5 "1efb55e70ffeec2111b87eb5e9dfed8b")
     (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "706c0baa4158bf272c4b0df17c1439d2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-items.fasl"
      :FASL-MD5 "a07402e22adb9e9494ff89b8d44d88a4")
     (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "987e8ed576a21eb644ac1ef2e06edbda" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-minimal.fasl"
      :FASL-MD5 "6c3e54a2f43612724f9877e9b867d8c6")
     (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cf1999ddb10f879aeefbeea853742d57" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-stack.fasl"
      :FASL-MD5 "16f31e88bfb88bcfcdbc7a5242ba9f4e")
     (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0c33aedcdb352e78a3c694cf796e6692" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan.fasl"
      :FASL-MD5 "6ae096a023e1480a8da1f90143ef4f20")
     (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-space.fasl"
      :FASL-MD5 "269cac09a1753b384d291334c681684d")
     (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b13e92b5f24a42fe283c17b649722b6a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-string-write.fasl"
      :FASL-MD5 "60f74619285ac04819867fdd15025701")
     (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "69e77bcd15b5413a815a65c5081229db" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/cbor-write.fasl"
      :FASL-MD5 "9d2e32b78d6568c324fb2cc3920c4347")
     (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d885bd2a9860eb60aec1a775e5031d5e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/package.fasl"
      :FASL-MD5 "b46f09c3b997e83442035472c4b35b62")
     (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/codec/utf8.fasl"
      :FASL-MD5 "ce2aa4f969799ed103994d6378344090")
     (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1130012fc5613a5648d22ed8628be0e8" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/csn/package.fasl"
      :FASL-MD5 "0ab2001fe00d289e8b2f80cb9fcb854f")
     (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a1cdb5661fc54beba5bf00e4765f3235" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/csn/registry.fasl"
      :FASL-MD5 "613dbc60aecaef0b4ae25b9023276fea")
     (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "765d14c88cd288093a77a57930cd6999" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/epochs/core.fasl"
      :FASL-MD5 "105da12e7208488784d2ffff0f7e7a5b")
     (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "875201dfab0a84efd40fe9828cc293c8" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/epochs/package.fasl"
      :FASL-MD5 "034a6c0e026a8838f5ffbdc3c1d0c4a3")
     (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/epochs/read.fasl"
      :FASL-MD5 "5d54eabe17e7651e5fca14677e861839")
     (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "036dd02adf87d33c3ae2f40735c733fa" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/epochs/reclaim.fasl"
      :FASL-MD5 "08046a0ab0bb446e1bac9d9c62177d0f")
     (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "653b974f310c09f6e2224a84acc43bbf" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/epochs/retire.fasl"
      :FASL-MD5 "c4c4ea8ce43f3f2074a4f8de6eded0a8")
     (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "82253491f995f5bc153fb5ebf30d564c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/epochs/types.fasl"
      :FASL-MD5 "d2008b43267cc48989149e6b3d9055cd")
     (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "6b85eebe69366e78ed5fc5cc20735f00" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/handoff.fasl"
      :FASL-MD5 "197e20b58955562651501f7a0294a0d2")
     (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cb5710d6c111cadb7121a50998a747fa" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/package.fasl"
      :FASL-MD5 "734c3ec6b853622f3869491b107be938")
     (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8202843bddb817da4279ac959ae3f3c4" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/queue.fasl"
      :FASL-MD5 "472f0444acf7d3888f483d0db070cfba")
     (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "38d26f8c749dd946dfc4b9c57103a892" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/ready-recycle.fasl"
      :FASL-MD5 "7c1513b89e62ef28a830b3eedac5c426")
     (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/ready-types.fasl"
      :FASL-MD5 "81442f4d732bac77ebb02c403b91f611")
     (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2c1892002f0599bb8273093031017520" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/ready.fasl"
      :FASL-MD5 "02c6836b720d6f6c7e01e85e0b02c127")
     (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c24065d6c8d80d1be53994a0041743df" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/worker-boundary.fasl"
      :FASL-MD5 "c313da9c54c8f28e61ea093db89dcaa6")
     (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "babd0a78b4185af24ae1fef870c0fabb" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/worker-claim.fasl"
      :FASL-MD5 "c27fd9e1fc5f5adc481ceea5f54b3455")
     (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "aa34ca6bc07535e35fea723878d99f66" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/worker-run.fasl"
      :FASL-MD5 "daa2c492e4b17e2dd32686c44da3eb9d")
     (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0679ee07c46f69db330706303c70d8d2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/worker-types.fasl"
      :FASL-MD5 "e2baa12d56487a65874ad90f961024ce")
     (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "73019644090e2971f2b54dc36e4491f5" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/execution/writer.fasl"
      :FASL-MD5 "104dcce9f952ca1f300434f1024a0bb0")
     (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/foundation/batch.fasl"
      :FASL-MD5 "49f41f1eb3d4d97faa4fb69c97c3df9b")
     (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a06115175f450776762761dce25acdb8" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/foundation/binary.fasl"
      :FASL-MD5 "967c5a6aaef42f6890e977aa47fec464")
     (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "942b596396c19815290a57830af2121b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/foundation/conditions.fasl"
      :FASL-MD5 "c11db511dcd2624244ae3cdfdcfe8606")
     (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/foundation/crc32c.fasl"
      :FASL-MD5 "b142dd53a5a004fe6f74f54ddb913667")
     (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5ee593a112958d94163dab17c5aa4ba2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/foundation/package.fasl"
      :FASL-MD5 "5e44acbef4bb1a6f726b5447221ebe82")
     (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/foundation/record.fasl"
      :FASL-MD5 "bdab1e0299c38c55b549fb3f5bc77301")
     (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cde24b2bf5c5637d5501b95bed47df31" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-directory/build.fasl"
      :FASL-MD5 "c64b4ce8df03f8b391c7ed485e1572ee")
     (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "4233eef9d87bdec712d4f690bcb699a9" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-directory/package.fasl"
      :FASL-MD5 "491322aea79e4dacc1926a99101873f7")
     (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "74a694385f1aaf03ec87721545494119" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl"
      :FASL-MD5 "477cc2d85814737322219ae7a807beea")
     (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "17c957d6934a31f4ed64313e756de2d2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-directory/types.fasl"
      :FASL-MD5 "6e696767ef5064c9ea5133582b544974")
     (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/active-build.fasl"
      :FASL-MD5 "5943cdb805eac10f402b2549f9498d5a")
     (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "6d95f29b331d335175843f47ae44a6ea" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/active-directory.fasl"
      :FASL-MD5 "02e7a5bf9e9d77f146bbe267e9263ec5")
     (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f13d422adb6aa9e8489352884137f25a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/active-preflight.fasl"
      :FASL-MD5 "37d393c42f27e9ec79255522316e3541")
     (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3da469a7aa1e682dd8f2e516ee451de1" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/active-read.fasl"
      :FASL-MD5 "fc43c87f1f6e7cc85352073532510c41")
     (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d6aaec49504a96f37c8ff1bc182c977b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/active-scan.fasl"
      :FASL-MD5 "5eea6d927f5eb5759859d56d49e8e3bf")
     (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bd7182e9871fe82530d0c828e473ccde" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/active-types.fasl"
      :FASL-MD5 "ec12216cb2e08d96e9862f1d13fcb99a")
     (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bbfb2082103e6712419e180ab972245c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/build.fasl"
      :FASL-MD5 "d66dd1d825216f5b577b5e5ff645a8bb")
     (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/package.fasl"
      :FASL-MD5 "21f9bbf5031534b85cbc14692848942a")
     (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1339edff0223dbf122f11ff0adbba61c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/read.fasl"
      :FASL-MD5 "c8ba1149c0df2a6ecb5575d51120aaa1")
     (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ca9002b81efd0aed9761cd1f78514762" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/rows.fasl"
      :FASL-MD5 "9ac3432f254e50c28677efb8ce98e666")
     (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/scan.fasl"
      :FASL-MD5 "d022389c9fc891970db17dd67da31520")
     (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2d869293ba47444c4721713d955c6254" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/sort.fasl"
      :FASL-MD5 "c814e75a3f7af58031e6ea31da6b259a")
     (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9df13bcc6908e9fa601d173a671e1ccf" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get-resolver/types.fasl"
      :FASL-MD5 "9f74706b360d579defc5ab2a82cc524a")
     (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c5cc36884b238221cc13ca0c087ec7c2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/build.fasl"
      :FASL-MD5 "40538bd915634795a5bcff3004a27380")
     (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e70bfeddd694336bbd088e65f8761834" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/lifecycle.fasl"
      :FASL-MD5 "4f65e619612b2a3381177e7a6e176036")
     (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "82258ec87aca513a508bc5dee8410dd6" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/lookup.fasl"
      :FASL-MD5 "15c3c9770c093f5a80ddce2e8d653a92")
     (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c72633d15c3488699072eb610ebde7c8" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/package.fasl"
      :FASL-MD5 "24f926a7ecafa646339a41dd61568152")
     (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "811869eb6a197d3c4e26af4322e52652" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/segment.fasl"
      :FASL-MD5 "49eb3f438f703256f8e4afb02f8cfbea")
     (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1b70dac05d6d2418909eb5105b808e81" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/target.fasl"
      :FASL-MD5 "b29e6b412871c62e6c50168f7375f0a7")
     (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c394e5684de5e2d938991c7cb348b93c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/get/types.fasl"
      :FASL-MD5 "cf201bfab9f592c114d50684807b53b6")
     (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b5c51802e607e3dd22de68204baf64e9" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/hash/arithmetic.fasl"
      :FASL-MD5 "f7595021562a50c9049ef5b5007056b9")
     (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bef497b9a267c7306d4100000491c814" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/hash/blocks.fasl"
      :FASL-MD5 "c31f4aa7945ad7f280c9b04305c2273b")
     (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "886b7c08b9929283e8968831cbe5c039" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/hash/hash64.fasl"
      :FASL-MD5 "76c887b034ba58a02e03a5e13e9972e0")
     (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2d9060e41bc5252067d35e59ac70ee06" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/hash/package.fasl"
      :FASL-MD5 "4ada3895f040593a66c396e6cb48cbe1")
     (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "65076c355c099b5dc73d185948d3bec4" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/core.fasl"
      :FASL-MD5 "29f472b9a2d9f7320bcc112572a3f9c7")
     (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "43d2209225707352daec6186ef95a805" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/hash-digests.fasl"
      :FASL-MD5 "375ddea6e22a94ce9f931d016f1f05be")
     (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "45ce41749bc6fa638539815d3f802b96" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/hash-seed.fasl"
      :FASL-MD5 "4dbf2fad8994a0e1f697eb3b25a940da")
     (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "598a9b65e73151c924b2cdcaf6d96705" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/package.fasl"
      :FASL-MD5 "f1416a87e2ec8551f1413f7adfd93aa4")
     (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a319691e3e28b7ea7b927de490cf69ba" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-arena.fasl"
      :FASL-MD5 "a7d83e85430ca9b3f67095317754d2a6")
     (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ff2cfbb865290d7a1510fdf6877c7229" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-build.fasl"
      :FASL-MD5 "dfc012dedfbb71a3b020694debea1f17")
     (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fa52433eae199ceeb874bf2bc47afca7" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-core.fasl"
      :FASL-MD5 "68ba62b95d3dc7d57596b4a839349434")
     (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1dd67c527257e43f17e006644ecdbd00" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-directory.fasl"
      :FASL-MD5 "dc38fbb6be73a70fba9b8021b3e57b13")
     (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d65cfce399b04f905bf969929962e59a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-package.fasl"
      :FASL-MD5 "10ab744174c930a4644ec76c18eb3c16")
     (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-probe.fasl"
      :FASL-MD5 "bf057aebafa778497c13fdb8cc339fb7")
     (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3f317a0d3c5ee86a73651aad36135cc3" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-read.fasl"
      :FASL-MD5 "49aaf8f52d406d1d28112930edb98ed4")
     (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5155959766645d3172ae5e73c58cc071" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-relocate.fasl"
      :FASL-MD5 "3f5c6eb4839943ba833ebdc0a267758f")
     (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-types.fasl"
      :FASL-MD5 "05c5259d91384f9d1a0fcf941198fbf3")
     (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e8e31e599356e592af29c0cc4604872b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/primary-write.fasl"
      :FASL-MD5 "4da3bebf8e7bb164c760b97b790d9a00")
     (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5b22b90cfe8534086f6aff96d156713e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/read.fasl"
      :FASL-MD5 "a73d44b6081b3a1fd5918ac4871ce970")
     (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/rebuild-budget.fasl"
      :FASL-MD5 "41a1615f33a4ca6904cc35600d086049")
     (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8befbbd00ed5c31c1487a11887eba495" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/rebuild-copy.fasl"
      :FASL-MD5 "fc72699d36bdd079c4baedd3cd1c1ebd")
     (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1188e7a64a7a5d9482c1233cb9acb452" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/rebuild-scan.fasl"
      :FASL-MD5 "60f66acd11d6bda00a7cf58f5bc66edb")
     (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a450cac8071513365267e7024cbe94b0" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/rebuild.fasl"
      :FASL-MD5 "3e8f7f6e0991059e992ffc1e2331760c")
     (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "475dd7d5809a836f01544b447cc8df27" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/relocate.fasl"
      :FASL-MD5 "453b186be89a34fd98c74d52166156ce")
     (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5157fd03ee806ee998ad8f0002d56268" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/types.fasl"
      :FASL-MD5 "5e794fe485c03e9680676752e1b8a76a")
     (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3384cadf737c7d80c004222022a281f6" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/validation.fasl"
      :FASL-MD5 "2e16001a53978863c97a9877503641a7")
     (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/index/write.fasl"
      :FASL-MD5 "77a3a3dbe4de4667af7bab60f40406de")
     (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "716866194d6b9f076e102e84187229c0" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/io/flush.fasl"
      :FASL-MD5 "719bc1d2c6fcdef5f99e6c49c1eaf68e")
     (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "11c7103efbe733bbf0a13927f23c3d34" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/io/lifecycle.fasl"
      :FASL-MD5 "fa960cefe556954c71bfa6143ad635fc")
     (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9500cfb800603de002d6d2b24f1bf056" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/io/native.fasl"
      :FASL-MD5 "b393dad3caf0ccbf69dd67b791454aef")
     (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c9380ad46a1d7acf41655aaed20db478" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/io/package.fasl"
      :FASL-MD5 "dc98df019ca9b7c16dfd04d724709c2b")
     (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a5e7108e80664eb3b562fbd7e680801f" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/io/transfer.fasl"
      :FASL-MD5 "68ac75acf345c9581b8d925318edb802")
     (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "db8497f9cff35b1ee261f1f410f46ca6" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/io/types.fasl"
      :FASL-MD5 "1c5e21b41c87174200ecccd715228b92")
     (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f188d1dbd5d0adb49f53acf09157aef9" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/package.fasl"
      :FASL-MD5 "46e894e8e64b16131866fbdb688ddd8f")
     (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8bb066aab61a18eff175b9edb11e42a2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-core.fasl"
      :FASL-MD5 "15d0cf4b824ea70f6b5aeade7b4b3e72")
     (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0e9365e674d1584b111f915ce1f58634" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-csn.fasl"
      :FASL-MD5 "f3d107d087cb49152089d617f8ebc59f")
     (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ff98aea5cb9a7ae2671f6a887a003725" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-lifecycle.fasl"
      :FASL-MD5 "45a7eaad164f62c3becbebc459ca2af3")
     (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-read.fasl"
      :FASL-MD5 "c88b5b5d2800acc1dff7d5ddcc65ee0e")
     (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2d5a795bcefd605c75da91c725ae83a2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-register.fasl"
      :FASL-MD5 "55df280a195754d9bb37b51d72018d4d")
     (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-types.fasl"
      :FASL-MD5 "222953b4b1f240420589c3f722ad7bef")
     (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a9bc70eab6720b5c6f8503178e2c966b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/mvcc/types.fasl"
      :FASL-MD5 "4b73ce15a5de07b85e1f05facf12afd0")
     (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "becf5c78049c85f2c05cd1ef54454032" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/package.fasl"
      :FASL-MD5 "051a9797d764edf0fc8d00535feb855c")
     (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "4040905f4a64ba704a480d82e87ec748" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/read/core.fasl"
      :FASL-MD5 "3eb2b462480475047b783a0689ce261a")
     (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/read/package.fasl"
      :FASL-MD5 "6e3fd3c52edc7e6888f36b30264b7c78")
     (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9e0baf22c53329d393e047c669679645" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/read/task.fasl"
      :FASL-MD5 "6af18b2f4f3352d6a66f2442327b7b3d")
     (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/read/types.fasl"
      :FASL-MD5 "7cddb4f1a50f776368755d7d737788ea")
     (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/decisions-build.fasl"
      :FASL-MD5 "aa5594322d0a8bd86a02f29ded7f2d41")
     (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cbdc30f93109c474e1fc25066c9b9b13" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/decisions-package.fasl"
      :FASL-MD5 "1b1393bffd87769284aa779416b1997a")
     (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f782d1137b8ce342b91c9999cfb7accc" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/decisions-query.fasl"
      :FASL-MD5 "6daa4ca950f8a36f204c619d8b8ca8ed")
     (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "852149de4c289b8e067602780378d87a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/decisions-radix.fasl"
      :FASL-MD5 "b766de5741b33b974943e6b2b73fef34")
     (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b33e57a643f2fca810846f6226366253" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/decisions-sort.fasl"
      :FASL-MD5 "567ecb830b8ead49b13a4e2781ef4d1c")
     (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/decisions-types.fasl"
      :FASL-MD5 "6bbe78d8f2634b587b3467f28ca685c5")
     (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9bd6820c4feba3e552aab1a4edd87861" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/inventory-build.fasl"
      :FASL-MD5 "529afacadb418d5e9d10dd6c7a7ba7e5")
     (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fcea263de1938767772e5b11411ecd5e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/inventory-query.fasl"
      :FASL-MD5 "9f4edcf59cc3c4b12a8d24b7ce106d6e")
     (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "78c136d5838dcfe3019d9069643a8d8f" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/inventory-types.fasl"
      :FASL-MD5 "d5c47fd3480427f0f080c77bdcee5310")
     (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bf65b1731eab6e0572461ef5cc60fc40" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/manifest-build.fasl"
      :FASL-MD5 "6adbbe889fbda150c100069e36f33fce")
     (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "67975249aaabd751757cdfb9222cc3c4" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/manifest-decode.fasl"
      :FASL-MD5 "7b40f0d2e31cdd15eb1bf4f9a44bcce1")
     (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e0d2498db1011e857b7b0daa1934f187" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/manifest-fold.fasl"
      :FASL-MD5 "4a82e619c6b2e9e5aa860fc075592805")
     (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "37ace42844c11b52446ee1fc500b8e0b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/manifest-package.fasl"
      :FASL-MD5 "70dd1a44a13e77868d992dde50b3d1ba")
     (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ebd7a54adea2213294a887e6d4db0927" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/manifest-query.fasl"
      :FASL-MD5 "b56f5e1532be9538412d1689163b5d28")
     (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/manifest-types.fasl"
      :FASL-MD5 "6bc94ea8daf7e954ee103f88dd0cf2ae")
     (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/package.fasl"
      :FASL-MD5 "1a25f9d19b12e30928634ec101adbe84")
     (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fcacd15460db25ea9cc4036065f9f096" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/recovery/scan.fasl"
      :FASL-MD5 "eb7087bbfbd4f63edbd7d6130d0ec057")
     (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "32b2156739a6f2ca996abb91df0a2603" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/events.fasl"
      :FASL-MD5 "e24860474427ac0ab28197492ff32465")
     (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b6026a8b7bb64b45c37a65effda70d8e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/io-events.fasl"
      :FASL-MD5 "69d5ff84f2070b4b51d688935a186417")
     (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "de1aca16a35d34d16aba12ff541c0d2b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/ownership.fasl"
      :FASL-MD5 "47b73b028842fc42cb447552dc0e75e1")
     (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "59e3c59c90d8d0fc5731b87496a785aa" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/package.fasl"
      :FASL-MD5 "3543558f941967fd11476501dc116753")
     (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/publication.fasl"
      :FASL-MD5 "bca50867d4624fbfae744c6fb4ee94ab")
     (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cb0d91405325b508e6b2ab24d178de7a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/query.fasl"
      :FASL-MD5 "da919b07b3d7082ad798321d65237187")
     (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b8e04971b8ad75a1bd0c722997badfd2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/retirement.fasl"
      :FASL-MD5 "61c48df4e326db1da6fa22e0635f979f")
     (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d6924deff152b941bd49f0bb200b4197" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/routing-build.fasl"
      :FASL-MD5 "4be9f3a812c4cf9cd5da8f36a930377c")
     (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e0f987d8767744050ec4d1b3ecb699ed" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/routing-select.fasl"
      :FASL-MD5 "b0903e7ab85193de38d6c1516cb4edf5")
     (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ce649df47dd38888d5103c98345f7e41" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/routing-types.fasl"
      :FASL-MD5 "7a76f13448bae5db535658644afb4246")
     (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ab19ec8d15af91511e817858c41cebc8" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/types.fasl"
      :FASL-MD5 "e9b1613210d8a6c126e1869958054466")
     (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2340e0c9074f7b1bf80c74f774986bc5" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/worker-boundary.fasl"
      :FASL-MD5 "6ebebf4e7b9159170b24ac89009d4cfc")
     (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/worker-package.fasl"
      :FASL-MD5 "6bd7a57c7771b6c1ba94534036a6d521")
     (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/worker-run.fasl"
      :FASL-MD5 "9e007c6a79d4c9ca4365e123a8799e32")
     (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/series/worker-types.fasl"
      :FASL-MD5 "5f790449cae7703e00d4a03e4e57aaf4")
     (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1cda77a357ab2147035993b72d135a37" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/compaction-scan.fasl"
      :FASL-MD5 "822e5db2ca6cb1a499ed6fcdf7abc465")
     (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cb64f806b8d69eb42d865b4abfff0b27" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/control-payload.fasl"
      :FASL-MD5 "f645f6277d222f290f3eb9af49319016")
     (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "061147be459d8d3b08c661bd3f91d152" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/formats.fasl"
      :FASL-MD5 "8289e1bac8d35437b9b47b39b271c15f")
     (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b53d27dcc9f4badf18b50519c50bc614" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/log-header.fasl"
      :FASL-MD5 "cd74446016974760c34f9feba8ff11be")
     (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f86bd104f20616a76b42c02227f72844" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/package.fasl"
      :FASL-MD5 "b381e97fce195c49e542a71de98f4850")
     (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/payload-record.fasl"
      :FASL-MD5 "fdc46906989740c03b79a61cd6f6d4cd")
     (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/payload-write.fasl"
      :FASL-MD5 "5b9e0f059be49959c938a45439bae7e1")
     (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/storage/segment-header.fasl"
      :FASL-MD5 "3780d1c9679d940438a85d7229797e24")
     (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a229f76f7036f3573a6e528dcd390a19" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/wal/builder.fasl"
      :FASL-MD5 "5612c337b546713e0a5e09c75cc70116")
     (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "42b990e3b254e6fb488c0ab91b6a6502" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/wal/csn.fasl"
      :FASL-MD5 "eebe745fd6b451521ca7b49a49f50834")
     (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c0340924c9130e14d0e8efedeec078f1" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/wal/executor.fasl"
      :FASL-MD5 "57e45ccce4b9e58271fac5f7398cea31")
     (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "7a0e7c99ab70b4720cbb091156560f5e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/wal/group.fasl"
      :FASL-MD5 "28c167fb62f06521ac5c7e15ebca8a77")
     (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "96c41b1d417135a24fc65659ea3abe11" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/wal/package.fasl"
      :FASL-MD5 "4ed69d0a0c567b1f3971ddcf2ddb4430")
     (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f799f27a8ac1a4c736c04796c1e543f9" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/src/wal/types.fasl"
      :FASL-MD5 "489ebb7b29b4fb07f0d29e8b524e7857"))
    :COMPILED-SUITE
    ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
      "758adad069aec2f9dbe0635797314ff6" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/tests/foundation/support.fasl"
      :FASL-MD5 "a33de8e447429bfdc19da0a4a2d9d924")
     (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
      "3f868ebe4307ad4238b314c37eceed9a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/tests/get-directory/support.fasl"
      :FASL-MD5 "2553a74bf9a3d078df55f83748d65fb1")
     (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
      "1137938073e71d6d8d62c751fbad05d5" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/tests/get-directory/construction.fasl"
      :FASL-MD5 "923e6e5c5a204451ff1e8e59785ae43a")
     (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
      "d1ab36d05cc1266e4533d27c693f12f4" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/tests/get-directory/read.fasl"
      :FASL-MD5 "9664eb20f13e7d7f6f22c30acbebdd35")
     (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
      "63dd01c852de1399c2c82274d481d257" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/baseline/fasl/tests/get-directory/threads.fasl"
      :FASL-MD5 "4adbb02362d26e51e088634c547058b0"))
    :FAILED-TEST NIL :PASSED-TESTS
    ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
     "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
     "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
     "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
     "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
     "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
     "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
     "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
     "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
     "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
     "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
     "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
     "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
     "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
     "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
     "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
     "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
     "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
     "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
     "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
     "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
     "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
     "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
     "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
     "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
     "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
     "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
     "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
     "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
    :FAILURE-KIND NIL :CONDITION-TYPE NIL :DIAGNOSTIC NIL))
  :DETAIL NIL :RUNNER-MD5
  #A((32) BASE-CHAR . "5a995d504e7082ff384c2007b729a9ab") :TARGET-SOURCE-MD5
  #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119") :ARTIFACTS-VERIFIED
  T)
 :MUTANTS
 ((:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   "omit-directory-owner" :FILE "src/get-directory/build.lisp" :DIRECTORY
   #A((137) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/")
   :EXPECTED-FAILURE :FOREIGN-DIRECTORY-ACCEPTED :SUBSTITUTION
   (:BEFORE "(unless (eq view (segmento-get-owner segment))" :AFTER
    "(unless (or (eq view (segmento-get-owner segment)) view)")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   ("TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER")
   :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . "692a695f7129e0cc693cffb2983be35b"))
    (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "62285b01dc017898fc16588b6522bbbf"))
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "db58ed1c3877f2d6ea58932d3bc75e56"))
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119"))
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
    (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
   :COMPILED-TARGET
   (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    "db58ed1c3877f2d6ea58932d3bc75e56" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl"
    :FASL-MD5 "f0308276da0bbaa2d1fa9d1d23dfefdf")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
     "--script" "isolated-build.lisp")
    :STDOUT-LOG
    #A((147) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/stdout.log")
    :STDERR-LOG
    #A((147) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/stderr.log")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 5129623/1000000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/"
     :SOURCE-MANIFEST
     ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
       "692a695f7129e0cc693cffb2983be35b")
      (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "62285b01dc017898fc16588b6522bbbf")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db58ed1c3877f2d6ea58932d3bc75e56")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "74a694385f1aaf03ec87721545494119")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9")
      (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257"))
     :SUITE-FILES
     ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
      "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
      "tests/get-directory/threads.lisp")
     :REGISTERED-TESTS
     ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
      "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
      "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
      "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
      "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
      "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
      "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
      "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
      "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
      "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
      "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
      "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
      "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
      "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
      "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
      "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
      "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
      "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
      "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
      "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
      "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
      "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
      "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
      "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
      "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
      "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
     :SELECTED-TEST
     "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "db58ed1c3877f2d6ea58932d3bc75e56" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl"
      :FASL-MD5 "f0308276da0bbaa2d1fa9d1d23dfefdf")
     :COMPILED-PRODUCT
     ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/build.fasl"
       :FASL-MD5 "767f8fd7f0ef3255bd731ab1dca64315")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/clock.fasl"
       :FASL-MD5 "0e3a41f24ada5cd097db2df2c9634012")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/core.fasl"
       :FASL-MD5 "b6daa67e9882d9d9a77fccc991031a09")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/package.fasl"
       :FASL-MD5 "1b4f18503fc166f67a03221509dd7f6f")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/read.fasl"
       :FASL-MD5 "38fbff367e78ef1ea7daa6f9a536b56f")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/types.fasl"
       :FASL-MD5 "62cae088caf6725a9dcd1b53f015c492")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/cache/write.fasl"
       :FASL-MD5 "574a482fa28484d367a18ca537632609")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-float-minimal.fasl"
       :FASL-MD5 "137df0aeec0c9a452588f14e5a57f381")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-header.fasl"
       :FASL-MD5 "4b9a01368b18f18bea2c35cfcff81def")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-minimal.fasl"
       :FASL-MD5 "2fdd32d9cdafcaeba80836f4cfc9b7db")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "62285b01dc017898fc16588b6522bbbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-package.fasl"
       :FASL-MD5 "116305f7865b48a6262b1bb9c4e70fd8")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-input.fasl"
       :FASL-MD5 "c83f811108114982660ff1fd34cb2126")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-items.fasl"
       :FASL-MD5 "319c31632d6beaf62a9e3ed9062359b6")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-minimal.fasl"
       :FASL-MD5 "555ed42f044d100b65de3324a018ec40")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-stack.fasl"
       :FASL-MD5 "f60016d033065bebd0dd7fb5ad3171e7")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan.fasl"
       :FASL-MD5 "73fec8ffe339bcbe0b1c42d1d842479d")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-space.fasl"
       :FASL-MD5 "733b3ca8327dd19c891cd166006c32d9")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-string-write.fasl"
       :FASL-MD5 "ac850b67e61971100cee8555b174189e")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-write.fasl"
       :FASL-MD5 "c19476b34b6d8bd484fa87c12440a3fc")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/package.fasl"
       :FASL-MD5 "33555c7659a69a00f62394414f851431")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/codec/utf8.fasl"
       :FASL-MD5 "5680f42e82b2f0a83b77c7c11d307955")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/csn/package.fasl"
       :FASL-MD5 "05206629656657cf6d2cbef961ad1be3")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/csn/registry.fasl"
       :FASL-MD5 "4e1086f42065c44b871d3561db6608b8")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/core.fasl"
       :FASL-MD5 "dbe331b5ebf04e6bf34a7b30ec2b1f6b")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/package.fasl"
       :FASL-MD5 "e1b811d401081018e945dbf796308493")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/read.fasl"
       :FASL-MD5 "11190d4b126f511fdd04ce1c285bdf16")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/reclaim.fasl"
       :FASL-MD5 "105af02bb8973aa1499c105b1e142a2d")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/retire.fasl"
       :FASL-MD5 "71932182172835b52149b573b1881b40")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/types.fasl"
       :FASL-MD5 "dbd542308374cb720b935ee03b6662ce")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/handoff.fasl"
       :FASL-MD5 "a8f4cc1f55dc7a50c9f6f2c6b627109e")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/package.fasl"
       :FASL-MD5 "ba56b24d3b5bf100ba22c7d57fd13a1e")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/queue.fasl"
       :FASL-MD5 "7aed3912b657d8cf3d8b5d95522655a3")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready-recycle.fasl"
       :FASL-MD5 "4c29e9bdb27a8dd0f5c8081ff842ea77")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready-types.fasl"
       :FASL-MD5 "6b5c61f97704b6b4ffffca7d448aad05")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready.fasl"
       :FASL-MD5 "ca47067198094ab249bf74df2738acfc")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-boundary.fasl"
       :FASL-MD5 "eb52c041e279d5e42c88938b66397143")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-claim.fasl"
       :FASL-MD5 "c647c896a1d3d8c775199a6af5808acc")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-run.fasl"
       :FASL-MD5 "c6881f8188888f5cf5a45880276d7576")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-types.fasl"
       :FASL-MD5 "982430e093c5ad84da740779f43b68dc")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/execution/writer.fasl"
       :FASL-MD5 "c0990c177930f681dd19f2516931e2b8")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/batch.fasl"
       :FASL-MD5 "b069c98c8c0be5bc84415ac231541dcc")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/binary.fasl"
       :FASL-MD5 "654cb4301488f4a8db5baccc128e8b1a")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/conditions.fasl"
       :FASL-MD5 "3ed94c5948cd1ae49fed281cc6725e8e")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/crc32c.fasl"
       :FASL-MD5 "1df599544fe71b3e05c105c55e104a82")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/package.fasl"
       :FASL-MD5 "aa622d8d85091fd7d735cf21250781b6")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/record.fasl"
       :FASL-MD5 "fb2ece22ee3f76e9de6ffe9aa8707af3")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db58ed1c3877f2d6ea58932d3bc75e56" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl"
       :FASL-MD5 "f0308276da0bbaa2d1fa9d1d23dfefdf")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/package.fasl"
       :FASL-MD5 "672837f879102cbbaaf12a96f899290c")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "74a694385f1aaf03ec87721545494119" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/read.fasl"
       :FASL-MD5 "fecb430e39bfc7f230a9185636e84e5c")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/types.fasl"
       :FASL-MD5 "e6c115cb6ccc33c80cf08ad4b5ae385e")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-build.fasl"
       :FASL-MD5 "8a5f446aefe1aa03f1f2e2d0e32a3511")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-directory.fasl"
       :FASL-MD5 "a3d90edf26040a6b38b8ac9068e87453")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-preflight.fasl"
       :FASL-MD5 "5fc678fed30ad7c108d635b8e1ca25e1")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-read.fasl"
       :FASL-MD5 "552edc6926fcad134bce9aecab6fbcab")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-scan.fasl"
       :FASL-MD5 "c65b2858d4189efc451cd5ecc38120d7")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-types.fasl"
       :FASL-MD5 "55a190b9367176c635662b3cc45c6b2c")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/build.fasl"
       :FASL-MD5 "328dda06ff46989de67a5ab36d6ed254")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/package.fasl"
       :FASL-MD5 "9f3fae74c3d55d32b28550d863a1a8eb")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/read.fasl"
       :FASL-MD5 "00b86b1810b694ce3585ea6d737ae129")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/rows.fasl"
       :FASL-MD5 "9938f78ae7f4034b3b47831d6d8b6cb4")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/scan.fasl"
       :FASL-MD5 "250a1ca87a8f759cc2c83ef70c352d3e")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/sort.fasl"
       :FASL-MD5 "f2217c681fe917c6570a6e08f8f80d27")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/types.fasl"
       :FASL-MD5 "bd48638acaba3c5c5ff05c012fb270f9")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/build.fasl"
       :FASL-MD5 "a410bf28b20c414e97ca35e08aa2c69d")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/lifecycle.fasl"
       :FASL-MD5 "bea1bb0a0bdb257a28dffc75b284235b")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/lookup.fasl"
       :FASL-MD5 "b31090d1fea48fc78748b91704ea7481")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/package.fasl"
       :FASL-MD5 "7bd5afa309dba76451d43a1888e5bd20")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/segment.fasl"
       :FASL-MD5 "8fa952f7eea0cd7af78c63d294232274")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/target.fasl"
       :FASL-MD5 "782a3d153b66b5382a138fbf9f406159")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/get/types.fasl"
       :FASL-MD5 "4c31c09f028bd27a293416e319968789")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/hash/arithmetic.fasl"
       :FASL-MD5 "e9ae89930440884122292e7db8d46489")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/hash/blocks.fasl"
       :FASL-MD5 "b7e4f54e1834f4a0cfa6a694a7588e97")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/hash/hash64.fasl"
       :FASL-MD5 "65e1f493cb483b38c0c405b2fd46946e")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/hash/package.fasl"
       :FASL-MD5 "3c4054879fefa59454d4065db2cff83a")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/core.fasl"
       :FASL-MD5 "af9f1aecb89c4a37e8cf509439d89c73")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/hash-digests.fasl"
       :FASL-MD5 "7b6b34de6c26e7447e0aaffd42829482")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/hash-seed.fasl"
       :FASL-MD5 "0367e935971f5c8c570e6b578483672f")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/package.fasl"
       :FASL-MD5 "a1d17082aef44668aca81e826f00ce82")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-arena.fasl"
       :FASL-MD5 "6e7e9551f7dccda6ca0981b0e167f998")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-build.fasl"
       :FASL-MD5 "1ec4bb994818306382c082799af6e203")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-core.fasl"
       :FASL-MD5 "f28cd70492b052c909e5433c22983e1a")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-directory.fasl"
       :FASL-MD5 "460aee2a9eb63649cfd5bfeb5899d1e7")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-package.fasl"
       :FASL-MD5 "cbf1a9bf191d38e16dadd81cfeb7fead")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-probe.fasl"
       :FASL-MD5 "89585c80c0d9e959cf85cd9049f83e12")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-read.fasl"
       :FASL-MD5 "7ef0135ee61702c614fe98d0a3104d37")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-relocate.fasl"
       :FASL-MD5 "56a85d48f9aa940cd8b40be8dcaf5481")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-types.fasl"
       :FASL-MD5 "195d0ac76f1f6f6af495743ad88657a0")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-write.fasl"
       :FASL-MD5 "cd12905a2fc93cb67c31701af358b28c")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/read.fasl"
       :FASL-MD5 "0328fc2e9c459c01e8de24f78b33c80d")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-budget.fasl"
       :FASL-MD5 "ad00d4ae5478ba6f591d9d4dab17d14b")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-copy.fasl"
       :FASL-MD5 "b67f6ea204b505009ab242f5f7dedd53")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-scan.fasl"
       :FASL-MD5 "820dae5d18fb89545b4b328f506dcc1c")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild.fasl"
       :FASL-MD5 "e58c3c55ea87ada6732bdf62ea6895ad")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/relocate.fasl"
       :FASL-MD5 "3015096dddbe9ac5686a4e4e5a3e0c05")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/types.fasl"
       :FASL-MD5 "479c61ea588b228e6988f60c225521cb")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/validation.fasl"
       :FASL-MD5 "10462934366ba803525675c42fd10b29")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/index/write.fasl"
       :FASL-MD5 "8e8509c31f0ed1a0828a33e819a0cf23")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/io/flush.fasl"
       :FASL-MD5 "9b7e1b48a9a7ec01a1f81117c311d335")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/io/lifecycle.fasl"
       :FASL-MD5 "12fe9859c8004f72fbb6061b452d95d8")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/io/native.fasl"
       :FASL-MD5 "afc070915d9080157f2843717dd62e59")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/io/package.fasl"
       :FASL-MD5 "f8e4d1231d6b8681d98ee1fcf27e25e9")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/io/transfer.fasl"
       :FASL-MD5 "d929b432d8fdd92ef8a28d06bf06e90c")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/io/types.fasl"
       :FASL-MD5 "873b9053ea54355f158fb86e2caf44ba")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/package.fasl"
       :FASL-MD5 "cd2971d34bc271842e12afc1b91dd5ad")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-core.fasl"
       :FASL-MD5 "a5b9fa45ff5a6a615d3b797e940f29e9")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-csn.fasl"
       :FASL-MD5 "03a24324a522d620ca566c6af18dfd09")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-lifecycle.fasl"
       :FASL-MD5 "61e3f86cc448fd319d5ef49c47907193")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-read.fasl"
       :FASL-MD5 "e1adb2d2bf6e6d43cd569cb4235e133d")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-register.fasl"
       :FASL-MD5 "10eedc1912ed36696a0d68e095e15cb6")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-types.fasl"
       :FASL-MD5 "b1ddcdf58249555550653bf3c2979a89")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/types.fasl"
       :FASL-MD5 "67404ab6930cae50cdc037faf3b00972")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/package.fasl"
       :FASL-MD5 "402075a493254eec53ea4e000dd77d6e")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/read/core.fasl"
       :FASL-MD5 "9aa891484bcb21f275dc07e4b1501ff3")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/read/package.fasl"
       :FASL-MD5 "657bdf4486662c76ce0e65a376b9d30d")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/read/task.fasl"
       :FASL-MD5 "0e12747b08fa3b1c04c3052f6e48e37e")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/read/types.fasl"
       :FASL-MD5 "b02cb84d492d7c09ce98e2800fed7d96")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-build.fasl"
       :FASL-MD5 "68ec9d39af0e4f2b3c81d1ba4a96f284")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-package.fasl"
       :FASL-MD5 "8bcb36a03f70b99d51afa91acffa7df5")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-query.fasl"
       :FASL-MD5 "47247787df5ecdde2677025ccd034091")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-radix.fasl"
       :FASL-MD5 "cfda53eb53c025c275c4ebbd7a02fec3")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-sort.fasl"
       :FASL-MD5 "357917aba778945fda4a83dc26162d92")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-types.fasl"
       :FASL-MD5 "d2cf664fb15ed1cfa72275ad5b9824ab")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-build.fasl"
       :FASL-MD5 "5f1c925ca69fbcea51a140ac325462ea")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-query.fasl"
       :FASL-MD5 "467035dc7243e7d172763bd17cbbfaa7")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-types.fasl"
       :FASL-MD5 "65321011a5f7d9c5399249a004551e8c")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-build.fasl"
       :FASL-MD5 "0d844794961edbb4e090e2dea2974e1b")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-decode.fasl"
       :FASL-MD5 "c8fea9dd42727049b2fe756f8e021d24")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-fold.fasl"
       :FASL-MD5 "71553830890ecdbae8d9dbc2af6313e0")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-package.fasl"
       :FASL-MD5 "4977808839b9ea1111d931dd97dda111")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-query.fasl"
       :FASL-MD5 "fee9d5438bc77e61dc2523d52175cba8")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-types.fasl"
       :FASL-MD5 "981a64f89cd48c21d72a510607db5498")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/package.fasl"
       :FASL-MD5 "59d88338e83401babeab73295840a9ec")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/scan.fasl"
       :FASL-MD5 "ca0a18e74257743dec60b76671cc11e6")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/events.fasl"
       :FASL-MD5 "a89ceb26cf6fa834c521e7edc73d34d9")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/io-events.fasl"
       :FASL-MD5 "ca09d22f2b26f9c2bc69386e9292c326")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/ownership.fasl"
       :FASL-MD5 "290cb2d9fdfd838a3f6993f752d598ff")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/package.fasl"
       :FASL-MD5 "93144fad7d67e324158ef17fa091d53d")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/publication.fasl"
       :FASL-MD5 "e814c8a9ecc9b3e54a9d27424d80305b")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/query.fasl"
       :FASL-MD5 "448185cdaf132714d3e626cd29f6784b")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/retirement.fasl"
       :FASL-MD5 "5e8650895fc5566d5da921054c475861")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-build.fasl"
       :FASL-MD5 "3d4620d535586ab1d953b7f90f47464e")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-select.fasl"
       :FASL-MD5 "e27d2399719c34662c4cf6e3639a9dde")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-types.fasl"
       :FASL-MD5 "969e1cbbd9639c011afd31bd890b2595")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/types.fasl"
       :FASL-MD5 "413f2a3a78a20d4b6e119357b31148a2")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-boundary.fasl"
       :FASL-MD5 "1786f75e2223480f9b46ff8b0d808280")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-package.fasl"
       :FASL-MD5 "6f5de6756e91ffb24adcc2c891b25b25")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-run.fasl"
       :FASL-MD5 "5e5bc6c0cf92dc5242686dd9d3af4f18")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-types.fasl"
       :FASL-MD5 "8400c6766edf595f33d1a8abe7a22a75")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/compaction-scan.fasl"
       :FASL-MD5 "dd668179ebb1c0e4f832e35a5e05fce3")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/control-payload.fasl"
       :FASL-MD5 "a20e37e6b2a5f2bf411715aad6518d22")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/formats.fasl"
       :FASL-MD5 "6f69ec582c28da22fd97f52b3a5635b0")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/log-header.fasl"
       :FASL-MD5 "088c617c981cc99d23c559dd3be30540")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/package.fasl"
       :FASL-MD5 "71d160edce0a207cf401bc335b495b2e")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/payload-record.fasl"
       :FASL-MD5 "1af42abb0da048c99a44c2fb65f26697")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/payload-write.fasl"
       :FASL-MD5 "628cbf8c05fe3854b9d64344c468a997")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/storage/segment-header.fasl"
       :FASL-MD5 "51537a2c0c77bd9422386bc83cf08a5c")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/wal/builder.fasl"
       :FASL-MD5 "79deff0e82902134125e067b8467a8b4")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/wal/csn.fasl"
       :FASL-MD5 "51444ba63fe16ea8c784c8b99feb4498")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/wal/executor.fasl"
       :FASL-MD5 "b5247f2ed9e98fda0877a4a994d2e0b7")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/wal/group.fasl"
       :FASL-MD5 "26aa893c3288da2d2624bfcf84daa7bf")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/wal/package.fasl"
       :FASL-MD5 "e0a5351a38027fb1a4dd73a7bd72cb78")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/src/wal/types.fasl"
       :FASL-MD5 "215800a3489efc67b60431c0529356d7"))
     :COMPILED-SUITE
     ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/tests/foundation/support.fasl"
       :FASL-MD5 "f5e7ddf620c9eab46fe1086e4a8bec10")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/support.fasl"
       :FASL-MD5 "9b7cf5637ac11350f98401b521bf320d")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/construction.fasl"
       :FASL-MD5 "f19770b94f431e4834b6ed82f0cb9bf2")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/read.fasl"
       :FASL-MD5 "fbbadd52f0a2012295b3ca45a77edea9")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/threads.fasl"
       :FASL-MD5 "161b709d7b16e288c2b5f21f2b77bc10"))
     :FAILED-TEST
     "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
     :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE "SIMPLE-ERROR"
     :DIAGNOSTIC "Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (ARCDOCDB.GET.DIRECTORY:CREA-DIRECTORY-GET-SERIE
                       ARCDOCDB.GET.DIRECTORY.TESTS::COPY
                       (ARCDOCDB.GET.DIRECTORY.TESTS:DIRECTORY-FIXTURE-MAPS
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVALID-ARGUMENT (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :DIRECTORY-SOURCE-OWNER)))"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . "6edf271e46b6c707e307c54f46fca708") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . "db58ed1c3877f2d6ea58932d3bc75e56") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   "missing-location-first-map" :FILE "src/get-directory/read.lisp" :DIRECTORY
   #A((143) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/")
   :EXPECTED-FAILURE :MISSING-PUBLISHED-SEGMENT-AUTHORIZED :SUBSTITUTION
   (:BEFORE
    "(when (= left right) (guasto-get context :directory-location-absent))"
    :AFTER "(when (= left right)
               (if (plusp (length maps))
                   (return-from cerca-mappa-directory-get
                     (the mappa-segmento-get (svref maps 0)))
                   (guasto-get context :directory-location-absent)))")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   ("TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP")
   :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . "692a695f7129e0cc693cffb2983be35b"))
    (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "62285b01dc017898fc16588b6522bbbf"))
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd12d0077a79f0c9c2f0a4dd01731f43"))
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
    (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
   :COMPILED-TARGET
   (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    "bd12d0077a79f0c9c2f0a4dd01731f43" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl"
    :FASL-MD5 "d388e78df967f057078fafd3e5f8f429")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
     "--script" "isolated-build.lisp")
    :STDOUT-LOG
    #A((153) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/stdout.log")
    :STDERR-LOG
    #A((153) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/stderr.log")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 2392301/500000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/"
     :SOURCE-MANIFEST
     ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
       "692a695f7129e0cc693cffb2983be35b")
      (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "62285b01dc017898fc16588b6522bbbf")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cde24b2bf5c5637d5501b95bed47df31")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd12d0077a79f0c9c2f0a4dd01731f43")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9")
      (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257"))
     :SUITE-FILES
     ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
      "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
      "tests/get-directory/threads.lisp")
     :REGISTERED-TESTS
     ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
      "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
      "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
      "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
      "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
      "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
      "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
      "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
      "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
      "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
      "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
      "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
      "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
      "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
      "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
      "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
      "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
      "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
      "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
      "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
      "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
      "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
      "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
      "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
      "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
      "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
     :SELECTED-TEST
     "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bd12d0077a79f0c9c2f0a4dd01731f43" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl"
      :FASL-MD5 "d388e78df967f057078fafd3e5f8f429")
     :COMPILED-PRODUCT
     ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/build.fasl"
       :FASL-MD5 "0deb1fa35ef22e224d8e5d0b8be06b2b")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/clock.fasl"
       :FASL-MD5 "a01aa6fb1fa41bd755b350ba3420af6f")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/core.fasl"
       :FASL-MD5 "1308c19d221ed7f25523140123b2ad22")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/package.fasl"
       :FASL-MD5 "62d3b0a44280ba3d2c843ad639a778f7")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/read.fasl"
       :FASL-MD5 "7ef4879e1382261502f94ec02e94293c")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/types.fasl"
       :FASL-MD5 "c5bf65350d01194ff5d5ba2257efdbc2")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/cache/write.fasl"
       :FASL-MD5 "8478e60e5ca5e4a0a913b2780b81e816")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-float-minimal.fasl"
       :FASL-MD5 "34be2fde8f4c4ff4f69d0dacf26d3856")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-header.fasl"
       :FASL-MD5 "8bfcd805d1bced566aa70d8ba5973634")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-minimal.fasl"
       :FASL-MD5 "1585bd5fc137c4f0f4368c72e848bc3a")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "62285b01dc017898fc16588b6522bbbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-package.fasl"
       :FASL-MD5 "ad8d7c83184b409becde0347d2deb13f")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-input.fasl"
       :FASL-MD5 "11bf0136b0b05b43e2ff69609725d5c2")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-items.fasl"
       :FASL-MD5 "c9fffe875445c78257974fe6bd91970a")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-minimal.fasl"
       :FASL-MD5 "3218b3fc88b2f91aa9e75c70fa4b78cd")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-stack.fasl"
       :FASL-MD5 "2383d83a4561104401ef31e8e52e0b74")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan.fasl"
       :FASL-MD5 "9bf882088d454ea9f13dcfcacb3dab3a")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-space.fasl"
       :FASL-MD5 "2afe2db8024d05d965e22bcc2b251480")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-string-write.fasl"
       :FASL-MD5 "3916199f765be575fb05f94f8d641a8c")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-write.fasl"
       :FASL-MD5 "af833660588204e589ba0793e84e72d0")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/package.fasl"
       :FASL-MD5 "e03cde68ce2199ad90de6f748b297dda")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/codec/utf8.fasl"
       :FASL-MD5 "2d98ce8215cf1a7716e739eaeb20d1e6")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/csn/package.fasl"
       :FASL-MD5 "1d7571db1622f4b838b8d7ce45fd4db8")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/csn/registry.fasl"
       :FASL-MD5 "f733e7076795926e5cd7eff90508cc1a")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/core.fasl"
       :FASL-MD5 "b8568b16c6f16ffa1ffd3e0aeee9178d")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/package.fasl"
       :FASL-MD5 "d33986b481290136caf2025939fbaaa9")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/read.fasl"
       :FASL-MD5 "84505e2a9e5916c484d094ff520fedba")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/reclaim.fasl"
       :FASL-MD5 "1c2ce13da6efeb898ab5d73af2cbbb2e")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/retire.fasl"
       :FASL-MD5 "17c84467447b4c9de5801257299c1bbe")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/types.fasl"
       :FASL-MD5 "fc1d3e7785e2accfd699947b7c555ff9")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/handoff.fasl"
       :FASL-MD5 "f77211f8340b0ad932a5c083441c3dc5")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/package.fasl"
       :FASL-MD5 "4f071fd619e2fc9c55d5d9fe19d6f394")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/queue.fasl"
       :FASL-MD5 "05f67b303fb1b95222c5fad213a698c0")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready-recycle.fasl"
       :FASL-MD5 "81cfb9518a80fe40e533b0d735aff8a2")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready-types.fasl"
       :FASL-MD5 "22ce37cf369a41452da19d4770607d75")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready.fasl"
       :FASL-MD5 "958f6f81619c35946a44427333cf3faa")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-boundary.fasl"
       :FASL-MD5 "b8e1b850ff73b0382138ff9e5e5b4736")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-claim.fasl"
       :FASL-MD5 "928c1660c5680d23ea3a525c26fe9e30")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-run.fasl"
       :FASL-MD5 "81cdcf098b2b9c337bbed88efa147138")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-types.fasl"
       :FASL-MD5 "39c5c236a0376c72fc2053a8446d7ad9")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/execution/writer.fasl"
       :FASL-MD5 "c8989d533c3cfc729c95fd16f17a648b")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/batch.fasl"
       :FASL-MD5 "1f97d7e43060572436ec33fe592358c4")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/binary.fasl"
       :FASL-MD5 "5565e9065bda8926f35b8ad5a3e13e22")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/conditions.fasl"
       :FASL-MD5 "59981e39ed8a2a535759e2e8871eacd5")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/crc32c.fasl"
       :FASL-MD5 "12f649bdf602bf8593c643df4a931f51")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/package.fasl"
       :FASL-MD5 "92b8e5285ad30f88bfdabc430afbcd17")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/record.fasl"
       :FASL-MD5 "4820f179bf9a19f9096c453b7b31a3a3")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cde24b2bf5c5637d5501b95bed47df31" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/build.fasl"
       :FASL-MD5 "c0ea274bf946e0570239c975ae0307fc")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/package.fasl"
       :FASL-MD5 "5bf4185cbf369269a2468fcaf35e51c4")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd12d0077a79f0c9c2f0a4dd01731f43" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl"
       :FASL-MD5 "d388e78df967f057078fafd3e5f8f429")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/types.fasl"
       :FASL-MD5 "38513102550029fff4e70684b043c1d9")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-build.fasl"
       :FASL-MD5 "08e8778aca6463e97c7e32c8d079c827")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-directory.fasl"
       :FASL-MD5 "84322601c89d79017d4f98f6ac2b8f0d")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-preflight.fasl"
       :FASL-MD5 "22a180c50620f025fa333af890f3e549")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-read.fasl"
       :FASL-MD5 "888b189a84dacf3885c1a3af457f20e5")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-scan.fasl"
       :FASL-MD5 "b4156ced850ccfd5312b14029a3ca340")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-types.fasl"
       :FASL-MD5 "f3d2e1d29598842c3ff27f416c4ceb3b")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/build.fasl"
       :FASL-MD5 "ed5300e664ccdc84cb6cc606a64c3fa8")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/package.fasl"
       :FASL-MD5 "b596ff314d8e6f109e47bc564db7da60")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/read.fasl"
       :FASL-MD5 "59c7561a99231f2bbedfce318fa42833")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/rows.fasl"
       :FASL-MD5 "438fb9cfc759285588ff678f1561a227")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/scan.fasl"
       :FASL-MD5 "8c110a020315a92501e3e0960aeca626")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/sort.fasl"
       :FASL-MD5 "9b202d7f4bff245088052c345011f996")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/types.fasl"
       :FASL-MD5 "9237cd1a6cdd70ed1bc56d3cf364960a")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/build.fasl"
       :FASL-MD5 "08780eb1875258f7a3cb2fa3eb965eba")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/lifecycle.fasl"
       :FASL-MD5 "9c6c8b03f1ee18ced58af2eb159a874a")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/lookup.fasl"
       :FASL-MD5 "8ad5199157b4fa5bf3cfa9ddd623427b")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/package.fasl"
       :FASL-MD5 "65fffdd835e087b770ebaa77725d20ee")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/segment.fasl"
       :FASL-MD5 "2d5fa8fd306f640b9b8eb902a3c02543")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/target.fasl"
       :FASL-MD5 "db58c8a225775389722547ba61c94c23")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/get/types.fasl"
       :FASL-MD5 "3e642ff24a29febf47b3079fa5960e90")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/hash/arithmetic.fasl"
       :FASL-MD5 "726b1a1fa3069e926a57153bcf74605e")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/hash/blocks.fasl"
       :FASL-MD5 "d33916a5d6f3faf0f18837fac8e849d0")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/hash/hash64.fasl"
       :FASL-MD5 "887c02f3228e2f7860951b38d65f605f")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/hash/package.fasl"
       :FASL-MD5 "d422aec5b520a1682dea65d643da07f6")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/core.fasl"
       :FASL-MD5 "af6197a105d9db7048da5f52f45f4c77")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/hash-digests.fasl"
       :FASL-MD5 "1c0e2535920c667e6d2e34ae37c1a386")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/hash-seed.fasl"
       :FASL-MD5 "42afe41bceea5f778934e48defad225d")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/package.fasl"
       :FASL-MD5 "b4ba56d7c032410a6ba63cd4fe1f859d")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-arena.fasl"
       :FASL-MD5 "0608ff4915e363fcd8adf405755e9a22")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-build.fasl"
       :FASL-MD5 "93cffdeff3d7e9ef3e3d2bd8141fde10")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-core.fasl"
       :FASL-MD5 "4a4534afa0ceb2defcd2d46dfe1e9e8e")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-directory.fasl"
       :FASL-MD5 "e6781e9a6fd89c52d73a8306d571ac97")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-package.fasl"
       :FASL-MD5 "94c7c45db752bb94bc7d33c5dcbbc4bd")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-probe.fasl"
       :FASL-MD5 "49eccf6447615ce62c2ffea3400e9e6b")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-read.fasl"
       :FASL-MD5 "7de4ffdecce7e48a4898eec1befd4097")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-relocate.fasl"
       :FASL-MD5 "64c7b41a887434e586765291bf6fb472")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-types.fasl"
       :FASL-MD5 "7b3aa62d2e45fb3320f041fbfabf6622")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-write.fasl"
       :FASL-MD5 "8d36a0ede70711e9b5a2e17c824ac557")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/read.fasl"
       :FASL-MD5 "d6a6832473f46b9bc499bfdfd6efd102")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-budget.fasl"
       :FASL-MD5 "0a882d07c33b349f302281b6bfc23099")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-copy.fasl"
       :FASL-MD5 "9263fbb8a971b3bf68eb9d02cdcc31d7")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-scan.fasl"
       :FASL-MD5 "ce67f1f1e6e49be925432fccd0cbd27d")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild.fasl"
       :FASL-MD5 "dbae1eb021526822828c644a0a63758f")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/relocate.fasl"
       :FASL-MD5 "6e41425adb621fb6384b7dc5532575ef")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/types.fasl"
       :FASL-MD5 "2577ea2665c5308844405b2d83ef5c97")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/validation.fasl"
       :FASL-MD5 "22d1e523224f74c4c7cf36579eaf6829")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/index/write.fasl"
       :FASL-MD5 "d0e29ab394973661e145f9e8bfadd8f5")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/io/flush.fasl"
       :FASL-MD5 "435f0688dda8099084ebe10e9179c848")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/io/lifecycle.fasl"
       :FASL-MD5 "b9a598586af8172af5ce652fac9b2821")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/io/native.fasl"
       :FASL-MD5 "994828895140841f1e90dd2d30604773")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/io/package.fasl"
       :FASL-MD5 "258730de7744d0e18d9dac588c3d4c8c")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/io/transfer.fasl"
       :FASL-MD5 "46ff77a14896780526841a5ca064f3b7")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/io/types.fasl"
       :FASL-MD5 "fc876df1861134948d817fee39c374f8")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/package.fasl"
       :FASL-MD5 "c4f8addb7ce207b67d5cc9209016ece0")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-core.fasl"
       :FASL-MD5 "aed7e4b7638e1d26088acc30a886ea8c")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-csn.fasl"
       :FASL-MD5 "c88c01a3bf82a07ec2aafd3688363a9d")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-lifecycle.fasl"
       :FASL-MD5 "19d1b5e8e242e406c67ed0c5ed453d4f")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-read.fasl"
       :FASL-MD5 "cb5f1195669d266fc393e65588fe2d88")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-register.fasl"
       :FASL-MD5 "14ea4df8f6883ae7322d261dfb9c4192")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-types.fasl"
       :FASL-MD5 "ce8deb93edb565301b8ebfecc15442a7")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/types.fasl"
       :FASL-MD5 "e4b80e56f694c8d6711509eac1616809")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/package.fasl"
       :FASL-MD5 "b92d351222e18fd85cff15cd4ae11ff2")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/read/core.fasl"
       :FASL-MD5 "7c8f84e7e14fb7af7e7ee5a8deb0296b")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/read/package.fasl"
       :FASL-MD5 "c11bd7eb3cd3994cb6dd0fa55d18fc42")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/read/task.fasl"
       :FASL-MD5 "c12e3fd59f955f491938168df013bd65")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/read/types.fasl"
       :FASL-MD5 "74799a5cf694f0464ae8c0d407f54098")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-build.fasl"
       :FASL-MD5 "f813a51eef622e333c54feaeffe8f558")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-package.fasl"
       :FASL-MD5 "f14d96dc7f6fb15cbb9764a77cb356db")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-query.fasl"
       :FASL-MD5 "ce864e102561e098c0b53edc13051d01")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-radix.fasl"
       :FASL-MD5 "bc77862dec5f3199ad5f2c7cc858539b")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-sort.fasl"
       :FASL-MD5 "7e047b08614a9ec630f4c0cb77e0953f")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-types.fasl"
       :FASL-MD5 "c2d1b847e7af10656708dbc84d817b9a")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-build.fasl"
       :FASL-MD5 "ce329fc4e64040d35e621b970c43cbf7")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-query.fasl"
       :FASL-MD5 "479d2952d03855105a5a953daf9309b3")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-types.fasl"
       :FASL-MD5 "9216ddd1bb0cdb3f1700b9dcc5cb8f03")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-build.fasl"
       :FASL-MD5 "1760557e8437957e4ab537856ce5271b")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-decode.fasl"
       :FASL-MD5 "0f1da84ff9acf1fc57e00c2fe2562f54")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-fold.fasl"
       :FASL-MD5 "076d2fd05d364023ea17aa97e5140051")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-package.fasl"
       :FASL-MD5 "f1c0e1b2ab99b9e1505c1e720228534d")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-query.fasl"
       :FASL-MD5 "a065a1e6b284a45b1e80f62a627cd180")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-types.fasl"
       :FASL-MD5 "e78c33e1fff70abe6c5d7c5b31970f2d")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/package.fasl"
       :FASL-MD5 "bd110a9045def8c27c9c7e9d4e729812")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/scan.fasl"
       :FASL-MD5 "ad7e383c7f530a73dbb46b71342a9195")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/events.fasl"
       :FASL-MD5 "f6dab4b919fdec4c39f5ac04d98f0d70")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/io-events.fasl"
       :FASL-MD5 "8eb3958b2832461f0a6856e806b2c622")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/ownership.fasl"
       :FASL-MD5 "d032be16253a322556aef403a6156981")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/package.fasl"
       :FASL-MD5 "9b279be15ff3b7726162d6a5ba20999b")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/publication.fasl"
       :FASL-MD5 "fdc4e2654e27b7f91089870a76bba4fd")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/query.fasl"
       :FASL-MD5 "b3357cdf0f1ed64a206d840c7cdd4ea9")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/retirement.fasl"
       :FASL-MD5 "b358d0ca44bee19a4054514d2fc9289c")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-build.fasl"
       :FASL-MD5 "92f1702af2dfb283da77693c90faa664")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-select.fasl"
       :FASL-MD5 "79378bb917a42a7694139262945f8fec")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-types.fasl"
       :FASL-MD5 "60dc98131c200df12b94d176aa667880")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/types.fasl"
       :FASL-MD5 "29a0b9321000c46aa1f1f55031a6cac6")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-boundary.fasl"
       :FASL-MD5 "baaf18b68696eeeeab2cd73f198a30a8")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-package.fasl"
       :FASL-MD5 "10e3b5ac496a82513fcc90b2437fd1c2")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-run.fasl"
       :FASL-MD5 "1b694a6bc8af4da2b3364ee228bd31a4")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-types.fasl"
       :FASL-MD5 "25a2f17627f7f520bbb9f25967576a1f")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/compaction-scan.fasl"
       :FASL-MD5 "79ca71e0fae3b01b25f58751b0362b8c")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/control-payload.fasl"
       :FASL-MD5 "df97463e8c88c7e1f9a1e190a70e27a4")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/formats.fasl"
       :FASL-MD5 "d21c6876743716217363ab58d99f5bec")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/log-header.fasl"
       :FASL-MD5 "fd4c542f24d8f29ab0cfb1f18f524153")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/package.fasl"
       :FASL-MD5 "65023eb760408329de588e04685f5ab4")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/payload-record.fasl"
       :FASL-MD5 "41ecb4ddd0e6f6056fab4ad410110c94")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/payload-write.fasl"
       :FASL-MD5 "0856987756240859daa11588c4fbf362")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/storage/segment-header.fasl"
       :FASL-MD5 "7692e1dd06be74a0d595d0adff689441")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/wal/builder.fasl"
       :FASL-MD5 "a87cff68123dd353afeec5f50bb145ee")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/wal/csn.fasl"
       :FASL-MD5 "9e66273e3828acba41dbcb051ac52688")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/wal/executor.fasl"
       :FASL-MD5 "ff2b687feed561d2e758601275198923")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/wal/group.fasl"
       :FASL-MD5 "a78d2b6e12896988a500e71db2875f82")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/wal/package.fasl"
       :FASL-MD5 "45582ed8da5abff26ed0daece4ec62f1")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/src/wal/types.fasl"
       :FASL-MD5 "08cb207fef312ef700c7005eb278dee5"))
     :COMPILED-SUITE
     ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/tests/foundation/support.fasl"
       :FASL-MD5 "bc4b74d2612be7c36315973745429874")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/support.fasl"
       :FASL-MD5 "eb89f35c1054c99a6b6c755b7ebdaca1")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/construction.fasl"
       :FASL-MD5 "240970902a90d6085e41ffdb4ae8e70d")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/read.fasl"
       :FASL-MD5 "ca65a9663b9961fcccbd1b62d5d57fcb")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/threads.fasl"
       :FASL-MD5 "2cc11422b5762f829a5e48f6a9784f0e"))
     :FAILED-TEST
     "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
     :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE "SIMPLE-ERROR"
     :DIAGNOSTIC "Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (PROGN
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-CALL-OPERATION
                        ARCDOCDB.GET.DIRECTORY.TESTS::OPERATION
                        ARCDOCDB.GET.DIRECTORY.TESTS::CONTEXT DIRECTORY)
                       (SETF ARCDOCDB.GET.DIRECTORY.TESTS::AUTHORIZED T))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVARIANT-VIOLATION (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :DIRECTORY-LOCATION-ABSENT)))"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . "f60caa0347db67d0c2a286997a5f7f54") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . "bd12d0077a79f0c9c2f0a4dd01731f43") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   "alias-input-maps" :FILE "src/get-directory/build.lisp" :DIRECTORY
   #A((133) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/")
   :EXPECTED-FAILURE :CALLER-ARRAY-CHANGES-DIRECTORY :SUBSTITUTION
   (:BEFORE "(owned (copy-seq maps))" :AFTER "(owned maps)") :STATUS :OK
   :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   ("TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED") :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . "692a695f7129e0cc693cffb2983be35b"))
    (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "62285b01dc017898fc16588b6522bbbf"))
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd0d166bfeee41dc15f53c57586a3d0d"))
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119"))
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
    (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
   :COMPILED-TARGET
   (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    "bd0d166bfeee41dc15f53c57586a3d0d" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/build.fasl"
    :FASL-MD5 "775ac262c9271c19f3a147708c02564d")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
     "--script" "isolated-build.lisp")
    :STDOUT-LOG
    #A((143) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/stdout.log")
    :STDERR-LOG
    #A((143) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/stderr.log")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 4610857/1000000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/"
     :SOURCE-MANIFEST
     ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
       "692a695f7129e0cc693cffb2983be35b")
      (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "62285b01dc017898fc16588b6522bbbf")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd0d166bfeee41dc15f53c57586a3d0d")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "74a694385f1aaf03ec87721545494119")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9")
      (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257"))
     :SUITE-FILES
     ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
      "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
      "tests/get-directory/threads.lisp")
     :REGISTERED-TESTS
     ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
      "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
      "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
      "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
      "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
      "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
      "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
      "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
      "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
      "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
      "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
      "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
      "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
      "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
      "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
      "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
      "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
      "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
      "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
      "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
      "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
      "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
      "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
      "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
      "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
      "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
     :SELECTED-TEST "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bd0d166bfeee41dc15f53c57586a3d0d" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/build.fasl"
      :FASL-MD5 "775ac262c9271c19f3a147708c02564d")
     :COMPILED-PRODUCT
     ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/build.fasl"
       :FASL-MD5 "98ca2b463946ef7634d47dd9fc47441a")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/clock.fasl"
       :FASL-MD5 "702914c0a974e3f8633a23227617134b")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/core.fasl"
       :FASL-MD5 "a128ed791797fe903df051c022a8150f")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/package.fasl"
       :FASL-MD5 "c5afec8b45ef141f8ffad2409b9b6a27")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/read.fasl"
       :FASL-MD5 "4d418ac5ff4db7941875d7790a1676a5")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/types.fasl"
       :FASL-MD5 "762c454aaf8fa723090b5618b2902849")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/cache/write.fasl"
       :FASL-MD5 "93bb0e08c2b00062b908daa817bc9533")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-float-minimal.fasl"
       :FASL-MD5 "7450b5fb5ac6ac5f67fbf6aa7a14bf7d")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-header.fasl"
       :FASL-MD5 "222947814a54530fef87fc9cf988c85d")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-minimal.fasl"
       :FASL-MD5 "85734a8937e76a02ffb2fb451915f301")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "62285b01dc017898fc16588b6522bbbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-package.fasl"
       :FASL-MD5 "6f97781f0443b8d3361e1be180afa545")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-input.fasl"
       :FASL-MD5 "b2be7ce51cc7f852ef7e991865e06505")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-items.fasl"
       :FASL-MD5 "c7c6eb5f62b8862cca4ff7d04df4bc5a")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-minimal.fasl"
       :FASL-MD5 "74c55d1ccf9e3cf75f353891ac524c94")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-stack.fasl"
       :FASL-MD5 "1cb1b94b55775761c912797ad72b9c25")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan.fasl"
       :FASL-MD5 "ea6b9ec34cd0a47f792217413b2ccaaa")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-space.fasl"
       :FASL-MD5 "ca616d3ebd68aff2b21c74ce9367d50b")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-string-write.fasl"
       :FASL-MD5 "b2cac757a0b17a823c363754fe97835f")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-write.fasl"
       :FASL-MD5 "5d68cfb51324f27adedb6d93b19c7c6e")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/package.fasl"
       :FASL-MD5 "56fd531bd84e5e47135adf74cbac826f")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/codec/utf8.fasl"
       :FASL-MD5 "6f42014aa526e2be330343ae8721d484")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/csn/package.fasl"
       :FASL-MD5 "becea9e37821c1256a3198f22ca806d9")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/csn/registry.fasl"
       :FASL-MD5 "e392075e05567c053d6ef808fa5b8207")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/epochs/core.fasl"
       :FASL-MD5 "16e8dcabc272352fb26c6b61f6e80197")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/epochs/package.fasl"
       :FASL-MD5 "b8e388c9a4efcdae3b1de76ad44f1127")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/epochs/read.fasl"
       :FASL-MD5 "c92360972b6090085d09712d9cbaa5f3")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/epochs/reclaim.fasl"
       :FASL-MD5 "893b06159db39c4b2fbabcf06f97e12c")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/epochs/retire.fasl"
       :FASL-MD5 "bd871cf16e0270ee6586e5326acb82fd")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/epochs/types.fasl"
       :FASL-MD5 "524a4539014e75fd439fa343878810d1")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/handoff.fasl"
       :FASL-MD5 "0ca6df5d26ad815136b7e350fe21f2dc")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/package.fasl"
       :FASL-MD5 "aaf6f903fcad7894fd2b494152fde471")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/queue.fasl"
       :FASL-MD5 "697b93c56aa5c450fa2091cf4eccfe5b")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/ready-recycle.fasl"
       :FASL-MD5 "e64c0b741450b116148d1d0091e273bd")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/ready-types.fasl"
       :FASL-MD5 "fcd987e8c5882f299c1f9bcfaeaf9e5f")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/ready.fasl"
       :FASL-MD5 "2aa799222f985ea85ce8d19e06ddb8a1")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-boundary.fasl"
       :FASL-MD5 "5b1f857ed44415443ff4dfa51a6414ca")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-claim.fasl"
       :FASL-MD5 "dfcd6ea685faa5ba4fa8da39ea9b9e81")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-run.fasl"
       :FASL-MD5 "13b23a28fb6c30005072e09a4551eed5")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-types.fasl"
       :FASL-MD5 "813dddbaeee0f82e21203d3cd3361573")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/execution/writer.fasl"
       :FASL-MD5 "e982473e4822a22e577fd8b2efd36080")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/foundation/batch.fasl"
       :FASL-MD5 "39621b611cc04be7bb9391576cfb1d50")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/foundation/binary.fasl"
       :FASL-MD5 "5bf02ba1a9f2cda71209f7beccc27174")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/foundation/conditions.fasl"
       :FASL-MD5 "b9fd52851c82468317d9953f8e0cfebc")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/foundation/crc32c.fasl"
       :FASL-MD5 "db2da46f29cfe00d8d8058699f9958d4")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/foundation/package.fasl"
       :FASL-MD5 "c868156cf2c95498d646aa3f6b4d085c")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/foundation/record.fasl"
       :FASL-MD5 "2dd66672a00556a40cdc9fe9c6657015")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd0d166bfeee41dc15f53c57586a3d0d" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/build.fasl"
       :FASL-MD5 "775ac262c9271c19f3a147708c02564d")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/package.fasl"
       :FASL-MD5 "2ea63c738a0afcf04abd657348796339")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "74a694385f1aaf03ec87721545494119" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/read.fasl"
       :FASL-MD5 "768899e774c98fa5ec9eec2b1a4ec5a5")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/types.fasl"
       :FASL-MD5 "fc9ea68243de53ee50a3f89c9e10e8cf")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-build.fasl"
       :FASL-MD5 "be992a06155318b2abdfefcefc80c829")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-directory.fasl"
       :FASL-MD5 "f2e75a3658a674288a7c41e39fd57d42")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-preflight.fasl"
       :FASL-MD5 "146d89c5a468d203cd2d1065586cfb0c")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-read.fasl"
       :FASL-MD5 "cc151465dfb75e72601057bb1f703613")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-scan.fasl"
       :FASL-MD5 "f9c7b802e6eeca3b7aa80070383bd537")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-types.fasl"
       :FASL-MD5 "088c4d913a99c9313aeeb6d29dc9a1ed")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/build.fasl"
       :FASL-MD5 "62205476464cbcf91fac3f31ec56a284")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/package.fasl"
       :FASL-MD5 "9d80a3354d1e0f9b5c02fe146c74d612")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/read.fasl"
       :FASL-MD5 "dac2f4d3eaa13887aa32dd4bad600791")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/rows.fasl"
       :FASL-MD5 "924238f561c1fd368a8463a71fb28e45")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/scan.fasl"
       :FASL-MD5 "fe8f02ce0c24debb23fa4e5119ebb19f")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/sort.fasl"
       :FASL-MD5 "2e7ce3a216b40bb31f5dbd74ad542cb9")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/types.fasl"
       :FASL-MD5 "73e635b10567d2f7e8d6acaa7dcff518")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/build.fasl"
       :FASL-MD5 "39b7418ad5e99c06f281389b04b91e08")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/lifecycle.fasl"
       :FASL-MD5 "d02f9dd9366588d3de8f93a28c3c2eab")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/lookup.fasl"
       :FASL-MD5 "eed8e483a9c01dea015ca35a09074a7a")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/package.fasl"
       :FASL-MD5 "00a5c713ebea3173d7437a5ad89d7efa")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/segment.fasl"
       :FASL-MD5 "4c7e67270a02bf45d9463a14a682980b")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/target.fasl"
       :FASL-MD5 "466b05027c8ff4f775f5dfe9a85e4640")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/get/types.fasl"
       :FASL-MD5 "2bf26a2f7e4cbd0b41fa3463fb38c4e0")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/hash/arithmetic.fasl"
       :FASL-MD5 "68692b103ec531382517319d6f21a07f")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/hash/blocks.fasl"
       :FASL-MD5 "d8a5c5749a99710b09660ed3be4b86a3")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/hash/hash64.fasl"
       :FASL-MD5 "6adf5c76d8acc26cd7e8e6a45fe31865")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/hash/package.fasl"
       :FASL-MD5 "7990dfda3055006598f6f1f95695e153")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/core.fasl"
       :FASL-MD5 "fd152cef84bd2ae9541cb4486ebf6c61")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/hash-digests.fasl"
       :FASL-MD5 "61c789bd66843600f7b464b371792e6d")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/hash-seed.fasl"
       :FASL-MD5 "bb73bcf196fe0c5dc2b7fb6fab1873a7")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/package.fasl"
       :FASL-MD5 "f77afc1abdf843bc470573c8d1d0e2b9")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-arena.fasl"
       :FASL-MD5 "8a5765a9be7e9a642a15b0cbd92fe882")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-build.fasl"
       :FASL-MD5 "c399428af1cd3a3207af09dc171b6b8f")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-core.fasl"
       :FASL-MD5 "bb5b909b36f288fd827ae94577818c9d")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-directory.fasl"
       :FASL-MD5 "3ce0dda5dc42c20e3d6448992e797802")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-package.fasl"
       :FASL-MD5 "ebf48a5351b7b509bb7b890490a9b8f0")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-probe.fasl"
       :FASL-MD5 "4420edcd0abe908445cf5325005a6e7e")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-read.fasl"
       :FASL-MD5 "628b9e1407d70f99f4a85d4c7c7d9990")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-relocate.fasl"
       :FASL-MD5 "20fe0f5ba7ad1eb9f4811a283718b3d2")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-types.fasl"
       :FASL-MD5 "3ccac881002c19ccd35cd92daa615c69")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-write.fasl"
       :FASL-MD5 "bd2d3a015ef7703b2a831041764f316b")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/read.fasl"
       :FASL-MD5 "68e20911eb02f6b903184a68ea9d97dd")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild-budget.fasl"
       :FASL-MD5 "43f665b7709de27281c7000605522bdd")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild-copy.fasl"
       :FASL-MD5 "fca9b123c54d6f2e0e72aaf3c31a124d")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild-scan.fasl"
       :FASL-MD5 "80a86bca06678ae36d4f25985d1472a9")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild.fasl"
       :FASL-MD5 "4bb5b0ffc6f1b71cd4dbc80949807e20")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/relocate.fasl"
       :FASL-MD5 "38c94fc4b039a805b24b8d262df4831c")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/types.fasl"
       :FASL-MD5 "0201c5559dbc26f489ede086e9c52e5c")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/validation.fasl"
       :FASL-MD5 "a4f6c0c3c79d6017de29a875d5063e37")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/index/write.fasl"
       :FASL-MD5 "fa2f7f755c6cdfeaa5cf3bfd4a11306a")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/io/flush.fasl"
       :FASL-MD5 "a0a1bbc22eb29c448cb926513901fc50")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/io/lifecycle.fasl"
       :FASL-MD5 "190980e4cff4e8c594f79e7b910dbd40")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/io/native.fasl"
       :FASL-MD5 "56a2b89948a4b228f44ae5a9f7483dea")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/io/package.fasl"
       :FASL-MD5 "ce9280eea66e53c197f9821d1b2a0054")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/io/transfer.fasl"
       :FASL-MD5 "4c1dfb773ea97f9602360928fd1cfd11")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/io/types.fasl"
       :FASL-MD5 "2992a7b6f937bab784ad022044d77e5f")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/package.fasl"
       :FASL-MD5 "7dd441098fc4dfdf18f2d4d152d5c13f")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-core.fasl"
       :FASL-MD5 "1a0977f076863cc33596e104a52b98b7")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-csn.fasl"
       :FASL-MD5 "9ef8c31e1dd54b1e0b0d47fde6d702b4")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-lifecycle.fasl"
       :FASL-MD5 "f8093dbbe20eeb797a8e6c99df89c423")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-read.fasl"
       :FASL-MD5 "ab227a88057bcfe392d0c2adbcbd927b")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-register.fasl"
       :FASL-MD5 "75e220d1aee2cbb64ea33792b088cd56")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-types.fasl"
       :FASL-MD5 "b27e2d393eb482275bd20e157cfe3a78")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/types.fasl"
       :FASL-MD5 "5580a6bcc1caa150a2bbe1c43b50a667")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/package.fasl"
       :FASL-MD5 "56b5bd9c37ffebed4c95c07c15b84d42")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/read/core.fasl"
       :FASL-MD5 "c66e998d3bae90f624237ee34f6913e1")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/read/package.fasl"
       :FASL-MD5 "6e52645c5cb2407842bfdb6241ed0ee1")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/read/task.fasl"
       :FASL-MD5 "8474e41405bbceaf3c565733473b96e4")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/read/types.fasl"
       :FASL-MD5 "18ca600d53f73ae89c9ca482ae4aabd0")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-build.fasl"
       :FASL-MD5 "f64ac26c8def467c56cbb8c3f4223e3b")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-package.fasl"
       :FASL-MD5 "e50c95afc607f2ac49700899fdcc2c04")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-query.fasl"
       :FASL-MD5 "fbb03f87f8a22f0f8c0b64aeace7037f")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-radix.fasl"
       :FASL-MD5 "0eb27cf5f2193f5f0188f73318c679fd")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-sort.fasl"
       :FASL-MD5 "042faac63912d41750ef23d732b8ee25")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-types.fasl"
       :FASL-MD5 "413534450f9fc7f81b8c0d064acdc79d")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/inventory-build.fasl"
       :FASL-MD5 "c07605568409c2a116cfefc9814004d0")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/inventory-query.fasl"
       :FASL-MD5 "722c863a09c2da6637a8589e49ecd47d")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/inventory-types.fasl"
       :FASL-MD5 "c0c10cb5587ae4ca6982006550110dab")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-build.fasl"
       :FASL-MD5 "f065d518c408fd35ce466d6da03d0681")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-decode.fasl"
       :FASL-MD5 "3c6f5cdeeab5c3570bcb4aea53bca06a")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-fold.fasl"
       :FASL-MD5 "940187e91638d4ae9a861617e7f18910")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-package.fasl"
       :FASL-MD5 "3838f7d8dbd831a9d540ff0f2e160ada")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-query.fasl"
       :FASL-MD5 "a86bf546656dd55a92675f401cbc16fb")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-types.fasl"
       :FASL-MD5 "b22b7b7dc6ff4303c844f5f8e3d5ebd8")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/package.fasl"
       :FASL-MD5 "7d2c4238189248d1032f76f996ca6734")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/recovery/scan.fasl"
       :FASL-MD5 "ee999206b7b63f50381a3b71aaee65e9")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/events.fasl"
       :FASL-MD5 "153960bd0e33cc586767f80e216a2443")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/io-events.fasl"
       :FASL-MD5 "3b34427fd635a99a7f173419d6ac5be3")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/ownership.fasl"
       :FASL-MD5 "e7d9469875d782a70e37b809eb9cc5c4")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/package.fasl"
       :FASL-MD5 "cf6f87f83636009e45cd231863c913e7")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/publication.fasl"
       :FASL-MD5 "2981b235043c2d360a803a4c62b87a5e")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/query.fasl"
       :FASL-MD5 "57a3f096f2af17df9f62cb3c6b5a139e")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/retirement.fasl"
       :FASL-MD5 "32bfee6ef018455c1a749a3f40144093")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/routing-build.fasl"
       :FASL-MD5 "a74cc649c99a964cbf933adb6d698265")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/routing-select.fasl"
       :FASL-MD5 "ee684b49f22544af34972074348a6e5a")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/routing-types.fasl"
       :FASL-MD5 "5a426f5c2edbd243f976994d840b2e40")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/types.fasl"
       :FASL-MD5 "e148e81a762838c6db02f7da73880fbb")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-boundary.fasl"
       :FASL-MD5 "d14c8f6c6c72012f93d4aa2289093f99")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-package.fasl"
       :FASL-MD5 "0f95111d4ca529b1d3f375525782268b")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-run.fasl"
       :FASL-MD5 "f4efbaa32375e61dc2279284313ef3cf")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-types.fasl"
       :FASL-MD5 "ca210939332b8aee6a13ab92c39c5686")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/compaction-scan.fasl"
       :FASL-MD5 "fdd501b00b7a18082b8c9fb81b7cd889")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/control-payload.fasl"
       :FASL-MD5 "365c45a1ee1e40cff75dde5f36e4de94")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/formats.fasl"
       :FASL-MD5 "ce4feb13c250f8c7a72893fc05afb6ca")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/log-header.fasl"
       :FASL-MD5 "746412ddec759dcf80bd6081b7d0b80c")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/package.fasl"
       :FASL-MD5 "4e9c79f05ae4d27f8e94ee0ecb064e01")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/payload-record.fasl"
       :FASL-MD5 "1b3321a19af1e109ce1dbad33857c7a0")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/payload-write.fasl"
       :FASL-MD5 "44413401c227d1ce4f8bbe89cada407d")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/storage/segment-header.fasl"
       :FASL-MD5 "99e7c47ca74a6e8cb379628ee8f59368")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/wal/builder.fasl"
       :FASL-MD5 "36b61d3f02169ea725734d7ee84876b5")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/wal/csn.fasl"
       :FASL-MD5 "c2d7fce47cf29c50fa0980161bddce86")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/wal/executor.fasl"
       :FASL-MD5 "d87a8889d7d93df12075a84b6a1187bf")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/wal/group.fasl"
       :FASL-MD5 "6b06f4fcae26188d355ecfcbc32e9777")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/wal/package.fasl"
       :FASL-MD5 "f68f78e5af7ebfa20c60e9a30f91b38f")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/src/wal/types.fasl"
       :FASL-MD5 "e61aebce9b40ea00bf47f6d6ce0ae368"))
     :COMPILED-SUITE
     ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/tests/foundation/support.fasl"
       :FASL-MD5 "b10aeba8b8ec7c29dc75cdcaa627253b")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/support.fasl"
       :FASL-MD5 "1ee1c14d13010204faf478e83a0fe824")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/construction.fasl"
       :FASL-MD5 "926bd0f92f6a90bcd68f18692c587d7c")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/read.fasl"
       :FASL-MD5 "b1a0342175ead12af06368805643c07a")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/threads.fasl"
       :FASL-MD5 "129b247069516796da072974699f71d7"))
     :FAILED-TEST "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED" :PASSED-TESTS
     NIL :FAILURE-KIND :PRODUCT-CONDITION :CONDITION-TYPE "INVARIANT-VIOLATION"
     :DIAGNOSTIC "ArcDocDB: DIRECTORY-SHAPE"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . "fdbdbe9c375b32143df6d8ed6e191b80") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . "bd0d166bfeee41dc15f53c57586a3d0d") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   "truncate-directory-id" :FILE "src/get-directory/read.lisp" :DIRECTORY
   #A((138) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/")
   :EXPECTED-FAILURE :MAX-U32-LOCATION-REJECTED :SUBSTITUTION
   (:BEFORE "(ldb (byte 32 32) location)" :AFTER "(ldb (byte 31 32) location)")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   ("TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID")
   :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . "692a695f7129e0cc693cffb2983be35b"))
    (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "62285b01dc017898fc16588b6522bbbf"))
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "65ce18f4ca8502f65bf6ee411e9f5fe9"))
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
    (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
   :COMPILED-TARGET
   (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    "65ce18f4ca8502f65bf6ee411e9f5fe9" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/read.fasl"
    :FASL-MD5 "38f618198dc1382b90692e3d6f857ae5")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
     "--script" "isolated-build.lisp")
    :STDOUT-LOG
    #A((148) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/stdout.log")
    :STDERR-LOG
    #A((148) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/stderr.log")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 467697/100000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/"
     :SOURCE-MANIFEST
     ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
       "692a695f7129e0cc693cffb2983be35b")
      (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "62285b01dc017898fc16588b6522bbbf")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cde24b2bf5c5637d5501b95bed47df31")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65ce18f4ca8502f65bf6ee411e9f5fe9")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9")
      (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257"))
     :SUITE-FILES
     ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
      "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
      "tests/get-directory/threads.lisp")
     :REGISTERED-TESTS
     ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
      "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
      "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
      "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
      "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
      "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
      "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
      "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
      "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
      "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
      "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
      "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
      "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
      "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
      "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
      "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
      "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
      "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
      "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
      "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
      "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
      "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
      "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
      "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
      "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
      "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
     :SELECTED-TEST
     "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "65ce18f4ca8502f65bf6ee411e9f5fe9" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/read.fasl"
      :FASL-MD5 "38f618198dc1382b90692e3d6f857ae5")
     :COMPILED-PRODUCT
     ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/build.fasl"
       :FASL-MD5 "b05bbf721e9d9be57cac12e7ee925931")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/clock.fasl"
       :FASL-MD5 "4df6ace6bdb5f5041c87e25f1d4cfd47")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/core.fasl"
       :FASL-MD5 "aed6bc27c670643e4739558a54a06b70")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/package.fasl"
       :FASL-MD5 "2323716d534af62fc43f847b94ef92f7")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/read.fasl"
       :FASL-MD5 "662a5016cb9413c342785889c47f8868")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/types.fasl"
       :FASL-MD5 "af84c827afea18aa92cf60cefad6aa1b")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/cache/write.fasl"
       :FASL-MD5 "8f1add68e061388d9d355f263e28f968")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-float-minimal.fasl"
       :FASL-MD5 "9f3f3f5f884fbf282477f144ec3fb1fa")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-header.fasl"
       :FASL-MD5 "5b29826950281b15edcee79bc9fff4f8")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-minimal.fasl"
       :FASL-MD5 "0c11dcdc935a0dcb13dd3f814a3098ce")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "62285b01dc017898fc16588b6522bbbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-package.fasl"
       :FASL-MD5 "ebb6a24dc276d2344199a435fb1633bc")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-input.fasl"
       :FASL-MD5 "08b465d088831277bc98ab95ce914bbe")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-items.fasl"
       :FASL-MD5 "4b7edeb7868eaddddbe31ed6d9af12e8")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-minimal.fasl"
       :FASL-MD5 "7820f3bf0743b41dd86f47e92821272a")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-stack.fasl"
       :FASL-MD5 "82e122cc047767abb022e79162ab5f87")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan.fasl"
       :FASL-MD5 "cb4ff521cd06dbda5124b0bfd17c4a77")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-space.fasl"
       :FASL-MD5 "67818d480ae64a153e2080600dc6c340")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-string-write.fasl"
       :FASL-MD5 "e56ddfc8814d9436b1bcc2be64e8ae54")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-write.fasl"
       :FASL-MD5 "8cde4fedec880bf6e060aad91d1bb3a2")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/package.fasl"
       :FASL-MD5 "e0be1a89927442f6341fa5a88fba61b9")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/codec/utf8.fasl"
       :FASL-MD5 "1ebd7a2277bc78785f19c5097483a98d")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/csn/package.fasl"
       :FASL-MD5 "9326ae39bc3c077fa52e3ea17cb9901f")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/csn/registry.fasl"
       :FASL-MD5 "42cbc0b6f7fd947da7869b987b2cc805")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/core.fasl"
       :FASL-MD5 "4734fd0bd91ea8a9c65665a591ad99eb")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/package.fasl"
       :FASL-MD5 "6188128fee03eea6e1c6091fe489ebf9")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/read.fasl"
       :FASL-MD5 "53e6b595cf35a4f778b8cd006212b103")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/reclaim.fasl"
       :FASL-MD5 "ba64f12b6bb139418fe1742b0eb8d6b9")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/retire.fasl"
       :FASL-MD5 "501caa2b41b6d0aea71b9056cc01c89e")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/types.fasl"
       :FASL-MD5 "75a757e9ed2294f50ff1d26e1bb1063a")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/handoff.fasl"
       :FASL-MD5 "2b36a3a0898e8fa404b50a8c5b6c6014")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/package.fasl"
       :FASL-MD5 "cdf9b72917e99a93ac2fdb2b953196e4")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/queue.fasl"
       :FASL-MD5 "7add88e43da71bb51e4fe40aa2197d1d")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/ready-recycle.fasl"
       :FASL-MD5 "ccc64dafcbd902537f124c469cba1918")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/ready-types.fasl"
       :FASL-MD5 "4bb6123e84978e564a7dc2b22c1ecb11")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/ready.fasl"
       :FASL-MD5 "c9c79a2a96ab45b46779f164f1cf3ec2")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-boundary.fasl"
       :FASL-MD5 "3cb1c991687701b51d1082419e3a4410")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-claim.fasl"
       :FASL-MD5 "8160873e5fec11b91d9fe9ac88d0cfad")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-run.fasl"
       :FASL-MD5 "9f63c285fbc5ab866d32297a437ea9b1")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-types.fasl"
       :FASL-MD5 "0c5a4555e62c9d337b8823ccda861f83")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/execution/writer.fasl"
       :FASL-MD5 "cd6f865798712b74f51192abbccda3b6")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/batch.fasl"
       :FASL-MD5 "1e13ae8269623b8368df564c0bb0d1a5")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/binary.fasl"
       :FASL-MD5 "87686cc89b819e2795e112f83da07abd")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/conditions.fasl"
       :FASL-MD5 "3665d3b05650f3e8a87a49553fafac81")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/crc32c.fasl"
       :FASL-MD5 "a9a3fefa5b960661a73146c8087d4697")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/package.fasl"
       :FASL-MD5 "36f58eb12fec0890f9ebf4052088a8fa")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/record.fasl"
       :FASL-MD5 "33381d692a1b4d58a3970ecfe32af0aa")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cde24b2bf5c5637d5501b95bed47df31" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/build.fasl"
       :FASL-MD5 "40d564ed7d9a03b22b53abd96ff282ea")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/package.fasl"
       :FASL-MD5 "b1a219972d64d3ce051bbf6d8f5c5c11")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65ce18f4ca8502f65bf6ee411e9f5fe9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/read.fasl"
       :FASL-MD5 "38f618198dc1382b90692e3d6f857ae5")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/types.fasl"
       :FASL-MD5 "7655d93b94a5c56de28f65884c4d7f54")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-build.fasl"
       :FASL-MD5 "c3ceb6e3f22865e824d60fba6ed8971d")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-directory.fasl"
       :FASL-MD5 "64475d2d7db3dd11de2037570fdc0d07")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-preflight.fasl"
       :FASL-MD5 "898b9592678c0620db53bd31b9182a79")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-read.fasl"
       :FASL-MD5 "f93ff7f7a587a2c2cfe0bc3f12aa943b")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-scan.fasl"
       :FASL-MD5 "ad0133b2881baf762e83d700143f81e8")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-types.fasl"
       :FASL-MD5 "29b5a0c9d020995c4aaadf02934d2cfc")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/build.fasl"
       :FASL-MD5 "44db0ca30900313fdf264354bdb812be")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/package.fasl"
       :FASL-MD5 "cdcd0e91b77cba603b378318828289a8")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/read.fasl"
       :FASL-MD5 "fd0e3c6977f8d58a8394479e5d4ffe9b")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/rows.fasl"
       :FASL-MD5 "facc250608567076c96dd32937ec759b")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/scan.fasl"
       :FASL-MD5 "b50667f8ba242ae8b838ca562fafe5a1")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/sort.fasl"
       :FASL-MD5 "6d54092ee39e4ee69743f4e216908f57")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/types.fasl"
       :FASL-MD5 "040aacbd6f5cf9e560dcb0e5f2d443de")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/build.fasl"
       :FASL-MD5 "04f56443b9cd88e787cbb543039d0ec5")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/lifecycle.fasl"
       :FASL-MD5 "71eb569c1cecf6d6dd266945fb6f52a9")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/lookup.fasl"
       :FASL-MD5 "86924f16f5bd3c2dc1967764f2a923eb")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/package.fasl"
       :FASL-MD5 "523c637fe9f8d1f8e950494008b93b0c")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/segment.fasl"
       :FASL-MD5 "7250ced5b174796f30e5f0422a5994c2")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/target.fasl"
       :FASL-MD5 "241567f9558ac64a29b173fea370afb9")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/get/types.fasl"
       :FASL-MD5 "a246f40885b954035a34ce03af72f795")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/hash/arithmetic.fasl"
       :FASL-MD5 "acb0244366c7cc423d7467342723b3d7")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/hash/blocks.fasl"
       :FASL-MD5 "f7e822abbc983b9578c036d349a6b070")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/hash/hash64.fasl"
       :FASL-MD5 "ad7c108b723cecbaebf17b8d0838cf5a")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/hash/package.fasl"
       :FASL-MD5 "9b28cc8ddf6acc9e0fcd44060e83d5ab")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/core.fasl"
       :FASL-MD5 "907ad30c0035428e3097e79c0889949a")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/hash-digests.fasl"
       :FASL-MD5 "827e8b4df8b348594bea03355ba04054")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/hash-seed.fasl"
       :FASL-MD5 "462ae13a472483c2ed06b0b3a61acfa4")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/package.fasl"
       :FASL-MD5 "6b74c42ef8e1acf7563e68512be7d86d")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-arena.fasl"
       :FASL-MD5 "c0a13a72357141521789a6a0abec6f2f")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-build.fasl"
       :FASL-MD5 "054d29002287b7ed79d525b47ec51641")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-core.fasl"
       :FASL-MD5 "35f6764e2d259ce2b07e750a6bf570d4")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-directory.fasl"
       :FASL-MD5 "64dc4fc07646c456b2c44b927f434c27")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-package.fasl"
       :FASL-MD5 "af545553bd2ab38353890e3212142d00")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-probe.fasl"
       :FASL-MD5 "1c5411483321f29886b3a232c9fbf319")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-read.fasl"
       :FASL-MD5 "625ddae47965e8aa6249f1788271991c")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-relocate.fasl"
       :FASL-MD5 "0d170e37957b1bf551ad23687cd8a33b")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-types.fasl"
       :FASL-MD5 "3c38b11ef949b618e445514f185d4575")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-write.fasl"
       :FASL-MD5 "dc499a87a98bf7859f6f64d91f36f85e")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/read.fasl"
       :FASL-MD5 "7c29243b02a5a7ca83c59f950198670f")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild-budget.fasl"
       :FASL-MD5 "f27c6482937d1003c9cd74241e79af44")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild-copy.fasl"
       :FASL-MD5 "e7c227dc881a5b9194896c7c5809f42a")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild-scan.fasl"
       :FASL-MD5 "1e92a6dad489cbd821c281325528cda4")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild.fasl"
       :FASL-MD5 "de80266ab708c260b9b3c25f4e1e2ae6")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/relocate.fasl"
       :FASL-MD5 "1569f537c003cfb58eb8018c2db3da0b")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/types.fasl"
       :FASL-MD5 "3bb5d6737581d66c019d2aa042d7b36c")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/validation.fasl"
       :FASL-MD5 "3fb7bb299e2418db777ea80f934ceaec")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/index/write.fasl"
       :FASL-MD5 "09d3af5d5bf8874bd3cbc680aac99b20")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/io/flush.fasl"
       :FASL-MD5 "9e0d369e00860a6eda55898bfac20147")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/io/lifecycle.fasl"
       :FASL-MD5 "ed10200d5c3b4d345f4a3b07cbd9b0eb")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/io/native.fasl"
       :FASL-MD5 "298e99b7c229999e9fc93e3a875228aa")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/io/package.fasl"
       :FASL-MD5 "636fac6c3371a9bc55ac437da588e4c0")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/io/transfer.fasl"
       :FASL-MD5 "f82014dc4706f1b280d16dafe0cb9986")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/io/types.fasl"
       :FASL-MD5 "a21a24e2deedb7dd27377a91ef2a7fb4")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/package.fasl"
       :FASL-MD5 "21261c54e8cc1f67c17d01417c944687")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-core.fasl"
       :FASL-MD5 "3d3e5d8e76483aebb0758e1255b197f3")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-csn.fasl"
       :FASL-MD5 "6d8196f915e0a6f5703261ad4cac5107")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-lifecycle.fasl"
       :FASL-MD5 "9846301d8af0c4ccb413f425afd63095")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-read.fasl"
       :FASL-MD5 "a837e111a5fce513c148e785b8501d11")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-register.fasl"
       :FASL-MD5 "9a43eaf19de9c55bc48452e03fe4ad68")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-types.fasl"
       :FASL-MD5 "a06e27191047791b589ba2763e85a019")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/types.fasl"
       :FASL-MD5 "b13bf6429530160333d8400b6eb07c61")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/package.fasl"
       :FASL-MD5 "b2964de08f8053e276ebdb7471a17fb6")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/read/core.fasl"
       :FASL-MD5 "155740baba0a4f6b882e7e357852c968")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/read/package.fasl"
       :FASL-MD5 "264da09a320097606f259da825d659b5")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/read/task.fasl"
       :FASL-MD5 "686353d5a5b09a7af33478e72b3e935b")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/read/types.fasl"
       :FASL-MD5 "8c0676159e84f65be6daacd8604533e1")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-build.fasl"
       :FASL-MD5 "89c5d6342b28aeaa1f03030074cce264")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-package.fasl"
       :FASL-MD5 "4e86cbc0bd7c82d3ef83387ce636aba8")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-query.fasl"
       :FASL-MD5 "0d55b4954635b12b2465860c117c36b0")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-radix.fasl"
       :FASL-MD5 "6a36659dcff6f29786a40abfc66a6c4e")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-sort.fasl"
       :FASL-MD5 "249a342a660bcb35818bc92295324953")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-types.fasl"
       :FASL-MD5 "4ab2d8a3a739d5af02ab16d68fa93118")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/inventory-build.fasl"
       :FASL-MD5 "5ef91e27a99b02e2b386777deb43af3b")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/inventory-query.fasl"
       :FASL-MD5 "12e94b93bbab6299f3c53797bca17620")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/inventory-types.fasl"
       :FASL-MD5 "32deb11c53f6dc01a2f6cc250b5c5775")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-build.fasl"
       :FASL-MD5 "ba277425244b2a907f307cb9bd8676ad")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-decode.fasl"
       :FASL-MD5 "610341d82cdfced946a88b47fe916013")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-fold.fasl"
       :FASL-MD5 "704d802562585e1ebc15abaf072d3f81")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-package.fasl"
       :FASL-MD5 "3371a2de4b8c70080bac1ab1439967b9")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-query.fasl"
       :FASL-MD5 "4558bdc7aa694f1c3ca4752b62c20c5a")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-types.fasl"
       :FASL-MD5 "2d4a1f47c8a2cd1e8a1c35d2e21600e3")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/package.fasl"
       :FASL-MD5 "889949e55d2311fb828cab9fa6c80ef4")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/scan.fasl"
       :FASL-MD5 "fb468e603bed3eb04f83ee9507a9690d")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/events.fasl"
       :FASL-MD5 "60353fa67ae0f6b41a6c234afd68fc82")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/io-events.fasl"
       :FASL-MD5 "2a707b1425d5b1f9fae7a8e2463f7468")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/ownership.fasl"
       :FASL-MD5 "374517178be6219359fd182806e75892")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/package.fasl"
       :FASL-MD5 "10d68d5d1fd1cb5c2f78490ac94b38d9")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/publication.fasl"
       :FASL-MD5 "57c81e5c4c026decc1a1447d1493b1b6")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/query.fasl"
       :FASL-MD5 "ea0c46e0746cb1d51546b5665ed730c7")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/retirement.fasl"
       :FASL-MD5 "7e14413378b17f0ca0f00310bf01708c")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/routing-build.fasl"
       :FASL-MD5 "ce24dc4df4cfc1ae0d5e847dace74a03")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/routing-select.fasl"
       :FASL-MD5 "702da9c50eb3c054998cdd6301b71c64")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/routing-types.fasl"
       :FASL-MD5 "22acd51bb446a3d6e9f8f946008455e9")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/types.fasl"
       :FASL-MD5 "45af9b0c08602d6120cc228849b628a9")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-boundary.fasl"
       :FASL-MD5 "0bb0ba114e8d4d261f0a092600e3fde6")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-package.fasl"
       :FASL-MD5 "b287506e0ac59014f9008509ce681aec")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-run.fasl"
       :FASL-MD5 "c942e5862a42b71d19bfc11673978f6e")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-types.fasl"
       :FASL-MD5 "c3e1c5fd79c8729657c7762fc678778f")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/compaction-scan.fasl"
       :FASL-MD5 "8e69627388f65c1773c4b7c92c40728b")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/control-payload.fasl"
       :FASL-MD5 "f0d45532cf2ca598f7163b634b4061ae")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/formats.fasl"
       :FASL-MD5 "cb8eb733dfd95c4beaf2e109d01cb61f")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/log-header.fasl"
       :FASL-MD5 "0ff539ab496c44a0cad42cd5fd505cd1")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/package.fasl"
       :FASL-MD5 "0929866f025ad8343cef909a0f13a7cf")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/payload-record.fasl"
       :FASL-MD5 "7dd0f4d7caf46480c531fb9645d2746f")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/payload-write.fasl"
       :FASL-MD5 "44e4c3e2ab9134892dcb9f7e34c6f58e")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/storage/segment-header.fasl"
       :FASL-MD5 "76666b0082f158a7cfd7f7e97574ef57")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/wal/builder.fasl"
       :FASL-MD5 "b4ab461a345f3edb1c85e3c787a17697")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/wal/csn.fasl"
       :FASL-MD5 "fef96a2e1158628774c7f64ec0ba544c")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/wal/executor.fasl"
       :FASL-MD5 "a748c92bcf356fad0f8bc4aad47c9d4d")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/wal/group.fasl"
       :FASL-MD5 "0d1263f1dc91b02d35ed4d0a1b33fbcf")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/wal/package.fasl"
       :FASL-MD5 "704d9ae5b3fc6fe6f07f823aeadef59e")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/src/wal/types.fasl"
       :FASL-MD5 "2f48cfa18274f05a7c4e8764f05419c0"))
     :COMPILED-SUITE
     ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/tests/foundation/support.fasl"
       :FASL-MD5 "3120a93248d7937fd2d9bc71bf809a5d")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/support.fasl"
       :FASL-MD5 "746a2ed2939c37e08d0af751a8a52781")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/construction.fasl"
       :FASL-MD5 "0cedbab583f31ee3d321dad9322ace3c")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/read.fasl"
       :FASL-MD5 "d480ab9f0133e4ab55bd0e9fb835e933")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/threads.fasl"
       :FASL-MD5 "b1b5c619ddeff19824588640d99a4ac8"))
     :FAILED-TEST
     "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
     :PASSED-TESTS NIL :FAILURE-KIND :PRODUCT-CONDITION :CONDITION-TYPE
     "INVARIANT-VIOLATION" :DIAGNOSTIC "ArcDocDB: DIRECTORY-LOCATION-ABSENT"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . "dd0d2a3ca3a6afb61b6623658d8eca74") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . "65ce18f4ca8502f65bf6ee411e9f5fe9") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   "bypass-closed-resolver" :FILE "src/get-directory/read.lisp" :DIRECTORY
   #A((139) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/")
   :EXPECTED-FAILURE :CANDIDATE-SIZE-AND-RESERVED-HIGH-BITS-NOT-CHECKED
   :SUBSTITUTION
   (:BEFORE
    "(risolvi-candidato-get context (trova-mappa-directory-get context directory))"
    :AFTER "(let ((map (trova-mappa-directory-get context directory)))
    (values (mappa-segmento-get-segment map)
            (arcdocdb.get.resolver::mappa-segmento-get-end map) 0 nil))")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   ("TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS") :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . "692a695f7129e0cc693cffb2983be35b"))
    (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "62285b01dc017898fc16588b6522bbbf"))
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "dde814f850eae82069c02ec9348edf34"))
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
    (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
   :COMPILED-TARGET
   (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    "dde814f850eae82069c02ec9348edf34" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/read.fasl"
    :FASL-MD5 "be6ac580dcc0e877e3f5abf31930db1f")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
     "--script" "isolated-build.lisp")
    :STDOUT-LOG
    #A((149) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/stdout.log")
    :STDERR-LOG
    #A((149) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/stderr.log")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 2267217/500000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/"
     :SOURCE-MANIFEST
     ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
       "692a695f7129e0cc693cffb2983be35b")
      (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "62285b01dc017898fc16588b6522bbbf")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cde24b2bf5c5637d5501b95bed47df31")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "dde814f850eae82069c02ec9348edf34")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9")
      (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257"))
     :SUITE-FILES
     ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
      "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
      "tests/get-directory/threads.lisp")
     :REGISTERED-TESTS
     ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
      "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
      "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
      "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
      "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
      "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
      "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
      "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
      "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
      "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
      "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
      "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
      "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
      "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
      "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
      "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
      "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
      "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
      "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
      "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
      "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
      "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
      "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
      "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
      "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
      "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
     :SELECTED-TEST "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "dde814f850eae82069c02ec9348edf34" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/read.fasl"
      :FASL-MD5 "be6ac580dcc0e877e3f5abf31930db1f")
     :COMPILED-PRODUCT
     ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/build.fasl"
       :FASL-MD5 "f9a4ea9d11cf536806250c735b3b8aa2")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/clock.fasl"
       :FASL-MD5 "448142c936c105a50271e62e5bfc3ed3")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/core.fasl"
       :FASL-MD5 "20fec77ee56eba06b63666223b04a0f5")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/package.fasl"
       :FASL-MD5 "45c19b70003419fab44dd960224faa8d")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/read.fasl"
       :FASL-MD5 "d9230d3815330c2b5661d616e9e9ae99")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/types.fasl"
       :FASL-MD5 "6026405572a5425f910856d777b02c9e")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/write.fasl"
       :FASL-MD5 "7a3be93fddaa1e21cbe4762a9b8dc167")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-float-minimal.fasl"
       :FASL-MD5 "e18a11fa41488ed8fb796326e7d0afae")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-header.fasl"
       :FASL-MD5 "371ecfa3ed9f7e02510da5824cc9f430")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-minimal.fasl"
       :FASL-MD5 "71f3a46cc044426cb5e127bec8602588")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "62285b01dc017898fc16588b6522bbbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-package.fasl"
       :FASL-MD5 "d376330fb83f612df7ffe656873e6ba2")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-input.fasl"
       :FASL-MD5 "933a23f0953e3f5e7c8303e29005ea50")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-items.fasl"
       :FASL-MD5 "a45f7fe8e98a20fc9c557208b6869121")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-minimal.fasl"
       :FASL-MD5 "a013ef2c351d8679013a9a19219f19c8")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-stack.fasl"
       :FASL-MD5 "74788e4c5d4782289000a3d2a647919c")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan.fasl"
       :FASL-MD5 "4e6d46faf6176e2503e81c7c364b60bb")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-space.fasl"
       :FASL-MD5 "2c8a5a04e89e10c106aabf0a42062daa")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-string-write.fasl"
       :FASL-MD5 "d65e8fb16ff34ba176bdf558435f480d")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-write.fasl"
       :FASL-MD5 "bb4e3cf2ceb2586a271c1f7c86b48ce6")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/package.fasl"
       :FASL-MD5 "b4b6b29c07a052aaca3850385897b956")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/utf8.fasl"
       :FASL-MD5 "919b455f5c191b726afb934b2d62c754")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/csn/package.fasl"
       :FASL-MD5 "a3f94b83046d8ced32ec27d2033076e9")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/csn/registry.fasl"
       :FASL-MD5 "99925e6ac7a2a6aebd83e004ac4bf5f4")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/core.fasl"
       :FASL-MD5 "4798244441317ef86765e9719a8d81be")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/package.fasl"
       :FASL-MD5 "b6704f55f1e019c10516fedfe65b2978")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/read.fasl"
       :FASL-MD5 "8b789661feed7afa29aa853c17ff56a7")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/reclaim.fasl"
       :FASL-MD5 "829315b46f38176b5adf878c64772521")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/retire.fasl"
       :FASL-MD5 "f42a76f7403d1c9e5fef7ad83d399899")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/types.fasl"
       :FASL-MD5 "26bb2a1f225fb0abce8de286ad5d5719")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/handoff.fasl"
       :FASL-MD5 "af9db626683b62cb2cb063d9c287905b")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/package.fasl"
       :FASL-MD5 "fdd2b3b1e3db06dcfab6cd5b5de11f72")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/queue.fasl"
       :FASL-MD5 "d16c14e2defc88089a7a1f101034b37f")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/ready-recycle.fasl"
       :FASL-MD5 "a220cf9ab5fc0cdd9af8308f1b0dcbd8")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/ready-types.fasl"
       :FASL-MD5 "b15224f2e7fb1e4dd5786533b484d605")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/ready.fasl"
       :FASL-MD5 "a662c4a780c64b47c97ceb3e1f690385")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-boundary.fasl"
       :FASL-MD5 "f70f52d71574b59b649a90b1fdc3e9d3")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-claim.fasl"
       :FASL-MD5 "9ee34ec079e472ab97f4dce437a60487")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-run.fasl"
       :FASL-MD5 "9559776decb53e2fe99f5f4aad21a1a6")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-types.fasl"
       :FASL-MD5 "e5ec53275a0c55ec6bbf5a5cc3c70f75")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/writer.fasl"
       :FASL-MD5 "cbf5da87576f80796fe09704d694839b")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/batch.fasl"
       :FASL-MD5 "bc277b18ea70a38d8f807459dafd27b5")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/binary.fasl"
       :FASL-MD5 "760956279a0d114ddeb66b33584ce979")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/conditions.fasl"
       :FASL-MD5 "bc6a16082005e7569c86fba5ffed0e34")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/crc32c.fasl"
       :FASL-MD5 "260ebfaa7df9e1fed190fa540bbf7372")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/package.fasl"
       :FASL-MD5 "dcaf6f22595dd69b65b1759e871b6972")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/record.fasl"
       :FASL-MD5 "b469b1757dfc25b8123e7733353b4b61")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cde24b2bf5c5637d5501b95bed47df31" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/build.fasl"
       :FASL-MD5 "23495cf4d23eac7f2542e1ad49238d90")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/package.fasl"
       :FASL-MD5 "257ea95f41cdc8cb9ce99ebacbcd70a3")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "dde814f850eae82069c02ec9348edf34" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/read.fasl"
       :FASL-MD5 "be6ac580dcc0e877e3f5abf31930db1f")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/types.fasl"
       :FASL-MD5 "8b2ae79db1883effb047c033b3837e10")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-build.fasl"
       :FASL-MD5 "940af291941eaf99d455259e3843ec17")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-directory.fasl"
       :FASL-MD5 "201371df8bc3e0e3d733aaa6902b53ca")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-preflight.fasl"
       :FASL-MD5 "0115e615c12013afb78456dc69ba3356")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-read.fasl"
       :FASL-MD5 "ddbb444acb4a2a4e2ff1bf7c262beecd")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-scan.fasl"
       :FASL-MD5 "ed4c4d754988f8ebf74b7912e1654b70")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-types.fasl"
       :FASL-MD5 "b7cab690dd9818b37393cd5d12cd8d04")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/build.fasl"
       :FASL-MD5 "d1838f688d1ffb1b3c02603c14b8bb95")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/package.fasl"
       :FASL-MD5 "43420f0fc05de49f83fd8b15176a1527")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/read.fasl"
       :FASL-MD5 "2328727c8a1670643c7f8bd226a620d5")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/rows.fasl"
       :FASL-MD5 "c870370a7052c9154f3629c30eb0bf0f")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/scan.fasl"
       :FASL-MD5 "4f9e33600b9e43be5b4c710850cd2961")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/sort.fasl"
       :FASL-MD5 "1b1b5068498b9ec3bff88bec6b76c028")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/types.fasl"
       :FASL-MD5 "bae516ecc750c3fcb409f1c87c1b1f47")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/build.fasl"
       :FASL-MD5 "229fb82bf561dda848090cf0c5c618e7")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/lifecycle.fasl"
       :FASL-MD5 "2ef49093ec09727fc5131f677a816467")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/lookup.fasl"
       :FASL-MD5 "e190d727a25692f6732a22545d045c96")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/package.fasl"
       :FASL-MD5 "6f127d76e5217b9f3f703af401256149")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/segment.fasl"
       :FASL-MD5 "24f79df0cde8cf074c4c66cf51a489ec")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/target.fasl"
       :FASL-MD5 "83a6b5d6cb3744baf9d1660efc5dae7d")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/types.fasl"
       :FASL-MD5 "00f633ef3cce15189fb1e1456d34861e")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/arithmetic.fasl"
       :FASL-MD5 "383f003fb0b5c8704617c84681f73c2e")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/blocks.fasl"
       :FASL-MD5 "6d41c0a8364cdf752d2d61a7dabcc903")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/hash64.fasl"
       :FASL-MD5 "852091abad84be58321f2104c3437115")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/package.fasl"
       :FASL-MD5 "dfc632efeeaf6e0c6f16aa3a3a5a64bc")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/core.fasl"
       :FASL-MD5 "390a644b487c9d8b362aa0397e3c2530")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/hash-digests.fasl"
       :FASL-MD5 "c5a8e3d256ac8661ba71bcacf1ff2662")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/hash-seed.fasl"
       :FASL-MD5 "67c1825a3c6392fc91716395a4754bef")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/package.fasl"
       :FASL-MD5 "dbcb62d125f2ef6ebadf2f48b0b6c634")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-arena.fasl"
       :FASL-MD5 "7f3c287fbcad84440b0d6091e649c668")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-build.fasl"
       :FASL-MD5 "c9fe55f0a9971680627c67b42a1f87b8")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-core.fasl"
       :FASL-MD5 "28dad47976c59ab58df0973137a8f067")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-directory.fasl"
       :FASL-MD5 "686d29fd69a8f0a91fe95a653f10a46f")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-package.fasl"
       :FASL-MD5 "05ad034178c4b2991a7367eb6ed3e94a")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-probe.fasl"
       :FASL-MD5 "e580172116c98cd61dd47f74c28e8fa2")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-read.fasl"
       :FASL-MD5 "fa8135e67df1cb628d96a380455ddd68")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-relocate.fasl"
       :FASL-MD5 "31958fc508a336c646135da73f9bc253")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-types.fasl"
       :FASL-MD5 "26e4ad5480a38b2433b0d047c4c49690")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-write.fasl"
       :FASL-MD5 "586f7a1adc61b68c83a661ed80ffe9b5")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/read.fasl"
       :FASL-MD5 "33406936a90cb74b8e60f796714af350")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild-budget.fasl"
       :FASL-MD5 "8e7510cbf68538afc5f7087fcc5028fc")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild-copy.fasl"
       :FASL-MD5 "0fdb8b50d89893ec88bdc4f551628455")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild-scan.fasl"
       :FASL-MD5 "49f27df7e3897a485d3592ab2165cb7d")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild.fasl"
       :FASL-MD5 "04d33046c9703cce4b82c7935a0dd5c4")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/relocate.fasl"
       :FASL-MD5 "960a21ef7a47c7cfbae7bd6d3f39b2f5")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/types.fasl"
       :FASL-MD5 "95eaef7bcdd10842c02efd78f181c148")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/validation.fasl"
       :FASL-MD5 "c97f19652b5e5b5c1bc16c4ab9d81ea7")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/write.fasl"
       :FASL-MD5 "0f1637f06ebe6617838e486a6e91e77d")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/flush.fasl"
       :FASL-MD5 "541b315377f757960926af114aa1cde2")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/lifecycle.fasl"
       :FASL-MD5 "cd31c89a703467d878f1dc639f024a31")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/native.fasl"
       :FASL-MD5 "7a676356dacebb51bdea95a9aef0539a")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/package.fasl"
       :FASL-MD5 "1321f70e8bca179ffb68cde27e80cfb1")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/transfer.fasl"
       :FASL-MD5 "61358c87617fd914aa4d83cd32f911d8")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/types.fasl"
       :FASL-MD5 "7350e2172fac779e406fe101f80570cb")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/package.fasl"
       :FASL-MD5 "355df966a2b880566dfd2b9f3a28b0ad")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-core.fasl"
       :FASL-MD5 "7395928115a1f420ebfc65e10daad219")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-csn.fasl"
       :FASL-MD5 "af3c1dc2b2cd6fab858751db92ce9380")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-lifecycle.fasl"
       :FASL-MD5 "a655f70bfa3463522a91a7a3e6317900")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-read.fasl"
       :FASL-MD5 "f5a170002e5a0c4167bfa14f97b64189")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-register.fasl"
       :FASL-MD5 "0bf0bc7de0d29875a5ae832b91759039")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-types.fasl"
       :FASL-MD5 "1868dbdba01687b9a87af125a8b15aab")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/types.fasl"
       :FASL-MD5 "782aac66dbc449f5a170ff39876541e6")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/package.fasl"
       :FASL-MD5 "a84177886f3b773bf688ebe34c1a08e1")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/core.fasl"
       :FASL-MD5 "78b5c7c27fdf379cfcb9a27014c37bce")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/package.fasl"
       :FASL-MD5 "87a3e35537da90e02bf3258a7d2ce9b2")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/task.fasl"
       :FASL-MD5 "5d0ec11ddc730f89e0cd4222c281a3e3")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/types.fasl"
       :FASL-MD5 "47f0a537f46a27478411159876d40af9")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-build.fasl"
       :FASL-MD5 "3fc2e37a81831691bca26a45873081e8")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-package.fasl"
       :FASL-MD5 "dbe584fcb8c0fc8bd612e0d69dd0ab6b")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-query.fasl"
       :FASL-MD5 "c40b6f25d028feec6c0e7d5df96b44e5")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-radix.fasl"
       :FASL-MD5 "6c7aca897b819fbd9396d43ff26833a4")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-sort.fasl"
       :FASL-MD5 "673389554a3fe982b83d62a0527bf887")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-types.fasl"
       :FASL-MD5 "eac578ad5029ee154f86464712928537")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/inventory-build.fasl"
       :FASL-MD5 "99be414a5cb4e856b14744c26210e04d")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/inventory-query.fasl"
       :FASL-MD5 "f3e4b6008b1a81a557b868cfa321472c")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/inventory-types.fasl"
       :FASL-MD5 "7e935108b8d1799d4b8a063f636b1664")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-build.fasl"
       :FASL-MD5 "0cec1d7052aa03e0b7016c2e97536a00")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-decode.fasl"
       :FASL-MD5 "59e3183923476773107919037be32d6c")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-fold.fasl"
       :FASL-MD5 "6e17764abea4531ff7c5cf3782b08fc6")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-package.fasl"
       :FASL-MD5 "e14f38b7f1ae6a50252b176c6bd1391b")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-query.fasl"
       :FASL-MD5 "516513b3614ba6cc05514a5cdfd290fb")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-types.fasl"
       :FASL-MD5 "10831d8d3d21b8c69120eada74b3a7d9")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/package.fasl"
       :FASL-MD5 "094e43234dce0ec852493924fb72ca8f")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/scan.fasl"
       :FASL-MD5 "dc7f77fb788e016d2dd1286f7bdf606b")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/events.fasl"
       :FASL-MD5 "c1d08e11dfcb781e97007c6aefa6c84d")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/io-events.fasl"
       :FASL-MD5 "7929af5ea2a9a7c03845d889bb0eccd4")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/ownership.fasl"
       :FASL-MD5 "0e0766b3cceff4b492a7a4fdb8523812")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/package.fasl"
       :FASL-MD5 "6e102ed0a32643e5fce230bd54b0d824")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/publication.fasl"
       :FASL-MD5 "67db8cf29f626b2779fab9883e80a525")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/query.fasl"
       :FASL-MD5 "9cdff0baf70cf4733d8fdbeababf6d4c")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/retirement.fasl"
       :FASL-MD5 "28b39910ff5f425676634c32d058d962")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/routing-build.fasl"
       :FASL-MD5 "f4ecb41bd82a265c72b22b7eeee07725")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/routing-select.fasl"
       :FASL-MD5 "92ecb6af9ce6e3d291ab3ecbba1073f9")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/routing-types.fasl"
       :FASL-MD5 "f6325a5dbb5606f6b37f8afd89cfb8c0")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/types.fasl"
       :FASL-MD5 "93611c7f6abea2c11fdc92b83d76e969")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-boundary.fasl"
       :FASL-MD5 "3eafdfdef44c6055dc6164f5da9206ce")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-package.fasl"
       :FASL-MD5 "12461950f8f36e1f5eba847d2e8e3d80")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-run.fasl"
       :FASL-MD5 "f461e35de15127b7628bf395f8424054")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-types.fasl"
       :FASL-MD5 "9d211172d1ffff26f6cb6e776aeeebc1")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/compaction-scan.fasl"
       :FASL-MD5 "b5ff94abfec18b581e004060a68f00c3")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/control-payload.fasl"
       :FASL-MD5 "6fd6fdc3cd2e6068733934376db23e13")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/formats.fasl"
       :FASL-MD5 "d68ed08220dc98f094c7b6d51be2420e")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/log-header.fasl"
       :FASL-MD5 "aad06b529bb381991fb60c49315b6438")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/package.fasl"
       :FASL-MD5 "99a536a5abfd4ebda9dc3ad4ed0f9a6f")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/payload-record.fasl"
       :FASL-MD5 "2e36612064831738c3adc38f452946cf")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/payload-write.fasl"
       :FASL-MD5 "651253dd0af8154eefb7b40fdd4b72df")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/segment-header.fasl"
       :FASL-MD5 "54906cd82142821bf08d3ff9644369ef")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/builder.fasl"
       :FASL-MD5 "408b3c5d2540f8022c46a125dcb81f5b")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/csn.fasl"
       :FASL-MD5 "28041b4091c04f71393ebf97e120ed75")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/executor.fasl"
       :FASL-MD5 "42a37556b55d21b8829754bfd4d0df4a")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/group.fasl"
       :FASL-MD5 "4df068f003730122e23fe8eb2f929fdc")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/package.fasl"
       :FASL-MD5 "ffef9fcccf37555ebbfe2dedeccdde33")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/types.fasl"
       :FASL-MD5 "d8c53e1525d649a29b18b0b3cd5f5cac"))
     :COMPILED-SUITE
     ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/tests/foundation/support.fasl"
       :FASL-MD5 "fc739ee43f3e3f44811a48a63a498eb3")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/support.fasl"
       :FASL-MD5 "e9bb328108301c1ce0dd82b6a5fee018")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/construction.fasl"
       :FASL-MD5 "4f70ee540a792db2201d60b3c449353c")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/read.fasl"
       :FASL-MD5 "77e61ce35426e350f470bc0de4f73d9a")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-d/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/threads.fasl"
       :FASL-MD5 "3b8118c1f013a028a962ba6c303c8d50"))
     :FAILED-TEST "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
     :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE "SIMPLE-ERROR"
     :DIAGNOSTIC "Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (ARCDOCDB.GET.DIRECTORY:RISOLVI-CANDIDATO-DIRECTORY-GET
                       ARCDOCDB.GET.DIRECTORY.TESTS::CONTEXT
                       (ARCDOCDB.GET.DIRECTORY.TESTS:DIRECTORY-FIXTURE-DIRECTORY
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVARIANT-VIOLATION (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :RESOLVER-CANDIDATE-SIZE)))"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . "c40df0a53fbe4c0249dc32ff2355cc82") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . "dde814f850eae82069c02ec9348edf34") :ARTIFACTS-VERIFIED
   T))
 :COUNTERS
 (:DETECTED 5 :SURVIVED 0 :BASELINE-PASSED 1 :BASELINE-FAILED 0
  :COMPILATION-ERROR 0 :INFRASTRUCTURE-ERROR 0 :INVALID 0 :NOT-RUN 0 :PENDING
  0)
 :DETECTED 5 :SURVIVED 0 :COMPILATION-ERRORS 0 :INFRASTRUCTURE-ERRORS 0
 :INVALID-RESULTS 0 :SOURCE-CONSISTENCY :STABLE :LIMITS
 (:ONLY-DIRECTORY-BUILD-READ-MUTATED :CLOSED-ONLY
  :ONLY-DIRECTORY-SUITE-EXECUTED :FOUNDATION-SUPPORT-DEFINITIONS-ONLY
  :ALL-PRODUCT-SOURCES-COMPILED :FRESH-CHILD-PRIVATE-ASDF-OUTPUT
  :SOURCE-AND-FASL-MD5-ATTESTATION :ONE-NAMED-TEST-PER-MUTANT
  :ASSERTIONS-AND-PRODUCT-CONDITIONS-SEPARATED
  :COMPILER-FIXTURE-IO-TIMEOUT-CRASH-AND-TYPE-ERRORS-ARE-NOT-KILLS
  :PARTIAL-COPIES-AND-LOGS-RETAINED :BOUNDED-CLEANUP :NO-ENGINE-QUALIFICATION))
