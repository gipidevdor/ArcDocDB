(:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
 "missing-location-first-map" :FILE "src/get-directory/read.lisp" :DIRECTORY
 #A((143) BASE-CHAR
    . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/")
 :EXPECTED-FAILURE :MISSING-PUBLISHED-SEGMENT-AUTHORIZED :SUBSTITUTION
 (:BEFORE
  "(when (= left right) (guasto-get context :directory-location-absent))"
  :AFTER "(when (= left right)
               (if (plusp (length maps))
                   (return-from cerca-mappa-directory-get
                     (the mappa-segmento-get (svref maps 0)))
                   (guasto-get context :directory-location-absent)))")
 :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
 ("TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP")
 :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . "b5e1e1260d8364e7eb1549db37153364"))
  (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
  (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
  (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
  (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
  (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
  (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
  (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
  (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
  (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
  (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
  (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c3f19ffb4aacfdfe502c5e8b12a234f2"))
  (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
  (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
  (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
  (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
  (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
  (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "200373402e6e082dd8c7afde305302bb"))
  (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
  (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
  (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
  (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
  (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
  (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
  (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
  (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
  (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
  (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
  (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
  (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
  (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
  (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
  (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
  (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
  (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
  (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
  (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
  (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
  (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
  (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
  (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
  (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
  (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
  (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
  (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
  (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
  (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
  (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
  (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
  (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
  (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bd12d0077a79f0c9c2f0a4dd01731f43"))
  (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
  (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
  (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
  (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
  (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
  (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
  (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
  (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
  (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
  (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
  (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
  (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
  (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
  (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
  (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
  (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
  (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
  (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
  (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
  (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
  (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
  (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
  (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
  (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
  (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
  (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
  (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
  (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
  (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
  (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
  (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
  (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
  (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
  (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
  (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
  (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
  (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
  (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
  (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
  (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
  (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
  (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
  (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
  (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
  (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
  (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
  (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
  (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
  (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
  (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
  (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
  (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
  (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
  (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
  (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
  (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
  (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
  (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
  (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
  (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
  (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
  (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
  (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
  (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
  (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
  (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
  (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
  (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
  (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
  (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
  (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
  (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
  (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
  (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
  (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
  (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
  (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
  (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
  (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
  (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
  (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
  (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
  (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
  (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
  (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
  (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
  (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
  (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
  (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
  (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
  (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
  (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
  (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
  (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
  (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
  (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
  (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
  (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
  (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
  (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
  (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
  (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
  (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
  (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
  (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
  (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
  (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
  (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
  (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
  (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
  (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
  (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
  (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
  (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
  (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
  (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
  (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
 :COMPILED-TARGET
 (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
  "bd12d0077a79f0c9c2f0a4dd01731f43" :FASL
  "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl"
  :FASL-MD5 "811607459e9ab3446a242baa097922eb")
 :EXECUTION
 (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
  :ARGV
  ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
   "--script" "isolated-build.lisp")
  :STDOUT-LOG
  #A((153) BASE-CHAR
     . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/stdout.log")
  :STDERR-LOG
  #A((153) BASE-CHAR
     . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/stderr.log")
  :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 6511759/1000000 :EXIT-CODE 1 :SIGNAL
  NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS :STATUS
   :FAILED :ROOT
   "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/"
   :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
     "b5e1e1260d8364e7eb1549db37153364")
    (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5d70197c8b64ad6f20c8be47a60c73ca")
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3546cf7f5c5ed138068548c20064f499")
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "72f3a33ce27ddf94c49c495580520004")
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a1f6a8e7aa4faed88e984b39871d1e53")
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "82f937b7b08bd1696ad9c88da2e1c60c")
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a25648d870eaa4f0b6e1e3b2cf76e28e")
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fc09021f74fb50aac57589614dae04d7")
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bc7a7b176e8cdd361b7c4306a1a4de4b")
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "6e8c6a49314c2f460aa6f8a1759200b6")
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ecd8fe950344059c629927b38fb6e4aa")
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c3f19ffb4aacfdfe502c5e8b12a234f2")
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f6488e987889432b375254021825dbe5")
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "706c0baa4158bf272c4b0df17c1439d2")
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "987e8ed576a21eb644ac1ef2e06edbda")
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cf1999ddb10f879aeefbeea853742d57")
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0c33aedcdb352e78a3c694cf796e6692")
    (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "200373402e6e082dd8c7afde305302bb")
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c33cdcc45f45218aa3e8bf26ce0ee575")
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b13e92b5f24a42fe283c17b649722b6a")
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "69e77bcd15b5413a815a65c5081229db")
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d885bd2a9860eb60aec1a775e5031d5e")
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0f67dd5c51bf6a63bc292ab4e2a280c2")
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1130012fc5613a5648d22ed8628be0e8")
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a1cdb5661fc54beba5bf00e4765f3235")
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "765d14c88cd288093a77a57930cd6999")
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "875201dfab0a84efd40fe9828cc293c8")
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "975b5f74e0c5a38ce978f4d9c7fcc6b8")
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "036dd02adf87d33c3ae2f40735c733fa")
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "653b974f310c09f6e2224a84acc43bbf")
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "82253491f995f5bc153fb5ebf30d564c")
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "6b85eebe69366e78ed5fc5cc20735f00")
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cb5710d6c111cadb7121a50998a747fa")
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8202843bddb817da4279ac959ae3f3c4")
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "38d26f8c749dd946dfc4b9c57103a892")
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a64d98c9ff429d6103d6e10ee1fd7980")
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2c1892002f0599bb8273093031017520")
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c24065d6c8d80d1be53994a0041743df")
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "babd0a78b4185af24ae1fef870c0fabb")
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "aa34ca6bc07535e35fea723878d99f66")
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0679ee07c46f69db330706303c70d8d2")
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "73019644090e2971f2b54dc36e4491f5")
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ca642ea47e4bff76f78f5b6d7287d6bd")
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a06115175f450776762761dce25acdb8")
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "942b596396c19815290a57830af2121b")
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "4db58e2f48bf77d751f1b83bb9f84b5c")
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5ee593a112958d94163dab17c5aa4ba2")
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cde24b2bf5c5637d5501b95bed47df31")
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "4233eef9d87bdec712d4f690bcb699a9")
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bd12d0077a79f0c9c2f0a4dd01731f43")
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "17c957d6934a31f4ed64313e756de2d2")
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8d26428a4e17ad18990b8ee7d5f5b53a")
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "6d95f29b331d335175843f47ae44a6ea")
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f13d422adb6aa9e8489352884137f25a")
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3da469a7aa1e682dd8f2e516ee451de1")
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d6aaec49504a96f37c8ff1bc182c977b")
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bd7182e9871fe82530d0c828e473ccde")
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bbfb2082103e6712419e180ab972245c")
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cbfb17bf1f65698fb7c7889953d02d1e")
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1339edff0223dbf122f11ff0adbba61c")
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ca9002b81efd0aed9761cd1f78514762")
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "536e9dc4ed51072b8a6d1528d3ec18bf")
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2d869293ba47444c4721713d955c6254")
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9df13bcc6908e9fa601d173a671e1ccf")
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c5cc36884b238221cc13ca0c087ec7c2")
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e70bfeddd694336bbd088e65f8761834")
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "82258ec87aca513a508bc5dee8410dd6")
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c72633d15c3488699072eb610ebde7c8")
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "811869eb6a197d3c4e26af4322e52652")
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1b70dac05d6d2418909eb5105b808e81")
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c394e5684de5e2d938991c7cb348b93c")
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b5c51802e607e3dd22de68204baf64e9")
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bef497b9a267c7306d4100000491c814")
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "886b7c08b9929283e8968831cbe5c039")
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2d9060e41bc5252067d35e59ac70ee06")
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "65076c355c099b5dc73d185948d3bec4")
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "43d2209225707352daec6186ef95a805")
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "45ce41749bc6fa638539815d3f802b96")
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "598a9b65e73151c924b2cdcaf6d96705")
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a319691e3e28b7ea7b927de490cf69ba")
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ff2cfbb865290d7a1510fdf6877c7229")
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fa52433eae199ceeb874bf2bc47afca7")
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1dd67c527257e43f17e006644ecdbd00")
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d65cfce399b04f905bf969929962e59a")
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "699ce3f1615296fc27fcde3e0d63a4bc")
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3f317a0d3c5ee86a73651aad36135cc3")
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5155959766645d3172ae5e73c58cc071")
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a59eab6425a60fa2656f86bf87d5c9ac")
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e8e31e599356e592af29c0cc4604872b")
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5b22b90cfe8534086f6aff96d156713e")
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0417dd41cb3ec1d62dfd913c19f810ad")
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8befbbd00ed5c31c1487a11887eba495")
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1188e7a64a7a5d9482c1233cb9acb452")
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a450cac8071513365267e7024cbe94b0")
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "475dd7d5809a836f01544b447cc8df27")
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5157fd03ee806ee998ad8f0002d56268")
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3384cadf737c7d80c004222022a281f6")
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f0c8c579cd7db466d243ed3ea9f8e8aa")
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "716866194d6b9f076e102e84187229c0")
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "11c7103efbe733bbf0a13927f23c3d34")
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9500cfb800603de002d6d2b24f1bf056")
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c9380ad46a1d7acf41655aaed20db478")
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a5e7108e80664eb3b562fbd7e680801f")
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "db8497f9cff35b1ee261f1f410f46ca6")
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f188d1dbd5d0adb49f53acf09157aef9")
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8bb066aab61a18eff175b9edb11e42a2")
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0e9365e674d1584b111f915ce1f58634")
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ff98aea5cb9a7ae2671f6a887a003725")
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ae3ad96269b5e711a9dbb455f3c0ce48")
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2d5a795bcefd605c75da91c725ae83a2")
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "475517bd7ba04a1c37a82efeb8ff73d9")
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a9bc70eab6720b5c6f8503178e2c966b")
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "becf5c78049c85f2c05cd1ef54454032")
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "4040905f4a64ba704a480d82e87ec748")
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "7d74d9decc5a0bc9f9331d89bd503e21")
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9e0baf22c53329d393e047c669679645")
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9c37ff8237fcc9fe9ae4f44316e854e3")
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1a51ef4a488bb9fde2ff7d47bae01379")
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cbdc30f93109c474e1fc25066c9b9b13")
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f782d1137b8ce342b91c9999cfb7accc")
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "852149de4c289b8e067602780378d87a")
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b33e57a643f2fca810846f6226366253")
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f4433fd19ebc7239dbc2628c39f3ecdb")
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9bd6820c4feba3e552aab1a4edd87861")
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fcea263de1938767772e5b11411ecd5e")
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "78c136d5838dcfe3019d9069643a8d8f")
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bf65b1731eab6e0572461ef5cc60fc40")
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "67975249aaabd751757cdfb9222cc3c4")
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e0d2498db1011e857b7b0daa1934f187")
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "37ace42844c11b52446ee1fc500b8e0b")
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ebd7a54adea2213294a887e6d4db0927")
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "7b1d4054415faca7e5fca59ad83b4d4a")
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fcacd15460db25ea9cc4036065f9f096")
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "32b2156739a6f2ca996abb91df0a2603")
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b6026a8b7bb64b45c37a65effda70d8e")
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "de1aca16a35d34d16aba12ff541c0d2b")
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "59e3c59c90d8d0fc5731b87496a785aa")
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "056d2c6a67c9d9f2bf9fe2d2c348d53c")
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cb0d91405325b508e6b2ab24d178de7a")
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b8e04971b8ad75a1bd0c722997badfd2")
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d6924deff152b941bd49f0bb200b4197")
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e0f987d8767744050ec4d1b3ecb699ed")
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ce649df47dd38888d5103c98345f7e41")
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ab19ec8d15af91511e817858c41cebc8")
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2340e0c9074f7b1bf80c74f774986bc5")
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a93ce2e84e8aee647b5083ad1d2b899b")
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f0fee18adf357bad98e8a3c3e8c70c0c")
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2b23d468be0165fa009c5ebd5d1bbe23")
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1cda77a357ab2147035993b72d135a37")
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cb64f806b8d69eb42d865b4abfff0b27")
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "061147be459d8d3b08c661bd3f91d152")
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b53d27dcc9f4badf18b50519c50bc614")
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f86bd104f20616a76b42c02227f72844")
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8c03f9c01dcb30f2d3970a5694968ecf")
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d6812fa59bf8fd1252fbf85a9bfa3896")
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a229f76f7036f3573a6e528dcd390a19")
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "42b990e3b254e6fb488c0ab91b6a6502")
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c0340924c9130e14d0e8efedeec078f1")
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "7a0e7c99ab70b4720cbb091156560f5e")
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "96c41b1d417135a24fc65659ea3abe11")
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f799f27a8ac1a4c736c04796c1e543f9")
    (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     "758adad069aec2f9dbe0635797314ff6")
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     "3f868ebe4307ad4238b314c37eceed9a")
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     "1137938073e71d6d8d62c751fbad05d5")
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     "d1ab36d05cc1266e4533d27c693f12f4")
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     "63dd01c852de1399c2c82274d481d257"))
   :SUITE-FILES
   ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
    "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
    "tests/get-directory/threads.lisp")
   :REGISTERED-TESTS
   ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
    "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
    "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
    "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
    "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
    "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
    "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
    "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
    "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
    "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
    "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
    "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
    "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
    "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
    "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
    "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
    "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
    "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
    "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
    "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
    "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
    "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
    "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
    "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
    "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
    "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
    "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
    "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
    "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
   :SELECTED-TEST
   "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
   :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
   (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    "bd12d0077a79f0c9c2f0a4dd01731f43" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl"
    :FASL-MD5 "811607459e9ab3446a242baa097922eb")
   :COMPILED-PRODUCT
   ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/build.fasl"
     :FASL-MD5 "b02d6ca7bb024cf74cd20ac1dbe429d3")
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3546cf7f5c5ed138068548c20064f499" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/clock.fasl"
     :FASL-MD5 "9bcf8da9ce5742bbd403e20d2f8464f3")
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "72f3a33ce27ddf94c49c495580520004" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/core.fasl"
     :FASL-MD5 "b5c57a3346a246b3e3c754fb94a0f12f")
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/package.fasl"
     :FASL-MD5 "9911226b6dea70848c306260f0d9011e")
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/read.fasl"
     :FASL-MD5 "839b62352f383439f27d02f04bb05b30")
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/types.fasl"
     :FASL-MD5 "9883b14e23650447b16eb2f0e45e83d9")
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fc09021f74fb50aac57589614dae04d7" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/write.fasl"
     :FASL-MD5 "03ce66722ebeb7b49f96aec2b9613719")
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-float-minimal.fasl"
     :FASL-MD5 "c83e4b5f6089d5c8f1c4c40138ad1da4")
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-header.fasl"
     :FASL-MD5 "29fe6e95583fc9f52a2fe10e3e888905")
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ecd8fe950344059c629927b38fb6e4aa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-minimal.fasl"
     :FASL-MD5 "98fb674c2596fd2efffdbbae30651878")
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-package.fasl"
     :FASL-MD5 "360e82897ee560169326125516069df7")
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f6488e987889432b375254021825dbe5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-input.fasl"
     :FASL-MD5 "8d0cc753b3869d9bcd311de738397086")
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "706c0baa4158bf272c4b0df17c1439d2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-items.fasl"
     :FASL-MD5 "33ec8fbadb9267ac8ff5f09ca1b98d34")
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "987e8ed576a21eb644ac1ef2e06edbda" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-minimal.fasl"
     :FASL-MD5 "b1290ae2174162571ed55a01f5c0c13e")
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cf1999ddb10f879aeefbeea853742d57" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-stack.fasl"
     :FASL-MD5 "7e11aae26575717ed37bf8239fc3a7e5")
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0c33aedcdb352e78a3c694cf796e6692" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan.fasl"
     :FASL-MD5 "6535296f089bdec31c2993d0347a9eab")
    (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "200373402e6e082dd8c7afde305302bb" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-simple-write.fasl"
     :FASL-MD5 "ed2ff333410dcef4fe7d2aa08f57cbcc")
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-space.fasl"
     :FASL-MD5 "df3ddf573be454579e058fa5bc8e06fa")
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b13e92b5f24a42fe283c17b649722b6a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-string-write.fasl"
     :FASL-MD5 "27bca02e549779951a95bb0a7e787cbf")
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "69e77bcd15b5413a815a65c5081229db" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-write.fasl"
     :FASL-MD5 "b6b33741165eba56e446b41a555952b5")
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d885bd2a9860eb60aec1a775e5031d5e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/package.fasl"
     :FASL-MD5 "23a9c67ad2a955fbca1dd58ab10541cc")
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/utf8.fasl"
     :FASL-MD5 "68566b98480a8b77ee07db4be58b8266")
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1130012fc5613a5648d22ed8628be0e8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/csn/package.fasl"
     :FASL-MD5 "f625fe6fee7cd3b4e1591c0dec71cfb1")
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a1cdb5661fc54beba5bf00e4765f3235" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/csn/registry.fasl"
     :FASL-MD5 "658cb95b65e768c97af8abaa67b4ec1c")
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "765d14c88cd288093a77a57930cd6999" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/core.fasl"
     :FASL-MD5 "889ab14bf558158601e6574c9a6cb451")
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "875201dfab0a84efd40fe9828cc293c8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/package.fasl"
     :FASL-MD5 "cd4c4f673dedf62edf626bad2400632d")
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/read.fasl"
     :FASL-MD5 "f5f65447b8a0f84f44b7cc500e6d1be7")
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "036dd02adf87d33c3ae2f40735c733fa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/reclaim.fasl"
     :FASL-MD5 "44067aca4695eba1d6a3a8153f31e8d2")
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "653b974f310c09f6e2224a84acc43bbf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/retire.fasl"
     :FASL-MD5 "189c29532108fd611320903eb8106388")
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "82253491f995f5bc153fb5ebf30d564c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/types.fasl"
     :FASL-MD5 "1c3f0215973ac536628450a82e735b55")
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "6b85eebe69366e78ed5fc5cc20735f00" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/handoff.fasl"
     :FASL-MD5 "b2aa378528ba8f4275b52173318092b6")
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cb5710d6c111cadb7121a50998a747fa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/package.fasl"
     :FASL-MD5 "41240eeb18d8bb3f97fb129fe8ea81ad")
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8202843bddb817da4279ac959ae3f3c4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/queue.fasl"
     :FASL-MD5 "9436642bf9a4853d97a5262b2fff8f3e")
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "38d26f8c749dd946dfc4b9c57103a892" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready-recycle.fasl"
     :FASL-MD5 "f9643e2f155e69e5d7bc36f54718672f")
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready-types.fasl"
     :FASL-MD5 "dd3dd6aa6070d7fd7a7f057418dd1b3b")
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2c1892002f0599bb8273093031017520" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready.fasl"
     :FASL-MD5 "41638343d9270fd3c1a96359c169eda2")
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c24065d6c8d80d1be53994a0041743df" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-boundary.fasl"
     :FASL-MD5 "b1513f5ebedc9a1766b6153d8d69d21e")
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "babd0a78b4185af24ae1fef870c0fabb" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-claim.fasl"
     :FASL-MD5 "e165fc474fb9a258f80865ff4f0c47d8")
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "aa34ca6bc07535e35fea723878d99f66" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-run.fasl"
     :FASL-MD5 "0243a87f41ad56b392dbae679f66f709")
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0679ee07c46f69db330706303c70d8d2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-types.fasl"
     :FASL-MD5 "6ed14c46917c4454d7ef96b914eb1116")
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "73019644090e2971f2b54dc36e4491f5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/writer.fasl"
     :FASL-MD5 "8c438dd8c6a3cfb2eadd20e730912733")
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/batch.fasl"
     :FASL-MD5 "79c9719a5036c9181ed6aa57d046b9c8")
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a06115175f450776762761dce25acdb8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/binary.fasl"
     :FASL-MD5 "87d2726dc64e746610adb46f352b0737")
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "942b596396c19815290a57830af2121b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/conditions.fasl"
     :FASL-MD5 "13e27519d15f4d4d0e57d3292565efa5")
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/crc32c.fasl"
     :FASL-MD5 "7e906f6696d62005ac5b6a7359c469d8")
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5ee593a112958d94163dab17c5aa4ba2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/package.fasl"
     :FASL-MD5 "b846cc52a0ba94f173c30c962b5a971a")
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/record.fasl"
     :FASL-MD5 "b317a0cee10a7008caa27fd5793eb975")
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cde24b2bf5c5637d5501b95bed47df31" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/build.fasl"
     :FASL-MD5 "73a76318fd7fedf37c8a18dc5bce1e56")
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "4233eef9d87bdec712d4f690bcb699a9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/package.fasl"
     :FASL-MD5 "60b906439b21437ed7dc57568c15145f")
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bd12d0077a79f0c9c2f0a4dd01731f43" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl"
     :FASL-MD5 "811607459e9ab3446a242baa097922eb")
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "17c957d6934a31f4ed64313e756de2d2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/types.fasl"
     :FASL-MD5 "dc3b0184dcbe1dbd1a605577f5c90aae")
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-build.fasl"
     :FASL-MD5 "781b11647a66b5f866e323995bdbdef9")
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "6d95f29b331d335175843f47ae44a6ea" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-directory.fasl"
     :FASL-MD5 "3eb16449838175cf81ac336e4411dc19")
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f13d422adb6aa9e8489352884137f25a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-preflight.fasl"
     :FASL-MD5 "672305d1bb65bf9b5d51aaa649fe4374")
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3da469a7aa1e682dd8f2e516ee451de1" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-read.fasl"
     :FASL-MD5 "68377524ede71036ae972ac42ae1104b")
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d6aaec49504a96f37c8ff1bc182c977b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-scan.fasl"
     :FASL-MD5 "95174d58607ca5411fe017f853d8fe58")
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bd7182e9871fe82530d0c828e473ccde" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-types.fasl"
     :FASL-MD5 "28fda7954b9a8272172228e18b6c0199")
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bbfb2082103e6712419e180ab972245c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/build.fasl"
     :FASL-MD5 "90fc630863a3c20dd05f15a76a353ba5")
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/package.fasl"
     :FASL-MD5 "4c25278dc9348a16793026667e4c40ce")
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1339edff0223dbf122f11ff0adbba61c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/read.fasl"
     :FASL-MD5 "e4b07f05e429292520028074b3167d25")
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ca9002b81efd0aed9761cd1f78514762" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/rows.fasl"
     :FASL-MD5 "a92743603873320ae09bbdac00350edf")
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/scan.fasl"
     :FASL-MD5 "1327a84e8ac23b721fc92a02b3ecaa49")
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2d869293ba47444c4721713d955c6254" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/sort.fasl"
     :FASL-MD5 "24dbb908f03f0f1b3fad07b9b46c1c60")
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9df13bcc6908e9fa601d173a671e1ccf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/types.fasl"
     :FASL-MD5 "4785bd0e6ec7dd4147a97672e1bae7c4")
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c5cc36884b238221cc13ca0c087ec7c2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/build.fasl"
     :FASL-MD5 "b2c2a8a902aa97e02f5c6529dbcc82d3")
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e70bfeddd694336bbd088e65f8761834" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/lifecycle.fasl"
     :FASL-MD5 "19c819788a912548f5f06fb35397b148")
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "82258ec87aca513a508bc5dee8410dd6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/lookup.fasl"
     :FASL-MD5 "00378dde1d9fad429a66844d7cfee890")
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c72633d15c3488699072eb610ebde7c8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/package.fasl"
     :FASL-MD5 "9bc220d5f2f64bbe0640d4638556a8c7")
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "811869eb6a197d3c4e26af4322e52652" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/segment.fasl"
     :FASL-MD5 "c925f6fdb1b0ccce64093f38b6381bdb")
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1b70dac05d6d2418909eb5105b808e81" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/target.fasl"
     :FASL-MD5 "5be1499b3c703184dcb61ecc1852d033")
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c394e5684de5e2d938991c7cb348b93c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/types.fasl"
     :FASL-MD5 "5ef76ab8ea86555a8c0c64670f47d6fd")
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b5c51802e607e3dd22de68204baf64e9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/hash/arithmetic.fasl"
     :FASL-MD5 "c15ffe968e7138bd0beaf879205fd931")
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bef497b9a267c7306d4100000491c814" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/hash/blocks.fasl"
     :FASL-MD5 "e23300ce6cd4e6fa026233b04754d3ba")
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "886b7c08b9929283e8968831cbe5c039" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/hash/hash64.fasl"
     :FASL-MD5 "a6094fbb46bd333ba2d4f8ccb0e16b5e")
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2d9060e41bc5252067d35e59ac70ee06" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/hash/package.fasl"
     :FASL-MD5 "f3200a579950303cb33375a3850292c9")
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "65076c355c099b5dc73d185948d3bec4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/core.fasl"
     :FASL-MD5 "41e25af714b754b100a58ca3826779fe")
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "43d2209225707352daec6186ef95a805" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/hash-digests.fasl"
     :FASL-MD5 "c6b4343071bebcfe7637ca3c7355db3a")
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "45ce41749bc6fa638539815d3f802b96" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/hash-seed.fasl"
     :FASL-MD5 "62504b79fcadd35868e810bacc682819")
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "598a9b65e73151c924b2cdcaf6d96705" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/package.fasl"
     :FASL-MD5 "aed7bf87558f618e18eb2e33e846d9bf")
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a319691e3e28b7ea7b927de490cf69ba" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-arena.fasl"
     :FASL-MD5 "dd2ece60cadb50f4e9a86f85212a0ada")
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ff2cfbb865290d7a1510fdf6877c7229" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-build.fasl"
     :FASL-MD5 "524bdb9815910bb5110e1a89a75414d4")
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fa52433eae199ceeb874bf2bc47afca7" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-core.fasl"
     :FASL-MD5 "5b7d179a29a94e0c96ebd051a64111f1")
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1dd67c527257e43f17e006644ecdbd00" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-directory.fasl"
     :FASL-MD5 "693e8582581b83a8e0e1f898cc834a13")
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d65cfce399b04f905bf969929962e59a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-package.fasl"
     :FASL-MD5 "1e58bd1d815dacfff845c2bcda90e504")
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-probe.fasl"
     :FASL-MD5 "0d24dbd9d80219644f05f836e96cf77c")
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3f317a0d3c5ee86a73651aad36135cc3" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-read.fasl"
     :FASL-MD5 "b82b1ee4e70aac544e5c5c72360ddf4b")
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5155959766645d3172ae5e73c58cc071" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-relocate.fasl"
     :FASL-MD5 "d6cf783638e810a021bb4f385d335a10")
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-types.fasl"
     :FASL-MD5 "bdbebc38df9db6a4310bad560afb5240")
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e8e31e599356e592af29c0cc4604872b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-write.fasl"
     :FASL-MD5 "a4e4a2b03577117b737a983795708421")
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5b22b90cfe8534086f6aff96d156713e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/read.fasl"
     :FASL-MD5 "4292af75ea212ebc83ffe42ce9ee277d")
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-budget.fasl"
     :FASL-MD5 "ac219c0e660517c72f9ed6dfe7ecd670")
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8befbbd00ed5c31c1487a11887eba495" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-copy.fasl"
     :FASL-MD5 "80166c61ce8eb613c2826e85130abc91")
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1188e7a64a7a5d9482c1233cb9acb452" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-scan.fasl"
     :FASL-MD5 "d8ba12886627fcf097a43c06a72db627")
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a450cac8071513365267e7024cbe94b0" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild.fasl"
     :FASL-MD5 "49e09058658872f1cb00f2f8f85e4f53")
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "475dd7d5809a836f01544b447cc8df27" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/relocate.fasl"
     :FASL-MD5 "5868322758b2112a4a277e262b2de5c7")
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5157fd03ee806ee998ad8f0002d56268" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/types.fasl"
     :FASL-MD5 "f126f5fb43c2ce643011e19c523691ae")
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3384cadf737c7d80c004222022a281f6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/validation.fasl"
     :FASL-MD5 "6d27a961aad9478df565da0bbeebcb01")
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/write.fasl"
     :FASL-MD5 "c94535cb251aa1581fe9dad06e65189f")
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "716866194d6b9f076e102e84187229c0" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/flush.fasl"
     :FASL-MD5 "402e073742473cedbad5f5c31ba7c3bc")
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "11c7103efbe733bbf0a13927f23c3d34" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/lifecycle.fasl"
     :FASL-MD5 "d6c866c25197d4ba7671dc9d4dd00088")
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9500cfb800603de002d6d2b24f1bf056" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/native.fasl"
     :FASL-MD5 "20821dabddd29a21cc93f22e5a47fc23")
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c9380ad46a1d7acf41655aaed20db478" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/package.fasl"
     :FASL-MD5 "c31f97a9a834492338352b54d3cb76fe")
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a5e7108e80664eb3b562fbd7e680801f" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/transfer.fasl"
     :FASL-MD5 "47db5dedf281fb57647512fb26195c10")
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "db8497f9cff35b1ee261f1f410f46ca6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/types.fasl"
     :FASL-MD5 "9b4dc5206b3198dc93477b3da8713c46")
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f188d1dbd5d0adb49f53acf09157aef9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/package.fasl"
     :FASL-MD5 "58c591ac71c44a1daa298a958b94188f")
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8bb066aab61a18eff175b9edb11e42a2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-core.fasl"
     :FASL-MD5 "759aee4169e0dfcb9c460589d8de028c")
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0e9365e674d1584b111f915ce1f58634" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-csn.fasl"
     :FASL-MD5 "b6830456645ab79a179a121119bb219f")
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ff98aea5cb9a7ae2671f6a887a003725" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-lifecycle.fasl"
     :FASL-MD5 "4e4520cbdc023b7e5b2c5f6f4cf79894")
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-read.fasl"
     :FASL-MD5 "8c3fbbb0107a22662a14f5fc9ec21838")
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2d5a795bcefd605c75da91c725ae83a2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-register.fasl"
     :FASL-MD5 "f8d7a2c00fef491c1dbd9c9321114ea5")
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-types.fasl"
     :FASL-MD5 "903e898d2b2434f27902c4e2c53b5f6c")
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a9bc70eab6720b5c6f8503178e2c966b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/types.fasl"
     :FASL-MD5 "be0fd75d1d94020bc45f3703ff3734e3")
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "becf5c78049c85f2c05cd1ef54454032" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/package.fasl"
     :FASL-MD5 "2a49876705d1a6ca22f2f4625a6236c4")
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "4040905f4a64ba704a480d82e87ec748" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/read/core.fasl"
     :FASL-MD5 "0f186935cac262d817f6134121cfc5f7")
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/read/package.fasl"
     :FASL-MD5 "0ba6045c6dcbdf5027169f3b93cde3d3")
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9e0baf22c53329d393e047c669679645" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/read/task.fasl"
     :FASL-MD5 "3493dd76978277941aac3fd1c1b529e6")
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/read/types.fasl"
     :FASL-MD5 "071001eddec42b0ef163989eb4a9a6b5")
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-build.fasl"
     :FASL-MD5 "39b07191b53c69657b0404e3e24974e1")
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cbdc30f93109c474e1fc25066c9b9b13" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-package.fasl"
     :FASL-MD5 "c756fa5d37ed7ad9c5594d775042342a")
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f782d1137b8ce342b91c9999cfb7accc" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-query.fasl"
     :FASL-MD5 "c9aa10ff7cf3398bd0dcc3d7e3b04b81")
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "852149de4c289b8e067602780378d87a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-radix.fasl"
     :FASL-MD5 "43dd68a21f1339051100d6cc04b1b47f")
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b33e57a643f2fca810846f6226366253" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-sort.fasl"
     :FASL-MD5 "10200d268e758bae15ba34ff4f50542a")
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-types.fasl"
     :FASL-MD5 "ee45d51cd5ae03261d71c407b7d88e71")
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9bd6820c4feba3e552aab1a4edd87861" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-build.fasl"
     :FASL-MD5 "cf81ca7473efa5d8803d03068cdcab00")
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fcea263de1938767772e5b11411ecd5e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-query.fasl"
     :FASL-MD5 "10fdf7973673c5c3413f3d2e831def3a")
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "78c136d5838dcfe3019d9069643a8d8f" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-types.fasl"
     :FASL-MD5 "b09c78871a371c97d61841172bf91f50")
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bf65b1731eab6e0572461ef5cc60fc40" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-build.fasl"
     :FASL-MD5 "6b9fe849adb58559151d875837bafee6")
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "67975249aaabd751757cdfb9222cc3c4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-decode.fasl"
     :FASL-MD5 "cd40b2b6c146af32e824ab13226e757b")
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e0d2498db1011e857b7b0daa1934f187" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-fold.fasl"
     :FASL-MD5 "f991ce6510d33ce0189f2b83e361283e")
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "37ace42844c11b52446ee1fc500b8e0b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-package.fasl"
     :FASL-MD5 "af0cfd8588703fd513f4e72adcca4ef1")
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ebd7a54adea2213294a887e6d4db0927" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-query.fasl"
     :FASL-MD5 "4d42ab875e7b9c2a53c064cfb6d632ea")
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-types.fasl"
     :FASL-MD5 "5b3b65133fe97d8d9774af2e4b1da73e")
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/package.fasl"
     :FASL-MD5 "b1d89ccb71be35451f471f1756bdfc79")
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fcacd15460db25ea9cc4036065f9f096" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/scan.fasl"
     :FASL-MD5 "6d7aae930dec65711516349374a005f4")
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "32b2156739a6f2ca996abb91df0a2603" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/events.fasl"
     :FASL-MD5 "3d8c4ddf26ef2065c02b4a198fef33d5")
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b6026a8b7bb64b45c37a65effda70d8e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/io-events.fasl"
     :FASL-MD5 "029caea504f3a110c7a9255312f8aab4")
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "de1aca16a35d34d16aba12ff541c0d2b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/ownership.fasl"
     :FASL-MD5 "7ffa7b8bd63f73aeedd4d6521a16eb8c")
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "59e3c59c90d8d0fc5731b87496a785aa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/package.fasl"
     :FASL-MD5 "1081449c95d25576e8e41f4f053b84a2")
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/publication.fasl"
     :FASL-MD5 "606bcac63cfd1f59aa28613800a6ca39")
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cb0d91405325b508e6b2ab24d178de7a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/query.fasl"
     :FASL-MD5 "d30ce85d85088ef55c760b67bd280a6d")
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b8e04971b8ad75a1bd0c722997badfd2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/retirement.fasl"
     :FASL-MD5 "9db8cf7707d369d843d6cf69902745ca")
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d6924deff152b941bd49f0bb200b4197" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-build.fasl"
     :FASL-MD5 "186361beccbca1e94b0ec83df8b35784")
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e0f987d8767744050ec4d1b3ecb699ed" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-select.fasl"
     :FASL-MD5 "301f1f17d398aa058ee8e6549a64e871")
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ce649df47dd38888d5103c98345f7e41" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-types.fasl"
     :FASL-MD5 "f78efb658271f5788d02c72bd56bd936")
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ab19ec8d15af91511e817858c41cebc8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/types.fasl"
     :FASL-MD5 "8fed182069e079a280c55b9aa1ef7864")
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2340e0c9074f7b1bf80c74f774986bc5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-boundary.fasl"
     :FASL-MD5 "37e2573f1e5bac1ee6e58b009b830a4a")
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-package.fasl"
     :FASL-MD5 "1d3b8025cc009e3bb44b0730c4eeac29")
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-run.fasl"
     :FASL-MD5 "a670c89dea5c1fff2b666237112a456a")
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-types.fasl"
     :FASL-MD5 "5df7d4e324744540f068dfefc572dea0")
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1cda77a357ab2147035993b72d135a37" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/compaction-scan.fasl"
     :FASL-MD5 "7fdca8176434134bdd6c9e5a74e9c26a")
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cb64f806b8d69eb42d865b4abfff0b27" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/control-payload.fasl"
     :FASL-MD5 "879e72d7229ad32ddd1c0d3df8a4375e")
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "061147be459d8d3b08c661bd3f91d152" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/formats.fasl"
     :FASL-MD5 "85397514b05380cfd53f9a995bd13840")
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b53d27dcc9f4badf18b50519c50bc614" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/log-header.fasl"
     :FASL-MD5 "85396ed67ffb7f99ebae994e0d557fa1")
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f86bd104f20616a76b42c02227f72844" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/package.fasl"
     :FASL-MD5 "85ec8a80610fd47e8e49044b1fbc4401")
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/payload-record.fasl"
     :FASL-MD5 "4deea68fc28b458c99aab6cc603d3d8a")
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/payload-write.fasl"
     :FASL-MD5 "fc935fb86674f44f1dd7db37401c625e")
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/segment-header.fasl"
     :FASL-MD5 "478253c6723e73f648d98410184931e4")
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a229f76f7036f3573a6e528dcd390a19" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/builder.fasl"
     :FASL-MD5 "07b4def5d4d414a603164d78da914062")
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "42b990e3b254e6fb488c0ab91b6a6502" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/csn.fasl"
     :FASL-MD5 "9eedda7c0fc0869d577c68112096829b")
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c0340924c9130e14d0e8efedeec078f1" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/executor.fasl"
     :FASL-MD5 "a3b615294fdd265be14d70a4a8b3bf5c")
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "7a0e7c99ab70b4720cbb091156560f5e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/group.fasl"
     :FASL-MD5 "35fd2a7c66852e068b06265d1206cdec")
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "96c41b1d417135a24fc65659ea3abe11" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/package.fasl"
     :FASL-MD5 "2d4bc531bb4fa3e246be240698ed3df3")
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f799f27a8ac1a4c736c04796c1e543f9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/types.fasl"
     :FASL-MD5 "a4cc525771adc7e60b585ea2f2667344"))
   :COMPILED-SUITE
   ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     "758adad069aec2f9dbe0635797314ff6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/foundation/support.fasl"
     :FASL-MD5 "b6ca8836931158c5bed41752672b2174")
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     "3f868ebe4307ad4238b314c37eceed9a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/support.fasl"
     :FASL-MD5 "3535f847c69ed377e089d7202976695e")
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     "1137938073e71d6d8d62c751fbad05d5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/construction.fasl"
     :FASL-MD5 "0bda601ec36b6f81d6a4eaa3fbd8a835")
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     "d1ab36d05cc1266e4533d27c693f12f4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/read.fasl"
     :FASL-MD5 "d7f68d7a63df505da55547e058ac19b8")
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     "63dd01c852de1399c2c82274d481d257" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/threads.fasl"
     :FASL-MD5 "d2f8ff497b118b6cb1141e5bde386497"))
   :FAILED-TEST
   "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
   :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE "SIMPLE-ERROR"
   :DIAGNOSTIC "Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (PROGN
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-CALL-OPERATION
                        ARCDOCDB.GET.DIRECTORY.TESTS::OPERATION
                        ARCDOCDB.GET.DIRECTORY.TESTS::CONTEXT DIRECTORY)
                       (SETF ARCDOCDB.GET.DIRECTORY.TESTS::AUTHORIZED T))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVARIANT-VIOLATION (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :DIRECTORY-LOCATION-ABSENT)))"))
 :DETAIL NIL :RUNNER-MD5
 #A((32) BASE-CHAR . "dafc6cdbd71746f79369cd04151fb7d0") :TARGET-SOURCE-MD5
 #A((32) BASE-CHAR . "bd12d0077a79f0c9c2f0a4dd01731f43") :ARTIFACTS-VERIFIED T)
