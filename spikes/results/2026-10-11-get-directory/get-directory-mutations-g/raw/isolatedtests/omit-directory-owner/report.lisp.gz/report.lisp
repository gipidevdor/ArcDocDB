(:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
 "omit-directory-owner" :FILE "src/get-directory/build.lisp" :DIRECTORY
 #A((137) BASE-CHAR
    . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/")
 :EXPECTED-FAILURE :FOREIGN-DIRECTORY-ACCEPTED :SUBSTITUTION
 (:BEFORE "(unless (eq view (segmento-get-owner segment))" :AFTER
  "(unless (or (eq view (segmento-get-owner segment)) view)")
 :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
 ("TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER")
 :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . "b5e1e1260d8364e7eb1549db37153364"))
  (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
  (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
  (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
  (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
  (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
  (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
  (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
  (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
  (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
  (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
  (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c3f19ffb4aacfdfe502c5e8b12a234f2"))
  (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
  (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
  (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
  (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
  (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
  (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "200373402e6e082dd8c7afde305302bb"))
  (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
  (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
  (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
  (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
  (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
  (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
  (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
  (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
  (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
  (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
  (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
  (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
  (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
  (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
  (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
  (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
  (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
  (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
  (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
  (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
  (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
  (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
  (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
  (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
  (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
  (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
  (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
  (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
  (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
  (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
  (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "db58ed1c3877f2d6ea58932d3bc75e56"))
  (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
  (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119"))
  (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
  (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
  (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
  (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
  (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
  (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
  (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
  (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
  (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
  (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
  (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
  (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
  (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
  (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
  (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
  (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
  (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
  (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
  (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
  (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
  (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
  (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
  (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
  (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
  (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
  (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
  (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
  (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
  (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
  (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
  (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
  (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
  (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
  (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
  (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
  (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
  (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
  (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
  (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
  (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
  (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
  (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
  (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
  (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
  (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
  (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
  (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
  (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
  (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
  (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
  (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
  (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
  (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
  (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
  (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
  (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
  (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
  (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
  (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
  (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
  (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
  (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
  (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
  (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
  (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
  (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
  (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
  (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
  (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
  (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
  (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
  (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
  (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
  (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
  (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
  (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
  (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
  (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
  (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
  (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
  (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
  (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
  (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
  (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
  (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
  (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
  (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
  (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
  (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
  (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
  (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
  (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
  (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
  (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
  (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
  (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
  (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
  (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
  (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
  (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
  (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
  (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
  (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
  (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
  (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
  (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
  (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
  (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
  (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
  (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
  (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
  (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
  (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
  (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
  (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
  (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
  (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
 :COMPILED-TARGET
 (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
  "db58ed1c3877f2d6ea58932d3bc75e56" :FASL
  "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl"
  :FASL-MD5 "98b1ee25f2ed929e1eb124933d284801")
 :EXECUTION
 (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
  :ARGV
  ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
   "--script" "isolated-build.lisp")
  :STDOUT-LOG
  #A((147) BASE-CHAR
     . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/stdout.log")
  :STDERR-LOG
  #A((147) BASE-CHAR
     . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/stderr.log")
  :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 1622631/250000 :EXIT-CODE 1 :SIGNAL
  NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS :STATUS
   :FAILED :ROOT
   "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/"
   :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
     "b5e1e1260d8364e7eb1549db37153364")
    (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5d70197c8b64ad6f20c8be47a60c73ca")
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3546cf7f5c5ed138068548c20064f499")
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "72f3a33ce27ddf94c49c495580520004")
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a1f6a8e7aa4faed88e984b39871d1e53")
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "82f937b7b08bd1696ad9c88da2e1c60c")
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a25648d870eaa4f0b6e1e3b2cf76e28e")
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fc09021f74fb50aac57589614dae04d7")
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bc7a7b176e8cdd361b7c4306a1a4de4b")
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "6e8c6a49314c2f460aa6f8a1759200b6")
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ecd8fe950344059c629927b38fb6e4aa")
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c3f19ffb4aacfdfe502c5e8b12a234f2")
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f6488e987889432b375254021825dbe5")
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "706c0baa4158bf272c4b0df17c1439d2")
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "987e8ed576a21eb644ac1ef2e06edbda")
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cf1999ddb10f879aeefbeea853742d57")
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0c33aedcdb352e78a3c694cf796e6692")
    (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "200373402e6e082dd8c7afde305302bb")
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c33cdcc45f45218aa3e8bf26ce0ee575")
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b13e92b5f24a42fe283c17b649722b6a")
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "69e77bcd15b5413a815a65c5081229db")
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d885bd2a9860eb60aec1a775e5031d5e")
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0f67dd5c51bf6a63bc292ab4e2a280c2")
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1130012fc5613a5648d22ed8628be0e8")
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a1cdb5661fc54beba5bf00e4765f3235")
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "765d14c88cd288093a77a57930cd6999")
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "875201dfab0a84efd40fe9828cc293c8")
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "975b5f74e0c5a38ce978f4d9c7fcc6b8")
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "036dd02adf87d33c3ae2f40735c733fa")
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "653b974f310c09f6e2224a84acc43bbf")
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "82253491f995f5bc153fb5ebf30d564c")
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "6b85eebe69366e78ed5fc5cc20735f00")
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cb5710d6c111cadb7121a50998a747fa")
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8202843bddb817da4279ac959ae3f3c4")
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "38d26f8c749dd946dfc4b9c57103a892")
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a64d98c9ff429d6103d6e10ee1fd7980")
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2c1892002f0599bb8273093031017520")
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c24065d6c8d80d1be53994a0041743df")
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "babd0a78b4185af24ae1fef870c0fabb")
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "aa34ca6bc07535e35fea723878d99f66")
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0679ee07c46f69db330706303c70d8d2")
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "73019644090e2971f2b54dc36e4491f5")
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ca642ea47e4bff76f78f5b6d7287d6bd")
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a06115175f450776762761dce25acdb8")
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "942b596396c19815290a57830af2121b")
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "4db58e2f48bf77d751f1b83bb9f84b5c")
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5ee593a112958d94163dab17c5aa4ba2")
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "db58ed1c3877f2d6ea58932d3bc75e56")
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "4233eef9d87bdec712d4f690bcb699a9")
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "74a694385f1aaf03ec87721545494119")
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "17c957d6934a31f4ed64313e756de2d2")
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8d26428a4e17ad18990b8ee7d5f5b53a")
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "6d95f29b331d335175843f47ae44a6ea")
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f13d422adb6aa9e8489352884137f25a")
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3da469a7aa1e682dd8f2e516ee451de1")
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d6aaec49504a96f37c8ff1bc182c977b")
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bd7182e9871fe82530d0c828e473ccde")
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bbfb2082103e6712419e180ab972245c")
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cbfb17bf1f65698fb7c7889953d02d1e")
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1339edff0223dbf122f11ff0adbba61c")
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ca9002b81efd0aed9761cd1f78514762")
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "536e9dc4ed51072b8a6d1528d3ec18bf")
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2d869293ba47444c4721713d955c6254")
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9df13bcc6908e9fa601d173a671e1ccf")
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c5cc36884b238221cc13ca0c087ec7c2")
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e70bfeddd694336bbd088e65f8761834")
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "82258ec87aca513a508bc5dee8410dd6")
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c72633d15c3488699072eb610ebde7c8")
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "811869eb6a197d3c4e26af4322e52652")
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1b70dac05d6d2418909eb5105b808e81")
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c394e5684de5e2d938991c7cb348b93c")
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b5c51802e607e3dd22de68204baf64e9")
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bef497b9a267c7306d4100000491c814")
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "886b7c08b9929283e8968831cbe5c039")
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2d9060e41bc5252067d35e59ac70ee06")
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "65076c355c099b5dc73d185948d3bec4")
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "43d2209225707352daec6186ef95a805")
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "45ce41749bc6fa638539815d3f802b96")
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "598a9b65e73151c924b2cdcaf6d96705")
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a319691e3e28b7ea7b927de490cf69ba")
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ff2cfbb865290d7a1510fdf6877c7229")
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fa52433eae199ceeb874bf2bc47afca7")
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1dd67c527257e43f17e006644ecdbd00")
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d65cfce399b04f905bf969929962e59a")
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "699ce3f1615296fc27fcde3e0d63a4bc")
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3f317a0d3c5ee86a73651aad36135cc3")
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5155959766645d3172ae5e73c58cc071")
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a59eab6425a60fa2656f86bf87d5c9ac")
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e8e31e599356e592af29c0cc4604872b")
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5b22b90cfe8534086f6aff96d156713e")
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0417dd41cb3ec1d62dfd913c19f810ad")
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8befbbd00ed5c31c1487a11887eba495")
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1188e7a64a7a5d9482c1233cb9acb452")
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a450cac8071513365267e7024cbe94b0")
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "475dd7d5809a836f01544b447cc8df27")
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5157fd03ee806ee998ad8f0002d56268")
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3384cadf737c7d80c004222022a281f6")
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f0c8c579cd7db466d243ed3ea9f8e8aa")
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "716866194d6b9f076e102e84187229c0")
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "11c7103efbe733bbf0a13927f23c3d34")
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9500cfb800603de002d6d2b24f1bf056")
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c9380ad46a1d7acf41655aaed20db478")
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a5e7108e80664eb3b562fbd7e680801f")
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "db8497f9cff35b1ee261f1f410f46ca6")
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f188d1dbd5d0adb49f53acf09157aef9")
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8bb066aab61a18eff175b9edb11e42a2")
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0e9365e674d1584b111f915ce1f58634")
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ff98aea5cb9a7ae2671f6a887a003725")
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ae3ad96269b5e711a9dbb455f3c0ce48")
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2d5a795bcefd605c75da91c725ae83a2")
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "475517bd7ba04a1c37a82efeb8ff73d9")
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a9bc70eab6720b5c6f8503178e2c966b")
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "becf5c78049c85f2c05cd1ef54454032")
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "4040905f4a64ba704a480d82e87ec748")
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "7d74d9decc5a0bc9f9331d89bd503e21")
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9e0baf22c53329d393e047c669679645")
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9c37ff8237fcc9fe9ae4f44316e854e3")
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1a51ef4a488bb9fde2ff7d47bae01379")
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cbdc30f93109c474e1fc25066c9b9b13")
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f782d1137b8ce342b91c9999cfb7accc")
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "852149de4c289b8e067602780378d87a")
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b33e57a643f2fca810846f6226366253")
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f4433fd19ebc7239dbc2628c39f3ecdb")
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9bd6820c4feba3e552aab1a4edd87861")
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fcea263de1938767772e5b11411ecd5e")
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "78c136d5838dcfe3019d9069643a8d8f")
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bf65b1731eab6e0572461ef5cc60fc40")
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "67975249aaabd751757cdfb9222cc3c4")
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e0d2498db1011e857b7b0daa1934f187")
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "37ace42844c11b52446ee1fc500b8e0b")
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ebd7a54adea2213294a887e6d4db0927")
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "7b1d4054415faca7e5fca59ad83b4d4a")
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fcacd15460db25ea9cc4036065f9f096")
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "32b2156739a6f2ca996abb91df0a2603")
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b6026a8b7bb64b45c37a65effda70d8e")
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "de1aca16a35d34d16aba12ff541c0d2b")
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "59e3c59c90d8d0fc5731b87496a785aa")
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "056d2c6a67c9d9f2bf9fe2d2c348d53c")
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cb0d91405325b508e6b2ab24d178de7a")
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b8e04971b8ad75a1bd0c722997badfd2")
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d6924deff152b941bd49f0bb200b4197")
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e0f987d8767744050ec4d1b3ecb699ed")
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ce649df47dd38888d5103c98345f7e41")
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ab19ec8d15af91511e817858c41cebc8")
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2340e0c9074f7b1bf80c74f774986bc5")
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a93ce2e84e8aee647b5083ad1d2b899b")
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f0fee18adf357bad98e8a3c3e8c70c0c")
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2b23d468be0165fa009c5ebd5d1bbe23")
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1cda77a357ab2147035993b72d135a37")
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cb64f806b8d69eb42d865b4abfff0b27")
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "061147be459d8d3b08c661bd3f91d152")
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b53d27dcc9f4badf18b50519c50bc614")
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f86bd104f20616a76b42c02227f72844")
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8c03f9c01dcb30f2d3970a5694968ecf")
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d6812fa59bf8fd1252fbf85a9bfa3896")
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a229f76f7036f3573a6e528dcd390a19")
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "42b990e3b254e6fb488c0ab91b6a6502")
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c0340924c9130e14d0e8efedeec078f1")
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "7a0e7c99ab70b4720cbb091156560f5e")
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "96c41b1d417135a24fc65659ea3abe11")
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f799f27a8ac1a4c736c04796c1e543f9")
    (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     "758adad069aec2f9dbe0635797314ff6")
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     "3f868ebe4307ad4238b314c37eceed9a")
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     "1137938073e71d6d8d62c751fbad05d5")
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     "d1ab36d05cc1266e4533d27c693f12f4")
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     "63dd01c852de1399c2c82274d481d257"))
   :SUITE-FILES
   ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
    "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
    "tests/get-directory/threads.lisp")
   :REGISTERED-TESTS
   ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
    "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
    "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
    "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
    "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
    "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
    "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
    "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
    "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
    "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
    "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
    "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
    "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
    "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
    "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
    "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
    "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
    "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
    "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
    "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
    "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
    "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
    "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
    "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
    "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
    "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
    "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
    "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
    "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
   :SELECTED-TEST
   "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
   :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
   (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    "db58ed1c3877f2d6ea58932d3bc75e56" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl"
    :FASL-MD5 "98b1ee25f2ed929e1eb124933d284801")
   :COMPILED-PRODUCT
   ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/build.fasl"
     :FASL-MD5 "a46eb0512e34427d96eb900faf741568")
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3546cf7f5c5ed138068548c20064f499" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/clock.fasl"
     :FASL-MD5 "94438278583432e9a2e2448d8275deb7")
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "72f3a33ce27ddf94c49c495580520004" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/core.fasl"
     :FASL-MD5 "10ad9452d0467e930c0398f2dbbe4875")
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/package.fasl"
     :FASL-MD5 "2d91b12ab632b52d88333c27a5b4d5ce")
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/read.fasl"
     :FASL-MD5 "2d5f38cc7c7a158b7d442feb1fb761af")
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/types.fasl"
     :FASL-MD5 "cce242ae3a521ac0af73e2b3669dd7b9")
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fc09021f74fb50aac57589614dae04d7" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/write.fasl"
     :FASL-MD5 "c6808f1d01a2f2ad06cc77479fb1652c")
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-float-minimal.fasl"
     :FASL-MD5 "6b82254db4da9979869c639b6b8a3064")
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-header.fasl"
     :FASL-MD5 "b179d0a19016ed4048696c4710304184")
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ecd8fe950344059c629927b38fb6e4aa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-minimal.fasl"
     :FASL-MD5 "a3de22c7c6e65bf77018da240e12f488")
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-package.fasl"
     :FASL-MD5 "d31a08b7517d1921770afc5bc2f928b1")
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f6488e987889432b375254021825dbe5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-input.fasl"
     :FASL-MD5 "5b4dd81d7b95c6f71c13e2fa30c3f2b6")
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "706c0baa4158bf272c4b0df17c1439d2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-items.fasl"
     :FASL-MD5 "f5036c95c3b33d5e530e04b9da197af1")
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "987e8ed576a21eb644ac1ef2e06edbda" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-minimal.fasl"
     :FASL-MD5 "17780fb906a50dbb269fe001ed248654")
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cf1999ddb10f879aeefbeea853742d57" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-stack.fasl"
     :FASL-MD5 "943b6523f99af6c6df17cf4803bc6f28")
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0c33aedcdb352e78a3c694cf796e6692" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan.fasl"
     :FASL-MD5 "f2cf245c86c17a038e4ce2cdf34e5e35")
    (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "200373402e6e082dd8c7afde305302bb" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-simple-write.fasl"
     :FASL-MD5 "437a12135e24b92689c3f5a82cfb9bb6")
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-space.fasl"
     :FASL-MD5 "545107778fdd782beaaaac095897f55e")
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b13e92b5f24a42fe283c17b649722b6a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-string-write.fasl"
     :FASL-MD5 "fe05ccfa98e4130bf5f6af316249c1c7")
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "69e77bcd15b5413a815a65c5081229db" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-write.fasl"
     :FASL-MD5 "10cdc1163af54561a5eb05b28eafbf44")
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d885bd2a9860eb60aec1a775e5031d5e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/package.fasl"
     :FASL-MD5 "1cadbe58e27343c38a7cab48d552d3ff")
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/utf8.fasl"
     :FASL-MD5 "f6b1ee7ff4cf194295d13afad61b44ef")
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1130012fc5613a5648d22ed8628be0e8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/csn/package.fasl"
     :FASL-MD5 "65b0d87d46b8d61f61000935d8fe5576")
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a1cdb5661fc54beba5bf00e4765f3235" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/csn/registry.fasl"
     :FASL-MD5 "2bc5ac49660b958216f62b88a4a321c0")
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "765d14c88cd288093a77a57930cd6999" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/core.fasl"
     :FASL-MD5 "dca740c3c2b07273fbe25e7cce8a7d1d")
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "875201dfab0a84efd40fe9828cc293c8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/package.fasl"
     :FASL-MD5 "7b459d1099d26e57689823fe9efeebc5")
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/read.fasl"
     :FASL-MD5 "e75a692d3b0f8514422125a0ce8abab1")
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "036dd02adf87d33c3ae2f40735c733fa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/reclaim.fasl"
     :FASL-MD5 "afd4008b54a9cf502343bf6d43952007")
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "653b974f310c09f6e2224a84acc43bbf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/retire.fasl"
     :FASL-MD5 "a402a70bee5bc0f2e3bb1d206b25b3a9")
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "82253491f995f5bc153fb5ebf30d564c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/types.fasl"
     :FASL-MD5 "dde99f548c07c6d25a0da70e960c9eba")
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "6b85eebe69366e78ed5fc5cc20735f00" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/handoff.fasl"
     :FASL-MD5 "9fff751b1260a4b0a9f6b9b6f0f8bb54")
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cb5710d6c111cadb7121a50998a747fa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/package.fasl"
     :FASL-MD5 "b88e7f9ac7e18d08c430f254c168c4f5")
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8202843bddb817da4279ac959ae3f3c4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/queue.fasl"
     :FASL-MD5 "e71f2bb5ae163881ae50618457512a7a")
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "38d26f8c749dd946dfc4b9c57103a892" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready-recycle.fasl"
     :FASL-MD5 "fbe63a64d45621529995d98477e3aa4c")
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready-types.fasl"
     :FASL-MD5 "cc9d1fc1a28add04841f1ab46fd8d224")
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2c1892002f0599bb8273093031017520" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready.fasl"
     :FASL-MD5 "ca741bfcd91ed7edafdac2e2e2e54a53")
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c24065d6c8d80d1be53994a0041743df" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-boundary.fasl"
     :FASL-MD5 "8368d441f5fb8abff6fa9df949a6fb08")
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "babd0a78b4185af24ae1fef870c0fabb" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-claim.fasl"
     :FASL-MD5 "dd26a114b23fb9b25a5f6041dbcb061e")
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "aa34ca6bc07535e35fea723878d99f66" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-run.fasl"
     :FASL-MD5 "ca780ea252acd63e69d7d80e8e8f8946")
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0679ee07c46f69db330706303c70d8d2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-types.fasl"
     :FASL-MD5 "9bbb71a6cee1b8c21047024660c08038")
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "73019644090e2971f2b54dc36e4491f5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/writer.fasl"
     :FASL-MD5 "6185c6cffb21ab8ebb2863b2c4b2946a")
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/batch.fasl"
     :FASL-MD5 "4ff4e0e661c6528460b0ac30ba98a7fa")
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a06115175f450776762761dce25acdb8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/binary.fasl"
     :FASL-MD5 "ef5f120eef374f0c0c797dba595143c3")
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "942b596396c19815290a57830af2121b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/conditions.fasl"
     :FASL-MD5 "ab5ddb67c86e71c62a7758302887da9a")
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/crc32c.fasl"
     :FASL-MD5 "f001bfd9365d0145759e50790daafab1")
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5ee593a112958d94163dab17c5aa4ba2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/package.fasl"
     :FASL-MD5 "45c085bdb91fdf79bf0d34b49694fc11")
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/record.fasl"
     :FASL-MD5 "2681b5a9fa5cd9f92c619a39a3c45463")
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "db58ed1c3877f2d6ea58932d3bc75e56" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl"
     :FASL-MD5 "98b1ee25f2ed929e1eb124933d284801")
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "4233eef9d87bdec712d4f690bcb699a9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/package.fasl"
     :FASL-MD5 "af22d1bc38ea6029ad91f6d568276c3e")
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "74a694385f1aaf03ec87721545494119" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/read.fasl"
     :FASL-MD5 "3d9e9385fc14ca4387df41c79c3cbb44")
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "17c957d6934a31f4ed64313e756de2d2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/types.fasl"
     :FASL-MD5 "e88f5b897f4c3df7e2ccc943eef9b713")
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-build.fasl"
     :FASL-MD5 "96b4a1143a316c6b2078b1a2b5e23bcf")
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "6d95f29b331d335175843f47ae44a6ea" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-directory.fasl"
     :FASL-MD5 "9e6b380b809e70553a3532230d211118")
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f13d422adb6aa9e8489352884137f25a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-preflight.fasl"
     :FASL-MD5 "4281483199b879624ec34ba3a5476057")
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3da469a7aa1e682dd8f2e516ee451de1" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-read.fasl"
     :FASL-MD5 "7c176eef5dc63d5396e8e821c0705253")
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d6aaec49504a96f37c8ff1bc182c977b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-scan.fasl"
     :FASL-MD5 "7eabeaef345faa90ebf90947b64c52d9")
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bd7182e9871fe82530d0c828e473ccde" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-types.fasl"
     :FASL-MD5 "7cbbfc95a006e89db579fede7dd05224")
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bbfb2082103e6712419e180ab972245c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/build.fasl"
     :FASL-MD5 "d3a7b649e2d46f5a4dcf771ba0556d52")
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/package.fasl"
     :FASL-MD5 "c950a25ca3de782f8f22dfc9158c0c4e")
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1339edff0223dbf122f11ff0adbba61c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/read.fasl"
     :FASL-MD5 "c3ea4ed2987b79200881fc03bfb58ad0")
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ca9002b81efd0aed9761cd1f78514762" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/rows.fasl"
     :FASL-MD5 "18b3eb844530ac9fc4ca065aecce6b8d")
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/scan.fasl"
     :FASL-MD5 "c287690291ad1a217a43f8ea4b5a1efc")
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2d869293ba47444c4721713d955c6254" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/sort.fasl"
     :FASL-MD5 "07cdce2b2b0f8b1f58c8ebb310a006a6")
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9df13bcc6908e9fa601d173a671e1ccf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/types.fasl"
     :FASL-MD5 "5da04d8828701c49f3a85cc27c131a6b")
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c5cc36884b238221cc13ca0c087ec7c2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/build.fasl"
     :FASL-MD5 "d159286342acbffebb713cfd51a0eae9")
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e70bfeddd694336bbd088e65f8761834" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/lifecycle.fasl"
     :FASL-MD5 "8db03100c0257e38241b87749f6d9717")
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "82258ec87aca513a508bc5dee8410dd6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/lookup.fasl"
     :FASL-MD5 "edeffe0153cda13a112fc23373f63806")
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c72633d15c3488699072eb610ebde7c8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/package.fasl"
     :FASL-MD5 "a84679081523c1ebe65d46fb220f9d14")
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "811869eb6a197d3c4e26af4322e52652" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/segment.fasl"
     :FASL-MD5 "791740211e919ad7ac66ca404d420f04")
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1b70dac05d6d2418909eb5105b808e81" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/target.fasl"
     :FASL-MD5 "b866c1e76ce062463bf5218a839622ba")
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c394e5684de5e2d938991c7cb348b93c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/types.fasl"
     :FASL-MD5 "fb198a3d79587e9241d9e167af86baf7")
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b5c51802e607e3dd22de68204baf64e9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/hash/arithmetic.fasl"
     :FASL-MD5 "2c49fa5f0dfe624592ba0c0a6a129219")
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bef497b9a267c7306d4100000491c814" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/hash/blocks.fasl"
     :FASL-MD5 "1b23b6b7298e967d09ead03484723eae")
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "886b7c08b9929283e8968831cbe5c039" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/hash/hash64.fasl"
     :FASL-MD5 "669a2537398b418ac4e505eaddd30a0c")
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2d9060e41bc5252067d35e59ac70ee06" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/hash/package.fasl"
     :FASL-MD5 "9b64498249d2904e2de5f06a3f62719b")
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "65076c355c099b5dc73d185948d3bec4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/core.fasl"
     :FASL-MD5 "a47381778e14c05db34402233efeb349")
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "43d2209225707352daec6186ef95a805" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/hash-digests.fasl"
     :FASL-MD5 "879a85ddab901bfbcffdccf708482fed")
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "45ce41749bc6fa638539815d3f802b96" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/hash-seed.fasl"
     :FASL-MD5 "09f15d0af5456904c82518a8c9a8852a")
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "598a9b65e73151c924b2cdcaf6d96705" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/package.fasl"
     :FASL-MD5 "f1ea80f501127ffc19a588227179f07b")
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a319691e3e28b7ea7b927de490cf69ba" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-arena.fasl"
     :FASL-MD5 "3975b387cdc450c2c289e3fcd9137de8")
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ff2cfbb865290d7a1510fdf6877c7229" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-build.fasl"
     :FASL-MD5 "ff5a02973d67ff748bf091f851669174")
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fa52433eae199ceeb874bf2bc47afca7" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-core.fasl"
     :FASL-MD5 "fd6dc9048a529b42f0a99283b18ca2ab")
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1dd67c527257e43f17e006644ecdbd00" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-directory.fasl"
     :FASL-MD5 "4872d7d17f31829e0714c6ac379150f9")
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d65cfce399b04f905bf969929962e59a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-package.fasl"
     :FASL-MD5 "b0529e9281d9c22766b312548594a9f1")
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-probe.fasl"
     :FASL-MD5 "ad468028b7b335f754a89c09f8593b8c")
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3f317a0d3c5ee86a73651aad36135cc3" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-read.fasl"
     :FASL-MD5 "face36fbe90f41a1e18d83c40c14162b")
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5155959766645d3172ae5e73c58cc071" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-relocate.fasl"
     :FASL-MD5 "7e8ba32ddcdaf5c41c63595b8fe469d9")
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-types.fasl"
     :FASL-MD5 "6b6237d115a1ebf074181c6868eebd09")
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e8e31e599356e592af29c0cc4604872b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-write.fasl"
     :FASL-MD5 "08aa1188c4338534a4e7d9ba7467d3ee")
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5b22b90cfe8534086f6aff96d156713e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/read.fasl"
     :FASL-MD5 "a9c82c2f693fec4bda8e0c1a43c35dbc")
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-budget.fasl"
     :FASL-MD5 "5c400b1fc7d41d335b82fc1e9c4d978b")
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8befbbd00ed5c31c1487a11887eba495" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-copy.fasl"
     :FASL-MD5 "1695fdeae49657f25cbe5c832fdb9864")
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1188e7a64a7a5d9482c1233cb9acb452" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-scan.fasl"
     :FASL-MD5 "3de612a0363386e9c69339c91722f31b")
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a450cac8071513365267e7024cbe94b0" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild.fasl"
     :FASL-MD5 "6636206e8869615bda474fa5ffdb91f3")
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "475dd7d5809a836f01544b447cc8df27" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/relocate.fasl"
     :FASL-MD5 "f687db2117d66ce8027c9951fe32477c")
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "5157fd03ee806ee998ad8f0002d56268" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/types.fasl"
     :FASL-MD5 "cef9c3875afed939258fd8a4a1235d77")
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "3384cadf737c7d80c004222022a281f6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/validation.fasl"
     :FASL-MD5 "a4e8edf93ce35dfc8c4a88e1d27282f6")
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/write.fasl"
     :FASL-MD5 "b156bdd74fa4163b7f8ee5a677aa4cd9")
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "716866194d6b9f076e102e84187229c0" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/flush.fasl"
     :FASL-MD5 "d8bae15eafff2f26253ca9b5ee4480e9")
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "11c7103efbe733bbf0a13927f23c3d34" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/lifecycle.fasl"
     :FASL-MD5 "d85ac349a8f6074d3759437c619a8b59")
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9500cfb800603de002d6d2b24f1bf056" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/native.fasl"
     :FASL-MD5 "28ecf767f8fb7d07ff1db7602c909b78")
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c9380ad46a1d7acf41655aaed20db478" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/package.fasl"
     :FASL-MD5 "5392379c2bcd3a3dd80c82c9823d168d")
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a5e7108e80664eb3b562fbd7e680801f" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/transfer.fasl"
     :FASL-MD5 "3e23a71d3c562fe20abebbc0a15dc4b1")
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "db8497f9cff35b1ee261f1f410f46ca6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/types.fasl"
     :FASL-MD5 "5cba7c87122f972f57f3d9e0d8dcb7bb")
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f188d1dbd5d0adb49f53acf09157aef9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/package.fasl"
     :FASL-MD5 "95a71e0cc68dd454df034fe8101ecf45")
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8bb066aab61a18eff175b9edb11e42a2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-core.fasl"
     :FASL-MD5 "b9a6877d1df7fdff94322438af9a7158")
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "0e9365e674d1584b111f915ce1f58634" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-csn.fasl"
     :FASL-MD5 "7e611afc01d7d15e20c74ab9af6df128")
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ff98aea5cb9a7ae2671f6a887a003725" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-lifecycle.fasl"
     :FASL-MD5 "ce3ed58f1457b3536a8d39facb7f8e28")
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-read.fasl"
     :FASL-MD5 "a9ebed892d8df0e62e3962ebc027fca5")
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2d5a795bcefd605c75da91c725ae83a2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-register.fasl"
     :FASL-MD5 "e004caf96659b9562ba5b2c25fd341da")
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-types.fasl"
     :FASL-MD5 "6dd39a2d36b581c9293950aa10becfc3")
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a9bc70eab6720b5c6f8503178e2c966b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/types.fasl"
     :FASL-MD5 "feb0d0b8409af6ddcd004d9c3652e7dc")
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "becf5c78049c85f2c05cd1ef54454032" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/package.fasl"
     :FASL-MD5 "d023e5b1e69cbe7691002e74ca632319")
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "4040905f4a64ba704a480d82e87ec748" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/read/core.fasl"
     :FASL-MD5 "5b7b0f5d3748bd81ba92b865c1fa06ab")
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/read/package.fasl"
     :FASL-MD5 "ef46f7ad417e9142ba52ac9494f64cce")
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9e0baf22c53329d393e047c669679645" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/read/task.fasl"
     :FASL-MD5 "c43b294eddae9ea9095dce8c80cff44b")
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/read/types.fasl"
     :FASL-MD5 "d9fbb7c0e0d564d4d92984b48a849228")
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-build.fasl"
     :FASL-MD5 "3d5011ef2a52ae2d8ac4eb566e575ad3")
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cbdc30f93109c474e1fc25066c9b9b13" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-package.fasl"
     :FASL-MD5 "779f34c64ae07b58896c573e4dfbcdf4")
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f782d1137b8ce342b91c9999cfb7accc" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-query.fasl"
     :FASL-MD5 "bcd49d6c1b482ef65ffd32fdb39542fe")
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "852149de4c289b8e067602780378d87a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-radix.fasl"
     :FASL-MD5 "4c827639429b332529b93c2d44fd79f4")
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b33e57a643f2fca810846f6226366253" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-sort.fasl"
     :FASL-MD5 "133bd60c58b2c4296ba2ea705b603602")
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-types.fasl"
     :FASL-MD5 "b7f7dbc30263f5a107ba76b6f679ad49")
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "9bd6820c4feba3e552aab1a4edd87861" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-build.fasl"
     :FASL-MD5 "e36117b44447aa66aa213ca6aba50734")
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fcea263de1938767772e5b11411ecd5e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-query.fasl"
     :FASL-MD5 "a2a1b2aea8f729fa6f7a3ceb4b080c21")
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "78c136d5838dcfe3019d9069643a8d8f" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-types.fasl"
     :FASL-MD5 "a2d054ce03254124b23192f3f4407aef")
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "bf65b1731eab6e0572461ef5cc60fc40" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-build.fasl"
     :FASL-MD5 "49b4f3ed06229c22bb598fbec42e2d5a")
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "67975249aaabd751757cdfb9222cc3c4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-decode.fasl"
     :FASL-MD5 "4c1da374d7d82466eb6df19897891639")
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e0d2498db1011e857b7b0daa1934f187" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-fold.fasl"
     :FASL-MD5 "12d258f6c0572a17e8c4c671c64d61e1")
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "37ace42844c11b52446ee1fc500b8e0b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-package.fasl"
     :FASL-MD5 "90aa5c281a788143792ecbc36cd05e6f")
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ebd7a54adea2213294a887e6d4db0927" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-query.fasl"
     :FASL-MD5 "5706223e272467aab2e6d25d88e49a06")
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-types.fasl"
     :FASL-MD5 "f27ae049d3d0ab5a6ebdca2ea9a6cfeb")
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/package.fasl"
     :FASL-MD5 "a774f4eaef0dbb44bea2fb0f118d6ce0")
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "fcacd15460db25ea9cc4036065f9f096" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/scan.fasl"
     :FASL-MD5 "8e232cbc429feac53ffdcb4562d52c5d")
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "32b2156739a6f2ca996abb91df0a2603" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/events.fasl"
     :FASL-MD5 "a9b23a54d0552f71a0c627124a855782")
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b6026a8b7bb64b45c37a65effda70d8e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/io-events.fasl"
     :FASL-MD5 "34c997b9fc34680e87ae78ef444aca08")
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "de1aca16a35d34d16aba12ff541c0d2b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/ownership.fasl"
     :FASL-MD5 "87be9aa09170427efec2f91f23f50ac9")
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "59e3c59c90d8d0fc5731b87496a785aa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/package.fasl"
     :FASL-MD5 "0fb9caa52bb3aff4dd205cd37d893f16")
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/publication.fasl"
     :FASL-MD5 "12c7ea2f7ea03ca3636d018aec1f6fe2")
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cb0d91405325b508e6b2ab24d178de7a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/query.fasl"
     :FASL-MD5 "7925c97ba7283740c4f52b0c5a29b33a")
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b8e04971b8ad75a1bd0c722997badfd2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/retirement.fasl"
     :FASL-MD5 "3f2370a9cb4332d73ec726b4c2b42995")
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d6924deff152b941bd49f0bb200b4197" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-build.fasl"
     :FASL-MD5 "5778ec621451c3250a75fef973cffade")
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "e0f987d8767744050ec4d1b3ecb699ed" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-select.fasl"
     :FASL-MD5 "8d65dd623d44559c3462c368d5faf3cd")
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ce649df47dd38888d5103c98345f7e41" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-types.fasl"
     :FASL-MD5 "721d3a6624f41b65f009075d44db81cb")
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "ab19ec8d15af91511e817858c41cebc8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/types.fasl"
     :FASL-MD5 "9f4ecfbe9fe6bf635774a3bbde550036")
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2340e0c9074f7b1bf80c74f774986bc5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-boundary.fasl"
     :FASL-MD5 "257af64dd67fd3e1b2c892d01213ab03")
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-package.fasl"
     :FASL-MD5 "f263fc786d6553e9717eecb7534c6190")
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-run.fasl"
     :FASL-MD5 "9b3a9ba2c6ddac51de732354f14d922c")
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-types.fasl"
     :FASL-MD5 "aa17a8a541f9147f07a80c18e7dcbd42")
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "1cda77a357ab2147035993b72d135a37" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/compaction-scan.fasl"
     :FASL-MD5 "38a8f2dab98e9c2a95100e4c26c96dc1")
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "cb64f806b8d69eb42d865b4abfff0b27" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/control-payload.fasl"
     :FASL-MD5 "3644b8af966f6ca9ebae7488699b733c")
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "061147be459d8d3b08c661bd3f91d152" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/formats.fasl"
     :FASL-MD5 "8f8a26ab4fdd903205a099f9ad7b9363")
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "b53d27dcc9f4badf18b50519c50bc614" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/log-header.fasl"
     :FASL-MD5 "ac0687e4cc927883e8a8e2a6577c054d")
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f86bd104f20616a76b42c02227f72844" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/package.fasl"
     :FASL-MD5 "e8e4a888edc5195b6840091ac488cafb")
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/payload-record.fasl"
     :FASL-MD5 "4e26316d85cf66bcdba2c31e14fe0b3a")
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/payload-write.fasl"
     :FASL-MD5 "4b376e3f603b2884ee97d30e2c8d9fba")
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/segment-header.fasl"
     :FASL-MD5 "b1a2fa08a5c6c01bbe0602de69169a7c")
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "a229f76f7036f3573a6e528dcd390a19" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/builder.fasl"
     :FASL-MD5 "e3f7c287eefb65f3335d0a7ef0bcae8b")
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "42b990e3b254e6fb488c0ab91b6a6502" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/csn.fasl"
     :FASL-MD5 "24efb3955a20fafd764efbc25ff236c6")
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "c0340924c9130e14d0e8efedeec078f1" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/executor.fasl"
     :FASL-MD5 "c859ef436556ac3b6d76b002258c5d09")
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "7a0e7c99ab70b4720cbb091156560f5e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/group.fasl"
     :FASL-MD5 "deb7be7ed8350a14f231dbde1060b893")
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "96c41b1d417135a24fc65659ea3abe11" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/package.fasl"
     :FASL-MD5 "721f55db54b07b358ba2a056b450e3be")
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "f799f27a8ac1a4c736c04796c1e543f9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/types.fasl"
     :FASL-MD5 "fb88f3f3347c5aeabbfd29f86fadc035"))
   :COMPILED-SUITE
   ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     "758adad069aec2f9dbe0635797314ff6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/foundation/support.fasl"
     :FASL-MD5 "6ae3175b59923ba593012660a54c137d")
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     "3f868ebe4307ad4238b314c37eceed9a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/support.fasl"
     :FASL-MD5 "4c541cd1e5669f2c50af86914ac34aa8")
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     "1137938073e71d6d8d62c751fbad05d5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/construction.fasl"
     :FASL-MD5 "2cca0eb4d9c952dad3bf037113cc1e36")
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     "d1ab36d05cc1266e4533d27c693f12f4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/read.fasl"
     :FASL-MD5 "19023583ca4e35cf4c1c6b1cc9aafd2e")
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     "63dd01c852de1399c2c82274d481d257" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/threads.fasl"
     :FASL-MD5 "d8c8b23ba4015b5afe6b233384ce36cf"))
   :FAILED-TEST "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
   :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE "SIMPLE-ERROR"
   :DIAGNOSTIC "Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (ARCDOCDB.GET.DIRECTORY:CREA-DIRECTORY-GET-SERIE
                       ARCDOCDB.GET.DIRECTORY.TESTS::COPY
                       (ARCDOCDB.GET.DIRECTORY.TESTS:DIRECTORY-FIXTURE-MAPS
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVALID-ARGUMENT (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :DIRECTORY-SOURCE-OWNER)))"))
 :DETAIL NIL :RUNNER-MD5
 #A((32) BASE-CHAR . "379f516cebb2691c0c32e27ab184b161") :TARGET-SOURCE-MD5
 #A((32) BASE-CHAR . "db58ed1c3877f2d6ea58932d3bc75e56") :ARTIFACTS-VERIFIED T)
