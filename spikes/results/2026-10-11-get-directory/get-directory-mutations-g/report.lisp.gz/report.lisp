(:ELAPSED-SECONDS 38069043/1000000 :SOURCE-FINGERPRINTS-AFTER
 ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . "b5e1e1260d8364e7eb1549db37153364"))
  (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
  (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
  (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
  (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
  (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
  (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
  (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
  (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
  (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
  (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
  (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c3f19ffb4aacfdfe502c5e8b12a234f2"))
  (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
  (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
  (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
  (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
  (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
  (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "200373402e6e082dd8c7afde305302bb"))
  (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
  (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
  (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
  (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
  (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
  (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
  (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
  (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
  (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
  (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
  (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
  (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
  (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
  (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
  (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
  (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
  (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
  (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
  (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
  (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
  (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
  (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
  (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
  (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
  (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
  (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
  (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
  (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
  (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
  (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
  (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
  (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
  (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119"))
  (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
  (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
  (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
  (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
  (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
  (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
  (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
  (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
  (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
  (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
  (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
  (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
  (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
  (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
  (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
  (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
  (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
  (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
  (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
  (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
  (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
  (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
  (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
  (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
  (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
  (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
  (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
  (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
  (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
  (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
  (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
  (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
  (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
  (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
  (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
  (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
  (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
  (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
  (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
  (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
  (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
  (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
  (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
  (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
  (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
  (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
  (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
  (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
  (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
  (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
  (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
  (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
  (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
  (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
  (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
  (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
  (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
  (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
  (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
  (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
  (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
  (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
  (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
  (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
  (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
  (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
  (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
  (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
  (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
  (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
  (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
  (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
  (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
  (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
  (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
  (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
  (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
  (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
  (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
  (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
  (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
  (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
  (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
  (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
  (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
  (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
  (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
  (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
  (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
  (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
  (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
  (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
  (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
  (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
  (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
  (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
  (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
  (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
  (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
  (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
  (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
  (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
  (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
  (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
  (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
  (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
  (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
  (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
  (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
  (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
  (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
  (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
  (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
  (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
  (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
  (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
  (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257"))
  (:FILE "tools/get-directory-mutation.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fe7ec868b29f06eb5e968896d5b431dc")))
 :FROZEN-MANIFEST
 ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . "b5e1e1260d8364e7eb1549db37153364"))
  (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
  (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
  (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
  (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
  (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
  (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
  (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
  (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
  (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
  (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
  (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c3f19ffb4aacfdfe502c5e8b12a234f2"))
  (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
  (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
  (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
  (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
  (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
  (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "200373402e6e082dd8c7afde305302bb"))
  (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
  (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
  (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
  (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
  (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
  (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
  (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
  (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
  (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
  (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
  (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
  (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
  (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
  (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
  (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
  (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
  (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
  (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
  (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
  (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
  (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
  (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
  (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
  (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
  (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
  (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
  (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
  (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
  (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
  (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
  (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
  (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
  (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119"))
  (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
  (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
  (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
  (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
  (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
  (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
  (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
  (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
  (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
  (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
  (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
  (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
  (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
  (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
  (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
  (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
  (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
  (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
  (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
  (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
  (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
  (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
  (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
  (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
  (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
  (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
  (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
  (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
  (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
  (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
  (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
  (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
  (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
  (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
  (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
  (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
  (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
  (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
  (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
  (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
  (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
  (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
  (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
  (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
  (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
  (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
  (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
  (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
  (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
  (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
  (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
  (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
  (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
  (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
  (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
  (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
  (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
  (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
  (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
  (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
  (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
  (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
  (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
  (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
  (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
  (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
  (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
  (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
  (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
  (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
  (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
  (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
  (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
  (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
  (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
  (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
  (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
  (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
  (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
  (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
  (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
  (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
  (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
  (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
  (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
  (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
  (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
  (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
  (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
  (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
  (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
  (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
  (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
  (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
  (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
  (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
  (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
  (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
  (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
  (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
  (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
  (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
  (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
  (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
  (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
  (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
  (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
  (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
  (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
  (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
  (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
  (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
  (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
  (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
  (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
  (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
  (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
 :SOURCE-FINGERPRINTS-BEFORE
 ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
   #A((32) BASE-CHAR . "b5e1e1260d8364e7eb1549db37153364"))
  (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
  (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
  (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
  (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
  (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
  (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
  (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
  (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
  (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
  (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
  (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c3f19ffb4aacfdfe502c5e8b12a234f2"))
  (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
  (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
  (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
  (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
  (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
  (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "200373402e6e082dd8c7afde305302bb"))
  (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
  (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
  (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
  (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
  (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
  (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
  (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
  (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
  (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
  (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
  (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
  (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
  (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
  (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
  (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
  (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
  (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
  (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
  (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
  (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
  (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
  (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
  (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
  (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
  (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
  (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
  (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
  (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
  (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
  (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
  (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
  (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
  (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119"))
  (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
  (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
  (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
  (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
  (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
  (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
  (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
  (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
  (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
  (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
  (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
  (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
  (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
  (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
  (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
  (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
  (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
  (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
  (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
  (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
  (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
  (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
  (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
  (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
  (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
  (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
  (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
  (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
  (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
  (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
  (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
  (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
  (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
  (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
  (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
  (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
  (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
  (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
  (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
  (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
  (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
  (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
  (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
  (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
  (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
  (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
  (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
  (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
  (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
  (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
  (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
  (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
  (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
  (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
  (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
  (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
  (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
  (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
  (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
  (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
  (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
  (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
  (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
  (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
  (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
  (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
  (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
  (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
  (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
  (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
  (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
  (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
  (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
  (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
  (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
  (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
  (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
  (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
  (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
  (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
  (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
  (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
  (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
  (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
  (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
  (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
  (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
  (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
  (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
  (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
  (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
  (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
  (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
  (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
  (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
  (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
  (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
  (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
  (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
  (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
  (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
  (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
  (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
  (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
  (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
  (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
  (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
  (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
  (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
  (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
  (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
  (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
  (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
  (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
  (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
  (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
  (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
   #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257"))
  (:FILE "tools/get-directory-mutation.lisp" :ROLE :PRODUCT :SOURCE-MD5
   #A((32) BASE-CHAR . "fe7ec868b29f06eb5e968896d5b431dc")))
 :DIRECTORY
 #A((98) BASE-CHAR
    . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/")
 :SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATIONS :STATUS :OK :RECORDED-AT
 4000716387 :SBCL #A((5) BASE-CHAR . "2.6.9") :ARGV
 (#A((48) BASE-CHAR . "/opt/homebrew/Cellar/sbcl/2.6.9/libexec/bin/sbcl")
  #A((7) BASE-CHAR . "--check")
  #A((37) BASE-CHAR . "spikes/out/get-directory-mutations-g/"))
 :CHILD-DEADLINE-SECONDS 120 :CAMPAIGN-DEADLINE-SECONDS 900
 :CLEANUP-DEADLINE-SECONDS 2 :TARGETS
 ((:NAME "omit-directory-owner" :FILE "src/get-directory/build.lisp" :TEST
   "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER" :BEFORE
   "(unless (eq view (segmento-get-owner segment))" :AFTER
   "(unless (or (eq view (segmento-get-owner segment)) view)" :EXPECTED-FAILURE
   :FOREIGN-DIRECTORY-ACCEPTED)
  (:NAME "missing-location-first-map" :FILE "src/get-directory/read.lisp" :TEST
   "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP" :BEFORE
   "(when (= left right) (guasto-get context :directory-location-absent))"
   :AFTER "(when (= left right)
               (if (plusp (length maps))
                   (return-from cerca-mappa-directory-get
                     (the mappa-segmento-get (svref maps 0)))
                   (guasto-get context :directory-location-absent)))"
   :EXPECTED-FAILURE :MISSING-PUBLISHED-SEGMENT-AUTHORIZED)
  (:NAME "alias-input-maps" :FILE "src/get-directory/build.lisp" :TEST
   "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED" :BEFORE
   "(owned (copy-seq maps))" :AFTER "(owned maps)" :EXPECTED-FAILURE
   :CALLER-ARRAY-CHANGES-DIRECTORY)
  (:NAME "truncate-directory-id" :FILE "src/get-directory/read.lisp" :TEST
   "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID" :BEFORE
   "(ldb (byte 32 32) location)" :AFTER "(ldb (byte 31 32) location)"
   :EXPECTED-FAILURE :MAX-U32-LOCATION-REJECTED)
  (:NAME "bypass-closed-resolver" :FILE "src/get-directory/read.lisp" :TEST
   "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS" :BEFORE
   "(risolvi-candidato-get context (trova-mappa-directory-get context directory))"
   :AFTER "(let ((map (trova-mappa-directory-get context directory)))
    (values (mappa-segmento-get-segment map)
            (arcdocdb.get.resolver::mappa-segmento-get-end map) 0 nil))"
   :EXPECTED-FAILURE :CANDIDATE-SIZE-AND-RESERVED-HIGH-BITS-NOT-CHECKED :LIMIT
   :ONLY-DIRECTORY-RESOLVE-WRAPPER))
 :SELF-TEST
 (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-SELF-TEST :STATUS :OK
  :CLASSIFIER-CASES 39 :NO-PROCESSES T :NO-COMPILATION T
  :NO-PRODUCT-OR-SUITE-LOADED T :PARSER-POSITIVE-AND-NEGATIVE T
  :FIXTURE-AND-PRODUCT-COVERAGE-GUARDS T :COUNTER-COVERAGE T)
 :EXPECTED-SUITE
 ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
  "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
  "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
  "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
  "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
  "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
  "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
  "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
  "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
  "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
  "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
  "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
  "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
  "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
  "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
  "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
  "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
  "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
  "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
  "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
  "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
  "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
  "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
  "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
  "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
  "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
  "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
  "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
  "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
 :BASELINE
 (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME "baseline" :FILE
  "src/get-directory/read.lisp" :DIRECTORY
  #A((125) BASE-CHAR
     . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/")
  :EXPECTED-FAILURE NIL :SUBSTITUTION NIL :STATUS :OK :RESULT :BASELINE-PASSED
  :DIAGNOSTIC NIL :EXPECTED-TESTS
  ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
   "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
   "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
   "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
   "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
   "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
   "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
   "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
   "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
   "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
   "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
   "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
   "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
   "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
   "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
   "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
   "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
   "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
   "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
   "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
   "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
   "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
   "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
   "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
   "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
   "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
   "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
   "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
   "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
  :SOURCE-MANIFEST
  ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
    #A((32) BASE-CHAR . "b5e1e1260d8364e7eb1549db37153364"))
   (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
   (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
   (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
   (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
   (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
   (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
   (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
   (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
   (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
   (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
   (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c3f19ffb4aacfdfe502c5e8b12a234f2"))
   (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
   (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
   (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
   (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
   (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
   (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "200373402e6e082dd8c7afde305302bb"))
   (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
   (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
   (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
   (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
   (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
   (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
   (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
   (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
   (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
   (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
   (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
   (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
   (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
   (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
   (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
   (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
   (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
   (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
   (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
   (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
   (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
   (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
   (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
   (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
   (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
   (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
   (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
   (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
   (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
   (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
   (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
   (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
   (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119"))
   (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
   (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
   (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
   (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
   (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
   (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
   (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
   (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
   (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
   (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
   (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
   (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
   (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
   (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
   (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
   (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
   (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
   (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
   (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
   (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
   (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
   (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
   (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
   (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
   (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
   (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
   (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
   (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
   (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
   (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
   (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
   (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
   (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
   (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
   (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
   (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
   (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
   (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
   (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
   (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
   (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
   (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
   (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
   (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
   (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
   (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
   (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
   (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
   (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
   (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
   (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
   (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
   (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
   (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
   (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
   (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
   (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
   (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
   (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
   (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
   (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
   (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
   (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
   (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
   (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
   (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
   (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
   (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
   (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
   (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
   (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
   (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
   (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
   (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
   (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
   (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
   (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
   (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
   (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
   (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
   (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
   (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
   (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
   (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
   (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
   (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
   (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
   (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
   (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
   (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
   (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
   (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
   (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
   (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
   (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
   (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
   (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
   (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
   (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
   (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
   (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
   (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
   (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
   (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
   (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
   (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
   (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
   (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
   (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
   (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
   (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
   (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
   (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
    #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
   (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
   (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
   (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
   (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
   (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
    #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
  :COMPILED-TARGET
  (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "ac89f55ce12b5f522620c844ff0007f9")
  :EXECUTION
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
   :ARGV
   ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
    "--script" "isolated-build.lisp")
   :STDOUT-LOG
   #A((135) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/stdout.log")
   :STDERR-LOG
   #A((135) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/stderr.log")
   :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 744167/100000 :EXIT-CODE 0 :SIGNAL
   NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :COMPLETE
    :STATUS :OK :ROOT
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/"
    :SOURCE-MANIFEST
    ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
      "b5e1e1260d8364e7eb1549db37153364")
     (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5d70197c8b64ad6f20c8be47a60c73ca")
     (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3546cf7f5c5ed138068548c20064f499")
     (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "72f3a33ce27ddf94c49c495580520004")
     (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a1f6a8e7aa4faed88e984b39871d1e53")
     (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "82f937b7b08bd1696ad9c88da2e1c60c")
     (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a25648d870eaa4f0b6e1e3b2cf76e28e")
     (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fc09021f74fb50aac57589614dae04d7")
     (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bc7a7b176e8cdd361b7c4306a1a4de4b")
     (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "6e8c6a49314c2f460aa6f8a1759200b6")
     (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ecd8fe950344059c629927b38fb6e4aa")
     (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c3f19ffb4aacfdfe502c5e8b12a234f2")
     (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f6488e987889432b375254021825dbe5")
     (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "706c0baa4158bf272c4b0df17c1439d2")
     (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "987e8ed576a21eb644ac1ef2e06edbda")
     (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cf1999ddb10f879aeefbeea853742d57")
     (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0c33aedcdb352e78a3c694cf796e6692")
     (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "200373402e6e082dd8c7afde305302bb")
     (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c33cdcc45f45218aa3e8bf26ce0ee575")
     (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b13e92b5f24a42fe283c17b649722b6a")
     (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "69e77bcd15b5413a815a65c5081229db")
     (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d885bd2a9860eb60aec1a775e5031d5e")
     (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0f67dd5c51bf6a63bc292ab4e2a280c2")
     (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1130012fc5613a5648d22ed8628be0e8")
     (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a1cdb5661fc54beba5bf00e4765f3235")
     (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "765d14c88cd288093a77a57930cd6999")
     (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "875201dfab0a84efd40fe9828cc293c8")
     (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "975b5f74e0c5a38ce978f4d9c7fcc6b8")
     (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "036dd02adf87d33c3ae2f40735c733fa")
     (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "653b974f310c09f6e2224a84acc43bbf")
     (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "82253491f995f5bc153fb5ebf30d564c")
     (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "6b85eebe69366e78ed5fc5cc20735f00")
     (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cb5710d6c111cadb7121a50998a747fa")
     (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8202843bddb817da4279ac959ae3f3c4")
     (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "38d26f8c749dd946dfc4b9c57103a892")
     (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a64d98c9ff429d6103d6e10ee1fd7980")
     (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2c1892002f0599bb8273093031017520")
     (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c24065d6c8d80d1be53994a0041743df")
     (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "babd0a78b4185af24ae1fef870c0fabb")
     (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "aa34ca6bc07535e35fea723878d99f66")
     (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0679ee07c46f69db330706303c70d8d2")
     (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "73019644090e2971f2b54dc36e4491f5")
     (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ca642ea47e4bff76f78f5b6d7287d6bd")
     (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a06115175f450776762761dce25acdb8")
     (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "942b596396c19815290a57830af2121b")
     (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "4db58e2f48bf77d751f1b83bb9f84b5c")
     (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5ee593a112958d94163dab17c5aa4ba2")
     (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
     (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cde24b2bf5c5637d5501b95bed47df31")
     (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "4233eef9d87bdec712d4f690bcb699a9")
     (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "74a694385f1aaf03ec87721545494119")
     (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "17c957d6934a31f4ed64313e756de2d2")
     (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8d26428a4e17ad18990b8ee7d5f5b53a")
     (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "6d95f29b331d335175843f47ae44a6ea")
     (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f13d422adb6aa9e8489352884137f25a")
     (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3da469a7aa1e682dd8f2e516ee451de1")
     (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d6aaec49504a96f37c8ff1bc182c977b")
     (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bd7182e9871fe82530d0c828e473ccde")
     (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bbfb2082103e6712419e180ab972245c")
     (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cbfb17bf1f65698fb7c7889953d02d1e")
     (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1339edff0223dbf122f11ff0adbba61c")
     (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ca9002b81efd0aed9761cd1f78514762")
     (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "536e9dc4ed51072b8a6d1528d3ec18bf")
     (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2d869293ba47444c4721713d955c6254")
     (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9df13bcc6908e9fa601d173a671e1ccf")
     (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c5cc36884b238221cc13ca0c087ec7c2")
     (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e70bfeddd694336bbd088e65f8761834")
     (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "82258ec87aca513a508bc5dee8410dd6")
     (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c72633d15c3488699072eb610ebde7c8")
     (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "811869eb6a197d3c4e26af4322e52652")
     (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1b70dac05d6d2418909eb5105b808e81")
     (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c394e5684de5e2d938991c7cb348b93c")
     (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b5c51802e607e3dd22de68204baf64e9")
     (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bef497b9a267c7306d4100000491c814")
     (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "886b7c08b9929283e8968831cbe5c039")
     (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2d9060e41bc5252067d35e59ac70ee06")
     (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "65076c355c099b5dc73d185948d3bec4")
     (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "43d2209225707352daec6186ef95a805")
     (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "45ce41749bc6fa638539815d3f802b96")
     (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "598a9b65e73151c924b2cdcaf6d96705")
     (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a319691e3e28b7ea7b927de490cf69ba")
     (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ff2cfbb865290d7a1510fdf6877c7229")
     (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fa52433eae199ceeb874bf2bc47afca7")
     (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1dd67c527257e43f17e006644ecdbd00")
     (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d65cfce399b04f905bf969929962e59a")
     (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "699ce3f1615296fc27fcde3e0d63a4bc")
     (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3f317a0d3c5ee86a73651aad36135cc3")
     (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5155959766645d3172ae5e73c58cc071")
     (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a59eab6425a60fa2656f86bf87d5c9ac")
     (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e8e31e599356e592af29c0cc4604872b")
     (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5b22b90cfe8534086f6aff96d156713e")
     (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0417dd41cb3ec1d62dfd913c19f810ad")
     (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8befbbd00ed5c31c1487a11887eba495")
     (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1188e7a64a7a5d9482c1233cb9acb452")
     (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a450cac8071513365267e7024cbe94b0")
     (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "475dd7d5809a836f01544b447cc8df27")
     (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5157fd03ee806ee998ad8f0002d56268")
     (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3384cadf737c7d80c004222022a281f6")
     (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f0c8c579cd7db466d243ed3ea9f8e8aa")
     (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "716866194d6b9f076e102e84187229c0")
     (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "11c7103efbe733bbf0a13927f23c3d34")
     (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9500cfb800603de002d6d2b24f1bf056")
     (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c9380ad46a1d7acf41655aaed20db478")
     (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a5e7108e80664eb3b562fbd7e680801f")
     (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "db8497f9cff35b1ee261f1f410f46ca6")
     (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f188d1dbd5d0adb49f53acf09157aef9")
     (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8bb066aab61a18eff175b9edb11e42a2")
     (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0e9365e674d1584b111f915ce1f58634")
     (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ff98aea5cb9a7ae2671f6a887a003725")
     (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ae3ad96269b5e711a9dbb455f3c0ce48")
     (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2d5a795bcefd605c75da91c725ae83a2")
     (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "475517bd7ba04a1c37a82efeb8ff73d9")
     (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a9bc70eab6720b5c6f8503178e2c966b")
     (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "becf5c78049c85f2c05cd1ef54454032")
     (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "4040905f4a64ba704a480d82e87ec748")
     (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "7d74d9decc5a0bc9f9331d89bd503e21")
     (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9e0baf22c53329d393e047c669679645")
     (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9c37ff8237fcc9fe9ae4f44316e854e3")
     (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1a51ef4a488bb9fde2ff7d47bae01379")
     (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cbdc30f93109c474e1fc25066c9b9b13")
     (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f782d1137b8ce342b91c9999cfb7accc")
     (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "852149de4c289b8e067602780378d87a")
     (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b33e57a643f2fca810846f6226366253")
     (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f4433fd19ebc7239dbc2628c39f3ecdb")
     (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9bd6820c4feba3e552aab1a4edd87861")
     (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fcea263de1938767772e5b11411ecd5e")
     (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "78c136d5838dcfe3019d9069643a8d8f")
     (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bf65b1731eab6e0572461ef5cc60fc40")
     (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "67975249aaabd751757cdfb9222cc3c4")
     (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e0d2498db1011e857b7b0daa1934f187")
     (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "37ace42844c11b52446ee1fc500b8e0b")
     (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ebd7a54adea2213294a887e6d4db0927")
     (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "7b1d4054415faca7e5fca59ad83b4d4a")
     (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
     (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fcacd15460db25ea9cc4036065f9f096")
     (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "32b2156739a6f2ca996abb91df0a2603")
     (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b6026a8b7bb64b45c37a65effda70d8e")
     (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "de1aca16a35d34d16aba12ff541c0d2b")
     (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "59e3c59c90d8d0fc5731b87496a785aa")
     (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "056d2c6a67c9d9f2bf9fe2d2c348d53c")
     (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cb0d91405325b508e6b2ab24d178de7a")
     (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b8e04971b8ad75a1bd0c722997badfd2")
     (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d6924deff152b941bd49f0bb200b4197")
     (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e0f987d8767744050ec4d1b3ecb699ed")
     (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ce649df47dd38888d5103c98345f7e41")
     (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ab19ec8d15af91511e817858c41cebc8")
     (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2340e0c9074f7b1bf80c74f774986bc5")
     (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a93ce2e84e8aee647b5083ad1d2b899b")
     (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f0fee18adf357bad98e8a3c3e8c70c0c")
     (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2b23d468be0165fa009c5ebd5d1bbe23")
     (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1cda77a357ab2147035993b72d135a37")
     (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cb64f806b8d69eb42d865b4abfff0b27")
     (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "061147be459d8d3b08c661bd3f91d152")
     (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b53d27dcc9f4badf18b50519c50bc614")
     (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f86bd104f20616a76b42c02227f72844")
     (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8c03f9c01dcb30f2d3970a5694968ecf")
     (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
     (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d6812fa59bf8fd1252fbf85a9bfa3896")
     (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a229f76f7036f3573a6e528dcd390a19")
     (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "42b990e3b254e6fb488c0ab91b6a6502")
     (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c0340924c9130e14d0e8efedeec078f1")
     (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "7a0e7c99ab70b4720cbb091156560f5e")
     (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "96c41b1d417135a24fc65659ea3abe11")
     (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f799f27a8ac1a4c736c04796c1e543f9")
     (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
      "758adad069aec2f9dbe0635797314ff6")
     (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
      "3f868ebe4307ad4238b314c37eceed9a")
     (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
      "1137938073e71d6d8d62c751fbad05d5")
     (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
      "d1ab36d05cc1266e4533d27c693f12f4")
     (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
      "63dd01c852de1399c2c82274d481d257"))
    :SUITE-FILES
    ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
     "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
     "tests/get-directory/threads.lisp")
    :REGISTERED-TESTS
    ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
     "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
     "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
     "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
     "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
     "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
     "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
     "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
     "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
     "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
     "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
     "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
     "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
     "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
     "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
     "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
     "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
     "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
     "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
     "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
     "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
     "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
     "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
     "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
     "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
     "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
     "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
     "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
     "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
    :SELECTED-TEST NIL :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     "74a694385f1aaf03ec87721545494119" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl"
     :FASL-MD5 "ac89f55ce12b5f522620c844ff0007f9")
    :COMPILED-PRODUCT
    ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/build.fasl"
      :FASL-MD5 "bbd833102442ca4e82e972a7aa6053fc")
     (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3546cf7f5c5ed138068548c20064f499" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/clock.fasl"
      :FASL-MD5 "007969e000b0a88a07e3b37bae0cdba2")
     (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "72f3a33ce27ddf94c49c495580520004" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/core.fasl"
      :FASL-MD5 "d7db298ef5e838edf34f6a9edf1fa9c4")
     (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/package.fasl"
      :FASL-MD5 "3dddcc10eb7875bf1f7f4867f0c985d7")
     (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/read.fasl"
      :FASL-MD5 "df0e76486ed1891a460b86744924d1b5")
     (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/types.fasl"
      :FASL-MD5 "f59b79c3db9b697da2b9c5bcbc8c54ef")
     (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fc09021f74fb50aac57589614dae04d7" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/write.fasl"
      :FASL-MD5 "b986d213bc8acd3375b3e42facfb00f9")
     (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-float-minimal.fasl"
      :FASL-MD5 "2bb20ee3b6ace69a9dd0d8ef59771c79")
     (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-header.fasl"
      :FASL-MD5 "9add0df37e7855416c789741aaf33d48")
     (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ecd8fe950344059c629927b38fb6e4aa" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-minimal.fasl"
      :FASL-MD5 "b5250c05c4b25eaa2bf3cd9bde72476a")
     (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-package.fasl"
      :FASL-MD5 "3610a07c58a0b7907e05198cb32e8928")
     (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f6488e987889432b375254021825dbe5" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-input.fasl"
      :FASL-MD5 "152cdf6ae118eccb172eb402b210d5c3")
     (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "706c0baa4158bf272c4b0df17c1439d2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-items.fasl"
      :FASL-MD5 "e0ce89e4c6a6cf8c5b5a0f66cb32bcc4")
     (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "987e8ed576a21eb644ac1ef2e06edbda" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-minimal.fasl"
      :FASL-MD5 "54e030cc0c926edfb0e93006b2605090")
     (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cf1999ddb10f879aeefbeea853742d57" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-stack.fasl"
      :FASL-MD5 "ac7e1baac058aa7fc2e012008c2b53f6")
     (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0c33aedcdb352e78a3c694cf796e6692" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan.fasl"
      :FASL-MD5 "8669e36909c83066564df2fe6627855c")
     (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "200373402e6e082dd8c7afde305302bb" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-simple-write.fasl"
      :FASL-MD5 "c7cfbaa1a72ef7d425f44446381f78e6")
     (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-space.fasl"
      :FASL-MD5 "3111c65b34bc57e95493900b453f1a5e")
     (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b13e92b5f24a42fe283c17b649722b6a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-string-write.fasl"
      :FASL-MD5 "9c559a149257df6d50e62cbb02bc7e4c")
     (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "69e77bcd15b5413a815a65c5081229db" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-write.fasl"
      :FASL-MD5 "1c81a37f6afd0faa1fc04eb156dd0df9")
     (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d885bd2a9860eb60aec1a775e5031d5e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/package.fasl"
      :FASL-MD5 "a97c3a4d35caa50bca6d9544ce8743ce")
     (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/utf8.fasl"
      :FASL-MD5 "fa7eaafda5fdac2d93ef494ed6ecb832")
     (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1130012fc5613a5648d22ed8628be0e8" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/csn/package.fasl"
      :FASL-MD5 "4142843e3041292c259b1724166d5459")
     (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a1cdb5661fc54beba5bf00e4765f3235" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/csn/registry.fasl"
      :FASL-MD5 "99cc7490a6da92e51a8c9a74bb4ed880")
     (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "765d14c88cd288093a77a57930cd6999" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/core.fasl"
      :FASL-MD5 "fa3bfa1fb41da87f33b7ada2be662349")
     (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "875201dfab0a84efd40fe9828cc293c8" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/package.fasl"
      :FASL-MD5 "fe3313387253a617abe9bd2d70d9f48e")
     (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/read.fasl"
      :FASL-MD5 "03e54285332b4a30cdb474404e0b024d")
     (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "036dd02adf87d33c3ae2f40735c733fa" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/reclaim.fasl"
      :FASL-MD5 "80152638829ecb54a8e9fa62949d6663")
     (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "653b974f310c09f6e2224a84acc43bbf" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/retire.fasl"
      :FASL-MD5 "3b2a18d8ccbb2100b55fc597b89cdf44")
     (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "82253491f995f5bc153fb5ebf30d564c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/types.fasl"
      :FASL-MD5 "061b3814c11ac2a4b1340f7d8e876106")
     (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "6b85eebe69366e78ed5fc5cc20735f00" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/handoff.fasl"
      :FASL-MD5 "c7c88ac1ab88084434980ae8b22b4a5f")
     (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cb5710d6c111cadb7121a50998a747fa" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/package.fasl"
      :FASL-MD5 "3f9161b2f8dee3c393f6dc62a239959b")
     (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8202843bddb817da4279ac959ae3f3c4" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/queue.fasl"
      :FASL-MD5 "5ce72de093f48e8898a602dcfeb961ce")
     (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "38d26f8c749dd946dfc4b9c57103a892" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/ready-recycle.fasl"
      :FASL-MD5 "e5b499b9f823d900ee50fe7bb9b069ad")
     (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/ready-types.fasl"
      :FASL-MD5 "6411144a936b25795be2485d14fcc360")
     (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2c1892002f0599bb8273093031017520" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/ready.fasl"
      :FASL-MD5 "5fc796ec1a6e3f6fe015034c16d55ea8")
     (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c24065d6c8d80d1be53994a0041743df" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/worker-boundary.fasl"
      :FASL-MD5 "e4ec7d200fa9fe03ff3364d40144c73d")
     (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "babd0a78b4185af24ae1fef870c0fabb" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/worker-claim.fasl"
      :FASL-MD5 "efc91aaa680ca127ddc2227e26789627")
     (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "aa34ca6bc07535e35fea723878d99f66" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/worker-run.fasl"
      :FASL-MD5 "6a236c36f4211f1caf2dc9054d52b1f5")
     (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0679ee07c46f69db330706303c70d8d2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/worker-types.fasl"
      :FASL-MD5 "6d66883e0fe466914843704591661cc2")
     (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "73019644090e2971f2b54dc36e4491f5" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/writer.fasl"
      :FASL-MD5 "777a5ac286215c4a51c353ea48b2c6f0")
     (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/batch.fasl"
      :FASL-MD5 "7553386ee4024f2c3c00f21f8e1fc340")
     (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a06115175f450776762761dce25acdb8" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/binary.fasl"
      :FASL-MD5 "10ad7d7087282db7f2aa41f6bf71f10e")
     (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "942b596396c19815290a57830af2121b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/conditions.fasl"
      :FASL-MD5 "919e8b6dd095439b412bf2fc742d686a")
     (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/crc32c.fasl"
      :FASL-MD5 "e910f172c594136b50f5c604e597a847")
     (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5ee593a112958d94163dab17c5aa4ba2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/package.fasl"
      :FASL-MD5 "d3577a1c353a0797c2be2775912c96c8")
     (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/record.fasl"
      :FASL-MD5 "8f28339c4bbeda765e3364bfb0dc9a6d")
     (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cde24b2bf5c5637d5501b95bed47df31" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/build.fasl"
      :FASL-MD5 "19a46300b89ce4c0658873de45c42282")
     (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "4233eef9d87bdec712d4f690bcb699a9" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/package.fasl"
      :FASL-MD5 "d385bf02825483e5966d7b83e5c07988")
     (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "74a694385f1aaf03ec87721545494119" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl"
      :FASL-MD5 "ac89f55ce12b5f522620c844ff0007f9")
     (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "17c957d6934a31f4ed64313e756de2d2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/types.fasl"
      :FASL-MD5 "a3f7c0fd3cb208d747fd2190a9e8c427")
     (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-build.fasl"
      :FASL-MD5 "0a1a6c2e1803cf444a9e1abb260c79a6")
     (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "6d95f29b331d335175843f47ae44a6ea" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-directory.fasl"
      :FASL-MD5 "f70d66508f1db43f4a8ab9b680d26eeb")
     (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f13d422adb6aa9e8489352884137f25a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-preflight.fasl"
      :FASL-MD5 "2eee01d8495e7519825d005cd1385ffc")
     (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3da469a7aa1e682dd8f2e516ee451de1" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-read.fasl"
      :FASL-MD5 "0e9658c92ab0924cc86f2d9503603ac3")
     (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d6aaec49504a96f37c8ff1bc182c977b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-scan.fasl"
      :FASL-MD5 "5aa905c544adf5d9065a1f31e86be9fe")
     (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bd7182e9871fe82530d0c828e473ccde" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-types.fasl"
      :FASL-MD5 "5e097d0ecb1a2124e4c934f330f487d6")
     (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bbfb2082103e6712419e180ab972245c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/build.fasl"
      :FASL-MD5 "64406a5ace6c4c138421feaedc1c92e9")
     (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/package.fasl"
      :FASL-MD5 "a2b8f7ce2f2e7879aa3566a28ab4673b")
     (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1339edff0223dbf122f11ff0adbba61c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/read.fasl"
      :FASL-MD5 "d1d648b75c9b9c8df5d5656c5b0db71f")
     (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ca9002b81efd0aed9761cd1f78514762" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/rows.fasl"
      :FASL-MD5 "07607ddef3f11ea6ffcf52bfe09ca1aa")
     (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/scan.fasl"
      :FASL-MD5 "b0f92ef9aa79bf516736bb02cfb5fae2")
     (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2d869293ba47444c4721713d955c6254" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/sort.fasl"
      :FASL-MD5 "03b0d60e8036e293aceeea6eb6616920")
     (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9df13bcc6908e9fa601d173a671e1ccf" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/types.fasl"
      :FASL-MD5 "6169185b2104eb7a5ca310cb73c19bb3")
     (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c5cc36884b238221cc13ca0c087ec7c2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/build.fasl"
      :FASL-MD5 "614545f9bff6ef65513266c352f9d277")
     (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e70bfeddd694336bbd088e65f8761834" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/lifecycle.fasl"
      :FASL-MD5 "3364131aa3d9a9bc8e33f7349d4eb412")
     (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "82258ec87aca513a508bc5dee8410dd6" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/lookup.fasl"
      :FASL-MD5 "415dc2f056881eb7da662fcb3b36bd95")
     (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c72633d15c3488699072eb610ebde7c8" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/package.fasl"
      :FASL-MD5 "b480bd53a98a07aef1e9790eb027e74f")
     (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "811869eb6a197d3c4e26af4322e52652" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/segment.fasl"
      :FASL-MD5 "d1eb26a97078c20bd17aefb891babfde")
     (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1b70dac05d6d2418909eb5105b808e81" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/target.fasl"
      :FASL-MD5 "e459c7ad4045188e3388682ec9476d3b")
     (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c394e5684de5e2d938991c7cb348b93c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/get/types.fasl"
      :FASL-MD5 "8869cf33ab049e65a2a47845c12292fc")
     (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b5c51802e607e3dd22de68204baf64e9" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/hash/arithmetic.fasl"
      :FASL-MD5 "9927d280cd1f443dfc31a20107476a84")
     (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bef497b9a267c7306d4100000491c814" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/hash/blocks.fasl"
      :FASL-MD5 "6a12d1b65c6dc1ea53b5c3f3c5905170")
     (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "886b7c08b9929283e8968831cbe5c039" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/hash/hash64.fasl"
      :FASL-MD5 "85a3f40fca41017964b0c835fd087228")
     (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2d9060e41bc5252067d35e59ac70ee06" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/hash/package.fasl"
      :FASL-MD5 "d14c80dd77525969e8faa80cfdc56a70")
     (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "65076c355c099b5dc73d185948d3bec4" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/core.fasl"
      :FASL-MD5 "0cd4724c62fac042d865a1dafe6380c9")
     (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "43d2209225707352daec6186ef95a805" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/hash-digests.fasl"
      :FASL-MD5 "9ed63fc2bde881b9a42f0ae547861af2")
     (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "45ce41749bc6fa638539815d3f802b96" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/hash-seed.fasl"
      :FASL-MD5 "1a59b622785857910b0d01d6145a7f13")
     (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "598a9b65e73151c924b2cdcaf6d96705" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/package.fasl"
      :FASL-MD5 "cd8652ec9490fb2fbb797d50fe2b983b")
     (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a319691e3e28b7ea7b927de490cf69ba" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-arena.fasl"
      :FASL-MD5 "4adf5a8607476aae37088dd5566cb55c")
     (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ff2cfbb865290d7a1510fdf6877c7229" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-build.fasl"
      :FASL-MD5 "e255905a8d714c5867971a3bee0b1022")
     (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fa52433eae199ceeb874bf2bc47afca7" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-core.fasl"
      :FASL-MD5 "b4dc0978f6967794bf9cb38d15741ab0")
     (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1dd67c527257e43f17e006644ecdbd00" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-directory.fasl"
      :FASL-MD5 "8a035986cafc80ecb5f07f1c6f345ac6")
     (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d65cfce399b04f905bf969929962e59a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-package.fasl"
      :FASL-MD5 "4fdcf33fb345e1aea3eed0ed3d1fd980")
     (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-probe.fasl"
      :FASL-MD5 "daadf693b35bef1c9553bd96885086da")
     (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3f317a0d3c5ee86a73651aad36135cc3" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-read.fasl"
      :FASL-MD5 "501ebac287d069b87eef03ddd3f13247")
     (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5155959766645d3172ae5e73c58cc071" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-relocate.fasl"
      :FASL-MD5 "0bf8a29bfa9b5d4f24730b6227bc9a84")
     (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-types.fasl"
      :FASL-MD5 "b236652958d716e209da8c916d6022ff")
     (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e8e31e599356e592af29c0cc4604872b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-write.fasl"
      :FASL-MD5 "279e70eb91f0f6199e2161e655864350")
     (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5b22b90cfe8534086f6aff96d156713e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/read.fasl"
      :FASL-MD5 "ef8e4af0af244268c0b44dc540b6cc2e")
     (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/rebuild-budget.fasl"
      :FASL-MD5 "edae82f86e32816a8fd28287d5a923d7")
     (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8befbbd00ed5c31c1487a11887eba495" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/rebuild-copy.fasl"
      :FASL-MD5 "8298d877352056e8bf3c03eb62954523")
     (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1188e7a64a7a5d9482c1233cb9acb452" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/rebuild-scan.fasl"
      :FASL-MD5 "584ac889a9928e12d94ed4b6167b5d22")
     (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a450cac8071513365267e7024cbe94b0" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/rebuild.fasl"
      :FASL-MD5 "43a72659bb69405cf8eee496fd7f3a25")
     (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "475dd7d5809a836f01544b447cc8df27" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/relocate.fasl"
      :FASL-MD5 "1edbc74769fb0508fab2062cdf2e9426")
     (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "5157fd03ee806ee998ad8f0002d56268" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/types.fasl"
      :FASL-MD5 "0f61594dc09fc4586f85c6f57b50909a")
     (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "3384cadf737c7d80c004222022a281f6" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/validation.fasl"
      :FASL-MD5 "51021f30a670fcc3b5bb82c5ade445a8")
     (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/index/write.fasl"
      :FASL-MD5 "0b964dc0aa30fbd6c803091d1af6ca47")
     (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "716866194d6b9f076e102e84187229c0" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/io/flush.fasl"
      :FASL-MD5 "92b2fc6d6fd66f0bca16e4839606bf51")
     (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "11c7103efbe733bbf0a13927f23c3d34" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/io/lifecycle.fasl"
      :FASL-MD5 "5a80d8f73e5821d2ae6868e92a8de605")
     (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9500cfb800603de002d6d2b24f1bf056" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/io/native.fasl"
      :FASL-MD5 "bc1db7d4995f4d9bac4c2b9af3202a18")
     (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c9380ad46a1d7acf41655aaed20db478" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/io/package.fasl"
      :FASL-MD5 "106ee1c3edcbe7d2e9fcfb811d47355c")
     (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a5e7108e80664eb3b562fbd7e680801f" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/io/transfer.fasl"
      :FASL-MD5 "0a06a42a0544a4189c4efd360f6b6c51")
     (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "db8497f9cff35b1ee261f1f410f46ca6" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/io/types.fasl"
      :FASL-MD5 "8e00c6fe437c53ee76905d7af36b90ba")
     (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f188d1dbd5d0adb49f53acf09157aef9" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/package.fasl"
      :FASL-MD5 "ab5f950a0f0db125aef199ba1d143b87")
     (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8bb066aab61a18eff175b9edb11e42a2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-core.fasl"
      :FASL-MD5 "2795f698d6c42641975636c35eb589bf")
     (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "0e9365e674d1584b111f915ce1f58634" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-csn.fasl"
      :FASL-MD5 "730d3db84b014e20ee27b27a90e54296")
     (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ff98aea5cb9a7ae2671f6a887a003725" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-lifecycle.fasl"
      :FASL-MD5 "154ee04bebdab11da7ec61136fa86fb1")
     (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-read.fasl"
      :FASL-MD5 "8457d11177b42db24c4c6ca481bf1e4a")
     (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2d5a795bcefd605c75da91c725ae83a2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-register.fasl"
      :FASL-MD5 "4006db9e991ac27550253a72a48d60ac")
     (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-types.fasl"
      :FASL-MD5 "5d11dc1722a20b30b255d9e221b3dbc8")
     (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a9bc70eab6720b5c6f8503178e2c966b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/types.fasl"
      :FASL-MD5 "9b2af16a74cf0f074326eb0992c93020")
     (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "becf5c78049c85f2c05cd1ef54454032" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/package.fasl"
      :FASL-MD5 "d5b21fd6d986b5cc703b9e74e8596031")
     (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "4040905f4a64ba704a480d82e87ec748" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/read/core.fasl"
      :FASL-MD5 "aa1457123ec168985f7a8fd0887c9d29")
     (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/read/package.fasl"
      :FASL-MD5 "03ddd022cd5d84637183eb1da9161a64")
     (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9e0baf22c53329d393e047c669679645" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/read/task.fasl"
      :FASL-MD5 "0cecff86b52e81425f01701181263b28")
     (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/read/types.fasl"
      :FASL-MD5 "37311adc7f918f33a4490a661b38ff28")
     (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-build.fasl"
      :FASL-MD5 "cd1199bc5c960b9c7aa16e6b0ea3efaa")
     (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cbdc30f93109c474e1fc25066c9b9b13" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-package.fasl"
      :FASL-MD5 "bfa292582a3d817d5472f918c245afc3")
     (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f782d1137b8ce342b91c9999cfb7accc" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-query.fasl"
      :FASL-MD5 "ac05f4e6e6664ec79c739295c349bb46")
     (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "852149de4c289b8e067602780378d87a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-radix.fasl"
      :FASL-MD5 "2e6b48455f479b23a7cc5106619d6a17")
     (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b33e57a643f2fca810846f6226366253" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-sort.fasl"
      :FASL-MD5 "63cf64ffd222d37dbe7749cb4c2cd5d0")
     (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-types.fasl"
      :FASL-MD5 "f9d095a076972c54013bb38673f97fc5")
     (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "9bd6820c4feba3e552aab1a4edd87861" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/inventory-build.fasl"
      :FASL-MD5 "4d8b00891bc43cf1e1b5837b24e6fd83")
     (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fcea263de1938767772e5b11411ecd5e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/inventory-query.fasl"
      :FASL-MD5 "d189d68311fdd4a84691240e42ec4895")
     (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "78c136d5838dcfe3019d9069643a8d8f" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/inventory-types.fasl"
      :FASL-MD5 "74debeedd4eb1eec41f96dada54919af")
     (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bf65b1731eab6e0572461ef5cc60fc40" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-build.fasl"
      :FASL-MD5 "b1b8b60c2fa43b0f0351df55e4ebc6f2")
     (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "67975249aaabd751757cdfb9222cc3c4" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-decode.fasl"
      :FASL-MD5 "cd0e0a018bc9746c7b212021c84a8b9c")
     (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e0d2498db1011e857b7b0daa1934f187" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-fold.fasl"
      :FASL-MD5 "e9578dcba01aa49321ab6ca3d6dcb3f3")
     (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "37ace42844c11b52446ee1fc500b8e0b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-package.fasl"
      :FASL-MD5 "252c688ced885cf36f2aa0949ea544a9")
     (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ebd7a54adea2213294a887e6d4db0927" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-query.fasl"
      :FASL-MD5 "d0caf5832e64b7812a482f2ff9a9e8d7")
     (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-types.fasl"
      :FASL-MD5 "c57e84128c782898db9d0d2b9d6a5f52")
     (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/package.fasl"
      :FASL-MD5 "a94c2a0743134e88fdf7f8fa208156f0")
     (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "fcacd15460db25ea9cc4036065f9f096" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/scan.fasl"
      :FASL-MD5 "9d3090e6493f13e81f35fac706dc8a19")
     (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "32b2156739a6f2ca996abb91df0a2603" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/events.fasl"
      :FASL-MD5 "60283a044f163c15b885339e35bbe103")
     (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b6026a8b7bb64b45c37a65effda70d8e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/io-events.fasl"
      :FASL-MD5 "fe71b322a7cbe1e64aa091b416d1f9d8")
     (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "de1aca16a35d34d16aba12ff541c0d2b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/ownership.fasl"
      :FASL-MD5 "7a59c386a70cc892f0770b414da4e619")
     (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "59e3c59c90d8d0fc5731b87496a785aa" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/package.fasl"
      :FASL-MD5 "82a7835f42c342bf57081772b748c92e")
     (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/publication.fasl"
      :FASL-MD5 "036b8055f63905ec6063b057605c323f")
     (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cb0d91405325b508e6b2ab24d178de7a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/query.fasl"
      :FASL-MD5 "130f45bbf07445a57719a03f344281e2")
     (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b8e04971b8ad75a1bd0c722997badfd2" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/retirement.fasl"
      :FASL-MD5 "355af37289f6a90dfa6acb152f9381a8")
     (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d6924deff152b941bd49f0bb200b4197" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/routing-build.fasl"
      :FASL-MD5 "9d5d9544e4710985d4c540734fbc8438")
     (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "e0f987d8767744050ec4d1b3ecb699ed" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/routing-select.fasl"
      :FASL-MD5 "9c6f42643ebb772d0d2210ad5318912e")
     (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ce649df47dd38888d5103c98345f7e41" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/routing-types.fasl"
      :FASL-MD5 "8780e3c901224072467ed049a1e8fc67")
     (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "ab19ec8d15af91511e817858c41cebc8" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/types.fasl"
      :FASL-MD5 "61274dc37195aeb0e4cb759772620c2d")
     (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2340e0c9074f7b1bf80c74f774986bc5" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/worker-boundary.fasl"
      :FASL-MD5 "f832397be042ec2b8c9b4c35ac2d9dd7")
     (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/worker-package.fasl"
      :FASL-MD5 "c6ee734416a8d627a51ccd58c3afdcf0")
     (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/worker-run.fasl"
      :FASL-MD5 "ae50edf03c34e0caf8caa12c6dc5869e")
     (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/series/worker-types.fasl"
      :FASL-MD5 "cb70d470c766a0cb5af6535b14ba051c")
     (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "1cda77a357ab2147035993b72d135a37" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/compaction-scan.fasl"
      :FASL-MD5 "b609fca930e3f66b53e251d7e53ab40d")
     (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "cb64f806b8d69eb42d865b4abfff0b27" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/control-payload.fasl"
      :FASL-MD5 "ec25dcaa4840ee7ac8e7911dd913b33a")
     (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "061147be459d8d3b08c661bd3f91d152" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/formats.fasl"
      :FASL-MD5 "ab43f475185fc1f4d6d6edb66279c723")
     (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "b53d27dcc9f4badf18b50519c50bc614" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/log-header.fasl"
      :FASL-MD5 "b1dbb0f8b1860b0a1170310b7caf07fb")
     (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f86bd104f20616a76b42c02227f72844" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/package.fasl"
      :FASL-MD5 "0340ff56f1c9010bbb21ffb7f76f6ade")
     (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/payload-record.fasl"
      :FASL-MD5 "0240c1aa4e93fe8a4a553f791ce0c873")
     (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/payload-write.fasl"
      :FASL-MD5 "3ab931c250deab52546c0285e6dc194d")
     (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/segment-header.fasl"
      :FASL-MD5 "cffbd5254a9f2b594f0a9886b03e7777")
     (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "a229f76f7036f3573a6e528dcd390a19" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/builder.fasl"
      :FASL-MD5 "3ada27c8ebd5a47ce9e0d955333bd86a")
     (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "42b990e3b254e6fb488c0ab91b6a6502" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/csn.fasl"
      :FASL-MD5 "e5b35e04d79a5eee8dd93afc0671eac4")
     (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "c0340924c9130e14d0e8efedeec078f1" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/executor.fasl"
      :FASL-MD5 "2eb9fe096b305ef749618182e2a11cb6")
     (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "7a0e7c99ab70b4720cbb091156560f5e" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/group.fasl"
      :FASL-MD5 "943cf6f850bb3c58f67abbdc3e2acdd3")
     (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "96c41b1d417135a24fc65659ea3abe11" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/package.fasl"
      :FASL-MD5 "a499f0e60c86ebd2870b4e868124de75")
     (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "f799f27a8ac1a4c736c04796c1e543f9" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/types.fasl"
      :FASL-MD5 "a8cbe334cc19468a0b3caa37f4f6c01f"))
    :COMPILED-SUITE
    ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
      "758adad069aec2f9dbe0635797314ff6" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/tests/foundation/support.fasl"
      :FASL-MD5 "804cf3fb444171d50e2b72a78450dcb1")
     (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
      "3f868ebe4307ad4238b314c37eceed9a" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/support.fasl"
      :FASL-MD5 "2c0562ac23a6122dd5b5c89abbf3399c")
     (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
      "1137938073e71d6d8d62c751fbad05d5" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/construction.fasl"
      :FASL-MD5 "b3ece450ad1bcec53000b9ad61362680")
     (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
      "d1ab36d05cc1266e4533d27c693f12f4" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/read.fasl"
      :FASL-MD5 "7c487bd512131f97514450cda50e4355")
     (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
      "63dd01c852de1399c2c82274d481d257" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/threads.fasl"
      :FASL-MD5 "5f76d2297b116aac8a02952dd0e07ff3"))
    :FAILED-TEST NIL :PASSED-TESTS
    ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
     "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
     "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
     "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
     "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
     "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
     "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
     "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
     "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
     "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
     "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
     "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
     "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
     "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
     "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
     "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
     "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
     "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
     "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
     "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
     "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
     "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
     "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
     "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
     "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
     "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
     "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
     "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
     "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
    :FAILURE-KIND NIL :CONDITION-TYPE NIL :DIAGNOSTIC NIL))
  :DETAIL NIL :RUNNER-MD5
  #A((32) BASE-CHAR . "91fc95b39dc283bbfd03f087486bc903") :TARGET-SOURCE-MD5
  #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119") :ARTIFACTS-VERIFIED
  T)
 :MUTANTS
 ((:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   "omit-directory-owner" :FILE "src/get-directory/build.lisp" :DIRECTORY
   #A((137) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/")
   :EXPECTED-FAILURE :FOREIGN-DIRECTORY-ACCEPTED :SUBSTITUTION
   (:BEFORE "(unless (eq view (segmento-get-owner segment))" :AFTER
    "(unless (or (eq view (segmento-get-owner segment)) view)")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   ("TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER")
   :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . "b5e1e1260d8364e7eb1549db37153364"))
    (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3f19ffb4aacfdfe502c5e8b12a234f2"))
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
    (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "200373402e6e082dd8c7afde305302bb"))
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "db58ed1c3877f2d6ea58932d3bc75e56"))
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119"))
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
    (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
   :COMPILED-TARGET
   (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    "db58ed1c3877f2d6ea58932d3bc75e56" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl"
    :FASL-MD5 "98b1ee25f2ed929e1eb124933d284801")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
     "--script" "isolated-build.lisp")
    :STDOUT-LOG
    #A((147) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/stdout.log")
    :STDERR-LOG
    #A((147) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/stderr.log")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 1622631/250000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/"
     :SOURCE-MANIFEST
     ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
       "b5e1e1260d8364e7eb1549db37153364")
      (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3f19ffb4aacfdfe502c5e8b12a234f2")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692")
      (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "200373402e6e082dd8c7afde305302bb")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db58ed1c3877f2d6ea58932d3bc75e56")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "74a694385f1aaf03ec87721545494119")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9")
      (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257"))
     :SUITE-FILES
     ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
      "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
      "tests/get-directory/threads.lisp")
     :REGISTERED-TESTS
     ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
      "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
      "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
      "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
      "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
      "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
      "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
      "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
      "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
      "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
      "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
      "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
      "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
      "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
      "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
      "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
      "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
      "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
      "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
      "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
      "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
      "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
      "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
      "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
      "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
      "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
     :SELECTED-TEST
     "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "db58ed1c3877f2d6ea58932d3bc75e56" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl"
      :FASL-MD5 "98b1ee25f2ed929e1eb124933d284801")
     :COMPILED-PRODUCT
     ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/build.fasl"
       :FASL-MD5 "a46eb0512e34427d96eb900faf741568")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/clock.fasl"
       :FASL-MD5 "94438278583432e9a2e2448d8275deb7")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/core.fasl"
       :FASL-MD5 "10ad9452d0467e930c0398f2dbbe4875")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/package.fasl"
       :FASL-MD5 "2d91b12ab632b52d88333c27a5b4d5ce")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/read.fasl"
       :FASL-MD5 "2d5f38cc7c7a158b7d442feb1fb761af")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/types.fasl"
       :FASL-MD5 "cce242ae3a521ac0af73e2b3669dd7b9")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/cache/write.fasl"
       :FASL-MD5 "c6808f1d01a2f2ad06cc77479fb1652c")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-float-minimal.fasl"
       :FASL-MD5 "6b82254db4da9979869c639b6b8a3064")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-header.fasl"
       :FASL-MD5 "b179d0a19016ed4048696c4710304184")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-minimal.fasl"
       :FASL-MD5 "a3de22c7c6e65bf77018da240e12f488")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-package.fasl"
       :FASL-MD5 "d31a08b7517d1921770afc5bc2f928b1")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-input.fasl"
       :FASL-MD5 "5b4dd81d7b95c6f71c13e2fa30c3f2b6")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-items.fasl"
       :FASL-MD5 "f5036c95c3b33d5e530e04b9da197af1")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-minimal.fasl"
       :FASL-MD5 "17780fb906a50dbb269fe001ed248654")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan-stack.fasl"
       :FASL-MD5 "943b6523f99af6c6df17cf4803bc6f28")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-scan.fasl"
       :FASL-MD5 "f2cf245c86c17a038e4ce2cdf34e5e35")
      (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "200373402e6e082dd8c7afde305302bb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-simple-write.fasl"
       :FASL-MD5 "437a12135e24b92689c3f5a82cfb9bb6")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-space.fasl"
       :FASL-MD5 "545107778fdd782beaaaac095897f55e")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-string-write.fasl"
       :FASL-MD5 "fe05ccfa98e4130bf5f6af316249c1c7")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/cbor-write.fasl"
       :FASL-MD5 "10cdc1163af54561a5eb05b28eafbf44")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/package.fasl"
       :FASL-MD5 "1cadbe58e27343c38a7cab48d552d3ff")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/codec/utf8.fasl"
       :FASL-MD5 "f6b1ee7ff4cf194295d13afad61b44ef")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/csn/package.fasl"
       :FASL-MD5 "65b0d87d46b8d61f61000935d8fe5576")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/csn/registry.fasl"
       :FASL-MD5 "2bc5ac49660b958216f62b88a4a321c0")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/core.fasl"
       :FASL-MD5 "dca740c3c2b07273fbe25e7cce8a7d1d")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/package.fasl"
       :FASL-MD5 "7b459d1099d26e57689823fe9efeebc5")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/read.fasl"
       :FASL-MD5 "e75a692d3b0f8514422125a0ce8abab1")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/reclaim.fasl"
       :FASL-MD5 "afd4008b54a9cf502343bf6d43952007")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/retire.fasl"
       :FASL-MD5 "a402a70bee5bc0f2e3bb1d206b25b3a9")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/epochs/types.fasl"
       :FASL-MD5 "dde99f548c07c6d25a0da70e960c9eba")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/handoff.fasl"
       :FASL-MD5 "9fff751b1260a4b0a9f6b9b6f0f8bb54")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/package.fasl"
       :FASL-MD5 "b88e7f9ac7e18d08c430f254c168c4f5")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/queue.fasl"
       :FASL-MD5 "e71f2bb5ae163881ae50618457512a7a")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready-recycle.fasl"
       :FASL-MD5 "fbe63a64d45621529995d98477e3aa4c")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready-types.fasl"
       :FASL-MD5 "cc9d1fc1a28add04841f1ab46fd8d224")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/ready.fasl"
       :FASL-MD5 "ca741bfcd91ed7edafdac2e2e2e54a53")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-boundary.fasl"
       :FASL-MD5 "8368d441f5fb8abff6fa9df949a6fb08")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-claim.fasl"
       :FASL-MD5 "dd26a114b23fb9b25a5f6041dbcb061e")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-run.fasl"
       :FASL-MD5 "ca780ea252acd63e69d7d80e8e8f8946")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/worker-types.fasl"
       :FASL-MD5 "9bbb71a6cee1b8c21047024660c08038")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/execution/writer.fasl"
       :FASL-MD5 "6185c6cffb21ab8ebb2863b2c4b2946a")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/batch.fasl"
       :FASL-MD5 "4ff4e0e661c6528460b0ac30ba98a7fa")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/binary.fasl"
       :FASL-MD5 "ef5f120eef374f0c0c797dba595143c3")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/conditions.fasl"
       :FASL-MD5 "ab5ddb67c86e71c62a7758302887da9a")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/crc32c.fasl"
       :FASL-MD5 "f001bfd9365d0145759e50790daafab1")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/package.fasl"
       :FASL-MD5 "45c085bdb91fdf79bf0d34b49694fc11")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/foundation/record.fasl"
       :FASL-MD5 "2681b5a9fa5cd9f92c619a39a3c45463")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db58ed1c3877f2d6ea58932d3bc75e56" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/build.fasl"
       :FASL-MD5 "98b1ee25f2ed929e1eb124933d284801")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/package.fasl"
       :FASL-MD5 "af22d1bc38ea6029ad91f6d568276c3e")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "74a694385f1aaf03ec87721545494119" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/read.fasl"
       :FASL-MD5 "3d9e9385fc14ca4387df41c79c3cbb44")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-directory/types.fasl"
       :FASL-MD5 "e88f5b897f4c3df7e2ccc943eef9b713")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-build.fasl"
       :FASL-MD5 "96b4a1143a316c6b2078b1a2b5e23bcf")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-directory.fasl"
       :FASL-MD5 "9e6b380b809e70553a3532230d211118")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-preflight.fasl"
       :FASL-MD5 "4281483199b879624ec34ba3a5476057")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-read.fasl"
       :FASL-MD5 "7c176eef5dc63d5396e8e821c0705253")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-scan.fasl"
       :FASL-MD5 "7eabeaef345faa90ebf90947b64c52d9")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/active-types.fasl"
       :FASL-MD5 "7cbbfc95a006e89db579fede7dd05224")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/build.fasl"
       :FASL-MD5 "d3a7b649e2d46f5a4dcf771ba0556d52")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/package.fasl"
       :FASL-MD5 "c950a25ca3de782f8f22dfc9158c0c4e")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/read.fasl"
       :FASL-MD5 "c3ea4ed2987b79200881fc03bfb58ad0")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/rows.fasl"
       :FASL-MD5 "18b3eb844530ac9fc4ca065aecce6b8d")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/scan.fasl"
       :FASL-MD5 "c287690291ad1a217a43f8ea4b5a1efc")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/sort.fasl"
       :FASL-MD5 "07cdce2b2b0f8b1f58c8ebb310a006a6")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get-resolver/types.fasl"
       :FASL-MD5 "5da04d8828701c49f3a85cc27c131a6b")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/build.fasl"
       :FASL-MD5 "d159286342acbffebb713cfd51a0eae9")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/lifecycle.fasl"
       :FASL-MD5 "8db03100c0257e38241b87749f6d9717")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/lookup.fasl"
       :FASL-MD5 "edeffe0153cda13a112fc23373f63806")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/package.fasl"
       :FASL-MD5 "a84679081523c1ebe65d46fb220f9d14")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/segment.fasl"
       :FASL-MD5 "791740211e919ad7ac66ca404d420f04")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/target.fasl"
       :FASL-MD5 "b866c1e76ce062463bf5218a839622ba")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/get/types.fasl"
       :FASL-MD5 "fb198a3d79587e9241d9e167af86baf7")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/hash/arithmetic.fasl"
       :FASL-MD5 "2c49fa5f0dfe624592ba0c0a6a129219")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/hash/blocks.fasl"
       :FASL-MD5 "1b23b6b7298e967d09ead03484723eae")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/hash/hash64.fasl"
       :FASL-MD5 "669a2537398b418ac4e505eaddd30a0c")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/hash/package.fasl"
       :FASL-MD5 "9b64498249d2904e2de5f06a3f62719b")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/core.fasl"
       :FASL-MD5 "a47381778e14c05db34402233efeb349")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/hash-digests.fasl"
       :FASL-MD5 "879a85ddab901bfbcffdccf708482fed")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/hash-seed.fasl"
       :FASL-MD5 "09f15d0af5456904c82518a8c9a8852a")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/package.fasl"
       :FASL-MD5 "f1ea80f501127ffc19a588227179f07b")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-arena.fasl"
       :FASL-MD5 "3975b387cdc450c2c289e3fcd9137de8")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-build.fasl"
       :FASL-MD5 "ff5a02973d67ff748bf091f851669174")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-core.fasl"
       :FASL-MD5 "fd6dc9048a529b42f0a99283b18ca2ab")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-directory.fasl"
       :FASL-MD5 "4872d7d17f31829e0714c6ac379150f9")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-package.fasl"
       :FASL-MD5 "b0529e9281d9c22766b312548594a9f1")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-probe.fasl"
       :FASL-MD5 "ad468028b7b335f754a89c09f8593b8c")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-read.fasl"
       :FASL-MD5 "face36fbe90f41a1e18d83c40c14162b")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-relocate.fasl"
       :FASL-MD5 "7e8ba32ddcdaf5c41c63595b8fe469d9")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-types.fasl"
       :FASL-MD5 "6b6237d115a1ebf074181c6868eebd09")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/primary-write.fasl"
       :FASL-MD5 "08aa1188c4338534a4e7d9ba7467d3ee")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/read.fasl"
       :FASL-MD5 "a9c82c2f693fec4bda8e0c1a43c35dbc")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-budget.fasl"
       :FASL-MD5 "5c400b1fc7d41d335b82fc1e9c4d978b")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-copy.fasl"
       :FASL-MD5 "1695fdeae49657f25cbe5c832fdb9864")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild-scan.fasl"
       :FASL-MD5 "3de612a0363386e9c69339c91722f31b")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/rebuild.fasl"
       :FASL-MD5 "6636206e8869615bda474fa5ffdb91f3")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/relocate.fasl"
       :FASL-MD5 "f687db2117d66ce8027c9951fe32477c")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/types.fasl"
       :FASL-MD5 "cef9c3875afed939258fd8a4a1235d77")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/validation.fasl"
       :FASL-MD5 "a4e8edf93ce35dfc8c4a88e1d27282f6")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/index/write.fasl"
       :FASL-MD5 "b156bdd74fa4163b7f8ee5a677aa4cd9")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/flush.fasl"
       :FASL-MD5 "d8bae15eafff2f26253ca9b5ee4480e9")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/lifecycle.fasl"
       :FASL-MD5 "d85ac349a8f6074d3759437c619a8b59")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/native.fasl"
       :FASL-MD5 "28ecf767f8fb7d07ff1db7602c909b78")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/package.fasl"
       :FASL-MD5 "5392379c2bcd3a3dd80c82c9823d168d")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/transfer.fasl"
       :FASL-MD5 "3e23a71d3c562fe20abebbc0a15dc4b1")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/io/types.fasl"
       :FASL-MD5 "5cba7c87122f972f57f3d9e0d8dcb7bb")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/package.fasl"
       :FASL-MD5 "95a71e0cc68dd454df034fe8101ecf45")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-core.fasl"
       :FASL-MD5 "b9a6877d1df7fdff94322438af9a7158")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-csn.fasl"
       :FASL-MD5 "7e611afc01d7d15e20c74ab9af6df128")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-lifecycle.fasl"
       :FASL-MD5 "ce3ed58f1457b3536a8d39facb7f8e28")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-read.fasl"
       :FASL-MD5 "a9ebed892d8df0e62e3962ebc027fca5")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-register.fasl"
       :FASL-MD5 "e004caf96659b9562ba5b2c25fd341da")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/snapshots-types.fasl"
       :FASL-MD5 "6dd39a2d36b581c9293950aa10becfc3")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/mvcc/types.fasl"
       :FASL-MD5 "feb0d0b8409af6ddcd004d9c3652e7dc")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/package.fasl"
       :FASL-MD5 "d023e5b1e69cbe7691002e74ca632319")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/read/core.fasl"
       :FASL-MD5 "5b7b0f5d3748bd81ba92b865c1fa06ab")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/read/package.fasl"
       :FASL-MD5 "ef46f7ad417e9142ba52ac9494f64cce")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/read/task.fasl"
       :FASL-MD5 "c43b294eddae9ea9095dce8c80cff44b")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/read/types.fasl"
       :FASL-MD5 "d9fbb7c0e0d564d4d92984b48a849228")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-build.fasl"
       :FASL-MD5 "3d5011ef2a52ae2d8ac4eb566e575ad3")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-package.fasl"
       :FASL-MD5 "779f34c64ae07b58896c573e4dfbcdf4")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-query.fasl"
       :FASL-MD5 "bcd49d6c1b482ef65ffd32fdb39542fe")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-radix.fasl"
       :FASL-MD5 "4c827639429b332529b93c2d44fd79f4")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-sort.fasl"
       :FASL-MD5 "133bd60c58b2c4296ba2ea705b603602")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/decisions-types.fasl"
       :FASL-MD5 "b7f7dbc30263f5a107ba76b6f679ad49")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-build.fasl"
       :FASL-MD5 "e36117b44447aa66aa213ca6aba50734")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-query.fasl"
       :FASL-MD5 "a2a1b2aea8f729fa6f7a3ceb4b080c21")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/inventory-types.fasl"
       :FASL-MD5 "a2d054ce03254124b23192f3f4407aef")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-build.fasl"
       :FASL-MD5 "49b4f3ed06229c22bb598fbec42e2d5a")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-decode.fasl"
       :FASL-MD5 "4c1da374d7d82466eb6df19897891639")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-fold.fasl"
       :FASL-MD5 "12d258f6c0572a17e8c4c671c64d61e1")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-package.fasl"
       :FASL-MD5 "90aa5c281a788143792ecbc36cd05e6f")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-query.fasl"
       :FASL-MD5 "5706223e272467aab2e6d25d88e49a06")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/manifest-types.fasl"
       :FASL-MD5 "f27ae049d3d0ab5a6ebdca2ea9a6cfeb")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/package.fasl"
       :FASL-MD5 "a774f4eaef0dbb44bea2fb0f118d6ce0")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/recovery/scan.fasl"
       :FASL-MD5 "8e232cbc429feac53ffdcb4562d52c5d")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/events.fasl"
       :FASL-MD5 "a9b23a54d0552f71a0c627124a855782")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/io-events.fasl"
       :FASL-MD5 "34c997b9fc34680e87ae78ef444aca08")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/ownership.fasl"
       :FASL-MD5 "87be9aa09170427efec2f91f23f50ac9")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/package.fasl"
       :FASL-MD5 "0fb9caa52bb3aff4dd205cd37d893f16")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/publication.fasl"
       :FASL-MD5 "12c7ea2f7ea03ca3636d018aec1f6fe2")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/query.fasl"
       :FASL-MD5 "7925c97ba7283740c4f52b0c5a29b33a")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/retirement.fasl"
       :FASL-MD5 "3f2370a9cb4332d73ec726b4c2b42995")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-build.fasl"
       :FASL-MD5 "5778ec621451c3250a75fef973cffade")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-select.fasl"
       :FASL-MD5 "8d65dd623d44559c3462c368d5faf3cd")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/routing-types.fasl"
       :FASL-MD5 "721d3a6624f41b65f009075d44db81cb")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/types.fasl"
       :FASL-MD5 "9f4ecfbe9fe6bf635774a3bbde550036")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-boundary.fasl"
       :FASL-MD5 "257af64dd67fd3e1b2c892d01213ab03")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-package.fasl"
       :FASL-MD5 "f263fc786d6553e9717eecb7534c6190")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-run.fasl"
       :FASL-MD5 "9b3a9ba2c6ddac51de732354f14d922c")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/series/worker-types.fasl"
       :FASL-MD5 "aa17a8a541f9147f07a80c18e7dcbd42")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/compaction-scan.fasl"
       :FASL-MD5 "38a8f2dab98e9c2a95100e4c26c96dc1")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/control-payload.fasl"
       :FASL-MD5 "3644b8af966f6ca9ebae7488699b733c")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/formats.fasl"
       :FASL-MD5 "8f8a26ab4fdd903205a099f9ad7b9363")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/log-header.fasl"
       :FASL-MD5 "ac0687e4cc927883e8a8e2a6577c054d")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/package.fasl"
       :FASL-MD5 "e8e4a888edc5195b6840091ac488cafb")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/payload-record.fasl"
       :FASL-MD5 "4e26316d85cf66bcdba2c31e14fe0b3a")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/payload-write.fasl"
       :FASL-MD5 "4b376e3f603b2884ee97d30e2c8d9fba")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/storage/segment-header.fasl"
       :FASL-MD5 "b1a2fa08a5c6c01bbe0602de69169a7c")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/builder.fasl"
       :FASL-MD5 "e3f7c287eefb65f3335d0a7ef0bcae8b")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/csn.fasl"
       :FASL-MD5 "24efb3955a20fafd764efbc25ff236c6")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/executor.fasl"
       :FASL-MD5 "c859ef436556ac3b6d76b002258c5d09")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/group.fasl"
       :FASL-MD5 "deb7be7ed8350a14f231dbde1060b893")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/package.fasl"
       :FASL-MD5 "721f55db54b07b358ba2a056b450e3be")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/src/wal/types.fasl"
       :FASL-MD5 "fb88f3f3347c5aeabbfd29f86fadc035"))
     :COMPILED-SUITE
     ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/foundation/support.fasl"
       :FASL-MD5 "6ae3175b59923ba593012660a54c137d")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/support.fasl"
       :FASL-MD5 "4c541cd1e5669f2c50af86914ac34aa8")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/construction.fasl"
       :FASL-MD5 "2cca0eb4d9c952dad3bf037113cc1e36")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/read.fasl"
       :FASL-MD5 "19023583ca4e35cf4c1c6b1cc9aafd2e")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/omit-directory-owner/fasl/tests/get-directory/threads.fasl"
       :FASL-MD5 "d8c8b23ba4015b5afe6b233384ce36cf"))
     :FAILED-TEST
     "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
     :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE "SIMPLE-ERROR"
     :DIAGNOSTIC "Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (ARCDOCDB.GET.DIRECTORY:CREA-DIRECTORY-GET-SERIE
                       ARCDOCDB.GET.DIRECTORY.TESTS::COPY
                       (ARCDOCDB.GET.DIRECTORY.TESTS:DIRECTORY-FIXTURE-MAPS
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVALID-ARGUMENT (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :DIRECTORY-SOURCE-OWNER)))"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . "379f516cebb2691c0c32e27ab184b161") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . "db58ed1c3877f2d6ea58932d3bc75e56") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   "missing-location-first-map" :FILE "src/get-directory/read.lisp" :DIRECTORY
   #A((143) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/")
   :EXPECTED-FAILURE :MISSING-PUBLISHED-SEGMENT-AUTHORIZED :SUBSTITUTION
   (:BEFORE
    "(when (= left right) (guasto-get context :directory-location-absent))"
    :AFTER "(when (= left right)
               (if (plusp (length maps))
                   (return-from cerca-mappa-directory-get
                     (the mappa-segmento-get (svref maps 0)))
                   (guasto-get context :directory-location-absent)))")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   ("TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP")
   :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . "b5e1e1260d8364e7eb1549db37153364"))
    (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3f19ffb4aacfdfe502c5e8b12a234f2"))
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
    (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "200373402e6e082dd8c7afde305302bb"))
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd12d0077a79f0c9c2f0a4dd01731f43"))
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
    (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
   :COMPILED-TARGET
   (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    "bd12d0077a79f0c9c2f0a4dd01731f43" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl"
    :FASL-MD5 "811607459e9ab3446a242baa097922eb")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
     "--script" "isolated-build.lisp")
    :STDOUT-LOG
    #A((153) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/stdout.log")
    :STDERR-LOG
    #A((153) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/stderr.log")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 6511759/1000000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/"
     :SOURCE-MANIFEST
     ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
       "b5e1e1260d8364e7eb1549db37153364")
      (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3f19ffb4aacfdfe502c5e8b12a234f2")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692")
      (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "200373402e6e082dd8c7afde305302bb")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cde24b2bf5c5637d5501b95bed47df31")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd12d0077a79f0c9c2f0a4dd01731f43")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9")
      (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257"))
     :SUITE-FILES
     ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
      "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
      "tests/get-directory/threads.lisp")
     :REGISTERED-TESTS
     ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
      "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
      "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
      "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
      "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
      "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
      "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
      "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
      "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
      "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
      "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
      "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
      "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
      "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
      "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
      "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
      "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
      "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
      "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
      "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
      "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
      "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
      "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
      "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
      "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
      "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
     :SELECTED-TEST
     "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bd12d0077a79f0c9c2f0a4dd01731f43" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl"
      :FASL-MD5 "811607459e9ab3446a242baa097922eb")
     :COMPILED-PRODUCT
     ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/build.fasl"
       :FASL-MD5 "b02d6ca7bb024cf74cd20ac1dbe429d3")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/clock.fasl"
       :FASL-MD5 "9bcf8da9ce5742bbd403e20d2f8464f3")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/core.fasl"
       :FASL-MD5 "b5c57a3346a246b3e3c754fb94a0f12f")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/package.fasl"
       :FASL-MD5 "9911226b6dea70848c306260f0d9011e")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/read.fasl"
       :FASL-MD5 "839b62352f383439f27d02f04bb05b30")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/types.fasl"
       :FASL-MD5 "9883b14e23650447b16eb2f0e45e83d9")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/cache/write.fasl"
       :FASL-MD5 "03ce66722ebeb7b49f96aec2b9613719")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-float-minimal.fasl"
       :FASL-MD5 "c83e4b5f6089d5c8f1c4c40138ad1da4")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-header.fasl"
       :FASL-MD5 "29fe6e95583fc9f52a2fe10e3e888905")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-minimal.fasl"
       :FASL-MD5 "98fb674c2596fd2efffdbbae30651878")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-package.fasl"
       :FASL-MD5 "360e82897ee560169326125516069df7")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-input.fasl"
       :FASL-MD5 "8d0cc753b3869d9bcd311de738397086")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-items.fasl"
       :FASL-MD5 "33ec8fbadb9267ac8ff5f09ca1b98d34")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-minimal.fasl"
       :FASL-MD5 "b1290ae2174162571ed55a01f5c0c13e")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan-stack.fasl"
       :FASL-MD5 "7e11aae26575717ed37bf8239fc3a7e5")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-scan.fasl"
       :FASL-MD5 "6535296f089bdec31c2993d0347a9eab")
      (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "200373402e6e082dd8c7afde305302bb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-simple-write.fasl"
       :FASL-MD5 "ed2ff333410dcef4fe7d2aa08f57cbcc")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-space.fasl"
       :FASL-MD5 "df3ddf573be454579e058fa5bc8e06fa")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-string-write.fasl"
       :FASL-MD5 "27bca02e549779951a95bb0a7e787cbf")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/cbor-write.fasl"
       :FASL-MD5 "b6b33741165eba56e446b41a555952b5")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/package.fasl"
       :FASL-MD5 "23a9c67ad2a955fbca1dd58ab10541cc")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/codec/utf8.fasl"
       :FASL-MD5 "68566b98480a8b77ee07db4be58b8266")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/csn/package.fasl"
       :FASL-MD5 "f625fe6fee7cd3b4e1591c0dec71cfb1")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/csn/registry.fasl"
       :FASL-MD5 "658cb95b65e768c97af8abaa67b4ec1c")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/core.fasl"
       :FASL-MD5 "889ab14bf558158601e6574c9a6cb451")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/package.fasl"
       :FASL-MD5 "cd4c4f673dedf62edf626bad2400632d")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/read.fasl"
       :FASL-MD5 "f5f65447b8a0f84f44b7cc500e6d1be7")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/reclaim.fasl"
       :FASL-MD5 "44067aca4695eba1d6a3a8153f31e8d2")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/retire.fasl"
       :FASL-MD5 "189c29532108fd611320903eb8106388")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/epochs/types.fasl"
       :FASL-MD5 "1c3f0215973ac536628450a82e735b55")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/handoff.fasl"
       :FASL-MD5 "b2aa378528ba8f4275b52173318092b6")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/package.fasl"
       :FASL-MD5 "41240eeb18d8bb3f97fb129fe8ea81ad")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/queue.fasl"
       :FASL-MD5 "9436642bf9a4853d97a5262b2fff8f3e")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready-recycle.fasl"
       :FASL-MD5 "f9643e2f155e69e5d7bc36f54718672f")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready-types.fasl"
       :FASL-MD5 "dd3dd6aa6070d7fd7a7f057418dd1b3b")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/ready.fasl"
       :FASL-MD5 "41638343d9270fd3c1a96359c169eda2")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-boundary.fasl"
       :FASL-MD5 "b1513f5ebedc9a1766b6153d8d69d21e")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-claim.fasl"
       :FASL-MD5 "e165fc474fb9a258f80865ff4f0c47d8")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-run.fasl"
       :FASL-MD5 "0243a87f41ad56b392dbae679f66f709")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/worker-types.fasl"
       :FASL-MD5 "6ed14c46917c4454d7ef96b914eb1116")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/execution/writer.fasl"
       :FASL-MD5 "8c438dd8c6a3cfb2eadd20e730912733")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/batch.fasl"
       :FASL-MD5 "79c9719a5036c9181ed6aa57d046b9c8")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/binary.fasl"
       :FASL-MD5 "87d2726dc64e746610adb46f352b0737")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/conditions.fasl"
       :FASL-MD5 "13e27519d15f4d4d0e57d3292565efa5")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/crc32c.fasl"
       :FASL-MD5 "7e906f6696d62005ac5b6a7359c469d8")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/package.fasl"
       :FASL-MD5 "b846cc52a0ba94f173c30c962b5a971a")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/foundation/record.fasl"
       :FASL-MD5 "b317a0cee10a7008caa27fd5793eb975")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cde24b2bf5c5637d5501b95bed47df31" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/build.fasl"
       :FASL-MD5 "73a76318fd7fedf37c8a18dc5bce1e56")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/package.fasl"
       :FASL-MD5 "60b906439b21437ed7dc57568c15145f")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd12d0077a79f0c9c2f0a4dd01731f43" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/read.fasl"
       :FASL-MD5 "811607459e9ab3446a242baa097922eb")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-directory/types.fasl"
       :FASL-MD5 "dc3b0184dcbe1dbd1a605577f5c90aae")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-build.fasl"
       :FASL-MD5 "781b11647a66b5f866e323995bdbdef9")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-directory.fasl"
       :FASL-MD5 "3eb16449838175cf81ac336e4411dc19")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-preflight.fasl"
       :FASL-MD5 "672305d1bb65bf9b5d51aaa649fe4374")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-read.fasl"
       :FASL-MD5 "68377524ede71036ae972ac42ae1104b")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-scan.fasl"
       :FASL-MD5 "95174d58607ca5411fe017f853d8fe58")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/active-types.fasl"
       :FASL-MD5 "28fda7954b9a8272172228e18b6c0199")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/build.fasl"
       :FASL-MD5 "90fc630863a3c20dd05f15a76a353ba5")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/package.fasl"
       :FASL-MD5 "4c25278dc9348a16793026667e4c40ce")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/read.fasl"
       :FASL-MD5 "e4b07f05e429292520028074b3167d25")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/rows.fasl"
       :FASL-MD5 "a92743603873320ae09bbdac00350edf")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/scan.fasl"
       :FASL-MD5 "1327a84e8ac23b721fc92a02b3ecaa49")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/sort.fasl"
       :FASL-MD5 "24dbb908f03f0f1b3fad07b9b46c1c60")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get-resolver/types.fasl"
       :FASL-MD5 "4785bd0e6ec7dd4147a97672e1bae7c4")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/build.fasl"
       :FASL-MD5 "b2c2a8a902aa97e02f5c6529dbcc82d3")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/lifecycle.fasl"
       :FASL-MD5 "19c819788a912548f5f06fb35397b148")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/lookup.fasl"
       :FASL-MD5 "00378dde1d9fad429a66844d7cfee890")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/package.fasl"
       :FASL-MD5 "9bc220d5f2f64bbe0640d4638556a8c7")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/segment.fasl"
       :FASL-MD5 "c925f6fdb1b0ccce64093f38b6381bdb")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/target.fasl"
       :FASL-MD5 "5be1499b3c703184dcb61ecc1852d033")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/get/types.fasl"
       :FASL-MD5 "5ef76ab8ea86555a8c0c64670f47d6fd")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/hash/arithmetic.fasl"
       :FASL-MD5 "c15ffe968e7138bd0beaf879205fd931")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/hash/blocks.fasl"
       :FASL-MD5 "e23300ce6cd4e6fa026233b04754d3ba")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/hash/hash64.fasl"
       :FASL-MD5 "a6094fbb46bd333ba2d4f8ccb0e16b5e")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/hash/package.fasl"
       :FASL-MD5 "f3200a579950303cb33375a3850292c9")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/core.fasl"
       :FASL-MD5 "41e25af714b754b100a58ca3826779fe")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/hash-digests.fasl"
       :FASL-MD5 "c6b4343071bebcfe7637ca3c7355db3a")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/hash-seed.fasl"
       :FASL-MD5 "62504b79fcadd35868e810bacc682819")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/package.fasl"
       :FASL-MD5 "aed7bf87558f618e18eb2e33e846d9bf")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-arena.fasl"
       :FASL-MD5 "dd2ece60cadb50f4e9a86f85212a0ada")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-build.fasl"
       :FASL-MD5 "524bdb9815910bb5110e1a89a75414d4")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-core.fasl"
       :FASL-MD5 "5b7d179a29a94e0c96ebd051a64111f1")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-directory.fasl"
       :FASL-MD5 "693e8582581b83a8e0e1f898cc834a13")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-package.fasl"
       :FASL-MD5 "1e58bd1d815dacfff845c2bcda90e504")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-probe.fasl"
       :FASL-MD5 "0d24dbd9d80219644f05f836e96cf77c")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-read.fasl"
       :FASL-MD5 "b82b1ee4e70aac544e5c5c72360ddf4b")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-relocate.fasl"
       :FASL-MD5 "d6cf783638e810a021bb4f385d335a10")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-types.fasl"
       :FASL-MD5 "bdbebc38df9db6a4310bad560afb5240")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/primary-write.fasl"
       :FASL-MD5 "a4e4a2b03577117b737a983795708421")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/read.fasl"
       :FASL-MD5 "4292af75ea212ebc83ffe42ce9ee277d")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-budget.fasl"
       :FASL-MD5 "ac219c0e660517c72f9ed6dfe7ecd670")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-copy.fasl"
       :FASL-MD5 "80166c61ce8eb613c2826e85130abc91")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild-scan.fasl"
       :FASL-MD5 "d8ba12886627fcf097a43c06a72db627")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/rebuild.fasl"
       :FASL-MD5 "49e09058658872f1cb00f2f8f85e4f53")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/relocate.fasl"
       :FASL-MD5 "5868322758b2112a4a277e262b2de5c7")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/types.fasl"
       :FASL-MD5 "f126f5fb43c2ce643011e19c523691ae")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/validation.fasl"
       :FASL-MD5 "6d27a961aad9478df565da0bbeebcb01")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/index/write.fasl"
       :FASL-MD5 "c94535cb251aa1581fe9dad06e65189f")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/flush.fasl"
       :FASL-MD5 "402e073742473cedbad5f5c31ba7c3bc")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/lifecycle.fasl"
       :FASL-MD5 "d6c866c25197d4ba7671dc9d4dd00088")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/native.fasl"
       :FASL-MD5 "20821dabddd29a21cc93f22e5a47fc23")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/package.fasl"
       :FASL-MD5 "c31f97a9a834492338352b54d3cb76fe")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/transfer.fasl"
       :FASL-MD5 "47db5dedf281fb57647512fb26195c10")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/io/types.fasl"
       :FASL-MD5 "9b4dc5206b3198dc93477b3da8713c46")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/package.fasl"
       :FASL-MD5 "58c591ac71c44a1daa298a958b94188f")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-core.fasl"
       :FASL-MD5 "759aee4169e0dfcb9c460589d8de028c")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-csn.fasl"
       :FASL-MD5 "b6830456645ab79a179a121119bb219f")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-lifecycle.fasl"
       :FASL-MD5 "4e4520cbdc023b7e5b2c5f6f4cf79894")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-read.fasl"
       :FASL-MD5 "8c3fbbb0107a22662a14f5fc9ec21838")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-register.fasl"
       :FASL-MD5 "f8d7a2c00fef491c1dbd9c9321114ea5")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/snapshots-types.fasl"
       :FASL-MD5 "903e898d2b2434f27902c4e2c53b5f6c")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/mvcc/types.fasl"
       :FASL-MD5 "be0fd75d1d94020bc45f3703ff3734e3")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/package.fasl"
       :FASL-MD5 "2a49876705d1a6ca22f2f4625a6236c4")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/read/core.fasl"
       :FASL-MD5 "0f186935cac262d817f6134121cfc5f7")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/read/package.fasl"
       :FASL-MD5 "0ba6045c6dcbdf5027169f3b93cde3d3")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/read/task.fasl"
       :FASL-MD5 "3493dd76978277941aac3fd1c1b529e6")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/read/types.fasl"
       :FASL-MD5 "071001eddec42b0ef163989eb4a9a6b5")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-build.fasl"
       :FASL-MD5 "39b07191b53c69657b0404e3e24974e1")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-package.fasl"
       :FASL-MD5 "c756fa5d37ed7ad9c5594d775042342a")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-query.fasl"
       :FASL-MD5 "c9aa10ff7cf3398bd0dcc3d7e3b04b81")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-radix.fasl"
       :FASL-MD5 "43dd68a21f1339051100d6cc04b1b47f")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-sort.fasl"
       :FASL-MD5 "10200d268e758bae15ba34ff4f50542a")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/decisions-types.fasl"
       :FASL-MD5 "ee45d51cd5ae03261d71c407b7d88e71")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-build.fasl"
       :FASL-MD5 "cf81ca7473efa5d8803d03068cdcab00")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-query.fasl"
       :FASL-MD5 "10fdf7973673c5c3413f3d2e831def3a")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/inventory-types.fasl"
       :FASL-MD5 "b09c78871a371c97d61841172bf91f50")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-build.fasl"
       :FASL-MD5 "6b9fe849adb58559151d875837bafee6")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-decode.fasl"
       :FASL-MD5 "cd40b2b6c146af32e824ab13226e757b")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-fold.fasl"
       :FASL-MD5 "f991ce6510d33ce0189f2b83e361283e")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-package.fasl"
       :FASL-MD5 "af0cfd8588703fd513f4e72adcca4ef1")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-query.fasl"
       :FASL-MD5 "4d42ab875e7b9c2a53c064cfb6d632ea")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/manifest-types.fasl"
       :FASL-MD5 "5b3b65133fe97d8d9774af2e4b1da73e")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/package.fasl"
       :FASL-MD5 "b1d89ccb71be35451f471f1756bdfc79")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/recovery/scan.fasl"
       :FASL-MD5 "6d7aae930dec65711516349374a005f4")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/events.fasl"
       :FASL-MD5 "3d8c4ddf26ef2065c02b4a198fef33d5")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/io-events.fasl"
       :FASL-MD5 "029caea504f3a110c7a9255312f8aab4")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/ownership.fasl"
       :FASL-MD5 "7ffa7b8bd63f73aeedd4d6521a16eb8c")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/package.fasl"
       :FASL-MD5 "1081449c95d25576e8e41f4f053b84a2")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/publication.fasl"
       :FASL-MD5 "606bcac63cfd1f59aa28613800a6ca39")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/query.fasl"
       :FASL-MD5 "d30ce85d85088ef55c760b67bd280a6d")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/retirement.fasl"
       :FASL-MD5 "9db8cf7707d369d843d6cf69902745ca")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-build.fasl"
       :FASL-MD5 "186361beccbca1e94b0ec83df8b35784")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-select.fasl"
       :FASL-MD5 "301f1f17d398aa058ee8e6549a64e871")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/routing-types.fasl"
       :FASL-MD5 "f78efb658271f5788d02c72bd56bd936")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/types.fasl"
       :FASL-MD5 "8fed182069e079a280c55b9aa1ef7864")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-boundary.fasl"
       :FASL-MD5 "37e2573f1e5bac1ee6e58b009b830a4a")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-package.fasl"
       :FASL-MD5 "1d3b8025cc009e3bb44b0730c4eeac29")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-run.fasl"
       :FASL-MD5 "a670c89dea5c1fff2b666237112a456a")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/series/worker-types.fasl"
       :FASL-MD5 "5df7d4e324744540f068dfefc572dea0")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/compaction-scan.fasl"
       :FASL-MD5 "7fdca8176434134bdd6c9e5a74e9c26a")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/control-payload.fasl"
       :FASL-MD5 "879e72d7229ad32ddd1c0d3df8a4375e")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/formats.fasl"
       :FASL-MD5 "85397514b05380cfd53f9a995bd13840")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/log-header.fasl"
       :FASL-MD5 "85396ed67ffb7f99ebae994e0d557fa1")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/package.fasl"
       :FASL-MD5 "85ec8a80610fd47e8e49044b1fbc4401")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/payload-record.fasl"
       :FASL-MD5 "4deea68fc28b458c99aab6cc603d3d8a")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/payload-write.fasl"
       :FASL-MD5 "fc935fb86674f44f1dd7db37401c625e")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/storage/segment-header.fasl"
       :FASL-MD5 "478253c6723e73f648d98410184931e4")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/builder.fasl"
       :FASL-MD5 "07b4def5d4d414a603164d78da914062")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/csn.fasl"
       :FASL-MD5 "9eedda7c0fc0869d577c68112096829b")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/executor.fasl"
       :FASL-MD5 "a3b615294fdd265be14d70a4a8b3bf5c")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/group.fasl"
       :FASL-MD5 "35fd2a7c66852e068b06265d1206cdec")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/package.fasl"
       :FASL-MD5 "2d4bc531bb4fa3e246be240698ed3df3")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/src/wal/types.fasl"
       :FASL-MD5 "a4cc525771adc7e60b585ea2f2667344"))
     :COMPILED-SUITE
     ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/foundation/support.fasl"
       :FASL-MD5 "b6ca8836931158c5bed41752672b2174")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/support.fasl"
       :FASL-MD5 "3535f847c69ed377e089d7202976695e")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/construction.fasl"
       :FASL-MD5 "0bda601ec36b6f81d6a4eaa3fbd8a835")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/read.fasl"
       :FASL-MD5 "d7f68d7a63df505da55547e058ac19b8")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/missing-location-first-map/fasl/tests/get-directory/threads.fasl"
       :FASL-MD5 "d2f8ff497b118b6cb1141e5bde386497"))
     :FAILED-TEST
     "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
     :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE "SIMPLE-ERROR"
     :DIAGNOSTIC "Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (PROGN
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-CALL-OPERATION
                        ARCDOCDB.GET.DIRECTORY.TESTS::OPERATION
                        ARCDOCDB.GET.DIRECTORY.TESTS::CONTEXT DIRECTORY)
                       (SETF ARCDOCDB.GET.DIRECTORY.TESTS::AUTHORIZED T))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVARIANT-VIOLATION (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :DIRECTORY-LOCATION-ABSENT)))"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . "dafc6cdbd71746f79369cd04151fb7d0") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . "bd12d0077a79f0c9c2f0a4dd01731f43") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   "alias-input-maps" :FILE "src/get-directory/build.lisp" :DIRECTORY
   #A((133) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/")
   :EXPECTED-FAILURE :CALLER-ARRAY-CHANGES-DIRECTORY :SUBSTITUTION
   (:BEFORE "(owned (copy-seq maps))" :AFTER "(owned maps)") :STATUS :OK
   :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   ("TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED") :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . "b5e1e1260d8364e7eb1549db37153364"))
    (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3f19ffb4aacfdfe502c5e8b12a234f2"))
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
    (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "200373402e6e082dd8c7afde305302bb"))
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd0d166bfeee41dc15f53c57586a3d0d"))
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "74a694385f1aaf03ec87721545494119"))
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
    (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
   :COMPILED-TARGET
   (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
    "bd0d166bfeee41dc15f53c57586a3d0d" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/build.fasl"
    :FASL-MD5 "70c53470eed0d0e84519f26ea68f419c")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
     "--script" "isolated-build.lisp")
    :STDOUT-LOG
    #A((143) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/stdout.log")
    :STDERR-LOG
    #A((143) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/stderr.log")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 5913239/1000000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/"
     :SOURCE-MANIFEST
     ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
       "b5e1e1260d8364e7eb1549db37153364")
      (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3f19ffb4aacfdfe502c5e8b12a234f2")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692")
      (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "200373402e6e082dd8c7afde305302bb")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd0d166bfeee41dc15f53c57586a3d0d")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "74a694385f1aaf03ec87721545494119")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9")
      (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257"))
     :SUITE-FILES
     ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
      "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
      "tests/get-directory/threads.lisp")
     :REGISTERED-TESTS
     ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
      "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
      "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
      "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
      "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
      "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
      "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
      "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
      "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
      "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
      "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
      "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
      "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
      "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
      "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
      "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
      "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
      "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
      "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
      "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
      "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
      "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
      "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
      "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
      "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
      "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
     :SELECTED-TEST "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "bd0d166bfeee41dc15f53c57586a3d0d" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/build.fasl"
      :FASL-MD5 "70c53470eed0d0e84519f26ea68f419c")
     :COMPILED-PRODUCT
     ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/build.fasl"
       :FASL-MD5 "c8699523bc3459b0a77f9f8cecef7203")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/clock.fasl"
       :FASL-MD5 "6b55b5904f25bea965b165eb79df6770")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/core.fasl"
       :FASL-MD5 "1232f7b038b3f49789029b39c8b3353d")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/package.fasl"
       :FASL-MD5 "7426304d94606eb7c47d5558b84b6dd4")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/read.fasl"
       :FASL-MD5 "633689bc1f90bc94d6bf71577e1ca0e0")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/types.fasl"
       :FASL-MD5 "3848e03b4470ede9a66f7f0bd47f7dfb")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/cache/write.fasl"
       :FASL-MD5 "88a016f1f369f407ab6970842204f5a3")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-float-minimal.fasl"
       :FASL-MD5 "80a34707e2eb49fa8b05116f85d391ad")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-header.fasl"
       :FASL-MD5 "9a0cb3f510cd602c4ba28fa050be9c23")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-minimal.fasl"
       :FASL-MD5 "8d69ff3debe1426c1756bc3f7ec7e0dd")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-package.fasl"
       :FASL-MD5 "c200e61a9071ec524c5aaa45ddc94cc7")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-input.fasl"
       :FASL-MD5 "bbb05b5df32ba0b275a3873fabf047ed")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-items.fasl"
       :FASL-MD5 "85c49369c85e2df1bfc6f7ab96ef9321")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-minimal.fasl"
       :FASL-MD5 "7ef9ee4132b667068cdb4db169e26e59")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan-stack.fasl"
       :FASL-MD5 "6a49f16375d1458819013afddb5b2c3e")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-scan.fasl"
       :FASL-MD5 "cdec575a4f91189369e43dc1ad070f09")
      (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "200373402e6e082dd8c7afde305302bb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-simple-write.fasl"
       :FASL-MD5 "12fc514522f802de24dc6cb19a25b757")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-space.fasl"
       :FASL-MD5 "637ca639cbf64e82b1e1047542bcf3f4")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-string-write.fasl"
       :FASL-MD5 "75e7cced8e3c46cf2e64c5742450bb57")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/cbor-write.fasl"
       :FASL-MD5 "82b1f757138dd40c4a44b3f326314204")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/package.fasl"
       :FASL-MD5 "3ee314f271d513d7347feee4e6baa629")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/codec/utf8.fasl"
       :FASL-MD5 "bb08ba5de6e37afa0cd71c408b53122b")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/csn/package.fasl"
       :FASL-MD5 "85ca7ad520306759fa4f45fdcfa4666a")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/csn/registry.fasl"
       :FASL-MD5 "ad345a971be234ad4b147a9c43d9231d")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/epochs/core.fasl"
       :FASL-MD5 "a633a79a634cae75d393ca38c003c3e9")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/epochs/package.fasl"
       :FASL-MD5 "96edc4be9f68f355f767514148cbe1dc")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/epochs/read.fasl"
       :FASL-MD5 "e7e6654654fca3794151ca5a666942af")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/epochs/reclaim.fasl"
       :FASL-MD5 "50bd72310a0325c0dc3c35a40f13abaa")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/epochs/retire.fasl"
       :FASL-MD5 "a1eb0b0a8a009265961ac40d918ae7da")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/epochs/types.fasl"
       :FASL-MD5 "327c4749543e73001f1d5daec0dfe41a")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/handoff.fasl"
       :FASL-MD5 "c1f3498b260d7b5d8b5d9fef7f4cead4")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/package.fasl"
       :FASL-MD5 "93d7d3127ca158aad8b5f2663f8eca3f")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/queue.fasl"
       :FASL-MD5 "fb5b6b72beabbbd605b7df5c0683240f")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/ready-recycle.fasl"
       :FASL-MD5 "0765f458dbf8864e87d7b5cc9b734196")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/ready-types.fasl"
       :FASL-MD5 "6a87e60fbc3f98108f28162e8a2dd919")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/ready.fasl"
       :FASL-MD5 "cd439014297cd332ff66d05fcc239a12")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-boundary.fasl"
       :FASL-MD5 "33376b886fd2efc6e91f6991fe8422c9")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-claim.fasl"
       :FASL-MD5 "2d0342f95aa0fdb388b03a4d64501d2a")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-run.fasl"
       :FASL-MD5 "97618c863c4350b6def98ddd3bc162a1")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/worker-types.fasl"
       :FASL-MD5 "7ad261513d5e26a574e80651a62cbd4c")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/execution/writer.fasl"
       :FASL-MD5 "65f1a0d7bbea718f6768893b30275b44")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/foundation/batch.fasl"
       :FASL-MD5 "0ba94e604ffa66ff9cb970cc9de9e7b7")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/foundation/binary.fasl"
       :FASL-MD5 "e21812e298276195cefb483aa7464110")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/foundation/conditions.fasl"
       :FASL-MD5 "05acf3afdd4166a7d56b95e58178cae4")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/foundation/crc32c.fasl"
       :FASL-MD5 "e7a1f08c71ba97d325ca890f8ed18391")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/foundation/package.fasl"
       :FASL-MD5 "cb3f265085d8629abb46dd20b7949fa7")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/foundation/record.fasl"
       :FASL-MD5 "abb6e9fa8c4a04f914f109bd3112bbf8")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd0d166bfeee41dc15f53c57586a3d0d" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/build.fasl"
       :FASL-MD5 "70c53470eed0d0e84519f26ea68f419c")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/package.fasl"
       :FASL-MD5 "f531c0bf787750e31f6145671fac6066")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "74a694385f1aaf03ec87721545494119" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/read.fasl"
       :FASL-MD5 "5c0bd9e4ad76c168a7d63bd043862ee8")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-directory/types.fasl"
       :FASL-MD5 "2e487bdca15b52f1fa69e93aa0fd57cc")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-build.fasl"
       :FASL-MD5 "adf608d6a2082e1aedc887688b9760de")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-directory.fasl"
       :FASL-MD5 "9d79d001a5e3cffe76eb0fd7464eeab5")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-preflight.fasl"
       :FASL-MD5 "5b271de07f19ea8493751116d2db8eb5")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-read.fasl"
       :FASL-MD5 "08c4d246abdb276e79dc609125b7a8a8")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-scan.fasl"
       :FASL-MD5 "a305ced450a049d240a6cc00e7488dc7")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/active-types.fasl"
       :FASL-MD5 "c6be5fcd818abf1b80ff2bbbbdb35394")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/build.fasl"
       :FASL-MD5 "7f1cbabe5b47d6e94aa52f6dac10205f")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/package.fasl"
       :FASL-MD5 "68816fc0a7902bf303f9400adb8c9d9d")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/read.fasl"
       :FASL-MD5 "2631ddfc7ea4bc9cf1423e4556e8436d")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/rows.fasl"
       :FASL-MD5 "cb521035f07b969496b7db65b7e0c2e9")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/scan.fasl"
       :FASL-MD5 "cbb3708628109bd3a5da3da30ac8e4c8")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/sort.fasl"
       :FASL-MD5 "281c37780b875207e8f24e5d996ba33e")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get-resolver/types.fasl"
       :FASL-MD5 "739334dcf728421140a2e60aed2652ee")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/build.fasl"
       :FASL-MD5 "f19319828c98fb47e1fb928ecde6c655")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/lifecycle.fasl"
       :FASL-MD5 "4aaa6c422b6fb395e54b497f6ba9b0fe")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/lookup.fasl"
       :FASL-MD5 "8bf7e65de31c424164e0af803873a558")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/package.fasl"
       :FASL-MD5 "6f94a561b4d69de73fe2f38df9e9d9a7")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/segment.fasl"
       :FASL-MD5 "a72ca47e871da35a662132fce593d8ab")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/target.fasl"
       :FASL-MD5 "dfb09cf166e6b081c36656aaf32eb77a")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/get/types.fasl"
       :FASL-MD5 "f0e4eb7a547b10e220903e9e1eb188b8")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/hash/arithmetic.fasl"
       :FASL-MD5 "1b7e73f087400e80bdd35c6b398b9ab3")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/hash/blocks.fasl"
       :FASL-MD5 "636b3f11d0a57c77d9a8bc0583d89278")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/hash/hash64.fasl"
       :FASL-MD5 "5a5b734f51febcc19eab80e7c95c4906")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/hash/package.fasl"
       :FASL-MD5 "f43410dae712b6a79d0cf6708f6e7f1e")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/core.fasl"
       :FASL-MD5 "256c990a30a301a60c5a8eaee2b9c3fd")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/hash-digests.fasl"
       :FASL-MD5 "c5901f65c97161199d72c22519a042ce")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/hash-seed.fasl"
       :FASL-MD5 "9c908732bc1430ad7fe348b98d1edf69")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/package.fasl"
       :FASL-MD5 "5f11bf0a9d4009fc39df142f9d4ea8a2")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-arena.fasl"
       :FASL-MD5 "60145d3a9fd3ba4f47c924e45a30fb56")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-build.fasl"
       :FASL-MD5 "f3281ae7e3fe3553fba77493c646e1e6")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-core.fasl"
       :FASL-MD5 "d3657f8d70ee36683370a628d95a35be")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-directory.fasl"
       :FASL-MD5 "122c2d3b3d7b89feda3557dc900faff7")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-package.fasl"
       :FASL-MD5 "708233d88d8edf8a8e46555776de4ca1")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-probe.fasl"
       :FASL-MD5 "475c45a9ad0ef6aefb451d1000adcffb")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-read.fasl"
       :FASL-MD5 "9f9a897734c51acb823162df4e16c27c")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-relocate.fasl"
       :FASL-MD5 "03a211ea764a11a4fb8c89490c155da5")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-types.fasl"
       :FASL-MD5 "6e8b7bcb0989e75659b555be14a51571")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/primary-write.fasl"
       :FASL-MD5 "f0d1c9f9dabcb9de9a95169fa87f5107")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/read.fasl"
       :FASL-MD5 "ff8049a54e07314acc8dff3df1e910e1")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild-budget.fasl"
       :FASL-MD5 "16fd97f708f60b2a156add50728ca222")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild-copy.fasl"
       :FASL-MD5 "dc389f6080c8501198011ce105815288")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild-scan.fasl"
       :FASL-MD5 "de2149e3c867d2b63804d2c9d5eb03b6")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/rebuild.fasl"
       :FASL-MD5 "79bb242251e9da2c476e678ddb6a3da4")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/relocate.fasl"
       :FASL-MD5 "7602f17a284a5318b27c2cd64550a419")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/types.fasl"
       :FASL-MD5 "84630e0b218674bda738303afd3a4cd3")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/validation.fasl"
       :FASL-MD5 "b645ff072dd958576a51a0a59d987c96")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/index/write.fasl"
       :FASL-MD5 "9080b80c7455cf88504c86c2eb127a9a")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/io/flush.fasl"
       :FASL-MD5 "c7bdcf51513f8cca5912f7c6e9326b35")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/io/lifecycle.fasl"
       :FASL-MD5 "a7f7bf18640f5a1962de0adfca7e58dd")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/io/native.fasl"
       :FASL-MD5 "d4cfb48a1ed0265531b37905d1dbf3b1")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/io/package.fasl"
       :FASL-MD5 "509a411521953abeb177c885afa9ed3e")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/io/transfer.fasl"
       :FASL-MD5 "5fe793788879caf168e1c1975eae17b3")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/io/types.fasl"
       :FASL-MD5 "31dfc65c90ed39a8e80ef7d572b39197")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/package.fasl"
       :FASL-MD5 "54ff5604a21f83e1087c30267fde4bb8")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-core.fasl"
       :FASL-MD5 "07cf8e7468395ec94f02b6ced8427cca")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-csn.fasl"
       :FASL-MD5 "b909ac2a3a70712b705503142b16c616")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-lifecycle.fasl"
       :FASL-MD5 "2f76e7d583aa57f74591b28f28a74b85")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-read.fasl"
       :FASL-MD5 "0b73358f37bf749f1775badaf408ca93")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-register.fasl"
       :FASL-MD5 "0182eccc2b5ec43b8cfb5d43640097ee")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/snapshots-types.fasl"
       :FASL-MD5 "1817fce0d10fdc3d4b75dcc3091fa960")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/mvcc/types.fasl"
       :FASL-MD5 "2625601d151d0bfb65811b5e2fb6e997")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/package.fasl"
       :FASL-MD5 "e01e8abcaa0c01bfd884c8aabcbe4c07")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/read/core.fasl"
       :FASL-MD5 "e0e5c3117ad68c15ca676eda749d433b")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/read/package.fasl"
       :FASL-MD5 "59c1c05d234bd49b421eff2232188439")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/read/task.fasl"
       :FASL-MD5 "3a3b9bdcfcda8f6e98aa04487d84c16d")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/read/types.fasl"
       :FASL-MD5 "6657aa01d6093e44469ebfe35fe7378d")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-build.fasl"
       :FASL-MD5 "05d989b183ff88b4fbf900f14688f5d4")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-package.fasl"
       :FASL-MD5 "ac2abadb735e6a477f668bbe54bfa44f")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-query.fasl"
       :FASL-MD5 "ecfe530f04a92175007a30698c730e61")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-radix.fasl"
       :FASL-MD5 "2134e25dd5fdea3306f3809362f99476")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-sort.fasl"
       :FASL-MD5 "3cedcb751de37c0de2c618fb888ee547")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/decisions-types.fasl"
       :FASL-MD5 "5ff32f60d47f58f56cbe5dfab255020f")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/inventory-build.fasl"
       :FASL-MD5 "0b5edd146a714491dc0295273cf12564")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/inventory-query.fasl"
       :FASL-MD5 "db1058988f7c145c182f7d7e076749f2")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/inventory-types.fasl"
       :FASL-MD5 "9ce9b14f1b32f5db53928ac61174fca9")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-build.fasl"
       :FASL-MD5 "cb2b05052739a99d7616823e947d3ff9")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-decode.fasl"
       :FASL-MD5 "4d3949908112449cf95d1d20c150195d")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-fold.fasl"
       :FASL-MD5 "3bc90448dca241c439ed1596cdd0c618")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-package.fasl"
       :FASL-MD5 "746e97c8d53034eab57e60c09cd71cd4")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-query.fasl"
       :FASL-MD5 "ed63820d6853abae5b71584dd496c6ef")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/manifest-types.fasl"
       :FASL-MD5 "16a235a566e5ce9a6fc0ae7048ecdea5")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/package.fasl"
       :FASL-MD5 "527d9a56fe26fec15ed3436f313c8cfb")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/recovery/scan.fasl"
       :FASL-MD5 "b2d9ee71e6b4ed1bfec0bbef700da31a")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/events.fasl"
       :FASL-MD5 "585eb28c53c5bcc3d34257e71c945b90")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/io-events.fasl"
       :FASL-MD5 "2b29c8d2f2dca5704ee745226c53df51")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/ownership.fasl"
       :FASL-MD5 "b2b14efbae548dfc64fc9de7e06372d0")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/package.fasl"
       :FASL-MD5 "e8b359065e102731bf88ffaff69f2e38")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/publication.fasl"
       :FASL-MD5 "e6d96a63c6f2df5ed37dc5a66123ca6b")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/query.fasl"
       :FASL-MD5 "c0cd9d4ee7eed3579b3ec3e1cabe547d")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/retirement.fasl"
       :FASL-MD5 "ca1257c5251404ea1c7e13e12973c944")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/routing-build.fasl"
       :FASL-MD5 "7e9a88b96eac5b56c766c4950c2161e3")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/routing-select.fasl"
       :FASL-MD5 "22fe90c3f1756cd1cdb44900b3854a6a")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/routing-types.fasl"
       :FASL-MD5 "f877de4f60990aa80fb6848a8748e502")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/types.fasl"
       :FASL-MD5 "7d3a1973925b1ca1c33ae76d0fcf6686")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-boundary.fasl"
       :FASL-MD5 "91fc422134ea87241376cfa580c3b040")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-package.fasl"
       :FASL-MD5 "e2c8f3ca6ad13349be96626540673373")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-run.fasl"
       :FASL-MD5 "51057c820bf7593db71c40d49f6d635d")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/series/worker-types.fasl"
       :FASL-MD5 "03b53e3dbddf26df49c54fa2888600b0")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/compaction-scan.fasl"
       :FASL-MD5 "049e1465afaeb06ac9adb78154729b99")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/control-payload.fasl"
       :FASL-MD5 "a33ff186104cac96ef850f58a69b1bf6")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/formats.fasl"
       :FASL-MD5 "a8b4b509e9395e7afe1f326d5668ef3c")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/log-header.fasl"
       :FASL-MD5 "83e528c78eeb28bc11b13c4e94a1f185")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/package.fasl"
       :FASL-MD5 "77d7e4c4754787412d84b55de6f1f2fd")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/payload-record.fasl"
       :FASL-MD5 "b70dafe615090af384a60dcb50f070b3")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/payload-write.fasl"
       :FASL-MD5 "72e891c713a96f0c6a22e364433fd590")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/storage/segment-header.fasl"
       :FASL-MD5 "9dd46ecf14e64a2adfe3dcb317483dce")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/wal/builder.fasl"
       :FASL-MD5 "4bc45b7226af9852c74ca69d329b6272")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/wal/csn.fasl"
       :FASL-MD5 "295019c75fe5e873c40b8b84bf791bb2")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/wal/executor.fasl"
       :FASL-MD5 "d514061338247b92fb8d70b31942e1b4")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/wal/group.fasl"
       :FASL-MD5 "9e4bcb355f4d6b1cbbe869273a5a9fe0")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/wal/package.fasl"
       :FASL-MD5 "b047591ba53e93ce851596b5c37f9166")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/src/wal/types.fasl"
       :FASL-MD5 "7f3b071048169d99e3381d0607efaf4d"))
     :COMPILED-SUITE
     ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/tests/foundation/support.fasl"
       :FASL-MD5 "bcd8f25457f4c9cc3f5174d2f3e0458c")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/support.fasl"
       :FASL-MD5 "46b222ef1e2d42417d4db578d72c0ab6")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/construction.fasl"
       :FASL-MD5 "dc3e317ba2b4d43b7f93df2599678ae2")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/read.fasl"
       :FASL-MD5 "1c79937545a4914ab7f79801083dc066")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/alias-input-maps/fasl/tests/get-directory/threads.fasl"
       :FASL-MD5 "94943c4668e853456f5759e0eeeae37f"))
     :FAILED-TEST "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED" :PASSED-TESTS
     NIL :FAILURE-KIND :PRODUCT-CONDITION :CONDITION-TYPE "INVARIANT-VIOLATION"
     :DIAGNOSTIC "ArcDocDB: DIRECTORY-SHAPE"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . "1cbcfe2ab10276b9301159fbb87d74c2") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . "bd0d166bfeee41dc15f53c57586a3d0d") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   "truncate-directory-id" :FILE "src/get-directory/read.lisp" :DIRECTORY
   #A((138) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/")
   :EXPECTED-FAILURE :MAX-U32-LOCATION-REJECTED :SUBSTITUTION
   (:BEFORE "(ldb (byte 32 32) location)" :AFTER "(ldb (byte 31 32) location)")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   ("TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID")
   :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . "b5e1e1260d8364e7eb1549db37153364"))
    (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3f19ffb4aacfdfe502c5e8b12a234f2"))
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
    (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "200373402e6e082dd8c7afde305302bb"))
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "65ce18f4ca8502f65bf6ee411e9f5fe9"))
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
    (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
   :COMPILED-TARGET
   (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    "65ce18f4ca8502f65bf6ee411e9f5fe9" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/read.fasl"
    :FASL-MD5 "e38f96a648455c6ee99ed2b15a69092a")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
     "--script" "isolated-build.lisp")
    :STDOUT-LOG
    #A((148) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/stdout.log")
    :STDERR-LOG
    #A((148) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/stderr.log")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 5707749/1000000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/"
     :SOURCE-MANIFEST
     ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
       "b5e1e1260d8364e7eb1549db37153364")
      (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3f19ffb4aacfdfe502c5e8b12a234f2")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692")
      (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "200373402e6e082dd8c7afde305302bb")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cde24b2bf5c5637d5501b95bed47df31")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65ce18f4ca8502f65bf6ee411e9f5fe9")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9")
      (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257"))
     :SUITE-FILES
     ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
      "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
      "tests/get-directory/threads.lisp")
     :REGISTERED-TESTS
     ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
      "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
      "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
      "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
      "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
      "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
      "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
      "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
      "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
      "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
      "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
      "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
      "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
      "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
      "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
      "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
      "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
      "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
      "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
      "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
      "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
      "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
      "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
      "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
      "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
      "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
     :SELECTED-TEST
     "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "65ce18f4ca8502f65bf6ee411e9f5fe9" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/read.fasl"
      :FASL-MD5 "e38f96a648455c6ee99ed2b15a69092a")
     :COMPILED-PRODUCT
     ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/build.fasl"
       :FASL-MD5 "579de5d3001edde3b15d2c7ee0354e7f")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/clock.fasl"
       :FASL-MD5 "3995b30c9eed3b1ce6b52ca6ef778969")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/core.fasl"
       :FASL-MD5 "f5bb2b2d9616a2fc37ea606f6c777d9c")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/package.fasl"
       :FASL-MD5 "0f3226966358a9948b1ddbaf6c075373")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/read.fasl"
       :FASL-MD5 "29a068db5d9622e2a917e55f435361b7")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/types.fasl"
       :FASL-MD5 "a45ae2cb181f3a94bbf7d3cc1d0604a7")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/cache/write.fasl"
       :FASL-MD5 "557a677e0894cb2463b607334e39482c")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-float-minimal.fasl"
       :FASL-MD5 "e06bd528f76a62edbf0fc37d81b0c21e")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-header.fasl"
       :FASL-MD5 "c1ee976ee2ec9ff54b1d57cf89777701")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-minimal.fasl"
       :FASL-MD5 "2992d936c288bf8230170d16f0e8baeb")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-package.fasl"
       :FASL-MD5 "d786341be7e857bff967f46def6a5ad7")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-input.fasl"
       :FASL-MD5 "ea2d88d175979b66530798bd50b39415")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-items.fasl"
       :FASL-MD5 "ba9e9c6b8fef29909e418f6421245df6")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-minimal.fasl"
       :FASL-MD5 "afd48768f571442620eb1562477d6122")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan-stack.fasl"
       :FASL-MD5 "181c0b0bf704f500c5a7c99bdcebe5ef")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-scan.fasl"
       :FASL-MD5 "958e60d3767ff4a893089d5fdf726c81")
      (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "200373402e6e082dd8c7afde305302bb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-simple-write.fasl"
       :FASL-MD5 "78fd717745451308b8c29b9ce9bf18f9")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-space.fasl"
       :FASL-MD5 "0e06ba38fd0c8a8e4422a3a8f09e86c2")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-string-write.fasl"
       :FASL-MD5 "d1e8a8947294bc2a4f7b8f8f505c1a46")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/cbor-write.fasl"
       :FASL-MD5 "f1ba6cd07a6eacfec0a0a118bd3da09e")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/package.fasl"
       :FASL-MD5 "aa8b90cac48737157f2f451551c33ffe")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/codec/utf8.fasl"
       :FASL-MD5 "0392bb5988c2b652f4e3beda9143871b")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/csn/package.fasl"
       :FASL-MD5 "a9c79d53f89dc39961b5e7b2f7b0f2de")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/csn/registry.fasl"
       :FASL-MD5 "55489f82ea2c9a4b38c6ade9b1eeafed")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/core.fasl"
       :FASL-MD5 "8e60f1ed8f21851c5be7dbfdfa81c761")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/package.fasl"
       :FASL-MD5 "8bc32d692490c900234a1b958c0d98bc")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/read.fasl"
       :FASL-MD5 "b3bfba4c127de4f9a35522064783a99f")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/reclaim.fasl"
       :FASL-MD5 "9445f335fb504875e57f937c3d3ee22d")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/retire.fasl"
       :FASL-MD5 "9e5c79c046095a361c132713ceaf9a50")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/epochs/types.fasl"
       :FASL-MD5 "542d509a92d0d68ddb8ff2cab1242ba6")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/handoff.fasl"
       :FASL-MD5 "42ee2510e0be09d2cd8198834b17523b")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/package.fasl"
       :FASL-MD5 "20bdc8610a6a4971320d45e5e1582e5b")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/queue.fasl"
       :FASL-MD5 "daee8d0140623406efb3aedf0ed4e1fe")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/ready-recycle.fasl"
       :FASL-MD5 "7f70cf49bf97b525e9dce8d160358b2f")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/ready-types.fasl"
       :FASL-MD5 "1af640a6ab3d56c839fd014e4d365ab2")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/ready.fasl"
       :FASL-MD5 "c420702806bb7e663645129f07ed231e")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-boundary.fasl"
       :FASL-MD5 "f970086f1390fb2584c047b8242af423")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-claim.fasl"
       :FASL-MD5 "6eddf01e9ae67c08de0b27cdca583ec3")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-run.fasl"
       :FASL-MD5 "726c763ca669a104e1d19bed727a0473")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/worker-types.fasl"
       :FASL-MD5 "3d5e8109d9d2e68c81bcaeac897be308")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/execution/writer.fasl"
       :FASL-MD5 "23f1fbb6e03114a75a66160da0409c7f")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/batch.fasl"
       :FASL-MD5 "e1b8d05d90fad7ccf5182c337a82362c")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/binary.fasl"
       :FASL-MD5 "b036ec7605c8b85aaaa0e4a387cd2a99")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/conditions.fasl"
       :FASL-MD5 "4a18e6a36ea04bc54724330600cf2ce1")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/crc32c.fasl"
       :FASL-MD5 "d70f5310bcfc903c408226d6f6d738c0")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/package.fasl"
       :FASL-MD5 "747e6c12b2804a22e8b7588c344fd614")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/foundation/record.fasl"
       :FASL-MD5 "c3037f83c74dd6118bc98ee24d3f0ceb")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cde24b2bf5c5637d5501b95bed47df31" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/build.fasl"
       :FASL-MD5 "34c1561a362f0e861871eb50244567da")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/package.fasl"
       :FASL-MD5 "5db839db629b34fda7988a08f635e89f")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65ce18f4ca8502f65bf6ee411e9f5fe9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/read.fasl"
       :FASL-MD5 "e38f96a648455c6ee99ed2b15a69092a")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-directory/types.fasl"
       :FASL-MD5 "8c74aba15d59afc55b8152ea69f647de")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-build.fasl"
       :FASL-MD5 "bd3e788ee0f1c95fdd3e103e90074d48")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-directory.fasl"
       :FASL-MD5 "271bafd2e884862d7b744f9f1a3848d1")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-preflight.fasl"
       :FASL-MD5 "b90e883019683974a4a707a5ffe48731")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-read.fasl"
       :FASL-MD5 "7b06a3dca74a3356a25d08478cce730a")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-scan.fasl"
       :FASL-MD5 "f6a19e35b499e22328f97c29c89a8df7")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/active-types.fasl"
       :FASL-MD5 "6dd7eb317d50437a04c75897fc84a296")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/build.fasl"
       :FASL-MD5 "28a9d80f006f244801d999bed4d1167c")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/package.fasl"
       :FASL-MD5 "1818ede181862747713fe1dc76192f98")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/read.fasl"
       :FASL-MD5 "5a8769935dff4d10d18ca7500585ff47")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/rows.fasl"
       :FASL-MD5 "3db58085edbf0a479d3f64d4d77e52bb")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/scan.fasl"
       :FASL-MD5 "d81206c678fb921c95207d4e9cda20b8")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/sort.fasl"
       :FASL-MD5 "5147cc2e164d26ca6581fc486e6704b6")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get-resolver/types.fasl"
       :FASL-MD5 "c242d0073ef6d55d83bc1133f4a21e75")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/build.fasl"
       :FASL-MD5 "9337a834757ba2c2e86528e60a7dd851")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/lifecycle.fasl"
       :FASL-MD5 "1d08256090b03f78626c921fdfed4106")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/lookup.fasl"
       :FASL-MD5 "4481c316f231fde80268e6bd15caa47a")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/package.fasl"
       :FASL-MD5 "61b6d15ecfda9083d3ca8d03d5de428f")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/segment.fasl"
       :FASL-MD5 "881352905b49a4463d81df859bc2a828")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/target.fasl"
       :FASL-MD5 "03ad5302593485726d5808d16a648049")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/get/types.fasl"
       :FASL-MD5 "99070f392c23b6735bed829f01e53bb7")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/hash/arithmetic.fasl"
       :FASL-MD5 "80ad5d8b7eb25fb4326228afd2c2dc87")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/hash/blocks.fasl"
       :FASL-MD5 "f52c76cb54ffeb9d2679591d3c7316fa")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/hash/hash64.fasl"
       :FASL-MD5 "4c71090164590e9e83efdf1280cd9c87")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/hash/package.fasl"
       :FASL-MD5 "76e873c4fdf0cde4af1dc0d560389e73")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/core.fasl"
       :FASL-MD5 "aa3a7085545bd9d52f47147173dedb98")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/hash-digests.fasl"
       :FASL-MD5 "4d798fe34b0ecf760def9b8132a27023")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/hash-seed.fasl"
       :FASL-MD5 "40f5415b96a5100f18430de2c19b9a61")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/package.fasl"
       :FASL-MD5 "592e57e331a74a6f74c5185d80ce08af")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-arena.fasl"
       :FASL-MD5 "40d8ae93640f1bca97751ca2816ed3a4")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-build.fasl"
       :FASL-MD5 "dfecbd2fbf04b5ea79f047c3f3d4829e")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-core.fasl"
       :FASL-MD5 "3b301c78f482d0a137352e205aeba52b")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-directory.fasl"
       :FASL-MD5 "d1eb9c4477f6d558cade3251c825575b")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-package.fasl"
       :FASL-MD5 "c6bb76322190c73bdc1f20c475ed9eeb")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-probe.fasl"
       :FASL-MD5 "5453065ce9d9a260de19fbe5bff4288a")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-read.fasl"
       :FASL-MD5 "bbaaa5fcf542f44236eccaec49041f32")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-relocate.fasl"
       :FASL-MD5 "f10caeceff5ef76634ff60e630403b25")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-types.fasl"
       :FASL-MD5 "08c5e01b12653a45d548a3a2f6d235e1")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/primary-write.fasl"
       :FASL-MD5 "a9113dcbf37d91e213423e543ba7114c")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/read.fasl"
       :FASL-MD5 "2d0bf5b0880b04c2601c905e7192d4c6")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild-budget.fasl"
       :FASL-MD5 "6f3aace77b2568590dab711536dc49eb")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild-copy.fasl"
       :FASL-MD5 "0bad4319a0d717c54d2d4d213e416f61")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild-scan.fasl"
       :FASL-MD5 "8e1caa5bf7e179e6adb7c4a39661c502")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/rebuild.fasl"
       :FASL-MD5 "36357fc841716daf2c6a3e66e4140be3")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/relocate.fasl"
       :FASL-MD5 "806c78fab893f9b8dc6781ab2ad85d85")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/types.fasl"
       :FASL-MD5 "ccbaccc757365e756533c25d7737f725")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/validation.fasl"
       :FASL-MD5 "c5250d1004bde92fbd3da0d1977eaec6")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/index/write.fasl"
       :FASL-MD5 "81f71c10edac858e5ce86b3757b35b2f")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/io/flush.fasl"
       :FASL-MD5 "648898f49267b2260c0eb0aecc238380")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/io/lifecycle.fasl"
       :FASL-MD5 "5fa2fbf4010b38f96021748dd7146fac")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/io/native.fasl"
       :FASL-MD5 "611d6fa50a78a7dd5b8dda6a18050224")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/io/package.fasl"
       :FASL-MD5 "5516d808a1c6a176a4ba811d453cf239")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/io/transfer.fasl"
       :FASL-MD5 "8003942fa0382692dbda89b3a3b3e60c")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/io/types.fasl"
       :FASL-MD5 "0049180e98734258d6ea293f943af958")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/package.fasl"
       :FASL-MD5 "c4650acc43bca0eab4492df119d26453")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-core.fasl"
       :FASL-MD5 "7a50ca3209849fee03c41e76df884ffe")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-csn.fasl"
       :FASL-MD5 "0f89dc0778ee3c0ca22fad49bff76883")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-lifecycle.fasl"
       :FASL-MD5 "8fcf1396bcf02198778d61286671e0ce")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-read.fasl"
       :FASL-MD5 "89a7e8f701f22ccf7763bca3ff32f803")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-register.fasl"
       :FASL-MD5 "72165fe1e309cf8cd8b039ccf081c125")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/snapshots-types.fasl"
       :FASL-MD5 "ad735fd9e1ebc5e8a3e004aaed8e1a99")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/mvcc/types.fasl"
       :FASL-MD5 "ff4c1947fe55f1e62cf20be0d4050f49")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/package.fasl"
       :FASL-MD5 "7b7f8a6e0d5dbb1f366957b262ce88f9")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/read/core.fasl"
       :FASL-MD5 "a864751776714a403aaf7313591209fe")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/read/package.fasl"
       :FASL-MD5 "8a7979111837f98676ba2979c6c18932")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/read/task.fasl"
       :FASL-MD5 "1a3f5249df7b44522405065415378974")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/read/types.fasl"
       :FASL-MD5 "58b9b878e7363d53d4295c1bf2b4dc45")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-build.fasl"
       :FASL-MD5 "b187350779e9ebbbd6965949af4ed036")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-package.fasl"
       :FASL-MD5 "770db036e33329d1eb53d458f12ac4cf")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-query.fasl"
       :FASL-MD5 "77f8746c234a813e3fbe08963ebd84fb")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-radix.fasl"
       :FASL-MD5 "004d408b28028cc875471b996e77dc4f")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-sort.fasl"
       :FASL-MD5 "b6ae688e8d14d27b26ca9eb78820252a")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/decisions-types.fasl"
       :FASL-MD5 "9848d8d76bb0ebeed8d569beb5005745")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/inventory-build.fasl"
       :FASL-MD5 "cb32760005018a7463865a6d3208865f")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/inventory-query.fasl"
       :FASL-MD5 "81e48897269659fb9dd4f63a0e48493e")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/inventory-types.fasl"
       :FASL-MD5 "8af2eea33640ed65f5e87f8aa5e2bb61")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-build.fasl"
       :FASL-MD5 "3853ea7a33304bfb1ad31559c584916e")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-decode.fasl"
       :FASL-MD5 "fa5ba970d84cd03b64a8c5cfee574df2")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-fold.fasl"
       :FASL-MD5 "d4de7b438c074f7810733a4cc5798438")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-package.fasl"
       :FASL-MD5 "280156bf6be201794a8e38ac14ab371c")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-query.fasl"
       :FASL-MD5 "085cc875ff302eb30334f36027fb6a5e")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/manifest-types.fasl"
       :FASL-MD5 "5df15d4511b20a512797ba118f560094")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/package.fasl"
       :FASL-MD5 "23e98933d773484494c2fc3d8f22e206")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/recovery/scan.fasl"
       :FASL-MD5 "36d45aa4dd10840ab9764019dba0ddae")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/events.fasl"
       :FASL-MD5 "fd60a0d997f33f4fc3f0af07e6fe5651")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/io-events.fasl"
       :FASL-MD5 "f6efb3b3086c20e943c3fa6e9ef48325")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/ownership.fasl"
       :FASL-MD5 "f8454da1f16cc2a9bbe4a3b38738d049")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/package.fasl"
       :FASL-MD5 "12d207d73eb789174ad9cf86b94bb970")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/publication.fasl"
       :FASL-MD5 "9e963f2e51397458f2e12ce0ae72799e")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/query.fasl"
       :FASL-MD5 "3c0e17d58665b3b2903044449ee28720")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/retirement.fasl"
       :FASL-MD5 "9a115b68bdc5a6daa05ea52188f89f09")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/routing-build.fasl"
       :FASL-MD5 "379f6dcdd96ac01337b1a1f96ea6b7b3")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/routing-select.fasl"
       :FASL-MD5 "bd74dd0564546b6900f3a69964c19efb")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/routing-types.fasl"
       :FASL-MD5 "791f1f409a50aa4f4647cf3541e6afee")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/types.fasl"
       :FASL-MD5 "03b0a93621ecd824d64f8a561f22cb86")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-boundary.fasl"
       :FASL-MD5 "96aa65d7de8b0731b91d47f21bc3aece")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-package.fasl"
       :FASL-MD5 "c0579cacbf4b959ad529c9c30d3ed9e4")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-run.fasl"
       :FASL-MD5 "d6c12d1437f40f4b036976e173900e4d")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/series/worker-types.fasl"
       :FASL-MD5 "9e53bb756d13cd41d03334b011e0254e")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/compaction-scan.fasl"
       :FASL-MD5 "73f64d68858697128ec9c6eb2e7bd1ca")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/control-payload.fasl"
       :FASL-MD5 "99efe0c8e41e2fa64f743e4ef3387e8d")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/formats.fasl"
       :FASL-MD5 "3671c4e0fe59800ce1f0e6d9dec33509")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/log-header.fasl"
       :FASL-MD5 "91b3f356a3b3a0d20cf6b5b7855f4542")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/package.fasl"
       :FASL-MD5 "a0b9ee3fb3baad2b9d68f2b1a2205fa5")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/payload-record.fasl"
       :FASL-MD5 "aebf189d8ed91aa258721056d6f67940")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/payload-write.fasl"
       :FASL-MD5 "da2d2bbf7cd4cc1cc0c4b87f0bbf0074")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/storage/segment-header.fasl"
       :FASL-MD5 "9baeca2293c4a311f80417c23ed109c9")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/wal/builder.fasl"
       :FASL-MD5 "97ef82ecb1ee1724a17ff02af85890bc")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/wal/csn.fasl"
       :FASL-MD5 "9b95024c4c14617f7c2fb5e1489fde54")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/wal/executor.fasl"
       :FASL-MD5 "01381bd077a8ef8c8414adc7cfe55bf3")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/wal/group.fasl"
       :FASL-MD5 "e8498657a67098490978ca44f11cc53d")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/wal/package.fasl"
       :FASL-MD5 "3861ddcb25dd2fd080bcbad8ead4c6cf")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/src/wal/types.fasl"
       :FASL-MD5 "daaf626d3f18b806d64af6bf03f4effb"))
     :COMPILED-SUITE
     ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/tests/foundation/support.fasl"
       :FASL-MD5 "365bf341bc1559d4b0f264a189bc399b")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/support.fasl"
       :FASL-MD5 "38f0dc423d4eeba7f9de0e7c53d1300f")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/construction.fasl"
       :FASL-MD5 "0d7d9461bb77822ba83bcd0ab18d8877")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/read.fasl"
       :FASL-MD5 "e3c08cd92af313c3c298948ff53ef8e2")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/truncate-directory-id/fasl/tests/get-directory/threads.fasl"
       :FASL-MD5 "64b0d17b8f8dad4340e36a2af6edef3b"))
     :FAILED-TEST
     "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
     :PASSED-TESTS NIL :FAILURE-KIND :PRODUCT-CONDITION :CONDITION-TYPE
     "INVARIANT-VIOLATION" :DIAGNOSTIC "ArcDocDB: DIRECTORY-LOCATION-ABSENT"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . "6c9f199953303643f910b20ecb13f8e5") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . "65ce18f4ca8502f65bf6ee411e9f5fe9") :ARTIFACTS-VERIFIED
   T)
  (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-COPY :NAME
   "bypass-closed-resolver" :FILE "src/get-directory/read.lisp" :DIRECTORY
   #A((139) BASE-CHAR
      . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/")
   :EXPECTED-FAILURE :CANDIDATE-SIZE-AND-RESERVED-HIGH-BITS-NOT-CHECKED
   :SUBSTITUTION
   (:BEFORE
    "(risolvi-candidato-get context (trova-mappa-directory-get context directory))"
    :AFTER "(let ((map (trova-mappa-directory-get context directory)))
    (values (mappa-segmento-get-segment map)
            (arcdocdb.get.resolver::mappa-segmento-get-end map) 0 nil))")
   :STATUS :OK :RESULT :DETECTED :DIAGNOSTIC NIL :EXPECTED-TESTS
   ("TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS") :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
     #A((32) BASE-CHAR . "b5e1e1260d8364e7eb1549db37153364"))
    (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5d70197c8b64ad6f20c8be47a60c73ca"))
    (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3546cf7f5c5ed138068548c20064f499"))
    (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "72f3a33ce27ddf94c49c495580520004"))
    (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1f6a8e7aa4faed88e984b39871d1e53"))
    (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82f937b7b08bd1696ad9c88da2e1c60c"))
    (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a25648d870eaa4f0b6e1e3b2cf76e28e"))
    (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fc09021f74fb50aac57589614dae04d7"))
    (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bc7a7b176e8cdd361b7c4306a1a4de4b"))
    (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6e8c6a49314c2f460aa6f8a1759200b6"))
    (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ecd8fe950344059c629927b38fb6e4aa"))
    (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3f19ffb4aacfdfe502c5e8b12a234f2"))
    (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f6488e987889432b375254021825dbe5"))
    (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "706c0baa4158bf272c4b0df17c1439d2"))
    (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "987e8ed576a21eb644ac1ef2e06edbda"))
    (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cf1999ddb10f879aeefbeea853742d57"))
    (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0c33aedcdb352e78a3c694cf796e6692"))
    (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "200373402e6e082dd8c7afde305302bb"))
    (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c33cdcc45f45218aa3e8bf26ce0ee575"))
    (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b13e92b5f24a42fe283c17b649722b6a"))
    (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "69e77bcd15b5413a815a65c5081229db"))
    (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d885bd2a9860eb60aec1a775e5031d5e"))
    (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0f67dd5c51bf6a63bc292ab4e2a280c2"))
    (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1130012fc5613a5648d22ed8628be0e8"))
    (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a1cdb5661fc54beba5bf00e4765f3235"))
    (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "765d14c88cd288093a77a57930cd6999"))
    (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "875201dfab0a84efd40fe9828cc293c8"))
    (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "975b5f74e0c5a38ce978f4d9c7fcc6b8"))
    (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "036dd02adf87d33c3ae2f40735c733fa"))
    (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "653b974f310c09f6e2224a84acc43bbf"))
    (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82253491f995f5bc153fb5ebf30d564c"))
    (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6b85eebe69366e78ed5fc5cc20735f00"))
    (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb5710d6c111cadb7121a50998a747fa"))
    (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8202843bddb817da4279ac959ae3f3c4"))
    (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "38d26f8c749dd946dfc4b9c57103a892"))
    (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a64d98c9ff429d6103d6e10ee1fd7980"))
    (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2c1892002f0599bb8273093031017520"))
    (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c24065d6c8d80d1be53994a0041743df"))
    (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "babd0a78b4185af24ae1fef870c0fabb"))
    (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "aa34ca6bc07535e35fea723878d99f66"))
    (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0679ee07c46f69db330706303c70d8d2"))
    (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "73019644090e2971f2b54dc36e4491f5"))
    (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca642ea47e4bff76f78f5b6d7287d6bd"))
    (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a06115175f450776762761dce25acdb8"))
    (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "942b596396c19815290a57830af2121b"))
    (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4db58e2f48bf77d751f1b83bb9f84b5c"))
    (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5ee593a112958d94163dab17c5aa4ba2"))
    (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c3ed0f09fa3fa6fe20c98e2ed6e69abe"))
    (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cde24b2bf5c5637d5501b95bed47df31"))
    (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4233eef9d87bdec712d4f690bcb699a9"))
    (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "dde814f850eae82069c02ec9348edf34"))
    (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "17c957d6934a31f4ed64313e756de2d2"))
    (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8d26428a4e17ad18990b8ee7d5f5b53a"))
    (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "6d95f29b331d335175843f47ae44a6ea"))
    (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f13d422adb6aa9e8489352884137f25a"))
    (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3da469a7aa1e682dd8f2e516ee451de1"))
    (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6aaec49504a96f37c8ff1bc182c977b"))
    (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bd7182e9871fe82530d0c828e473ccde"))
    (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bbfb2082103e6712419e180ab972245c"))
    (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbfb17bf1f65698fb7c7889953d02d1e"))
    (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1339edff0223dbf122f11ff0adbba61c"))
    (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ca9002b81efd0aed9761cd1f78514762"))
    (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "536e9dc4ed51072b8a6d1528d3ec18bf"))
    (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d869293ba47444c4721713d955c6254"))
    (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9df13bcc6908e9fa601d173a671e1ccf"))
    (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c5cc36884b238221cc13ca0c087ec7c2"))
    (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e70bfeddd694336bbd088e65f8761834"))
    (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "82258ec87aca513a508bc5dee8410dd6"))
    (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c72633d15c3488699072eb610ebde7c8"))
    (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "811869eb6a197d3c4e26af4322e52652"))
    (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1b70dac05d6d2418909eb5105b808e81"))
    (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c394e5684de5e2d938991c7cb348b93c"))
    (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b5c51802e607e3dd22de68204baf64e9"))
    (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bef497b9a267c7306d4100000491c814"))
    (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "886b7c08b9929283e8968831cbe5c039"))
    (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d9060e41bc5252067d35e59ac70ee06"))
    (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "65076c355c099b5dc73d185948d3bec4"))
    (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "43d2209225707352daec6186ef95a805"))
    (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "45ce41749bc6fa638539815d3f802b96"))
    (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "598a9b65e73151c924b2cdcaf6d96705"))
    (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a319691e3e28b7ea7b927de490cf69ba"))
    (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff2cfbb865290d7a1510fdf6877c7229"))
    (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fa52433eae199ceeb874bf2bc47afca7"))
    (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1dd67c527257e43f17e006644ecdbd00"))
    (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d65cfce399b04f905bf969929962e59a"))
    (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "699ce3f1615296fc27fcde3e0d63a4bc"))
    (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3f317a0d3c5ee86a73651aad36135cc3"))
    (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5155959766645d3172ae5e73c58cc071"))
    (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a59eab6425a60fa2656f86bf87d5c9ac"))
    (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e8e31e599356e592af29c0cc4604872b"))
    (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5b22b90cfe8534086f6aff96d156713e"))
    (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0417dd41cb3ec1d62dfd913c19f810ad"))
    (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8befbbd00ed5c31c1487a11887eba495"))
    (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1188e7a64a7a5d9482c1233cb9acb452"))
    (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a450cac8071513365267e7024cbe94b0"))
    (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475dd7d5809a836f01544b447cc8df27"))
    (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "5157fd03ee806ee998ad8f0002d56268"))
    (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "3384cadf737c7d80c004222022a281f6"))
    (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0c8c579cd7db466d243ed3ea9f8e8aa"))
    (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "716866194d6b9f076e102e84187229c0"))
    (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "11c7103efbe733bbf0a13927f23c3d34"))
    (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9500cfb800603de002d6d2b24f1bf056"))
    (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c9380ad46a1d7acf41655aaed20db478"))
    (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a5e7108e80664eb3b562fbd7e680801f"))
    (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "db8497f9cff35b1ee261f1f410f46ca6"))
    (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f188d1dbd5d0adb49f53acf09157aef9"))
    (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8bb066aab61a18eff175b9edb11e42a2"))
    (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "0e9365e674d1584b111f915ce1f58634"))
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ff98aea5cb9a7ae2671f6a887a003725"))
    (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ae3ad96269b5e711a9dbb455f3c0ce48"))
    (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2d5a795bcefd605c75da91c725ae83a2"))
    (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "475517bd7ba04a1c37a82efeb8ff73d9"))
    (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a9bc70eab6720b5c6f8503178e2c966b"))
    (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "becf5c78049c85f2c05cd1ef54454032"))
    (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "4040905f4a64ba704a480d82e87ec748"))
    (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7d74d9decc5a0bc9f9331d89bd503e21"))
    (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9e0baf22c53329d393e047c669679645"))
    (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9c37ff8237fcc9fe9ae4f44316e854e3"))
    (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1a51ef4a488bb9fde2ff7d47bae01379"))
    (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cbdc30f93109c474e1fc25066c9b9b13"))
    (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f782d1137b8ce342b91c9999cfb7accc"))
    (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "852149de4c289b8e067602780378d87a"))
    (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b33e57a643f2fca810846f6226366253"))
    (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f4433fd19ebc7239dbc2628c39f3ecdb"))
    (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "9bd6820c4feba3e552aab1a4edd87861"))
    (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcea263de1938767772e5b11411ecd5e"))
    (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "78c136d5838dcfe3019d9069643a8d8f"))
    (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "bf65b1731eab6e0572461ef5cc60fc40"))
    (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "67975249aaabd751757cdfb9222cc3c4"))
    (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0d2498db1011e857b7b0daa1934f187"))
    (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "37ace42844c11b52446ee1fc500b8e0b"))
    (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ebd7a54adea2213294a887e6d4db0927"))
    (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7b1d4054415faca7e5fca59ad83b4d4a"))
    (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1c1c8ad0cd15b1703a2fe19cbf3f13c2"))
    (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "fcacd15460db25ea9cc4036065f9f096"))
    (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "32b2156739a6f2ca996abb91df0a2603"))
    (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b6026a8b7bb64b45c37a65effda70d8e"))
    (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "de1aca16a35d34d16aba12ff541c0d2b"))
    (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "59e3c59c90d8d0fc5731b87496a785aa"))
    (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "056d2c6a67c9d9f2bf9fe2d2c348d53c"))
    (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb0d91405325b508e6b2ab24d178de7a"))
    (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b8e04971b8ad75a1bd0c722997badfd2"))
    (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6924deff152b941bd49f0bb200b4197"))
    (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "e0f987d8767744050ec4d1b3ecb699ed"))
    (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ce649df47dd38888d5103c98345f7e41"))
    (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "ab19ec8d15af91511e817858c41cebc8"))
    (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2340e0c9074f7b1bf80c74f774986bc5"))
    (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a93ce2e84e8aee647b5083ad1d2b899b"))
    (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f0fee18adf357bad98e8a3c3e8c70c0c"))
    (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "2b23d468be0165fa009c5ebd5d1bbe23"))
    (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "1cda77a357ab2147035993b72d135a37"))
    (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "cb64f806b8d69eb42d865b4abfff0b27"))
    (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "061147be459d8d3b08c661bd3f91d152"))
    (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "b53d27dcc9f4badf18b50519c50bc614"))
    (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f86bd104f20616a76b42c02227f72844"))
    (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "8c03f9c01dcb30f2d3970a5694968ecf"))
    (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c4ece3c4fa8d9492d2a80df7c0a4f5a0"))
    (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "d6812fa59bf8fd1252fbf85a9bfa3896"))
    (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "a229f76f7036f3573a6e528dcd390a19"))
    (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "42b990e3b254e6fb488c0ab91b6a6502"))
    (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "c0340924c9130e14d0e8efedeec078f1"))
    (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "7a0e7c99ab70b4720cbb091156560f5e"))
    (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "96c41b1d417135a24fc65659ea3abe11"))
    (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
     #A((32) BASE-CHAR . "f799f27a8ac1a4c736c04796c1e543f9"))
    (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "758adad069aec2f9dbe0635797314ff6"))
    (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "3f868ebe4307ad4238b314c37eceed9a"))
    (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "1137938073e71d6d8d62c751fbad05d5"))
    (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "d1ab36d05cc1266e4533d27c693f12f4"))
    (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
     #A((32) BASE-CHAR . "63dd01c852de1399c2c82274d481d257")))
   :COMPILED-TARGET
   (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
    "dde814f850eae82069c02ec9348edf34" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/read.fasl"
    :FASL-MD5 "46c6f5e85e0427ed069dbd44fb4d8f70")
   :EXECUTION
   (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-EXECUTION :STATUS :COMPLETE
    :ARGV
    ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
     "--script" "isolated-build.lisp")
    :STDOUT-LOG
    #A((149) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/stdout.log")
    :STDERR-LOG
    #A((149) BASE-CHAR
       . "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/stderr.log")
    :DEADLINE-SECONDS 120 :ELAPSED-SECONDS 953493/200000 :EXIT-CODE 1 :SIGNAL
    NIL :TIMED-OUT NIL :CLEANUP :REAPED :CLEANUP-ERROR NIL :REPORT
    (:SCHEMA-VERSION 1 :KIND :GET-DIRECTORY-MUTATION-CHILD :PHASE :TESTS
     :STATUS :FAILED :ROOT
     "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/"
     :SOURCE-MANIFEST
     ((:FILE "arcdocdb.asd" :ROLE :SYSTEM :SOURCE-MD5
       "b5e1e1260d8364e7eb1549db37153364")
      (:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3f19ffb4aacfdfe502c5e8b12a234f2")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692")
      (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "200373402e6e082dd8c7afde305302bb")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cde24b2bf5c5637d5501b95bed47df31")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "dde814f850eae82069c02ec9348edf34")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9")
      (:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257"))
     :SUITE-FILES
     ("tests/foundation/support.lisp" "tests/get-directory/support.lisp"
      "tests/get-directory/construction.lisp" "tests/get-directory/read.lisp"
      "tests/get-directory/threads.lisp")
     :REGISTERED-TESTS
     ("TEST-REQ-STO-003-DIRECTORY-NATIVE-READ-NONZERO-BUFFER-START"
      "TEST-REQ-IDX-001-DIRECTORY-EMPTY-AND-PAYLOAD12N"
      "TEST-REQ-AFF-008-DIRECTORY-BUDGET-EXACT-AND-ONE-SHORT"
      "TEST-REQ-AFF-008-DIRECTORY-INVALID-CONFIGURATION-AND-MAPS"
      "TEST-REQ-IDX-001-DIRECTORY-INPUT-ARRAY-COPIED"
      "TEST-REQ-IDX-001-DIRECTORY-DUPLICATES-AND-DESCENDING-ORDER"
      "TEST-REQ-CMP-007-DIRECTORY-CANONICAL-OWNER-AND-FOREIGN-OWNER"
      "TEST-REQ-IDX-001-DIRECTORY-SEGMENT-ZERO-HIGHBITS-AND-LIFETIME"
      "TEST-REQ-IDX-001-DIRECTORY-65536-FIRST-LAST-SEARCH17"
      "TEST-REQ-IDX-001-DIRECTORY-NATIVE-READ-V1-V2-VALUES-AND-MAXID"
      "TEST-REQ-CCH-002-DIRECTORY-CACHE-ENUMS-AND-PRIVATE-OUTPUT"
      "TEST-REQ-CCH-004-DIRECTORY-CACHE-VERIFY-FAILED-NATIVE-FALLBACK"
      "TEST-REQ-CCH-001-DIRECTORY-CACHE64-NO-EVICTION-AND-EVERY-HIT"
      "TEST-REQ-FOR-004-DIRECTORY-PREPARED-WRITER-OUTCOME-SEAL"
      "TEST-REQ-IDX-001-DIRECTORY-MISSING-PUBLISHED-CANDIDATE-FAILSTOP"
      "TEST-REQ-CMP-007-DIRECTORY-WRONG-OWNER-CLEANUP-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-CSN-LOW-AND-HIGH"
      "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
      "TEST-REQ-FOR-004-DIRECTORY-SOURCE-KEY-MISMATCH-NO-AUTHORIZED-VALUE"
      "TEST-REQ-IDX-001-DIRECTORY-SHAPE-FI-BEFORE-SOURCE-READ"
      "TEST-REQ-IDX-001-DIRECTORY-PRIVATE-NIL-ENTRY-SHAPE-FI-ALL-ENTRYPOINTS"
      "TEST-REQ-IDX-001-DIRECTORY-CLOSED-FD-AFTER-PUBLICATION"
      "TEST-REQ-CON-004-DIRECTORY-STATE-BEFORE-CLEANUP-AND-REENTRANCY"
      "TEST-REQ-CON-004-DIRECTORY-THROW-DURING-NATIVE-READ-CLEANS-PIN"
      "TEST-REQ-MVC-004-DIRECTORY-FRESH-SNAPSHOT-FINAL-AUTHORIZATION"
      "TEST-REQ-IDX-001-DIRECTORY-PRIMARY-ABSENCE-AND-SNAPSHOT-HISTORY"
      "TEST-REQ-CON-004-DIRECTORY-BUFFER-REQUIRED-RESTARTS-IN-NEW-WORKER"
      "TEST-REQ-CON-004-DIRECTORY-FOUR-READERS-PRIVATE-OUTPUT-PINS-ZERO"
      "TEST-REQ-CON-004-DIRECTORY-THREAD-TIMEOUTS-AND-CONDITION-TRANSFER")
     :SELECTED-TEST "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
     :PRODUCT-COMPILED T :SUITE-COMPILED T :COMPILED-TARGET
     (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
      "dde814f850eae82069c02ec9348edf34" :FASL
      "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/read.fasl"
      :FASL-MD5 "46c6f5e85e0427ed069dbd44fb4d8f70")
     :COMPILED-PRODUCT
     ((:FILE "src/cache/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/build.fasl"
       :FASL-MD5 "4bfe6c9ca40f5d47c20e6c19e31110bb")
      (:FILE "src/cache/clock.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3546cf7f5c5ed138068548c20064f499" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/clock.fasl"
       :FASL-MD5 "847a21c4ad737dd883c0b616f3a881e3")
      (:FILE "src/cache/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "72f3a33ce27ddf94c49c495580520004" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/core.fasl"
       :FASL-MD5 "ddd1bbd26bdd94192fa39f06d7530dc5")
      (:FILE "src/cache/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/package.fasl"
       :FASL-MD5 "751c86c047670c376abcacde753580dc")
      (:FILE "src/cache/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82f937b7b08bd1696ad9c88da2e1c60c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/read.fasl"
       :FASL-MD5 "82c6bb29b01eee002a5dbfc45b48b18e")
      (:FILE "src/cache/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/types.fasl"
       :FASL-MD5 "c1a048471f33e39e2039bea07c22541c")
      (:FILE "src/cache/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fc09021f74fb50aac57589614dae04d7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/cache/write.fasl"
       :FASL-MD5 "fb33ef0a491d00498f66c149f5fb6fa8")
      (:FILE "src/codec/cbor-float-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-float-minimal.fasl"
       :FASL-MD5 "47288a60d0170484e1ab9cb70eb4fb2e")
      (:FILE "src/codec/cbor-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-header.fasl"
       :FASL-MD5 "1f1ad73235f62521ef87e056fe58a89c")
      (:FILE "src/codec/cbor-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ecd8fe950344059c629927b38fb6e4aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-minimal.fasl"
       :FASL-MD5 "b8a0f2ce887d14479ed9940fb856a760")
      (:FILE "src/codec/cbor-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-package.fasl"
       :FASL-MD5 "1da007b9696614510fef8002fa47552c")
      (:FILE "src/codec/cbor-scan-input.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f6488e987889432b375254021825dbe5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-input.fasl"
       :FASL-MD5 "55eb13c33270eab2eb97fa4e70f24b39")
      (:FILE "src/codec/cbor-scan-items.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "706c0baa4158bf272c4b0df17c1439d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-items.fasl"
       :FASL-MD5 "1f3fe41a99e7a6c3c215bf96c79fd3a7")
      (:FILE "src/codec/cbor-scan-minimal.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "987e8ed576a21eb644ac1ef2e06edbda" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-minimal.fasl"
       :FASL-MD5 "d52868d54b819aacb434455001d6689c")
      (:FILE "src/codec/cbor-scan-stack.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cf1999ddb10f879aeefbeea853742d57" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan-stack.fasl"
       :FASL-MD5 "79f6d878dd3999bc723b5d2a226f3e54")
      (:FILE "src/codec/cbor-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0c33aedcdb352e78a3c694cf796e6692" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-scan.fasl"
       :FASL-MD5 "7204e374fd7e727f32ed347b1bfa8355")
      (:FILE "src/codec/cbor-simple-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "200373402e6e082dd8c7afde305302bb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-simple-write.fasl"
       :FASL-MD5 "ca68804128224983b4db0ffa657e15b9")
      (:FILE "src/codec/cbor-space.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-space.fasl"
       :FASL-MD5 "e5fa81ffc7fdabbfaf9e3e880bc35d7f")
      (:FILE "src/codec/cbor-string-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b13e92b5f24a42fe283c17b649722b6a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-string-write.fasl"
       :FASL-MD5 "87ac44b85909d42d6e04f168267c96fa")
      (:FILE "src/codec/cbor-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "69e77bcd15b5413a815a65c5081229db" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/cbor-write.fasl"
       :FASL-MD5 "9ae0855dbd3a9106516d0cae3d66a6aa")
      (:FILE "src/codec/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d885bd2a9860eb60aec1a775e5031d5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/package.fasl"
       :FASL-MD5 "0790229752b1212ffad1ba6a0233be44")
      (:FILE "src/codec/utf8.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0f67dd5c51bf6a63bc292ab4e2a280c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/codec/utf8.fasl"
       :FASL-MD5 "4b0381ae81bc3699f02646c03df0989e")
      (:FILE "src/csn/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1130012fc5613a5648d22ed8628be0e8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/csn/package.fasl"
       :FASL-MD5 "df89e0f2d8156fa0f6d0365f6df0e1e7")
      (:FILE "src/csn/registry.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a1cdb5661fc54beba5bf00e4765f3235" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/csn/registry.fasl"
       :FASL-MD5 "271854be397418e55c890473584b474d")
      (:FILE "src/epochs/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "765d14c88cd288093a77a57930cd6999" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/core.fasl"
       :FASL-MD5 "fb2e1bbb0a90d2908a0be0e595f364b4")
      (:FILE "src/epochs/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "875201dfab0a84efd40fe9828cc293c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/package.fasl"
       :FASL-MD5 "093d88be07574a710910a81208989ae2")
      (:FILE "src/epochs/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/read.fasl"
       :FASL-MD5 "eacfe692cbc9d73719e79eb68ef091fd")
      (:FILE "src/epochs/reclaim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "036dd02adf87d33c3ae2f40735c733fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/reclaim.fasl"
       :FASL-MD5 "9db400e247921fd13f910509fcfd62da")
      (:FILE "src/epochs/retire.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "653b974f310c09f6e2224a84acc43bbf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/retire.fasl"
       :FASL-MD5 "6413a610cb96edf1843ac04b603b146c")
      (:FILE "src/epochs/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82253491f995f5bc153fb5ebf30d564c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/epochs/types.fasl"
       :FASL-MD5 "1666f74074ab236986896575aaae8dd6")
      (:FILE "src/execution/handoff.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "6b85eebe69366e78ed5fc5cc20735f00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/handoff.fasl"
       :FASL-MD5 "790fccb1aea0b1289a87ace23fd2dc95")
      (:FILE "src/execution/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb5710d6c111cadb7121a50998a747fa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/package.fasl"
       :FASL-MD5 "743f34ad8f74b017c501ba3202d9d139")
      (:FILE "src/execution/queue.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8202843bddb817da4279ac959ae3f3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/queue.fasl"
       :FASL-MD5 "573416ae14e77f07ba78805b9aeccc74")
      (:FILE "src/execution/ready-recycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "38d26f8c749dd946dfc4b9c57103a892" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/ready-recycle.fasl"
       :FASL-MD5 "66dc399bf2be711f9b914243bbc20c81")
      (:FILE "src/execution/ready-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/ready-types.fasl"
       :FASL-MD5 "2b2483687b78702e9b2b55f7c0cb8d56")
      (:FILE "src/execution/ready.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2c1892002f0599bb8273093031017520" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/ready.fasl"
       :FASL-MD5 "2dccea81307dbd1e91ad15d264181faa")
      (:FILE "src/execution/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c24065d6c8d80d1be53994a0041743df" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-boundary.fasl"
       :FASL-MD5 "ff8ef41e65726a8b5d45114bc976328e")
      (:FILE "src/execution/worker-claim.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "babd0a78b4185af24ae1fef870c0fabb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-claim.fasl"
       :FASL-MD5 "032637bf947c423d539a906e1f654e5d")
      (:FILE "src/execution/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "aa34ca6bc07535e35fea723878d99f66" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-run.fasl"
       :FASL-MD5 "08df52e201724b4cfb59b2a5d2210748")
      (:FILE "src/execution/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0679ee07c46f69db330706303c70d8d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/worker-types.fasl"
       :FASL-MD5 "127b3457fa3e24296361b03ca817a19d")
      (:FILE "src/execution/writer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "73019644090e2971f2b54dc36e4491f5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/execution/writer.fasl"
       :FASL-MD5 "0477b9cffb5b2f32cd41151a1341c6f8")
      (:FILE "src/foundation/batch.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/batch.fasl"
       :FASL-MD5 "b58701c5b20756ce8ff50d097f473e39")
      (:FILE "src/foundation/binary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a06115175f450776762761dce25acdb8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/binary.fasl"
       :FASL-MD5 "84529178db980a7f25996d06ac79bd7e")
      (:FILE "src/foundation/conditions.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "942b596396c19815290a57830af2121b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/conditions.fasl"
       :FASL-MD5 "cb8436c06179a6df535b6245da165926")
      (:FILE "src/foundation/crc32c.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/crc32c.fasl"
       :FASL-MD5 "34ef0b2ccae1ff3cad4c67d417143b5f")
      (:FILE "src/foundation/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5ee593a112958d94163dab17c5aa4ba2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/package.fasl"
       :FASL-MD5 "57b3060bee62fcfeec42c6d1439ef1c6")
      (:FILE "src/foundation/record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/foundation/record.fasl"
       :FASL-MD5 "908c84145efe2fb2604254bd8f2581f9")
      (:FILE "src/get-directory/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cde24b2bf5c5637d5501b95bed47df31" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/build.fasl"
       :FASL-MD5 "b643567b2f2350cd90e8c395303c7362")
      (:FILE "src/get-directory/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4233eef9d87bdec712d4f690bcb699a9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/package.fasl"
       :FASL-MD5 "734e41eb14c341823df84fb357a76ebd")
      (:FILE "src/get-directory/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "dde814f850eae82069c02ec9348edf34" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/read.fasl"
       :FASL-MD5 "46c6f5e85e0427ed069dbd44fb4d8f70")
      (:FILE "src/get-directory/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "17c957d6934a31f4ed64313e756de2d2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-directory/types.fasl"
       :FASL-MD5 "e3d808ce929cf1f6f20e5d4dceaefd27")
      (:FILE "src/get-resolver/active-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-build.fasl"
       :FASL-MD5 "c69b6fc07193795f86b26fb375a49e9c")
      (:FILE "src/get-resolver/active-directory.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "6d95f29b331d335175843f47ae44a6ea" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-directory.fasl"
       :FASL-MD5 "cb950fcba84d729769bce32d2e4183c3")
      (:FILE "src/get-resolver/active-preflight.lisp" :ROLE :PRODUCT
       :SOURCE-MD5 "f13d422adb6aa9e8489352884137f25a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-preflight.fasl"
       :FASL-MD5 "e530514c89535752027ffa7834aaf22d")
      (:FILE "src/get-resolver/active-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3da469a7aa1e682dd8f2e516ee451de1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-read.fasl"
       :FASL-MD5 "ec256c826cb68feb2d03c08a4d0c6c6c")
      (:FILE "src/get-resolver/active-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6aaec49504a96f37c8ff1bc182c977b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-scan.fasl"
       :FASL-MD5 "1f521234d4b767d7ddc6003bf3a819ec")
      (:FILE "src/get-resolver/active-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bd7182e9871fe82530d0c828e473ccde" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/active-types.fasl"
       :FASL-MD5 "83de37f2c2035129b7aef868f27fba76")
      (:FILE "src/get-resolver/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bbfb2082103e6712419e180ab972245c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/build.fasl"
       :FASL-MD5 "7e9a35a6652466c2668c11cc9b624c31")
      (:FILE "src/get-resolver/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbfb17bf1f65698fb7c7889953d02d1e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/package.fasl"
       :FASL-MD5 "0e859b9bc47447487f955b58ff643a7b")
      (:FILE "src/get-resolver/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1339edff0223dbf122f11ff0adbba61c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/read.fasl"
       :FASL-MD5 "f6e4a8ec98fbdf8eab87bf4c996a4cde")
      (:FILE "src/get-resolver/rows.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ca9002b81efd0aed9761cd1f78514762" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/rows.fasl"
       :FASL-MD5 "37c51affe3d26283bbb8d9f96d9fcd89")
      (:FILE "src/get-resolver/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/scan.fasl"
       :FASL-MD5 "57ccec1cda2793de73e2ecad88944ec6")
      (:FILE "src/get-resolver/sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d869293ba47444c4721713d955c6254" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/sort.fasl"
       :FASL-MD5 "e26a75dc152a99aba73be3f7724b1b13")
      (:FILE "src/get-resolver/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9df13bcc6908e9fa601d173a671e1ccf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get-resolver/types.fasl"
       :FASL-MD5 "7a0633935dfc827b03f0342e35a0419e")
      (:FILE "src/get/build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c5cc36884b238221cc13ca0c087ec7c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/build.fasl"
       :FASL-MD5 "cb1145a83335d158c3ea7d5e599f972c")
      (:FILE "src/get/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e70bfeddd694336bbd088e65f8761834" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/lifecycle.fasl"
       :FASL-MD5 "5c655cbd98ac17d72bd649f537611c29")
      (:FILE "src/get/lookup.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "82258ec87aca513a508bc5dee8410dd6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/lookup.fasl"
       :FASL-MD5 "1ece8ad6ef0b702c6763ed7eff186406")
      (:FILE "src/get/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c72633d15c3488699072eb610ebde7c8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/package.fasl"
       :FASL-MD5 "55c01f6e5efa2b9ff27ee4105c596be1")
      (:FILE "src/get/segment.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "811869eb6a197d3c4e26af4322e52652" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/segment.fasl"
       :FASL-MD5 "1f965d88ad4e68bc11bd14c094f1b301")
      (:FILE "src/get/target.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1b70dac05d6d2418909eb5105b808e81" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/target.fasl"
       :FASL-MD5 "1c24bfbe566e2737d94aa83761a4ad7f")
      (:FILE "src/get/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c394e5684de5e2d938991c7cb348b93c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/get/types.fasl"
       :FASL-MD5 "4874fdfc158d12864a7c6771ad6f710a")
      (:FILE "src/hash/arithmetic.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b5c51802e607e3dd22de68204baf64e9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/arithmetic.fasl"
       :FASL-MD5 "210cb3aa288be897aa6fa66994661a8d")
      (:FILE "src/hash/blocks.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bef497b9a267c7306d4100000491c814" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/blocks.fasl"
       :FASL-MD5 "2e5d597de13e6e97bc176743d7d21032")
      (:FILE "src/hash/hash64.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "886b7c08b9929283e8968831cbe5c039" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/hash64.fasl"
       :FASL-MD5 "e312cc420bc64c9dfd1a3f884d5a5636")
      (:FILE "src/hash/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d9060e41bc5252067d35e59ac70ee06" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/hash/package.fasl"
       :FASL-MD5 "8036cba79f427b98e37347a2beec68cd")
      (:FILE "src/index/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "65076c355c099b5dc73d185948d3bec4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/core.fasl"
       :FASL-MD5 "512e871535d254fca2ba3faa10370638")
      (:FILE "src/index/hash-digests.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "43d2209225707352daec6186ef95a805" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/hash-digests.fasl"
       :FASL-MD5 "4442b0da7317d01ec46075db1c351afb")
      (:FILE "src/index/hash-seed.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "45ce41749bc6fa638539815d3f802b96" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/hash-seed.fasl"
       :FASL-MD5 "21b180bc012bed65e08536b1af7bae9d")
      (:FILE "src/index/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "598a9b65e73151c924b2cdcaf6d96705" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/package.fasl"
       :FASL-MD5 "3468c1803733b0e499b893f324374e94")
      (:FILE "src/index/primary-arena.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a319691e3e28b7ea7b927de490cf69ba" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-arena.fasl"
       :FASL-MD5 "25e7a843da2bcbcb5082e8669e7991eb")
      (:FILE "src/index/primary-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff2cfbb865290d7a1510fdf6877c7229" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-build.fasl"
       :FASL-MD5 "8b03ff8fc4fbbb86d7b597aafe64ce90")
      (:FILE "src/index/primary-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fa52433eae199ceeb874bf2bc47afca7" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-core.fasl"
       :FASL-MD5 "9e7db1beff58eab77dc0fb44f7527dfa")
      (:FILE "src/index/primary-directory.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1dd67c527257e43f17e006644ecdbd00" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-directory.fasl"
       :FASL-MD5 "f9095c4bf9b930b407266ce170c7640f")
      (:FILE "src/index/primary-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d65cfce399b04f905bf969929962e59a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-package.fasl"
       :FASL-MD5 "092b72e4e226ea219d03136385cf7f41")
      (:FILE "src/index/primary-probe.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-probe.fasl"
       :FASL-MD5 "140d0ef49f81dc8f4179a5ce83224f86")
      (:FILE "src/index/primary-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3f317a0d3c5ee86a73651aad36135cc3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-read.fasl"
       :FASL-MD5 "9a714be99da10f2aa6c7579e6ce3ab5c")
      (:FILE "src/index/primary-relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5155959766645d3172ae5e73c58cc071" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-relocate.fasl"
       :FASL-MD5 "9101c7898b1201e4671f139a1c79f358")
      (:FILE "src/index/primary-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-types.fasl"
       :FASL-MD5 "d2cd71a94dcbc3af89e2150e0499fff5")
      (:FILE "src/index/primary-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e8e31e599356e592af29c0cc4604872b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/primary-write.fasl"
       :FASL-MD5 "c005637e592895a5d6258cfcaf3f747d")
      (:FILE "src/index/read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5b22b90cfe8534086f6aff96d156713e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/read.fasl"
       :FASL-MD5 "d342cef626c9e5d143eeda9beeab77c0")
      (:FILE "src/index/rebuild-budget.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild-budget.fasl"
       :FASL-MD5 "36aefe1d623364ed414f03ecdc9705ec")
      (:FILE "src/index/rebuild-copy.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8befbbd00ed5c31c1487a11887eba495" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild-copy.fasl"
       :FASL-MD5 "d61b826d05a05d4472f1e41cf3e58ddc")
      (:FILE "src/index/rebuild-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1188e7a64a7a5d9482c1233cb9acb452" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild-scan.fasl"
       :FASL-MD5 "c2a7e9912a4dbccfde82638d1b6fc2e6")
      (:FILE "src/index/rebuild.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a450cac8071513365267e7024cbe94b0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/rebuild.fasl"
       :FASL-MD5 "d83a690d9f3ca330d8335b1211181c3c")
      (:FILE "src/index/relocate.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475dd7d5809a836f01544b447cc8df27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/relocate.fasl"
       :FASL-MD5 "2fba7739a90d64436367b7035afbb51f")
      (:FILE "src/index/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "5157fd03ee806ee998ad8f0002d56268" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/types.fasl"
       :FASL-MD5 "0b361fc4b9afabba5c7677ddcf2a2788")
      (:FILE "src/index/validation.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "3384cadf737c7d80c004222022a281f6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/validation.fasl"
       :FASL-MD5 "29e549e4d8963f98e28a9ae7f9dd56ec")
      (:FILE "src/index/write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/index/write.fasl"
       :FASL-MD5 "5a28df9380bba3a081231bfa0582af17")
      (:FILE "src/io/flush.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "716866194d6b9f076e102e84187229c0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/flush.fasl"
       :FASL-MD5 "c45f65dae49db0bdcbc76af7647a731a")
      (:FILE "src/io/lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "11c7103efbe733bbf0a13927f23c3d34" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/lifecycle.fasl"
       :FASL-MD5 "777b4c27aa41f84e7eff48f37baab9c7")
      (:FILE "src/io/native.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9500cfb800603de002d6d2b24f1bf056" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/native.fasl"
       :FASL-MD5 "8eec9ad0419f4ca2bbc59d94b38b7c82")
      (:FILE "src/io/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c9380ad46a1d7acf41655aaed20db478" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/package.fasl"
       :FASL-MD5 "9a51c6da859f95c5c932a9e9569e9ea2")
      (:FILE "src/io/transfer.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a5e7108e80664eb3b562fbd7e680801f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/transfer.fasl"
       :FASL-MD5 "e49efb62eae361271ad6994618528b83")
      (:FILE "src/io/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "db8497f9cff35b1ee261f1f410f46ca6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/io/types.fasl"
       :FASL-MD5 "097f90cba7c86c097ee04fdd0ae5596b")
      (:FILE "src/mvcc/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f188d1dbd5d0adb49f53acf09157aef9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/package.fasl"
       :FASL-MD5 "cbbae61dcd0dee8cf26fd56061590caa")
      (:FILE "src/mvcc/snapshots-core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8bb066aab61a18eff175b9edb11e42a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-core.fasl"
       :FASL-MD5 "ad55c43202a533809b3e75733112bd29")
      (:FILE "src/mvcc/snapshots-csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "0e9365e674d1584b111f915ce1f58634" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-csn.fasl"
       :FASL-MD5 "b9b3e415f76bd9c03c8861264c6a57ca")
      (:FILE "src/mvcc/snapshots-lifecycle.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ff98aea5cb9a7ae2671f6a887a003725" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-lifecycle.fasl"
       :FASL-MD5 "bcac2f4606cb6de7a95cadd5556d05ae")
      (:FILE "src/mvcc/snapshots-read.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-read.fasl"
       :FASL-MD5 "47b47c94a15e2c842dd5fc98bd973a82")
      (:FILE "src/mvcc/snapshots-register.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2d5a795bcefd605c75da91c725ae83a2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-register.fasl"
       :FASL-MD5 "2860e7e94c49efad48ea1e90c05acbd2")
      (:FILE "src/mvcc/snapshots-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/snapshots-types.fasl"
       :FASL-MD5 "695e3f39d4cc4e046443f030eaaea65e")
      (:FILE "src/mvcc/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a9bc70eab6720b5c6f8503178e2c966b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/mvcc/types.fasl"
       :FASL-MD5 "f80d43006b5118b7351e4f26d656adf8")
      (:FILE "src/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "becf5c78049c85f2c05cd1ef54454032" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/package.fasl"
       :FASL-MD5 "1fbf59d226dd3ed20f58be940b2f9638")
      (:FILE "src/read/core.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "4040905f4a64ba704a480d82e87ec748" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/core.fasl"
       :FASL-MD5 "1f9e545f2238339f210638351b927ed4")
      (:FILE "src/read/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/package.fasl"
       :FASL-MD5 "6e3ee417bba0fc7dc70be30babe51b63")
      (:FILE "src/read/task.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9e0baf22c53329d393e047c669679645" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/task.fasl"
       :FASL-MD5 "c5c3a205d2dffff692ecb7ffe5999870")
      (:FILE "src/read/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9c37ff8237fcc9fe9ae4f44316e854e3" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/read/types.fasl"
       :FASL-MD5 "5fffbb0b18e82090d8739868857f9b82")
      (:FILE "src/recovery/decisions-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-build.fasl"
       :FASL-MD5 "79cd063a2392225a47494187f53498d8")
      (:FILE "src/recovery/decisions-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cbdc30f93109c474e1fc25066c9b9b13" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-package.fasl"
       :FASL-MD5 "1da43c3cc7157c18a132126bcf339dd2")
      (:FILE "src/recovery/decisions-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f782d1137b8ce342b91c9999cfb7accc" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-query.fasl"
       :FASL-MD5 "451697bbae6b6077220fac282ae4f4e4")
      (:FILE "src/recovery/decisions-radix.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "852149de4c289b8e067602780378d87a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-radix.fasl"
       :FASL-MD5 "c18f9bea49d626a78903d2db3ce6de82")
      (:FILE "src/recovery/decisions-sort.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b33e57a643f2fca810846f6226366253" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-sort.fasl"
       :FASL-MD5 "485a9ba8109ae9df685c3b7347276655")
      (:FILE "src/recovery/decisions-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/decisions-types.fasl"
       :FASL-MD5 "1cce49fa37e590cef03d3f64ef5967df")
      (:FILE "src/recovery/inventory-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "9bd6820c4feba3e552aab1a4edd87861" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/inventory-build.fasl"
       :FASL-MD5 "877c307aa1ec9ec15d252c3b13a72ea1")
      (:FILE "src/recovery/inventory-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcea263de1938767772e5b11411ecd5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/inventory-query.fasl"
       :FASL-MD5 "2e151ae56d9805663cff504cf94a60ed")
      (:FILE "src/recovery/inventory-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "78c136d5838dcfe3019d9069643a8d8f" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/inventory-types.fasl"
       :FASL-MD5 "273cce396631867d9dfb6b91896dc4fd")
      (:FILE "src/recovery/manifest-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "bf65b1731eab6e0572461ef5cc60fc40" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-build.fasl"
       :FASL-MD5 "8a9ba850ed5ab4def4c1859668baa5d2")
      (:FILE "src/recovery/manifest-decode.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "67975249aaabd751757cdfb9222cc3c4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-decode.fasl"
       :FASL-MD5 "06decaeebc1b295055e326fdcbc5cac9")
      (:FILE "src/recovery/manifest-fold.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0d2498db1011e857b7b0daa1934f187" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-fold.fasl"
       :FASL-MD5 "9b49927ad1cac09804b79dcb2d8a39cb")
      (:FILE "src/recovery/manifest-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "37ace42844c11b52446ee1fc500b8e0b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-package.fasl"
       :FASL-MD5 "a2006c80b0f584d5da029e1de03842fc")
      (:FILE "src/recovery/manifest-query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ebd7a54adea2213294a887e6d4db0927" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-query.fasl"
       :FASL-MD5 "80bb7dca6dbc6e5d0b701d34781724f6")
      (:FILE "src/recovery/manifest-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/manifest-types.fasl"
       :FASL-MD5 "f5213b6e55425389d99b117f044efa9f")
      (:FILE "src/recovery/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/package.fasl"
       :FASL-MD5 "cc7d1d8fad85ce9ecec2dc7f4cc3a258")
      (:FILE "src/recovery/scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "fcacd15460db25ea9cc4036065f9f096" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/recovery/scan.fasl"
       :FASL-MD5 "c043180d3c4877dde6e476b6b74294ad")
      (:FILE "src/series/events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "32b2156739a6f2ca996abb91df0a2603" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/events.fasl"
       :FASL-MD5 "13bcb02d15386a52c2ae217f148bd243")
      (:FILE "src/series/io-events.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b6026a8b7bb64b45c37a65effda70d8e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/io-events.fasl"
       :FASL-MD5 "9c372355628d46eff534f120001f7445")
      (:FILE "src/series/ownership.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "de1aca16a35d34d16aba12ff541c0d2b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/ownership.fasl"
       :FASL-MD5 "40d3ef58a2843ee533a88cb549467d20")
      (:FILE "src/series/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "59e3c59c90d8d0fc5731b87496a785aa" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/package.fasl"
       :FASL-MD5 "3e399a0a31474150e6c3a07555f80fe2")
      (:FILE "src/series/publication.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/publication.fasl"
       :FASL-MD5 "923e9420f9ec613465b50f50bb033e9a")
      (:FILE "src/series/query.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb0d91405325b508e6b2ab24d178de7a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/query.fasl"
       :FASL-MD5 "812b2011f0aef8e7a81f2ff20eea1e67")
      (:FILE "src/series/retirement.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b8e04971b8ad75a1bd0c722997badfd2" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/retirement.fasl"
       :FASL-MD5 "8037675dcbb048a36f57d4bea01a557a")
      (:FILE "src/series/routing-build.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6924deff152b941bd49f0bb200b4197" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/routing-build.fasl"
       :FASL-MD5 "dc274a460f33c3095e2dccb2526a64e4")
      (:FILE "src/series/routing-select.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "e0f987d8767744050ec4d1b3ecb699ed" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/routing-select.fasl"
       :FASL-MD5 "d93dce82bf7074d5e091ed5775efbae3")
      (:FILE "src/series/routing-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ce649df47dd38888d5103c98345f7e41" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/routing-types.fasl"
       :FASL-MD5 "190c2d3283db2fc49ce47c33aaf0950f")
      (:FILE "src/series/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "ab19ec8d15af91511e817858c41cebc8" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/types.fasl"
       :FASL-MD5 "51d47b6777c994823399d4fc1a50cd81")
      (:FILE "src/series/worker-boundary.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2340e0c9074f7b1bf80c74f774986bc5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-boundary.fasl"
       :FASL-MD5 "d2b0b1913419426953728b7974ed3188")
      (:FILE "src/series/worker-package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-package.fasl"
       :FASL-MD5 "899f5066dd98a46e8199b0e33218354b")
      (:FILE "src/series/worker-run.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-run.fasl"
       :FASL-MD5 "9ab78a227872472ddcd06209467cc1c7")
      (:FILE "src/series/worker-types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/series/worker-types.fasl"
       :FASL-MD5 "c6d49ca15f18a4d7bd25101f2ce26798")
      (:FILE "src/storage/compaction-scan.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "1cda77a357ab2147035993b72d135a37" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/compaction-scan.fasl"
       :FASL-MD5 "f2460eb373451c70099962915e216beb")
      (:FILE "src/storage/control-payload.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "cb64f806b8d69eb42d865b4abfff0b27" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/control-payload.fasl"
       :FASL-MD5 "437bc0bb08c6c12a70e25526e825b981")
      (:FILE "src/storage/formats.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "061147be459d8d3b08c661bd3f91d152" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/formats.fasl"
       :FASL-MD5 "b09ec9d2c4f766b908a711df0ade76b5")
      (:FILE "src/storage/log-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "b53d27dcc9f4badf18b50519c50bc614" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/log-header.fasl"
       :FASL-MD5 "667c2e773ada0bb636b95d96dc5a63ef")
      (:FILE "src/storage/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f86bd104f20616a76b42c02227f72844" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/package.fasl"
       :FASL-MD5 "8aab472c42598e5c4e7e27c77f2156dc")
      (:FILE "src/storage/payload-record.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/payload-record.fasl"
       :FASL-MD5 "5f81ec32e737f65c014ca83d02c364c6")
      (:FILE "src/storage/payload-write.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/payload-write.fasl"
       :FASL-MD5 "99376d8d3d16dc69ec90edb1d947c2b7")
      (:FILE "src/storage/segment-header.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/storage/segment-header.fasl"
       :FASL-MD5 "d31d333b5b38fd8e667b69b164262573")
      (:FILE "src/wal/builder.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "a229f76f7036f3573a6e528dcd390a19" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/builder.fasl"
       :FASL-MD5 "9205732cf67cbfd873aef516803cc77f")
      (:FILE "src/wal/csn.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "42b990e3b254e6fb488c0ab91b6a6502" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/csn.fasl"
       :FASL-MD5 "0d4717caea32f54e2aa484a8c94dfe71")
      (:FILE "src/wal/executor.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "c0340924c9130e14d0e8efedeec078f1" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/executor.fasl"
       :FASL-MD5 "12e66a3f72f728a1cdc29b351acd4162")
      (:FILE "src/wal/group.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "7a0e7c99ab70b4720cbb091156560f5e" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/group.fasl"
       :FASL-MD5 "72fa5a80283c1fd2744c1b6952eb1e8b")
      (:FILE "src/wal/package.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "96c41b1d417135a24fc65659ea3abe11" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/package.fasl"
       :FASL-MD5 "2411728a39980c94c6cfd5698f081fdc")
      (:FILE "src/wal/types.lisp" :ROLE :PRODUCT :SOURCE-MD5
       "f799f27a8ac1a4c736c04796c1e543f9" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/src/wal/types.fasl"
       :FASL-MD5 "8a9af505a0a250812c6602c6a85dd902"))
     :COMPILED-SUITE
     ((:FILE "tests/foundation/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "758adad069aec2f9dbe0635797314ff6" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/tests/foundation/support.fasl"
       :FASL-MD5 "1835a9ca68c5b3643b4290db2c7def41")
      (:FILE "tests/get-directory/support.lisp" :ROLE :SUITE :SOURCE-MD5
       "3f868ebe4307ad4238b314c37eceed9a" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/support.fasl"
       :FASL-MD5 "3b63b0601dcfd4195759da604e189642")
      (:FILE "tests/get-directory/construction.lisp" :ROLE :SUITE :SOURCE-MD5
       "1137938073e71d6d8d62c751fbad05d5" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/construction.fasl"
       :FASL-MD5 "23bb70339481a8a3e6c05b5b1edb4ba8")
      (:FILE "tests/get-directory/read.lisp" :ROLE :SUITE :SOURCE-MD5
       "d1ab36d05cc1266e4533d27c693f12f4" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/read.fasl"
       :FASL-MD5 "3669fb1f4ef1374f7aa3f121678aabd9")
      (:FILE "tests/get-directory/threads.lisp" :ROLE :SUITE :SOURCE-MD5
       "63dd01c852de1399c2c82274d481d257" :FASL
       "/Users/gpicchiarelli/.codex/worktrees/get-directory/ArcDocDB/spikes/out/get-directory-mutations-g/raw/isolatedtests/bypass-closed-resolver/fasl/tests/get-directory/threads.fasl"
       :FASL-MD5 "66ab11b2e3c8401ad49fd6b9d985f1ad"))
     :FAILED-TEST "TEST-REQ-IDX-001-DIRECTORY-CANDIDATE-SIZE-AND-HIGHBITS"
     :PASSED-TESTS NIL :FAILURE-KIND :ASSERTION :CONDITION-TYPE "SIMPLE-ERROR"
     :DIAGNOSTIC "Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (ARCDOCDB.GET.DIRECTORY:RISOLVI-CANDIDATO-DIRECTORY-GET
                       ARCDOCDB.GET.DIRECTORY.TESTS::CONTEXT
                       (ARCDOCDB.GET.DIRECTORY.TESTS:DIRECTORY-FIXTURE-DIRECTORY
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVARIANT-VIOLATION (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :RESOLVER-CANDIDATE-SIZE)))"))
   :DETAIL NIL :RUNNER-MD5
   #A((32) BASE-CHAR . "5abd0c88793c21103e61d4c4d326d024") :TARGET-SOURCE-MD5
   #A((32) BASE-CHAR . "dde814f850eae82069c02ec9348edf34") :ARTIFACTS-VERIFIED
   T))
 :COUNTERS
 (:DETECTED 5 :SURVIVED 0 :BASELINE-PASSED 1 :BASELINE-FAILED 0
  :COMPILATION-ERROR 0 :INFRASTRUCTURE-ERROR 0 :INVALID 0 :NOT-RUN 0 :PENDING
  0)
 :DETECTED 5 :SURVIVED 0 :COMPILATION-ERRORS 0 :INFRASTRUCTURE-ERRORS 0
 :INVALID-RESULTS 0 :SOURCE-CONSISTENCY :STABLE :LIMITS
 (:ONLY-DIRECTORY-BUILD-READ-MUTATED :CLOSED-ONLY
  :ONLY-DIRECTORY-SUITE-EXECUTED :FOUNDATION-SUPPORT-DEFINITIONS-ONLY
  :ALL-PRODUCT-SOURCES-COMPILED :FRESH-CHILD-PRIVATE-ASDF-OUTPUT
  :SOURCE-AND-FASL-MD5-ATTESTATION :ONE-NAMED-TEST-PER-MUTANT
  :ASSERTIONS-AND-PRODUCT-CONDITIONS-SEPARATED
  :COMPILER-FIXTURE-IO-TIMEOUT-CRASH-AND-TYPE-ERRORS-ARE-NOT-KILLS
  :PARTIAL-COPIES-AND-LOGS-RETAINED :BOUNDED-CLEANUP :NO-ENGINE-QUALIFICATION))
