(:SOURCE-CONSISTENCY :STABLE :SOURCE-BLOBS-AFTER
 ((:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "0241da912be93fdf70b9a9749b759efc17aca329")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "30f2e951591f8822ce780f77cfa9c4ab93f0a98b")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "8f682f6ff22f6a0c1847b71be3994e628d399a77")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "d654f504cacdfbe7e144a074e0c2aba5ff2f4b31")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "b239b5187a2649125b7429273cb0fe4f4cba673b")
  (:PATH ".gitignore" :GIT-BLOB "19bf1ab91a6ed3c89cfff48070fb170b09679360")
  (:PATH "CHANGELOG.md" :GIT-BLOB "2fc0d78d84bacb4ffcfed3877697e5475724fb58")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bb642c10cc99a2a8d62cc101ec1c6e9903ec1441")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "5820eb0ee2f06bc024e238afe12106b0e74275dc")
  (:PATH "README.md" :GIT-BLOB "99958454de32ddbc01794b0817781c287cf4c0d6")
  (:PATH "SECURITY.md" :GIT-BLOB "27fb94691a84b389d72184838e38d2e43a8fcfbb")
  (:PATH "arcdocdb.asd" :GIT-BLOB "18edc6e4701765c456241b14443949ccac03ce91")
  (:PATH "assets/README.md" :GIT-BLOB
   "933cfee445a3fe85c8b9ca8c7c4e48afda9bdc95")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "0e9fe71b160f4ff7fcc61c9695159b00e352b12e")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "de51c5d5d625caf2ba89581880a7e932a86d2556")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "9ac19a17e0c095ed711eeb2a9da52b4965d3c481")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "b6dcf61865707b01724190e83c4987aa5d98762f")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "0c81882c35757d460e55f808fc6d2370f845550d")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "d65d5b12f248347430260c6671017a0894ebd3eb")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "2713de877ed961857868b53bcc346fe62088ec0e")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "b0e2afc520b8ea9a540f0605f682c1182b5af3ab")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "2e83c526df9864f1c3d2373fd313e4ea61d29fde")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "39cf33413347ccc9d91478efc1c08355908c23c9")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "3eab0ad4c56c1744c456579c8e773c5d7fe7493a")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "6616ed0cfadc71596ae3162affdef4f75f608de5")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "0f702230f39f3b4761886499d99b2eb431514908")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "07b5adf23d044b552d5e038adacf194774dfcf40")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "b92eea4011a182108002786370c8330e8271e356")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "db87b7732e2e42f22c711a89f5deae97f5f00757")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "1b845787d56dbc1296e7283f809e1be1bd0d3b80")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "826a6f1d12e37dd26893598caca3889010be7480")
  (:PATH "docs/README.md" :GIT-BLOB "303b4a009be18ad5f03ef990156ca0e145914fb2")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "88eeb77497b6d6124010ad65a71b98e08743131e")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "a4d7157123f6cad4b92d3722e136bd02f15fa138")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "fe20638b50dffc66f5d5b3497f00e5f526ea046a")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "2b9f1e16b289ec754c0ac0de79e7823852c4815a")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "4af05ad11f846d733b3485bfdabac47535f41415")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "ac6e1e0f042e6ce5622c0b579ff8d0419a707980")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "ad70fc5e177886b0be609ebc0234c0c7c2fbab90")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "7e6590a619252983120f8ef9b5b3fba5bf24659f")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "5ae6feb439b1d182febe27d16e6d485183150d6a")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "18de49d285e52d25e055397f47c829ba7db45500")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "2f04c342ca714f0638dfdf2bed17fe48de54edc9")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "1a86df3d58358950d8b658b6b8194563288fd0c8")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "99ca666f07f0f04168af74c55459ca76a6f421c7")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "3ca2df1c7beddedd65511d9282a547294cabbff4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "87931cd80f665581fc43a2b02fc6738ea3d57fb3")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "001950113b1fc347642e1939ef060d93a54096e5")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "5a442b2aeb665be3f23da887ff615bef889e167d")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "250c272e2ddaa4b062b956d5ab3eb66ce610b44a")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "be9686df1c7ecb762bebac602bab12010d73d0b9")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "6fff5ed7db6d11a51f12b167636b7a23a3750068")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "83c6cae3eb56b9edfda572533258d8438132e0ae")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "81823c873cf52abafd86a3e8ab35df2e161d1034")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "623209aef44929e1b8397b1f8470dffc20d9bbf8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "bc3d2144b30022e7ab239c561b6986a18e10ec8c")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "470ef1b7f52d571ea5af046ccf06896729a06a13")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "24235615cfaab3821cc38bc9b9979a9928c6dee9")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "8c29d6d4d55cbc7226c2df7361a3d7220c103f8f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "225aa16313ca4b54a04da07851f0824c2494543a")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "506080464430c1b9e5f2b09816d186ca95e3fcc9")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "328152db463a6e5796435ccd3867d8838429df15")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "b9dae81c93e124b6db129e90fb641c85ca349c93")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "dc8228d1c2dc5e01fa6a5cb6c69ec9e8648427d2")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "fc947bb28bdf5a015d7b353f56e0d6fb86a524c6")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "4646cd378729d3841b8419b3681477b4e1a80816")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "dfeef8dd42d465d1c97830bd6f8304d3f8579416")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "eb3138e9017cc95b7f71fb29ec3a21e4bc44a3c3")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "d4140bc0d14bee6ca7480e94fa96bd8c79e656fd")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "aadf427743cc9b511c4fac4952ec1335005b5568")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "fce6228c1a393557b2475a7600cc998246de97d0")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "c347b791cfa1e13319894e5c2a9c3c20527a7047")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "77640ef6687df0ba7a570b682000bd4b2fa042cc")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c571f195148361a34fa6bc9d1c6f35836742ab11")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "ba7550dfd1890a483f313610cadc808142bdddeb")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "1f07f3d9c4a9a1b6a0c1250dc09923966b2081d3")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "3ada528fa148db73ca09df933265ff82a5e0dd6b")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "75301c4284016be1da4f6f7a9e4b8a1c00b1fe8c")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2ebb221d1f2e8666fa62910f561728eb6ee0a9f3")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "4c11a9e20d9d7bf315bf7623740addd876019d77")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "f36aeeeab161774fce91906d1ba5d47e6b1a8636")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "47b35236825274bd340b61e4c30b7b38d8349d5a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "f393c09cc917be5e4a123befca7bdd3f238ad8eb")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "123524e58806fe8cee2727e5ada0b00561583a76")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "817f3f72a09e74d142b160bd8da172b459f327f9")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "0cb9800d4e89438f0ba2e9ecdf763245f0768196")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "83dd5fe0d9323805d7e97e6814129d16841efb80")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "c031db7bad8fa2f115938e3699e6ce01bc436bec")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "fdb928d6caf051a0341c162d537ca5d6351acfd9")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "61f400316607e9c47904680e6730c3034ba5897a")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "ebb3e21821c8b3d53a40a3bb6594b5c9ae20fc50")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "7800931fe3bc4c8204cd873ccc0ec8ed42af8b50")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "7028bc0b2b30b0ad17f9bbae81590519d3775e73")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "13ec9283f25316675f7bbbc2e95d80ed18469da1")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "80f4576d4e5afecdabdc3620771fc573e4ca9c4a")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "7137f05ec0a8e6cd345a00fda62be573855da3b4")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "2d883ca7e34a8b31f88930e0d266ec0a094e6b0a")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "4598d73762c03c81d489050db655ff29de7b35fd")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "00a1f025a375559acf548fb855c59d42e4a21642")
  (:PATH "docs/implementazione/associazione-file.md" :GIT-BLOB
   "7f46537f9196d5ce884a7010ee2c33caf223db7d")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "173b91ac893a1bafe8d16ddb91b99dd6341c1a01")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c8182641591fa6f24bddedca56f92145a3c7a038")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "b8b2b37a18cb4d01815e07df5e64e763f273a9d0")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "325784adbb5cff4121559fd3d50a1ef943443434")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "bc95228574813d37b27882f24713e4d834788dd2")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "69bf38c64b527b5aeec011f9fe49d9fd3c31d253")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "9eb64c8428b638f6c0c1f0aaa80c4dbfd0f900b7")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "e39571136cad9d563a933aa608c011b887f17260")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "a83c5cc798dfb87750030781d015eeda260c4ac0")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "245f95c99a4735fd40a1d9694b4a5826f5ccb5d6")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "9f6526bf5c135cf43289127c4c1bc5dfdcbb8114")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "162cd32188a030d6cc3c5d16585054aa36055175")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "4af8109f8d01f1107791836371720802876ae775")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "2a9e7f0bf30460b3b7dbbbc1c7776c9259fe545d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "3935fc5225836a0669664701921ad1bfff3d443e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "8ba7e4ba06ca958c0be9a5e1128c63419aa7577a")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "a83375d3c09898353fc0173f3171884f92319d73")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "d379ed246db14204b7632b7b3c31266bfcd46b1e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "ba4d2ed61bf06d0504bb1e0067c8741ef45cc4e0")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "8966ac0cdf66fcefd616201cc97017d384b3f0a8")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "cd2f1ef9dfcd3f9029549430c21ec553509a62fc")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "81675040c1c6155f7e3efa669ca62ed4b8a63064")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "d8b22e42e7ab906488cef72d935b71d4a83ba499")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "6b4a59954e2d48cc30a044b57cfe43b0b91ae1e8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "7d44d58d7de6c62b2206a8e35be398bc34811663")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "9605de0679e062361f80c5654c5fbb8028765008")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "8b79dfa3b7cf5011b66534d02c2a4551232d503c")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "e9007f26d323a1ffd2993c461c3f84ad2aee90bc")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "a25b46457201e1a7885cc9b21cfb3e66267ec12c")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "a9e2e9dc6d0d4b968a9940d78abf8ca2de825e98")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "5d0aacab996dc47e2d479d505604d6eda5d42ea2")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "3ec66f8edebd79a128969e0b398e7700a2b1c5cd")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "46a0480b0bc29938f8654ce8f59cdaee5b720a4a")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e8864f7c0124f86cebdcdbcb2449800e078e1cc8")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "d276363cd59d6d1a914a6055b27edce016122323")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "94d950c644e849103eecb0d74c053df4aa1473dd")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "47cfd5c96e2150c42a2a7b716bef117090b0cd86")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "f5817e4d931148aa4f526b93066ab9d1b4bdf783")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "0a3a2123e618a8ff39e86dbbb70db36ccf51b133")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "2df0a214fc5cfe64ceb239aab4f7d2a2d1827305")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "1c1d617e19c0d74199ef11a56105d3ed90eb0ec0")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "56342dae95caf8705e0b28b3c0ea7ac86fdd8fa0")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "90bac509af0aff7b7085a2239de6e9dfddfc70ba")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "cbcfdba7c5967d5d36e5d9487f6a7b1ab0300a53")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "278d9413eab7578c99a07b1c614db37c83141097")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "8e1b0d0d6066669e1ffb65d95900a3b1aa385c51")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "c9808d48a01444ff6faddf2d8389673f91598db4")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "6b2909a5f56212947dea864584d2f96252fe1b1a")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "f0a2791f988b0d0c513629824f75ce1842fe059a")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "cebaf33e7e7cde4efbcbc2ada22fd494577c9e81")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "7b22c788ecf0d69f84316f39d2f580bfadb7b91f")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "76509dd8d44a61eff9129d08fb19c289d57fd1e8")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "93f1366c17eca13f37f63927d64779f7afeae658")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "a48d5b525d2c78fef0399666ebb14c6f8a2342e8")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "8dfa1cf8533764fdd89014f31cac59d02b248e2e")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "759b72a96a099d18fd353ef8936d63481e25129c")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "b28934a0a4eac77562b07fa8db796c167176ef36")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4a2c524c6b1c7be1c1b5d7e43d35d385ee7f5b1d")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "f6cadf13877cab21d869993f33e485f1af116806")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "8dbbd94b11ca62b266df8e1b58ef8b15487dde9f")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "2e1d7abdfe9b4880682ff1da97b526e180d01370")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "0264c59fce79fd2a9f34d05f85c8dfff5fed69be")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "a2a8d5bba2c3da3ad6977d6a6f750e468d229693")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "1aafc63fa8904a8504ec6fd42d34b606d6505677")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "ac23ebc4c1d6ab57116def02bf4ad7df115394d1")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "8fe4debab581640b3d1db74b6fa43610c8e547d2")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "a3d67947dafc891946df3ea19706d32d67b24a80")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "bc99cae302da8bb90c208cfc0d5def111e945269")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "79755fdc3fcc8cdc8459d0cf3d108d06e577bf3f")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "c3467fd1f58d977797821581ff127bfb2cfdd5cf")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "a0953cd3789ec80e22ec33f445510db6769ad2ed")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "4474e5ced93e129bae0ae13255e2c56363334f20")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "5f8fa54b5df938dc51ea2053298baa58413d7e5a")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "4434a2412cbcc6bab1bc5292331eb2c2eeabeb6a")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "ae05757ce562c9b2eb5632765cc9da4db8c2fe56")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "96a9d6be3614715a434ecfec5808375e06ff6468")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "a64f148cb2254e87c649bb16e7bee39aa45eb40d")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "a1631f582d8b3ecaa177cccead8c1e3d0051a822")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "30775c49aefcef182145497ee2c91e7f9ce6cf93")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "69e50510426fa53d230b64b89da9e64fdc5c6efa")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "542584f7ea490cc7b4639ee42969c17f52a8e559")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "204a995d2152620792e923275de5abcc5e29bfb3")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "550afaffd56bdaa4b5a16337432ec9ccf655d377")
  (:PATH "docs/implementazione/get-fonti-serie-metodo.md" :GIT-BLOB
   "76ca65cb32040dcf98ca9599d40dfb2f1d4a217e")
  (:PATH "docs/implementazione/get-fonti-serie-revisione.md" :GIT-BLOB
   "a8ac6d02893d0fc74093c1fe42319cdef8adbe4f")
  (:PATH "docs/implementazione/get-fonti-serie.md" :GIT-BLOB
   "678bea348d7c7cd6c3eca0b8e0cd2bd4d9450240")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "ee84732af73d4d753b211bd9cd33f9c7dd1d2a3f")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "3932b391102e3b7e0ead521a1fb223ef5ca2129a")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "058623adabd6a98f7d7617c4c1ac4fd0b7bce825")
  (:PATH "docs/implementazione/get-resolver-metodo.md" :GIT-BLOB
   "31b568cfe4db29d5d4c6d6d4de82dd0f54747f23")
  (:PATH "docs/implementazione/get-resolver-verifica.md" :GIT-BLOB
   "7751ad4582bf2d9b5402c2430c2aaeb5a6d713bf")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "a991a37b6a5460941170bce7d951eb86888abe4f")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "acc39ebcd47f56d31d5ddcf9843ebf8543424f22")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "a6b480a9726002150f65443b9a3c97c9039f2012")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "c799f6cd5399c37daa1687cd0d154ebcfac2cb39")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "d9de17c5fcd7e7f21555c68db8f3eaa7d7e1b158")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "b7c4c84c6d688015a43f81b476e58744fbf5d467")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "f103ded38e6cb575820d7fb89d72e47b9fc16693")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "d09dc4f0914935805770cf148cfab99b1ca30eb1")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "ac29588884b2f12f2bd67a72f04504d88c2d44a0")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "d4382b97ee69a12235f4c1d445b9b13dd5440684")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "4dc9aa9bdfdd5e21a2ef2bf6ab6fc8d2e111a586")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "c88785115dfda86f3e6ce425487638fe514f0e3b")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "1950d3f3b38736f7d32e1c3a24fb217bd1dffc86")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "a220b68f94b35c81b9bca4420453c4057eded097")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "37ff4f5316483960508fa78df1f890ebaff8942e")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "27cb98d6bf753515b880d7b09e8069302a0e72d2")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "476e35fca8858a4a4eed163e4a3a42c7ce38bd4a")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "550c69493fdb363631b83dea4fff765119b6ad5f")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "a1b3490342f3a234595cb1c237061def91b67d0f")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "656e8162bd3833268a6243e136c2e46b39e548f5")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "f779f81d41748e3e9b10596dc9af12b334d4dc23")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "f755abc620aaad10470143418702e883baf2493a")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "6b39b77b28e576610308a9d98e540df64e28555d")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "cb473b09149385d5d32bb44db1478e5ba7da7640")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "23966839673d2e5931f1822c0c2e0302a189911a")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "1b746fefc25d8cd1be1bb44611c7ac5f98e8acb1")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "c451a24e86e98a2dd3a75cfbae55260625b33dc8")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "096b16489aa910182fe01349aa5552ccc1ccd446")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "f77e4acc65f3582d76bee6867e7a728757a98d4c")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "b6c4a6992ef5ca707c19e08dfbdc7d1e01e1e900")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "6fbe1f002e3e18df09a964292f27c3657bb46004")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "b275c083f9705d1ed32b4cf282fd0c12c39d98a2")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "3c2423f187253e7c2c83b3848c7efbd43d269641")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "c7780a6798cec4964badc6a5529508898ae4945c")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "bbc3431b5872adfdee0e23d566caf7d2172a971a")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "8101b2da12ae1a60a0663b11ab70590a96c5bcf2")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "99cf34e5c5c3875ed97414c30ec9b7bef96d30b4")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "0a534e557a3fe8216e0d5fbfc84c354255d081ac")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "d17e9e45a1d4896249d11f2bd474aa05af5222cb")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "805c6b231d9fd7223ef1b149e75e9c3be0dd0859")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "d6e2ad12c278d5bb26050c056df4342671c590f5")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "77d0c406a967ebe97f81781f9dd4cc9d68488ee4")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "1798cdf9b8916ba74b21d1d86442a49874938e41")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "bc3121e6274d610f56155a1e159d0a8948ee87c5")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "73bfef0b478f57c9441a6d0e2ab59c0e7f223fef")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "89a767f226693292d6a934970010d6dc5f13bbe7")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "d7e1f6e6fd5baa3c0c345507b8c3cd7a71e47f33")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "497b96ba252c1d223b91c7a958af3a1de6e6bba9")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "4b9535873216af6a4ede0b3d6d31e80c466ad395")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "6c46cebd54cacfe7b366932d1be6bd2132346087")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "c9ec2a33ac47f9811f152032cc6232fb1ccb941a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "9cfa2d91655890f50c7a0d83cb14f0bbae650f21")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "08c866115be68fd9e88c2d30fd111017851bbb53")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "df02aed3cd659b1b09e746d8315f54e32f526965")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "2d2ffb30c9051c58fd7f9b7efb27a487d1c0fd8e")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "76b2e79d012ebffcdde4477af9b19fb2e1e54e67")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "7e470b27c01de9fbfb4d4b532136760ec18afdad")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "5f0636cde6711769dc13bdaabefb55e6af843147")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "f6eb25d050854b65daa7766d203b3e177dbc8f4a")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "04f64ce2d33e27cc5d40482765223aa6dec062ea")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "e4fa3bae3e265d1ca702c1ecc6aa8e44c676155e")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "f76d0c995da17ae17ef8ccc6c68a3045ea461a73")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "a92e30d229b4d76f6220a96ded2c46f4054544a4")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "c04cfa11a0b9edaf4b73a251845690cdbb3ee98c")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "caafe0a8685e4faf2215bebe5f37fd1a80683f93")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "1f01809c914084c4773dd184439d1cf599710f09")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "ef2ed1ac671dec6c7904174152fdd90dd03c4589")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "dfd353b4f7544d41a04d916abdb4a0aedaac2c3d")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "b94583da79c1834c306118ebcc013c795b286ce1")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "4d6ff67e6e78c550986e2e953ed8a9a5d8b4ee20")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "db7e38f078621af681d9b5e523f4c91bf4801c6d")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ffd1c9ac47dcab5ab8c1c0301c0c04c3e2686b6e")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "01109f06ce875665dffb11263b80f68a2d3c07ba")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "3249fbcd44f2f2e76a14195461a3a4e43b3031ec")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "a12ac9c53969f6755c8cb0de21212f06e7e03e4b")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "f500b01def047de7973851144c8196036abf36bb")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "2e58b4d0e459495430a6cd1e9540994d8a25a0da")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "f134e4c3c3cfda195b324e7bb362948b67aa1fd5")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "5ebf0d1098584b8ea8dd380b92a9b913980f2285")
  (:PATH "docs/limiti.md" :GIT-BLOB "dd24577016d7a14379ebbbc35a1e86a0d23a4295")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "4bd3d55870e1b05b12a4a2287de6b5186f2d3b5d")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "f27f1e9ecbf711aaa240bb7697f6b06f553bac2f")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "2b56cf1d8636aede273e4cd12165ec78a6ba73f0")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "742c9309d02efe4238c859a3a7c6cd577240cdf2")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "70d45ea89536739989e90f7815ed8e89fc1544c6")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "59aa701b8d0752437db3360aec4551ad6bc9cb0d")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "19223d1767a6b7eebb9636d99cea7d898560cbd2")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "2004d712f3755c501fd2b506b8f729ce6297707e")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "c5b7d4f08337ce5b0fa7096b872e21ca8c94462e")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "2709ceddf253b8a53c7726f2fcf33fc0c8d2ecff")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "2ed70c7629bc15b9b7803135fa000168ca818cbe")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "989474478f9330b3f8d731cc34c190c229850217")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "cac1621bcd068d757ea86d25ce1da1d5d1f254e9")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "0fa9272a2986414342a107ae4c1e5fbde3720958")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "9647505f8a2ae9cf74348487e9648a6c0dd5d252")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "25d94d78061e6c68007e4316aca4cdc60f9de610")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "a95cb4392328411d9f17c334c149d9c029535102")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "679e74cf6c8051dd57ea1f2fa0584c46aaef47e2")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "e8af15a00e7178168116c0138027e820c07e598c")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "139d030b0125b61aad567263b7b7db95e830e927")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "108872e995b0def43475138c76e11fdb5d578ceb")
  (:PATH "spikes/README.md" :GIT-BLOB
   "14250504c27c786cd83174a7cca53bf273af2125")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "81c46b7e0a82ca474857d5e5de01dc43c0572bf1")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "1683f3951361ad60dea42821451a4bea35147b6c")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "19840c3a15271323546259e5c0aafd7d13489681")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "54a1982bd08ac27197c3266bb2f883aab405f705")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "f7d9674884267ad4d22f962c762e1995b749fb44")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "f8480d84bb8e932e0a17719c779ea54709c3c3f4")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "1c6ae01e442bd3c4d8c829006647aaa59ae1a185")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "91732544806c231b77dcbddc9a2e4460a12873ec")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "16ebc31ba682d36cf3520086d43f35a310159bec")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "e5d56bb99d2bae3867cacd19d18711f35e6ff8db")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "2eca7df2fd82994b4ad13ff58f72ab5efb9edc3a")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "ea4feea4edb0e4a1dd7ad357419b6bf97b415f50")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "51be4a3beb85262d453bd6b283a3b31378615fe7")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "f23f9ecd889437c83c946c88f2bf56a45a73f3ab")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "bbeac271ff79f96c0f69d22c60a045a4bfec8f09")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "9d97ed258355e5afd21edfc1820ee6d68137a02c")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "729f3500b4f427612b39c02f210c4ac25f45c805")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "a6bd28dd37f149b2b47cedfdbbb7b4c11fa1bf6d")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "648bd776767e4be914a2470069afced14bc1c1e5")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "a813fbeb55cd03980b2215c99fc3170d6afa4d92")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "a05614fee1df43315393f048efbbfe9a948bee9c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "6b3bc87d5700e52ca6b861fa562c2b7958248887")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "9e9121e124a6af86e9ccb8a253f69e1db584e873")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "e6b80fa0165026cd1a89c58786ec35d240bdc6c5")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "a1fdf6705a10fcca3926f40e26051fe7b6df5bf0")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "5755794e6b6afeed6f00a698cb337cf4b18730a4")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "cb5452eab513ddab4db6eb2955603a0c133d4e77")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "8c83b0067a0481759f14733e3c60ca888c6d01d8")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69fb5930c2722871c30056b41c13f7919058bfcb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "b5cc04cfdf8ff989a5eb6081dd100f8c506b081d")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "e3ebc7594ca6b1ae269579e5e9c7f9fef1b14300")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "45255a912edb4300b1f22c9505d09be5177d1d4b")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "5aca4d48de7bf0d849eafe87ae89f6e7800282d8")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9ab280c17b61b8f98f8299cbfae676942bb3ae47")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "5f4f08a4609bd264fa058ec25ba8f6a516c162c8")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "b335ea1d241672a3989da65b9a7ec516e7533347")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "bcd7de80241f809dcfce472741f120a61ac787b4")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "ca6215b30010d3d2eb90eaa6fd09dd5a9ac7778f")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "db635a50678f2712ec9516be335717ea254d4d09")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "761302dad1073c841397f6c88d595b114af8d9ef")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "0a75ef778c3d5ea490ec0a61f11bf6c65a3183ee")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "57ffc48cc688a4de8ebec5cb14c1e69c4209704a")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "70272936e323b3e0cb05173c9fb68cb2b614c355")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "f1afe79c7a4d49abd6a6e5f6975dec830ef7b1f6")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "c574e87af5e195ddf3f596a4ae527e69c7a3c6a6")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "e3d7d77407046338d23e26eb0b8a2e8fdc3d699d")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "58c7a3a040ec814fae2dfe636f569b5623cba8f0")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "a8330e50a77b52a6b9044ebbb48f62bb4b3222a3")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a2c5c77dd51bff760bff4508e998d94370921eda")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "61f0d6e2783e4790ed7e19a45bba6407d6e5b3de")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "807939c0fbc5d149bc7c8c1e29c7864ef7be991d")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "26726c45555ae8490e0dff31f61f70735183acc7")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "9eb660cca8f097e25ca3c1535cace8c20bc1e238")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "80cb600f6c6d724cf1eaec25c3d2742c8c320906")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "9388a84a1beb35cfa2bf016471389c881ad38628")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "a3dfde4a4780554b88e6e037ab4f70731f9c884a")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "57235763cf556ecd7633a0052f265ce3eb2b0462")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "f0f1cd22e87892119a4b7768b4efe5e519925dff")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "909dfdbc901c4cbdeae5b47faf52480350372524")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "34c8add62a6df92446be5234ef013893ebcf6879")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "bb4d4d6f222aa360ec64ef2f45ee6ba0524dd2f0")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "58981c7e41ce2694dbfcaed99010a3a53e3c1dea")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "5b3c26f78d5c4aa53ca200abdd3e0f753f926b54")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "4119f86231b7d8698fc3558868ff8a5bcbdf3090")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "720f16e96203f00e308727b430b66b28689dc7bb")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "4f34d18152d77fbf63bf708ebd0aabac178c3ac1")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "65a3f3c9e84c83b900c1dd8c9cc2fc21cec36c52")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "6d36e1f64d79f24c95209fd70551953e40c62335")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8e5102497f628796fa8faffa2085a165496af230")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "2cbd40c539b13dd80070eedf4af82bd1b26f4b28")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "2d514f6fe2e81eecb29fa53de611fa5e28696904")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "edbe5eaa88c50dc13af8e367b73f7f41fd7bd724")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "f9c691d28620427099d1d89a89a1ff5d04cbe257")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "bca6808e75e144ac7e9643df07a1cc6df4f70ed3")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "09185339cab38ab937045b40c52bb1b9092ffb8e")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "f1a1a37ccd59a81e7ff91fcb36009d5953d7edd5")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "74f06b27cd04c4f498399a47e47f296228a488ca")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "1d93461227b222a8effc53ec9344c5dab0b531fe")
  (:PATH "src/get-directory/sources-read.lisp" :GIT-BLOB
   "ca171a29008377ec491dce07afd6cf24f12cd8fe")
  (:PATH "src/get-directory/sources-types.lisp" :GIT-BLOB
   "b9b9a00d607dcf36f3cac7db31fe4663eb0bcdb2")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "ec99839d234468298b553e331873a320c8ece53f")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "d135084116b62ed3b55f81ee5798618919f76ead")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "70341c7c32b364603d38bdc42e8b3af1cc631773")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "bd75d3a4b7483900689417ae3eb2dd65e76c8468")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "0a93acd78d9b8b341011531e23e5663ae1df4f72")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "5ae454c03e8a9b9196653c8b28df0727e480d142")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "17e5ad4e2206e280c3f7324adc5c8a1e50e232e0")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "956b6c7145a25dc64a7247f2e14321876ac08f15")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "424539d39d88993d6f4048bb64fda3e6c1840bf1")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1177496e5baca7f7c698156e196c60fe1fe2566a")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "e1bf83fbcc737b55eaa71bd6b41a912a901178ce")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "6f54751adb255f49582ff1da62f951965c3860a1")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "9cbbdb6200af813bc9595d0ef964628a9ba0368f")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "53438f156d3e1e15f3732ec840223231b308a7a5")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "cb426426eac6e923224bc57c1dd602405f4bc040")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "23f16c3039b71be0bd46d6bf92f05791e444683e")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "5a105a141b43f5585f8e79c2965d59e96cd35ac6")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "cf168c44bfe5aedd2e34180ce4f766a6a89500a7")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "c9b8488d0a1aa7643a6ab1570765ec870aa7c9e4")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "032ad088b19ec3498a7c80a5e4b96d7777257dad")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "0d8e799b889df829aeb46054ef100377845dd0e0")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "f115b63c6089960e9857469475f821f3035a5ef2")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "6d43b042d7d9018f8aa48e88fc58c24b5a089cdf")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "a83ee5a2d8903538f8ba977ef0f5ddbe3a357d6b")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "6d05b467aee412f447308eb697daa7f4f5ec6f0d")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "5627b4179b115c008379aa3e60a4724e63f9657b")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "20de8a35a4deaa830348a6db5b5bb033a82c81d2")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "aa80e1b0b6af77379cfe2f2bd12c0b17e5c6851b")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "20d4b57b2a7c4b9f11205e753b92301f74f56cfc")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "1d7969c842b1f9a4cd0b9eba2ea3496cf914a2c4")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "aacbb9975ad3795d848c4523d178af31d34aa7b2")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "f36b55b9e2d9002ed2ce203a0289c92984c89ac9")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "b5b8243bc40b44af8c34ba76a5ab732675690af5")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "2282593c0a431f3f73fb47cdfc7a8e530e704ce7")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "b8009b8313054c9abebb70de8f8223fb1df708f3")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "5db1d132d91fa11be2b2624ed4c0c8d5405ce591")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "abfdeb5397f8be1d390cbdf47f4f02cd2f36bf91")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "77df997ef72008e7758899a348ae07695bce0b38")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "8555e14347d05182c99b756a312207019e2f904f")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "79d794b102c3ebf50679426e7cebbf49f02683ce")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "321ae3d1fdcda8e34efbdaac4b10dfc08fe9d9a5")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "012c8cff2c265aa7f0daa909a9a0dd01adf7ca3b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "3c7cd919b94dd9458422143c18075dd7498fda1f")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "a8088783354d2e4e5048d6ac7a3bee7afff92719")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "80156ca526a341c845fc43fc9963097f8669e65a")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "ba31b07379219fa8fd80fca169d43a053d28063b")
  (:PATH "src/io/identity-types.lisp" :GIT-BLOB
   "9c94bab051b318a872d78efa45ba3358bf74f8b6")
  (:PATH "src/io/identity.lisp" :GIT-BLOB
   "83e3963f617da174cf5a77ada16ab6590bbbd0d6")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "0b93448ffe9c6dd4f3a0a2f3f35d5cd656700bd7")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "18b23eba1b6cabfacf4d2c423714408f0b592bd4")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "93d47c86db3ea0d2030d64e4ccaa4e8b5fe57077")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "93acbd608b1af475aa505a6a7dedceb3b15e8d4b")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "30ed9e74b6bea270f64daaaeb3014876f6aeeabe")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "01875b76743c514ef07346a32587f4dc5c34d2f8")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "48372f6f09a54cfcee793ac03ec321fca6ad18f5")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "25d93efc7c604042d09dc84e31baf1f4e2c4c45e")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "09d73425a6e571c8fac6669b14b98e3ceeb7c96b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "c9cadaabf755add3671cd1cc0408c3ff216df2a5")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "bf80277418243422144cf6ee71eef83d7eff6da5")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "3d0181717e3f334580bab9a6a507e2dfe57261ff")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "132e44c138e209d3f8840b098cca0424853d09c3")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "b3601060197a27c6e8a2aaee22b5576c6b0c6e5a")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "b30795fb7efad5f5313198d345ffabb43249e3fa")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "87cc54024e59757c16e20f3025970b1699b11662")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "878fd1afdcbf035a232166ef87066af4420e1aae")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "a6ce94b8be3c8c84043abfd6441599f9780b2c11")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "e58176890a26751bf5767582b279cb667a29744e")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "b133ea00a3b8063e9e934a1b41f10cad024471ae")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "0dbb2b3bdfbf5447a5904ce0fa6e4a97337a6827")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "60057f6a50c657f016bee3c21c21911b582f86fe")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47810fb2944b4b5c18d9a9c8e60dfdc1c5f19db4")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "68c357d2d522fcabe79284c540c2631e5fa87780")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "e74b806f5116db46f3a385821515c317b2dcb452")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "ae5b8e4677fdd1dcee2f2a1baf293f49d9ce2972")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "eaddc83c63dce2fde59227e0416917bbc766e325")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "5405bd515df8b26b792bd0430c9ec3dbadce63e7")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "55e56d621129d1637eac1a787bad60dd0f0405b1")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "e062c804e68a8f62eddadd5c87db0e7af392744f")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "7ad6b7541397611f1ecbda7dffdda98c4453dbf1")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "63fb4a20faeedceb47b8cd550262f1bdca497c06")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "128fe9650a741541b46d1ad0887b872cb2e85012")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "7352a27581b8e2e68407611e65e46773efdc333c")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "0cccb1f1b9bb8f63a308352d64426a420bd1e283")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "48a789494e731732ae0b378347e133d50daacfe4")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "7f91ca22b7f2f339b450db0f4c26c97f86906c58")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "fc42b51a0f8606687881e239ba650a9f1bb58124")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "6fbe5e4720187be3bcada2dcc9fc40026267da07")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "f280c35e8f7ed283d30e8f4a43bbf2f172600816")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "e350df4e2fdc2f651ffbdb136bdbb266ccafcb1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "a0def7fc9452d291e2e60dbeff26a56a2b06e3a3")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "acc9f6ea83a8ef2774b41bdb114165b6bfb54949")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "02c219d556a8cd807a0e322667dfb401d8b06fb6")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "39f28974f3fae098d32d4ad1a056a45b06f777a6")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "233556c366a99b7b263af1c7bc19b47ceaebf940")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "7980cac6cc8070836b9aa49fc8a0d6fb42630749")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "fc942f1c8e30e637abaf13dc26343d40417fc72f")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "fde8608e6ad3fe062937c48bdcb7d2d5870207bf")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0012eaf90064c4cc2949834a60e83c9db8ba6308")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "6cbbb89f681965173e9b1b95edf3f7f870af1eca")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "f1d99b205b1ea5e6ad059ecd7971d3633411b040")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "6d30698383477880c693954314bab03ca8affe24")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "f65662b4dea8ef04e4e59ce38b29a94fecea4f6c")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "edc8ce7474365e0885925d557a378779655d2e70")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "8245bc10cedafbff8665489fbced6833f078a373")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "ad1b1356eeb10248526f15ac31d2cc9b59811fc5")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "10c4b1949994d01cb9ed231f66a69cf81f1ea062")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "56318b1632a7a0ae11f2987cdf0d4bec68e465cb")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "e613ea025c2a886cdae7fd5e119cf80593c6b72e")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "10979b4a89af0b00d48abbc7bf6760afc3b5aa9b")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "a7bee65793fc3a3e0c89c9c73871d7c183669a3e")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "5a7f38de22be659787305441b65c689de4bd6dba")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "43c4b1ffe8c3dee1a37e9f7b07f655ec3959896b")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "3624e1dde5f5a484a117f4c783d4e6b88027cc89")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "720d80c6dd5a962dc724835c1421635ba289b7ef")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "878f0fa10825ae3d49e9cac2f94d9992c06f2d20")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "dc9ea34945c3a8c52d5c62062951674d27becd5a")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "4212f8cc4be686e923cdbec9ded24f42f1da74ba")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ff6df200a7ace3af204b622969a387ce7a1e1504")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "24543b1595fbd12972e7073680fde062337b8417")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/series-read.lisp" :GIT-BLOB
   "3a38ad33e53828878053385ca88fd0cdab95c3aa")
  (:PATH "tests/get-directory/series-support.lisp" :GIT-BLOB
   "2e97e2c50b4038ca91dec50d884ba1efef5b8c7f")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "51351fe8bb7b748fdbd7e8af9efdff1a8fa9eb56")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "0f706343bab19794f90df89400b1e94aead1db38")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get-resolver/construction.lisp" :GIT-BLOB
   "322c63ee6576304ca1ab19e28b902b680bc2acae")
  (:PATH "tests/get-resolver/read.lisp" :GIT-BLOB
   "a1788d1aab3f76b9dc29095676ec42f3a1f936a8")
  (:PATH "tests/get-resolver/sort.lisp" :GIT-BLOB
   "442ce9eef4fac8f593a9d94ed08a76b830773563")
  (:PATH "tests/get-resolver/support.lisp" :GIT-BLOB
   "11d5cf0efe8ee4f5606707cc7eca175442a50190")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "3cea6b1438f8ef7095726c592a991028e203da32")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "55b8fabbec5c66417e16b34caa5f73b0f24b1e46")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "13b367549c38c5fff1b826944df658ad1ee0a7c3")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "8d0ed3547f0dd71e7d74af31ce0ded585d7bb436")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "f2209f6ba53f7140069b42151995bfe312907561")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "93a40af0b228460656d9ad48f4c123e7b6c842d3")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "362141c30925f7bb8a3936743454326ddc510dbe")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "9bcd0387306320bf0f069c50abc578b019b2d994")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "fd285d0ae73d312d7234a2a142d16897c9adbcf7")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "be5fc283b3c06bc60548ea32c240ebf8d9ecafc2")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/get-resolver-coverage.lisp" :GIT-BLOB
   "7811075f3b625e060957d66ee84749952c652ec9")
  (:PATH "tools/get-series-bench.lisp" :GIT-BLOB
   "2950d4fcb7fc93fbfc7d78c860f0ac43ed984f35")
  (:PATH "tools/get-series-capture.lisp" :GIT-BLOB
   "9c42e23d381751e8140f186f969c6c2ef8d606cf")
  (:PATH "tools/get-series-mutation.lisp" :GIT-BLOB
   "3d3e887ba8e1d90612e561dfffb3d71c486e813b")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "4e84645950948a15caf27e4f9c5f18fa030efcd0")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "2e7364821e345b8b8714856a6a2f03c684140320")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "9421994e3c9883b423f6f17311d1b26c094ee991")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :WALL-SECONDS 7.997357d0 :FINISHED-AT-UNIVERSAL-TIME 4000908573
 :SCHEMA-VERSION 1 :KIND :COMMAND-VERIFICATION :ENVIRONMENT
 (:LISP #A((4) BASE-CHAR . "SBCL") :VERSION #A((5) BASE-CHAR . "2.6.9") :OS
  #A((6) BASE-CHAR . "Darwin") :OS-VERSION #A((6) BASE-CHAR . "27.0.0")
  :MACHINE #A((5) BASE-CHAR . "ARM64") :CPU "Apple M4" :MEMORY-BYTES
  17179869184 :LOGICAL-CPUS 10 :EXTERNAL-LOAD-STATUS :UNCONTROLLED
  :LOAD-AVERAGE "{ 7.52 7.14 5.67 }" :COMMIT
  "17be854ae21757659e329fd6fb57777adc1a95c9" :WORKING-TREE "" :CWD
  #A((62) BASE-CHAR
     . "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/")
  :DATE-UNIVERSAL-TIME 4000908566)
 :COMMAND
 (#A((4) BASE-CHAR . "sbcl") #A((10) BASE-CHAR . "--noinform")
  #A((13) BASE-CHAR . "--no-userinit") #A((12) BASE-CHAR . "--no-sysinit")
  #A((8) BASE-CHAR . "--script")
  #A((29) BASE-CHAR . "tools/get-series-capture.lisp")
  #A((10) BASE-CHAR . "--raw-root")
  #A((30) BASE-CHAR . "spikes/out/get-series-bench-h/")
  #A((2) BASE-CHAR . "--") #A((4) BASE-CHAR . "sbcl")
  #A((10) BASE-CHAR . "--noinform") #A((13) BASE-CHAR . "--no-userinit")
  #A((12) BASE-CHAR . "--no-sysinit") #A((8) BASE-CHAR . "--script")
  #A((27) BASE-CHAR . "tools/get-series-bench.lisp")
  #A((7) BASE-CHAR . "--bench")
  #A((30) BASE-CHAR . "spikes/out/get-series-bench-h/"))
 :STATUS :OK :STARTED-AT-UNIVERSAL-TIME 4000908566 :SOURCE-BLOBS-BEFORE
 ((:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "0241da912be93fdf70b9a9749b759efc17aca329")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "30f2e951591f8822ce780f77cfa9c4ab93f0a98b")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "8f682f6ff22f6a0c1847b71be3994e628d399a77")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "d654f504cacdfbe7e144a074e0c2aba5ff2f4b31")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "b239b5187a2649125b7429273cb0fe4f4cba673b")
  (:PATH ".gitignore" :GIT-BLOB "19bf1ab91a6ed3c89cfff48070fb170b09679360")
  (:PATH "CHANGELOG.md" :GIT-BLOB "2fc0d78d84bacb4ffcfed3877697e5475724fb58")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bb642c10cc99a2a8d62cc101ec1c6e9903ec1441")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "5820eb0ee2f06bc024e238afe12106b0e74275dc")
  (:PATH "README.md" :GIT-BLOB "99958454de32ddbc01794b0817781c287cf4c0d6")
  (:PATH "SECURITY.md" :GIT-BLOB "27fb94691a84b389d72184838e38d2e43a8fcfbb")
  (:PATH "arcdocdb.asd" :GIT-BLOB "18edc6e4701765c456241b14443949ccac03ce91")
  (:PATH "assets/README.md" :GIT-BLOB
   "933cfee445a3fe85c8b9ca8c7c4e48afda9bdc95")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "0e9fe71b160f4ff7fcc61c9695159b00e352b12e")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "de51c5d5d625caf2ba89581880a7e932a86d2556")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "9ac19a17e0c095ed711eeb2a9da52b4965d3c481")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "b6dcf61865707b01724190e83c4987aa5d98762f")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "0c81882c35757d460e55f808fc6d2370f845550d")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "d65d5b12f248347430260c6671017a0894ebd3eb")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "2713de877ed961857868b53bcc346fe62088ec0e")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "b0e2afc520b8ea9a540f0605f682c1182b5af3ab")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "2e83c526df9864f1c3d2373fd313e4ea61d29fde")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "39cf33413347ccc9d91478efc1c08355908c23c9")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "3eab0ad4c56c1744c456579c8e773c5d7fe7493a")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "6616ed0cfadc71596ae3162affdef4f75f608de5")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "0f702230f39f3b4761886499d99b2eb431514908")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "07b5adf23d044b552d5e038adacf194774dfcf40")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "b92eea4011a182108002786370c8330e8271e356")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "db87b7732e2e42f22c711a89f5deae97f5f00757")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "1b845787d56dbc1296e7283f809e1be1bd0d3b80")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "826a6f1d12e37dd26893598caca3889010be7480")
  (:PATH "docs/README.md" :GIT-BLOB "303b4a009be18ad5f03ef990156ca0e145914fb2")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "88eeb77497b6d6124010ad65a71b98e08743131e")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "a4d7157123f6cad4b92d3722e136bd02f15fa138")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "fe20638b50dffc66f5d5b3497f00e5f526ea046a")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "2b9f1e16b289ec754c0ac0de79e7823852c4815a")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "4af05ad11f846d733b3485bfdabac47535f41415")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "ac6e1e0f042e6ce5622c0b579ff8d0419a707980")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "ad70fc5e177886b0be609ebc0234c0c7c2fbab90")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "7e6590a619252983120f8ef9b5b3fba5bf24659f")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "5ae6feb439b1d182febe27d16e6d485183150d6a")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "18de49d285e52d25e055397f47c829ba7db45500")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "2f04c342ca714f0638dfdf2bed17fe48de54edc9")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "1a86df3d58358950d8b658b6b8194563288fd0c8")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "99ca666f07f0f04168af74c55459ca76a6f421c7")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "3ca2df1c7beddedd65511d9282a547294cabbff4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "87931cd80f665581fc43a2b02fc6738ea3d57fb3")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "001950113b1fc347642e1939ef060d93a54096e5")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "5a442b2aeb665be3f23da887ff615bef889e167d")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "250c272e2ddaa4b062b956d5ab3eb66ce610b44a")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "be9686df1c7ecb762bebac602bab12010d73d0b9")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "6fff5ed7db6d11a51f12b167636b7a23a3750068")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "83c6cae3eb56b9edfda572533258d8438132e0ae")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "81823c873cf52abafd86a3e8ab35df2e161d1034")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "623209aef44929e1b8397b1f8470dffc20d9bbf8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "bc3d2144b30022e7ab239c561b6986a18e10ec8c")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "470ef1b7f52d571ea5af046ccf06896729a06a13")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "24235615cfaab3821cc38bc9b9979a9928c6dee9")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "8c29d6d4d55cbc7226c2df7361a3d7220c103f8f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "225aa16313ca4b54a04da07851f0824c2494543a")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "506080464430c1b9e5f2b09816d186ca95e3fcc9")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "328152db463a6e5796435ccd3867d8838429df15")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "b9dae81c93e124b6db129e90fb641c85ca349c93")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "dc8228d1c2dc5e01fa6a5cb6c69ec9e8648427d2")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "fc947bb28bdf5a015d7b353f56e0d6fb86a524c6")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "4646cd378729d3841b8419b3681477b4e1a80816")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "dfeef8dd42d465d1c97830bd6f8304d3f8579416")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "eb3138e9017cc95b7f71fb29ec3a21e4bc44a3c3")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "d4140bc0d14bee6ca7480e94fa96bd8c79e656fd")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "aadf427743cc9b511c4fac4952ec1335005b5568")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "fce6228c1a393557b2475a7600cc998246de97d0")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "c347b791cfa1e13319894e5c2a9c3c20527a7047")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "77640ef6687df0ba7a570b682000bd4b2fa042cc")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c571f195148361a34fa6bc9d1c6f35836742ab11")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "ba7550dfd1890a483f313610cadc808142bdddeb")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "1f07f3d9c4a9a1b6a0c1250dc09923966b2081d3")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "3ada528fa148db73ca09df933265ff82a5e0dd6b")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "75301c4284016be1da4f6f7a9e4b8a1c00b1fe8c")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2ebb221d1f2e8666fa62910f561728eb6ee0a9f3")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "4c11a9e20d9d7bf315bf7623740addd876019d77")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "f36aeeeab161774fce91906d1ba5d47e6b1a8636")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "47b35236825274bd340b61e4c30b7b38d8349d5a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "f393c09cc917be5e4a123befca7bdd3f238ad8eb")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "123524e58806fe8cee2727e5ada0b00561583a76")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "817f3f72a09e74d142b160bd8da172b459f327f9")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "0cb9800d4e89438f0ba2e9ecdf763245f0768196")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "83dd5fe0d9323805d7e97e6814129d16841efb80")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "c031db7bad8fa2f115938e3699e6ce01bc436bec")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "fdb928d6caf051a0341c162d537ca5d6351acfd9")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "61f400316607e9c47904680e6730c3034ba5897a")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "ebb3e21821c8b3d53a40a3bb6594b5c9ae20fc50")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "7800931fe3bc4c8204cd873ccc0ec8ed42af8b50")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "7028bc0b2b30b0ad17f9bbae81590519d3775e73")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "13ec9283f25316675f7bbbc2e95d80ed18469da1")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "80f4576d4e5afecdabdc3620771fc573e4ca9c4a")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "7137f05ec0a8e6cd345a00fda62be573855da3b4")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "2d883ca7e34a8b31f88930e0d266ec0a094e6b0a")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "4598d73762c03c81d489050db655ff29de7b35fd")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "00a1f025a375559acf548fb855c59d42e4a21642")
  (:PATH "docs/implementazione/associazione-file.md" :GIT-BLOB
   "7f46537f9196d5ce884a7010ee2c33caf223db7d")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "173b91ac893a1bafe8d16ddb91b99dd6341c1a01")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c8182641591fa6f24bddedca56f92145a3c7a038")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "b8b2b37a18cb4d01815e07df5e64e763f273a9d0")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "325784adbb5cff4121559fd3d50a1ef943443434")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "bc95228574813d37b27882f24713e4d834788dd2")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "69bf38c64b527b5aeec011f9fe49d9fd3c31d253")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "9eb64c8428b638f6c0c1f0aaa80c4dbfd0f900b7")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "e39571136cad9d563a933aa608c011b887f17260")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "a83c5cc798dfb87750030781d015eeda260c4ac0")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "245f95c99a4735fd40a1d9694b4a5826f5ccb5d6")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "9f6526bf5c135cf43289127c4c1bc5dfdcbb8114")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "162cd32188a030d6cc3c5d16585054aa36055175")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "4af8109f8d01f1107791836371720802876ae775")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "2a9e7f0bf30460b3b7dbbbc1c7776c9259fe545d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "3935fc5225836a0669664701921ad1bfff3d443e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "8ba7e4ba06ca958c0be9a5e1128c63419aa7577a")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "a83375d3c09898353fc0173f3171884f92319d73")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "d379ed246db14204b7632b7b3c31266bfcd46b1e")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "ba4d2ed61bf06d0504bb1e0067c8741ef45cc4e0")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "8966ac0cdf66fcefd616201cc97017d384b3f0a8")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "cd2f1ef9dfcd3f9029549430c21ec553509a62fc")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "81675040c1c6155f7e3efa669ca62ed4b8a63064")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "d8b22e42e7ab906488cef72d935b71d4a83ba499")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "6b4a59954e2d48cc30a044b57cfe43b0b91ae1e8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "7d44d58d7de6c62b2206a8e35be398bc34811663")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "9605de0679e062361f80c5654c5fbb8028765008")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "8b79dfa3b7cf5011b66534d02c2a4551232d503c")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "e9007f26d323a1ffd2993c461c3f84ad2aee90bc")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "a25b46457201e1a7885cc9b21cfb3e66267ec12c")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "a9e2e9dc6d0d4b968a9940d78abf8ca2de825e98")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "5d0aacab996dc47e2d479d505604d6eda5d42ea2")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "3ec66f8edebd79a128969e0b398e7700a2b1c5cd")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "46a0480b0bc29938f8654ce8f59cdaee5b720a4a")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e8864f7c0124f86cebdcdbcb2449800e078e1cc8")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "d276363cd59d6d1a914a6055b27edce016122323")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "94d950c644e849103eecb0d74c053df4aa1473dd")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "47cfd5c96e2150c42a2a7b716bef117090b0cd86")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "f5817e4d931148aa4f526b93066ab9d1b4bdf783")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "0a3a2123e618a8ff39e86dbbb70db36ccf51b133")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "2df0a214fc5cfe64ceb239aab4f7d2a2d1827305")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "1c1d617e19c0d74199ef11a56105d3ed90eb0ec0")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "56342dae95caf8705e0b28b3c0ea7ac86fdd8fa0")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "90bac509af0aff7b7085a2239de6e9dfddfc70ba")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "cbcfdba7c5967d5d36e5d9487f6a7b1ab0300a53")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "278d9413eab7578c99a07b1c614db37c83141097")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "8e1b0d0d6066669e1ffb65d95900a3b1aa385c51")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "c9808d48a01444ff6faddf2d8389673f91598db4")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "6b2909a5f56212947dea864584d2f96252fe1b1a")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "f0a2791f988b0d0c513629824f75ce1842fe059a")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "cebaf33e7e7cde4efbcbc2ada22fd494577c9e81")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "7b22c788ecf0d69f84316f39d2f580bfadb7b91f")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "76509dd8d44a61eff9129d08fb19c289d57fd1e8")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "93f1366c17eca13f37f63927d64779f7afeae658")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "a48d5b525d2c78fef0399666ebb14c6f8a2342e8")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "8dfa1cf8533764fdd89014f31cac59d02b248e2e")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "759b72a96a099d18fd353ef8936d63481e25129c")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "b28934a0a4eac77562b07fa8db796c167176ef36")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4a2c524c6b1c7be1c1b5d7e43d35d385ee7f5b1d")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "f6cadf13877cab21d869993f33e485f1af116806")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "8dbbd94b11ca62b266df8e1b58ef8b15487dde9f")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "2e1d7abdfe9b4880682ff1da97b526e180d01370")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "0264c59fce79fd2a9f34d05f85c8dfff5fed69be")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "a2a8d5bba2c3da3ad6977d6a6f750e468d229693")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "1aafc63fa8904a8504ec6fd42d34b606d6505677")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "ac23ebc4c1d6ab57116def02bf4ad7df115394d1")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "8fe4debab581640b3d1db74b6fa43610c8e547d2")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "a3d67947dafc891946df3ea19706d32d67b24a80")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "bc99cae302da8bb90c208cfc0d5def111e945269")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "79755fdc3fcc8cdc8459d0cf3d108d06e577bf3f")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "c3467fd1f58d977797821581ff127bfb2cfdd5cf")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "a0953cd3789ec80e22ec33f445510db6769ad2ed")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "4474e5ced93e129bae0ae13255e2c56363334f20")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "5f8fa54b5df938dc51ea2053298baa58413d7e5a")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "4434a2412cbcc6bab1bc5292331eb2c2eeabeb6a")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "ae05757ce562c9b2eb5632765cc9da4db8c2fe56")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "96a9d6be3614715a434ecfec5808375e06ff6468")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "a64f148cb2254e87c649bb16e7bee39aa45eb40d")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "a1631f582d8b3ecaa177cccead8c1e3d0051a822")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "30775c49aefcef182145497ee2c91e7f9ce6cf93")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "69e50510426fa53d230b64b89da9e64fdc5c6efa")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "542584f7ea490cc7b4639ee42969c17f52a8e559")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "204a995d2152620792e923275de5abcc5e29bfb3")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "550afaffd56bdaa4b5a16337432ec9ccf655d377")
  (:PATH "docs/implementazione/get-fonti-serie-metodo.md" :GIT-BLOB
   "76ca65cb32040dcf98ca9599d40dfb2f1d4a217e")
  (:PATH "docs/implementazione/get-fonti-serie-revisione.md" :GIT-BLOB
   "a8ac6d02893d0fc74093c1fe42319cdef8adbe4f")
  (:PATH "docs/implementazione/get-fonti-serie.md" :GIT-BLOB
   "678bea348d7c7cd6c3eca0b8e0cd2bd4d9450240")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "ee84732af73d4d753b211bd9cd33f9c7dd1d2a3f")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "3932b391102e3b7e0ead521a1fb223ef5ca2129a")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "058623adabd6a98f7d7617c4c1ac4fd0b7bce825")
  (:PATH "docs/implementazione/get-resolver-metodo.md" :GIT-BLOB
   "31b568cfe4db29d5d4c6d6d4de82dd0f54747f23")
  (:PATH "docs/implementazione/get-resolver-verifica.md" :GIT-BLOB
   "7751ad4582bf2d9b5402c2430c2aaeb5a6d713bf")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "a991a37b6a5460941170bce7d951eb86888abe4f")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "acc39ebcd47f56d31d5ddcf9843ebf8543424f22")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "a6b480a9726002150f65443b9a3c97c9039f2012")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "c799f6cd5399c37daa1687cd0d154ebcfac2cb39")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "d9de17c5fcd7e7f21555c68db8f3eaa7d7e1b158")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "b7c4c84c6d688015a43f81b476e58744fbf5d467")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "f103ded38e6cb575820d7fb89d72e47b9fc16693")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "d09dc4f0914935805770cf148cfab99b1ca30eb1")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "ac29588884b2f12f2bd67a72f04504d88c2d44a0")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "d4382b97ee69a12235f4c1d445b9b13dd5440684")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "4dc9aa9bdfdd5e21a2ef2bf6ab6fc8d2e111a586")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "c88785115dfda86f3e6ce425487638fe514f0e3b")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "1950d3f3b38736f7d32e1c3a24fb217bd1dffc86")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "a220b68f94b35c81b9bca4420453c4057eded097")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "37ff4f5316483960508fa78df1f890ebaff8942e")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "27cb98d6bf753515b880d7b09e8069302a0e72d2")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "476e35fca8858a4a4eed163e4a3a42c7ce38bd4a")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "550c69493fdb363631b83dea4fff765119b6ad5f")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "a1b3490342f3a234595cb1c237061def91b67d0f")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "656e8162bd3833268a6243e136c2e46b39e548f5")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "f779f81d41748e3e9b10596dc9af12b334d4dc23")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "f755abc620aaad10470143418702e883baf2493a")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "6b39b77b28e576610308a9d98e540df64e28555d")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "cb473b09149385d5d32bb44db1478e5ba7da7640")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "23966839673d2e5931f1822c0c2e0302a189911a")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "1b746fefc25d8cd1be1bb44611c7ac5f98e8acb1")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "c451a24e86e98a2dd3a75cfbae55260625b33dc8")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "096b16489aa910182fe01349aa5552ccc1ccd446")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "f77e4acc65f3582d76bee6867e7a728757a98d4c")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "b6c4a6992ef5ca707c19e08dfbdc7d1e01e1e900")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "6fbe1f002e3e18df09a964292f27c3657bb46004")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "b275c083f9705d1ed32b4cf282fd0c12c39d98a2")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "3c2423f187253e7c2c83b3848c7efbd43d269641")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "c7780a6798cec4964badc6a5529508898ae4945c")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "bbc3431b5872adfdee0e23d566caf7d2172a971a")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "8101b2da12ae1a60a0663b11ab70590a96c5bcf2")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "99cf34e5c5c3875ed97414c30ec9b7bef96d30b4")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "0a534e557a3fe8216e0d5fbfc84c354255d081ac")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "d17e9e45a1d4896249d11f2bd474aa05af5222cb")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "805c6b231d9fd7223ef1b149e75e9c3be0dd0859")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "d6e2ad12c278d5bb26050c056df4342671c590f5")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "77d0c406a967ebe97f81781f9dd4cc9d68488ee4")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "1798cdf9b8916ba74b21d1d86442a49874938e41")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "bc3121e6274d610f56155a1e159d0a8948ee87c5")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "73bfef0b478f57c9441a6d0e2ab59c0e7f223fef")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "89a767f226693292d6a934970010d6dc5f13bbe7")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "d7e1f6e6fd5baa3c0c345507b8c3cd7a71e47f33")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "497b96ba252c1d223b91c7a958af3a1de6e6bba9")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "4b9535873216af6a4ede0b3d6d31e80c466ad395")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "6c46cebd54cacfe7b366932d1be6bd2132346087")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "c9ec2a33ac47f9811f152032cc6232fb1ccb941a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "9cfa2d91655890f50c7a0d83cb14f0bbae650f21")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "08c866115be68fd9e88c2d30fd111017851bbb53")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "df02aed3cd659b1b09e746d8315f54e32f526965")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "2d2ffb30c9051c58fd7f9b7efb27a487d1c0fd8e")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "76b2e79d012ebffcdde4477af9b19fb2e1e54e67")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "7e470b27c01de9fbfb4d4b532136760ec18afdad")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "5f0636cde6711769dc13bdaabefb55e6af843147")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "f6eb25d050854b65daa7766d203b3e177dbc8f4a")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "04f64ce2d33e27cc5d40482765223aa6dec062ea")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "e4fa3bae3e265d1ca702c1ecc6aa8e44c676155e")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "f76d0c995da17ae17ef8ccc6c68a3045ea461a73")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "a92e30d229b4d76f6220a96ded2c46f4054544a4")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "c04cfa11a0b9edaf4b73a251845690cdbb3ee98c")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "caafe0a8685e4faf2215bebe5f37fd1a80683f93")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "1f01809c914084c4773dd184439d1cf599710f09")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "ef2ed1ac671dec6c7904174152fdd90dd03c4589")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "dfd353b4f7544d41a04d916abdb4a0aedaac2c3d")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "b94583da79c1834c306118ebcc013c795b286ce1")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "4d6ff67e6e78c550986e2e953ed8a9a5d8b4ee20")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "db7e38f078621af681d9b5e523f4c91bf4801c6d")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ffd1c9ac47dcab5ab8c1c0301c0c04c3e2686b6e")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "01109f06ce875665dffb11263b80f68a2d3c07ba")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "3249fbcd44f2f2e76a14195461a3a4e43b3031ec")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "a12ac9c53969f6755c8cb0de21212f06e7e03e4b")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "f500b01def047de7973851144c8196036abf36bb")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "2e58b4d0e459495430a6cd1e9540994d8a25a0da")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "f134e4c3c3cfda195b324e7bb362948b67aa1fd5")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "5ebf0d1098584b8ea8dd380b92a9b913980f2285")
  (:PATH "docs/limiti.md" :GIT-BLOB "dd24577016d7a14379ebbbc35a1e86a0d23a4295")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "4bd3d55870e1b05b12a4a2287de6b5186f2d3b5d")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "f27f1e9ecbf711aaa240bb7697f6b06f553bac2f")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "2b56cf1d8636aede273e4cd12165ec78a6ba73f0")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "742c9309d02efe4238c859a3a7c6cd577240cdf2")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "70d45ea89536739989e90f7815ed8e89fc1544c6")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "59aa701b8d0752437db3360aec4551ad6bc9cb0d")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "19223d1767a6b7eebb9636d99cea7d898560cbd2")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "2004d712f3755c501fd2b506b8f729ce6297707e")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "c5b7d4f08337ce5b0fa7096b872e21ca8c94462e")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "2709ceddf253b8a53c7726f2fcf33fc0c8d2ecff")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "2ed70c7629bc15b9b7803135fa000168ca818cbe")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "989474478f9330b3f8d731cc34c190c229850217")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "cac1621bcd068d757ea86d25ce1da1d5d1f254e9")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "0fa9272a2986414342a107ae4c1e5fbde3720958")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "9647505f8a2ae9cf74348487e9648a6c0dd5d252")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "25d94d78061e6c68007e4316aca4cdc60f9de610")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "a95cb4392328411d9f17c334c149d9c029535102")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "679e74cf6c8051dd57ea1f2fa0584c46aaef47e2")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "e8af15a00e7178168116c0138027e820c07e598c")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "139d030b0125b61aad567263b7b7db95e830e927")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "108872e995b0def43475138c76e11fdb5d578ceb")
  (:PATH "spikes/README.md" :GIT-BLOB
   "14250504c27c786cd83174a7cca53bf273af2125")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "81c46b7e0a82ca474857d5e5de01dc43c0572bf1")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "1683f3951361ad60dea42821451a4bea35147b6c")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "19840c3a15271323546259e5c0aafd7d13489681")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "54a1982bd08ac27197c3266bb2f883aab405f705")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "f7d9674884267ad4d22f962c762e1995b749fb44")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "f8480d84bb8e932e0a17719c779ea54709c3c3f4")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "1c6ae01e442bd3c4d8c829006647aaa59ae1a185")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "91732544806c231b77dcbddc9a2e4460a12873ec")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "16ebc31ba682d36cf3520086d43f35a310159bec")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "e5d56bb99d2bae3867cacd19d18711f35e6ff8db")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "2eca7df2fd82994b4ad13ff58f72ab5efb9edc3a")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "ea4feea4edb0e4a1dd7ad357419b6bf97b415f50")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "51be4a3beb85262d453bd6b283a3b31378615fe7")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "f23f9ecd889437c83c946c88f2bf56a45a73f3ab")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "bbeac271ff79f96c0f69d22c60a045a4bfec8f09")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "9d97ed258355e5afd21edfc1820ee6d68137a02c")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "729f3500b4f427612b39c02f210c4ac25f45c805")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "a6bd28dd37f149b2b47cedfdbbb7b4c11fa1bf6d")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "648bd776767e4be914a2470069afced14bc1c1e5")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "a813fbeb55cd03980b2215c99fc3170d6afa4d92")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "a05614fee1df43315393f048efbbfe9a948bee9c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "6b3bc87d5700e52ca6b861fa562c2b7958248887")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "9e9121e124a6af86e9ccb8a253f69e1db584e873")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "e6b80fa0165026cd1a89c58786ec35d240bdc6c5")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "a1fdf6705a10fcca3926f40e26051fe7b6df5bf0")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "5755794e6b6afeed6f00a698cb337cf4b18730a4")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "cb5452eab513ddab4db6eb2955603a0c133d4e77")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "8c83b0067a0481759f14733e3c60ca888c6d01d8")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69fb5930c2722871c30056b41c13f7919058bfcb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "b5cc04cfdf8ff989a5eb6081dd100f8c506b081d")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "e3ebc7594ca6b1ae269579e5e9c7f9fef1b14300")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "45255a912edb4300b1f22c9505d09be5177d1d4b")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "5aca4d48de7bf0d849eafe87ae89f6e7800282d8")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9ab280c17b61b8f98f8299cbfae676942bb3ae47")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "5f4f08a4609bd264fa058ec25ba8f6a516c162c8")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "b335ea1d241672a3989da65b9a7ec516e7533347")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "bcd7de80241f809dcfce472741f120a61ac787b4")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "ca6215b30010d3d2eb90eaa6fd09dd5a9ac7778f")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "db635a50678f2712ec9516be335717ea254d4d09")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "761302dad1073c841397f6c88d595b114af8d9ef")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "0a75ef778c3d5ea490ec0a61f11bf6c65a3183ee")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "57ffc48cc688a4de8ebec5cb14c1e69c4209704a")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "70272936e323b3e0cb05173c9fb68cb2b614c355")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "f1afe79c7a4d49abd6a6e5f6975dec830ef7b1f6")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "c574e87af5e195ddf3f596a4ae527e69c7a3c6a6")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "e3d7d77407046338d23e26eb0b8a2e8fdc3d699d")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "58c7a3a040ec814fae2dfe636f569b5623cba8f0")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "a8330e50a77b52a6b9044ebbb48f62bb4b3222a3")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a2c5c77dd51bff760bff4508e998d94370921eda")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "61f0d6e2783e4790ed7e19a45bba6407d6e5b3de")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "807939c0fbc5d149bc7c8c1e29c7864ef7be991d")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "26726c45555ae8490e0dff31f61f70735183acc7")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "9eb660cca8f097e25ca3c1535cace8c20bc1e238")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "80cb600f6c6d724cf1eaec25c3d2742c8c320906")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "9388a84a1beb35cfa2bf016471389c881ad38628")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "a3dfde4a4780554b88e6e037ab4f70731f9c884a")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "57235763cf556ecd7633a0052f265ce3eb2b0462")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "f0f1cd22e87892119a4b7768b4efe5e519925dff")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "909dfdbc901c4cbdeae5b47faf52480350372524")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "34c8add62a6df92446be5234ef013893ebcf6879")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "bb4d4d6f222aa360ec64ef2f45ee6ba0524dd2f0")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "58981c7e41ce2694dbfcaed99010a3a53e3c1dea")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "5b3c26f78d5c4aa53ca200abdd3e0f753f926b54")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "4119f86231b7d8698fc3558868ff8a5bcbdf3090")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "720f16e96203f00e308727b430b66b28689dc7bb")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "4f34d18152d77fbf63bf708ebd0aabac178c3ac1")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "65a3f3c9e84c83b900c1dd8c9cc2fc21cec36c52")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "6d36e1f64d79f24c95209fd70551953e40c62335")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8e5102497f628796fa8faffa2085a165496af230")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "2cbd40c539b13dd80070eedf4af82bd1b26f4b28")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "2d514f6fe2e81eecb29fa53de611fa5e28696904")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "edbe5eaa88c50dc13af8e367b73f7f41fd7bd724")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "f9c691d28620427099d1d89a89a1ff5d04cbe257")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "bca6808e75e144ac7e9643df07a1cc6df4f70ed3")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "09185339cab38ab937045b40c52bb1b9092ffb8e")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "f1a1a37ccd59a81e7ff91fcb36009d5953d7edd5")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "74f06b27cd04c4f498399a47e47f296228a488ca")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "1d93461227b222a8effc53ec9344c5dab0b531fe")
  (:PATH "src/get-directory/sources-read.lisp" :GIT-BLOB
   "ca171a29008377ec491dce07afd6cf24f12cd8fe")
  (:PATH "src/get-directory/sources-types.lisp" :GIT-BLOB
   "b9b9a00d607dcf36f3cac7db31fe4663eb0bcdb2")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "ec99839d234468298b553e331873a320c8ece53f")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "d135084116b62ed3b55f81ee5798618919f76ead")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "70341c7c32b364603d38bdc42e8b3af1cc631773")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "bd75d3a4b7483900689417ae3eb2dd65e76c8468")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "0a93acd78d9b8b341011531e23e5663ae1df4f72")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "5ae454c03e8a9b9196653c8b28df0727e480d142")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "17e5ad4e2206e280c3f7324adc5c8a1e50e232e0")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "956b6c7145a25dc64a7247f2e14321876ac08f15")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "424539d39d88993d6f4048bb64fda3e6c1840bf1")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1177496e5baca7f7c698156e196c60fe1fe2566a")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "e1bf83fbcc737b55eaa71bd6b41a912a901178ce")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "6f54751adb255f49582ff1da62f951965c3860a1")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "9cbbdb6200af813bc9595d0ef964628a9ba0368f")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "53438f156d3e1e15f3732ec840223231b308a7a5")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "cb426426eac6e923224bc57c1dd602405f4bc040")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "23f16c3039b71be0bd46d6bf92f05791e444683e")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "5a105a141b43f5585f8e79c2965d59e96cd35ac6")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "cf168c44bfe5aedd2e34180ce4f766a6a89500a7")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "c9b8488d0a1aa7643a6ab1570765ec870aa7c9e4")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "032ad088b19ec3498a7c80a5e4b96d7777257dad")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "0d8e799b889df829aeb46054ef100377845dd0e0")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "f115b63c6089960e9857469475f821f3035a5ef2")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "6d43b042d7d9018f8aa48e88fc58c24b5a089cdf")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "a83ee5a2d8903538f8ba977ef0f5ddbe3a357d6b")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "6d05b467aee412f447308eb697daa7f4f5ec6f0d")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "5627b4179b115c008379aa3e60a4724e63f9657b")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "20de8a35a4deaa830348a6db5b5bb033a82c81d2")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "aa80e1b0b6af77379cfe2f2bd12c0b17e5c6851b")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "20d4b57b2a7c4b9f11205e753b92301f74f56cfc")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "1d7969c842b1f9a4cd0b9eba2ea3496cf914a2c4")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "aacbb9975ad3795d848c4523d178af31d34aa7b2")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "f36b55b9e2d9002ed2ce203a0289c92984c89ac9")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "b5b8243bc40b44af8c34ba76a5ab732675690af5")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "2282593c0a431f3f73fb47cdfc7a8e530e704ce7")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "b8009b8313054c9abebb70de8f8223fb1df708f3")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "5db1d132d91fa11be2b2624ed4c0c8d5405ce591")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "abfdeb5397f8be1d390cbdf47f4f02cd2f36bf91")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "77df997ef72008e7758899a348ae07695bce0b38")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "8555e14347d05182c99b756a312207019e2f904f")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "79d794b102c3ebf50679426e7cebbf49f02683ce")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "321ae3d1fdcda8e34efbdaac4b10dfc08fe9d9a5")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "012c8cff2c265aa7f0daa909a9a0dd01adf7ca3b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "3c7cd919b94dd9458422143c18075dd7498fda1f")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "a8088783354d2e4e5048d6ac7a3bee7afff92719")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "80156ca526a341c845fc43fc9963097f8669e65a")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "ba31b07379219fa8fd80fca169d43a053d28063b")
  (:PATH "src/io/identity-types.lisp" :GIT-BLOB
   "9c94bab051b318a872d78efa45ba3358bf74f8b6")
  (:PATH "src/io/identity.lisp" :GIT-BLOB
   "83e3963f617da174cf5a77ada16ab6590bbbd0d6")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "0b93448ffe9c6dd4f3a0a2f3f35d5cd656700bd7")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "18b23eba1b6cabfacf4d2c423714408f0b592bd4")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "93d47c86db3ea0d2030d64e4ccaa4e8b5fe57077")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "93acbd608b1af475aa505a6a7dedceb3b15e8d4b")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "30ed9e74b6bea270f64daaaeb3014876f6aeeabe")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "01875b76743c514ef07346a32587f4dc5c34d2f8")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "48372f6f09a54cfcee793ac03ec321fca6ad18f5")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "25d93efc7c604042d09dc84e31baf1f4e2c4c45e")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "09d73425a6e571c8fac6669b14b98e3ceeb7c96b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "c9cadaabf755add3671cd1cc0408c3ff216df2a5")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "bf80277418243422144cf6ee71eef83d7eff6da5")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "3d0181717e3f334580bab9a6a507e2dfe57261ff")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "132e44c138e209d3f8840b098cca0424853d09c3")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "b3601060197a27c6e8a2aaee22b5576c6b0c6e5a")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "b30795fb7efad5f5313198d345ffabb43249e3fa")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "87cc54024e59757c16e20f3025970b1699b11662")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "878fd1afdcbf035a232166ef87066af4420e1aae")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "a6ce94b8be3c8c84043abfd6441599f9780b2c11")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "e58176890a26751bf5767582b279cb667a29744e")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "b133ea00a3b8063e9e934a1b41f10cad024471ae")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "0dbb2b3bdfbf5447a5904ce0fa6e4a97337a6827")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "60057f6a50c657f016bee3c21c21911b582f86fe")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47810fb2944b4b5c18d9a9c8e60dfdc1c5f19db4")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "68c357d2d522fcabe79284c540c2631e5fa87780")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "e74b806f5116db46f3a385821515c317b2dcb452")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "ae5b8e4677fdd1dcee2f2a1baf293f49d9ce2972")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "eaddc83c63dce2fde59227e0416917bbc766e325")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "5405bd515df8b26b792bd0430c9ec3dbadce63e7")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "55e56d621129d1637eac1a787bad60dd0f0405b1")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "e062c804e68a8f62eddadd5c87db0e7af392744f")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "7ad6b7541397611f1ecbda7dffdda98c4453dbf1")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "63fb4a20faeedceb47b8cd550262f1bdca497c06")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "128fe9650a741541b46d1ad0887b872cb2e85012")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "7352a27581b8e2e68407611e65e46773efdc333c")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "0cccb1f1b9bb8f63a308352d64426a420bd1e283")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "48a789494e731732ae0b378347e133d50daacfe4")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "7f91ca22b7f2f339b450db0f4c26c97f86906c58")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "fc42b51a0f8606687881e239ba650a9f1bb58124")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "6fbe5e4720187be3bcada2dcc9fc40026267da07")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "f280c35e8f7ed283d30e8f4a43bbf2f172600816")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "e350df4e2fdc2f651ffbdb136bdbb266ccafcb1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "a0def7fc9452d291e2e60dbeff26a56a2b06e3a3")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "acc9f6ea83a8ef2774b41bdb114165b6bfb54949")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "02c219d556a8cd807a0e322667dfb401d8b06fb6")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "39f28974f3fae098d32d4ad1a056a45b06f777a6")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "233556c366a99b7b263af1c7bc19b47ceaebf940")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "7980cac6cc8070836b9aa49fc8a0d6fb42630749")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "fc942f1c8e30e637abaf13dc26343d40417fc72f")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "fde8608e6ad3fe062937c48bdcb7d2d5870207bf")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0012eaf90064c4cc2949834a60e83c9db8ba6308")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "6cbbb89f681965173e9b1b95edf3f7f870af1eca")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "f1d99b205b1ea5e6ad059ecd7971d3633411b040")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "6d30698383477880c693954314bab03ca8affe24")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "f65662b4dea8ef04e4e59ce38b29a94fecea4f6c")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "edc8ce7474365e0885925d557a378779655d2e70")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "8245bc10cedafbff8665489fbced6833f078a373")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "ad1b1356eeb10248526f15ac31d2cc9b59811fc5")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "10c4b1949994d01cb9ed231f66a69cf81f1ea062")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "56318b1632a7a0ae11f2987cdf0d4bec68e465cb")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "e613ea025c2a886cdae7fd5e119cf80593c6b72e")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "10979b4a89af0b00d48abbc7bf6760afc3b5aa9b")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "a7bee65793fc3a3e0c89c9c73871d7c183669a3e")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "5a7f38de22be659787305441b65c689de4bd6dba")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "43c4b1ffe8c3dee1a37e9f7b07f655ec3959896b")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "3624e1dde5f5a484a117f4c783d4e6b88027cc89")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "720d80c6dd5a962dc724835c1421635ba289b7ef")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "878f0fa10825ae3d49e9cac2f94d9992c06f2d20")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "dc9ea34945c3a8c52d5c62062951674d27becd5a")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "4212f8cc4be686e923cdbec9ded24f42f1da74ba")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ff6df200a7ace3af204b622969a387ce7a1e1504")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "24543b1595fbd12972e7073680fde062337b8417")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/series-read.lisp" :GIT-BLOB
   "3a38ad33e53828878053385ca88fd0cdab95c3aa")
  (:PATH "tests/get-directory/series-support.lisp" :GIT-BLOB
   "2e97e2c50b4038ca91dec50d884ba1efef5b8c7f")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "51351fe8bb7b748fdbd7e8af9efdff1a8fa9eb56")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "0f706343bab19794f90df89400b1e94aead1db38")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get-resolver/construction.lisp" :GIT-BLOB
   "322c63ee6576304ca1ab19e28b902b680bc2acae")
  (:PATH "tests/get-resolver/read.lisp" :GIT-BLOB
   "a1788d1aab3f76b9dc29095676ec42f3a1f936a8")
  (:PATH "tests/get-resolver/sort.lisp" :GIT-BLOB
   "442ce9eef4fac8f593a9d94ed08a76b830773563")
  (:PATH "tests/get-resolver/support.lisp" :GIT-BLOB
   "11d5cf0efe8ee4f5606707cc7eca175442a50190")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "3cea6b1438f8ef7095726c592a991028e203da32")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "55b8fabbec5c66417e16b34caa5f73b0f24b1e46")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "13b367549c38c5fff1b826944df658ad1ee0a7c3")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "8d0ed3547f0dd71e7d74af31ce0ded585d7bb436")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "f2209f6ba53f7140069b42151995bfe312907561")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "93a40af0b228460656d9ad48f4c123e7b6c842d3")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "362141c30925f7bb8a3936743454326ddc510dbe")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "9bcd0387306320bf0f069c50abc578b019b2d994")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "fd285d0ae73d312d7234a2a142d16897c9adbcf7")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "be5fc283b3c06bc60548ea32c240ebf8d9ecafc2")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/get-resolver-coverage.lisp" :GIT-BLOB
   "7811075f3b625e060957d66ee84749952c652ec9")
  (:PATH "tools/get-series-bench.lisp" :GIT-BLOB
   "2950d4fcb7fc93fbfc7d78c860f0ac43ed984f35")
  (:PATH "tools/get-series-capture.lisp" :GIT-BLOB
   "9c42e23d381751e8140f186f969c6c2ef8d606cf")
  (:PATH "tools/get-series-mutation.lisp" :GIT-BLOB
   "3d3e887ba8e1d90612e561dfffb3d71c486e813b")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "4e84645950948a15caf27e4f9c5f18fa030efcd0")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "2e7364821e345b8b8714856a6a2f03c684140320")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "9421994e3c9883b423f6f17311d1b26c094ee991")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :STDOUT "(:FINISHED-AT-UNIVERSAL-TIME 4000908573 :SCHEMA-VERSION 1 :KIND
 :GET-SERIES-BENCHMARK :STATUS :OK :ARGV
 (\"--bench\" \"spikes/out/get-series-bench-h/\") :MODE \"--bench\" :SELF-TEST
 (:STATUS :OK :NEGATIVE-CHECKS 11 :ALLOCATION-CONTROL-BYTES 1048576
  :OBSERVED-HEAP-BYTES 1048592)
 :WINDOWS
 ((:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 64 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 5360298281728 :EXPECTED-CHECKSUM 5360298281728 :TICKS 39065
   :HEAP-BYTES 524224 :SECONDS 0.039065d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570464
     :EXPECTED-CHECKSUM 1340074570464 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570528
     :EXPECTED-CHECKSUM 1340074570528 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570592
     :EXPECTED-CHECKSUM 1340074570592 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 64 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 2680149140608 :EXPECTED-CHECKSUM 2680149140608 :TICKS 32419
   :HEAP-BYTES 262112 :SECONDS 0.032419d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570464
     :EXPECTED-CHECKSUM 1340074570464 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 64 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340074570144 :EXPECTED-CHECKSUM 1340074570144 :TICKS 26598
   :HEAP-BYTES 131056 :SECONDS 0.026598d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 64 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340074570144 :EXPECTED-CHECKSUM 1340074570144 :TICKS 26681
   :HEAP-BYTES 0 :SECONDS 0.026681d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 64 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 5360298281728 :EXPECTED-CHECKSUM 5360298281728 :TICKS 45932
   :HEAP-BYTES 524224 :SECONDS 0.045932d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570464
     :EXPECTED-CHECKSUM 1340074570464 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570528
     :EXPECTED-CHECKSUM 1340074570528 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570592
     :EXPECTED-CHECKSUM 1340074570592 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 64 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 2680149140608 :EXPECTED-CHECKSUM 2680149140608 :TICKS 30930
   :HEAP-BYTES 262112 :SECONDS 0.03093d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570464
     :EXPECTED-CHECKSUM 1340074570464 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 64 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340074570144 :EXPECTED-CHECKSUM 1340074570144 :TICKS 26713
   :HEAP-BYTES 131056 :SECONDS 0.026713d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 64 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340074570144 :EXPECTED-CHECKSUM 1340074570144 :TICKS 29470
   :HEAP-BYTES 0 :SECONDS 0.02947d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 64 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 5360298281728 :EXPECTED-CHECKSUM 5360298281728 :TICKS 38258
   :HEAP-BYTES 524224 :SECONDS 0.038258d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570464
     :EXPECTED-CHECKSUM 1340074570464 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570528
     :EXPECTED-CHECKSUM 1340074570528 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570592
     :EXPECTED-CHECKSUM 1340074570592 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 64 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 2680149140608 :EXPECTED-CHECKSUM 2680149140608 :TICKS 32369
   :HEAP-BYTES 262112 :SECONDS 0.032369d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570464
     :EXPECTED-CHECKSUM 1340074570464 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 64 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340074570144 :EXPECTED-CHECKSUM 1340074570144 :TICKS 32573
   :HEAP-BYTES 131056 :SECONDS 0.032573d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 64 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340074570144 :EXPECTED-CHECKSUM 1340074570144 :TICKS 28293
   :HEAP-BYTES 0 :SECONDS 0.028293d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 64 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 5360298281728 :EXPECTED-CHECKSUM 5360298281728 :TICKS 38951
   :HEAP-BYTES 524224 :SECONDS 0.038951d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570464
     :EXPECTED-CHECKSUM 1340074570464 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570528
     :EXPECTED-CHECKSUM 1340074570528 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570592
     :EXPECTED-CHECKSUM 1340074570592 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 64 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 2680149140608 :EXPECTED-CHECKSUM 2680149140608 :TICKS 35173
   :HEAP-BYTES 262112 :SECONDS 0.035173d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570464
     :EXPECTED-CHECKSUM 1340074570464 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 64 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340074570144 :EXPECTED-CHECKSUM 1340074570144 :TICKS 27098
   :HEAP-BYTES 131056 :SECONDS 0.027098d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 64 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340074570144 :EXPECTED-CHECKSUM 1340074570144 :TICKS 28116
   :HEAP-BYTES 0 :SECONDS 0.028116d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 64 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 5360298281728 :EXPECTED-CHECKSUM 5360298281728 :TICKS 44502
   :HEAP-BYTES 524224 :SECONDS 0.044502d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570464
     :EXPECTED-CHECKSUM 1340074570464 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570528
     :EXPECTED-CHECKSUM 1340074570528 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570592
     :EXPECTED-CHECKSUM 1340074570592 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 64 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 2680149140608 :EXPECTED-CHECKSUM 2680149140608 :TICKS 34338
   :HEAP-BYTES 262112 :SECONDS 0.034338d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570464
     :EXPECTED-CHECKSUM 1340074570464 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 64 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340074570144 :EXPECTED-CHECKSUM 1340074570144 :TICKS 29826
   :HEAP-BYTES 131056 :SECONDS 0.029826d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 64 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340074570144 :EXPECTED-CHECKSUM 1340074570144 :TICKS 28829
   :HEAP-BYTES 0 :SECONDS 0.028829d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340074570144
     :EXPECTED-CHECKSUM 1340074570144 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 64 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 5360135081984 :EXPECTED-CHECKSUM 5360135081984 :TICKS 17618
   :HEAP-BYTES 524224 :SECONDS 0.017618d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770464
     :EXPECTED-CHECKSUM 1340033770464 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770528
     :EXPECTED-CHECKSUM 1340033770528 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770592
     :EXPECTED-CHECKSUM 1340033770592 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 64 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 2680067540864 :EXPECTED-CHECKSUM 2680067540864 :TICKS 17179
   :HEAP-BYTES 262112 :SECONDS 0.017179d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770464
     :EXPECTED-CHECKSUM 1340033770464 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 64 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340033770400 :EXPECTED-CHECKSUM 1340033770400 :TICKS 12332
   :HEAP-BYTES 131056 :SECONDS 0.012332d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 64 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340033770400 :EXPECTED-CHECKSUM 1340033770400 :TICKS 12912
   :HEAP-BYTES 0 :SECONDS 0.012912d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 64 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 5360135081984 :EXPECTED-CHECKSUM 5360135081984 :TICKS 21365
   :HEAP-BYTES 524224 :SECONDS 0.021365d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770464
     :EXPECTED-CHECKSUM 1340033770464 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770528
     :EXPECTED-CHECKSUM 1340033770528 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770592
     :EXPECTED-CHECKSUM 1340033770592 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 64 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 2680067540864 :EXPECTED-CHECKSUM 2680067540864 :TICKS 15239
   :HEAP-BYTES 262112 :SECONDS 0.015239d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770464
     :EXPECTED-CHECKSUM 1340033770464 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 64 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340033770400 :EXPECTED-CHECKSUM 1340033770400 :TICKS 12537
   :HEAP-BYTES 131056 :SECONDS 0.012537d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 64 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340033770400 :EXPECTED-CHECKSUM 1340033770400 :TICKS 13139
   :HEAP-BYTES 0 :SECONDS 0.013139d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 64 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 5360135081984 :EXPECTED-CHECKSUM 5360135081984 :TICKS 20308
   :HEAP-BYTES 524224 :SECONDS 0.020308d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770464
     :EXPECTED-CHECKSUM 1340033770464 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770528
     :EXPECTED-CHECKSUM 1340033770528 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770592
     :EXPECTED-CHECKSUM 1340033770592 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 64 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 2680067540864 :EXPECTED-CHECKSUM 2680067540864 :TICKS 15028
   :HEAP-BYTES 262112 :SECONDS 0.015028d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770464
     :EXPECTED-CHECKSUM 1340033770464 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 64 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340033770400 :EXPECTED-CHECKSUM 1340033770400 :TICKS 13232
   :HEAP-BYTES 131056 :SECONDS 0.013232d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 64 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340033770400 :EXPECTED-CHECKSUM 1340033770400 :TICKS 14490
   :HEAP-BYTES 0 :SECONDS 0.01449d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 64 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 5360135081984 :EXPECTED-CHECKSUM 5360135081984 :TICKS 22991
   :HEAP-BYTES 524224 :SECONDS 0.022991d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770464
     :EXPECTED-CHECKSUM 1340033770464 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770528
     :EXPECTED-CHECKSUM 1340033770528 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770592
     :EXPECTED-CHECKSUM 1340033770592 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 64 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 2680067540864 :EXPECTED-CHECKSUM 2680067540864 :TICKS 14458
   :HEAP-BYTES 262112 :SECONDS 0.014458d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770464
     :EXPECTED-CHECKSUM 1340033770464 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 64 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340033770400 :EXPECTED-CHECKSUM 1340033770400 :TICKS 13539
   :HEAP-BYTES 131056 :SECONDS 0.013539d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 64 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340033770400 :EXPECTED-CHECKSUM 1340033770400 :TICKS 12328
   :HEAP-BYTES 0 :SECONDS 0.012328d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 64 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 5360135081984 :EXPECTED-CHECKSUM 5360135081984 :TICKS 20181
   :HEAP-BYTES 524224 :SECONDS 0.020181d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770464
     :EXPECTED-CHECKSUM 1340033770464 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770528
     :EXPECTED-CHECKSUM 1340033770528 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770592
     :EXPECTED-CHECKSUM 1340033770592 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 64 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 2680067540864 :EXPECTED-CHECKSUM 2680067540864 :TICKS 16976
   :HEAP-BYTES 262112 :SECONDS 0.016976d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770464
     :EXPECTED-CHECKSUM 1340033770464 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 64 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340033770400 :EXPECTED-CHECKSUM 1340033770400 :TICKS 14969
   :HEAP-BYTES 131056 :SECONDS 0.014969d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 64 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 1340033770400 :EXPECTED-CHECKSUM 1340033770400 :TICKS 14815
   :HEAP-BYTES 0 :SECONDS 0.014815d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 1340033770400
     :EXPECTED-CHECKSUM 1340033770400 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 8 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 42949849360000 :EXPECTED-CHECKSUM 42949849360000 :TICKS
   36366 :HEAP-BYTES 524224 :SECONDS 0.036366d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 8 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 21474924680000 :EXPECTED-CHECKSUM 21474924680000 :TICKS
   32573 :HEAP-BYTES 262112 :SECONDS 0.032573d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 8 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737462340000 :EXPECTED-CHECKSUM 10737462340000 :TICKS
   31826 :HEAP-BYTES 131056 :SECONDS 0.031826d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 8 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737462340000 :EXPECTED-CHECKSUM 10737462340000 :TICKS
   26870 :HEAP-BYTES 0 :SECONDS 0.02687d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 8 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 42949849360000 :EXPECTED-CHECKSUM 42949849360000 :TICKS
   36736 :HEAP-BYTES 524224 :SECONDS 0.036736d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 8 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 21474924680000 :EXPECTED-CHECKSUM 21474924680000 :TICKS
   33591 :HEAP-BYTES 262112 :SECONDS 0.033591d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 8 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737462340000 :EXPECTED-CHECKSUM 10737462340000 :TICKS
   27560 :HEAP-BYTES 131056 :SECONDS 0.02756d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 8 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737462340000 :EXPECTED-CHECKSUM 10737462340000 :TICKS
   28407 :HEAP-BYTES 0 :SECONDS 0.028407d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 8 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 42949849360000 :EXPECTED-CHECKSUM 42949849360000 :TICKS
   40863 :HEAP-BYTES 524224 :SECONDS 0.040863d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 8 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 21474924680000 :EXPECTED-CHECKSUM 21474924680000 :TICKS
   32668 :HEAP-BYTES 262112 :SECONDS 0.032668d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 8 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737462340000 :EXPECTED-CHECKSUM 10737462340000 :TICKS
   25521 :HEAP-BYTES 131056 :SECONDS 0.025521d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 8 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737462340000 :EXPECTED-CHECKSUM 10737462340000 :TICKS
   27220 :HEAP-BYTES 0 :SECONDS 0.02722d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 8 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 42949849360000 :EXPECTED-CHECKSUM 42949849360000 :TICKS
   41850 :HEAP-BYTES 524224 :SECONDS 0.04185d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 8 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 21474924680000 :EXPECTED-CHECKSUM 21474924680000 :TICKS
   32768 :HEAP-BYTES 262112 :SECONDS 0.032768d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 8 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737462340000 :EXPECTED-CHECKSUM 10737462340000 :TICKS
   29686 :HEAP-BYTES 131056 :SECONDS 0.029686d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 8 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737462340000 :EXPECTED-CHECKSUM 10737462340000 :TICKS
   28746 :HEAP-BYTES 0 :SECONDS 0.028746d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 8 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 42949849360000 :EXPECTED-CHECKSUM 42949849360000 :TICKS
   38406 :HEAP-BYTES 524224 :SECONDS 0.038406d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 8 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 21474924680000 :EXPECTED-CHECKSUM 21474924680000 :TICKS
   30130 :HEAP-BYTES 262112 :SECONDS 0.03013d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 8 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737462340000 :EXPECTED-CHECKSUM 10737462340000 :TICKS
   26754 :HEAP-BYTES 131056 :SECONDS 0.026754d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 8 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737462340000 :EXPECTED-CHECKSUM 10737462340000 :TICKS
   27724 :HEAP-BYTES 0 :SECONDS 0.027724d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737462340000
     :EXPECTED-CHECKSUM 10737462340000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 8 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 42949684240000 :EXPECTED-CHECKSUM 42949684240000 :TICKS
   19671 :HEAP-BYTES 524224 :SECONDS 0.019671d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 8 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 21474842120000 :EXPECTED-CHECKSUM 21474842120000 :TICKS
   12496 :HEAP-BYTES 262112 :SECONDS 0.012496d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 8 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737421060000 :EXPECTED-CHECKSUM 10737421060000 :TICKS
   13625 :HEAP-BYTES 131056 :SECONDS 0.013625d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 8 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737421060000 :EXPECTED-CHECKSUM 10737421060000 :TICKS
   11646 :HEAP-BYTES 0 :SECONDS 0.011646d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 8 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 42949684240000 :EXPECTED-CHECKSUM 42949684240000 :TICKS
   23422 :HEAP-BYTES 524224 :SECONDS 0.023422d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 8 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 21474842120000 :EXPECTED-CHECKSUM 21474842120000 :TICKS
   16180 :HEAP-BYTES 262112 :SECONDS 0.01618d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 8 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737421060000 :EXPECTED-CHECKSUM 10737421060000 :TICKS
   12627 :HEAP-BYTES 131056 :SECONDS 0.012627d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 8 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737421060000 :EXPECTED-CHECKSUM 10737421060000 :TICKS
   11961 :HEAP-BYTES 0 :SECONDS 0.011961d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 8 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 42949684240000 :EXPECTED-CHECKSUM 42949684240000 :TICKS
   19973 :HEAP-BYTES 524224 :SECONDS 0.019973d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 8 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 21474842120000 :EXPECTED-CHECKSUM 21474842120000 :TICKS
   15999 :HEAP-BYTES 262112 :SECONDS 0.015999d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 8 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737421060000 :EXPECTED-CHECKSUM 10737421060000 :TICKS
   15413 :HEAP-BYTES 131056 :SECONDS 0.015413d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 8 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737421060000 :EXPECTED-CHECKSUM 10737421060000 :TICKS
   13724 :HEAP-BYTES 0 :SECONDS 0.013724d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 8 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 42949684240000 :EXPECTED-CHECKSUM 42949684240000 :TICKS
   17657 :HEAP-BYTES 524224 :SECONDS 0.017657d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 8 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 21474842120000 :EXPECTED-CHECKSUM 21474842120000 :TICKS
   14724 :HEAP-BYTES 262112 :SECONDS 0.014724d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 8 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737421060000 :EXPECTED-CHECKSUM 10737421060000 :TICKS
   13223 :HEAP-BYTES 131056 :SECONDS 0.013223d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 8 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737421060000 :EXPECTED-CHECKSUM 10737421060000 :TICKS
   13103 :HEAP-BYTES 0 :SECONDS 0.013103d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 8 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 42949684240000 :EXPECTED-CHECKSUM 42949684240000 :TICKS
   26017 :HEAP-BYTES 524224 :SECONDS 0.026017d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 8 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 21474842120000 :EXPECTED-CHECKSUM 21474842120000 :TICKS
   14274 :HEAP-BYTES 262112 :SECONDS 0.014274d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 8 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737421060000 :EXPECTED-CHECKSUM 10737421060000 :TICKS
   55768 :HEAP-BYTES 131056 :SECONDS 0.055768d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 8 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 10737421060000 :EXPECTED-CHECKSUM 10737421060000 :TICKS
   11927 :HEAP-BYTES 0 :SECONDS 0.011927d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 10737421060000
     :EXPECTED-CHECKSUM 10737421060000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 1 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 343597557760000 :EXPECTED-CHECKSUM 343597557760000 :TICKS
   39591 :HEAP-BYTES 524224 :SECONDS 0.039591d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 1 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 171798778880000 :EXPECTED-CHECKSUM 171798778880000 :TICKS
   25465 :HEAP-BYTES 262112 :SECONDS 0.025465d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 1 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899389440000 :EXPECTED-CHECKSUM 85899389440000 :TICKS
   24755 :HEAP-BYTES 131056 :SECONDS 0.024755d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 1 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899389440000 :EXPECTED-CHECKSUM 85899389440000 :TICKS
   24561 :HEAP-BYTES 0 :SECONDS 0.024561d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 1 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 343597557760000 :EXPECTED-CHECKSUM 343597557760000 :TICKS
   36099 :HEAP-BYTES 524224 :SECONDS 0.036099d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 1 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 171798778880000 :EXPECTED-CHECKSUM 171798778880000 :TICKS
   26205 :HEAP-BYTES 262112 :SECONDS 0.026205d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 1 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899389440000 :EXPECTED-CHECKSUM 85899389440000 :TICKS
   24588 :HEAP-BYTES 131056 :SECONDS 0.024588d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 1 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899389440000 :EXPECTED-CHECKSUM 85899389440000 :TICKS
   24429 :HEAP-BYTES 0 :SECONDS 0.024429d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 1 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 343597557760000 :EXPECTED-CHECKSUM 343597557760000 :TICKS
   42007 :HEAP-BYTES 524224 :SECONDS 0.042007d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 1 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 171798778880000 :EXPECTED-CHECKSUM 171798778880000 :TICKS
   25683 :HEAP-BYTES 262112 :SECONDS 0.025683d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 1 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899389440000 :EXPECTED-CHECKSUM 85899389440000 :TICKS
   24624 :HEAP-BYTES 131056 :SECONDS 0.024624d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 1 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899389440000 :EXPECTED-CHECKSUM 85899389440000 :TICKS
   24597 :HEAP-BYTES 0 :SECONDS 0.024597d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 1 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 343597557760000 :EXPECTED-CHECKSUM 343597557760000 :TICKS
   38647 :HEAP-BYTES 524224 :SECONDS 0.038647d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 1 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 171798778880000 :EXPECTED-CHECKSUM 171798778880000 :TICKS
   29455 :HEAP-BYTES 262112 :SECONDS 0.029455d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 1 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899389440000 :EXPECTED-CHECKSUM 85899389440000 :TICKS
   24871 :HEAP-BYTES 131056 :SECONDS 0.024871d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 1 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899389440000 :EXPECTED-CHECKSUM 85899389440000 :TICKS
   25385 :HEAP-BYTES 0 :SECONDS 0.025385d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 4 :N 1 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 343597557760000 :EXPECTED-CHECKSUM 343597557760000 :TICKS
   49561 :HEAP-BYTES 524224 :SECONDS 0.049561d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 2 :N 1 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 171798778880000 :EXPECTED-CHECKSUM 171798778880000 :TICKS
   26233 :HEAP-BYTES 262112 :SECONDS 0.026233d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :PARALLEL :READERS 1 :N 1 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899389440000 :EXPECTED-CHECKSUM 85899389440000 :TICKS
   24656 :HEAP-BYTES 131056 :SECONDS 0.024656d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T
   :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :CACHE-HIT :EXECUTION :SERIAL :READERS 1 :N 1 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899389440000 :EXPECTED-CHECKSUM 85899389440000 :TICKS
   24616 :HEAP-BYTES 0 :SECONDS 0.024616d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899389440000
     :EXPECTED-CHECKSUM 85899389440000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 2 :MEASUREMENT
   :START-RESOLVE-PROBE-COPY-FINISH-ABANDON :GATE-STARTUP-WAIT-JOIN-IN-WINDOW
   NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 1 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 343597393280000 :EXPECTED-CHECKSUM 343597393280000 :TICKS
   22897 :HEAP-BYTES 524224 :SECONDS 0.022897d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 1 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 171798696640000 :EXPECTED-CHECKSUM 171798696640000 :TICKS
   11708 :HEAP-BYTES 262112 :SECONDS 0.011708d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 1 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899348320000 :EXPECTED-CHECKSUM 85899348320000 :TICKS
   11247 :HEAP-BYTES 131056 :SECONDS 0.011247d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 1 :REPLICA 4
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899348320000 :EXPECTED-CHECKSUM 85899348320000 :TICKS
   10989 :HEAP-BYTES 0 :SECONDS 0.010989d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 1 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 343597393280000 :EXPECTED-CHECKSUM 343597393280000 :TICKS
   24263 :HEAP-BYTES 524224 :SECONDS 0.024263d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 1 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 171798696640000 :EXPECTED-CHECKSUM 171798696640000 :TICKS
   11679 :HEAP-BYTES 262112 :SECONDS 0.011679d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 1 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899348320000 :EXPECTED-CHECKSUM 85899348320000 :TICKS
   11054 :HEAP-BYTES 131056 :SECONDS 0.011054d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 1 :REPLICA 3
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899348320000 :EXPECTED-CHECKSUM 85899348320000 :TICKS
   13295 :HEAP-BYTES 0 :SECONDS 0.013295d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 1 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 343597393280000 :EXPECTED-CHECKSUM 343597393280000 :TICKS
   21565 :HEAP-BYTES 524224 :SECONDS 0.021565d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 1 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 171798696640000 :EXPECTED-CHECKSUM 171798696640000 :TICKS
   18918 :HEAP-BYTES 262112 :SECONDS 0.018918d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 1 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899348320000 :EXPECTED-CHECKSUM 85899348320000 :TICKS
   11079 :HEAP-BYTES 131056 :SECONDS 0.011079d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 1 :REPLICA 2
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899348320000 :EXPECTED-CHECKSUM 85899348320000 :TICKS
   11548 :HEAP-BYTES 0 :SECONDS 0.011548d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 1 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 343597393280000 :EXPECTED-CHECKSUM 343597393280000 :TICKS
   25838 :HEAP-BYTES 524224 :SECONDS 0.025838d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 1 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 171798696640000 :EXPECTED-CHECKSUM 171798696640000 :TICKS
   19509 :HEAP-BYTES 262112 :SECONDS 0.019509d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 1 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899348320000 :EXPECTED-CHECKSUM 85899348320000 :TICKS
   11409 :HEAP-BYTES 131056 :SECONDS 0.011409d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 1 :REPLICA 1
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899348320000 :EXPECTED-CHECKSUM 85899348320000 :TICKS
   11079 :HEAP-BYTES 0 :SECONDS 0.011079d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 4 :N 1 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 80000 :COMPLETED
   80000 :CHECKSUM 343597393280000 :EXPECTED-CHECKSUM 343597393280000 :TICKS
   25438 :HEAP-BYTES 524224 :SECONDS 0.025438d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 2 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 3 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 2 :N 1 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 40000 :COMPLETED
   40000 :CHECKSUM 171798696640000 :EXPECTED-CHECKSUM 171798696640000 :TICKS
   15498 :HEAP-BYTES 262112 :SECONDS 0.015498d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL)
    (:WORKER 1 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :PARALLEL :READERS 1 :N 1 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899348320000 :EXPECTED-CHECKSUM 85899348320000 :TICKS
   10988 :HEAP-BYTES 131056 :SECONDS 0.010988d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW T :STATUS :OK :DIAGNOSTIC NIL)
  (:SCENARIO :RESOLVE :EXECUTION :SERIAL :READERS 1 :N 1 :REPLICA 0
   :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :REQUESTED 20000 :COMPLETED
   20000 :CHECKSUM 85899348320000 :EXPECTED-CHECKSUM 85899348320000 :TICKS
   10998 :HEAP-BYTES 0 :SECONDS 0.010998d0 :QUIESCENT T :WORKERS
   ((:WORKER 0 :REQUESTED 20000 :COMPLETED 20000 :CHECKSUM 85899348320000
     :EXPECTED-CHECKSUM 85899348320000 :FAILURE NIL))
   :ROOT-ACQUISITIONS-PER-CYCLE 1 :MEASUREMENT :START-RESOLVE-ABANDON
   :GATE-STARTUP-WAIT-JOIN-IN-WINDOW NIL :STATUS :OK :DIAGNOSTIC NIL))
 :DIAGNOSTIC NIL :STARTED-AT-UNIVERSAL-TIME 4000908566 :ENVIRONMENT
 (:LISP \"2.6.9\" :MACHINE \"ARM64\" :OS \"Darwin\" :OS-VERSION \"27.0.0\" :CWD
  \"/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/\" :TIMER-UNITS
  1000000 :HEAP :SB-EXT-GET-BYTES-CONSED :HEAP-SCOPE :WHOLE-PROCESS
  :EXTERNAL-LOAD :UNCONTROLLED)
 :CAMPAIGN
 (:N (1 8 64) :VALUE-BYTES 16 :SCENARIOS (:RESOLVE :CACHE-HIT) :REPLICAS 5
  :COUNT-PER-READER 20000 :WARMUP-PER-READER 1000 :CONFIGURATIONS
  ((:SERIAL 1) (:PARALLEL 1) (:PARALLEL 2) (:PARALLEL 4)) :WINDOWS 120
  :MEASURED-CYCLES 4800000 :WARMUP-CYCLES 240000 :DEADLINE-SECONDS 600
  :WINDOW-DEADLINE-SECONDS 30 :CLEANUP-SECONDS 2 :CACHE-MEASUREMENT
  :RESOLVE-PLUS-PROBE :CACHE-ROOT-ACQUISITIONS-PER-CYCLE 2)
 :STATIC-RISKS
 (:PARENT-SOURCE-FREEZE-REQUIRED :NOT-EXECUTED-BY-AUTHOR :SBCL64-REQUIRED
  :TESTS-SYSTEM-LOADED-OUTSIDE-CLOCK :CLOSED-ONLY :ORDINARY-V2-ONLY
  :FIXTURE-PUBLISHED-PRIMARY-ASSUMPTION :SINGLE-FRAGMENT-ARENA-ORDER
  :CANDIDATE-OUTPUT-PIN-CHECKS-IN-WINDOW :DEADLINE-POLL-EVERY-256-CYCLES
  :PARALLEL-GATE-WAIT-STARTUP-AND-JOIN-IN-WINDOW
  :GATE-NOT-PROOF-OF-TEMPORAL-OVERLAP
  :SELF-TEST-COUNT8-NOT-PROOF-OF-TEMPORAL-OVERLAP
  :FIXED-COUNT-ABORTS-ON-DEADLINE
  :CAMPAIGN-DEADLINE-COOPERATIVE-IN-COLD-LOAD-AND-NATIVE-IO
  :HEAP-IS-WHOLE-PROCESS-ALLOCATION-NOT-RSS :FAILED-CLEANUP-OUTSIDE-WINDOW
  :ALLOCATIONS-AND-COMPILER-WARNINGS-UNVERIFIED
  :NO-CONTROLLER-PUBLICATION-OR-RECLAIM-MEASUREMENT :NO-PERFORMANCE-THRESHOLD
  :NO-DATABASE-THROUGHPUT-CLAIM))
GET-SERIES-CAPTURE (:FINISHED-AT-UNIVERSAL-TIME 4000908573 :SCHEMA-VERSION 1 :KIND :GET-SERIES-CAPTURE :STATUS :OK :COMMAND (\"sbcl\" \"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" \"tools/get-series-bench.lisp\" \"--bench\" \"spikes/out/get-series-bench-h/\") :HELPER-SOURCES-BEFORE ((:FILE \"tools/get-series-bench.lisp\" :SHA256 \"1ac1937218cf7c22354243f0c4f0bf5e1b300d874b47c8dfee78cce5e11ea19e\")) :HELPER-SOURCES-AFTER ((:FILE \"tools/get-series-bench.lisp\" :SHA256 \"1ac1937218cf7c22354243f0c4f0bf5e1b300d874b47c8dfee78cce5e11ea19e\")) :RAW-ROOT \"spikes/out/get-series-bench-h/\" :RAW-FILES ((:FILE \"controller-1.tmp\" :BYTES 0 :SHA256 \"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855\") (:FILE \"controller-64.tmp\" :BYTES 0 :SHA256 \"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855\") (:FILE \"controller-8.tmp\" :BYTES 0 :SHA256 \"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855\") (:FILE \"report.lisp\" :BYTES 85297 :SHA256 \"1863dd5d9a4fef4893ecd08db3aad483db36e1b8aa72134b148964f002316786\")) :EXIT-CODE 0 :DIAGNOSTIC NIL :LIMITS (:SINGLE-OWNER-FROZEN-HELPER-SOURCE :RAW-DIGESTS-AT-COMMAND-EXIT :NOT-HOSTILE-HOST-AUTHENTICATION :NESTED-COMMAND-OWNS-TIMEOUT))
"
 :STDERR "" :EXIT-CODE 0 :LIMITS
 (:COMMAND-OUTPUT-IS-RAW :WALL-TIME-INCLUDES-ENTIRE-COMMAND
  :NO-AUTOMATIC-REQUIREMENT-PROMOTION))
