(:FINISHED-AT-UNIVERSAL-TIME 4000906463 :CONDITION-TYPE "INVALID-ARGUMENT"
 :DIAGNOSTIC "ArcDocDB: LOTTO-OWNED" :SCHEMA-VERSION 1 :KIND
 :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE :TESTS :COMPILED T
 :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "08b80240b37fb703ac2cfb9acde1dfa8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "1c6bb27d155987a246bf063c382d0649")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "56badeccb6c6a18693c8b41cb3cd596a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "ef026b225935c507ddcb36372c248916")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "7b0610e2e03d6cccdad102f2ac7073b4")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "a35c66c76db58caed98428bc940312e2")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "34837855567edc48146cfa34256cb35e")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "0e444d2f26c04083196c15586ecff821")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "2ec18073e683f74bfa41b87d8ab52c00")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/wal/types.fasl"
   :FASL-MD5 "5c7431d958d6bca34a4d07ded3a51228")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/wal/package.fasl"
   :FASL-MD5 "2084b450615b0b87dc9fd411e9b05917")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/wal/group.fasl"
   :FASL-MD5 "dcad4458428ce89828f4f78e1071819d")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/wal/executor.fasl"
   :FASL-MD5 "f9be7dc385cabed6022fa260572227af")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/wal/csn.fasl"
   :FASL-MD5 "5dd93426f9865e0ba7a08980685bbe0a")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/wal/builder.fasl"
   :FASL-MD5 "992f1358a0000f7248faf3039f4eccf1")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "8b0edcb65ea8b9301abb01def8942f2a")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "ac9814432437f59cbb4537794fa1cbb9")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "4f70a4f848248c6d52283ea710645b3f")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/storage/package.fasl"
   :FASL-MD5 "e4ba82f6387d264a7c3384091cb5a11c")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "4b4717931d556fe6e7249e2fbeaddc1c")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/storage/formats.fasl"
   :FASL-MD5 "76e069924752a9e7eab152022e1db2c9")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "0a5d9e021dc36210d1bd4accc92212e7")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "d63ec6614ae0e6880bcd4e96c0baccad")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "ba5343654780a34e5a34e167d111bbb9")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "814fb3301f8f5be957dd932fa57e7be9")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "e39ecf61d5c87c213d9787c2946e612c")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "3462797b30c5e6165360fedb2de4c76c")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/types.fasl"
   :FASL-MD5 "91875636105835fdce5488f890ef25f3")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "f504a682c7fbe28980fb3385ce14ce77")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "a7a7e0295c1e856db83704703616117a")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "374b6bc431192ee9b4b5c92eb0fef1ba")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/retirement.fasl"
   :FASL-MD5 "31b5e33382fa2785344c58756cff8e00")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/query.fasl"
   :FASL-MD5 "b97920d05770aeaaf98442688016cdfb")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/publication.fasl"
   :FASL-MD5 "a934dfc9445744dda8a30ef4545a7825")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/package.fasl"
   :FASL-MD5 "b1a462816332f6bfa9d280e3fc310e35")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/ownership.fasl"
   :FASL-MD5 "cf85792880daa9febff4e88655b5f507")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/io-events.fasl"
   :FASL-MD5 "038a0d74235851427c9d0ca4d80b95f2")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/series/events.fasl"
   :FASL-MD5 "c295e0cbb1aa4a5d34fe8c2412a62587")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "996ac9773757899cf8c74310225b62c6")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/package.fasl"
   :FASL-MD5 "0c3727726cb7614ec99afed5ce462fef")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "f173dafaddf475c45170ad784c9ffa38")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "6b9269ab7d498b51c69a5bf0c394f23f")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "13abdf6db9de60131e5e3f8377d6428d")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "dae4c86b58ecfbd8f07c51570e1538ee")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "1db96214327dd0099e566fbd8c1c8483")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "2d73771c321452683dddcbc134f45fc2")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "2ffd08c5da2aeea7c4c502b49680c54d")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "e76facbbe932a1a5df3ff07c880ebc53")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "433bc87097118cae83787d8ea1ce2e2c")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "41b24d053679648ebad331ec84358569")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "0b5a937104f612552aa0dee2f5460bda")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "2a75b28ce597fa0ebf68017dad3595ce")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "3a5a63ba0175bce52b09876a0c8a19f4")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "3a2db57c718210dace21d17621769a23")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "aec28490022556361f70f0022f46aae2")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/read/types.fasl"
   :FASL-MD5 "57f42a3315025dd170a3e44578f47834")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/read/task.fasl"
   :FASL-MD5 "38e3e728c542005b17c8f06d57808847")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/read/package.fasl"
   :FASL-MD5 "b1242b069913298569ee91c1fca791bc")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/read/core.fasl"
   :FASL-MD5 "c137d3206eef284c79b8c5a78c4cc51e")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/package.fasl"
   :FASL-MD5 "39abf74f8146cf30650b47256c78d0cf")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "cc9f6d0835c0b079c6654ed894175239")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "cc216ccff76bab8ba38e707feb2cc7d2")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "38b10cdc930e26efa993caa5ae46f47b")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "9f2c7a81620aed0af438471d5cfaac1d")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "b96000c497a0374cb4b8b3fc9ac4ca33")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "8dece13b78cd6d439f9e2a43053d2719")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "de3ff36a9e8eeec74da2704cb92b6e7d")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "851e1ebcc8869ff769f8f43a48f47ff5")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "db8497f9cff35b1ee261f1f410f46ca6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/io/types.fasl"
   :FASL-MD5 "c34995ea2904454b031b582f9a82e725")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/io/transfer.fasl"
   :FASL-MD5 "65e1b64829dff4b6861991d81de8df6f")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c9380ad46a1d7acf41655aaed20db478"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/io/package.fasl"
   :FASL-MD5 "b907708fd989621a2e70b77dff6f0c9a")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "9500cfb800603de002d6d2b24f1bf056"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/io/native.fasl"
   :FASL-MD5 "c28ec7bffd4ad4d1142905093c189ea5")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "d16c78373ccd43b1aaa3b8c45af89341")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/io/flush.fasl"
   :FASL-MD5 "67edd2ea9764b6a86f5d59ebe001b51b")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/write.fasl"
   :FASL-MD5 "7f67448c75e83d6255c1c3fdbea67d4d")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/validation.fasl"
   :FASL-MD5 "5833309f4d03daf683a136678ebe9548")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/types.fasl"
   :FASL-MD5 "94663b7f030798c6f468b138df65e7f8")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/relocate.fasl"
   :FASL-MD5 "e8a637d91b3dfd71a3fe60a606be0e05")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "0dc2395832f5a1981abf6f1dad11fc14")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "7b1442fedaee72541bef58a54b247357")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "503cadcd47a6b94a284f08eb3632ce90")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "201ff579c7bec3e646c8ef7bd67f6dfb")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/read.fasl"
   :FASL-MD5 "bfe0fe73a01bb069641c198565da2a04")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "ce1e10285a60d572c4a3c4e1b795480e")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "7631cc03d3341c5323763719976d50fd")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "c1a8b72b821693d6d79121f2e81c5b62")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "8c66d8a5ed4729275e0f12e8669074d8")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "0bde919c940d62212897ab5c3351be52")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "aab70d41ab3218f95d512150725a6cab")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "a83e0ca5b4d4d222a2deaa1176f4cf02")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "f4e94f2c72de0c60e700fb7cc0376cee")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "291a1cbdc03c89eaf13c117d67e37696")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "6f037c6dbe4a61ddae629ca53b85385c")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/package.fasl"
   :FASL-MD5 "38af64bbd0086c8aa5c5a32705d68b1e")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "55eb6e20537793b1033f07e2e026e090")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "083790733fba846f5b5c01fb963b3e58")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/index/core.fasl"
   :FASL-MD5 "44dc666bcbb12f2cfcb2e0a15a37c074")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/hash/package.fasl"
   :FASL-MD5 "b6383d57defd9ff0efbc45a1f0e8e974")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "9189a3c443563ed749212500e395d809")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "0c22de307cf35f0f108e332c40195911")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "8edfdfc3969e7f18e6952fd7c65800cf")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get/types.fasl"
   :FASL-MD5 "332ea793bb40bd087988e025a8baeba3")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get/target.fasl"
   :FASL-MD5 "cd087c2918038ea74f80c702d98babd5")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get/segment.fasl"
   :FASL-MD5 "7b7648cf0e7399281c5bf36280eb3f7a")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get/package.fasl"
   :FASL-MD5 "b26f7d2e6186ccbbe13a53f78c09bb3e")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get/lookup.fasl"
   :FASL-MD5 "77298c937bda970eecffd738866ddce0")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "35fe70a42bcb4ea16eebefec89ef9651")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get/build.fasl"
   :FASL-MD5 "28e640659b61e1fce9d2ab9f05cf0cee")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "49de4be7d5633ccf719c4cc7edcddd4a")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "ae47b588ddfd117729af193fb38f3534")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "18f99ab8581c064bbef067b3aa607c57")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "e67cc827c5e45ff9dac5955dd78a6013")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "113edd2c4d874e22450fad5c042d7053")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "b537f636f38cd80ae73e2131c72532b4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "d19b948d53889f9fbd21e0a4194693cd")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "6f138e397fa6c06532909c782695b137")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "a4ed64b9a5ab6203d1c692719fb0345c")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "a27a021145dca8b21f037afec8b0803a")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "521737861e057d663964b0c030552587" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "2082875cc788ca3bd670c42934d577e7")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "10b4fee46801efa20652d4cb1f4c59cf")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "6eb7a525176722cd952d6ead207b62c6")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "5db400f6c4e60fc00a3fd5b9fd82e6b4")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "d73de75dbbf0ae555e2a9c8cab0ab516")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "c8c9e171aed04da24c738f37b34ed540")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "2b8193aab6801de19e26fa55e7c53f87" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "b05a29cb76ea8ba9bab9e2b700dad98a")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "4b771680a2d239ddd32095ba966f586c")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "99738bf3ec0a015607d831254877b7ee")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "5f8ab7243b03366e1caaadeb79e33175")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/foundation/record.fasl"
   :FASL-MD5 "ba9d3523b56181e806d76d4cc9e584a8")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/foundation/package.fasl"
   :FASL-MD5 "6458f2a0a99f6ffdfe96eb3fcdc0cc44")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "8a3fcc65ef9930da5d09dcd38a14a355")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "11e54d8a19ebe5e14a1309588da41bc5")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "a834e518e7d0acfce82356ffc3df4c69")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "baa16cba0d98d7be4d520fffd421bc5b")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/execution/writer.fasl"
   :FASL-MD5 "7f73d36eed73e6d54222fc4bc3aac0e5")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "569a5f0c75a4ac0989a91bafb85101b1")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "e68fac20ca9044111b00895ddb6e347a")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "7b50805621c506533ec04458aca7e225")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "727efe9094b7901ea9df55278a644424")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/execution/ready.fasl"
   :FASL-MD5 "943c245bbb091f926ba6967b33547ae0")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "0d0d6f2f0e3b210e3ab6742a27b4b1e7")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "0bafd96bb7b85aa0bac38ba684a5ee3b")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/execution/queue.fasl"
   :FASL-MD5 "a9a0876a4dd021d85c67e3f7aff7e159")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/execution/package.fasl"
   :FASL-MD5 "6d7791664a581c6bf83ad494d19be420")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "81b05724229142dc72f9098f66942e9f")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/epochs/types.fasl"
   :FASL-MD5 "da12c4abc9b1866067fc255caf080b16")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "8a72e40fe0a3b46031be888007ee1cdc")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "3d57086a787530255096098a91a5595d")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/epochs/read.fasl"
   :FASL-MD5 "123a5f46b8c849c98c499fb958384d60")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/epochs/package.fasl"
   :FASL-MD5 "873c58ff189a0c3351bb1667d3ac53d7")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/epochs/core.fasl"
   :FASL-MD5 "589e621ebc171195de697a7587c82a75")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/csn/registry.fasl"
   :FASL-MD5 "babcdb67c7bd156047ef4b3f16756ec7")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/csn/package.fasl"
   :FASL-MD5 "76469561020b86657930b27d8ea21698")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "5496c76a2fdb5686b999c7e17f3a11ab")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/package.fasl"
   :FASL-MD5 "a649845d4de94f78405c7e17f13e047a")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "14bc08a6fb48f5771ea39ae419622bb2")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "6428ea753c37e22281dddced363170bf")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "b1188200ca2c98d6e9fbab6441572744")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "222281c99c0dcfd76e975061be23d1e8")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "1c0bc76aa80974d65bdc2486c98e52fe")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "22dcd2bb0ab18ed6a5fbd371df3e06a4")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "8791f578e2e34f3bbeea217e04323a51")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "843e9eb39239aefc53b2d80f930e320f")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "3b2c0b9c08a23297bc5b4766c1fea403")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "84db83bf3130c78131e58f7f8e77f02f")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "728e3a1be797c56ea19a43faa64c1347")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "bdee8da55c0679f404abff87eeca9df8")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "be04e108e74d05003ff248c93b93ebdd")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/cache/write.fasl"
   :FASL-MD5 "c0aef29eb513c14b9ab8daf467731e47")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/cache/types.fasl"
   :FASL-MD5 "b8e155a941c9abfa58f49e98f2f0106a")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/cache/read.fasl"
   :FASL-MD5 "61a097ff3d5e88e406d9f1f42bc650e9")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/cache/package.fasl"
   :FASL-MD5 "3f084f1304cd1dc22b311acfc774fed3")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/cache/core.fasl"
   :FASL-MD5 "731bba905de093010f59e135c264d086")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/cache/clock.fasl"
   :FASL-MD5 "90fe0ad0268dc6b2fff27f36cc57d996")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-b/raw/isolatedtests/baseline/fasl/src/cache/build.fasl"
   :FASL-MD5 "02499356041fde70d1556384dc2c1253"))
 :EXPECTED-TESTS
 ("TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP"
  "TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2"
  "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED"
  "TEST-REQ-CCH-002-SERIES-GET-FIVE-OUTCOMES-COLD-AND-HOT"
  "TEST-REQ-CCH-004-SERIES-GET-CACHE-CORRUPTION-NATIVE-FALLBACK"
  "TEST-REQ-CMP-007-SERIES-GET-WRONG-OWNER-CLEANUP"
  "TEST-REQ-AFF-004-SERIES-GET-NIL-AND-CORRUPT-ROOT-FAULTED"
  "TEST-REQ-AFF-004-SERIES-GET-CORRUPT-ACTIVE-CONTENT-FAULTED"
  "TEST-REQ-AFF-004-SERIES-GET-SOURCE-CONTROLLER-MISMATCH-TYPED-FAULTED"
  "TEST-REQ-IDX-001-SERIES-GET-MISSING-CLOSED-ID-FAULTED"
  "TEST-REQ-CON-004-SERIES-GET-WRONG-STATE-NO-PIN-STEAL"
  "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION"
  "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
  "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-EXCLUDES-LATER-PUBLICATION"
  "TEST-REQ-WAL-005-SERIES-GET-WRITER-FOREIGN-OWNER-BEFORE-ADOPTION"
  "TEST-REQ-WAL-005-SERIES-GET-WRITER-DUPLICATE-ACTIVE-BEFORE-ADOPTION"
  "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED"
  "TEST-REQ-AFF-004-SERIES-GET-ACTIVE-OWNER-AND-ID-GUARDS"
  "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-EMPTY-AND-ID-EXTREMES"
  "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-65536-GEOMETRY-SEARCH17"
  "TEST-REQ-CON-004-SERIES-GET-BUFFER-REQUIRED-FIVE-OUTCOMES-AND-RESTART"
  "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-READER-FAULTED"
  "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-WRITER-ARCHIVE-FAULTED")
 :PASSED-TESTS
 ("TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP"
  "TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2")
 :FAILED-TEST "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED"
 :FAILURE-KIND :PRODUCT-CONDITION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "86f5e897461590ccc2370d6655acd0d0")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "2b8193aab6801de19e26fa55e7c53f87")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "8d26428a4e17ad18990b8ee7d5f5b53a")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "b537f636f38cd80ae73e2131c72532b4")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "9500cfb800603de002d6d2b24f1bf056")
  (:FILE "src/io/package.lisp" :MD5 "c9380ad46a1d7acf41655aaed20db478")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "db8497f9cff35b1ee261f1f410f46ca6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "56badeccb6c6a18693c8b41cb3cd596a")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "08b80240b37fb703ac2cfb9acde1dfa8")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
