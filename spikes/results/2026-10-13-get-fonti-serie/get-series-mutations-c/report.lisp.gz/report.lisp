(:COUNTERS
 (:BASELINE-PASSED 0 :BASELINE-FAILED 1 :DETECTED 0 :SURVIVED 0
  :COMPILATION-ERROR 0 :INFRASTRUCTURE-ERROR 0 :INVALID 0)
 :FINISHED-AT-UNIVERSAL-TIME 4000906549 :DIAGNOSTIC
 "tools/get-series-mutation.lisp COD-61: tools/get-series-mutation.lisp COD-61: baseline not passed."
 :FROZEN-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "86f5e897461590ccc2370d6655acd0d0")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "2b8193aab6801de19e26fa55e7c53f87")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "8d26428a4e17ad18990b8ee7d5f5b53a")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "b537f636f38cd80ae73e2131c72532b4")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "9500cfb800603de002d6d2b24f1bf056")
  (:FILE "src/io/package.lisp" :MD5 "c9380ad46a1d7acf41655aaed20db478")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "db8497f9cff35b1ee261f1f410f46ca6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "004b8f8cf110a26e3dc56a2a4a67c3f1")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "08b80240b37fb703ac2cfb9acde1dfa8")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54"))
 :SCHEMA-VERSION 1 :KIND :GET-SERIES-MUTATIONS :STATUS :FAILED :ARGV
 ("--check" "spikes/out/get-series-mutations-c/") :STARTED-AT-UNIVERSAL-TIME
 4000906544 :SELF-TEST
 (:STATUS :OK :CLASSIFIER-CASES 24 :ANCHOR-NEGATIVE-CASES 3 :NO-COMPILATION T
  :NO-CHILD T)
 :BASELINE
 (:CHILD-REPORT
  (:FINISHED-AT-UNIVERSAL-TIME 4000906549 :CONDITION-TYPE "INVALID-ARGUMENT"
   :DIAGNOSTIC "ArcDocDB: PRIMARY-CSN-NOT-INCREASING" :SCHEMA-VERSION 1 :KIND
   :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE :TESTS :COMPILED T
   :SUITE-COMPILED T :COMPILED-FILES
   ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
     "08b80240b37fb703ac2cfb9acde1dfa8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/tests/get-directory/series-read.fasl"
     :FASL-MD5 "bf1ff341172191f4e41bb487dad195db")
    (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
     "004b8f8cf110a26e3dc56a2a4a67c3f1" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/tests/get-directory/series-support.fasl"
     :FASL-MD5 "9e68e4501102a62a7a6d46dcf903f149")
    (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
     "63dd01c852de1399c2c82274d481d257" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/tests/get-directory/threads.fasl"
     :FASL-MD5 "528a3a4c68909178f3941d125cd47bc5")
    (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
     "d1ab36d05cc1266e4533d27c693f12f4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/tests/get-directory/read.fasl"
     :FASL-MD5 "7820f09dd0dbb65c3797a4e39bea3d8f")
    (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
     "1137938073e71d6d8d62c751fbad05d5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/tests/get-directory/construction.fasl"
     :FASL-MD5 "160c392d8ee9d8bd1114b120f4aa2b95")
    (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
     "3f868ebe4307ad4238b314c37eceed9a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/tests/get-directory/support.fasl"
     :FASL-MD5 "4dfbbdac16709aebd1ea719c0086fb96")
    (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
     "758adad069aec2f9dbe0635797314ff6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/tests/foundation/support.fasl"
     :FASL-MD5 "07aecfa8f23a630f6b64dfab04e72d5f")
    (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/wal/types.fasl"
     :FASL-MD5 "25fff5e129e759e94a51210482acfcd7")
    (:FILE "src/wal/package.lisp" :SOURCE-MD5
     "96c41b1d417135a24fc65659ea3abe11" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/wal/package.fasl"
     :FASL-MD5 "0b8d6f2a29ba496e94d59e1c53f19a98")
    (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/wal/group.fasl"
     :FASL-MD5 "0848eab7ddbeea40fe5f40de772082dd")
    (:FILE "src/wal/executor.lisp" :SOURCE-MD5
     "c0340924c9130e14d0e8efedeec078f1" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/wal/executor.fasl"
     :FASL-MD5 "221aed963e58e4d017f0c5fac6d7dd62")
    (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/wal/csn.fasl"
     :FASL-MD5 "747d59039c6074a1b1ff80b3c87d6a40")
    (:FILE "src/wal/builder.lisp" :SOURCE-MD5
     "a229f76f7036f3573a6e528dcd390a19" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/wal/builder.fasl"
     :FASL-MD5 "b7cb700b150707fb4075d3e052a1a7dc")
    (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
     "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/storage/segment-header.fasl"
     :FASL-MD5 "5a24e29fb4347c18d02e3c59323b263e")
    (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
     "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/storage/payload-write.fasl"
     :FASL-MD5 "c38dc32346bf8c3d65134bceb44ddf51")
    (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
     "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/storage/payload-record.fasl"
     :FASL-MD5 "7fafac8975d139945c4b0ab54c57500c")
    (:FILE "src/storage/package.lisp" :SOURCE-MD5
     "f86bd104f20616a76b42c02227f72844" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/storage/package.fasl"
     :FASL-MD5 "9a0ddebce2140f134a148deba77498da")
    (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
     "b53d27dcc9f4badf18b50519c50bc614" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/storage/log-header.fasl"
     :FASL-MD5 "33e946ad4bd33f6f02d957dbc79c7f39")
    (:FILE "src/storage/formats.lisp" :SOURCE-MD5
     "061147be459d8d3b08c661bd3f91d152" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/storage/formats.fasl"
     :FASL-MD5 "3f535988dc05d5d30f40a75594edd53e")
    (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
     "cb64f806b8d69eb42d865b4abfff0b27" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/storage/control-payload.fasl"
     :FASL-MD5 "007bdde5b17131a742c5e079619d2ca8")
    (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
     "1cda77a357ab2147035993b72d135a37" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/storage/compaction-scan.fasl"
     :FASL-MD5 "1f8aa9fd56bb3c4904a6cd81f372941c")
    (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
     "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/worker-types.fasl"
     :FASL-MD5 "be696bc23bf895c052b230771fdf94d6")
    (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
     "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/worker-run.fasl"
     :FASL-MD5 "78d54a7bffae5492a725330f2e731635")
    (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
     "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/worker-package.fasl"
     :FASL-MD5 "57dac6b3d91b400a8948559cdc40010f")
    (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
     "2340e0c9074f7b1bf80c74f774986bc5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/worker-boundary.fasl"
     :FASL-MD5 "4d44eb48901197e38be445cdee4ba515")
    (:FILE "src/series/types.lisp" :SOURCE-MD5
     "ab19ec8d15af91511e817858c41cebc8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/types.fasl"
     :FASL-MD5 "f54bf2499ffd3e0ca936133308bf462e")
    (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
     "ce649df47dd38888d5103c98345f7e41" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/routing-types.fasl"
     :FASL-MD5 "38b0e5f31a843773189e02282118770e")
    (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
     "e0f987d8767744050ec4d1b3ecb699ed" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/routing-select.fasl"
     :FASL-MD5 "54a5fe93c8599488eeec543c9dc80f22")
    (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
     "d6924deff152b941bd49f0bb200b4197" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/routing-build.fasl"
     :FASL-MD5 "262380a48ad4b8733921b65038d37651")
    (:FILE "src/series/retirement.lisp" :SOURCE-MD5
     "b8e04971b8ad75a1bd0c722997badfd2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/retirement.fasl"
     :FASL-MD5 "293878cf9ec1461ca0f5aa6c61d76417")
    (:FILE "src/series/query.lisp" :SOURCE-MD5
     "cb0d91405325b508e6b2ab24d178de7a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/query.fasl"
     :FASL-MD5 "9b4811d81a41fd89e108ff6bd579b094")
    (:FILE "src/series/publication.lisp" :SOURCE-MD5
     "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/publication.fasl"
     :FASL-MD5 "2203b9c8165fbd60a0583ad9950e777b")
    (:FILE "src/series/package.lisp" :SOURCE-MD5
     "59e3c59c90d8d0fc5731b87496a785aa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/package.fasl"
     :FASL-MD5 "9ca9fef49e4c61fee7ffe7ce35364066")
    (:FILE "src/series/ownership.lisp" :SOURCE-MD5
     "de1aca16a35d34d16aba12ff541c0d2b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/ownership.fasl"
     :FASL-MD5 "ec24d43423f3ce0973afc340f24afb23")
    (:FILE "src/series/io-events.lisp" :SOURCE-MD5
     "b6026a8b7bb64b45c37a65effda70d8e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/io-events.fasl"
     :FASL-MD5 "6e85fa2a9eb290ce6718dc2a1993350b")
    (:FILE "src/series/events.lisp" :SOURCE-MD5
     "32b2156739a6f2ca996abb91df0a2603" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/series/events.fasl"
     :FASL-MD5 "3ded387f1787e998c2ce67c0a64eb52e")
    (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
     "fcacd15460db25ea9cc4036065f9f096" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/scan.fasl"
     :FASL-MD5 "bf11c727f057d798bb1d905702bffcc5")
    (:FILE "src/recovery/package.lisp" :SOURCE-MD5
     "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/package.fasl"
     :FASL-MD5 "83d5409487c9e03a1cf4439ad0b356b8")
    (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
     "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/manifest-types.fasl"
     :FASL-MD5 "997d22e197ee52173a080298475d5fcc")
    (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
     "ebd7a54adea2213294a887e6d4db0927" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/manifest-query.fasl"
     :FASL-MD5 "176ea4f57edbe978bce7a6b7a6695d3b")
    (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
     "37ace42844c11b52446ee1fc500b8e0b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/manifest-package.fasl"
     :FASL-MD5 "163a792a8cd51905d753bd6b8ef32d50")
    (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
     "e0d2498db1011e857b7b0daa1934f187" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/manifest-fold.fasl"
     :FASL-MD5 "c199bbc0be3e603180969ca3e21c4d73")
    (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
     "67975249aaabd751757cdfb9222cc3c4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/manifest-decode.fasl"
     :FASL-MD5 "4835d9800606947126e2ae7595d65807")
    (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
     "bf65b1731eab6e0572461ef5cc60fc40" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/manifest-build.fasl"
     :FASL-MD5 "1d213ca499516c734d30f91eb2d83f63")
    (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
     "78c136d5838dcfe3019d9069643a8d8f" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/inventory-types.fasl"
     :FASL-MD5 "01e6dce5ab97fce3d4aa226fb4c0db3b")
    (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
     "fcea263de1938767772e5b11411ecd5e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/inventory-query.fasl"
     :FASL-MD5 "82ff50ffb108072ffc315aed40246c38")
    (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
     "9bd6820c4feba3e552aab1a4edd87861" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/inventory-build.fasl"
     :FASL-MD5 "ba64401d9763225863343f6a8a17dfc6")
    (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
     "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/decisions-types.fasl"
     :FASL-MD5 "4148f75c0dcde348f2ac2bd626f8e70b")
    (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
     "b33e57a643f2fca810846f6226366253" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/decisions-sort.fasl"
     :FASL-MD5 "748a990c974f75573a61d85e6d0a084e")
    (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
     "852149de4c289b8e067602780378d87a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/decisions-radix.fasl"
     :FASL-MD5 "416c624ba3e993a9c5875363e9dfa355")
    (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
     "f782d1137b8ce342b91c9999cfb7accc" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/decisions-query.fasl"
     :FASL-MD5 "179f1b84443d96c191dc9151d2176926")
    (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
     "cbdc30f93109c474e1fc25066c9b9b13" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/decisions-package.fasl"
     :FASL-MD5 "97b6a92a42181e936c9c32a81ee6048a")
    (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
     "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/recovery/decisions-build.fasl"
     :FASL-MD5 "99dc53afb556a8f4ae23224a210db239")
    (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/read/types.fasl"
     :FASL-MD5 "5d78987ca6658a121f687523922a55db")
    (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/read/task.fasl"
     :FASL-MD5 "d47bd777249f458b141607e87f6aa4be")
    (:FILE "src/read/package.lisp" :SOURCE-MD5
     "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/read/package.fasl"
     :FASL-MD5 "1a2bf7ea7e50f89c3e7f07dce5e15a59")
    (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/read/core.fasl"
     :FASL-MD5 "f2941e81f84b50e3303498ecbaff84e0")
    (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/package.fasl"
     :FASL-MD5 "4603beb188f8ad48fe746bbc612f4e0d")
    (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/mvcc/types.fasl"
     :FASL-MD5 "303c747c24f5650fc0143bc6a1254343")
    (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
     "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-types.fasl"
     :FASL-MD5 "8964848f589bfc10110d20c0bcb8dca5")
    (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
     "2d5a795bcefd605c75da91c725ae83a2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-register.fasl"
     :FASL-MD5 "34aaaf93115f0767f48a1296b2263b93")
    (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
     "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-read.fasl"
     :FASL-MD5 "4e39a18a77202b7f4bbb180df8c511ab")
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
     "ff98aea5cb9a7ae2671f6a887a003725" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-lifecycle.fasl"
     :FASL-MD5 "435d7d8b2b1ba1c0c2927eb9e78ded09")
    (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
     "0e9365e674d1584b111f915ce1f58634" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-csn.fasl"
     :FASL-MD5 "2bc78a17375747b408efb9c9bb7153c5")
    (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
     "8bb066aab61a18eff175b9edb11e42a2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-core.fasl"
     :FASL-MD5 "4d23e095b075329218e079634236c426")
    (:FILE "src/mvcc/package.lisp" :SOURCE-MD5
     "f188d1dbd5d0adb49f53acf09157aef9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/mvcc/package.fasl"
     :FASL-MD5 "f74086e465c74328c54eb228bb43e4a7")
    (:FILE "src/io/types.lisp" :SOURCE-MD5 "db8497f9cff35b1ee261f1f410f46ca6"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/io/types.fasl"
     :FASL-MD5 "ea35a682df5b0b986fd1443c75ec9f2d")
    (:FILE "src/io/transfer.lisp" :SOURCE-MD5
     "a5e7108e80664eb3b562fbd7e680801f" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/io/transfer.fasl"
     :FASL-MD5 "eaab9aed8cacc688b20c8bfd27ed00fe")
    (:FILE "src/io/package.lisp" :SOURCE-MD5 "c9380ad46a1d7acf41655aaed20db478"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/io/package.fasl"
     :FASL-MD5 "3132490769aa30baa9c9d8d7475379b3")
    (:FILE "src/io/native.lisp" :SOURCE-MD5 "9500cfb800603de002d6d2b24f1bf056"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/io/native.fasl"
     :FASL-MD5 "e55d8ff7d5268203455bafec51c81cc4")
    (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5
     "11c7103efbe733bbf0a13927f23c3d34" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/io/lifecycle.fasl"
     :FASL-MD5 "691755c1320da84740732f885f1ae8fc")
    (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/io/flush.fasl"
     :FASL-MD5 "02ba0317d06d5c157ac54bb1437006e9")
    (:FILE "src/index/write.lisp" :SOURCE-MD5
     "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/write.fasl"
     :FASL-MD5 "029c999d2a2fe929d1f358a901ae59b6")
    (:FILE "src/index/validation.lisp" :SOURCE-MD5
     "3384cadf737c7d80c004222022a281f6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/validation.fasl"
     :FASL-MD5 "78c15ff28fbc395b2aa237bced12cbb4")
    (:FILE "src/index/types.lisp" :SOURCE-MD5
     "5157fd03ee806ee998ad8f0002d56268" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/types.fasl"
     :FASL-MD5 "8bd83f6802f1b9432c57b5e6d3a5cee2")
    (:FILE "src/index/relocate.lisp" :SOURCE-MD5
     "475dd7d5809a836f01544b447cc8df27" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/relocate.fasl"
     :FASL-MD5 "a1d7a74228733cd361b7918f5e62a0c2")
    (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
     "a450cac8071513365267e7024cbe94b0" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/rebuild.fasl"
     :FASL-MD5 "ae7209cebfe988c190b96b2cd8ccbdf6")
    (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
     "1188e7a64a7a5d9482c1233cb9acb452" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/rebuild-scan.fasl"
     :FASL-MD5 "441a451732ce04f2aaffcdffbef7abb5")
    (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
     "8befbbd00ed5c31c1487a11887eba495" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/rebuild-copy.fasl"
     :FASL-MD5 "86f67b635c8543884a6220f169acd7ee")
    (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
     "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/rebuild-budget.fasl"
     :FASL-MD5 "4ef616e17dbf637e21729729d72a23ad")
    (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/read.fasl"
     :FASL-MD5 "d939a1ae9ded3dbfe326a33b7366e06a")
    (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
     "e8e31e599356e592af29c0cc4604872b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/primary-write.fasl"
     :FASL-MD5 "f2b410c2bcf99505b7537a66d3eacbcb")
    (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
     "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/primary-types.fasl"
     :FASL-MD5 "d5bcfab2986d5d34667692f8d8b61266")
    (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
     "5155959766645d3172ae5e73c58cc071" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/primary-relocate.fasl"
     :FASL-MD5 "3cf5a4a397aea72f2c28e8be488cab73")
    (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
     "3f317a0d3c5ee86a73651aad36135cc3" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/primary-read.fasl"
     :FASL-MD5 "199804ea6c93cc630fd51c256d4df7dc")
    (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
     "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/primary-probe.fasl"
     :FASL-MD5 "ba0b632065c3685a51e08c885b063754")
    (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
     "d65cfce399b04f905bf969929962e59a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/primary-package.fasl"
     :FASL-MD5 "ddf8b219427b234d5db0a243123f47d7")
    (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
     "1dd67c527257e43f17e006644ecdbd00" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/primary-directory.fasl"
     :FASL-MD5 "20f9b84d3186a78508aa70bcdf700f2a")
    (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
     "fa52433eae199ceeb874bf2bc47afca7" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/primary-core.fasl"
     :FASL-MD5 "a9db47528e6f02913a449803937b897b")
    (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
     "ff2cfbb865290d7a1510fdf6877c7229" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/primary-build.fasl"
     :FASL-MD5 "c56dad3aa5e831728d3e2fefd004952c")
    (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
     "a319691e3e28b7ea7b927de490cf69ba" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/primary-arena.fasl"
     :FASL-MD5 "8c0ceedfa76930184dc68a136f7a256c")
    (:FILE "src/index/package.lisp" :SOURCE-MD5
     "598a9b65e73151c924b2cdcaf6d96705" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/package.fasl"
     :FASL-MD5 "027780e3b4e6b235e9bed245eb53b7f3")
    (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
     "45ce41749bc6fa638539815d3f802b96" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/hash-seed.fasl"
     :FASL-MD5 "9fc06a5c6aba941265a3e0157297fb92")
    (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
     "43d2209225707352daec6186ef95a805" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/hash-digests.fasl"
     :FASL-MD5 "e823d367177aa0e8048efb91cfd337f9")
    (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/index/core.fasl"
     :FASL-MD5 "d8b551f02c824a60f52028c37827ad39")
    (:FILE "src/hash/package.lisp" :SOURCE-MD5
     "2d9060e41bc5252067d35e59ac70ee06" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/hash/package.fasl"
     :FASL-MD5 "150e59e0135f700ddd7d59252694c138")
    (:FILE "src/hash/hash64.lisp" :SOURCE-MD5
     "886b7c08b9929283e8968831cbe5c039" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/hash/hash64.fasl"
     :FASL-MD5 "e6c10d5747a660943acf838fe62c8c14")
    (:FILE "src/hash/blocks.lisp" :SOURCE-MD5
     "bef497b9a267c7306d4100000491c814" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/hash/blocks.fasl"
     :FASL-MD5 "918b030f8cf144fe3e646d763ff21360")
    (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
     "b5c51802e607e3dd22de68204baf64e9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/hash/arithmetic.fasl"
     :FASL-MD5 "2937951de2cf5327f7db53254b374701")
    (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get/types.fasl"
     :FASL-MD5 "9cd2f2a0d4f46cf794eaea14f3fffb38")
    (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get/target.fasl"
     :FASL-MD5 "34dbac6f8395d2435b3153f8a5a44054")
    (:FILE "src/get/segment.lisp" :SOURCE-MD5
     "811869eb6a197d3c4e26af4322e52652" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get/segment.fasl"
     :FASL-MD5 "838d8cb1c556ca982bf8933d586ba4c0")
    (:FILE "src/get/package.lisp" :SOURCE-MD5
     "c72633d15c3488699072eb610ebde7c8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get/package.fasl"
     :FASL-MD5 "dd217fa153b76e8a6e1abb32236c66de")
    (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get/lookup.fasl"
     :FASL-MD5 "82801f2226a1e979b7268d62cf22e75e")
    (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
     "e70bfeddd694336bbd088e65f8761834" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get/lifecycle.fasl"
     :FASL-MD5 "b738cbb917e902cf27a282552f756b6c")
    (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get/build.fasl"
     :FASL-MD5 "4f4753c4826af729e5fa96411b3c1424")
    (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
     "9df13bcc6908e9fa601d173a671e1ccf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-resolver/types.fasl"
     :FASL-MD5 "ef4057869e2f0072205cda87b94a2990")
    (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
     "2d869293ba47444c4721713d955c6254" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-resolver/sort.fasl"
     :FASL-MD5 "647333c6fbbd3de75679e0855f860700")
    (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
     "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-resolver/scan.fasl"
     :FASL-MD5 "a894c2f352f1f6e787cc901a375e0e75")
    (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
     "ca9002b81efd0aed9761cd1f78514762" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-resolver/rows.fasl"
     :FASL-MD5 "5cce7a9b9c57f240de793674fe33c8e1")
    (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
     "1339edff0223dbf122f11ff0adbba61c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-resolver/read.fasl"
     :FASL-MD5 "04a6ccbd87c3283ee2340957d9a648f2")
    (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
     "b537f636f38cd80ae73e2131c72532b4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-resolver/package.fasl"
     :FASL-MD5 "7b6fb2cf0452c8b8bb72cf4997466046")
    (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
     "bbfb2082103e6712419e180ab972245c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-resolver/build.fasl"
     :FASL-MD5 "c1dacc21689181e6dcb105faf73f3a0f")
    (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
     "bd7182e9871fe82530d0c828e473ccde" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-resolver/active-types.fasl"
     :FASL-MD5 "0e6d42d0cdea73e75c43194aa1c91bd5")
    (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
     "d6aaec49504a96f37c8ff1bc182c977b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-resolver/active-scan.fasl"
     :FASL-MD5 "159cb8aba047af2485117dfd725887b8")
    (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
     "521737861e057d663964b0c030552587" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-resolver/active-read.fasl"
     :FASL-MD5 "7945bcf6bd11da6335d9dd03cf16d5bd")
    (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
     "f13d422adb6aa9e8489352884137f25a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-resolver/active-preflight.fasl"
     :FASL-MD5 "584d16fe6ef39c6903bea7feeafecdb0")
    (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
     "6d95f29b331d335175843f47ae44a6ea" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-resolver/active-directory.fasl"
     :FASL-MD5 "9107a59a38650244274889e32b8ef4c3")
    (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
     "8d26428a4e17ad18990b8ee7d5f5b53a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-resolver/active-build.fasl"
     :FASL-MD5 "4bc299fe3765174c7c29946082fcfb14")
    (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
     "17c957d6934a31f4ed64313e756de2d2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-directory/types.fasl"
     :FASL-MD5 "9964a5db0a00ff2ff558dd0db4a4a598")
    (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
     "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-directory/sources-types.fasl"
     :FASL-MD5 "e8c412f4bb88e40b55afa1ab766f7611")
    (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
     "2b8193aab6801de19e26fa55e7c53f87" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-directory/sources-read.fasl"
     :FASL-MD5 "ed7c9ac4a91770a365b98f5bd6e92085")
    (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
     "74a694385f1aaf03ec87721545494119" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl"
     :FASL-MD5 "779cef7737b77138cd771d5c7a79a9b0")
    (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
     "894f6e238fe4047f2bf607fceae86846" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-directory/package.fasl"
     :FASL-MD5 "3e0b16e4640dbed507ec97becf39ce8e")
    (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
     "cde24b2bf5c5637d5501b95bed47df31" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/get-directory/build.fasl"
     :FASL-MD5 "ebcdb66174361f9c39f575f27254d05d")
    (:FILE "src/foundation/record.lisp" :SOURCE-MD5
     "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/foundation/record.fasl"
     :FASL-MD5 "f53a4bfc0ef53773b04bbfd36f37ffdd")
    (:FILE "src/foundation/package.lisp" :SOURCE-MD5
     "5ee593a112958d94163dab17c5aa4ba2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/foundation/package.fasl"
     :FASL-MD5 "7d09ab53b4734ab2e44a057db96d6d6d")
    (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
     "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/foundation/crc32c.fasl"
     :FASL-MD5 "a9dfff9d67fdf9335ee57b2e8105943d")
    (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
     "942b596396c19815290a57830af2121b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/foundation/conditions.fasl"
     :FASL-MD5 "cb8da7072f0ccb72075e3fa9c1bfd4f3")
    (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
     "a06115175f450776762761dce25acdb8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/foundation/binary.fasl"
     :FASL-MD5 "f83e7604879ab30c8e668d6f49997fa1")
    (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
     "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/foundation/batch.fasl"
     :FASL-MD5 "152b80fdef5afb41e5e13056c0554557")
    (:FILE "src/execution/writer.lisp" :SOURCE-MD5
     "73019644090e2971f2b54dc36e4491f5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/execution/writer.fasl"
     :FASL-MD5 "eb113ef1b466c6a5ed1f84b354258407")
    (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
     "0679ee07c46f69db330706303c70d8d2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/execution/worker-types.fasl"
     :FASL-MD5 "152ccc6b20032eb37b712de5c274a9be")
    (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
     "aa34ca6bc07535e35fea723878d99f66" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/execution/worker-run.fasl"
     :FASL-MD5 "7a6c2dd109b689d06f4400b06bc8230e")
    (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
     "babd0a78b4185af24ae1fef870c0fabb" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/execution/worker-claim.fasl"
     :FASL-MD5 "0daf3e686a1e4f1dceeb40d1bc588eff")
    (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
     "c24065d6c8d80d1be53994a0041743df" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/execution/worker-boundary.fasl"
     :FASL-MD5 "10458c8cd900f6af17b0c419a100d4e1")
    (:FILE "src/execution/ready.lisp" :SOURCE-MD5
     "2c1892002f0599bb8273093031017520" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/execution/ready.fasl"
     :FASL-MD5 "43d283f2a7c659e892194ad27fd60877")
    (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
     "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/execution/ready-types.fasl"
     :FASL-MD5 "28464f80abbfb96e46b04191a8f96f78")
    (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
     "38d26f8c749dd946dfc4b9c57103a892" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/execution/ready-recycle.fasl"
     :FASL-MD5 "40d990a6f69f68180557e6e50fe2f6f0")
    (:FILE "src/execution/queue.lisp" :SOURCE-MD5
     "8202843bddb817da4279ac959ae3f3c4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/execution/queue.fasl"
     :FASL-MD5 "de8d6b7103d28c9d0b8e9e1608a0ad75")
    (:FILE "src/execution/package.lisp" :SOURCE-MD5
     "cb5710d6c111cadb7121a50998a747fa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/execution/package.fasl"
     :FASL-MD5 "40cbfbbe971495df10666ddd11e451b0")
    (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
     "6b85eebe69366e78ed5fc5cc20735f00" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/execution/handoff.fasl"
     :FASL-MD5 "b230a128163eafa9eb03d918cafbfe7f")
    (:FILE "src/epochs/types.lisp" :SOURCE-MD5
     "82253491f995f5bc153fb5ebf30d564c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/epochs/types.fasl"
     :FASL-MD5 "114d3b7d8bf8adaae437fa4f37e77eab")
    (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
     "653b974f310c09f6e2224a84acc43bbf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/epochs/retire.fasl"
     :FASL-MD5 "759724a8b0d903c4b6accef8624e5d24")
    (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
     "036dd02adf87d33c3ae2f40735c733fa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/epochs/reclaim.fasl"
     :FASL-MD5 "e4ca67992e91e366babd9a373fc95aac")
    (:FILE "src/epochs/read.lisp" :SOURCE-MD5
     "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/epochs/read.fasl"
     :FASL-MD5 "98874005c1cde429dd8412d188d8b65f")
    (:FILE "src/epochs/package.lisp" :SOURCE-MD5
     "875201dfab0a84efd40fe9828cc293c8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/epochs/package.fasl"
     :FASL-MD5 "c03eb564c9e177422c304231a9e2c4bf")
    (:FILE "src/epochs/core.lisp" :SOURCE-MD5
     "765d14c88cd288093a77a57930cd6999" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/epochs/core.fasl"
     :FASL-MD5 "1c0ec7cd5b15bb9a530accb09b47aa60")
    (:FILE "src/csn/registry.lisp" :SOURCE-MD5
     "a1cdb5661fc54beba5bf00e4765f3235" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/csn/registry.fasl"
     :FASL-MD5 "6ca6f23e888bc1cda88b04f867c3db60")
    (:FILE "src/csn/package.lisp" :SOURCE-MD5
     "1130012fc5613a5648d22ed8628be0e8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/csn/package.fasl"
     :FASL-MD5 "ae349e4b514b1345232200fbdbf2a790")
    (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/utf8.fasl"
     :FASL-MD5 "fe47a573d184379aea44bc66c5262594")
    (:FILE "src/codec/package.lisp" :SOURCE-MD5
     "d885bd2a9860eb60aec1a775e5031d5e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/package.fasl"
     :FASL-MD5 "6991d55a2adaa07aa6b3e15d9ee1a581")
    (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
     "69e77bcd15b5413a815a65c5081229db" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/cbor-write.fasl"
     :FASL-MD5 "7db75dc45cbfb0b116335559805233b8")
    (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
     "b13e92b5f24a42fe283c17b649722b6a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/cbor-string-write.fasl"
     :FASL-MD5 "bfc21e7cf944077cb4c740da6a641a2a")
    (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
     "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/cbor-space.fasl"
     :FASL-MD5 "77c6b92753dc42647590b8b7ac86c1e8")
    (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
     "200373402e6e082dd8c7afde305302bb" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/cbor-simple-write.fasl"
     :FASL-MD5 "78a80010c8104c84cb9369b7648ff636")
    (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
     "0c33aedcdb352e78a3c694cf796e6692" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan.fasl"
     :FASL-MD5 "8c802de43cb5970923cb566136ac8129")
    (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
     "cf1999ddb10f879aeefbeea853742d57" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-stack.fasl"
     :FASL-MD5 "7aa20d9014c0e5b5b9020d161fc966eb")
    (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
     "987e8ed576a21eb644ac1ef2e06edbda" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-minimal.fasl"
     :FASL-MD5 "e7f57b5c59c49959db151f53e3d74134")
    (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
     "706c0baa4158bf272c4b0df17c1439d2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-items.fasl"
     :FASL-MD5 "8275cd87c433d4298cca66865d49a8b2")
    (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
     "f6488e987889432b375254021825dbe5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-input.fasl"
     :FASL-MD5 "6dd46c51fc8efe92a3eff8a6e2e0c585")
    (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
     "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/cbor-package.fasl"
     :FASL-MD5 "e92576da5a53802c5f1f8b420dfdd211")
    (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
     "ecd8fe950344059c629927b38fb6e4aa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/cbor-minimal.fasl"
     :FASL-MD5 "df8be1a54987e10ca48619399d544144")
    (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
     "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/cbor-header.fasl"
     :FASL-MD5 "e1a07dfe0fcf0d0e19ffc413ab2c80ae")
    (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
     "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/codec/cbor-float-minimal.fasl"
     :FASL-MD5 "17cbea48d782b5186fb22f98fee6cb19")
    (:FILE "src/cache/write.lisp" :SOURCE-MD5
     "fc09021f74fb50aac57589614dae04d7" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/cache/write.fasl"
     :FASL-MD5 "5c8a7ea8dca2840b1ac91edc3a036f2d")
    (:FILE "src/cache/types.lisp" :SOURCE-MD5
     "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/cache/types.fasl"
     :FASL-MD5 "da1bc4ab73b840059e8f9a90ec517848")
    (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/cache/read.fasl"
     :FASL-MD5 "853490a6e4d3a948495e209bea3486a6")
    (:FILE "src/cache/package.lisp" :SOURCE-MD5
     "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/cache/package.fasl"
     :FASL-MD5 "da057c2fce640b6d3b2e36e8b6db518d")
    (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/cache/core.fasl"
     :FASL-MD5 "b2fc70a9387b26c65c43270e018174de")
    (:FILE "src/cache/clock.lisp" :SOURCE-MD5
     "3546cf7f5c5ed138068548c20064f499" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/cache/clock.fasl"
     :FASL-MD5 "46ae4fc4e8e4db6646664fc60076f9e3")
    (:FILE "src/cache/build.lisp" :SOURCE-MD5
     "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/fasl/src/cache/build.fasl"
     :FASL-MD5 "95bdff815e4a9731fd372f0db656c503"))
   :EXPECTED-TESTS
   ("TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP"
    "TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2"
    "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED"
    "TEST-REQ-CCH-002-SERIES-GET-FIVE-OUTCOMES-COLD-AND-HOT"
    "TEST-REQ-CCH-004-SERIES-GET-CACHE-CORRUPTION-NATIVE-FALLBACK"
    "TEST-REQ-CMP-007-SERIES-GET-WRONG-OWNER-CLEANUP"
    "TEST-REQ-AFF-004-SERIES-GET-NIL-AND-CORRUPT-ROOT-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-CORRUPT-ACTIVE-CONTENT-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-SOURCE-CONTROLLER-MISMATCH-TYPED-FAULTED"
    "TEST-REQ-IDX-001-SERIES-GET-MISSING-CLOSED-ID-FAULTED"
    "TEST-REQ-CON-004-SERIES-GET-WRONG-STATE-NO-PIN-STEAL"
    "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION"
    "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
    "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-EXCLUDES-LATER-PUBLICATION"
    "TEST-REQ-WAL-005-SERIES-GET-WRITER-FOREIGN-OWNER-BEFORE-ADOPTION"
    "TEST-REQ-WAL-005-SERIES-GET-WRITER-DUPLICATE-ACTIVE-BEFORE-ADOPTION"
    "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-ACTIVE-OWNER-AND-ID-GUARDS"
    "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-EMPTY-AND-ID-EXTREMES"
    "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-65536-GEOMETRY-SEARCH17"
    "TEST-REQ-CON-004-SERIES-GET-BUFFER-REQUIRED-FIVE-OUTCOMES-AND-RESTART"
    "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-READER-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-WRITER-ARCHIVE-FAULTED")
   :PASSED-TESTS
   ("TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP"
    "TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2"
    "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED"
    "TEST-REQ-CCH-002-SERIES-GET-FIVE-OUTCOMES-COLD-AND-HOT"
    "TEST-REQ-CCH-004-SERIES-GET-CACHE-CORRUPTION-NATIVE-FALLBACK"
    "TEST-REQ-CMP-007-SERIES-GET-WRONG-OWNER-CLEANUP"
    "TEST-REQ-AFF-004-SERIES-GET-NIL-AND-CORRUPT-ROOT-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-CORRUPT-ACTIVE-CONTENT-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-SOURCE-CONTROLLER-MISMATCH-TYPED-FAULTED")
   :FAILED-TEST "TEST-REQ-IDX-001-SERIES-GET-MISSING-CLOSED-ID-FAULTED"
   :FAILURE-KIND :PRODUCT-CONDITION :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :MD5 "86f5e897461590ccc2370d6655acd0d0")
    (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
    (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
    (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
    (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
    (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
    (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
    (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
    (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
     "bc7a7b176e8cdd361b7c4306a1a4de4b")
    (:FILE "src/codec/cbor-header.lisp" :MD5
     "6e8c6a49314c2f460aa6f8a1759200b6")
    (:FILE "src/codec/cbor-minimal.lisp" :MD5
     "ecd8fe950344059c629927b38fb6e4aa")
    (:FILE "src/codec/cbor-package.lisp" :MD5
     "c3f19ffb4aacfdfe502c5e8b12a234f2")
    (:FILE "src/codec/cbor-scan-input.lisp" :MD5
     "f6488e987889432b375254021825dbe5")
    (:FILE "src/codec/cbor-scan-items.lisp" :MD5
     "706c0baa4158bf272c4b0df17c1439d2")
    (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
     "987e8ed576a21eb644ac1ef2e06edbda")
    (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
     "cf1999ddb10f879aeefbeea853742d57")
    (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
    (:FILE "src/codec/cbor-simple-write.lisp" :MD5
     "200373402e6e082dd8c7afde305302bb")
    (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
    (:FILE "src/codec/cbor-string-write.lisp" :MD5
     "b13e92b5f24a42fe283c17b649722b6a")
    (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
    (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
    (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
    (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
    (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
    (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
    (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
    (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
    (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
    (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
    (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
    (:FILE "src/execution/handoff.lisp" :MD5
     "6b85eebe69366e78ed5fc5cc20735f00")
    (:FILE "src/execution/package.lisp" :MD5
     "cb5710d6c111cadb7121a50998a747fa")
    (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
    (:FILE "src/execution/ready-recycle.lisp" :MD5
     "38d26f8c749dd946dfc4b9c57103a892")
    (:FILE "src/execution/ready-types.lisp" :MD5
     "a64d98c9ff429d6103d6e10ee1fd7980")
    (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
    (:FILE "src/execution/worker-boundary.lisp" :MD5
     "c24065d6c8d80d1be53994a0041743df")
    (:FILE "src/execution/worker-claim.lisp" :MD5
     "babd0a78b4185af24ae1fef870c0fabb")
    (:FILE "src/execution/worker-run.lisp" :MD5
     "aa34ca6bc07535e35fea723878d99f66")
    (:FILE "src/execution/worker-types.lisp" :MD5
     "0679ee07c46f69db330706303c70d8d2")
    (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
    (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
    (:FILE "src/foundation/binary.lisp" :MD5
     "a06115175f450776762761dce25acdb8")
    (:FILE "src/foundation/conditions.lisp" :MD5
     "942b596396c19815290a57830af2121b")
    (:FILE "src/foundation/crc32c.lisp" :MD5
     "4db58e2f48bf77d751f1b83bb9f84b5c")
    (:FILE "src/foundation/package.lisp" :MD5
     "5ee593a112958d94163dab17c5aa4ba2")
    (:FILE "src/foundation/record.lisp" :MD5
     "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
    (:FILE "src/get-directory/build.lisp" :MD5
     "cde24b2bf5c5637d5501b95bed47df31")
    (:FILE "src/get-directory/package.lisp" :MD5
     "894f6e238fe4047f2bf607fceae86846")
    (:FILE "src/get-directory/read.lisp" :MD5
     "74a694385f1aaf03ec87721545494119")
    (:FILE "src/get-directory/sources-read.lisp" :MD5
     "2b8193aab6801de19e26fa55e7c53f87")
    (:FILE "src/get-directory/sources-types.lisp" :MD5
     "b846a6348ff7d4b5f7b380b5b3ff8c17")
    (:FILE "src/get-directory/types.lisp" :MD5
     "17c957d6934a31f4ed64313e756de2d2")
    (:FILE "src/get-resolver/active-build.lisp" :MD5
     "8d26428a4e17ad18990b8ee7d5f5b53a")
    (:FILE "src/get-resolver/active-directory.lisp" :MD5
     "6d95f29b331d335175843f47ae44a6ea")
    (:FILE "src/get-resolver/active-preflight.lisp" :MD5
     "f13d422adb6aa9e8489352884137f25a")
    (:FILE "src/get-resolver/active-read.lisp" :MD5
     "521737861e057d663964b0c030552587")
    (:FILE "src/get-resolver/active-scan.lisp" :MD5
     "d6aaec49504a96f37c8ff1bc182c977b")
    (:FILE "src/get-resolver/active-types.lisp" :MD5
     "bd7182e9871fe82530d0c828e473ccde")
    (:FILE "src/get-resolver/build.lisp" :MD5
     "bbfb2082103e6712419e180ab972245c")
    (:FILE "src/get-resolver/package.lisp" :MD5
     "b537f636f38cd80ae73e2131c72532b4")
    (:FILE "src/get-resolver/read.lisp" :MD5
     "1339edff0223dbf122f11ff0adbba61c")
    (:FILE "src/get-resolver/rows.lisp" :MD5
     "ca9002b81efd0aed9761cd1f78514762")
    (:FILE "src/get-resolver/scan.lisp" :MD5
     "536e9dc4ed51072b8a6d1528d3ec18bf")
    (:FILE "src/get-resolver/sort.lisp" :MD5
     "2d869293ba47444c4721713d955c6254")
    (:FILE "src/get-resolver/types.lisp" :MD5
     "9df13bcc6908e9fa601d173a671e1ccf")
    (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
    (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
    (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
    (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
    (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
    (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
    (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
    (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
    (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
    (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
    (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
    (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
    (:FILE "src/index/hash-digests.lisp" :MD5
     "43d2209225707352daec6186ef95a805")
    (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
    (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
    (:FILE "src/index/primary-arena.lisp" :MD5
     "a319691e3e28b7ea7b927de490cf69ba")
    (:FILE "src/index/primary-build.lisp" :MD5
     "ff2cfbb865290d7a1510fdf6877c7229")
    (:FILE "src/index/primary-core.lisp" :MD5
     "fa52433eae199ceeb874bf2bc47afca7")
    (:FILE "src/index/primary-directory.lisp" :MD5
     "1dd67c527257e43f17e006644ecdbd00")
    (:FILE "src/index/primary-package.lisp" :MD5
     "d65cfce399b04f905bf969929962e59a")
    (:FILE "src/index/primary-probe.lisp" :MD5
     "699ce3f1615296fc27fcde3e0d63a4bc")
    (:FILE "src/index/primary-read.lisp" :MD5
     "3f317a0d3c5ee86a73651aad36135cc3")
    (:FILE "src/index/primary-relocate.lisp" :MD5
     "5155959766645d3172ae5e73c58cc071")
    (:FILE "src/index/primary-types.lisp" :MD5
     "a59eab6425a60fa2656f86bf87d5c9ac")
    (:FILE "src/index/primary-write.lisp" :MD5
     "e8e31e599356e592af29c0cc4604872b")
    (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
    (:FILE "src/index/rebuild-budget.lisp" :MD5
     "0417dd41cb3ec1d62dfd913c19f810ad")
    (:FILE "src/index/rebuild-copy.lisp" :MD5
     "8befbbd00ed5c31c1487a11887eba495")
    (:FILE "src/index/rebuild-scan.lisp" :MD5
     "1188e7a64a7a5d9482c1233cb9acb452")
    (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
    (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
    (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
    (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
    (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
    (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
    (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
    (:FILE "src/io/native.lisp" :MD5 "9500cfb800603de002d6d2b24f1bf056")
    (:FILE "src/io/package.lisp" :MD5 "c9380ad46a1d7acf41655aaed20db478")
    (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
    (:FILE "src/io/types.lisp" :MD5 "db8497f9cff35b1ee261f1f410f46ca6")
    (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
    (:FILE "src/mvcc/snapshots-core.lisp" :MD5
     "8bb066aab61a18eff175b9edb11e42a2")
    (:FILE "src/mvcc/snapshots-csn.lisp" :MD5
     "0e9365e674d1584b111f915ce1f58634")
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
     "ff98aea5cb9a7ae2671f6a887a003725")
    (:FILE "src/mvcc/snapshots-read.lisp" :MD5
     "ae3ad96269b5e711a9dbb455f3c0ce48")
    (:FILE "src/mvcc/snapshots-register.lisp" :MD5
     "2d5a795bcefd605c75da91c725ae83a2")
    (:FILE "src/mvcc/snapshots-types.lisp" :MD5
     "475517bd7ba04a1c37a82efeb8ff73d9")
    (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
    (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
    (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
    (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
    (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
    (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
    (:FILE "src/recovery/decisions-build.lisp" :MD5
     "1a51ef4a488bb9fde2ff7d47bae01379")
    (:FILE "src/recovery/decisions-package.lisp" :MD5
     "cbdc30f93109c474e1fc25066c9b9b13")
    (:FILE "src/recovery/decisions-query.lisp" :MD5
     "f782d1137b8ce342b91c9999cfb7accc")
    (:FILE "src/recovery/decisions-radix.lisp" :MD5
     "852149de4c289b8e067602780378d87a")
    (:FILE "src/recovery/decisions-sort.lisp" :MD5
     "b33e57a643f2fca810846f6226366253")
    (:FILE "src/recovery/decisions-types.lisp" :MD5
     "f4433fd19ebc7239dbc2628c39f3ecdb")
    (:FILE "src/recovery/inventory-build.lisp" :MD5
     "9bd6820c4feba3e552aab1a4edd87861")
    (:FILE "src/recovery/inventory-query.lisp" :MD5
     "fcea263de1938767772e5b11411ecd5e")
    (:FILE "src/recovery/inventory-types.lisp" :MD5
     "78c136d5838dcfe3019d9069643a8d8f")
    (:FILE "src/recovery/manifest-build.lisp" :MD5
     "bf65b1731eab6e0572461ef5cc60fc40")
    (:FILE "src/recovery/manifest-decode.lisp" :MD5
     "67975249aaabd751757cdfb9222cc3c4")
    (:FILE "src/recovery/manifest-fold.lisp" :MD5
     "e0d2498db1011e857b7b0daa1934f187")
    (:FILE "src/recovery/manifest-package.lisp" :MD5
     "37ace42844c11b52446ee1fc500b8e0b")
    (:FILE "src/recovery/manifest-query.lisp" :MD5
     "ebd7a54adea2213294a887e6d4db0927")
    (:FILE "src/recovery/manifest-types.lisp" :MD5
     "7b1d4054415faca7e5fca59ad83b4d4a")
    (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
    (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
    (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
    (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
    (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
    (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
    (:FILE "src/series/publication.lisp" :MD5
     "056d2c6a67c9d9f2bf9fe2d2c348d53c")
    (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
    (:FILE "src/series/retirement.lisp" :MD5
     "b8e04971b8ad75a1bd0c722997badfd2")
    (:FILE "src/series/routing-build.lisp" :MD5
     "d6924deff152b941bd49f0bb200b4197")
    (:FILE "src/series/routing-select.lisp" :MD5
     "e0f987d8767744050ec4d1b3ecb699ed")
    (:FILE "src/series/routing-types.lisp" :MD5
     "ce649df47dd38888d5103c98345f7e41")
    (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
    (:FILE "src/series/worker-boundary.lisp" :MD5
     "2340e0c9074f7b1bf80c74f774986bc5")
    (:FILE "src/series/worker-package.lisp" :MD5
     "a93ce2e84e8aee647b5083ad1d2b899b")
    (:FILE "src/series/worker-run.lisp" :MD5
     "f0fee18adf357bad98e8a3c3e8c70c0c")
    (:FILE "src/series/worker-types.lisp" :MD5
     "2b23d468be0165fa009c5ebd5d1bbe23")
    (:FILE "src/storage/compaction-scan.lisp" :MD5
     "1cda77a357ab2147035993b72d135a37")
    (:FILE "src/storage/control-payload.lisp" :MD5
     "cb64f806b8d69eb42d865b4abfff0b27")
    (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
    (:FILE "src/storage/log-header.lisp" :MD5
     "b53d27dcc9f4badf18b50519c50bc614")
    (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
    (:FILE "src/storage/payload-record.lisp" :MD5
     "8c03f9c01dcb30f2d3970a5694968ecf")
    (:FILE "src/storage/payload-write.lisp" :MD5
     "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
    (:FILE "src/storage/segment-header.lisp" :MD5
     "d6812fa59bf8fd1252fbf85a9bfa3896")
    (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
    (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
    (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
    (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
    (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
    (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
    (:FILE "tests/foundation/support.lisp" :MD5
     "758adad069aec2f9dbe0635797314ff6")
    (:FILE "tests/get-directory/support.lisp" :MD5
     "3f868ebe4307ad4238b314c37eceed9a")
    (:FILE "tests/get-directory/construction.lisp" :MD5
     "1137938073e71d6d8d62c751fbad05d5")
    (:FILE "tests/get-directory/read.lisp" :MD5
     "d1ab36d05cc1266e4533d27c693f12f4")
    (:FILE "tests/get-directory/threads.lisp" :MD5
     "63dd01c852de1399c2c82274d481d257")
    (:FILE "tests/get-directory/series-support.lisp" :MD5
     "004b8f8cf110a26e3dc56a2a4a67c3f1")
    (:FILE "tests/get-directory/series-read.lisp" :MD5
     "08b80240b37fb703ac2cfb9acde1dfa8")
    (:FILE "tools/get-series-mutation.lisp" :MD5
     "2068edb227d28b9e53c4eecc125fca54")))
  :ARTIFACTS-VERIFIED T :SIGNAL NIL :EXIT-CODE 1 :SOURCE-MANIFEST
  ((:FILE "arcdocdb.asd" :MD5 "86f5e897461590ccc2370d6655acd0d0")
   (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
   (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
   (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
   (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
   (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
   (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
   (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
   (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
    "bc7a7b176e8cdd361b7c4306a1a4de4b")
   (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
   (:FILE "src/codec/cbor-minimal.lisp" :MD5
    "ecd8fe950344059c629927b38fb6e4aa")
   (:FILE "src/codec/cbor-package.lisp" :MD5
    "c3f19ffb4aacfdfe502c5e8b12a234f2")
   (:FILE "src/codec/cbor-scan-input.lisp" :MD5
    "f6488e987889432b375254021825dbe5")
   (:FILE "src/codec/cbor-scan-items.lisp" :MD5
    "706c0baa4158bf272c4b0df17c1439d2")
   (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
    "987e8ed576a21eb644ac1ef2e06edbda")
   (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
    "cf1999ddb10f879aeefbeea853742d57")
   (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
   (:FILE "src/codec/cbor-simple-write.lisp" :MD5
    "200373402e6e082dd8c7afde305302bb")
   (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
   (:FILE "src/codec/cbor-string-write.lisp" :MD5
    "b13e92b5f24a42fe283c17b649722b6a")
   (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
   (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
   (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
   (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
   (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
   (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
   (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
   (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
   (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
   (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
   (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
   (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
   (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
   (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
   (:FILE "src/execution/ready-recycle.lisp" :MD5
    "38d26f8c749dd946dfc4b9c57103a892")
   (:FILE "src/execution/ready-types.lisp" :MD5
    "a64d98c9ff429d6103d6e10ee1fd7980")
   (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
   (:FILE "src/execution/worker-boundary.lisp" :MD5
    "c24065d6c8d80d1be53994a0041743df")
   (:FILE "src/execution/worker-claim.lisp" :MD5
    "babd0a78b4185af24ae1fef870c0fabb")
   (:FILE "src/execution/worker-run.lisp" :MD5
    "aa34ca6bc07535e35fea723878d99f66")
   (:FILE "src/execution/worker-types.lisp" :MD5
    "0679ee07c46f69db330706303c70d8d2")
   (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
   (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
   (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
   (:FILE "src/foundation/conditions.lisp" :MD5
    "942b596396c19815290a57830af2121b")
   (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
   (:FILE "src/foundation/package.lisp" :MD5
    "5ee593a112958d94163dab17c5aa4ba2")
   (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
   (:FILE "src/get-directory/build.lisp" :MD5
    "cde24b2bf5c5637d5501b95bed47df31")
   (:FILE "src/get-directory/package.lisp" :MD5
    "894f6e238fe4047f2bf607fceae86846")
   (:FILE "src/get-directory/read.lisp" :MD5
    "74a694385f1aaf03ec87721545494119")
   (:FILE "src/get-directory/sources-read.lisp" :MD5
    "2b8193aab6801de19e26fa55e7c53f87")
   (:FILE "src/get-directory/sources-types.lisp" :MD5
    "b846a6348ff7d4b5f7b380b5b3ff8c17")
   (:FILE "src/get-directory/types.lisp" :MD5
    "17c957d6934a31f4ed64313e756de2d2")
   (:FILE "src/get-resolver/active-build.lisp" :MD5
    "8d26428a4e17ad18990b8ee7d5f5b53a")
   (:FILE "src/get-resolver/active-directory.lisp" :MD5
    "6d95f29b331d335175843f47ae44a6ea")
   (:FILE "src/get-resolver/active-preflight.lisp" :MD5
    "f13d422adb6aa9e8489352884137f25a")
   (:FILE "src/get-resolver/active-read.lisp" :MD5
    "521737861e057d663964b0c030552587")
   (:FILE "src/get-resolver/active-scan.lisp" :MD5
    "d6aaec49504a96f37c8ff1bc182c977b")
   (:FILE "src/get-resolver/active-types.lisp" :MD5
    "bd7182e9871fe82530d0c828e473ccde")
   (:FILE "src/get-resolver/build.lisp" :MD5
    "bbfb2082103e6712419e180ab972245c")
   (:FILE "src/get-resolver/package.lisp" :MD5
    "b537f636f38cd80ae73e2131c72532b4")
   (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
   (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
   (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
   (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
   (:FILE "src/get-resolver/types.lisp" :MD5
    "9df13bcc6908e9fa601d173a671e1ccf")
   (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
   (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
   (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
   (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
   (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
   (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
   (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
   (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
   (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
   (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
   (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
   (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
   (:FILE "src/index/hash-digests.lisp" :MD5
    "43d2209225707352daec6186ef95a805")
   (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
   (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
   (:FILE "src/index/primary-arena.lisp" :MD5
    "a319691e3e28b7ea7b927de490cf69ba")
   (:FILE "src/index/primary-build.lisp" :MD5
    "ff2cfbb865290d7a1510fdf6877c7229")
   (:FILE "src/index/primary-core.lisp" :MD5
    "fa52433eae199ceeb874bf2bc47afca7")
   (:FILE "src/index/primary-directory.lisp" :MD5
    "1dd67c527257e43f17e006644ecdbd00")
   (:FILE "src/index/primary-package.lisp" :MD5
    "d65cfce399b04f905bf969929962e59a")
   (:FILE "src/index/primary-probe.lisp" :MD5
    "699ce3f1615296fc27fcde3e0d63a4bc")
   (:FILE "src/index/primary-read.lisp" :MD5
    "3f317a0d3c5ee86a73651aad36135cc3")
   (:FILE "src/index/primary-relocate.lisp" :MD5
    "5155959766645d3172ae5e73c58cc071")
   (:FILE "src/index/primary-types.lisp" :MD5
    "a59eab6425a60fa2656f86bf87d5c9ac")
   (:FILE "src/index/primary-write.lisp" :MD5
    "e8e31e599356e592af29c0cc4604872b")
   (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
   (:FILE "src/index/rebuild-budget.lisp" :MD5
    "0417dd41cb3ec1d62dfd913c19f810ad")
   (:FILE "src/index/rebuild-copy.lisp" :MD5
    "8befbbd00ed5c31c1487a11887eba495")
   (:FILE "src/index/rebuild-scan.lisp" :MD5
    "1188e7a64a7a5d9482c1233cb9acb452")
   (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
   (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
   (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
   (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
   (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
   (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
   (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
   (:FILE "src/io/native.lisp" :MD5 "9500cfb800603de002d6d2b24f1bf056")
   (:FILE "src/io/package.lisp" :MD5 "c9380ad46a1d7acf41655aaed20db478")
   (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
   (:FILE "src/io/types.lisp" :MD5 "db8497f9cff35b1ee261f1f410f46ca6")
   (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
   (:FILE "src/mvcc/snapshots-core.lisp" :MD5
    "8bb066aab61a18eff175b9edb11e42a2")
   (:FILE "src/mvcc/snapshots-csn.lisp" :MD5
    "0e9365e674d1584b111f915ce1f58634")
   (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
    "ff98aea5cb9a7ae2671f6a887a003725")
   (:FILE "src/mvcc/snapshots-read.lisp" :MD5
    "ae3ad96269b5e711a9dbb455f3c0ce48")
   (:FILE "src/mvcc/snapshots-register.lisp" :MD5
    "2d5a795bcefd605c75da91c725ae83a2")
   (:FILE "src/mvcc/snapshots-types.lisp" :MD5
    "475517bd7ba04a1c37a82efeb8ff73d9")
   (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
   (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
   (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
   (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
   (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
   (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
   (:FILE "src/recovery/decisions-build.lisp" :MD5
    "1a51ef4a488bb9fde2ff7d47bae01379")
   (:FILE "src/recovery/decisions-package.lisp" :MD5
    "cbdc30f93109c474e1fc25066c9b9b13")
   (:FILE "src/recovery/decisions-query.lisp" :MD5
    "f782d1137b8ce342b91c9999cfb7accc")
   (:FILE "src/recovery/decisions-radix.lisp" :MD5
    "852149de4c289b8e067602780378d87a")
   (:FILE "src/recovery/decisions-sort.lisp" :MD5
    "b33e57a643f2fca810846f6226366253")
   (:FILE "src/recovery/decisions-types.lisp" :MD5
    "f4433fd19ebc7239dbc2628c39f3ecdb")
   (:FILE "src/recovery/inventory-build.lisp" :MD5
    "9bd6820c4feba3e552aab1a4edd87861")
   (:FILE "src/recovery/inventory-query.lisp" :MD5
    "fcea263de1938767772e5b11411ecd5e")
   (:FILE "src/recovery/inventory-types.lisp" :MD5
    "78c136d5838dcfe3019d9069643a8d8f")
   (:FILE "src/recovery/manifest-build.lisp" :MD5
    "bf65b1731eab6e0572461ef5cc60fc40")
   (:FILE "src/recovery/manifest-decode.lisp" :MD5
    "67975249aaabd751757cdfb9222cc3c4")
   (:FILE "src/recovery/manifest-fold.lisp" :MD5
    "e0d2498db1011e857b7b0daa1934f187")
   (:FILE "src/recovery/manifest-package.lisp" :MD5
    "37ace42844c11b52446ee1fc500b8e0b")
   (:FILE "src/recovery/manifest-query.lisp" :MD5
    "ebd7a54adea2213294a887e6d4db0927")
   (:FILE "src/recovery/manifest-types.lisp" :MD5
    "7b1d4054415faca7e5fca59ad83b4d4a")
   (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
   (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
   (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
   (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
   (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
   (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
   (:FILE "src/series/publication.lisp" :MD5
    "056d2c6a67c9d9f2bf9fe2d2c348d53c")
   (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
   (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
   (:FILE "src/series/routing-build.lisp" :MD5
    "d6924deff152b941bd49f0bb200b4197")
   (:FILE "src/series/routing-select.lisp" :MD5
    "e0f987d8767744050ec4d1b3ecb699ed")
   (:FILE "src/series/routing-types.lisp" :MD5
    "ce649df47dd38888d5103c98345f7e41")
   (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
   (:FILE "src/series/worker-boundary.lisp" :MD5
    "2340e0c9074f7b1bf80c74f774986bc5")
   (:FILE "src/series/worker-package.lisp" :MD5
    "a93ce2e84e8aee647b5083ad1d2b899b")
   (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
   (:FILE "src/series/worker-types.lisp" :MD5
    "2b23d468be0165fa009c5ebd5d1bbe23")
   (:FILE "src/storage/compaction-scan.lisp" :MD5
    "1cda77a357ab2147035993b72d135a37")
   (:FILE "src/storage/control-payload.lisp" :MD5
    "cb64f806b8d69eb42d865b4abfff0b27")
   (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
   (:FILE "src/storage/log-header.lisp" :MD5
    "b53d27dcc9f4badf18b50519c50bc614")
   (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
   (:FILE "src/storage/payload-record.lisp" :MD5
    "8c03f9c01dcb30f2d3970a5694968ecf")
   (:FILE "src/storage/payload-write.lisp" :MD5
    "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
   (:FILE "src/storage/segment-header.lisp" :MD5
    "d6812fa59bf8fd1252fbf85a9bfa3896")
   (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
   (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
   (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
   (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
   (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
   (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
   (:FILE "tests/foundation/support.lisp" :MD5
    "758adad069aec2f9dbe0635797314ff6")
   (:FILE "tests/get-directory/support.lisp" :MD5
    "3f868ebe4307ad4238b314c37eceed9a")
   (:FILE "tests/get-directory/construction.lisp" :MD5
    "1137938073e71d6d8d62c751fbad05d5")
   (:FILE "tests/get-directory/read.lisp" :MD5
    "d1ab36d05cc1266e4533d27c693f12f4")
   (:FILE "tests/get-directory/threads.lisp" :MD5
    "63dd01c852de1399c2c82274d481d257")
   (:FILE "tests/get-directory/series-support.lisp" :MD5
    "004b8f8cf110a26e3dc56a2a4a67c3f1")
   (:FILE "tests/get-directory/series-read.lisp" :MD5
    "08b80240b37fb703ac2cfb9acde1dfa8")
   (:FILE "tools/get-series-mutation.lisp" :MD5
    "2068edb227d28b9e53c4eecc125fca54"))
  :DEADLINE-SECONDS 120 :ARGV
  ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
   "--script"
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/evidence/baseline/driver.lisp"
   "--child"
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/evidence/baseline/config.lisp")
  :NAME "baseline" :FILE NIL :RESULT :BASELINE-FAILED :STATUS :FAILED
  :COPY-DIRECTORY
  "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/isolatedtests/baseline/"
  :EVIDENCE-DIRECTORY
  "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/raw/evidence/baseline/"
  :EXPECTED-FAILURE NIL :PRODUCER-RECORD
  "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-c/report.lisp"
  :PRODUCER-CLOSED T :CHILD-LAUNCHED T :CHILD-REAPED T :TIMED-OUT NIL :CLEANUP
  :REAPED)
 :MUTANTS NIL :TARGETS
 ((:NAME "planned-root-instead-of-published" :FILE
   "src/get-directory/sources-read.lisp" :TEST
   "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION" :BEFORE
   "(root (leggi-radice-serie controller))" :AFTER
   "(root (arcdocdb.series::controllore-serie-planned-root controller))"
   :EXPECTED-FAILURE :PUBLISHED-ROOT-OR-SINGLE-ACQUIRE)
  (:NAME "accept-active-closed-duplicate" :FILE
   "src/get-directory/sources-read.lisp" :TEST
   "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED" :BEFORE
   "(guasto-get context :sources-active-duplicate)" :AFTER
   "(when (null active) (guasto-get context :sources-active-duplicate))"
   :EXPECTED-FAILURE :ACTIVE-CLOSED-DUPLICATE-ACCEPTED)
  (:NAME "dispatch-active-to-closed" :FILE
   "src/get-directory/sources-read.lisp" :TEST
   "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED" :BEFORE
   "(risolvi-candidato-radice-attiva-get context active)" :AFTER
   "(risolvi-candidato-directory-get context (fonti-get-serie-directory sources))"
   :EXPECTED-FAILURE :ACTIVE-SELECTION)
  (:NAME "active-end-one-byte-overrun" :FILE
   "src/get-resolver/active-read.lisp" :TEST
   "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE" :BEFORE
   "(values segment end flags nil)" :AFTER
   "(values segment (1+ end) flags nil)" :EXPECTED-FAILURE
   :ACTIVE-COMMITTED-FRONTIER))
 :EXPECTED-TESTS
 ("TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP"
  "TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2"
  "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED"
  "TEST-REQ-CCH-002-SERIES-GET-FIVE-OUTCOMES-COLD-AND-HOT"
  "TEST-REQ-CCH-004-SERIES-GET-CACHE-CORRUPTION-NATIVE-FALLBACK"
  "TEST-REQ-CMP-007-SERIES-GET-WRONG-OWNER-CLEANUP"
  "TEST-REQ-AFF-004-SERIES-GET-NIL-AND-CORRUPT-ROOT-FAULTED"
  "TEST-REQ-AFF-004-SERIES-GET-CORRUPT-ACTIVE-CONTENT-FAULTED"
  "TEST-REQ-AFF-004-SERIES-GET-SOURCE-CONTROLLER-MISMATCH-TYPED-FAULTED"
  "TEST-REQ-IDX-001-SERIES-GET-MISSING-CLOSED-ID-FAULTED"
  "TEST-REQ-CON-004-SERIES-GET-WRONG-STATE-NO-PIN-STEAL"
  "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION"
  "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
  "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-EXCLUDES-LATER-PUBLICATION"
  "TEST-REQ-WAL-005-SERIES-GET-WRITER-FOREIGN-OWNER-BEFORE-ADOPTION"
  "TEST-REQ-WAL-005-SERIES-GET-WRITER-DUPLICATE-ACTIVE-BEFORE-ADOPTION"
  "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED"
  "TEST-REQ-AFF-004-SERIES-GET-ACTIVE-OWNER-AND-ID-GUARDS"
  "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-EMPTY-AND-ID-EXTREMES"
  "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-65536-GEOMETRY-SEARCH17"
  "TEST-REQ-CON-004-SERIES-GET-BUFFER-REQUIRED-FIVE-OUTCOMES-AND-RESTART"
  "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-READER-FAULTED"
  "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-WRITER-ARCHIVE-FAULTED")
 :SOURCE-CONSISTENCY :STABLE :RAW-ROOT "raw/evidence/" :COLLECTOR-EXCLUSIONS
 ("raw/isolatedtests/") :CHILD-DEADLINE-SECONDS 120 :CAMPAIGN-DEADLINE-SECONDS
 900 :STATIC-RISKS
 (:PARENT-SOURCE-FREEZE-REQUIRED :NOT-EXECUTED-BY-AUTHOR
  :ONLY-FOUR-READ-MUTANTS :NEW-SERIES-SUITE-REQUIRED :NATIVE-FIXTURE-IO
  :SERIAL-FUNCTION-FI :COMPILER-FIXTURE-TYPE-IO-TIMEOUT-CRASH-NOT-KILLS
  :ISOLATEDCOPIES-EXCLUDED-FROM-COLLECTOR
  :EVIDENCE-DIRECTORY-MUST-BE-COLLECTED-WITH-TERMINAL-PRODUCER
  :MD5-FOR-LOCAL-BYTE-IDENTITY-NOT-ADVERSARIAL-ATTESTATION
  :NO-ENGINE-QUALIFICATION))
