(:FINISHED-AT-UNIVERSAL-TIME 4000906976 :CONDITION-TYPE "SIMPLE-ERROR"
 :DIAGNOSTIC "Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-OPERATION
                       ARCDOCDB.GET.DIRECTORY.TESTS::OPERATION
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-CONTEXT
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE)
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-FIXTURE-CONTROLLER
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVARIANT-VIOLATION (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :SOURCES-ACTIVE-DUPLICATE)))"
 :SCHEMA-VERSION 1 :KIND :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE
 :TESTS :COMPILED T :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "23a9e837d437b705ca7bd826fa755f89" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "17ef2369e382bc198188727f73d67673")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "5ebceb4f65e866bcbf0c5ff3722ce4b9")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "49c7390ccf572403dc96d8126674bf13")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "d4d8c0276039272d08d55eb49180f705")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "9a30e68b787c428bbd328ef6e7a9fb22")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "bc7783b9d58d9115dee39f3fc9e05989")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "160f7b73dffa5d3cad533debb1126e5e")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/types.fasl"
   :FASL-MD5 "bb5886c1325a091f90f5e09680c27e2f")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/package.fasl"
   :FASL-MD5 "12b7f2b18da802c3ac57fc54579f5d4e")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/group.fasl"
   :FASL-MD5 "1a40b7abfa3e1c0bc952bf714d431c5c")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/executor.fasl"
   :FASL-MD5 "aef0560823d9494e456261c10498fbd7")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/csn.fasl"
   :FASL-MD5 "a175016f89fd38ed5fd10b903eab08ea")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/builder.fasl"
   :FASL-MD5 "f928b267a8acf076f150428369bf58b9")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "51fb6ffae5ab4c120b7257cf41b1743b")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "fb7a4d70107c97f43a6b7ec2006b6e42")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "c3a53dfec07a0046a666d585d0d3c64f")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/package.fasl"
   :FASL-MD5 "d39e2d878eafafa821f06929476e3a19")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "20a1ae165faa335f5e303497e615836a")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/formats.fasl"
   :FASL-MD5 "310174ca84bf59db659e63cc24c6376c")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "b7a8f585d8af7454d32d7cdacbd43c5c")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "c5ad883bb783abaab0a5ea778962e138")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "94b512e5bb6e14381037654ce6ad75d2")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "15f896ecf8402538e2a3e2d954e90e8f")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "438e6108ca85f8b5b2ab046df301ca0e")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "e1cc1f295ed48da39f4900fe589fef4c")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/types.fasl"
   :FASL-MD5 "936ac8c235defb9684c7eaae8503c4c3")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "40d3949c0bb8608655696a6d2e5d6174")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "20eda707e3e22bbf52c943dabf8b5b0e")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "1607cfc98f748516457e37be5a13b6a8")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/retirement.fasl"
   :FASL-MD5 "88c325fc20199540046a301eb89272c5")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/query.fasl"
   :FASL-MD5 "8842fc2d52a5417b4599ad8a3137ee11")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/publication.fasl"
   :FASL-MD5 "12e3aef2334da887848c4e3b9edc854b")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/package.fasl"
   :FASL-MD5 "20d178c558baa87d2ebd55e13ac58cd4")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/ownership.fasl"
   :FASL-MD5 "99253ad300b82f420c3cdf28c45322d4")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/io-events.fasl"
   :FASL-MD5 "b519546715183c323fcda7ecb37a59f9")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/events.fasl"
   :FASL-MD5 "9a5406731766051e1902643307bef6b5")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "2f53f3b6bab54cbf22b0be710c77f0e9")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/package.fasl"
   :FASL-MD5 "f0161f201fa34b8bd30837b5bcec0c2b")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "fd959b26b7a209f8daa91e03b44f5d05")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "216891a9c60a5b4832e85e168f504a25")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "c04dd6fd2e0433cc6bbe9db726b0c3c5")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "cec527ed0af5e8b4cd0d1fc0560f1de0")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "27c266f70dc1641dbfc82723401be0e2")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "c460fb6b905709f2098b8a23dbe19087")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "9c6d36747e9825bc664581a135fe733d")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "c47120253f27bf36e66a2b4ba2ebce8d")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "b059b8effd033120cb7804bbb5d87739")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "01306761e12104b6cfd8f385d5732988")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "e23a67203e0f02e2496790928b337de5")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "806bfd6be52610f9eef6a3cc28d2692f")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "3e9fba0c3739272f630b22ab15a7fa07")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "e89aacf60cc055970790f58448ef770d")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "d11cda06dc3c5a9e0d11cae2c325a4c6")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/types.fasl"
   :FASL-MD5 "c702a38ad2d036b397d1db4a01380855")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/task.fasl"
   :FASL-MD5 "b0aa19a8c7a9be37cb990cdb851da4f4")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/package.fasl"
   :FASL-MD5 "d823ce9dc071563f7af7607ac9457a30")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/core.fasl"
   :FASL-MD5 "f5d503e19f41e88cf50ea9c0a6e1a000")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/package.fasl"
   :FASL-MD5 "e9f98747a371f93ebb028aba238e3983")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "3f71940875b9911a8c8d063f1bcd8212")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "16f26df8546f9bf9b5394e1cb7a55422")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "83f9467ce9abb192ad9c5487e3bee3ed")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "c95da1a972d0f378e733455ca6d70aed")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "3aa99676b522c0881f5bc3e37e6bef9b")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "2e9e7614a2e63c8758a842526906a24a")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "83e6804e14c986bf3ddbe093d900281c")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "bb71e84c0d7ca4c67c821eff7cf08fe6")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/types.fasl"
   :FASL-MD5 "6497f047d37c5179f3eb8d7243c7b8ab")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/transfer.fasl"
   :FASL-MD5 "83963782e75622c54f023c1344677740")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/package.fasl"
   :FASL-MD5 "88b7de629b4ae03e17380be478e27319")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/native.fasl"
   :FASL-MD5 "c609747b2833e26bb3a19f0d57dedcf4")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "522793872dd25ec49a03431858a5b308")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/identity.fasl"
   :FASL-MD5 "2f0fd257f50ad5f5349fc4c9e6e88af0")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "7dd33aa3fc52321c8ee2db442c9763c2")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/flush.fasl"
   :FASL-MD5 "5eab162d1de7634a60fc2c25bd20a22e")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/write.fasl"
   :FASL-MD5 "50f5fd551cc0cfeb4797c277343c58d3")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/validation.fasl"
   :FASL-MD5 "cb407b4c6292635eb893998675f985e6")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/types.fasl"
   :FASL-MD5 "15e0b90b0ffd7682c82eb8fc7abde379")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/relocate.fasl"
   :FASL-MD5 "4b15eac80e79440415e7882e22fa3488")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "e4ec277d3999ab15e01f9625d29a5c46")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "aa5341068f11fb275195f3500bf54375")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "4808e0c2156177071a6aa25e1f9e8b8d")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "dd8a36e9d34fbc5a06fae750051ae3f3")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/read.fasl"
   :FASL-MD5 "1b151d18cab4088d23b813f441016e4b")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "531e343c8dccb345551bfa887ec2cf7d")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "4174bc9166804e9f7e4b4fe4a17b974d")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "c2d9944196ef36aaf1ade0912920d5e5")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "0b5fb4d1532f4e9f2b5a1f82b6bad4d3")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "4b9d40027e343c219dc7e81d453f9eeb")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "bf7fdafadca8255d9c8376c725facf19")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "d00d6db6753ecae8a9ed28d2032f19b4")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "71d2ca394ef15496895f51effffdf10a")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "8df8969216852acd546e401d34640e09")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "dabdd456d4c264beb1b8999d6ea5dbe4")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/package.fasl"
   :FASL-MD5 "ed74d6cfc222b88d8d830455dd56a2b7")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "608247a0ed4d47565ee12e17153d0b14")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "6cea224cd3c4f56e241aa293475a322d")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/core.fasl"
   :FASL-MD5 "64ac8150896bda9fec6e05696d92203c")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/package.fasl"
   :FASL-MD5 "00dbd84e3630d5f533837179724e19a2")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "401d1d006ace4868d3db68d1f485e286")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "4a39747d41ede332512bf7ec58ea6975")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "e2a461e7fadfe451dad1d0f74838b74d")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/types.fasl"
   :FASL-MD5 "55f4e3ed4cf1ba31ff2dd636b800d786")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/target.fasl"
   :FASL-MD5 "c104bed345c9c6ccad7a59e8393fdfb2")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/segment.fasl"
   :FASL-MD5 "60a4fc3f2afa2650a89159b905255cac")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/package.fasl"
   :FASL-MD5 "b64aa045c13872d86c28a9024f4d86b7")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/lookup.fasl"
   :FASL-MD5 "12269f30724f14c11b3209dbb75825d9")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "5801f78140c7489b00d36e59c7b35541")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/build.fasl"
   :FASL-MD5 "6cc742db54485283028829e28c3bbfd1")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "52fb0d42f6c2eee063ec34aa6c42ed22")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "d5ce436a3fd07fdd40d805edbc983e88")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "a02835b026aea97d3173b8a7326dfe87")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "0bf51318ffaf9aeda870bb07ee223d78")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "94b924e2d625aa1046af373e2fd3b7f5")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "0780c5c651f76ee6ebc9f7a7d00e8ff1")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "8900a670eec84a946b3f300592e8c656")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "9824fef5b38ab6d8b12199f593a3450d")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "e046b8238fd46310fa33b01fb89a2597")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "521737861e057d663964b0c030552587" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "da283c6e093b331cf8b062653e79dbee")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "55239d7a307f7dc7b97f54732e5346db")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "f28ac0a0460f6c32f35dfeb2abbf729b")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "4d2d8624fd522e7e206585cdb41ac11d")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "a517c7a462dc4bfe39bcea7423b3e637")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "6bd2bb5e17c2f866019f85de58aee729")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "f308c6780bdb4e3839a67eb57e0bbcba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "6fef2f5a302d888165e18c93f553b129")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "bc4e922bb8efa70789a68265353016e5")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "0c3339f5ca97104c9ae47191d6641334")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "33e5a33ebdc64983cc2599cec611a323")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/record.fasl"
   :FASL-MD5 "620f3bdb35a842744a45f8f01e53c313")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/package.fasl"
   :FASL-MD5 "a383ff7a68d60aafca6aa98251fb0349")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "25c26cb96cba69a9c6c4e84dc96f88c8")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "167a0ff18861ccfad53507874bccfd44")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "e9536925b54cdd1c051288040d368f71")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "cd27470ba34f52f6dff1a900a07f6be9")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/writer.fasl"
   :FASL-MD5 "22d507c1d5ca69f89610f65fe768af47")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "fb5f9a3210451f815fc31324780aad81")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "66f5081be0c1529cdab454d8e992d4f8")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "4c84703214e14410032a60e986fe2288")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "beb6a5762c815eae6aff92aecaa30d39")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/ready.fasl"
   :FASL-MD5 "3f3f589d2737708e299dff40792448f6")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "3a904a1592d96606c6af78fbe78bc486")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "c565e4c8dfc1581954f068fe504405b8")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/queue.fasl"
   :FASL-MD5 "1906b3512ea8d7431b88e307ddbe5d35")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/package.fasl"
   :FASL-MD5 "dd096d1c35a092f8faa7ba52b4626524")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "844224018b9602863831b8e10a19bbf3")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/types.fasl"
   :FASL-MD5 "2885286fb00e2289182a023e77d9f400")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "06273efe066238c66908da9b116af11d")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "0223e94812cfde895b87dce8d92e43d7")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/read.fasl"
   :FASL-MD5 "6e48b0d8fcc02cacc9606c6de7cfd50f")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/package.fasl"
   :FASL-MD5 "8de9f59a8eed04a92a24303d31679544")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/core.fasl"
   :FASL-MD5 "a0cfbb1fd8ede074364a6daea52823a3")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/csn/registry.fasl"
   :FASL-MD5 "53b5ad39a70a904b5db0e216f1ec0534")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/csn/package.fasl"
   :FASL-MD5 "b1e2d9ac40d73a6dcd7d2cbf4aacfbab")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "feb6af32577728bd71ddecda8253d6e5")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/package.fasl"
   :FASL-MD5 "fc930b23fca2720c20125e2d05fd0935")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "36979d99b9c0d0a3bfbe73142250822d")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "3c607f83522abe493acbd1617691a2b8")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "70a7b5bc4bba76807173a6ba33ad5782")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "b9a8605f20206b87187efb268731144f")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "b5b079ca7775e5ce9db8e308a820df00")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "6855c20e06fd1ddab6f94af6f99db501")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "85143a25979c0de4f24dd8900c746a06")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "9fb4a761741b10f64db2e1216d5f1446")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "afb4fa2cffd29c32b4f493e9ddcf0e6c")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "a5f8f47031810fecba3c456aa853d237")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "665292ae677c03f1c7d2102fba662513")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "70c0dbd1d99fa3628d3110f3653ebc62")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "7181c299f5d2b4727e023b7c1ba368e6")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/write.fasl"
   :FASL-MD5 "d000fe22fcbac70d0bb0894d8b1c33d2")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/types.fasl"
   :FASL-MD5 "d61e79b8982d4c0e6497673154f80522")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/read.fasl"
   :FASL-MD5 "ef26aeb510b4bf4a7f048e7f88cc4d30")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/package.fasl"
   :FASL-MD5 "0dc45e32e86d38c19bc063020dd8a132")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/core.fasl"
   :FASL-MD5 "b720233e3314bc389cc65f74b39abc0b")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/clock.fasl"
   :FASL-MD5 "abc9fee297285dafa6793424abc65f6c")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/build.fasl"
   :FASL-MD5 "c0e1d1635cd806c0e56fbb8ae5bc814c"))
 :EXPECTED-TESTS
 ("TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED" :FAILURE-KIND
 :ASSERTION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "e8571ddf559a7a9b6d291de4fdf50717")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "f308c6780bdb4e3839a67eb57e0bbcba")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "23a9e837d437b705ca7bd826fa755f89")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
