(:FINISHED-AT-UNIVERSAL-TIME 4000906988 :CONDITION-TYPE "SIMPLE-ERROR"
 :DIAGNOSTIC "Asserzione fallita: (EQUAL
                     (LIST
                      (ARCDOCDB.GET.RESOLVER::SORGENTE-GET-ATTIVA-SEGMENT
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-FIXTURE-SOURCE
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      176 0 NIL)
                     (MULTIPLE-VALUE-LIST
                      (ARCDOCDB.GET.RESOLVER:RISOLVI-CANDIDATO-RADICE-ATTIVA-GET
                       ARCDOCDB.GET.DIRECTORY.TESTS::CONTEXT
                       ARCDOCDB.GET.DIRECTORY.TESTS::CAPTURED)))"
 :SCHEMA-VERSION 1 :KIND :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE
 :TESTS :COMPILED T :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "23a9e837d437b705ca7bd826fa755f89" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "633ddb1a7fa0271a6e2f775a14aed105")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "dc017cc221480fb03859ba54b668fe2a")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "47795a6bf81248408075bed94f94f368")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "f069decef2691f3235660150bb3fa570")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "e0fad3511ad8432d3572c093937a63c1")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "4d5a8a7ed4fdaab3e7003cbdd107804f")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "7592d5f44a553588c992c9a363888678")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/types.fasl"
   :FASL-MD5 "3c35e8b99c13b834d819ce9e424193ba")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/package.fasl"
   :FASL-MD5 "69cc54f62f472e8058f8e22ea5c0a5f9")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/group.fasl"
   :FASL-MD5 "d136a8368161e92ca3c9c5cfaff3a476")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/executor.fasl"
   :FASL-MD5 "46721ead47c864ee42c040cf3cfa646e")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/csn.fasl"
   :FASL-MD5 "3bceb7ff8473839b18d56ddfffb1401e")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/builder.fasl"
   :FASL-MD5 "b7cc37465d100d323014dccfb3502e7b")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "db5a1d72f7ec18a5a4cba48cda23e8b2")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "10e6f0a720ebd4023014293576f807a4")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "a0c3ff1d29c3d523d1f19968bb787c5a")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/package.fasl"
   :FASL-MD5 "d6570f7d30318e7da04f5cfc56eb1cac")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "8521e528d2b2f8f1bf30625617c84c92")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/formats.fasl"
   :FASL-MD5 "8ce8ec9d760f4b4a967725084fffcdb5")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "2d1a888f720821f3d99bb4788d3a6fec")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "f2b56d2779166e2b1d6fc2adad1db637")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "320b96e64cd302faecbde7aaa073ebb9")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "efd5fbebbd8149d288e11870b1e43b25")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "1ba60268e6ece9408ccd782771e0977d")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "91e829d006a4dd083a0aceadf326e7d9")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/types.fasl"
   :FASL-MD5 "a3f2f20f685f9355817c00a9a3879174")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "2f69dd256116790f971be79a345e0a70")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "f34b16d84fa7a18c9838a8b44eafbc8c")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "8a91ecb00b78264de0fcc7d0a27b1914")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/retirement.fasl"
   :FASL-MD5 "5b658f840a0cd0412f3c22f1984360a9")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/query.fasl"
   :FASL-MD5 "08fbfa89e547e6ec1f534cea8fa1ea45")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/publication.fasl"
   :FASL-MD5 "1c3e2e5189cc363d131ec8988652cd76")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/package.fasl"
   :FASL-MD5 "bb4c872acef3e53fbb2cbcc07f82cc88")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/ownership.fasl"
   :FASL-MD5 "0b8a02b0da20565f9eaca52c79477894")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/io-events.fasl"
   :FASL-MD5 "becd275efdec8320382f6d15b2c29c2d")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/events.fasl"
   :FASL-MD5 "177b94fa94d533d82a5c67024f845055")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "6eeb3f829677596913aaef3df34973d2")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/package.fasl"
   :FASL-MD5 "1a49b95f71b8d2a1b9f805c525e1e994")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "e2a6d23f9e70cf9de84bc9ee5e29813c")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "d36d4b6e8fb51733b66bb97a69e53f88")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "6583d5a09709c82a84bf7d92f575ba05")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "557e3bca92428fc58db68d6805bf4968")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "3f69e0ee3cb3e02bb520db199d704f51")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "35c6e2692887a14141726c2ca37aeb17")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "fdbaa8a5dc2351cc8be05b5ad024b38e")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "692e2579a4d09ac8626bf6c08d3b361b")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "15a079f071706b705d70b1ee56656b81")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "8cb8ec69d47de5d91bc12fce7ca89b86")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "b0639455a0acaf27e13b2bf92b2241fe")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "5ca0689303078b26de7da57ee7c0097c")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "6372132882138df3122cd97202fc1b24")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "783ace7dbd482ecc9ffac6f19ad42fd1")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "3e4bfc3f425bb268ec2537f60f04bb20")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/types.fasl"
   :FASL-MD5 "79f72fe6534d94e94787e7a8717bd1f5")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/task.fasl"
   :FASL-MD5 "3747e994ea242baed0d9f40fe2905ad6")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/package.fasl"
   :FASL-MD5 "c680d5d1a5368cdd89bf0b5e080ae230")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/core.fasl"
   :FASL-MD5 "75ae1ab8f7bc3ce6728a8b15d581f559")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/package.fasl"
   :FASL-MD5 "ced1b24d95ec854f63c107443acff7c9")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "c87238ac12fe34d0c261648aa31127aa")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "fa8527ad92dc5ed1b0e133f98916c92b")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "f277a9b885f81bbb08a5ea8528e4e541")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "0a0e4af7b18053530932901138114679")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "76c2de4c48476e6bd6d4cb4c32c030f0")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "247bec0b5bfb10e2608228df41cfae21")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "d6df76dd174b83e52fd67dd81e1769d4")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "a462571d78a9a4a34ac8e20970ef2536")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/types.fasl"
   :FASL-MD5 "20fa3a5f683569fe7e5a29914c10d5a1")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/transfer.fasl"
   :FASL-MD5 "d2bd14a073ad10ec2dcf94fb93a2f64b")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/package.fasl"
   :FASL-MD5 "6c005e8be600796d301b4e85638196fb")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/native.fasl"
   :FASL-MD5 "57e004eb0d6a489bfd64450a093e7818")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "34a04ff3c575d28dae6cf03fa5484221")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/identity.fasl"
   :FASL-MD5 "9e31460995f36def55165e2b0a180403")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "b9d22ab71999552b48db2918880c55ba")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/flush.fasl"
   :FASL-MD5 "ab8a02d79d7a0aec7a866ced678a627b")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/write.fasl"
   :FASL-MD5 "8764c588eb14b7ba7c168ad16b424942")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/validation.fasl"
   :FASL-MD5 "a163a6236547fba9917907e8b8daaaf7")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/types.fasl"
   :FASL-MD5 "840a35e75d7c56de5259df1a9bdfe282")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/relocate.fasl"
   :FASL-MD5 "7922bcd0d2ebc7f37d93822a8c62487a")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "d61083fcd7fa324a6935057daab505bd")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "1b3d0b31a991ce7914df5e19502efb24")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "848f63563a35a94170b8da797b1689dc")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "7661fe3c84c52d13aa68c201ae6bd989")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/read.fasl"
   :FASL-MD5 "7911c547bb1538f42da9934521abe306")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "3f132bdaf9526915c0fc90f7aefd5768")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "b10136d1549f64c5d43155214f320fba")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "9e704c2445d22d1fc20e55f367281681")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "b1f10a5dc26344ab0946fae3aab87712")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "a78cf3bec5030290e2e3c7694e1058aa")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "aca8f5e71c77529a13290a165c18c293")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "88ada9a56397fc929c89f47a03a02013")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "3a10741abbe93aa21b3409868d6de111")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "ce6e02c58bca75bf7ee8e644d95f1f88")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "92f8927fbc3aebc2ad87a1c33ae67185")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/package.fasl"
   :FASL-MD5 "6a46a4aafdd8c2ede1b56059d9924390")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "d3746976dd462732191edda7d71bfc68")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "51d6b4938e97523ea675e696e31703de")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/core.fasl"
   :FASL-MD5 "a31371bfe546a3ad9250b403635f0cd9")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/package.fasl"
   :FASL-MD5 "ed51588c3d2d5261b6b4ce4a0bde5732")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "5dce45efcdf9c48ac20d8d8c38ef6828")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "0b3d5f77858c5a3368203813ead1f101")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "1999bddaad39fb86962210b081d14ea0")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/types.fasl"
   :FASL-MD5 "64852ae41f7a6dfd1c90390729e5d966")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/target.fasl"
   :FASL-MD5 "f0cdc8f1e84d564b1232148bae447e28")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/segment.fasl"
   :FASL-MD5 "aa0a85bba2801278457f18425067f024")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/package.fasl"
   :FASL-MD5 "9c7fc7044282595a35c755c13e1e4011")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/lookup.fasl"
   :FASL-MD5 "1ee78d632afebb2bbac272c1e4da9d42")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "da2c615450f5968fb7b2c8004f2ea594")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/build.fasl"
   :FASL-MD5 "8e05da6c433aaabd60aec9cee81875bd")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "0aab3f9d6572c3ce5de472e609d33af5")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "51732e8dc41910afcef2544aaa7601db")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "a0d263a77c1d0cbc0bc530d20a7abfb8")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "1ad763779a1f9cf2358a267f55d2bb8d")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "21a4517c9ba3a3b82805c431b06fbe44")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "74280b471c8620ab1d207fa89d02665b")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "e7c23ecb5db7446237c2065bd6514685")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "9dc158445d7dfe597579f6d8d2dd1e96")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "876c922e8fa969e914e8c88bcebc495e")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "96f146f885377c6d102c0af49f05bfae" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "7c5784a8c7f24fc6e2c405c7c1ffbd81")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "af70f466ba1ededd746591c7f5cdcd1d")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "575654e91dee9cf35618acd4c390c23e")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "6c71e6ba032ece295e6265e2315d0b69")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "2057eaa5313cf9fb6b3fa03a4d865270")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "aca1a5cfb39d030e7251fd5f3240319c")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "2b8193aab6801de19e26fa55e7c53f87" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "ec528d2ce1415607f20db5e9f8ff5909")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "0d69e9bb1293f2413ba1a475d8e5909b")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "18565a3a9d3b4367d3dd738d2adc04aa")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "d01f68754aa49d9b7638eec1216e7bb6")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/record.fasl"
   :FASL-MD5 "1c54d37898e7263ec2ed68a548ffff01")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/package.fasl"
   :FASL-MD5 "9d5b6b4644aa6630cf909dcc21f3db40")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "743fa2feffc8662d196e4b456a906230")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "c0a28ee7ff438603be30485f34924fbd")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "f4b3dc86d3454a27da8f4d7f102c08b8")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "4f69dced33d2d9cc982dbd5a44058aff")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/writer.fasl"
   :FASL-MD5 "5089a8a535b6f99f5f340ba7cf1c94de")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "d29f993117089578b951bbf6e04c0f6e")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "ad036005b171e6d69c85c1eabca54f5f")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "0a6e4a544d27eeae09322d248d749583")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "5a3c8ea324744bce490ce440f521b679")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/ready.fasl"
   :FASL-MD5 "a2d0ed812b94161c98ac262be76ccf06")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "d2661fc2be2085c171aaf9f70399fed2")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "4d1e80a185ef7a25b2efb58fe8fff1a4")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/queue.fasl"
   :FASL-MD5 "6726ab9606456a5d71653f7262024d0c")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/package.fasl"
   :FASL-MD5 "350c5ca053d940062b2d0f3e6b472316")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "157ebe1bc70dc95232846c2261159f67")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/types.fasl"
   :FASL-MD5 "bc93a543aab0e99083907c9c8fa02a60")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "35d658922e8c1676a2e51d9b6aae1343")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "a93b94a0ef5379622095bbec642551be")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/read.fasl"
   :FASL-MD5 "da5115bf30ec47025739442a663f2848")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/package.fasl"
   :FASL-MD5 "8f8f6410810de1febb7c67303ba5c81d")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/core.fasl"
   :FASL-MD5 "80352c94d69eb5c8e0923c2bda1ddc2d")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/csn/registry.fasl"
   :FASL-MD5 "3db57eb55375a776c5e566ac3d8f64dc")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/csn/package.fasl"
   :FASL-MD5 "596240705a8b1a82c2efdd268eea66b6")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "38606f8dd0da0db0a32fb0dedcfeed31")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/package.fasl"
   :FASL-MD5 "6cc5190171eaeab42f3dcb15194e181e")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "b895067e7538880416491c8dcb5c7ed5")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "be0289f55e734a153eaa5ec41c5fcbba")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "ab205904651867caf8f6a5aec4111426")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "5eb8d3f407ac2ca5b37a38e0a76f62f5")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "683c5a90f805384279d17774d899ba83")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "801b778ebee17ccea6df1b2949ec8b93")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "e4f0cb567f8522cbd759d5535c821087")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "9393d67fc71b5e486e6c3424113db905")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "e2590a49031874e07ca26200cb96e8f9")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "b01835311d9dc13f387aa63612af0ef7")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "d13c3fb20f71336342a87819fab99dcc")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "cfe852e7844f51d27282ebe10732f2b4")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "47b27a59ea6721adfb99077332b42031")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/write.fasl"
   :FASL-MD5 "7e9fc88efe4e76913d284be0fa5a7dbb")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/types.fasl"
   :FASL-MD5 "053747b0a97bb4325a2a3cb666744c2d")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/read.fasl"
   :FASL-MD5 "e8166134e8378392e0fe9f8d173b5404")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/package.fasl"
   :FASL-MD5 "688b6387d05ae45b21c59be9f220b7dc")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/core.fasl"
   :FASL-MD5 "a8baaca610f2a380fe259ff22cd44ebe")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/clock.fasl"
   :FASL-MD5 "f1ff3a478903848734eaa2054e098d02")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/build.fasl"
   :FASL-MD5 "6d05c2e0361a7e338603305d3dc73a06"))
 :EXPECTED-TESTS
 ("TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
 :FAILURE-KIND :ASSERTION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "e8571ddf559a7a9b6d291de4fdf50717")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "2b8193aab6801de19e26fa55e7c53f87")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "96f146f885377c6d102c0af49f05bfae")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "23a9e837d437b705ca7bd826fa755f89")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
