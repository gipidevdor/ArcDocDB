(:FINISHED-AT-UNIVERSAL-TIME 4000906982 :CONDITION-TYPE "INVARIANT-VIOLATION"
 :DIAGNOSTIC "ArcDocDB: DIRECTORY-LOCATION-ABSENT" :SCHEMA-VERSION 1 :KIND
 :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE :TESTS :COMPILED T
 :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "23a9e837d437b705ca7bd826fa755f89" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "7fda8a03cb9db201b6ae684c85abc784")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "078258c2577300d789eee77f6785c9fe")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "9e63d142759453beca9be65ab436ced5")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "0362c9532fdb44a50f4b5e6f1527c98d")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "6a4a9e28f20df1a8b269fdb96b0e8d38")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "c13839a26f59c52397861693df96c9e7")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "a75724858c59bcf4fa707e6fc54eb558")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/types.fasl"
   :FASL-MD5 "4b9b9035f75b06fd536a75ca3f00ddc4")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/package.fasl"
   :FASL-MD5 "a06e1960f79af188453b335258f50874")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/group.fasl"
   :FASL-MD5 "558383874579aa80c99297f155eb9669")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/executor.fasl"
   :FASL-MD5 "f066ee8a42e4ac6cc0daebb1df9b5a7d")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/csn.fasl"
   :FASL-MD5 "8d2cd39b51d51a63b0fb150e8e1c8fde")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/builder.fasl"
   :FASL-MD5 "9e1f42b54774c7579e26c0aa999769aa")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "ba0e9a29cafd494134e6f5c77f886215")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "d203c4ad44a1fc5128665fad17899d76")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "bda9bef849b83d563d0428175ac4c818")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/package.fasl"
   :FASL-MD5 "6662c1118c63d55e4839989292b9ca81")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "5fdbd5cca4c6570352dd6399e309907f")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/formats.fasl"
   :FASL-MD5 "71ee0bf5fa1657a7b1c13df6e791cafd")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "f3fb5daeaabe1a64ba58cb4a44045ff6")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "54553693577d7ab67f6a5687fc868a61")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "d9ccd25d6cc7256d8bbb9069351c1d10")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "4695a1378dfd05e7843235033ff2108e")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "bad01e4b8f1fde32c0c6d47a366e830d")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "f21a00f46ead004826fc544de2d0d79d")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/types.fasl"
   :FASL-MD5 "a9dff2228385a97fc57e85bd6b43df2b")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "83fe64423b5974d63c4e28a3733ee711")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "07db70610be3d5ef0a7cd1b3147603dd")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "3fe74bb7ce3f411bb67ffefb8e150861")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/retirement.fasl"
   :FASL-MD5 "e15f3b0a05e687fd0f2048e42b78f26b")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/query.fasl"
   :FASL-MD5 "6f1f81fc32040dc9ece3dd702bc57b38")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/publication.fasl"
   :FASL-MD5 "7ebfa9ed9f2ff40660e828e3de17fc1c")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/package.fasl"
   :FASL-MD5 "d6105cd05d4a17f2d4b9fbba4a865c64")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/ownership.fasl"
   :FASL-MD5 "0b7c0f1bb7f27eef93ec5cc8c8dfd2af")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/io-events.fasl"
   :FASL-MD5 "fadfcb341830ec8cc03d4880d9a43394")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/events.fasl"
   :FASL-MD5 "b8e63cdb5708f73a43483205ac73b9a2")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "5a76935843908a463e67bc32ec1211a4")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/package.fasl"
   :FASL-MD5 "b9e667817acdf434aa0faa2f3c38c29d")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "82ddd11e70a3f671ccac857ebc91f501")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "74016d6f41a074ab1bc7fa06d54027bf")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "5285b08f85307d83f28bd5dc192b0382")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "b7e72b7e8fc28b3d71f8425d18eb1934")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "ad0354eac75cf1d9a8ca763a0213533f")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "3f833a6f348bb69145128aee48becc93")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "fd2165cd588d8ea1e5930e0d75063e67")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "e0739f268d8509c450acbeefa4d99186")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "fb299dee7dfe0395510fbdcd4dfceedd")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "fb762106a156b9a92e548de67cff7581")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "15af180610c0547de7c8a0fa14b7f6b1")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "982d546f806466ad24617075ba21192b")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "28d4c17b0e37f5c1d4bbc9286f83c61f")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "8f3658e83b826e5494596ebdbafe8fd8")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "c9af36b63c67478ae29b7de0428409de")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/types.fasl"
   :FASL-MD5 "1a5bc33659332f57ba6e73f1e845bccb")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/task.fasl"
   :FASL-MD5 "f8ec955081ad3f1b6daa609a002f5e5a")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/package.fasl"
   :FASL-MD5 "ddd4115d30b4c3855039e499164c380e")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/core.fasl"
   :FASL-MD5 "0c675852958ffec295994fc0b3905242")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/package.fasl"
   :FASL-MD5 "910678e9a717b476b62495b3f9f95b8d")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "e2dd8c113531b8607e9415bc921e6a39")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "d956202598958c3c2ef909dff22cec55")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "16bd401d48a9056217042b1b003336a6")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "7bb29e1f594449ce5bc176110b935dde")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "20721afb3693c4a13025b7db28c3d15e")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "ab1544541c6696d02fc6a5df9e741aa5")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "d0751a49f9fe2101db2f4043e0ffa7fd")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "8db0a286e49cff5275b8670c1f41bebd")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/types.fasl"
   :FASL-MD5 "f7f3556f2abf0e67329dac3f2b60471d")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/transfer.fasl"
   :FASL-MD5 "0fdea8765834b04aa42007ba1ab2b80e")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/package.fasl"
   :FASL-MD5 "45bd9dce3b138343b2cda9f048fe2200")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/native.fasl"
   :FASL-MD5 "4b5ae9762a5e5529f343ea5c27d570d6")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "2059b467a1ec0fc5d1ed070aae5e221f")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/identity.fasl"
   :FASL-MD5 "5cacea0d4e44310aebb02220fdb8d5f6")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "c956b71618b1ce047bba9ac82ccb14e3")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/flush.fasl"
   :FASL-MD5 "1e9f82da05d67a0293a708186be8da2c")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/write.fasl"
   :FASL-MD5 "8f809f7215dd37ec2946453a83313379")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/validation.fasl"
   :FASL-MD5 "db8e4a8d1f85884946825ece5ca072c8")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/types.fasl"
   :FASL-MD5 "cfd3c2f75481e6672ff875d0bec6908f")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/relocate.fasl"
   :FASL-MD5 "c7e63425fd0579e9bb61a0960bf21b8d")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "8c9955fa41d1eccd14da9bd4c399d0f5")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "8a4bdba5979a9115d702dd3cbb7bc88c")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "c0f28e0a995856508873bb48025146e6")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "735a1b86db1367b4cb6ad047274ed280")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/read.fasl"
   :FASL-MD5 "07807cf19db7dac03943a81c473089bc")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "6bc77092742c9b21bc91286539f8ee2d")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "e9379376b0cd3a2c63d210cd95ff79f8")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "c965edd4041ba9ea8f5b34f384b0a456")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "ed04f3b0f21763396f40ba0e21c8e4db")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "7913b853f918c59da38ab356a0728045")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "00f01c0e26a3052349ab85ff240618da")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "376c3920d1f92e8e465bd1ad9c5b9a6f")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "1c65597c1c8b30ff8018d571d65e5a91")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "0296b0b44453c4639c39149152627c90")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "42b4cddbd415209567add960d2e47bdb")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/package.fasl"
   :FASL-MD5 "433d7eb83eca488648196cb7551a40cd")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "4be1917ee68a87d9c4839c94350bc036")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "6c57ebbb816ed44029e3bb2aecd05189")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/core.fasl"
   :FASL-MD5 "5dcfec3727b614e855ea6535cd2d4ba3")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/package.fasl"
   :FASL-MD5 "504d4ead4480b6f075617a08e4b6cad2")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "75ba3a4ad46171c812a0783e37ab483f")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "8bf4e99cd41890b113eec157b1808d5f")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "f0c66e2c333f179264217ca25c048647")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/types.fasl"
   :FASL-MD5 "ba49d78f3a94bc3ace86e63b8f1d6a8d")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/target.fasl"
   :FASL-MD5 "d45b04a57ab35eecb4c9e5f605339e95")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/segment.fasl"
   :FASL-MD5 "982325af5c805dbf308dfea6c65907c4")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/package.fasl"
   :FASL-MD5 "082b376048d6e3379604d4c09ebac43e")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/lookup.fasl"
   :FASL-MD5 "9a0960a03f53adc5f5d1671e3c3f391b")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "fac291bc348c6fc7213bdab40566370e")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/build.fasl"
   :FASL-MD5 "edba223cfbcfeb1d0016ef4cb9e65d53")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "81057619b556dca8e472e7dddd1c6bc9")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "8085ce53458b0546b8bdab72290645f2")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "9ecc417a5bf422416155069abe0baeea")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "cb81a4f1a5aef233948ce25c19cc950e")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "688b121a81a144f352c2068613c97708")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "0a2c92f5b0c1db52c31918f07e73db77")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "a3ad94b9d832e5d0fb1ffaa97d9a8e88")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "50ec9b3d81d01af9faa48e6154757928")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "b8017971cffd32f601987db39b3f8ab6")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "521737861e057d663964b0c030552587" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "6235e5695e39391f060b5dfdbbd3108e")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "bac3e81f7829d1a12b5333ddab270deb")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "d391a4ce27e96077108bcf4f1b229827")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "5a6dab85d1921da0d5aed847f9c2efe6")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "160428927ee68df352b984d369a07c5e")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "13ce52132e2e7b53c16e03cbaa201c30")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "db44405bae8b58b9bb6519429dc016a8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "00b5d18b4f43a34b50c4f28d208a3c58")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "f197d2d6311324c658007fd47fcfecc0")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "745d869d02d1dd5348a7ca678699019a")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "6f3709e7638ffab6d8891ab6d456c523")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/record.fasl"
   :FASL-MD5 "2a4c5a61645efaf75fd5d5934cdab809")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/package.fasl"
   :FASL-MD5 "4fc9fc9eed7bbebcdb522ca92b9f48dc")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "641a7fced4331493d32066a05d247575")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "cc65b496fafb983c8cc3b088ff8f83d8")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "77b40133347dc7239f2d9d26d144778e")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "a2bfe38c85f37f6e717f07819e323341")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/writer.fasl"
   :FASL-MD5 "743a77b9ee55c0621895ad86cf21f4d8")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "d21a932108e8bf9f73c1ede21a7d0fcc")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "56729dade33972492b8ec0f73b37d172")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "88b35d4ae994acba078fbd3e5afc4aab")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "7a40cf876f9a4d79ccd0a7de7dda8bda")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/ready.fasl"
   :FASL-MD5 "558efda6f7f98fd67308aadb23aedf2d")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "ae15c5a3c47bd2c3dc2952b6946e8228")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "5459ec7710cdf1b99b323a05f2cb7864")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/queue.fasl"
   :FASL-MD5 "78fa7afb8c9fbc2f9ba1068d50a8db57")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/package.fasl"
   :FASL-MD5 "5ebfa88e255ec433c18acb316fe89474")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "359dc50450f4dfb7a3bea4da9d52811e")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/types.fasl"
   :FASL-MD5 "11b6d830ca1b4c3c6799818a32e91ed2")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "30b5ebd33fa758c3e53090aa257fa819")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "c7c1a1642ed0fe318d36db8b40cb540f")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/read.fasl"
   :FASL-MD5 "4bb05edef0ec26edcfdac23d6954dd93")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/package.fasl"
   :FASL-MD5 "bd5b30f124da12f3eb414cf8de6b0558")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/core.fasl"
   :FASL-MD5 "6b5eb738e2b31f21c44383e3c8c61950")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/csn/registry.fasl"
   :FASL-MD5 "6b7adb59594d17014e9f253fb735c5aa")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/csn/package.fasl"
   :FASL-MD5 "80c391908026619f0e9ca7d84d1df4ae")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "a0e64d67b28d67b03d6e8c6244fac43a")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/package.fasl"
   :FASL-MD5 "61cf85f8d4f3316b11c793fcb3ea5d54")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "1014ee3049fa259ee6610d16a99ff3f4")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "bbc978818f47fe269067fc4470b9c721")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "dc6272944f90f8754bf632032a97aef0")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "90df0032d54a8ccee83a5b7ba7aa3884")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "6c871a080fd79e0f58de11918b607d55")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "aee257d275e327fc6b55a216a91c0cf5")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "3f0e102956bdc628d3796795b42e4b60")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "1506af4f06aa7ad2ae6697cd752632b2")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "b2fae1be12d24afc5c814d32c6861051")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "aaf278c53b20ea80f28fd7362fcde067")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "9bc09c3069307fab077908fccf0ce7dd")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "5bbe2980bb8ffd20a429e2677f05d363")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "8236a3073bfbef141039b8cfc9b6fb0c")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/write.fasl"
   :FASL-MD5 "f55208a02e2c965cff6a78357d3863e9")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/types.fasl"
   :FASL-MD5 "a49506a3c37eb38208c62dbcd0e625fb")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/read.fasl"
   :FASL-MD5 "c97e52299c0cdd5c06368e2560beb53f")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/package.fasl"
   :FASL-MD5 "bf95c2e72108479b8fdf7a5bca61c356")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/core.fasl"
   :FASL-MD5 "86dff9fa45d07e8f4b51a975fd3189d4")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/clock.fasl"
   :FASL-MD5 "e6cd210fcc057bad4bf83fc756101720")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-e/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/build.fasl"
   :FASL-MD5 "b487774bc4abf2eec5a1cae2ee2a3a53"))
 :EXPECTED-TESTS ("TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED" :FAILURE-KIND
 :PRODUCT-CONDITION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "e8571ddf559a7a9b6d291de4fdf50717")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "db44405bae8b58b9bb6519429dc016a8")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "23a9e837d437b705ca7bd826fa755f89")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
