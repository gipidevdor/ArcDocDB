(:FINISHED-AT-UNIVERSAL-TIME 4000907619 :CONDITION-TYPE "SIMPLE-ERROR"
 :DIAGNOSTIC "Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-OPERATION
                       ARCDOCDB.GET.DIRECTORY.TESTS::OPERATION
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-CONTEXT
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE)
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-FIXTURE-CONTROLLER
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVARIANT-VIOLATION (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :SOURCES-ACTIVE-DUPLICATE)))"
 :SCHEMA-VERSION 1 :KIND :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE
 :TESTS :COMPILED T :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "3e565b431b88fb5211023601b5e3ce3b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "555d94659d089f9d815153eee2f4f0f8")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "152a7bda3635aed8d06472cf3500e343")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "6b089437eb60bdadaef4824a405644ca")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "485d3293c9dc4f9b15cea593e7c7c7ba")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "7c5c639933a634e5239cd8aaa274971b")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "b5ae4467a2100777903861b03aa2472b")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "1424a6505270daea7e3533a5782a41e1")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/types.fasl"
   :FASL-MD5 "23dfd94a9ed17d3d6233e3d3818aae59")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/package.fasl"
   :FASL-MD5 "a0372122c157e7397e4757c398fbf726")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/group.fasl"
   :FASL-MD5 "8253c71c606bbb2c6f9678332a08fbba")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/executor.fasl"
   :FASL-MD5 "1621d392c86bce1ffff1cd1f6593395d")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/csn.fasl"
   :FASL-MD5 "aef322b5f52eb81d8c55fd0725c1aa82")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/builder.fasl"
   :FASL-MD5 "52e985c267551fc591c0cf791ead1a01")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "b032527259c9454420a2b4f45f374535")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "16112a3f542c2ed71f53528a041a21b2")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "33422f579e7c152048ecdf22b641e311")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/package.fasl"
   :FASL-MD5 "9325d9b52f01b7d20624b5a33c94c5ec")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "4b4762deea5390e2d8307022c30fa911")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/formats.fasl"
   :FASL-MD5 "a6914ff5d2e9e992cd193183be90988b")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "598aaedea718a4479f0b2bbc907be2e9")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "919b9694e97d2f3d4d9ebba5e67ffea5")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "774e0cf5786a834915902a493aa2933e")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "600e927504952a610b20fbd1775221f9")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "3b0cd7573a844d41c8ad0078600193d2")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "9e457c5631d41a06d28eb31a277f547d")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/types.fasl"
   :FASL-MD5 "711fc263bf59e89d2bb9450be24927f4")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "ce8cdc592cab6eb7fd44b764fb17ef8b")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "35a9cf327192aa5d11f9c4a563f461c6")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "623fb2d9d5a4526ca949a2f67c0ff979")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/retirement.fasl"
   :FASL-MD5 "bcc1450b3107080cdd1264c81de6981a")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/query.fasl"
   :FASL-MD5 "fbbb43d0e08823d2b6db847458acc308")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/publication.fasl"
   :FASL-MD5 "6df583500dcbd9369ca5e9a1da0a1a0f")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/package.fasl"
   :FASL-MD5 "bd2525d51a33d55eb3b302a8b7a20138")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/ownership.fasl"
   :FASL-MD5 "73a41bc0fad0f658acbc14bb97268468")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/io-events.fasl"
   :FASL-MD5 "f6b296dcca8dcb7c05e5f76375399145")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/events.fasl"
   :FASL-MD5 "8f935fcfe3eb44f06c23daa275bfd959")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "fea60d866d906097e82f79dc281e1e8e")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/package.fasl"
   :FASL-MD5 "4aa2465199a1cabdc3e8f4b16ddc0566")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "0706b292e25e4c4dc39b0ce1a3b5e0d6")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "7cf9fe867daaf7ce02fe68e8cb046522")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "5f719c08d709a54b8ea9216f35029b74")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "0d83d3bdad74b067c4d674c1aab2b684")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "3c41629fed4f34af4edbd13f0fe1c809")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "1f18bd58d58be31baa0a4a7422243e64")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "f22f6df9aeb9a7c56c8a90299a16b7b9")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "efaf299f640c3a7076ff80e4c3de2cce")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "79f081f62452f535668d64419a7ad4d0")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "347f341ecc40837084b26ef5cd9c67a1")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "76ef3943b292f73b9224049045169ef1")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "383112b0df75d2175f2848298e1d6b2f")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "873bfc21ec3c16e2db5ddef66daa03d6")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "a15e2301e5d16b6b8be9aaf55cbac254")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "1c4a4a8ea528bb4d4280b7beb517e4e1")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/types.fasl"
   :FASL-MD5 "187ad8dee743149744f3f5b5853814a6")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/task.fasl"
   :FASL-MD5 "3557bc41a8675a2da53a2947c884dfb6")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/package.fasl"
   :FASL-MD5 "81d13f681067c74a85bd0f40b6b01303")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/core.fasl"
   :FASL-MD5 "a76f2fbffd4f3f7411cf5dbd18a110c8")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/package.fasl"
   :FASL-MD5 "9bcb0ea2c1fed71ff2d0c5b81d1f2811")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "be0515dab2f78ff526dc31d94c4de0d0")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "3fa0f2e940e95685ded869179d81e8bd")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "a87196f5c4667332b46ee081319d0380")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "3fbd1fcd18df3a965cea436cfa90530b")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "947ae6c31952a2d7728949df0abf4170")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "476d110ffce40e756d2fc0dba7306dc6")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "27e8bb8673112ee7ffd3beb04426c953")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "a2f4456014c6a00359ee83a51eabd8ea")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/types.fasl"
   :FASL-MD5 "6ce6509654bca5a086c8da71376c915e")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/transfer.fasl"
   :FASL-MD5 "9a4dff59109281ac37b267db5db9d3f7")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/package.fasl"
   :FASL-MD5 "73dc5c379b896c1409fcf88885ffd45a")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/native.fasl"
   :FASL-MD5 "e6b71b310dd3333c553f97ba821ea555")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "ad966005d8da635257b56e3187823216")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/identity.fasl"
   :FASL-MD5 "d48ccdbe8cd7d89c3a7412df536459a2")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "ffb6aa370e719430df8b885f35397d66")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/flush.fasl"
   :FASL-MD5 "47e9af78b6165b430a244a58fd2494e2")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/write.fasl"
   :FASL-MD5 "e3dcfcb1be8b9c6654d89888057c1de6")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/validation.fasl"
   :FASL-MD5 "bf6b91ba3c2c36534db18233f7811c34")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/types.fasl"
   :FASL-MD5 "70f46bcffde8831fd48012d32dd71fa0")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/relocate.fasl"
   :FASL-MD5 "6b1a789acc172e6f2d3f02e1cdfb84d4")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "ac3e0308b26aaedc4b94a232a505e2cc")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "61bb5850a4551fe2f0265f6e04e4ce55")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "d0a5921ba04704e7c7379bb09efaaecf")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "62053c9045be25b2f360e177afdb8730")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/read.fasl"
   :FASL-MD5 "46bffbe763396dd24c53aa73eb075b4f")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "9241b5f39e81959a55b77c85b59e3faf")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "28b4a0658e4c408cdc80d6572ba63024")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "059bd7000348b2b9aaa449568548ef7b")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "eeb529fd4149d2be3da43f4b7100692b")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "4fc08d2a78a3dbaeeda29cb9ebf14ccf")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "6c4e846b3bbf4ea9d58a5dd315ad8419")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "8697bd8f879eea4557e1d127e30974c7")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "1f92f4ddf1601bbd6b792ca307545f6b")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "58b940e07bd21e765e6db9804b90ebef")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "d23065b3198e2f7fc946f966b47d25c6")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/package.fasl"
   :FASL-MD5 "36a984cabc7b9ef8a17f78c53b8c50d9")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "449a2cf53ad9140183c8b7c72a1f43d5")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "b42e77f44a03878bd1066c494e926d6f")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/core.fasl"
   :FASL-MD5 "aef2e7f6bad4aab985c7a364721f058e")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/package.fasl"
   :FASL-MD5 "0c0fc20e8c1ae2749b5b2dc2596a5cae")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "fe4fbbf366c8714c87acfcf19eada07d")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "0fb98c60a2c703e0a777d04f81cb063e")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "26d1470480f91ad712ca235c8a5316e3")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/types.fasl"
   :FASL-MD5 "ebade5c45df88b7ad5490e87d27694cc")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/target.fasl"
   :FASL-MD5 "2cfb0bc05b190278bdb5b75cee11f00b")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/segment.fasl"
   :FASL-MD5 "eb1d9f4837c51e01cfbb13c1b777b788")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/package.fasl"
   :FASL-MD5 "85143a808c410e4fb4a35b7d0dd23ec0")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/lookup.fasl"
   :FASL-MD5 "5b1fc8b81dbda07de12648b9584300b8")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "8c3d5e9f6ccd90178793cee4ec4d613b")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/build.fasl"
   :FASL-MD5 "2d2448a6d1a13b87fdc729c6698867f7")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "2fd71c6fe2a54aabe710bb5eae8b4e5c")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "37e476bd20f9d3db72cc56fe1244921b")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "56ad6072812da2cde9b36154da84c8d0")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "6baa9ac6eec4070e9b1a3e539b68fdef")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "aa38a08c52dae96c02330e35fcfd8015")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "12039943303d449351d949ebca438dae")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "e964cc6b84ca8cf0d0638d1700c4fc3b")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "4b6bbc8ba245ef031c371d0820c61956")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "343174a82bcd72d6a294829042b7b222")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "521737861e057d663964b0c030552587" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "13e3289cf85e66c3d2d9f72a863f506f")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "82037eff48c5c8cd2bd1e93ea1b30a79")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "2ed56c81b64b92615bc14f6882704fde")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "88656ceffcd3261559bd60c15eccb1c4")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "af2d80234ce5b46073197010d8d83420")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "3ba1df437229b9eea125dd56f58fc817")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "f308c6780bdb4e3839a67eb57e0bbcba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "7cf3f52787ca04dbaed323b2af764af0")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "23368a82a9fc2b1264c095c83b8db44f")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "bc38ca15b6cd9d8541e35c5faa5e2ac1")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "298887b886f77873f51590061153c228")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/record.fasl"
   :FASL-MD5 "d6d5c3042a1764bd2478d57a0e3f4383")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/package.fasl"
   :FASL-MD5 "e2455b1394250ae1fad628b91307195d")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "9bbe546fa944777c8e7accced88c7ec4")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "481e00f1f9959331ecefaca20f3b980c")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "9d83a386459be2f43ee88d5fa34dc80e")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "d28c49eda9ef5ba9cbde5fb5766489d8")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/writer.fasl"
   :FASL-MD5 "70149c8f4bff5394da8ac8f9b3dfd50a")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "2067cacbe2b5bab2e7e2ca80ade50b70")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "9e7c5e3206c4415bc29087611295e90c")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "4f78542dd3051d95eca9d642ee0a637a")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "dc252b0e1f38a12815702bc5c0e7302b")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/ready.fasl"
   :FASL-MD5 "7af17b0a0dc710163abfde58bc133d94")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "dc9ad25415b28f2e7ae517b9c3f316ab")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "ddd0641cb1996b073bb168cae62c978e")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/queue.fasl"
   :FASL-MD5 "5920dbaaef332631167698f4af022214")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/package.fasl"
   :FASL-MD5 "a7477b7990f2090f190b3027b892805d")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "605074e9460b686a4d87b132182b75af")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/types.fasl"
   :FASL-MD5 "7864dcd546cf1d9ff97db9cce86463a6")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "59bd976ea3055cc51e6273e69013e329")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "908b8c169596053c8ee81ac4ef41f69b")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/read.fasl"
   :FASL-MD5 "80d1285d91d5d39094101002082875f4")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/package.fasl"
   :FASL-MD5 "044fe21b2cafdf0befd7db67e27a82e4")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/core.fasl"
   :FASL-MD5 "014776f392c515ba8a6450e776422121")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/csn/registry.fasl"
   :FASL-MD5 "74f21237964977802e9fb2f2dab124dd")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/csn/package.fasl"
   :FASL-MD5 "f8b9cbb063a3c54deffc6d1c7178b3d2")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "c28a3235b85fc29a2a4fa26c1a9cef25")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/package.fasl"
   :FASL-MD5 "3976e62f58f1f6afe378361ec67a673e")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "8be1cc96d091bae843c4cd8bbf2b12e6")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "6f375889c8512b6f5d73683761f3aeef")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "08d3794783444d782f860de5fe0b42e3")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "fa7bbdae401efaee587a9e1792eee087")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "010ef55b5b5f7a2d285a08bb631f111b")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "c6574ca2d2e15dc7002cbfcb1022b82d")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "51c3407e9dd5dc190a4cdec45f7fea85")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "3e8b142a167d3801474fa88f7c886c62")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "add7b1d1acbbc0bb32402bfc915dbbd7")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "68a5dfac008584925f350e6cae5b2902")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "b21fa56d67fc6cc6b508daaf56be5a2e")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "c8dcce1b59796bf848654914ccdbf722")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "8cdba11d69732422354cbe8777df26a6")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/write.fasl"
   :FASL-MD5 "50acdac9822e3f71571de72c5fb80337")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/types.fasl"
   :FASL-MD5 "8750a4b25403ecb4e41c84ff9bb5907e")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/read.fasl"
   :FASL-MD5 "7d00000a75da3c2e06b62642736331f1")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/package.fasl"
   :FASL-MD5 "594c5be9f67daa425bc9303dcf0ca9d5")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/core.fasl"
   :FASL-MD5 "63a79ce13b69d78188bcd87921afec73")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/clock.fasl"
   :FASL-MD5 "bb08cd859b1d206d3ef5cfb52fad7d6e")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/build.fasl"
   :FASL-MD5 "f13548c483fb6274666e5a3ca34984ce"))
 :EXPECTED-TESTS
 ("TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED" :FAILURE-KIND
 :ASSERTION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "e8571ddf559a7a9b6d291de4fdf50717")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "f308c6780bdb4e3839a67eb57e0bbcba")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
