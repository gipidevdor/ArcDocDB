(:FINISHED-AT-UNIVERSAL-TIME 4000907630 :CONDITION-TYPE "SIMPLE-ERROR"
 :DIAGNOSTIC "Asserzione fallita: (EQUAL
                     (LIST
                      (ARCDOCDB.GET.RESOLVER::SORGENTE-GET-ATTIVA-SEGMENT
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-FIXTURE-SOURCE
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      176 0 NIL)
                     (MULTIPLE-VALUE-LIST
                      (ARCDOCDB.GET.RESOLVER:RISOLVI-CANDIDATO-RADICE-ATTIVA-GET
                       ARCDOCDB.GET.DIRECTORY.TESTS::CONTEXT
                       ARCDOCDB.GET.DIRECTORY.TESTS::CAPTURED)))"
 :SCHEMA-VERSION 1 :KIND :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE
 :TESTS :COMPILED T :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "3e565b431b88fb5211023601b5e3ce3b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "8264f36ab8753a393d071b191ba71968")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "f6e80f103560cc2759087f6ab1adc49c")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "436fc793dcc7ed57f282356f0ddcf87b")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "3c3ec8441006f8c7a158e5e3ad8cbdab")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "140acbe2efe9a074a1bd68b82a73067a")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "da1dba26715ef13ab17923f28b5d14d7")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "4e96d24a874ab9c490b742f7ac36dff6")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/types.fasl"
   :FASL-MD5 "328eabe775f9cbe43e95855b5ea4556e")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/package.fasl"
   :FASL-MD5 "a36cffea1dfe56785f3b62834b7ea5cd")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/group.fasl"
   :FASL-MD5 "f69fa5d67da66c2ff639c1b3f18a5460")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/executor.fasl"
   :FASL-MD5 "92675585593ade970a971166f54ee956")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/csn.fasl"
   :FASL-MD5 "532dce3f9995b4c549756712f399b630")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/builder.fasl"
   :FASL-MD5 "d0dbbd7f32ad46cfdbac8390278af768")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "408a59ca747fa27b58f2af9e43844e54")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "5573dd39436a4ccdbfcfd7b5986d0305")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "e503c348132ad22e499d534b043b543d")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/package.fasl"
   :FASL-MD5 "c80df62316658f0d002ffc0ba1f7cd5e")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "4a7456d5229878597a673ad87d9b9571")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/formats.fasl"
   :FASL-MD5 "fff7351e37870a3891a0ffe885677948")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "4f74c94a14a5ce9368cc3e8dfa2fe6b5")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "8bec4242ea2cc1f529b38352b8853975")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "0602fb7067e3a0ae5fa1277c7c3a19c4")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "53609ca5edb5539ca2f482ceae90b4cf")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "3135f03e9a5295e4d996c22938e079d1")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "bf2834f59d8bd38087e4c6af58d98cd7")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/types.fasl"
   :FASL-MD5 "75f8dcf3de72aa5ffc6be0848558712c")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "a3534ba0a78fef473c09b1105b435c85")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "2ce1ab138df5b336ceb9bb061bd3334e")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "b61187c208cd635c83e6762f5c592b8c")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/retirement.fasl"
   :FASL-MD5 "56c6e0bf4f5eaf52ea7e7057a8d8395d")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/query.fasl"
   :FASL-MD5 "24416c6f14ff7d476151619127b98f26")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/publication.fasl"
   :FASL-MD5 "5169c9d652d7fbb6ce89fa44a6499b60")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/package.fasl"
   :FASL-MD5 "0fa40413fdeca5e5b96095879d608744")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/ownership.fasl"
   :FASL-MD5 "5d1ba4bd5a7faa86fde97795ff7e8016")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/io-events.fasl"
   :FASL-MD5 "64c6da104f50543fa6120ad32848e16d")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/events.fasl"
   :FASL-MD5 "cf12a7162bc89371328e8631004ec652")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "3ee0245013f51930bc1666811b862ba9")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/package.fasl"
   :FASL-MD5 "fda09325239c0dae17706a8182a1b479")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "4945fd68ea4ca971b220b093ad898820")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "1a1cd45339e63206507abc0962f01d92")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "a77351dc2b687b6573ec43c42f79a17a")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "7327a59302321a4b806eeb6f80c49d48")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "93e9eae342eb7502ce661c0a7cff2a0a")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "66e1bdfb03517097fff1fcea0d5b25ed")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "701695cdcb96d0df0026b79004b11b7b")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "c8e63bf8c304140ead86bfed3b6d418b")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "301550f58f07b77d593c6d1bc5640083")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "6300d27bbd9812b50f4b7af9db58aefd")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "95b89abbf2fb0d234ad06cd171c62f7e")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "c1c7b74b65dbf9c4ca40fc041847a29c")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "5d27c98a54e997ae5d2ce83a8ee3cdaa")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "5e7cc9e46d0d4a28782af5db91dadd26")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "e75b5e6fc98a1cf62dfa5d3005c56310")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/types.fasl"
   :FASL-MD5 "59a4d585dde1900d06a454b25df7940f")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/task.fasl"
   :FASL-MD5 "3a965fbe507d51247fe37338fd9fa1c7")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/package.fasl"
   :FASL-MD5 "dad8622db377d2f5a4424228812352b0")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/core.fasl"
   :FASL-MD5 "4aa8ffe421f33e8be648577aeed6c1b7")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/package.fasl"
   :FASL-MD5 "b9c9c24c7c6cf5ca9a7aa92b22c52464")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "d9be0451b453fae94cec2ea878cdfbd6")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "cf89f490930fccb4f14e0ec2ac5b8d41")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "e8050d9d1196cc8ac229738435b22af4")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "5602a20bfc22ab995e2231f38eae2eab")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "cdde959f3256a9da1acbfa10a68bb6c0")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "834cff85721782773c8251d8ada337c5")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "70e3f62d0529e67d2e5ad4fcef2648b9")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "dbf2e3819257f34c93acf4cc526cd567")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/types.fasl"
   :FASL-MD5 "87afdfff9d50dfb126185bbd7ca65dc7")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/transfer.fasl"
   :FASL-MD5 "a3c31eafca709e3c8f1f6084d72d9ef5")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/package.fasl"
   :FASL-MD5 "a5f5943cd412e533e690faa4328e1d54")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/native.fasl"
   :FASL-MD5 "67b98bfc8aa898c69a5ad94d9b7f242b")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "3092b0bd729d59d2b19f9c19933187cb")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/identity.fasl"
   :FASL-MD5 "358a85f57d761e71130e9817b330f6c8")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "ec2a081cc2a6532ec0d177aa551cf962")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/flush.fasl"
   :FASL-MD5 "0df543f6485acf67b4fd7ad2dda3664e")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/write.fasl"
   :FASL-MD5 "10452e17655528b8b4d482d756200b35")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/validation.fasl"
   :FASL-MD5 "70927fa36ac0766b3997f3bf74271ca6")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/types.fasl"
   :FASL-MD5 "c0eb437a42ff06b608f62b0fbbd112cc")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/relocate.fasl"
   :FASL-MD5 "1454b7edea1a6c96aa3c6ccf5c587f8e")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "0a97c85b99d02f66b682a3a953d64b97")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "3210ef8624bb1bcf327ab5a154a613aa")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "341e6b14cc7b5c6f83cd43f2ff17a7c1")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "8dabb742ba575097c0b073df243e464c")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/read.fasl"
   :FASL-MD5 "1fcf27ddaf121133e808dc93cffb2161")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "5006cbb57f6eb348165b86a33daccaec")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "e383fb2dbc32a10dcf49e013a84f1d6f")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "001f2c104fd219d5a71be088a6e4daa7")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "6c25bb01404083c8487786b977b3fded")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "2527023d4ed259d2e720d5f13750d39a")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "69356e869fecb52ed048a4395580028b")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "792be43ae5da688fad5367ef6b416e73")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "4b17b18f21a11fbfd3a6ed4822b32fc9")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "f07dca9cadc84d947beacf374b78193a")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "a9e3f8e9f8337ee1ee94293cc1b7208d")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/package.fasl"
   :FASL-MD5 "9b5fa513f841e22dd164c71e1d99d430")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "0c3d48b03d9e6b786ae68d5d0bee44db")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "2b7bc3d72466ec5e0bf4476ae7f4d140")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/core.fasl"
   :FASL-MD5 "99ffc919c7e3d655365689ffe5ade06e")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/package.fasl"
   :FASL-MD5 "8a2341b9dc4341ef91f07f504ac121d3")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "19d627e4d9b59219d621f7095dbd8859")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "4fdeb0a8a2ae94771eb614f1bf9263ac")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "676a7b362cd22cc065afdd3ad0422649")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/types.fasl"
   :FASL-MD5 "1bce726da3cacc2d2701869f54fa94d9")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/target.fasl"
   :FASL-MD5 "54ece7f47ed274d9da2c2793f221f6da")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/segment.fasl"
   :FASL-MD5 "3e7c919f95d02a32b883387fee05b9f4")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/package.fasl"
   :FASL-MD5 "9aee5a220b0b972d510668e8a5a4f433")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/lookup.fasl"
   :FASL-MD5 "643643d5acd668ccd71644deaad3b33e")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "8840c9205e59daa413068eccfd5f4c4a")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/build.fasl"
   :FASL-MD5 "44274776a232493585000c838f6ef6ba")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "227775a1d0a1943681beb3044ad9b750")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "4cc5cdae6496c81e477b335d5100120f")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "c2fdeee2469acf5449f19d88745e096b")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "e78c116007c1f217aed74bcbd5f3b5bd")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "6016a992519b8e56faa6f17bd73af67f")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "1c073558035a6e849c3d088f0e80679d")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "fedf1282f210d28e7dbf2438fb0017af")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "425d0f4f1afe4da2ac7e1f944d8134e5")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "26e24f77c6f7dab81c59f21c9cb7c159")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "96f146f885377c6d102c0af49f05bfae" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "b893137e627cbdfc3bb5d2ea3412fef2")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "3eef6e15facd3eac3e4b65361592ba70")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "7c4eacc6a6d826ba2c0ac314ab3d2f15")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "d8b36e9026f34d24ca7f11102c24194c")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "320f866079d0ab7e26054967dad5ac5a")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "02463f86e027478db4766ec8c2063c3e")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "2b8193aab6801de19e26fa55e7c53f87" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "a6ed93836551b285a4174124b375684b")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "bf6435d942276298d8a034880b960998")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "b1c4d0e65199868f606836c68465fbf8")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "a05267d58b71ffd93003997ead95ae69")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/record.fasl"
   :FASL-MD5 "9d91a8b6ca077945d149c7f46d9df216")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/package.fasl"
   :FASL-MD5 "4a9a56a8c07f456492da744e59f43f89")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "0127ed0dc1229ca424eaa586f03a98a0")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "8436cebbc4a9e8c41c5256ce8818ac08")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "26a8434a3263603c2ba557e37e60082f")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "4efd03ecb7b341b2aa72925cacd5f4ae")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/writer.fasl"
   :FASL-MD5 "8f5b4cd136d1546cea9acaa979e5af46")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "2963ccd1e591f61ed5d10ac1cf7bcb95")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "3dd7721f8c87725aa8226faa107e221f")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "4e30563781a0c27ae4dbd0c7b36b4f0e")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "70fbc21f01672750efdcebc60025acd3")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/ready.fasl"
   :FASL-MD5 "cfe104fb20f1b9e48876e1823e21dded")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "09c9ba7eae1be738d71428bef27be0da")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "a0796a9c0bcfe1e658cd4a1566e415d7")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/queue.fasl"
   :FASL-MD5 "d18bf38f30484e54df65f246ea991312")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/package.fasl"
   :FASL-MD5 "77582a975989a2f5f5ba626d21326f80")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "c8ddf572554d1becebe61d8c5ea0fc33")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/types.fasl"
   :FASL-MD5 "94d839eee90a2d37b7a56ca0e3ab1c43")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "acf54f465c9894057f1ddd38506e802c")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "cea5abf9b76a45a844528cde740f068e")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/read.fasl"
   :FASL-MD5 "37f3efe467d384609fd6c9e0f14b5819")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/package.fasl"
   :FASL-MD5 "a49d9e6b97b4e64dfce23959714fd944")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/core.fasl"
   :FASL-MD5 "7500dc10bed63d92033875d903a29909")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/csn/registry.fasl"
   :FASL-MD5 "81c9eed8f0efec3bd0c2647d6ad86cab")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/csn/package.fasl"
   :FASL-MD5 "cc11a9d6a29becbbf9d7b23effacfa31")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "a1cc9592833e768009377728077096ee")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/package.fasl"
   :FASL-MD5 "0d9b133d1c3883e073df7fef0998bd34")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "927db904e5946c7516121de2539d58e4")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "b28c777d3ed480899265d87b88e5f596")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "1d99b5c630e309b648656d45915ba1a3")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "626f12e99760cc865960b03fe673897f")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "6023c685fa2338fffa8c8f1cfa8c40f7")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "4f37e8395075b0ff72d2083a1f1dfbda")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "4becdd6c6edd1326200a7283eaa1bfcc")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "055fdda7b6cd39476337a2ce7efa2110")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "d1a6dbb749c44ec7efb68e47b99ad0c9")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "a50d9baa94d4c0d80101dd5040b4ebb3")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "41888f0d3cd4371e4750668d163399e1")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "fdca9898bbde2ab02302524adc450545")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "e84e2bc31614855a0fb5b50d83a12f62")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/write.fasl"
   :FASL-MD5 "e88d3d3d6ac0daac0ee91fa89c3d885c")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/types.fasl"
   :FASL-MD5 "35c2d56089c929b1ef586127aae22947")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/read.fasl"
   :FASL-MD5 "98f8e1329be4bdd65697068091b98e98")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/package.fasl"
   :FASL-MD5 "38c08c3d461b32ff2b511db5f4d93873")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/core.fasl"
   :FASL-MD5 "c95423d773cecde8bc7b0e18dbe969e0")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/clock.fasl"
   :FASL-MD5 "295244b217fa2d3646e905534302ec36")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/build.fasl"
   :FASL-MD5 "c067d8b3ad8748ad0c32dfc098c944c5"))
 :EXPECTED-TESTS
 ("TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
 :FAILURE-KIND :ASSERTION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "e8571ddf559a7a9b6d291de4fdf50717")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "2b8193aab6801de19e26fa55e7c53f87")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "96f146f885377c6d102c0af49f05bfae")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
