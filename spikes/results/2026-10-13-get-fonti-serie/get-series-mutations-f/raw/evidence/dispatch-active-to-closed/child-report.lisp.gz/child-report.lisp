(:FINISHED-AT-UNIVERSAL-TIME 4000907624 :CONDITION-TYPE "INVARIANT-VIOLATION"
 :DIAGNOSTIC "ArcDocDB: DIRECTORY-LOCATION-ABSENT" :SCHEMA-VERSION 1 :KIND
 :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE :TESTS :COMPILED T
 :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "3e565b431b88fb5211023601b5e3ce3b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "008430b38d6742de7908dd6f75ddf274")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "49853d204097d583a6d727428bbe01be")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "832933b89b973db3fa147fe64f4603c1")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "fee6f976d96d97a95357bc57e22f5acb")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "89f9fb13887779244d06b29b97a2fe10")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "11c1b87d347662923ee5ba31c21ce8c5")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "723645a2b7db47544fabaf25267e09e4")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/types.fasl"
   :FASL-MD5 "6fabb89f1bce650ee917c4c6b26d5fce")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/package.fasl"
   :FASL-MD5 "6f1889cce8a3ff927ec9c399654fb252")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/group.fasl"
   :FASL-MD5 "80f5bccef621156082aa8920d3d41d90")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/executor.fasl"
   :FASL-MD5 "155f7707ba93c0790d95508b05d65110")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/csn.fasl"
   :FASL-MD5 "cea8a7306328fcefce056550abd96a17")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/builder.fasl"
   :FASL-MD5 "45714ecf257d7655e8d411c03ad536b9")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "94f0781b2fcb977fd03293662a743647")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "3d013530289ae4ca58419f19eb05ac00")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "8c6efa92a680c2a91c1e9d0dd78a4813")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/package.fasl"
   :FASL-MD5 "5febef02fb62370a0888a84e1b09090d")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "9714cd21a321f69184180becd85c7478")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/formats.fasl"
   :FASL-MD5 "c178dafd9f039a21307de7e20e514021")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "6a7c8e09636b5b3d7a2c3fa6204f3de4")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "33e96048ae9ed6168c9631b3d7563ef9")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "4972b0335195236c94a4c6a52ef56cc2")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "db313a8def7ef00944c95cdfa579d1a3")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "fbe4e105bc975f4686e042ff2e47258a")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "d811b83b65c09bc4beb13be988074f6a")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/types.fasl"
   :FASL-MD5 "a5e759597ea316792c5d69ddb9f78766")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "2ea42da8a98bc1a8a8c5ed540c05fa6a")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "312ab33c98c77a115764b5aeda482ed6")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "f0d80f5ab45bbd85d3551ee2780b7e91")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/retirement.fasl"
   :FASL-MD5 "ca42efe82c8a9c28e267a9d449dd5e0d")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/query.fasl"
   :FASL-MD5 "feda88c2078bcd5c3818e484899f3473")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/publication.fasl"
   :FASL-MD5 "1ae54d326322d1d7e6caa1bd93140a52")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/package.fasl"
   :FASL-MD5 "3c909aa4da83b48435a910413c3b585f")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/ownership.fasl"
   :FASL-MD5 "4ff15883bc0f347e0d089b3d05cc9442")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/io-events.fasl"
   :FASL-MD5 "15f028be5971babafc5ea51f3865f15f")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/events.fasl"
   :FASL-MD5 "6668c536426130149affbef3a2641c34")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "7d1333eb59bb95f34dd1c792f4c373e4")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/package.fasl"
   :FASL-MD5 "b01a4033556c6d836c3d03bfd8be0211")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "91fd7e71a7da84e3118017ebe83ad901")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "c3786d6723474bc1d1c43735c4e61a25")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "0699a47e8b74bde08e389afcecd800e8")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "a1409f83115e60cfbc97659834de36ea")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "52e3a92e85c7a7de245d649fd874bcdf")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "464ee0b716416f0225b1fb82c2020b51")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "6394ec347cc5c6e7bbf56c734eaee50b")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "3ae3e88a3a5ac81b74d614c286756416")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "b6f330d5f19ced06eddf55ebf684c36c")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "58366b0c022eb69c95faecdee7f49037")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "a838cadf6de9c2ec3f45149695febee6")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "616e68d70b58d6eb233e503953171f65")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "8bea6747ed92980f2774e119b02abe63")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "6e0398677a22d68dfd5cceecd4a35acd")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "f7ac4dda17ee632d21568cdb86417a5c")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/types.fasl"
   :FASL-MD5 "a2103a55b70c02c7fe2ae3cabf8c9359")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/task.fasl"
   :FASL-MD5 "ed0fbb5707fc13eb622a6fecda445c7d")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/package.fasl"
   :FASL-MD5 "7e49339f6b8e16abb7072f90ee0930db")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/core.fasl"
   :FASL-MD5 "15f24bf114212c38a2cafeaad2c0e222")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/package.fasl"
   :FASL-MD5 "f9ee9d9fa1c62bab0b057d3aa4361daf")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "036355c9a6baec2aa653924e56e472ff")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "07034a11c218e19e42f7a61f713d3541")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "5d0b4c6d61797828433cbdf93c7e2848")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "8147cc221276925d1b8d026940352af6")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "39f3220f5ca20b1b6866f83101d94ac6")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "361c20826fdea24905196b98ed6e2e52")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "45976fc56cd41aa9fed8a06f43d81f7e")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "b533feb17023f53e8465aeecdefd32b5")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/types.fasl"
   :FASL-MD5 "903d408c640969f848f54af28837bc27")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/transfer.fasl"
   :FASL-MD5 "97930c43a27e621add76a5ab88970278")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/package.fasl"
   :FASL-MD5 "3a99dae0fc2d00603d03ef7ec63afd4d")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/native.fasl"
   :FASL-MD5 "31326e5cd205661087b623b096b1bf8b")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "99e401ad6e69952b020322a28a86082c")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/identity.fasl"
   :FASL-MD5 "be57f3a46ac1d9e3f5640efa0c71bd1e")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "9b369aec533d0479212c4543efa12cb6")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/flush.fasl"
   :FASL-MD5 "69991ceece673b5991d554e1f0a2d7ce")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/write.fasl"
   :FASL-MD5 "4e56e0e7eda594c65c66256e7747e446")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/validation.fasl"
   :FASL-MD5 "d9ba3e4d49efea41e4d1f08a4373f612")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/types.fasl"
   :FASL-MD5 "dbac1e2415207e7b13a3f5d550ecb35a")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/relocate.fasl"
   :FASL-MD5 "6a9f064fd93e9ac54d0a25ac94de0fae")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "302a977de2132efec3e125025187c9ef")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "93bd63e630164cdb5c5224fb0dbcdfe2")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "49711575c769d27615bae1de26a983be")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "43a68cc96eb546c80a744ddd700bc7bf")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/read.fasl"
   :FASL-MD5 "3e8829995c2078db920b986a3ba014a5")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "a29115e756fa6a4c07ece058b8a841c1")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "98ee13f04f22a41129eaf31004bce9a9")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "954b2842770c4d4093a8e45b438db7c1")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "bcbdb72e05fa0d9923363559761567d9")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "ec4732198604d04f21b7ebe15bae0dae")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "b8168799e62b4ba11b42f04626cd8ff9")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "debdb338c2e37db92a02c331a69b675c")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "b2eddb5139465822179e82ee515b4bbf")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "1006de4b326ece94cb55deab45e985d7")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "6b6e53ee5a644e6e5c56c713535dcf66")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/package.fasl"
   :FASL-MD5 "b88bb3bc8f64e18856d2675ee827b5b8")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "c8794327757c8ab3d39eb1167680768a")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "6c7c39ee20a9f0b126a8abc625a4e96f")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/core.fasl"
   :FASL-MD5 "4b28ed7bcc7abbce0b4a2a2b0d2cea64")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/package.fasl"
   :FASL-MD5 "970487b5f22fef2ddb5e0d4101d0143b")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "c7981a65017b52adaa169c46efd49321")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "a9849132732dc7cbbd5453d4b93fc05c")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "3608c2ba15e9e300dda874c5413f5df0")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/types.fasl"
   :FASL-MD5 "23668e9ae30c1fc751645ccefb797765")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/target.fasl"
   :FASL-MD5 "5c852f3d72f012e3e7395fcdb99bfe46")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/segment.fasl"
   :FASL-MD5 "34e47c78892c82665add483ea3cd9c0d")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/package.fasl"
   :FASL-MD5 "d4475b795d1832306cdc35ba8b9a63fc")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/lookup.fasl"
   :FASL-MD5 "8dc61bf4b7ef3e2180581275f95683e2")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "8dddad260997538ceb55c75b954aed42")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/build.fasl"
   :FASL-MD5 "c67267665bf7ec2b50ec3e947bc1e2cc")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "4f97d761e4eacd9592edb83b3b48c72a")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "b6f91c3cc0acb767dd605c6370ac8384")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "e275110790e53281e0b6ea0aa7e064a9")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "ff7d940fd55c50ab436c9ccc942370ae")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "f814dd12c8931f28a07ac3a7e93b53b8")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "046677d175b7daf43c7f65b5f7a91030")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "3f00bc920a087f04a3bdcada68900f07")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "34381f2aefcba43bb1a4fc4eccaa6540")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "82d949e8d0275790823b7467ae4d7883")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "521737861e057d663964b0c030552587" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "29d326f646ee32d5ee44856530153d29")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "8ae41e1aec42332ac0959ae62b4f76a7")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "fddd076d3b20a1fb28a0f099be27ab02")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "7785cff2d9d18ee9d2b4d322766058cd")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "0d50d1c163d22e3a6908494dafb80ed9")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "e00167d972591713e769a5656c1cf698")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "db44405bae8b58b9bb6519429dc016a8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "335be73d0ce78c2f6d9856f5f5f9157d")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "161033baf879bc8ecfd512c5cec677ef")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "85726888d178f2b339c5bb55274cdb58")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "2bd3c003233c0f1122459647f6758e1e")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/record.fasl"
   :FASL-MD5 "eb766f9119b43d2d9a7369576da81864")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/package.fasl"
   :FASL-MD5 "9a2b06e6c99f24bd9fbc24b8138afa98")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "a20186e77f0e5ce6b4c49205d9957523")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "23ad339065626fc9cfc6abe02eb0529e")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "0d4fdddbd122e09b5fe888f5f24edb87")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "872594cccb2c47d8e63f8f4eef69047e")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/writer.fasl"
   :FASL-MD5 "0aa755207293383088a7bca710d3d22d")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "e47a780bc612d2d81998c2a9a0bad739")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "c630d660786022e22ebd596d573d5bc8")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "9ffbe146a596b0a9d0151e3e0faae1c9")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "81a7e726efe6d10e784d40a85b203096")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/ready.fasl"
   :FASL-MD5 "b742bc1a34f39cb7a3e3ecd5b5554144")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "0b7d3474a693dd333419f9c273a5e153")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "50fdccc06254c8ff685dbd24b2edcd3c")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/queue.fasl"
   :FASL-MD5 "656ec8140116bd3c6d610b2a0a94f32f")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/package.fasl"
   :FASL-MD5 "76d6d218823219123e5ff54d003aaeeb")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "0c04ab0f564f9dff237d8b0b6b073b21")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/types.fasl"
   :FASL-MD5 "4809793a9c9a13ae4e2fd0dda0aa7145")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "9d8eaad147f51f25d1a5d8282321f197")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "f77155083d8fc4aa8cd799e9675a4eac")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/read.fasl"
   :FASL-MD5 "f81247f4222f1d33dd6ab4ab816ac4bc")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/package.fasl"
   :FASL-MD5 "66f15d669bf44af06c6f52d8fde7bd27")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/core.fasl"
   :FASL-MD5 "01c6846f5c8e102092a1f27b7bbcfb4f")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/csn/registry.fasl"
   :FASL-MD5 "c9a82eedc8534a87e90f7538856f9e1c")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/csn/package.fasl"
   :FASL-MD5 "777f2def3f433d57f883b07759cc3f0b")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "3a8c745cf6c2e51592efe2a5a2c89399")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/package.fasl"
   :FASL-MD5 "3d892f3a93e120bea41572a4c0c5b225")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "3f593cb58dfbf3b7ed9b5fecb53fc2cc")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "43a864ca400deebebb4f97f23cbcaa08")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "c9366db7ec912a574bbf8bf70d837f5b")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "b51e0ab7bb430d75a79c955074772fa0")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "2633d6fc698d55ff80323a26f5978a52")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "c37e423b50e5696ae3af065ad11d2d02")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "840564682c261f9d99b682c5306c056c")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "b020d638dc187530851df5003a1c2a48")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "488233ab22c8b501ffb9fdd5d2ef71ac")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "b385793831ce46785c07d1d6fe1bbd66")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "3d376b153f9fd9bf3788994e48bf0b81")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "e25830b52355df35059f7e3638fdb4a0")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "8075b2db215a731c9e4b635f31e89be5")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/write.fasl"
   :FASL-MD5 "606d04578c1c1b99e201b398780ccade")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/types.fasl"
   :FASL-MD5 "bc809d23c40acea31a46031c77eaa8d2")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/read.fasl"
   :FASL-MD5 "f8121759a7769893cee324ab425f6068")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/package.fasl"
   :FASL-MD5 "e8d62840adf01c383f45e903ce758eed")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/core.fasl"
   :FASL-MD5 "4a9ab00478f69e56eafd7ee2aab85421")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/clock.fasl"
   :FASL-MD5 "ed3c5b7b5fd9581ad84acbd6f620b56d")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/build.fasl"
   :FASL-MD5 "6c37853502946a022a164eddbd901785"))
 :EXPECTED-TESTS ("TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED" :FAILURE-KIND
 :PRODUCT-CONDITION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "e8571ddf559a7a9b6d291de4fdf50717")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "db44405bae8b58b9bb6519429dc016a8")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
