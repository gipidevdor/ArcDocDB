(:FINISHED-AT-UNIVERSAL-TIME 4000907613 :CONDITION-TYPE "INVARIANT-VIOLATION"
 :DIAGNOSTIC "ArcDocDB: DIRECTORY-LOCATION-ABSENT" :SCHEMA-VERSION 1 :KIND
 :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE :TESTS :COMPILED T
 :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "3e565b431b88fb5211023601b5e3ce3b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "d81e9803b068f7a7c470770a2fec841f")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "d43aad9a173abc232a348f11ce223669")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "7c23a05d2105acb4e8ec70cf8a2056ad")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "b36f955070b3378f738f8e9c6bc0b6ac")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "9d833c43662861b44eb0b95e17cd8153")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "fd904d29b7f0ee28c999388a4ba8e5cd")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "54a3bf753b340108716f6ac84421f85b")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/types.fasl"
   :FASL-MD5 "9283c1c3ac7893721029c4148ce5d77d")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/package.fasl"
   :FASL-MD5 "86d0f9a932ecae031e63349c8a370580")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/group.fasl"
   :FASL-MD5 "d21173781cc5ecb2655180657cfe3642")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/executor.fasl"
   :FASL-MD5 "e7006391987e1f47d9f15e85617e8e95")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/csn.fasl"
   :FASL-MD5 "e7bb86f0e3908803be80ddb71981b4dc")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/builder.fasl"
   :FASL-MD5 "f08b37839af689f21ef9209d18e41285")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "bd496e2b76213eccdd7d0d6e5f439218")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "dd456bf906e07e3fdd354cf090f3a881")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "8642ab022ed0c7481e8e67342b7dcb27")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/package.fasl"
   :FASL-MD5 "011804f3861d303108e6adc2dcd817cd")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "283e8756cc39075958c37f69c0e544d1")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/formats.fasl"
   :FASL-MD5 "48ffa79f034430276c0690bdf22cfb35")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "e1de4609dcbdb452296d050ecff4415e")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "ca4cbd2c9772700a660eb446a2acb7af")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "9ca1354db51a43b7d0d179a59a42ace0")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "16d060f8517a0c370c2db1ee73f73ab6")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "a176fb654afa74d2581bdba40e85994d")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "14fb7d093aac0a6edf996b170c77b915")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/types.fasl"
   :FASL-MD5 "ecbdbab72b97d3d168eca89439b28d29")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "9b1d1c39235811c679ae15d0385675d1")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "15b872b29c8ee61c44f6fbb5b263a351")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "36ff78dc0da5f3e4a02d2c8a5e668496")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/retirement.fasl"
   :FASL-MD5 "c1919bde02c6723a6413717c8c9b0d23")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/query.fasl"
   :FASL-MD5 "d76f95b5784fcc7de60d67686c9211c4")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/publication.fasl"
   :FASL-MD5 "2a6a8349527d52d7fed087156c3aacba")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/package.fasl"
   :FASL-MD5 "e8a1f251b70702644937860c35d56ea1")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/ownership.fasl"
   :FASL-MD5 "04663f7cd85ec4a2e11919e1b310315c")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/io-events.fasl"
   :FASL-MD5 "a9726fb969b5c9c5e6fa3ddb5430fc19")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/events.fasl"
   :FASL-MD5 "10b1afa323810f9886712ff2cd702617")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "c68f951541666263419c06619a3b93d9")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/package.fasl"
   :FASL-MD5 "3858445289c7b04daf96ce9e56f21a81")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "c2215fe1bf6c40a9283508f2f2889242")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "8cba225b0f8d9bbff0365ac4064cc1a6")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "795b602be72c7c2f0f73111643d5e61c")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "89210ef11c07452b03a4f6a95ff684ba")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "592747ff453e4afa6444259fc49c90cd")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "0d482bf658c7ce4a2ea3c7b5c9fdcfdb")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "d2172e88b97369bfa907506b4fc051a0")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "bc29386dc9345cb83a65bc78292ce8f0")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "ddb599f8c1ac83c3f994c9a5a2bd4014")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "673597a3b3064e169eb0c4307214fcd0")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "99961c221837867b557d5bbc25e44558")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "6a03c64c8e3e39a2907d9f1a52b5bd12")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "54bdf496ab1792456747da91f41149ca")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "47f8907d8f3f1f98dd853a73702276bc")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "6134ee73eb542f219e7de5f820d2ac32")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/read/types.fasl"
   :FASL-MD5 "a2e250f0177e4346efc71c5e4deff66d")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/read/task.fasl"
   :FASL-MD5 "13a6a5f42742b4f02dabc9432cf8c31a")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/read/package.fasl"
   :FASL-MD5 "53357f1d8b8c3d25133cd6be30947e14")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/read/core.fasl"
   :FASL-MD5 "b4fdc8455d3487474001f323e44ad766")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/package.fasl"
   :FASL-MD5 "299d5437a86bacba82296f2f9636c96a")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "9e7ca86a6ead439a6e373323738d56c5")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "1b075e97df19d3be300e42b1a3b00f5e")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "3e99fe3a204153e18c3a12b3a0d63120")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "180426e2361b8d81c0807281d1748e34")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "38bb3f577b8d0ca9d021f70bfed2766d")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "4bc68347d71e7883361fc5dab8cc4b93")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "450725446429b45b670a6839558e53b0")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "6b613b0875cf11c30fee0dc5579405e8")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/types.fasl"
   :FASL-MD5 "e5d938547f6e681c7dcf799ed90db2a3")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/transfer.fasl"
   :FASL-MD5 "51ccb65c409829884d2f54e473d19965")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/package.fasl"
   :FASL-MD5 "66b192eb075df7b1ca43397dbd56fdea")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/native.fasl"
   :FASL-MD5 "5692e874480c98446231c89b2af5924e")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "0deb67dba664a1e32c27cad6b7205f7c")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/identity.fasl"
   :FASL-MD5 "9ec6264e8ed33675712cf593d98f8470")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "6510986e46e8dd9fb9eefe1d4a1a4ad1")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/flush.fasl"
   :FASL-MD5 "f139db875d33274d325617bb2b20a1ec")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/write.fasl"
   :FASL-MD5 "1d081a8b503c27e8c6dca51f0cfd8dba")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/validation.fasl"
   :FASL-MD5 "d9d9901f87055d0fa6c849c4ea84deea")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/types.fasl"
   :FASL-MD5 "e60fa5095c0fe5354e166b35190328d4")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/relocate.fasl"
   :FASL-MD5 "a1c625e84512489a7cd12c6af69fcfcf")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "2ae5990e1dabbbda8a5223b8202e133f")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "b11a0fbb14a3406f556ce863d65f4b28")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "8be93ab23331316bd97fabd9d8bf9811")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "fd9e6ffa0506e150cbd74b1486f8af40")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/read.fasl"
   :FASL-MD5 "44eed8e527a8b51a52f914c114059e64")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "03930cfe549477d77a7d027d3af88155")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "08cf724c114891bfb1d0c94d8ee40873")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "a2e95a17faf3cfa1071669bda92eea50")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "e237697d5930e35daaf9288ba1c3f9dc")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "22060740f0300e9291997bbf9c437f26")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "41f16ca21e545054f5e30434da693a35")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "39062975de1feb40d26c5ba3d36c0bda")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "de37ac8d6de6efab41a77abfdb92d077")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "f7e53b461cb89d6e9f28d942cebc1383")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "a7af12bd8c04ab23b20af647b4117d38")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/package.fasl"
   :FASL-MD5 "6354aa078a8fccac362dac3067784bb5")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "cdd5ec39271c7bd9082b04318238b7d4")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "edbaca8dfe6c0a3889416c5fbf8d9c6b")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/core.fasl"
   :FASL-MD5 "4c5a84fb6318778f435c335ad9e5d922")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/hash/package.fasl"
   :FASL-MD5 "8f81bcb35672061b4d2690f095cbfca0")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "520c07244780e9968528c1e4e8e1418e")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "43c3a09c55c24dabd1622ecb49f5beb7")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "dd8a0ede5b30f4bb3b7c0f902c71f0c1")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/types.fasl"
   :FASL-MD5 "897172f1f36c08f8710175eacb6ca5dd")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/target.fasl"
   :FASL-MD5 "6a0c63e6e8dcd1468cc503c6686a9a0d")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/segment.fasl"
   :FASL-MD5 "30075c6c3e4511fd9c2dc210d2bcdf85")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/package.fasl"
   :FASL-MD5 "109bcebc58f032280a354c8bc4401fff")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/lookup.fasl"
   :FASL-MD5 "a13c6ebef870e2b1d31a2a23e7de9ef6")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "5e458dbab5148cfcb125042388c13c9b")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/build.fasl"
   :FASL-MD5 "e5aec5483538377874a84ba1d6218d68")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "2e5af51671ca37583dd2e12cf2927ff6")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "07f09452640589eeb2a69ff01f68cd17")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "b25fcfff57f2316e33573e13b4d00ce8")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "c4ded2392e517057831e0dfe200f545c")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "e47053e021161e415bba9c67116f9f0b")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "31c29a4063f6ace4b38076c3f6af115b")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "9384f54e77825a1c3257de07fef8a9bd")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "a7e2d8b3639b7e28f55f0318d0e1de75")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "b00864543190ed4576230d4452f3dee7")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "521737861e057d663964b0c030552587" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "619cc7c72c05965742af803c7c619cd4")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "449731ccf6eced8a0e68dff0b5b75182")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "14045daa174417fb4caf9b5153c5948e")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "3117b5c13d0d1051acf5581af2eb2892")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "3ea8a958d58e4ebc3b4b92e0d89068bf")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "c1d42ce3aa4c918d12c3f90f80791a21")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "fe8a60fc4f720bd864c248b71cb71654" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "01b9dbfb9b18b250793e3219f487803b")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "ddbfdaded4c3042df841740653d9283d")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "285bb5b47217bbcba98d87cce98ccfdd")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "8d13599e9b3a18b5f0b7976fa7e17627")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/record.fasl"
   :FASL-MD5 "44f9aa5578c0fc887779d8b28e314448")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/package.fasl"
   :FASL-MD5 "d135478e2b964337e104d75b47f993e3")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "8196c3ad6479ba85efbb45244062d34d")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "0d1e22be15b98d8de3956270b2510a44")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "50126ad9747fc40c8f1fa1dea6d3457c")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "6d74f279a61e2a057a1390baa456f474")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/writer.fasl"
   :FASL-MD5 "842ca1979ee81e56359a82068575f9e6")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "1ba0fe1fd2db1b684ba45c4ee6a3bb14")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "3f6663e5cad8840558564c8b51b8fd8a")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "6e75eadc4889242193d181b0ce7f938f")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "00f08976f1116fbd6df4bb392f0bb806")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/ready.fasl"
   :FASL-MD5 "e3ca6f903a03c04d894e1481d0cb5d02")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "a8c901cda9469db381a8ea048f1ce302")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "442426e50a2eff0910bb7b597291f951")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/queue.fasl"
   :FASL-MD5 "b2246c3d540bf2cd447536c0604730eb")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/package.fasl"
   :FASL-MD5 "3f079a36902214493b53b45cb7f015aa")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "413ce66abdfc092677e08fb2177ca0ad")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/types.fasl"
   :FASL-MD5 "c17d4f3da84b9c48f62df8621b9f64dd")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "4d9db49ed9293019a15d74f6dda28508")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "37ec66bff400475dda01051f9f0f7169")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/read.fasl"
   :FASL-MD5 "860b41657829d22c39bc1ee9f7b10bef")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/package.fasl"
   :FASL-MD5 "ff376eedde3886d9f05d2ef41f739d38")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/core.fasl"
   :FASL-MD5 "ce1fd2e784364c8aff5cfb82ac6e5b3b")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/csn/registry.fasl"
   :FASL-MD5 "130e3539fb85367e80812c50ab7c492b")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/csn/package.fasl"
   :FASL-MD5 "87fab9f30a6e01b4a559920cc64b52eb")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "4365dbf873480c85c52e15900b2c16f1")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/package.fasl"
   :FASL-MD5 "6b9071a666b06902a0c5466888311e95")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "616f611098ef599bf509ef05da174e30")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "47a743952816cd8d682a2f2ecdc5b15c")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "051675b9ac19b70bfd0e426d2b55cc51")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "17878423e4dc426bbf96af849020d1c7")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "74bab064710606fd882022f4161819e6")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "fe611d46c155b4d76328c64e4af4d3d9")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "6d349e12e289b1c435b2780b6a125dd2")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "a9d585fa0fd4f2d1b2f0a63ca457c0ec")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "5c522df68533d69adffeb04282306577")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "af47d1415f66f119acfaf7aa405babb1")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "bc0f6b807870296d6e67a272c3e222e5")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "a3b1912952478e5ae111eecd29d572f9")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "5c36732f2fd1fb10b981426444d1a025")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/write.fasl"
   :FASL-MD5 "2c2ddeef09d90ead885b4552a603fb7b")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/types.fasl"
   :FASL-MD5 "e24f6762df692d78909a18670c2eacec")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/read.fasl"
   :FASL-MD5 "3a567f0290158f432297927caa218ced")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/package.fasl"
   :FASL-MD5 "d2c2a0cbc70fc0e1d258a7d423b60bfe")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/core.fasl"
   :FASL-MD5 "6d6e27e22dce13b19e5db05c88924713")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/clock.fasl"
   :FASL-MD5 "ad9ab6f3202997acd616620dd3d107c3")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/build.fasl"
   :FASL-MD5 "4080e0097f9fc0cac7443f98e8c46a4d"))
 :EXPECTED-TESTS
 ("TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION"
 :FAILURE-KIND :PRODUCT-CONDITION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "e8571ddf559a7a9b6d291de4fdf50717")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "fe8a60fc4f720bd864c248b71cb71654")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
