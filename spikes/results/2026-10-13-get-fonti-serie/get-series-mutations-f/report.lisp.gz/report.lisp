(:COUNTERS
 (:BASELINE-PASSED 1 :BASELINE-FAILED 0 :DETECTED 4 :SURVIVED 0
  :COMPILATION-ERROR 0 :INFRASTRUCTURE-ERROR 0 :INVALID 0)
 :FINISHED-AT-UNIVERSAL-TIME 4000907630 :FROZEN-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "e8571ddf559a7a9b6d291de4fdf50717")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "2b8193aab6801de19e26fa55e7c53f87")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54"))
 :SCHEMA-VERSION 1 :KIND :GET-SERIES-MUTATIONS :STATUS :OK :ARGV
 ("--check" "spikes/out/get-series-mutations-f/") :STARTED-AT-UNIVERSAL-TIME
 4000907601 :SELF-TEST
 (:STATUS :OK :CLASSIFIER-CASES 24 :ANCHOR-NEGATIVE-CASES 3 :NO-COMPILATION T
  :NO-CHILD T)
 :BASELINE
 (:CHILD-REPORT
  (:FINISHED-AT-UNIVERSAL-TIME 4000907607 :SCHEMA-VERSION 1 :KIND
   :GET-SERIES-MUTATION-CHILD :STATUS :OK :PHASE :COMPLETE :COMPILED T
   :SUITE-COMPILED T :COMPILED-FILES
   ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
     "3e565b431b88fb5211023601b5e3ce3b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/tests/get-directory/series-read.fasl"
     :FASL-MD5 "9306b19ef6716da3b46d9f07682f33e9")
    (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
     "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/tests/get-directory/series-support.fasl"
     :FASL-MD5 "e1702b6ca5f28b2831c7ad7076a5827f")
    (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
     "63dd01c852de1399c2c82274d481d257" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/tests/get-directory/threads.fasl"
     :FASL-MD5 "9ed34906d8720d64f8559c4f5e1f1c45")
    (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
     "d1ab36d05cc1266e4533d27c693f12f4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/tests/get-directory/read.fasl"
     :FASL-MD5 "e0a099611c07a8cdcbf4b579ef522127")
    (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
     "1137938073e71d6d8d62c751fbad05d5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/tests/get-directory/construction.fasl"
     :FASL-MD5 "fda5ea701a0aa9a00e9026c3e81b7e89")
    (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
     "3f868ebe4307ad4238b314c37eceed9a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/tests/get-directory/support.fasl"
     :FASL-MD5 "f205987644e3e6747d33903c6ce851b3")
    (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
     "758adad069aec2f9dbe0635797314ff6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/tests/foundation/support.fasl"
     :FASL-MD5 "c96d95915268e371afdc419e8866db96")
    (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/wal/types.fasl"
     :FASL-MD5 "b220f984b99a211a89b649a7ca04c746")
    (:FILE "src/wal/package.lisp" :SOURCE-MD5
     "96c41b1d417135a24fc65659ea3abe11" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/wal/package.fasl"
     :FASL-MD5 "e9a74cab6cda5659910f2a528671e75c")
    (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/wal/group.fasl"
     :FASL-MD5 "24a1f08975db0eab6e0dc65a77b233a8")
    (:FILE "src/wal/executor.lisp" :SOURCE-MD5
     "c0340924c9130e14d0e8efedeec078f1" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/wal/executor.fasl"
     :FASL-MD5 "225276dd01095dd4f349502066ce3915")
    (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/wal/csn.fasl"
     :FASL-MD5 "7db6bf06714dfb4b986141683f14c783")
    (:FILE "src/wal/builder.lisp" :SOURCE-MD5
     "a229f76f7036f3573a6e528dcd390a19" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/wal/builder.fasl"
     :FASL-MD5 "7d477c58b2b9672db887918da34d51cb")
    (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
     "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/storage/segment-header.fasl"
     :FASL-MD5 "23993811ccba8f46eda3842b0f50094d")
    (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
     "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/storage/payload-write.fasl"
     :FASL-MD5 "5944d1581245506605802ca583cc554f")
    (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
     "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/storage/payload-record.fasl"
     :FASL-MD5 "22b4b92e0678e9850d8647427d8b1c23")
    (:FILE "src/storage/package.lisp" :SOURCE-MD5
     "f86bd104f20616a76b42c02227f72844" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/storage/package.fasl"
     :FASL-MD5 "9774a27494e97fe61aa4a6d175d078be")
    (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
     "b53d27dcc9f4badf18b50519c50bc614" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/storage/log-header.fasl"
     :FASL-MD5 "c00a66faf25b24a172533202456b6945")
    (:FILE "src/storage/formats.lisp" :SOURCE-MD5
     "061147be459d8d3b08c661bd3f91d152" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/storage/formats.fasl"
     :FASL-MD5 "a4a1eb16c69acce9fdd86c18f4769e50")
    (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
     "cb64f806b8d69eb42d865b4abfff0b27" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/storage/control-payload.fasl"
     :FASL-MD5 "894f905d4951c659fa2aed087745ef90")
    (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
     "1cda77a357ab2147035993b72d135a37" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/storage/compaction-scan.fasl"
     :FASL-MD5 "6648c33d331624bd37a88adce84f3577")
    (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
     "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/worker-types.fasl"
     :FASL-MD5 "c740e998e3365d13f2fd7d9b369ccb55")
    (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
     "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/worker-run.fasl"
     :FASL-MD5 "e1055668657a95e56989d90a44f308d6")
    (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
     "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/worker-package.fasl"
     :FASL-MD5 "affec25b11cdea33e530e2c5d12a8ab9")
    (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
     "2340e0c9074f7b1bf80c74f774986bc5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/worker-boundary.fasl"
     :FASL-MD5 "e8f0ab76876b99c42c8712a5f04635fc")
    (:FILE "src/series/types.lisp" :SOURCE-MD5
     "ab19ec8d15af91511e817858c41cebc8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/types.fasl"
     :FASL-MD5 "0a3a8c570e877e8accacb7ef8edeb2c0")
    (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
     "ce649df47dd38888d5103c98345f7e41" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/routing-types.fasl"
     :FASL-MD5 "1cf54f906a3c6dda9c93d2e0a8b54278")
    (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
     "e0f987d8767744050ec4d1b3ecb699ed" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/routing-select.fasl"
     :FASL-MD5 "c34199525fe0e2739bd81ab332401343")
    (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
     "d6924deff152b941bd49f0bb200b4197" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/routing-build.fasl"
     :FASL-MD5 "7d474af4fec12eede8dbee15f4d88bc1")
    (:FILE "src/series/retirement.lisp" :SOURCE-MD5
     "b8e04971b8ad75a1bd0c722997badfd2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/retirement.fasl"
     :FASL-MD5 "73735846564869c75e660163ac3689c3")
    (:FILE "src/series/query.lisp" :SOURCE-MD5
     "cb0d91405325b508e6b2ab24d178de7a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/query.fasl"
     :FASL-MD5 "b16062313931978a3d2b9ac384d914e4")
    (:FILE "src/series/publication.lisp" :SOURCE-MD5
     "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/publication.fasl"
     :FASL-MD5 "51dd851b528cc153bf043d1e24060b4d")
    (:FILE "src/series/package.lisp" :SOURCE-MD5
     "59e3c59c90d8d0fc5731b87496a785aa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/package.fasl"
     :FASL-MD5 "22da75e52c7bf71a52ae7046de41024d")
    (:FILE "src/series/ownership.lisp" :SOURCE-MD5
     "de1aca16a35d34d16aba12ff541c0d2b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/ownership.fasl"
     :FASL-MD5 "9631c8d0b331581af324863838ef474b")
    (:FILE "src/series/io-events.lisp" :SOURCE-MD5
     "b6026a8b7bb64b45c37a65effda70d8e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/io-events.fasl"
     :FASL-MD5 "533a30906511999f50d6bc4ad83968ca")
    (:FILE "src/series/events.lisp" :SOURCE-MD5
     "32b2156739a6f2ca996abb91df0a2603" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/series/events.fasl"
     :FASL-MD5 "b6d6c67ff4d43c00b865a26c4b6c0c01")
    (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
     "fcacd15460db25ea9cc4036065f9f096" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/scan.fasl"
     :FASL-MD5 "e8a30c6740095ded649e97a0730e32bb")
    (:FILE "src/recovery/package.lisp" :SOURCE-MD5
     "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/package.fasl"
     :FASL-MD5 "a98d943c188ceb4b21a4571235b04a69")
    (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
     "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/manifest-types.fasl"
     :FASL-MD5 "ab9010867011dc667651e322bf223f29")
    (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
     "ebd7a54adea2213294a887e6d4db0927" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/manifest-query.fasl"
     :FASL-MD5 "a94d3fc7e029577d83832b759898f42f")
    (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
     "37ace42844c11b52446ee1fc500b8e0b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/manifest-package.fasl"
     :FASL-MD5 "e651f0abf4ea73b060bdbf6d7c1ea802")
    (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
     "e0d2498db1011e857b7b0daa1934f187" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/manifest-fold.fasl"
     :FASL-MD5 "2f5e0b937da2e5bb722615e80effbc3a")
    (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
     "67975249aaabd751757cdfb9222cc3c4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/manifest-decode.fasl"
     :FASL-MD5 "14afb4a4f1ffac89b87ae17b8b403ec5")
    (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
     "bf65b1731eab6e0572461ef5cc60fc40" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/manifest-build.fasl"
     :FASL-MD5 "8b20f525ccd64853de87a9f11726affa")
    (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
     "78c136d5838dcfe3019d9069643a8d8f" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/inventory-types.fasl"
     :FASL-MD5 "6f2e7d6d62dabf2330da7c65dd9514f6")
    (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
     "fcea263de1938767772e5b11411ecd5e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/inventory-query.fasl"
     :FASL-MD5 "e3c6dc148a2b279bd5573564b0be1f62")
    (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
     "9bd6820c4feba3e552aab1a4edd87861" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/inventory-build.fasl"
     :FASL-MD5 "7afb9a2a6413f1afa83c7574e75cfe8f")
    (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
     "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/decisions-types.fasl"
     :FASL-MD5 "bfd377ede7a370b44f670c731afddbbb")
    (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
     "b33e57a643f2fca810846f6226366253" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/decisions-sort.fasl"
     :FASL-MD5 "3647a1ab9700e6eea69fe2b8263cf01c")
    (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
     "852149de4c289b8e067602780378d87a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/decisions-radix.fasl"
     :FASL-MD5 "120593b4c9150066c97a4baad988d305")
    (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
     "f782d1137b8ce342b91c9999cfb7accc" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/decisions-query.fasl"
     :FASL-MD5 "9b2cd0bc7d0c02a8ec603323c66c3096")
    (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
     "cbdc30f93109c474e1fc25066c9b9b13" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/decisions-package.fasl"
     :FASL-MD5 "4f1f64abe8880dc0393863f9bf79823b")
    (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
     "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/recovery/decisions-build.fasl"
     :FASL-MD5 "c6ed711bf5b6bd7bd5eb07d5cd7d950d")
    (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/read/types.fasl"
     :FASL-MD5 "3692bf95999ac57587ecf1212567b354")
    (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/read/task.fasl"
     :FASL-MD5 "ede9907babf197d9bd9040286baaaec5")
    (:FILE "src/read/package.lisp" :SOURCE-MD5
     "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/read/package.fasl"
     :FASL-MD5 "209de4342d2f26a335b9f1b0b049e9c5")
    (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/read/core.fasl"
     :FASL-MD5 "3891009d978504e200212b9c0d7e5278")
    (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/package.fasl"
     :FASL-MD5 "f301b941b3a97f97907c93565e3d621f")
    (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/mvcc/types.fasl"
     :FASL-MD5 "a0ab796f136b4cc368f014ef019b7d4b")
    (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
     "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-types.fasl"
     :FASL-MD5 "6ed6f56c8eb4433c84f9bed82597cec1")
    (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
     "2d5a795bcefd605c75da91c725ae83a2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-register.fasl"
     :FASL-MD5 "4387363339ea1b29386538e62185d9f4")
    (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
     "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-read.fasl"
     :FASL-MD5 "e07080884f84df2b1d4168fce079377d")
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
     "ff98aea5cb9a7ae2671f6a887a003725" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-lifecycle.fasl"
     :FASL-MD5 "0896836a264fc08cdcddf12e1335327c")
    (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
     "0e9365e674d1584b111f915ce1f58634" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-csn.fasl"
     :FASL-MD5 "1ea78985f6ae9dd0a3550c9e3b88a156")
    (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
     "8bb066aab61a18eff175b9edb11e42a2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-core.fasl"
     :FASL-MD5 "6c90aa6cd5f16ccfaa370eb120db0e00")
    (:FILE "src/mvcc/package.lisp" :SOURCE-MD5
     "f188d1dbd5d0adb49f53acf09157aef9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/mvcc/package.fasl"
     :FASL-MD5 "a337acd911e747e1ecad3a452348e662")
    (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/io/types.fasl"
     :FASL-MD5 "0ca4c8684f3b734c20186dde31dc1938")
    (:FILE "src/io/transfer.lisp" :SOURCE-MD5
     "a5e7108e80664eb3b562fbd7e680801f" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/io/transfer.fasl"
     :FASL-MD5 "9fd0648afa2625c96ea48174563841e7")
    (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/io/package.fasl"
     :FASL-MD5 "c496b86e06ec3286d14e4a23385b0297")
    (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/io/native.fasl"
     :FASL-MD5 "2a1970feec004ec0b3e17878d01bf928")
    (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5
     "11c7103efbe733bbf0a13927f23c3d34" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/io/lifecycle.fasl"
     :FASL-MD5 "9b95c7e5f49eef70f67b356ad5cd1e7e")
    (:FILE "src/io/identity.lisp" :SOURCE-MD5
     "06ea105db71f021ea60b2c59645273b4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/io/identity.fasl"
     :FASL-MD5 "c4a2e4e5014163b60918c8d36a97ca43")
    (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
     "d354a095fb378c1b6f27397ffb902227" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/io/identity-types.fasl"
     :FASL-MD5 "d1eeb4333f18639250feba36af2df410")
    (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/io/flush.fasl"
     :FASL-MD5 "7ea956bb77dbd028674258f1cd2cc5dc")
    (:FILE "src/index/write.lisp" :SOURCE-MD5
     "f0c8c579cd7db466d243ed3ea9f8e8aa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/write.fasl"
     :FASL-MD5 "8f6c007ef33b349dc0f4b3c8a874f756")
    (:FILE "src/index/validation.lisp" :SOURCE-MD5
     "3384cadf737c7d80c004222022a281f6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/validation.fasl"
     :FASL-MD5 "6f79fee44054cf7cd26fe4f07de9f39b")
    (:FILE "src/index/types.lisp" :SOURCE-MD5
     "5157fd03ee806ee998ad8f0002d56268" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/types.fasl"
     :FASL-MD5 "cee0ddb709a09ed15e058d85608af100")
    (:FILE "src/index/relocate.lisp" :SOURCE-MD5
     "475dd7d5809a836f01544b447cc8df27" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/relocate.fasl"
     :FASL-MD5 "7a9f842f2d869f7b509a7e692221b216")
    (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
     "a450cac8071513365267e7024cbe94b0" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/rebuild.fasl"
     :FASL-MD5 "feba5471f14c80b7733a94c690c4c5a5")
    (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
     "1188e7a64a7a5d9482c1233cb9acb452" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/rebuild-scan.fasl"
     :FASL-MD5 "3672a7a12e68dee812fb24ac4fbc69d7")
    (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
     "8befbbd00ed5c31c1487a11887eba495" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/rebuild-copy.fasl"
     :FASL-MD5 "6e8cdff039fd8f878f8787c68649ca8e")
    (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
     "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/rebuild-budget.fasl"
     :FASL-MD5 "afa2ad1066f81495ba0627dbe7cef2a6")
    (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/read.fasl"
     :FASL-MD5 "e8c6c42c0d5a3e969edeac76609c22aa")
    (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
     "e8e31e599356e592af29c0cc4604872b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/primary-write.fasl"
     :FASL-MD5 "bfb0c2bf4fe920943a8b82cd98bf9476")
    (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
     "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/primary-types.fasl"
     :FASL-MD5 "73ec42fe5bac929afbadaadc61fb1cf8")
    (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
     "5155959766645d3172ae5e73c58cc071" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/primary-relocate.fasl"
     :FASL-MD5 "a2f6d3e1203b43e397ab9d49ab597c30")
    (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
     "3f317a0d3c5ee86a73651aad36135cc3" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/primary-read.fasl"
     :FASL-MD5 "c6f0e2eae7f638f8072c537acf099355")
    (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
     "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/primary-probe.fasl"
     :FASL-MD5 "32cb423148570f357f406153aa710f5c")
    (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
     "d65cfce399b04f905bf969929962e59a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/primary-package.fasl"
     :FASL-MD5 "686861497adb14b044c0ed2fc00a87c9")
    (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
     "1dd67c527257e43f17e006644ecdbd00" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/primary-directory.fasl"
     :FASL-MD5 "646f87916b5c358322f857beb647e03f")
    (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
     "fa52433eae199ceeb874bf2bc47afca7" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/primary-core.fasl"
     :FASL-MD5 "7251e7ff1aad8f96360934c2b2df3fb0")
    (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
     "ff2cfbb865290d7a1510fdf6877c7229" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/primary-build.fasl"
     :FASL-MD5 "4ba3a393a4388a9eeb14856018cac433")
    (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
     "a319691e3e28b7ea7b927de490cf69ba" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/primary-arena.fasl"
     :FASL-MD5 "5507e10823ec2ddd9e7f61827d02744b")
    (:FILE "src/index/package.lisp" :SOURCE-MD5
     "598a9b65e73151c924b2cdcaf6d96705" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/package.fasl"
     :FASL-MD5 "f3777e73c86fe4f7b1aba9a8abcf4f0c")
    (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
     "45ce41749bc6fa638539815d3f802b96" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/hash-seed.fasl"
     :FASL-MD5 "45ee015cc4c65e1ef9063d9c6848aa79")
    (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
     "43d2209225707352daec6186ef95a805" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/hash-digests.fasl"
     :FASL-MD5 "6f843fd6455175269d564a27a3ff6499")
    (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/index/core.fasl"
     :FASL-MD5 "da738ea2484a9a56708fa32edf79a67e")
    (:FILE "src/hash/package.lisp" :SOURCE-MD5
     "2d9060e41bc5252067d35e59ac70ee06" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/hash/package.fasl"
     :FASL-MD5 "caa80a8dfc8c92ba98fb4b091d3e15f4")
    (:FILE "src/hash/hash64.lisp" :SOURCE-MD5
     "886b7c08b9929283e8968831cbe5c039" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/hash/hash64.fasl"
     :FASL-MD5 "ba262fd005c07813c875840502eee3d8")
    (:FILE "src/hash/blocks.lisp" :SOURCE-MD5
     "bef497b9a267c7306d4100000491c814" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/hash/blocks.fasl"
     :FASL-MD5 "bc1ddc954ae32826731c416f04b1409f")
    (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
     "b5c51802e607e3dd22de68204baf64e9" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/hash/arithmetic.fasl"
     :FASL-MD5 "19ddb31f36ccc990c9c7e8362db764bc")
    (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get/types.fasl"
     :FASL-MD5 "04f4922204dd77c01242e5fb386023b1")
    (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get/target.fasl"
     :FASL-MD5 "4857d1e124a6cd9699022607c1618f6e")
    (:FILE "src/get/segment.lisp" :SOURCE-MD5
     "811869eb6a197d3c4e26af4322e52652" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get/segment.fasl"
     :FASL-MD5 "ca19de5c33dbb82e0460a3ac99b71650")
    (:FILE "src/get/package.lisp" :SOURCE-MD5
     "c72633d15c3488699072eb610ebde7c8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get/package.fasl"
     :FASL-MD5 "d5704b9827663b34db96288e6ddb9fba")
    (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get/lookup.fasl"
     :FASL-MD5 "0405fbaec8453185bb1d97f1a156d1ab")
    (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
     "e70bfeddd694336bbd088e65f8761834" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get/lifecycle.fasl"
     :FASL-MD5 "dda934f926004401c963f3f7a848e3ef")
    (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get/build.fasl"
     :FASL-MD5 "b9dfebf337f25ca7173f6d274f695d83")
    (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
     "9df13bcc6908e9fa601d173a671e1ccf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-resolver/types.fasl"
     :FASL-MD5 "6f096360298e271bb4c1ff2c5014ecb5")
    (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
     "2d869293ba47444c4721713d955c6254" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-resolver/sort.fasl"
     :FASL-MD5 "b5e00f756752cc31553ef572ef57dd17")
    (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
     "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-resolver/scan.fasl"
     :FASL-MD5 "bcd396ec9ae99ab3fe77fc620831e257")
    (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
     "ca9002b81efd0aed9761cd1f78514762" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-resolver/rows.fasl"
     :FASL-MD5 "eb2c7b1bb675052ca543ccff9c831ff6")
    (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
     "1339edff0223dbf122f11ff0adbba61c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-resolver/read.fasl"
     :FASL-MD5 "a8c9be28f5e183947b4d1e4b926a07c0")
    (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
     "6226d131f5562a475048b6444049c4ca" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-resolver/package.fasl"
     :FASL-MD5 "2af7ec229e64a64e21102f07110d02f3")
    (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
     "bbfb2082103e6712419e180ab972245c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-resolver/build.fasl"
     :FASL-MD5 "172f7eeac1ef2ade1b9c835355dc3c70")
    (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
     "bd7182e9871fe82530d0c828e473ccde" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-resolver/active-types.fasl"
     :FASL-MD5 "7f457190f16f94a3c71ae6ac92e2c4b0")
    (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
     "d6aaec49504a96f37c8ff1bc182c977b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-resolver/active-scan.fasl"
     :FASL-MD5 "c90fc2af832d3ea1d1733d555dffce0a")
    (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
     "521737861e057d663964b0c030552587" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-resolver/active-read.fasl"
     :FASL-MD5 "92b218d30761e033e3f7883031edbd12")
    (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
     "f13d422adb6aa9e8489352884137f25a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-resolver/active-preflight.fasl"
     :FASL-MD5 "3a0e3460bf76912a9955e994adc56514")
    (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
     "6d95f29b331d335175843f47ae44a6ea" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-resolver/active-directory.fasl"
     :FASL-MD5 "1fd9d9c9c43d2bcb925ffb029e2f02f6")
    (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
     "c65593cf172f53a8e90a853bbe9504c2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-resolver/active-build.fasl"
     :FASL-MD5 "6e370fb6422e8701c7f6a36833d0d57b")
    (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
     "17c957d6934a31f4ed64313e756de2d2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-directory/types.fasl"
     :FASL-MD5 "3101b56f6722727f1bd6f15e798289e0")
    (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
     "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-directory/sources-types.fasl"
     :FASL-MD5 "73fc2a64ba44c48e06e3db0638b9cfa8")
    (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
     "2b8193aab6801de19e26fa55e7c53f87" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-directory/sources-read.fasl"
     :FASL-MD5 "654062a2d9e0cca0193a1b06390ab05a")
    (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
     "74a694385f1aaf03ec87721545494119" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl"
     :FASL-MD5 "2156c6a477bc9acb7a094022235de2da")
    (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
     "894f6e238fe4047f2bf607fceae86846" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-directory/package.fasl"
     :FASL-MD5 "262787f7db95a2a543c0826306148fc3")
    (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
     "cde24b2bf5c5637d5501b95bed47df31" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/get-directory/build.fasl"
     :FASL-MD5 "5a5f5db5bcb92aac756b58631a28eda7")
    (:FILE "src/foundation/record.lisp" :SOURCE-MD5
     "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/foundation/record.fasl"
     :FASL-MD5 "a22a51b32ddd67e71c5f023ee5e240ed")
    (:FILE "src/foundation/package.lisp" :SOURCE-MD5
     "5ee593a112958d94163dab17c5aa4ba2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/foundation/package.fasl"
     :FASL-MD5 "355a66cf71477eb80f614614314361b1")
    (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
     "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/foundation/crc32c.fasl"
     :FASL-MD5 "a89b51f3de0016958a5ba211c8bcca33")
    (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
     "942b596396c19815290a57830af2121b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/foundation/conditions.fasl"
     :FASL-MD5 "69e1fc25795dbb563446bd87e556e511")
    (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
     "a06115175f450776762761dce25acdb8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/foundation/binary.fasl"
     :FASL-MD5 "61be88f99c7e76467afd93217aba1a79")
    (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
     "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/foundation/batch.fasl"
     :FASL-MD5 "47f70243c31b96446bafafa92f73fc4d")
    (:FILE "src/execution/writer.lisp" :SOURCE-MD5
     "73019644090e2971f2b54dc36e4491f5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/execution/writer.fasl"
     :FASL-MD5 "e156f1c3e5e44ef291b8174b36484222")
    (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
     "0679ee07c46f69db330706303c70d8d2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/execution/worker-types.fasl"
     :FASL-MD5 "b3bf192f7aef56cd0f7cb3232dde08f8")
    (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
     "aa34ca6bc07535e35fea723878d99f66" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/execution/worker-run.fasl"
     :FASL-MD5 "1802bf6b08fa9c055ac4973e7a84ea3d")
    (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
     "babd0a78b4185af24ae1fef870c0fabb" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/execution/worker-claim.fasl"
     :FASL-MD5 "3bd1a742de13571ae3a8a1d63f6e7324")
    (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
     "c24065d6c8d80d1be53994a0041743df" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/execution/worker-boundary.fasl"
     :FASL-MD5 "bd9303e4f2974278875bbe3afc3c5e01")
    (:FILE "src/execution/ready.lisp" :SOURCE-MD5
     "2c1892002f0599bb8273093031017520" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/execution/ready.fasl"
     :FASL-MD5 "79e9db03efa11a35b40b96e50b52353e")
    (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
     "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/execution/ready-types.fasl"
     :FASL-MD5 "4a2a906ebfb585b67c951a69d5dc8d3b")
    (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
     "38d26f8c749dd946dfc4b9c57103a892" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/execution/ready-recycle.fasl"
     :FASL-MD5 "f14f66d56f82dda2de0c5ff1486ab38a")
    (:FILE "src/execution/queue.lisp" :SOURCE-MD5
     "8202843bddb817da4279ac959ae3f3c4" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/execution/queue.fasl"
     :FASL-MD5 "7a9d18ba3612f87bb166c0c0d6c09a0a")
    (:FILE "src/execution/package.lisp" :SOURCE-MD5
     "cb5710d6c111cadb7121a50998a747fa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/execution/package.fasl"
     :FASL-MD5 "2089ca90c3e3728f3bed1e914036e1eb")
    (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
     "6b85eebe69366e78ed5fc5cc20735f00" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/execution/handoff.fasl"
     :FASL-MD5 "9b23e9113af9d1d6289871794c23eb2d")
    (:FILE "src/epochs/types.lisp" :SOURCE-MD5
     "82253491f995f5bc153fb5ebf30d564c" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/epochs/types.fasl"
     :FASL-MD5 "90b37b717fb5a5a88438afc53e3c7591")
    (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
     "653b974f310c09f6e2224a84acc43bbf" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/epochs/retire.fasl"
     :FASL-MD5 "f370cd5237b34db58858325b21ba9004")
    (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
     "036dd02adf87d33c3ae2f40735c733fa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/epochs/reclaim.fasl"
     :FASL-MD5 "5b47c349339f718e6b19520eb836c74b")
    (:FILE "src/epochs/read.lisp" :SOURCE-MD5
     "975b5f74e0c5a38ce978f4d9c7fcc6b8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/epochs/read.fasl"
     :FASL-MD5 "f1fe193ce6bb133ece0ca57ce9956ee9")
    (:FILE "src/epochs/package.lisp" :SOURCE-MD5
     "875201dfab0a84efd40fe9828cc293c8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/epochs/package.fasl"
     :FASL-MD5 "2805049fa6d1189a25b6084bdf4ca72e")
    (:FILE "src/epochs/core.lisp" :SOURCE-MD5
     "765d14c88cd288093a77a57930cd6999" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/epochs/core.fasl"
     :FASL-MD5 "7f381fd23427abde01130cb74e432b8a")
    (:FILE "src/csn/registry.lisp" :SOURCE-MD5
     "a1cdb5661fc54beba5bf00e4765f3235" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/csn/registry.fasl"
     :FASL-MD5 "1b6a6dfd63d902eaa52d5e1128b514c3")
    (:FILE "src/csn/package.lisp" :SOURCE-MD5
     "1130012fc5613a5648d22ed8628be0e8" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/csn/package.fasl"
     :FASL-MD5 "3713a0c3f4a075593c1aa30c260f57fe")
    (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/utf8.fasl"
     :FASL-MD5 "19597da0d9929963bd25f5811e085f17")
    (:FILE "src/codec/package.lisp" :SOURCE-MD5
     "d885bd2a9860eb60aec1a775e5031d5e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/package.fasl"
     :FASL-MD5 "70e3492bb2f8e82dbfd6a3c240bc6455")
    (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
     "69e77bcd15b5413a815a65c5081229db" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/cbor-write.fasl"
     :FASL-MD5 "a8ce023ecc9f85e960b6818c19367074")
    (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
     "b13e92b5f24a42fe283c17b649722b6a" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/cbor-string-write.fasl"
     :FASL-MD5 "d925887c10032af91cfec67aa38e2cba")
    (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
     "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/cbor-space.fasl"
     :FASL-MD5 "346e6804602ea3f8263d41ff4e8b4745")
    (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
     "200373402e6e082dd8c7afde305302bb" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/cbor-simple-write.fasl"
     :FASL-MD5 "69f39503c389230c0ceb67fc33967c65")
    (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
     "0c33aedcdb352e78a3c694cf796e6692" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan.fasl"
     :FASL-MD5 "06c220a74befdf50df79e8282c9c821e")
    (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
     "cf1999ddb10f879aeefbeea853742d57" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-stack.fasl"
     :FASL-MD5 "dbdf44956b1eba22e7806092a1a883e6")
    (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
     "987e8ed576a21eb644ac1ef2e06edbda" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-minimal.fasl"
     :FASL-MD5 "b1185601684fedccebc69722b2895615")
    (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
     "706c0baa4158bf272c4b0df17c1439d2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-items.fasl"
     :FASL-MD5 "13e8bc2434d83349d9834260fa6172c1")
    (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
     "f6488e987889432b375254021825dbe5" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-input.fasl"
     :FASL-MD5 "7683a1f63a4d9b1c8282c703705342a0")
    (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
     "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/cbor-package.fasl"
     :FASL-MD5 "684e0463612127e337d2b92f20aecc2c")
    (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
     "ecd8fe950344059c629927b38fb6e4aa" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/cbor-minimal.fasl"
     :FASL-MD5 "bcbca5bdea74a09b936aeca224fcdfab")
    (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
     "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/cbor-header.fasl"
     :FASL-MD5 "e9965dd3e1f1e058aa24b14277b06124")
    (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
     "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/codec/cbor-float-minimal.fasl"
     :FASL-MD5 "94da9b1580a0974dc350ef2f56f105cb")
    (:FILE "src/cache/write.lisp" :SOURCE-MD5
     "fc09021f74fb50aac57589614dae04d7" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/cache/write.fasl"
     :FASL-MD5 "c29eaf34c57846b60cd0f54375c4b5e8")
    (:FILE "src/cache/types.lisp" :SOURCE-MD5
     "a25648d870eaa4f0b6e1e3b2cf76e28e" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/cache/types.fasl"
     :FASL-MD5 "d8a3ce667076b5c5f3ae57de695d8e85")
    (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/cache/read.fasl"
     :FASL-MD5 "5d251657941e199ffc6243a1f6c9094f")
    (:FILE "src/cache/package.lisp" :SOURCE-MD5
     "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/cache/package.fasl"
     :FASL-MD5 "e418e3f1587ea9a5cdeb71d98898fb3d")
    (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
     :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/cache/core.fasl"
     :FASL-MD5 "efa2c77498ddffa5a121d58a66d62758")
    (:FILE "src/cache/clock.lisp" :SOURCE-MD5
     "3546cf7f5c5ed138068548c20064f499" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/cache/clock.fasl"
     :FASL-MD5 "f7107972ec649efe5bdeb97e658df565")
    (:FILE "src/cache/build.lisp" :SOURCE-MD5
     "5d70197c8b64ad6f20c8be47a60c73ca" :FASL
     "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/fasl/src/cache/build.fasl"
     :FASL-MD5 "4ae86587bcf10274d84e380d1c2fd2c1"))
   :EXPECTED-TESTS
   ("TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP"
    "TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2"
    "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED"
    "TEST-REQ-CCH-002-SERIES-GET-FIVE-OUTCOMES-COLD-AND-HOT"
    "TEST-REQ-CCH-004-SERIES-GET-CACHE-CORRUPTION-NATIVE-FALLBACK"
    "TEST-REQ-CMP-007-SERIES-GET-WRONG-OWNER-CLEANUP"
    "TEST-REQ-AFF-004-SERIES-GET-NIL-AND-CORRUPT-ROOT-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-CORRUPT-ACTIVE-CONTENT-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-SOURCE-CONTROLLER-MISMATCH-TYPED-FAULTED"
    "TEST-REQ-IDX-001-SERIES-GET-MISSING-CLOSED-ID-FAULTED"
    "TEST-REQ-CON-004-SERIES-GET-WRONG-STATE-NO-PIN-STEAL"
    "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION"
    "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
    "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-EXCLUDES-LATER-PUBLICATION"
    "TEST-REQ-WAL-005-SERIES-GET-WRITER-FOREIGN-OWNER-BEFORE-ADOPTION"
    "TEST-REQ-WAL-005-SERIES-GET-WRITER-DUPLICATE-ACTIVE-BEFORE-ADOPTION"
    "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-ACTIVE-OWNER-AND-ID-GUARDS"
    "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-EMPTY-AND-ID-EXTREMES"
    "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-65536-GEOMETRY-SEARCH17"
    "TEST-REQ-CON-004-SERIES-GET-BUFFER-REQUIRED-FIVE-OUTCOMES-AND-RESTART"
    "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-READER-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-WRITER-ARCHIVE-FAULTED"
    "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-ADAPTERS-NATIVE"
    "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-INVALID-ROOT-FAULTED"
    "TEST-REQ-CMP-007-SERIES-GET-ACTIVE-OWNER-BEFORE-FAULTED-CONTROLLER"
    "TEST-REQ-WAL-006-SERIES-GET-ACTIVE-UNEXPECTED-PROOF-FAULTED")
   :PASSED-TESTS
   ("TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP"
    "TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2"
    "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED"
    "TEST-REQ-CCH-002-SERIES-GET-FIVE-OUTCOMES-COLD-AND-HOT"
    "TEST-REQ-CCH-004-SERIES-GET-CACHE-CORRUPTION-NATIVE-FALLBACK"
    "TEST-REQ-CMP-007-SERIES-GET-WRONG-OWNER-CLEANUP"
    "TEST-REQ-AFF-004-SERIES-GET-NIL-AND-CORRUPT-ROOT-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-CORRUPT-ACTIVE-CONTENT-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-SOURCE-CONTROLLER-MISMATCH-TYPED-FAULTED"
    "TEST-REQ-IDX-001-SERIES-GET-MISSING-CLOSED-ID-FAULTED"
    "TEST-REQ-CON-004-SERIES-GET-WRONG-STATE-NO-PIN-STEAL"
    "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION"
    "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
    "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-EXCLUDES-LATER-PUBLICATION"
    "TEST-REQ-WAL-005-SERIES-GET-WRITER-FOREIGN-OWNER-BEFORE-ADOPTION"
    "TEST-REQ-WAL-005-SERIES-GET-WRITER-DUPLICATE-ACTIVE-BEFORE-ADOPTION"
    "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-ACTIVE-OWNER-AND-ID-GUARDS"
    "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-EMPTY-AND-ID-EXTREMES"
    "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-65536-GEOMETRY-SEARCH17"
    "TEST-REQ-CON-004-SERIES-GET-BUFFER-REQUIRED-FIVE-OUTCOMES-AND-RESTART"
    "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-READER-FAULTED"
    "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-WRITER-ARCHIVE-FAULTED"
    "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-ADAPTERS-NATIVE"
    "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-INVALID-ROOT-FAULTED"
    "TEST-REQ-CMP-007-SERIES-GET-ACTIVE-OWNER-BEFORE-FAULTED-CONTROLLER"
    "TEST-REQ-WAL-006-SERIES-GET-ACTIVE-UNEXPECTED-PROOF-FAULTED")
   :FAILED-TEST NIL :FAILURE-KIND NIL :SOURCE-MANIFEST
   ((:FILE "arcdocdb.asd" :MD5 "e8571ddf559a7a9b6d291de4fdf50717")
    (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
    (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
    (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
    (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
    (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
    (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
    (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
    (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
     "bc7a7b176e8cdd361b7c4306a1a4de4b")
    (:FILE "src/codec/cbor-header.lisp" :MD5
     "6e8c6a49314c2f460aa6f8a1759200b6")
    (:FILE "src/codec/cbor-minimal.lisp" :MD5
     "ecd8fe950344059c629927b38fb6e4aa")
    (:FILE "src/codec/cbor-package.lisp" :MD5
     "c3f19ffb4aacfdfe502c5e8b12a234f2")
    (:FILE "src/codec/cbor-scan-input.lisp" :MD5
     "f6488e987889432b375254021825dbe5")
    (:FILE "src/codec/cbor-scan-items.lisp" :MD5
     "706c0baa4158bf272c4b0df17c1439d2")
    (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
     "987e8ed576a21eb644ac1ef2e06edbda")
    (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
     "cf1999ddb10f879aeefbeea853742d57")
    (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
    (:FILE "src/codec/cbor-simple-write.lisp" :MD5
     "200373402e6e082dd8c7afde305302bb")
    (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
    (:FILE "src/codec/cbor-string-write.lisp" :MD5
     "b13e92b5f24a42fe283c17b649722b6a")
    (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
    (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
    (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
    (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
    (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
    (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
    (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
    (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
    (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
    (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
    (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
    (:FILE "src/execution/handoff.lisp" :MD5
     "6b85eebe69366e78ed5fc5cc20735f00")
    (:FILE "src/execution/package.lisp" :MD5
     "cb5710d6c111cadb7121a50998a747fa")
    (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
    (:FILE "src/execution/ready-recycle.lisp" :MD5
     "38d26f8c749dd946dfc4b9c57103a892")
    (:FILE "src/execution/ready-types.lisp" :MD5
     "a64d98c9ff429d6103d6e10ee1fd7980")
    (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
    (:FILE "src/execution/worker-boundary.lisp" :MD5
     "c24065d6c8d80d1be53994a0041743df")
    (:FILE "src/execution/worker-claim.lisp" :MD5
     "babd0a78b4185af24ae1fef870c0fabb")
    (:FILE "src/execution/worker-run.lisp" :MD5
     "aa34ca6bc07535e35fea723878d99f66")
    (:FILE "src/execution/worker-types.lisp" :MD5
     "0679ee07c46f69db330706303c70d8d2")
    (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
    (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
    (:FILE "src/foundation/binary.lisp" :MD5
     "a06115175f450776762761dce25acdb8")
    (:FILE "src/foundation/conditions.lisp" :MD5
     "942b596396c19815290a57830af2121b")
    (:FILE "src/foundation/crc32c.lisp" :MD5
     "4db58e2f48bf77d751f1b83bb9f84b5c")
    (:FILE "src/foundation/package.lisp" :MD5
     "5ee593a112958d94163dab17c5aa4ba2")
    (:FILE "src/foundation/record.lisp" :MD5
     "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
    (:FILE "src/get-directory/build.lisp" :MD5
     "cde24b2bf5c5637d5501b95bed47df31")
    (:FILE "src/get-directory/package.lisp" :MD5
     "894f6e238fe4047f2bf607fceae86846")
    (:FILE "src/get-directory/read.lisp" :MD5
     "74a694385f1aaf03ec87721545494119")
    (:FILE "src/get-directory/sources-read.lisp" :MD5
     "2b8193aab6801de19e26fa55e7c53f87")
    (:FILE "src/get-directory/sources-types.lisp" :MD5
     "b846a6348ff7d4b5f7b380b5b3ff8c17")
    (:FILE "src/get-directory/types.lisp" :MD5
     "17c957d6934a31f4ed64313e756de2d2")
    (:FILE "src/get-resolver/active-build.lisp" :MD5
     "c65593cf172f53a8e90a853bbe9504c2")
    (:FILE "src/get-resolver/active-directory.lisp" :MD5
     "6d95f29b331d335175843f47ae44a6ea")
    (:FILE "src/get-resolver/active-preflight.lisp" :MD5
     "f13d422adb6aa9e8489352884137f25a")
    (:FILE "src/get-resolver/active-read.lisp" :MD5
     "521737861e057d663964b0c030552587")
    (:FILE "src/get-resolver/active-scan.lisp" :MD5
     "d6aaec49504a96f37c8ff1bc182c977b")
    (:FILE "src/get-resolver/active-types.lisp" :MD5
     "bd7182e9871fe82530d0c828e473ccde")
    (:FILE "src/get-resolver/build.lisp" :MD5
     "bbfb2082103e6712419e180ab972245c")
    (:FILE "src/get-resolver/package.lisp" :MD5
     "6226d131f5562a475048b6444049c4ca")
    (:FILE "src/get-resolver/read.lisp" :MD5
     "1339edff0223dbf122f11ff0adbba61c")
    (:FILE "src/get-resolver/rows.lisp" :MD5
     "ca9002b81efd0aed9761cd1f78514762")
    (:FILE "src/get-resolver/scan.lisp" :MD5
     "536e9dc4ed51072b8a6d1528d3ec18bf")
    (:FILE "src/get-resolver/sort.lisp" :MD5
     "2d869293ba47444c4721713d955c6254")
    (:FILE "src/get-resolver/types.lisp" :MD5
     "9df13bcc6908e9fa601d173a671e1ccf")
    (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
    (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
    (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
    (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
    (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
    (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
    (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
    (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
    (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
    (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
    (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
    (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
    (:FILE "src/index/hash-digests.lisp" :MD5
     "43d2209225707352daec6186ef95a805")
    (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
    (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
    (:FILE "src/index/primary-arena.lisp" :MD5
     "a319691e3e28b7ea7b927de490cf69ba")
    (:FILE "src/index/primary-build.lisp" :MD5
     "ff2cfbb865290d7a1510fdf6877c7229")
    (:FILE "src/index/primary-core.lisp" :MD5
     "fa52433eae199ceeb874bf2bc47afca7")
    (:FILE "src/index/primary-directory.lisp" :MD5
     "1dd67c527257e43f17e006644ecdbd00")
    (:FILE "src/index/primary-package.lisp" :MD5
     "d65cfce399b04f905bf969929962e59a")
    (:FILE "src/index/primary-probe.lisp" :MD5
     "699ce3f1615296fc27fcde3e0d63a4bc")
    (:FILE "src/index/primary-read.lisp" :MD5
     "3f317a0d3c5ee86a73651aad36135cc3")
    (:FILE "src/index/primary-relocate.lisp" :MD5
     "5155959766645d3172ae5e73c58cc071")
    (:FILE "src/index/primary-types.lisp" :MD5
     "a59eab6425a60fa2656f86bf87d5c9ac")
    (:FILE "src/index/primary-write.lisp" :MD5
     "e8e31e599356e592af29c0cc4604872b")
    (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
    (:FILE "src/index/rebuild-budget.lisp" :MD5
     "0417dd41cb3ec1d62dfd913c19f810ad")
    (:FILE "src/index/rebuild-copy.lisp" :MD5
     "8befbbd00ed5c31c1487a11887eba495")
    (:FILE "src/index/rebuild-scan.lisp" :MD5
     "1188e7a64a7a5d9482c1233cb9acb452")
    (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
    (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
    (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
    (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
    (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
    (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
    (:FILE "src/io/identity-types.lisp" :MD5
     "d354a095fb378c1b6f27397ffb902227")
    (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
    (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
    (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
    (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
    (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
    (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
    (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
    (:FILE "src/mvcc/snapshots-core.lisp" :MD5
     "8bb066aab61a18eff175b9edb11e42a2")
    (:FILE "src/mvcc/snapshots-csn.lisp" :MD5
     "0e9365e674d1584b111f915ce1f58634")
    (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
     "ff98aea5cb9a7ae2671f6a887a003725")
    (:FILE "src/mvcc/snapshots-read.lisp" :MD5
     "ae3ad96269b5e711a9dbb455f3c0ce48")
    (:FILE "src/mvcc/snapshots-register.lisp" :MD5
     "2d5a795bcefd605c75da91c725ae83a2")
    (:FILE "src/mvcc/snapshots-types.lisp" :MD5
     "475517bd7ba04a1c37a82efeb8ff73d9")
    (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
    (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
    (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
    (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
    (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
    (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
    (:FILE "src/recovery/decisions-build.lisp" :MD5
     "1a51ef4a488bb9fde2ff7d47bae01379")
    (:FILE "src/recovery/decisions-package.lisp" :MD5
     "cbdc30f93109c474e1fc25066c9b9b13")
    (:FILE "src/recovery/decisions-query.lisp" :MD5
     "f782d1137b8ce342b91c9999cfb7accc")
    (:FILE "src/recovery/decisions-radix.lisp" :MD5
     "852149de4c289b8e067602780378d87a")
    (:FILE "src/recovery/decisions-sort.lisp" :MD5
     "b33e57a643f2fca810846f6226366253")
    (:FILE "src/recovery/decisions-types.lisp" :MD5
     "f4433fd19ebc7239dbc2628c39f3ecdb")
    (:FILE "src/recovery/inventory-build.lisp" :MD5
     "9bd6820c4feba3e552aab1a4edd87861")
    (:FILE "src/recovery/inventory-query.lisp" :MD5
     "fcea263de1938767772e5b11411ecd5e")
    (:FILE "src/recovery/inventory-types.lisp" :MD5
     "78c136d5838dcfe3019d9069643a8d8f")
    (:FILE "src/recovery/manifest-build.lisp" :MD5
     "bf65b1731eab6e0572461ef5cc60fc40")
    (:FILE "src/recovery/manifest-decode.lisp" :MD5
     "67975249aaabd751757cdfb9222cc3c4")
    (:FILE "src/recovery/manifest-fold.lisp" :MD5
     "e0d2498db1011e857b7b0daa1934f187")
    (:FILE "src/recovery/manifest-package.lisp" :MD5
     "37ace42844c11b52446ee1fc500b8e0b")
    (:FILE "src/recovery/manifest-query.lisp" :MD5
     "ebd7a54adea2213294a887e6d4db0927")
    (:FILE "src/recovery/manifest-types.lisp" :MD5
     "7b1d4054415faca7e5fca59ad83b4d4a")
    (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
    (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
    (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
    (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
    (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
    (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
    (:FILE "src/series/publication.lisp" :MD5
     "056d2c6a67c9d9f2bf9fe2d2c348d53c")
    (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
    (:FILE "src/series/retirement.lisp" :MD5
     "b8e04971b8ad75a1bd0c722997badfd2")
    (:FILE "src/series/routing-build.lisp" :MD5
     "d6924deff152b941bd49f0bb200b4197")
    (:FILE "src/series/routing-select.lisp" :MD5
     "e0f987d8767744050ec4d1b3ecb699ed")
    (:FILE "src/series/routing-types.lisp" :MD5
     "ce649df47dd38888d5103c98345f7e41")
    (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
    (:FILE "src/series/worker-boundary.lisp" :MD5
     "2340e0c9074f7b1bf80c74f774986bc5")
    (:FILE "src/series/worker-package.lisp" :MD5
     "a93ce2e84e8aee647b5083ad1d2b899b")
    (:FILE "src/series/worker-run.lisp" :MD5
     "f0fee18adf357bad98e8a3c3e8c70c0c")
    (:FILE "src/series/worker-types.lisp" :MD5
     "2b23d468be0165fa009c5ebd5d1bbe23")
    (:FILE "src/storage/compaction-scan.lisp" :MD5
     "1cda77a357ab2147035993b72d135a37")
    (:FILE "src/storage/control-payload.lisp" :MD5
     "cb64f806b8d69eb42d865b4abfff0b27")
    (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
    (:FILE "src/storage/log-header.lisp" :MD5
     "b53d27dcc9f4badf18b50519c50bc614")
    (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
    (:FILE "src/storage/payload-record.lisp" :MD5
     "8c03f9c01dcb30f2d3970a5694968ecf")
    (:FILE "src/storage/payload-write.lisp" :MD5
     "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
    (:FILE "src/storage/segment-header.lisp" :MD5
     "d6812fa59bf8fd1252fbf85a9bfa3896")
    (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
    (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
    (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
    (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
    (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
    (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
    (:FILE "tests/foundation/support.lisp" :MD5
     "758adad069aec2f9dbe0635797314ff6")
    (:FILE "tests/get-directory/support.lisp" :MD5
     "3f868ebe4307ad4238b314c37eceed9a")
    (:FILE "tests/get-directory/construction.lisp" :MD5
     "1137938073e71d6d8d62c751fbad05d5")
    (:FILE "tests/get-directory/read.lisp" :MD5
     "d1ab36d05cc1266e4533d27c693f12f4")
    (:FILE "tests/get-directory/threads.lisp" :MD5
     "63dd01c852de1399c2c82274d481d257")
    (:FILE "tests/get-directory/series-support.lisp" :MD5
     "8d7ed4f8d3f9e8394b15c648a3a4507b")
    (:FILE "tests/get-directory/series-read.lisp" :MD5
     "3e565b431b88fb5211023601b5e3ce3b")
    (:FILE "tools/get-series-mutation.lisp" :MD5
     "2068edb227d28b9e53c4eecc125fca54")))
  :ARTIFACTS-VERIFIED T :SIGNAL NIL :EXIT-CODE 0 :SOURCE-MANIFEST
  ((:FILE "arcdocdb.asd" :MD5 "e8571ddf559a7a9b6d291de4fdf50717")
   (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
   (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
   (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
   (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
   (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
   (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
   (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
   (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
    "bc7a7b176e8cdd361b7c4306a1a4de4b")
   (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
   (:FILE "src/codec/cbor-minimal.lisp" :MD5
    "ecd8fe950344059c629927b38fb6e4aa")
   (:FILE "src/codec/cbor-package.lisp" :MD5
    "c3f19ffb4aacfdfe502c5e8b12a234f2")
   (:FILE "src/codec/cbor-scan-input.lisp" :MD5
    "f6488e987889432b375254021825dbe5")
   (:FILE "src/codec/cbor-scan-items.lisp" :MD5
    "706c0baa4158bf272c4b0df17c1439d2")
   (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
    "987e8ed576a21eb644ac1ef2e06edbda")
   (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
    "cf1999ddb10f879aeefbeea853742d57")
   (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
   (:FILE "src/codec/cbor-simple-write.lisp" :MD5
    "200373402e6e082dd8c7afde305302bb")
   (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
   (:FILE "src/codec/cbor-string-write.lisp" :MD5
    "b13e92b5f24a42fe283c17b649722b6a")
   (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
   (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
   (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
   (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
   (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
   (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
   (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
   (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
   (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
   (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
   (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
   (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
   (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
   (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
   (:FILE "src/execution/ready-recycle.lisp" :MD5
    "38d26f8c749dd946dfc4b9c57103a892")
   (:FILE "src/execution/ready-types.lisp" :MD5
    "a64d98c9ff429d6103d6e10ee1fd7980")
   (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
   (:FILE "src/execution/worker-boundary.lisp" :MD5
    "c24065d6c8d80d1be53994a0041743df")
   (:FILE "src/execution/worker-claim.lisp" :MD5
    "babd0a78b4185af24ae1fef870c0fabb")
   (:FILE "src/execution/worker-run.lisp" :MD5
    "aa34ca6bc07535e35fea723878d99f66")
   (:FILE "src/execution/worker-types.lisp" :MD5
    "0679ee07c46f69db330706303c70d8d2")
   (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
   (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
   (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
   (:FILE "src/foundation/conditions.lisp" :MD5
    "942b596396c19815290a57830af2121b")
   (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
   (:FILE "src/foundation/package.lisp" :MD5
    "5ee593a112958d94163dab17c5aa4ba2")
   (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
   (:FILE "src/get-directory/build.lisp" :MD5
    "cde24b2bf5c5637d5501b95bed47df31")
   (:FILE "src/get-directory/package.lisp" :MD5
    "894f6e238fe4047f2bf607fceae86846")
   (:FILE "src/get-directory/read.lisp" :MD5
    "74a694385f1aaf03ec87721545494119")
   (:FILE "src/get-directory/sources-read.lisp" :MD5
    "2b8193aab6801de19e26fa55e7c53f87")
   (:FILE "src/get-directory/sources-types.lisp" :MD5
    "b846a6348ff7d4b5f7b380b5b3ff8c17")
   (:FILE "src/get-directory/types.lisp" :MD5
    "17c957d6934a31f4ed64313e756de2d2")
   (:FILE "src/get-resolver/active-build.lisp" :MD5
    "c65593cf172f53a8e90a853bbe9504c2")
   (:FILE "src/get-resolver/active-directory.lisp" :MD5
    "6d95f29b331d335175843f47ae44a6ea")
   (:FILE "src/get-resolver/active-preflight.lisp" :MD5
    "f13d422adb6aa9e8489352884137f25a")
   (:FILE "src/get-resolver/active-read.lisp" :MD5
    "521737861e057d663964b0c030552587")
   (:FILE "src/get-resolver/active-scan.lisp" :MD5
    "d6aaec49504a96f37c8ff1bc182c977b")
   (:FILE "src/get-resolver/active-types.lisp" :MD5
    "bd7182e9871fe82530d0c828e473ccde")
   (:FILE "src/get-resolver/build.lisp" :MD5
    "bbfb2082103e6712419e180ab972245c")
   (:FILE "src/get-resolver/package.lisp" :MD5
    "6226d131f5562a475048b6444049c4ca")
   (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
   (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
   (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
   (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
   (:FILE "src/get-resolver/types.lisp" :MD5
    "9df13bcc6908e9fa601d173a671e1ccf")
   (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
   (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
   (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
   (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
   (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
   (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
   (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
   (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
   (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
   (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
   (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
   (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
   (:FILE "src/index/hash-digests.lisp" :MD5
    "43d2209225707352daec6186ef95a805")
   (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
   (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
   (:FILE "src/index/primary-arena.lisp" :MD5
    "a319691e3e28b7ea7b927de490cf69ba")
   (:FILE "src/index/primary-build.lisp" :MD5
    "ff2cfbb865290d7a1510fdf6877c7229")
   (:FILE "src/index/primary-core.lisp" :MD5
    "fa52433eae199ceeb874bf2bc47afca7")
   (:FILE "src/index/primary-directory.lisp" :MD5
    "1dd67c527257e43f17e006644ecdbd00")
   (:FILE "src/index/primary-package.lisp" :MD5
    "d65cfce399b04f905bf969929962e59a")
   (:FILE "src/index/primary-probe.lisp" :MD5
    "699ce3f1615296fc27fcde3e0d63a4bc")
   (:FILE "src/index/primary-read.lisp" :MD5
    "3f317a0d3c5ee86a73651aad36135cc3")
   (:FILE "src/index/primary-relocate.lisp" :MD5
    "5155959766645d3172ae5e73c58cc071")
   (:FILE "src/index/primary-types.lisp" :MD5
    "a59eab6425a60fa2656f86bf87d5c9ac")
   (:FILE "src/index/primary-write.lisp" :MD5
    "e8e31e599356e592af29c0cc4604872b")
   (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
   (:FILE "src/index/rebuild-budget.lisp" :MD5
    "0417dd41cb3ec1d62dfd913c19f810ad")
   (:FILE "src/index/rebuild-copy.lisp" :MD5
    "8befbbd00ed5c31c1487a11887eba495")
   (:FILE "src/index/rebuild-scan.lisp" :MD5
    "1188e7a64a7a5d9482c1233cb9acb452")
   (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
   (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
   (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
   (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
   (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
   (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
   (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
   (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
   (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
   (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
   (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
   (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
   (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
   (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
   (:FILE "src/mvcc/snapshots-core.lisp" :MD5
    "8bb066aab61a18eff175b9edb11e42a2")
   (:FILE "src/mvcc/snapshots-csn.lisp" :MD5
    "0e9365e674d1584b111f915ce1f58634")
   (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
    "ff98aea5cb9a7ae2671f6a887a003725")
   (:FILE "src/mvcc/snapshots-read.lisp" :MD5
    "ae3ad96269b5e711a9dbb455f3c0ce48")
   (:FILE "src/mvcc/snapshots-register.lisp" :MD5
    "2d5a795bcefd605c75da91c725ae83a2")
   (:FILE "src/mvcc/snapshots-types.lisp" :MD5
    "475517bd7ba04a1c37a82efeb8ff73d9")
   (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
   (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
   (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
   (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
   (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
   (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
   (:FILE "src/recovery/decisions-build.lisp" :MD5
    "1a51ef4a488bb9fde2ff7d47bae01379")
   (:FILE "src/recovery/decisions-package.lisp" :MD5
    "cbdc30f93109c474e1fc25066c9b9b13")
   (:FILE "src/recovery/decisions-query.lisp" :MD5
    "f782d1137b8ce342b91c9999cfb7accc")
   (:FILE "src/recovery/decisions-radix.lisp" :MD5
    "852149de4c289b8e067602780378d87a")
   (:FILE "src/recovery/decisions-sort.lisp" :MD5
    "b33e57a643f2fca810846f6226366253")
   (:FILE "src/recovery/decisions-types.lisp" :MD5
    "f4433fd19ebc7239dbc2628c39f3ecdb")
   (:FILE "src/recovery/inventory-build.lisp" :MD5
    "9bd6820c4feba3e552aab1a4edd87861")
   (:FILE "src/recovery/inventory-query.lisp" :MD5
    "fcea263de1938767772e5b11411ecd5e")
   (:FILE "src/recovery/inventory-types.lisp" :MD5
    "78c136d5838dcfe3019d9069643a8d8f")
   (:FILE "src/recovery/manifest-build.lisp" :MD5
    "bf65b1731eab6e0572461ef5cc60fc40")
   (:FILE "src/recovery/manifest-decode.lisp" :MD5
    "67975249aaabd751757cdfb9222cc3c4")
   (:FILE "src/recovery/manifest-fold.lisp" :MD5
    "e0d2498db1011e857b7b0daa1934f187")
   (:FILE "src/recovery/manifest-package.lisp" :MD5
    "37ace42844c11b52446ee1fc500b8e0b")
   (:FILE "src/recovery/manifest-query.lisp" :MD5
    "ebd7a54adea2213294a887e6d4db0927")
   (:FILE "src/recovery/manifest-types.lisp" :MD5
    "7b1d4054415faca7e5fca59ad83b4d4a")
   (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
   (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
   (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
   (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
   (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
   (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
   (:FILE "src/series/publication.lisp" :MD5
    "056d2c6a67c9d9f2bf9fe2d2c348d53c")
   (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
   (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
   (:FILE "src/series/routing-build.lisp" :MD5
    "d6924deff152b941bd49f0bb200b4197")
   (:FILE "src/series/routing-select.lisp" :MD5
    "e0f987d8767744050ec4d1b3ecb699ed")
   (:FILE "src/series/routing-types.lisp" :MD5
    "ce649df47dd38888d5103c98345f7e41")
   (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
   (:FILE "src/series/worker-boundary.lisp" :MD5
    "2340e0c9074f7b1bf80c74f774986bc5")
   (:FILE "src/series/worker-package.lisp" :MD5
    "a93ce2e84e8aee647b5083ad1d2b899b")
   (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
   (:FILE "src/series/worker-types.lisp" :MD5
    "2b23d468be0165fa009c5ebd5d1bbe23")
   (:FILE "src/storage/compaction-scan.lisp" :MD5
    "1cda77a357ab2147035993b72d135a37")
   (:FILE "src/storage/control-payload.lisp" :MD5
    "cb64f806b8d69eb42d865b4abfff0b27")
   (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
   (:FILE "src/storage/log-header.lisp" :MD5
    "b53d27dcc9f4badf18b50519c50bc614")
   (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
   (:FILE "src/storage/payload-record.lisp" :MD5
    "8c03f9c01dcb30f2d3970a5694968ecf")
   (:FILE "src/storage/payload-write.lisp" :MD5
    "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
   (:FILE "src/storage/segment-header.lisp" :MD5
    "d6812fa59bf8fd1252fbf85a9bfa3896")
   (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
   (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
   (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
   (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
   (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
   (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
   (:FILE "tests/foundation/support.lisp" :MD5
    "758adad069aec2f9dbe0635797314ff6")
   (:FILE "tests/get-directory/support.lisp" :MD5
    "3f868ebe4307ad4238b314c37eceed9a")
   (:FILE "tests/get-directory/construction.lisp" :MD5
    "1137938073e71d6d8d62c751fbad05d5")
   (:FILE "tests/get-directory/read.lisp" :MD5
    "d1ab36d05cc1266e4533d27c693f12f4")
   (:FILE "tests/get-directory/threads.lisp" :MD5
    "63dd01c852de1399c2c82274d481d257")
   (:FILE "tests/get-directory/series-support.lisp" :MD5
    "8d7ed4f8d3f9e8394b15c648a3a4507b")
   (:FILE "tests/get-directory/series-read.lisp" :MD5
    "3e565b431b88fb5211023601b5e3ce3b")
   (:FILE "tools/get-series-mutation.lisp" :MD5
    "2068edb227d28b9e53c4eecc125fca54"))
  :DEADLINE-SECONDS 120 :ARGV
  ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
   "--script"
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/evidence/baseline/driver.lisp"
   "--child"
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/evidence/baseline/config.lisp")
  :NAME "baseline" :FILE NIL :RESULT :BASELINE-PASSED :STATUS :OK
  :COPY-DIRECTORY
  "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/baseline/"
  :EVIDENCE-DIRECTORY
  "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/evidence/baseline/"
  :EXPECTED-FAILURE NIL :PRODUCER-RECORD
  "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/report.lisp"
  :PRODUCER-CLOSED T :CHILD-LAUNCHED T :CHILD-REAPED T :TIMED-OUT NIL :CLEANUP
  :REAPED)
 :MUTANTS
 ((:NAME "active-end-one-byte-overrun" :FILE
   "src/get-resolver/active-read.lisp" :RESULT :DETECTED :STATUS :OK
   :COPY-DIRECTORY
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/active-end-one-byte-overrun/"
   :EVIDENCE-DIRECTORY
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/evidence/active-end-one-byte-overrun/"
   :EXPECTED-FAILURE :ACTIVE-COMMITTED-FRONTIER :PRODUCER-RECORD
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/report.lisp"
   :PRODUCER-CLOSED T :CHILD-LAUNCHED T :CHILD-REAPED T :TIMED-OUT NIL :CLEANUP
   :REAPED)
  (:NAME "dispatch-active-to-closed" :FILE
   "src/get-directory/sources-read.lisp" :RESULT :DETECTED :STATUS :OK
   :COPY-DIRECTORY
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/dispatch-active-to-closed/"
   :EVIDENCE-DIRECTORY
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/evidence/dispatch-active-to-closed/"
   :EXPECTED-FAILURE :ACTIVE-SELECTION :PRODUCER-RECORD
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/report.lisp"
   :PRODUCER-CLOSED T :CHILD-LAUNCHED T :CHILD-REAPED T :TIMED-OUT NIL :CLEANUP
   :REAPED)
  (:NAME "accept-active-closed-duplicate" :FILE
   "src/get-directory/sources-read.lisp" :RESULT :DETECTED :STATUS :OK
   :COPY-DIRECTORY
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/accept-active-closed-duplicate/"
   :EVIDENCE-DIRECTORY
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/evidence/accept-active-closed-duplicate/"
   :EXPECTED-FAILURE :ACTIVE-CLOSED-DUPLICATE-ACCEPTED :PRODUCER-RECORD
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/report.lisp"
   :PRODUCER-CLOSED T :CHILD-LAUNCHED T :CHILD-REAPED T :TIMED-OUT NIL :CLEANUP
   :REAPED)
  (:NAME "planned-root-instead-of-published" :FILE
   "src/get-directory/sources-read.lisp" :RESULT :DETECTED :STATUS :OK
   :COPY-DIRECTORY
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/isolatedtests/planned-root-instead-of-published/"
   :EVIDENCE-DIRECTORY
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/raw/evidence/planned-root-instead-of-published/"
   :EXPECTED-FAILURE :PUBLISHED-ROOT-OR-SINGLE-ACQUIRE :PRODUCER-RECORD
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-f/report.lisp"
   :PRODUCER-CLOSED T :CHILD-LAUNCHED T :CHILD-REAPED T :TIMED-OUT NIL :CLEANUP
   :REAPED))
 :TARGETS
 ((:NAME "planned-root-instead-of-published" :FILE
   "src/get-directory/sources-read.lisp" :TEST
   "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION" :BEFORE
   "(root (leggi-radice-serie controller))" :AFTER
   "(root (arcdocdb.series::controllore-serie-planned-root controller))"
   :EXPECTED-FAILURE :PUBLISHED-ROOT-OR-SINGLE-ACQUIRE)
  (:NAME "accept-active-closed-duplicate" :FILE
   "src/get-directory/sources-read.lisp" :TEST
   "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED" :BEFORE
   "(guasto-get context :sources-active-duplicate)" :AFTER
   "(when (null active) (guasto-get context :sources-active-duplicate))"
   :EXPECTED-FAILURE :ACTIVE-CLOSED-DUPLICATE-ACCEPTED)
  (:NAME "dispatch-active-to-closed" :FILE
   "src/get-directory/sources-read.lisp" :TEST
   "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED" :BEFORE
   "(risolvi-candidato-radice-attiva-get context active)" :AFTER
   "(risolvi-candidato-directory-get context (fonti-get-serie-directory sources))"
   :EXPECTED-FAILURE :ACTIVE-SELECTION)
  (:NAME "active-end-one-byte-overrun" :FILE
   "src/get-resolver/active-read.lisp" :TEST
   "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE" :BEFORE
   "(values segment end flags nil)" :AFTER
   "(values segment (1+ end) flags nil)" :EXPECTED-FAILURE
   :ACTIVE-COMMITTED-FRONTIER))
 :EXPECTED-TESTS
 ("TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP"
  "TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2"
  "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED"
  "TEST-REQ-CCH-002-SERIES-GET-FIVE-OUTCOMES-COLD-AND-HOT"
  "TEST-REQ-CCH-004-SERIES-GET-CACHE-CORRUPTION-NATIVE-FALLBACK"
  "TEST-REQ-CMP-007-SERIES-GET-WRONG-OWNER-CLEANUP"
  "TEST-REQ-AFF-004-SERIES-GET-NIL-AND-CORRUPT-ROOT-FAULTED"
  "TEST-REQ-AFF-004-SERIES-GET-CORRUPT-ACTIVE-CONTENT-FAULTED"
  "TEST-REQ-AFF-004-SERIES-GET-SOURCE-CONTROLLER-MISMATCH-TYPED-FAULTED"
  "TEST-REQ-IDX-001-SERIES-GET-MISSING-CLOSED-ID-FAULTED"
  "TEST-REQ-CON-004-SERIES-GET-WRONG-STATE-NO-PIN-STEAL"
  "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION"
  "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
  "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-EXCLUDES-LATER-PUBLICATION"
  "TEST-REQ-WAL-005-SERIES-GET-WRITER-FOREIGN-OWNER-BEFORE-ADOPTION"
  "TEST-REQ-WAL-005-SERIES-GET-WRITER-DUPLICATE-ACTIVE-BEFORE-ADOPTION"
  "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED"
  "TEST-REQ-AFF-004-SERIES-GET-ACTIVE-OWNER-AND-ID-GUARDS"
  "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-EMPTY-AND-ID-EXTREMES"
  "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-65536-GEOMETRY-SEARCH17"
  "TEST-REQ-CON-004-SERIES-GET-BUFFER-REQUIRED-FIVE-OUTCOMES-AND-RESTART"
  "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-READER-FAULTED"
  "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-WRITER-ARCHIVE-FAULTED"
  "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-ADAPTERS-NATIVE"
  "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-INVALID-ROOT-FAULTED"
  "TEST-REQ-CMP-007-SERIES-GET-ACTIVE-OWNER-BEFORE-FAULTED-CONTROLLER"
  "TEST-REQ-WAL-006-SERIES-GET-ACTIVE-UNEXPECTED-PROOF-FAULTED")
 :SOURCE-CONSISTENCY :STABLE :RAW-ROOT "raw/evidence/" :COLLECTOR-EXCLUSIONS
 ("raw/isolatedtests/") :CHILD-DEADLINE-SECONDS 120 :CAMPAIGN-DEADLINE-SECONDS
 900 :STATIC-RISKS
 (:PARENT-SOURCE-FREEZE-REQUIRED :NOT-EXECUTED-BY-AUTHOR
  :ONLY-FOUR-READ-MUTANTS :NEW-SERIES-SUITE-REQUIRED :NATIVE-FIXTURE-IO
  :SERIAL-FUNCTION-FI :COMPILER-FIXTURE-TYPE-IO-TIMEOUT-CRASH-NOT-KILLS
  :ISOLATEDCOPIES-EXCLUDED-FROM-COLLECTOR
  :EVIDENCE-DIRECTORY-MUST-BE-COLLECTED-WITH-TERMINAL-PRODUCER
  :MD5-FOR-LOCAL-BYTE-IDENTITY-NOT-ADVERSARIAL-ATTESTATION
  :NO-ENGINE-QUALIFICATION))
