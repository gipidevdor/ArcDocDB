(:FINISHED-AT-UNIVERSAL-TIME 4000908054 :CONDITION-TYPE "SIMPLE-ERROR"
 :DIAGNOSTIC "Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-OPERATION
                       ARCDOCDB.GET.DIRECTORY.TESTS::OPERATION
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-CONTEXT
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE)
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-FIXTURE-CONTROLLER
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVARIANT-VIOLATION (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :SOURCES-ACTIVE-DUPLICATE)))"
 :SCHEMA-VERSION 1 :KIND :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE
 :TESTS :COMPILED T :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "3e565b431b88fb5211023601b5e3ce3b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "2522ff2dc0c33e4be47bcd43740bad70")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "bc0be0652d7282fbe09c3a7f9955d795")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "532a1ac228327b886eaf5808d8c688a0")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "064710f25b616dad71aac692fa1e2fe2")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "4c78e45ff6d4b109932062c70fe9f922")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "e19aedc71f6909410860759b167eef10")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "9cb79297cefcfee4522cdcc47a675671")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/types.fasl"
   :FASL-MD5 "3a1836398b05a85caceee6de774d5702")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/package.fasl"
   :FASL-MD5 "5b966050c2e3f9afd7d840bd998bfda6")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/group.fasl"
   :FASL-MD5 "a3b86b31ee3818edcff36a9af6116c8a")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/executor.fasl"
   :FASL-MD5 "a7d2e9d5fab7745be6ffa35735b56e59")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/csn.fasl"
   :FASL-MD5 "af8160abe94e58a3dd874100a57e4d6e")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/builder.fasl"
   :FASL-MD5 "6e110a645a938170b82ea84c85386462")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "30869ba6c2ab9ede154ceb6cf18bdb17")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "9b9be675ebeafa499f816dd92c45e7a6")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "005fd7cd6fab48368ba9457fad7d52d5")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/package.fasl"
   :FASL-MD5 "987f7fc166d06fdea62cc06749e8bb45")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "20c281bbe17bfb69fd4f10882ee9acb9")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/formats.fasl"
   :FASL-MD5 "7c6745e43f96181e92201b424a5ec8fa")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "f7ede81187b5c549675473b061a59d87")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "53e0792855b4d8d9998a9a58abf3d1ff")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "30aa538537b2c7d3de679b504af62371")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "d56644e0b1823bbcdb97d286d698d514")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "572cd56ee0f24e22b87eb2ea2ed2e5e7")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "085cbdcd6c2c72e43479447a379d8e8f")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/types.fasl"
   :FASL-MD5 "506e7d76681bbdc585994394308a9a2b")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "91632eae605c26433c69ecbff4a20f10")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "c6cda782e1b61866ff1fee5be79e6823")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "8a16b6c35675935c33a793060e46138d")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/retirement.fasl"
   :FASL-MD5 "a62427a8893a3dd2b82d7cdad2fa4e0a")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/query.fasl"
   :FASL-MD5 "b4ac0e4e91ec143bec1d6dd3690fe4a7")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/publication.fasl"
   :FASL-MD5 "4c5c6194e2a1c1674b301438a852980e")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/package.fasl"
   :FASL-MD5 "fa6e1a70ba7694bd4a03cd2da8c3c722")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/ownership.fasl"
   :FASL-MD5 "1b67989c14127c47b43f3e26e116e9cc")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/io-events.fasl"
   :FASL-MD5 "e1aff4ecaba352c8959b731bcabec5df")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/events.fasl"
   :FASL-MD5 "57db216131660db7a6bf579e08c9a355")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "85eaa8313368f67dd7f83ea97ac14647")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/package.fasl"
   :FASL-MD5 "b669eaf17fc4839ef117f431035bdc82")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "99892cae0a64b2f345bcf8abefa9fb54")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "80b370e6dccc9514390cfee25c0b21c0")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "da342810d414fb94fe58a7277c355487")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "3286e975304ab37cd65a864b64e3c1fa")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "39da642cf691b0b8f7cfc5a7c6a8e81e")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "fede2f71a9c91caddd6d08418db14447")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "9aca0cfa3d9dbd1e8e84677a11433eac")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "b3d81b174f406d696fb8eb73a6d70ca8")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "d2b2f2a1c1ce77fde0773fcd25d3ee14")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "6f602997197a858aaf93b1fda21b00dd")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "2b47fdf2c590fc1574151e2617d2db2c")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "f257a387ad63f399775069c9b9c38e7d")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "ab02c6c1ffebf83dca9eeeeec9fc0ecc")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "9610730caafbbea0f96cfbedd3094f02")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "bef61674e94c1043ba8060865b028222")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/types.fasl"
   :FASL-MD5 "c8f6788f291a295d63e51de7febf7d4b")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/task.fasl"
   :FASL-MD5 "26e205e83082ddeebc78485a4532d288")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/package.fasl"
   :FASL-MD5 "3c8e4e011bac62073fb2a410cf62516a")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/core.fasl"
   :FASL-MD5 "c6b3eaba34ba33eb5ae29fd8ea6e3c6b")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/package.fasl"
   :FASL-MD5 "a109d279c5decdcd9230efbc9766d15b")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "9b2a00902f9e030bdb3863e55659bd75")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "702999fef06a39603d6a5cf15436705a")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "33d3fb5eb92673ffc4b5cd3b50fb4c68")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "9925c276e34d4d09026070054c5db834")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "c6f9828c77c0b7ea348d86453cb65925")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "94b554d2ba4c4ff46cf1c4b50a0e635d")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "285fa879a46dff092313760bcb04a47f")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "fd6dcb887f7aa66cc70c95b5dee45e33")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/types.fasl"
   :FASL-MD5 "67278fde0abb6dfca64b336faa91bb0e")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/transfer.fasl"
   :FASL-MD5 "947c28c2f1af00db6406516a53b362e3")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/package.fasl"
   :FASL-MD5 "631b86931090b26f34f499762478b68c")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/native.fasl"
   :FASL-MD5 "d7658bd01dfe842efad6197cfa7b3753")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "3dff79f42192b41624cfca742ed628e0")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/identity.fasl"
   :FASL-MD5 "3b821aa23cd100ab893882376e0e6fbb")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "794880c3a6d7d02db14962dd1237804d")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/flush.fasl"
   :FASL-MD5 "bd04dd0b0dc384d88ff754bf4f8635c3")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/write.fasl"
   :FASL-MD5 "695c1eeea27738943abea443c404a545")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/validation.fasl"
   :FASL-MD5 "7b2658e9c2c384a86e4a8e6a4bc7e3c0")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/types.fasl"
   :FASL-MD5 "787c4cf1ae2105784e09da01546d324b")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/relocate.fasl"
   :FASL-MD5 "3c43474ff308df4e2bc487835ee42aaa")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "694edca9f769612cdd541516c9e4cee0")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "b875b9b05be2403b41fac24fce1d7a65")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "6adbc633f1bc6a544a87cefbb1770399")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "4a4c2918a1ab673d7efba8618cc9838f")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/read.fasl"
   :FASL-MD5 "a7a835fd91e00e944deab77207ef2157")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "05981a187940fd3867618a541038449b")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "5cecfcdfb79afe910948ccaf5842a017")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "9d9a94c1bd0c4e47a4c2bb287607f535")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "2ed093751a091400901a69340e9f9981")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "04af8b6111fca45bc1c3429d31657c26")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "dde2ede7d9d9f4ace027247720dd5ec6")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "e34c272d9877c3a8691a79750a0cece3")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "183b24a21fbc901bb73f1b502a896509")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "7acf9e4c076d3cebaabcdcd4bfcb4b54")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "84a4ed33cec8a48dca6f70b2dde6ae51")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/package.fasl"
   :FASL-MD5 "702d202383bd367ce24e9a718432eb3f")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "dc41fbcc2100a2fa8ff85c52e80c57f3")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "ce1656b9bf39ea4e608ab7fcc7d1b753")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/core.fasl"
   :FASL-MD5 "2cf416c4824e621820c340dbd1fb37da")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/package.fasl"
   :FASL-MD5 "64bd27a5a6b694ffa63ca231347ba155")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "4e9fe4356fd7507c7c0590e274c67d49")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "3cca22c56395a538ea158c3569430d4b")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "6c87b4cab226e499c266104f5d440ee2")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/types.fasl"
   :FASL-MD5 "b78dbe45b71cafbcc0ee5150ce42162a")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/target.fasl"
   :FASL-MD5 "7dbc9036bff6e5904381c0ff77b2df65")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/segment.fasl"
   :FASL-MD5 "0b89a766cb9d28746758cd59e2a58372")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/package.fasl"
   :FASL-MD5 "64fbf5f81f404d912a5a645c97c4d1f4")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/lookup.fasl"
   :FASL-MD5 "79e12ca0580c843f52ba93d98bb96552")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "3140facb12d81d3e7bb94093fd38a012")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/build.fasl"
   :FASL-MD5 "11a85e7ace500fd08f5309292200a983")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "b205fc4ff5d9ee4cd18f0cf15ab67a82")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "0d10b2a603b4888bdccadecc49aed188")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "648a02c4f36d42126f52f51e99ecfd74")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "93d44e0077099f12be334338abb5570d")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "c9d02ad3fa93b5b9e164924818739435")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "c60f3dac597664bcb9bf3a2810a4c665")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "c5d92260f5a50152d1a629d00406f0e6")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "e9a20d8c66f110a83a266df283ee1238")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "cf74a0e6de79a573cbee75674dc2d2ad")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "521737861e057d663964b0c030552587" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "f412ec6711fa62cf25a2ffcf44c6fe91")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "b9f5dcdfce2704ffb3749a062eea4638")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "41f8e97fd2c4ab6b46c0200dc737d316")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "b2c5f90a359e774e3efb0c6a96c203ae")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "bda6d076db3a8c635929ac557ea4d3a4")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "84ea201b2f181bd1680d21a3ed2c1558")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "f308c6780bdb4e3839a67eb57e0bbcba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "ef6048269c9f9e01ee0bcc4214605507")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "da569ec97ca89a842bba5d9efc2ecf84")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "c61b219ad7603b82b353500c94300772")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "8a4ab414b47860602f578cb26a7c7e28")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/record.fasl"
   :FASL-MD5 "cca6b44905a142f117d8e9c4792909e9")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/package.fasl"
   :FASL-MD5 "25465a4e463e92cb7d040f7bafce60b5")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "4cec568c55ff36a2904ff80fbbede141")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "ee338aba7017eff4fb6c0ccf9cc99d22")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "4c024353cee11f6f7e6196afd507c92e")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "a70713ac98b858e7afde94f684f95e24")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/writer.fasl"
   :FASL-MD5 "ed594795af8efe5af5acd8406d5c3e66")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "a1271323e7b917a7531a632706a6a44c")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "07f16c8b1cfdd4ab4955204d2d72a662")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "51bcad465720d7821073e31593c9b179")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "59786c40c9bf86a62fb5d0b60041d29f")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/ready.fasl"
   :FASL-MD5 "3f9bf83b95ecee71570d42329ab79ec9")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "5e23001bbe9bddcaade3598b37a2f2f1")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "7d32f45935a208f49a268e5b7d6dc623")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/queue.fasl"
   :FASL-MD5 "ce454496f892afb80510c5d16bd21789")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/package.fasl"
   :FASL-MD5 "8ea5e081a8134dc23fefa0555626edf3")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "1bfc0fd9eb2b82df3855d00f45b38d8d")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/types.fasl"
   :FASL-MD5 "771e706a895e56fbf4d036d62b277189")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "967daf85004213f2cab403fdaa905f86")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "c5e28bfe206e17052ef865f20d77e935")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/read.fasl"
   :FASL-MD5 "c768a3a4da104c29424b213b3f24368d")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/package.fasl"
   :FASL-MD5 "2aeed001308b43f1a8994beb26725f05")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/core.fasl"
   :FASL-MD5 "754ef8d8ecffefa4eb412fbb77c4bbb3")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/csn/registry.fasl"
   :FASL-MD5 "8104d7ec070f928974b34993ffaa2947")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/csn/package.fasl"
   :FASL-MD5 "28746fca90c665a9509dda0c5f16fb5c")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "f06c32b336f0739ba4d5c21dde6abf31")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/package.fasl"
   :FASL-MD5 "3fe3560f6bfa093f6e98ebac1e6c0f6e")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "2ff5146f11bd97f4cb428fdf4c966607")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "b8725771e2fc0d22fc692ac1d8104b2a")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "5c421545ee3faa99cff4389805f609d7")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "22698e923e2c9deaa645b2c6bd116638")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "0c2329d9ca8a3364c1afd983ba80700e")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "e1eaad874f270d42867bdf2041c666d5")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "346d4016fe7a8d280df5d6452426c783")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "3098a1b967c8122cd41e94ea46e087c0")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "74ea09eb40b3b829aae6d32a874d460b")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "ee58cfe21cff575346ab5f9f8e2dfa8a")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "d39761ec81495cb2a21f81d61258c344")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "3c8d433aca37a7f934d4b8272f1973b3")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "d06075d6e30101da39949ccf84b33571")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/write.fasl"
   :FASL-MD5 "a7fef4c03f9b1ae69d33ac39fca0040d")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/types.fasl"
   :FASL-MD5 "cfc7005c726ba8e04281f44e81e04516")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/read.fasl"
   :FASL-MD5 "53a5d5e145f0d224ff9c83caf8f82dcb")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/package.fasl"
   :FASL-MD5 "e386beec73e880b418528da9e745b937")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/core.fasl"
   :FASL-MD5 "b53364e81defa42bb15b8e020c4d4502")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/clock.fasl"
   :FASL-MD5 "0ba6a64031d10990e341b5676bdb49dd")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/build.fasl"
   :FASL-MD5 "b9bb326034187c88b4e2e26ead21c071"))
 :EXPECTED-TESTS
 ("TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED" :FAILURE-KIND
 :ASSERTION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "1c847de175f4954cec5ef2186308f1a7")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "f308c6780bdb4e3839a67eb57e0bbcba")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
