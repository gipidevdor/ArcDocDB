(:FINISHED-AT-UNIVERSAL-TIME 4000908066 :CONDITION-TYPE "SIMPLE-ERROR"
 :DIAGNOSTIC "Asserzione fallita: (EQUAL
                     (LIST
                      (ARCDOCDB.GET.RESOLVER::SORGENTE-GET-ATTIVA-SEGMENT
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-FIXTURE-SOURCE
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      176 0 NIL)
                     (MULTIPLE-VALUE-LIST
                      (ARCDOCDB.GET.RESOLVER:RISOLVI-CANDIDATO-RADICE-ATTIVA-GET
                       ARCDOCDB.GET.DIRECTORY.TESTS::CONTEXT
                       ARCDOCDB.GET.DIRECTORY.TESTS::CAPTURED)))"
 :SCHEMA-VERSION 1 :KIND :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE
 :TESTS :COMPILED T :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "3e565b431b88fb5211023601b5e3ce3b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "f5f107799a0dbfeeaf905b8bcd691238")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "25734bd051689adf5629455af5f1ec68")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "76b876402b64cff0dc642415f9822b39")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "2928f72dbf001e5763d8fa6abd2cea0a")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "d1d3444ac3518d78620100ad720f2b5d")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "5dc9cc51598c1d48bf3e154c7c0d0a56")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "de160b55985033b582858e6a3bf92503")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/types.fasl"
   :FASL-MD5 "532c4f9e787e7344b042399280edb719")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/package.fasl"
   :FASL-MD5 "9cc1c413d61c6fb20c67c61b95d78a4d")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/group.fasl"
   :FASL-MD5 "c879e617d093d60ea85a5233cd24b78d")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/executor.fasl"
   :FASL-MD5 "cf9b704155ddf4c332a88facf3e5a83e")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/csn.fasl"
   :FASL-MD5 "e7753198238d46359cf259e5bfc1061a")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/builder.fasl"
   :FASL-MD5 "dff06a6c412ac2f2e66466c33d7914fe")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "db1d76ef6dbd2fb55e5248cc0a9e3a55")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "8ebb2355524953f4330bda53a54d8a9c")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "e3dc3c4b60dc39bad8de343b3c0a73da")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/package.fasl"
   :FASL-MD5 "fdd97becbdb77c580383715d604ea0fc")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "16cb172eefc542409382e1d128010fb8")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/formats.fasl"
   :FASL-MD5 "e007f57bb72bb043bd85c6136e6739e0")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "d2495a06fd4f23ec1d60df05ebfbd27c")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "06a04b12034e24b4aa5a47b68e514fd6")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "eb247e7d2848a58180ffdea5287561af")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "e2bf013f4adcb59acffb24def585b595")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "bc78b5593e050c3f5aa60632ddb7fdb4")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "62865c1feaf1adabc004ffeb2c70cf7e")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/types.fasl"
   :FASL-MD5 "1cf8848457f3480f689da7a95b89d37d")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "fe379bbc92e585e4ab12a386a1770bed")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "254b1ff3fe85c7028f4560a87fae2588")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "1017b6ba40c6168ea80e1e55e6a92ce7")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/retirement.fasl"
   :FASL-MD5 "55c9a4539bd456e04271a17f9cbefbbc")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/query.fasl"
   :FASL-MD5 "886c157c00a2d169bc61d8514c3f7b31")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/publication.fasl"
   :FASL-MD5 "706ae5c799ba0b7aecba46f0363bff33")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/package.fasl"
   :FASL-MD5 "7fee127ed78199d666a61fada76c7611")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/ownership.fasl"
   :FASL-MD5 "e16a32bfd359dc39f05586520ae7b98f")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/io-events.fasl"
   :FASL-MD5 "b227f50f0f95c5b6aebf47974dfa12c7")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/events.fasl"
   :FASL-MD5 "c04daf983c64b8d927e9175cfab7453b")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "5bfba99c32b7dc02d161dac606d799e8")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/package.fasl"
   :FASL-MD5 "1b6069576067399d7ff95062922a9203")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "cdcdffcf935a5a4d74f34922df7d8750")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "8e49ea746025b01ed550f2d42631c413")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "cb240a3728b3353de1aaa812f796e397")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "f6ef1597f82888aea7b98deedc924e49")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "cd3054a1c64c2daad6bf371fccc41b53")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "70f3e80bb7ca45cdbc604080c63df786")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "20515f85d6d8469348ab8a59a21527ce")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "e07be07c15099da2f65062ee45ff3787")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "3a25e80e9687a50b959f0d8ab187cb5d")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "3f4428bca72ffeb748028c5234378109")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "bc44d2e6348984389d429e06e2fe764b")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "96d45ec2a46c7b3d370cf96a0e5e5b70")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "60425149878c4f2ba4082533344094bb")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "755eea19da70b6cca29ef8f27d07d52a")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "3c84e76ae793a42044cab1ee1448d8d9")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/types.fasl"
   :FASL-MD5 "a4812cd49dc546641a1fa777d8fe79f6")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/task.fasl"
   :FASL-MD5 "828fd2d62f49a4e5e4a14f50c82fb4df")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/package.fasl"
   :FASL-MD5 "70a13522a8097c298c06964cd515e464")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/core.fasl"
   :FASL-MD5 "5d173dacd04ee23e81b51ac6f45e4ddb")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/package.fasl"
   :FASL-MD5 "3b036b2715250c346500853877f620ea")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "bf55cdc7a18592b3ec94b22a620daa80")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "01427efc8b937f1bd1f23cafb5bf8cff")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "b25fb3f87d85e4d31063807d0c7bad58")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "08130651fc082e966e5610937fe9cac3")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "f232681d0f7c6b536e07f751bc622745")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "1f9a04b89b33b79c9549f76cc5d5ee72")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "919378dd66d78486f748794118d89eca")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "271b9357bd7822d3627def4526e2c4d9")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/types.fasl"
   :FASL-MD5 "1eefc99d5c9a11c2d09de549ce8e08bd")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/transfer.fasl"
   :FASL-MD5 "acd18c28742e08484d367ca97f73805f")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/package.fasl"
   :FASL-MD5 "f53b2eb5dc38ee8cbae7a5c6325534a3")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/native.fasl"
   :FASL-MD5 "f5c651d4175ae752c12ba41dc05c3a25")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "bf930aeec1514238a3a192aab511382c")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/identity.fasl"
   :FASL-MD5 "32e71a4e3cfa10642d878d9799b94bc0")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "d0f7e48eebf5b71dda17b583dfabe7d5")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/flush.fasl"
   :FASL-MD5 "d80678fc35989341e42dce75f96cb5cc")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/write.fasl"
   :FASL-MD5 "896cfe39518e7549e4e7bd034cc65bf2")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/validation.fasl"
   :FASL-MD5 "e84ef3ebdc33fa6d9a76a5db1ce0ecd5")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/types.fasl"
   :FASL-MD5 "c1689d49b2a9f38b7f8e90f92cb30aaa")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/relocate.fasl"
   :FASL-MD5 "7e74404f5cf624cce9a9eb96abf61c92")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "0113368aa2b0871393e7be3c12e4efeb")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "a75c6df66f38549ab08b287f3963f0b9")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "3b8bb956813f897849329fbcefd519d6")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "351b5d966afdcae68155a9948da32ad2")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/read.fasl"
   :FASL-MD5 "1bbb7cbd3134e7b5a950120cda2358f5")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "cb81faae9c82cd96707adc67371ce0b6")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "83299b582312518a0945068499a851d3")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "b2c2ccf169d0aed5620b291395172112")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "6edf6b253f57487824fe8a72f9f386d8")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "176733952479a673545576ed8c423faf")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "c4a30cc44cb333febc28ee19f101910c")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "69ac58f0b5365225f38c9b2ba04543e9")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "0e25f34b3fbcc948968788600b81d49e")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "326f36c4802e602a55845b378b0c07c0")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "c6e2d39a219690a933f5d06c6df7731f")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/package.fasl"
   :FASL-MD5 "c10bf679ffd4f648825db99af7617d6e")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "ca19f7e47d1953b447d16d7a5588a729")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "0f2646e2f3109a0e73c2f5b56bd79c3d")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/core.fasl"
   :FASL-MD5 "55021679b8206f6d36cd9b37f1ebb85f")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/package.fasl"
   :FASL-MD5 "bf83a54269a7730dc3449d59468517fb")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "3d7eadc18a908ee37760a1bf7192d15f")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "97ed631c1f92b3f7c542a7e5788a70b0")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "d2b429fa29923a58f5d9fa24d1f1e375")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/types.fasl"
   :FASL-MD5 "acfb8e7b43a60dc5a3375b8975641d45")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/target.fasl"
   :FASL-MD5 "ed9071b4250082fa90b9aab8202d05da")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/segment.fasl"
   :FASL-MD5 "f3af54478f540e12bdff23de370fb1a2")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/package.fasl"
   :FASL-MD5 "486bb1875ae2615d65d5b3aaea7a880f")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/lookup.fasl"
   :FASL-MD5 "c182e60cd62106753c482378736584cd")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "14178a64810db990df4c28fcf97ce03b")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/build.fasl"
   :FASL-MD5 "fcfb5c38162e049bf67ad096271551f0")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "aa14bb000e34b9503ffa080acbb9d0c2")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "8347a810a97da07d328b0139c0b32c87")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "a66b79a285de8bf34fc1a4f43ad5cdf3")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "4115f10ae02133fa3017ac5ccc027b5e")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "b25748dd7ac38591c5f984b8afd19adf")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "f3ee3ce870ade34466c8f1557a76fa3a")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "29b70896c33cd819e14c5449a982d20c")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "9f867ea0c21aef0c29622a58eab76d25")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "c518c6b2c4a995e07770b81e4d71de48")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "96f146f885377c6d102c0af49f05bfae" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "a557b67afa5d3fb672d85ad79202bb96")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "01026e63d4c6a65832531624c3704730")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "513c537bc8e7d8b238467acef9e8a853")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "2a159738fa60671ed8a682cd633b16ba")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "0074f8876538697b9b6cb8f6bf1b8378")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "75fc6d229d7464e52e5c7b26dd9dae13")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "2b8193aab6801de19e26fa55e7c53f87" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "70edb666517a3a5e9d13492b3371330e")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "e6927113d1c86b040d6b6ec1356f2fe3")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "9c4e0292bdc600f060691f71ed291703")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "b1ee11f52815f1d2546db62ee103d226")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/record.fasl"
   :FASL-MD5 "fda7acaeaf36b3a9dcb0af25cc9a6457")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/package.fasl"
   :FASL-MD5 "827659d1c89684d4d2f826678d24c4bd")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "bcd0f1f69647037d41bd9db60823bb14")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "3ef7d79e7ae0612689c196aa7ae82ca4")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "ad486d916de5d1751057834b77692595")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "1c99f1d42daa53506d80c4dd987cbea0")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/writer.fasl"
   :FASL-MD5 "f4fef2937743d150e9a8b8cf727a9618")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "81e7a7e78e4e27ae47c520a3ed4e3bac")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "6870340f5bb1e47e2bf5434361aa2e9d")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "7ba21d896c9f9861255baeaef6397e49")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "944d560973a40c47e1bc42c363dc0cbf")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/ready.fasl"
   :FASL-MD5 "615888623733996b6b035a73948b023e")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "e897a284ae7a345bd723eaef68a2e036")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "111b2e8288a74f2784d9c4a76bc601b2")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/queue.fasl"
   :FASL-MD5 "c0a7ec23d928e5cb8c2232e76491bd19")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/package.fasl"
   :FASL-MD5 "c9a5f67aa0dbca5047e5699d20586b22")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "964bf8c2f28ed653b9dd04e0d6ddd1a3")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/types.fasl"
   :FASL-MD5 "5e51a147450af45518b1d1e5a83b59f1")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "638a56f2f57a7e55578b30af106b7f9f")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "1f028dafc6cda8b029d5050d9e4564ee")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/read.fasl"
   :FASL-MD5 "062a8d635865585e06422d101b7355c6")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/package.fasl"
   :FASL-MD5 "16f0eb709de3d81f7ceb895de61e76b6")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/core.fasl"
   :FASL-MD5 "53f7aec90f7485e74e27cff594dcad87")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/csn/registry.fasl"
   :FASL-MD5 "cde3ff04e0b4eff84d47792b4c9063c2")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/csn/package.fasl"
   :FASL-MD5 "2cb9f16c62f0f296dad206920610a6c3")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "8ef52faa5a0d83b9c4cda99f472a74cf")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/package.fasl"
   :FASL-MD5 "3163a8eaa3578394949e58109ad751ae")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "1a9bac1a1597c3b2ee7e5fce4c0d3d1b")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "a06b35d37ae344410a71135c5de4a969")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "3e1782dad78ab5f5e7d74588494f2c33")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "4119e0c053860eb5b8d476a158cbd4a9")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "40ed85132828e6f2ea0c1a3c4e673bdd")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "996add00ecd2003b3f9e2d5a2036290e")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "14775e0cf50d78e6ae7ce66b5318bcae")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "bd4ce4e067d4424c910d93bef867fe19")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "2deaa27a8827815f48eeba6c8e78612e")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "7fe58ec1366269f661018d6fe28f7b08")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "e76e2458eafe07d86f6bcfa72817b618")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "ee1b5e541f372241b6fafb7dd186802a")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "707babf4dbbdab11daaeee5cf42934e5")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/write.fasl"
   :FASL-MD5 "58c41bb86c5f3aae6bb3da9d45488f53")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/types.fasl"
   :FASL-MD5 "d57413162f067d1474054c74878e122b")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/read.fasl"
   :FASL-MD5 "64387e566ff654bcde941832f0a2b460")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/package.fasl"
   :FASL-MD5 "482568cbda595ec32561ba87f4f751ec")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/core.fasl"
   :FASL-MD5 "3b2b9253749fd297be0091e0da9be48e")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/clock.fasl"
   :FASL-MD5 "ab526343144b19659d232af64f7e334f")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/build.fasl"
   :FASL-MD5 "f8640f2d13232f40e454dd1ab8ce4422"))
 :EXPECTED-TESTS
 ("TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
 :FAILURE-KIND :ASSERTION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "1c847de175f4954cec5ef2186308f1a7")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "2b8193aab6801de19e26fa55e7c53f87")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "96f146f885377c6d102c0af49f05bfae")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
