(:CHILD-REPORT
 (:FINISHED-AT-UNIVERSAL-TIME 4000908041 :SCHEMA-VERSION 1 :KIND
  :GET-SERIES-MUTATION-CHILD :STATUS :OK :PHASE :COMPLETE :COMPILED T
  :SUITE-COMPILED T :COMPILED-FILES
  ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
    "3e565b431b88fb5211023601b5e3ce3b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/series-read.fasl"
    :FASL-MD5 "171a7eb79e83f997784ff47b533f34b6")
   (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
    "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/series-support.fasl"
    :FASL-MD5 "58a1821f54dee6521a073c2b4371c5df")
   (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
    "63dd01c852de1399c2c82274d481d257" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/threads.fasl"
    :FASL-MD5 "d604a05572d538f92518419ad4a1db63")
   (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
    "d1ab36d05cc1266e4533d27c693f12f4" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/read.fasl"
    :FASL-MD5 "6d5104761e0441e2515d130d26a8b05b")
   (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
    "1137938073e71d6d8d62c751fbad05d5" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/construction.fasl"
    :FASL-MD5 "ff9f187d6c79dd70e79076bc4d2b5254")
   (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
    "3f868ebe4307ad4238b314c37eceed9a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/tests/get-directory/support.fasl"
    :FASL-MD5 "2011511c90b4546f85ad47d79b4d2864")
   (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
    "758adad069aec2f9dbe0635797314ff6" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/tests/foundation/support.fasl"
    :FASL-MD5 "fb149e855c4ced0f67c1e3f9a322da84")
   (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/types.fasl"
    :FASL-MD5 "19cd62be6fd87494b9cb5a35201c618e")
   (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/package.fasl"
    :FASL-MD5 "d6cfa645190bb5fa451d8fc58cf7119d")
   (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/group.fasl"
    :FASL-MD5 "f78945201c14a2b062716dd1549c17b5")
   (:FILE "src/wal/executor.lisp" :SOURCE-MD5
    "c0340924c9130e14d0e8efedeec078f1" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/executor.fasl"
    :FASL-MD5 "c9d5d57c58ce9af35e886d1237f5f154")
   (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/csn.fasl"
    :FASL-MD5 "79a3ca0684479ac3b580649b6ddfc028")
   (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/wal/builder.fasl"
    :FASL-MD5 "cb79600946435120bd96792255780a31")
   (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
    "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/segment-header.fasl"
    :FASL-MD5 "978dfee784b6570384aa996c077cce9c")
   (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
    "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/payload-write.fasl"
    :FASL-MD5 "1254fa1c1e51d7ad98d98cd69745e429")
   (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
    "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/payload-record.fasl"
    :FASL-MD5 "a88212967dd5b3374cf8a49e05cf266e")
   (:FILE "src/storage/package.lisp" :SOURCE-MD5
    "f86bd104f20616a76b42c02227f72844" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/package.fasl"
    :FASL-MD5 "1cb6a99c14a807db55ff76aa9898b5bf")
   (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
    "b53d27dcc9f4badf18b50519c50bc614" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/log-header.fasl"
    :FASL-MD5 "d54f7d6b61b66d973806a8407d742089")
   (:FILE "src/storage/formats.lisp" :SOURCE-MD5
    "061147be459d8d3b08c661bd3f91d152" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/formats.fasl"
    :FASL-MD5 "9cb997dc3c638606b1fd169b368fb567")
   (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
    "cb64f806b8d69eb42d865b4abfff0b27" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/control-payload.fasl"
    :FASL-MD5 "4753855e72ad024822d4bdfb1fdcb0bd")
   (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
    "1cda77a357ab2147035993b72d135a37" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/storage/compaction-scan.fasl"
    :FASL-MD5 "93ed771efe1fb19c5ee3fd9a3f55c587")
   (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
    "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/worker-types.fasl"
    :FASL-MD5 "7b01b9540a7ed3fda439f9335b3e17fa")
   (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
    "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/worker-run.fasl"
    :FASL-MD5 "c690b5ffa5d9d39afb539075f537e06b")
   (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
    "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/worker-package.fasl"
    :FASL-MD5 "14460c0152ddc157c09ba2acb1edf25b")
   (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
    "2340e0c9074f7b1bf80c74f774986bc5" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/worker-boundary.fasl"
    :FASL-MD5 "db6255e8ba4902dc2568c5c746f8553b")
   (:FILE "src/series/types.lisp" :SOURCE-MD5
    "ab19ec8d15af91511e817858c41cebc8" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/types.fasl"
    :FASL-MD5 "b68c6049d297c290252954953ff88944")
   (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
    "ce649df47dd38888d5103c98345f7e41" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/routing-types.fasl"
    :FASL-MD5 "486e12423575313c8413f8a52f67dbdb")
   (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
    "e0f987d8767744050ec4d1b3ecb699ed" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/routing-select.fasl"
    :FASL-MD5 "673021522da5449075cf837a61fdd5b0")
   (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
    "d6924deff152b941bd49f0bb200b4197" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/routing-build.fasl"
    :FASL-MD5 "ba33a022e6f27c6772073c0fc400efe5")
   (:FILE "src/series/retirement.lisp" :SOURCE-MD5
    "b8e04971b8ad75a1bd0c722997badfd2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/retirement.fasl"
    :FASL-MD5 "497d7535d91cfd2a0d9340675ad30a7d")
   (:FILE "src/series/query.lisp" :SOURCE-MD5
    "cb0d91405325b508e6b2ab24d178de7a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/query.fasl"
    :FASL-MD5 "ad6436eeeb296ad395a975f0cfee7198")
   (:FILE "src/series/publication.lisp" :SOURCE-MD5
    "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/publication.fasl"
    :FASL-MD5 "a41f11633f06cf1c8c88d20387aef33f")
   (:FILE "src/series/package.lisp" :SOURCE-MD5
    "59e3c59c90d8d0fc5731b87496a785aa" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/package.fasl"
    :FASL-MD5 "b3d6bc3953c5a7742da2604c0f152f78")
   (:FILE "src/series/ownership.lisp" :SOURCE-MD5
    "de1aca16a35d34d16aba12ff541c0d2b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/ownership.fasl"
    :FASL-MD5 "5a77af65ffa69f2a53cb0c56db56254b")
   (:FILE "src/series/io-events.lisp" :SOURCE-MD5
    "b6026a8b7bb64b45c37a65effda70d8e" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/io-events.fasl"
    :FASL-MD5 "3574d8abde106f55e10d5a789a406eaa")
   (:FILE "src/series/events.lisp" :SOURCE-MD5
    "32b2156739a6f2ca996abb91df0a2603" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/series/events.fasl"
    :FASL-MD5 "a3d96263dd8dee749857e1c233b35c26")
   (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
    "fcacd15460db25ea9cc4036065f9f096" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/scan.fasl"
    :FASL-MD5 "c3d56d7a3750094a230b60288dc8ba39")
   (:FILE "src/recovery/package.lisp" :SOURCE-MD5
    "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/package.fasl"
    :FASL-MD5 "67f0374c16d5d3bbab182807c7351c2a")
   (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
    "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-types.fasl"
    :FASL-MD5 "98e1ea57f3ec67c23ff9363fabdbcd69")
   (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
    "ebd7a54adea2213294a887e6d4db0927" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-query.fasl"
    :FASL-MD5 "13abd93b2e8d27b432eea281f20f6923")
   (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
    "37ace42844c11b52446ee1fc500b8e0b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-package.fasl"
    :FASL-MD5 "6944589d95267fdcf1a5edb5e0f79b55")
   (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
    "e0d2498db1011e857b7b0daa1934f187" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-fold.fasl"
    :FASL-MD5 "c2f8cec1efc814b6732bd146c96950c6")
   (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
    "67975249aaabd751757cdfb9222cc3c4" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-decode.fasl"
    :FASL-MD5 "d5eebe28b205a26d2295e25f31cd10f5")
   (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
    "bf65b1731eab6e0572461ef5cc60fc40" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/manifest-build.fasl"
    :FASL-MD5 "a45f50f4a1089b1e869d5fb61d04b779")
   (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
    "78c136d5838dcfe3019d9069643a8d8f" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/inventory-types.fasl"
    :FASL-MD5 "90a2539d0a19e82f45aa962cf2150b9a")
   (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
    "fcea263de1938767772e5b11411ecd5e" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/inventory-query.fasl"
    :FASL-MD5 "164f1b129f47855dfd833c8ab970275e")
   (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
    "9bd6820c4feba3e552aab1a4edd87861" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/inventory-build.fasl"
    :FASL-MD5 "b7327a888b4a5198cf48395cf640a935")
   (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
    "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-types.fasl"
    :FASL-MD5 "aee10a028e38fff7a2dc4c6889e40f90")
   (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
    "b33e57a643f2fca810846f6226366253" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-sort.fasl"
    :FASL-MD5 "b9791a7ac71b47972027b8987a23293a")
   (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
    "852149de4c289b8e067602780378d87a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-radix.fasl"
    :FASL-MD5 "46e3e44d194d01cddafd38d239b6cdb3")
   (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
    "f782d1137b8ce342b91c9999cfb7accc" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-query.fasl"
    :FASL-MD5 "b908fbe50d92d9e7efef145945354a3c")
   (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
    "cbdc30f93109c474e1fc25066c9b9b13" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-package.fasl"
    :FASL-MD5 "e3e1bbc19e441906f79101b07875aa15")
   (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
    "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/recovery/decisions-build.fasl"
    :FASL-MD5 "a6abc0e9bf4d8e1562301f7094787b5f")
   (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/read/types.fasl"
    :FASL-MD5 "e0047f9a572b5edae0362f2956c9d376")
   (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/read/task.fasl"
    :FASL-MD5 "593e9d1b4d8127934559ecf91a9399f8")
   (:FILE "src/read/package.lisp" :SOURCE-MD5
    "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/read/package.fasl"
    :FASL-MD5 "7df771292897c8b11e4d5f6e30a396af")
   (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/read/core.fasl"
    :FASL-MD5 "e9f278037f870736d5854d6ad9085556")
   (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/package.fasl"
    :FASL-MD5 "4ece8b61ff28cc0147d1a1d971c94912")
   (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/types.fasl"
    :FASL-MD5 "32511783c0045288db4f2b1fdd56b42a")
   (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
    "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-types.fasl"
    :FASL-MD5 "af0d9838392bd77326d3e74e947acf9b")
   (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
    "2d5a795bcefd605c75da91c725ae83a2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-register.fasl"
    :FASL-MD5 "02e8bfc665795329c7e7a127a9504d93")
   (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
    "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-read.fasl"
    :FASL-MD5 "45652e3e4cf3025788c439740d29b605")
   (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
    "ff98aea5cb9a7ae2671f6a887a003725" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-lifecycle.fasl"
    :FASL-MD5 "730e51e802bf7cb340accf69c52cfcc1")
   (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
    "0e9365e674d1584b111f915ce1f58634" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-csn.fasl"
    :FASL-MD5 "0651bf8a9ab2d62ad5edc73b5ec19ec7")
   (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
    "8bb066aab61a18eff175b9edb11e42a2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-core.fasl"
    :FASL-MD5 "a6bcf015a151714572509d55e00f1a51")
   (:FILE "src/mvcc/package.lisp" :SOURCE-MD5
    "f188d1dbd5d0adb49f53acf09157aef9" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/mvcc/package.fasl"
    :FASL-MD5 "acfd6ce4cb48eee768a428e622c034e2")
   (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/io/types.fasl"
    :FASL-MD5 "d0d9fa06853c806e5df8ac80e111a858")
   (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/io/transfer.fasl"
    :FASL-MD5 "cfdedc3bb74ae1913bde5b7209979a06")
   (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/io/package.fasl"
    :FASL-MD5 "46b1ef9925905dddd191f0f6b2c78c40")
   (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/io/native.fasl"
    :FASL-MD5 "54e34dc22938f71bc26cb653ce1c7df8")
   (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5
    "11c7103efbe733bbf0a13927f23c3d34" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/io/lifecycle.fasl"
    :FASL-MD5 "23fe5bd446b027f45df04e58ee31e86c")
   (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/io/identity.fasl"
    :FASL-MD5 "5305befa29c23fb59f492f434beeb0fa")
   (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
    "d354a095fb378c1b6f27397ffb902227" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/io/identity-types.fasl"
    :FASL-MD5 "67fb3eff50421ef748481cac87bf2b5d")
   (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/io/flush.fasl"
    :FASL-MD5 "ad3537e62bc79078c673cb9b1b0dd038")
   (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/write.fasl"
    :FASL-MD5 "82be12ca11bdc838a0fbd735cda7967e")
   (:FILE "src/index/validation.lisp" :SOURCE-MD5
    "3384cadf737c7d80c004222022a281f6" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/validation.fasl"
    :FASL-MD5 "8c9c9e66eac82cf8680cf350eef7ead9")
   (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/types.fasl"
    :FASL-MD5 "ef067a8c6fd89055fc024d90246e73ba")
   (:FILE "src/index/relocate.lisp" :SOURCE-MD5
    "475dd7d5809a836f01544b447cc8df27" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/relocate.fasl"
    :FASL-MD5 "ffe81cc82d100b1b2c7c48846a9f55b2")
   (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
    "a450cac8071513365267e7024cbe94b0" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/rebuild.fasl"
    :FASL-MD5 "f4f41f6682489e42966590cce139d4ca")
   (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
    "1188e7a64a7a5d9482c1233cb9acb452" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/rebuild-scan.fasl"
    :FASL-MD5 "71a1c70f7daed91968e7d0235f24bbbd")
   (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
    "8befbbd00ed5c31c1487a11887eba495" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/rebuild-copy.fasl"
    :FASL-MD5 "5f5bd7d2352a947a53feea5ecc0281f9")
   (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
    "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/rebuild-budget.fasl"
    :FASL-MD5 "af19ed93ce10f23e7e856878346f51c5")
   (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/read.fasl"
    :FASL-MD5 "9739528bd53e94154f9f0fa78cfedf98")
   (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
    "e8e31e599356e592af29c0cc4604872b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-write.fasl"
    :FASL-MD5 "35a16158969967d670b263b897ec30e7")
   (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
    "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-types.fasl"
    :FASL-MD5 "4725324b697916c669a8926048b1b9a0")
   (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
    "5155959766645d3172ae5e73c58cc071" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-relocate.fasl"
    :FASL-MD5 "abd63c427044284d939963cc4179fdfa")
   (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
    "3f317a0d3c5ee86a73651aad36135cc3" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-read.fasl"
    :FASL-MD5 "858c20ae9dc3dee846bef434bc8bcfb0")
   (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
    "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-probe.fasl"
    :FASL-MD5 "8d4626f6a70feb9a3b4491210c60513b")
   (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
    "d65cfce399b04f905bf969929962e59a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-package.fasl"
    :FASL-MD5 "6b4404d39d2beea74a21684eb3d9d277")
   (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
    "1dd67c527257e43f17e006644ecdbd00" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-directory.fasl"
    :FASL-MD5 "9338fdd1e64a5fa3a97049ac8b96ce78")
   (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
    "fa52433eae199ceeb874bf2bc47afca7" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-core.fasl"
    :FASL-MD5 "6b9c2cc5c22a16dde13a7dd16e8062ec")
   (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
    "ff2cfbb865290d7a1510fdf6877c7229" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-build.fasl"
    :FASL-MD5 "32cb552cd6617f6133575bcdd03155c6")
   (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
    "a319691e3e28b7ea7b927de490cf69ba" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/primary-arena.fasl"
    :FASL-MD5 "a7a75bdc35f58c501ae4f528560e01f2")
   (:FILE "src/index/package.lisp" :SOURCE-MD5
    "598a9b65e73151c924b2cdcaf6d96705" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/package.fasl"
    :FASL-MD5 "b22403aff34c386d67daae8df33b42fe")
   (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
    "45ce41749bc6fa638539815d3f802b96" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/hash-seed.fasl"
    :FASL-MD5 "69f5cced18552e62144e3e0b77b7d400")
   (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
    "43d2209225707352daec6186ef95a805" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/hash-digests.fasl"
    :FASL-MD5 "41bcf2bce106ec2d4f198a2c819e4982")
   (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/index/core.fasl"
    :FASL-MD5 "21be10bd02ccf8fe15a0bdd4dac447d0")
   (:FILE "src/hash/package.lisp" :SOURCE-MD5
    "2d9060e41bc5252067d35e59ac70ee06" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/hash/package.fasl"
    :FASL-MD5 "35b15bf757f1581d410408bd8ee86809")
   (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/hash/hash64.fasl"
    :FASL-MD5 "85b2f4905cd537ca7c39e87ec42fe848")
   (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/hash/blocks.fasl"
    :FASL-MD5 "a8bde115bdd7ffca4d5b8f8d0a364864")
   (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
    "b5c51802e607e3dd22de68204baf64e9" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/hash/arithmetic.fasl"
    :FASL-MD5 "e4cf84fd49a3d5ddf69baf026c256133")
   (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get/types.fasl"
    :FASL-MD5 "d144e6296fc5dc5acaeff5fe93250fb8")
   (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get/target.fasl"
    :FASL-MD5 "4b2279d12f310483f1b7b4bfd941e7ec")
   (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get/segment.fasl"
    :FASL-MD5 "f9dfb31012d7e1c48a3645ee359e811e")
   (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get/package.fasl"
    :FASL-MD5 "6eb52ab6df51ac08aeec467f738985d7")
   (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get/lookup.fasl"
    :FASL-MD5 "e162008ca65cf7e645b94a3b93628ee6")
   (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
    "e70bfeddd694336bbd088e65f8761834" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get/lifecycle.fasl"
    :FASL-MD5 "ae9cc54946c9d14ab7ec7ed9e1a2957a")
   (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get/build.fasl"
    :FASL-MD5 "5248724c954f7012f722213e7f3d9d7e")
   (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
    "9df13bcc6908e9fa601d173a671e1ccf" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/types.fasl"
    :FASL-MD5 "55afe92f3c687af3b5e2dbf7d9240293")
   (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
    "2d869293ba47444c4721713d955c6254" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/sort.fasl"
    :FASL-MD5 "1cdbd0993ecef8b86bb513dbd7c0aa42")
   (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
    "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/scan.fasl"
    :FASL-MD5 "3a662c2bb664c48bfc2ebe91dc506d69")
   (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
    "ca9002b81efd0aed9761cd1f78514762" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/rows.fasl"
    :FASL-MD5 "3b4e35f4884e78129668a617ee553c05")
   (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
    "1339edff0223dbf122f11ff0adbba61c" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/read.fasl"
    :FASL-MD5 "c70d6afa2e13906fd3b9333d5a39a11d")
   (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
    "6226d131f5562a475048b6444049c4ca" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/package.fasl"
    :FASL-MD5 "c5a3c1e7e59db37a0eba3ac4b97d1c63")
   (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
    "bbfb2082103e6712419e180ab972245c" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/build.fasl"
    :FASL-MD5 "099bfedbd75044947597cd49a60c50f8")
   (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
    "bd7182e9871fe82530d0c828e473ccde" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-types.fasl"
    :FASL-MD5 "1c81f67edf6a6b5cb55f11278c92b306")
   (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
    "d6aaec49504a96f37c8ff1bc182c977b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-scan.fasl"
    :FASL-MD5 "d96b9889e572b974360f55f32e5ab6ad")
   (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
    "521737861e057d663964b0c030552587" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-read.fasl"
    :FASL-MD5 "98a78701648c1babaa75039ac2aab4ba")
   (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
    "f13d422adb6aa9e8489352884137f25a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-preflight.fasl"
    :FASL-MD5 "cc80e52d8c5c611c76cbf59e96e1a703")
   (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
    "6d95f29b331d335175843f47ae44a6ea" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-directory.fasl"
    :FASL-MD5 "b13eb7c565875ae4dd2b0a78e6eaec61")
   (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
    "c65593cf172f53a8e90a853bbe9504c2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-resolver/active-build.fasl"
    :FASL-MD5 "8edef056d90bab1721ca8afde4a50fad")
   (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
    "17c957d6934a31f4ed64313e756de2d2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/types.fasl"
    :FASL-MD5 "94be84d9ea1c8ec758acbcbbcc86c946")
   (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
    "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/sources-types.fasl"
    :FASL-MD5 "8e2716b8f5acf6092fb3e0cf80afcc5c")
   (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
    "2b8193aab6801de19e26fa55e7c53f87" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/sources-read.fasl"
    :FASL-MD5 "e37612b9aab5200dd9f005c2baf83941")
   (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
    "74a694385f1aaf03ec87721545494119" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl"
    :FASL-MD5 "c4fa31b3b87cd1682778a0838ac4faf8")
   (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
    "894f6e238fe4047f2bf607fceae86846" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/package.fasl"
    :FASL-MD5 "375695ca8cbc001c98118a5b4aece9a1")
   (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
    "cde24b2bf5c5637d5501b95bed47df31" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/get-directory/build.fasl"
    :FASL-MD5 "e9b657097ccbe22ab37d0f8560b7d6b8")
   (:FILE "src/foundation/record.lisp" :SOURCE-MD5
    "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/record.fasl"
    :FASL-MD5 "5084871f77c80055cab594ce9aa9acdd")
   (:FILE "src/foundation/package.lisp" :SOURCE-MD5
    "5ee593a112958d94163dab17c5aa4ba2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/package.fasl"
    :FASL-MD5 "196fb88c040aefa5ac0d59c6108f24fa")
   (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
    "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/crc32c.fasl"
    :FASL-MD5 "40c688f3d1ff02fb83f4c7dc010979ba")
   (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
    "942b596396c19815290a57830af2121b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/conditions.fasl"
    :FASL-MD5 "960263cb8972893414fc462c9c99b112")
   (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
    "a06115175f450776762761dce25acdb8" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/binary.fasl"
    :FASL-MD5 "75e4e11c10b7a6748281541778ba7112")
   (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
    "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/foundation/batch.fasl"
    :FASL-MD5 "6f5d4b87fdf6e3f2502c0f220e7b529d")
   (:FILE "src/execution/writer.lisp" :SOURCE-MD5
    "73019644090e2971f2b54dc36e4491f5" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/writer.fasl"
    :FASL-MD5 "232f0b0a3833bc39a0dd9508d3527a63")
   (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
    "0679ee07c46f69db330706303c70d8d2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/worker-types.fasl"
    :FASL-MD5 "fcd4dd55b343f66bc0fd503e618de885")
   (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
    "aa34ca6bc07535e35fea723878d99f66" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/worker-run.fasl"
    :FASL-MD5 "a6643c831b19b60c6c4482925ac1ed25")
   (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
    "babd0a78b4185af24ae1fef870c0fabb" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/worker-claim.fasl"
    :FASL-MD5 "6aa460911d6c1a8f58a3b94328230ca1")
   (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
    "c24065d6c8d80d1be53994a0041743df" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/worker-boundary.fasl"
    :FASL-MD5 "e5e5d157d62493b1155ccb6e1e97d559")
   (:FILE "src/execution/ready.lisp" :SOURCE-MD5
    "2c1892002f0599bb8273093031017520" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/ready.fasl"
    :FASL-MD5 "4596809bd0a52bed99e8b9019aa73958")
   (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
    "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/ready-types.fasl"
    :FASL-MD5 "ced26ec9ae78c5478637cf8a9ffb3235")
   (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
    "38d26f8c749dd946dfc4b9c57103a892" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/ready-recycle.fasl"
    :FASL-MD5 "56dd9daa652faa28cdb2c29e09dfe519")
   (:FILE "src/execution/queue.lisp" :SOURCE-MD5
    "8202843bddb817da4279ac959ae3f3c4" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/queue.fasl"
    :FASL-MD5 "48b0f3cd47fe207e916eefe6db8d04f0")
   (:FILE "src/execution/package.lisp" :SOURCE-MD5
    "cb5710d6c111cadb7121a50998a747fa" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/package.fasl"
    :FASL-MD5 "39f4728b515a6d9ae0da4b73f1ee2a6e")
   (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
    "6b85eebe69366e78ed5fc5cc20735f00" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/execution/handoff.fasl"
    :FASL-MD5 "1cbca40ce614ec3f4deecac251dd946c")
   (:FILE "src/epochs/types.lisp" :SOURCE-MD5
    "82253491f995f5bc153fb5ebf30d564c" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/types.fasl"
    :FASL-MD5 "0700c397602c215d94502abd4f64911e")
   (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
    "653b974f310c09f6e2224a84acc43bbf" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/retire.fasl"
    :FASL-MD5 "6a3b7496d4d6b0a7e14644ed18c0e0e6")
   (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
    "036dd02adf87d33c3ae2f40735c733fa" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/reclaim.fasl"
    :FASL-MD5 "709dfb94ddb219a9092025f7be29763d")
   (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/read.fasl"
    :FASL-MD5 "230002fb3b622a314afc6f84402fbea2")
   (:FILE "src/epochs/package.lisp" :SOURCE-MD5
    "875201dfab0a84efd40fe9828cc293c8" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/package.fasl"
    :FASL-MD5 "177404bfba6cb4de37a66efd4c844c1e")
   (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/epochs/core.fasl"
    :FASL-MD5 "6029eb7ec9b7383380b33f84e7d6c2e3")
   (:FILE "src/csn/registry.lisp" :SOURCE-MD5
    "a1cdb5661fc54beba5bf00e4765f3235" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/csn/registry.fasl"
    :FASL-MD5 "cca3af29c116a28c7f6caea096dae436")
   (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/csn/package.fasl"
    :FASL-MD5 "bac36dc815d05d39915a2ce1e8b82ccb")
   (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/utf8.fasl"
    :FASL-MD5 "d92f7ed4e3add3e2b3768685458c2876")
   (:FILE "src/codec/package.lisp" :SOURCE-MD5
    "d885bd2a9860eb60aec1a775e5031d5e" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/package.fasl"
    :FASL-MD5 "c496cd5ca2214472957ffb72e9dbaa2d")
   (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
    "69e77bcd15b5413a815a65c5081229db" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-write.fasl"
    :FASL-MD5 "cea89f5cd755d1d23dd1b0255862801c")
   (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
    "b13e92b5f24a42fe283c17b649722b6a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-string-write.fasl"
    :FASL-MD5 "35e989926f77409eba82bb116798c51e")
   (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
    "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-space.fasl"
    :FASL-MD5 "8120940b52150d1deccec5a88a5e1518")
   (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
    "200373402e6e082dd8c7afde305302bb" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-simple-write.fasl"
    :FASL-MD5 "d7e8fc5fa2b0975af59742c3fa3c450a")
   (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
    "0c33aedcdb352e78a3c694cf796e6692" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan.fasl"
    :FASL-MD5 "77efb1bd8189ef84e30b76b6091e7822")
   (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
    "cf1999ddb10f879aeefbeea853742d57" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-stack.fasl"
    :FASL-MD5 "203cffad9b2094f035451aa1b75b5dca")
   (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
    "987e8ed576a21eb644ac1ef2e06edbda" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-minimal.fasl"
    :FASL-MD5 "6ab2973ddadd9d4e93ac1c3eab9c6b52")
   (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
    "706c0baa4158bf272c4b0df17c1439d2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-items.fasl"
    :FASL-MD5 "b51143cc54b122ae321063f1da5b1014")
   (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
    "f6488e987889432b375254021825dbe5" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-input.fasl"
    :FASL-MD5 "081901e0f170c2ab9cf146b5c164e466")
   (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
    "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-package.fasl"
    :FASL-MD5 "12563d9639540489baed610c10b78f62")
   (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
    "ecd8fe950344059c629927b38fb6e4aa" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-minimal.fasl"
    :FASL-MD5 "9428764e9b3b9199f82350c9fdecd82d")
   (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
    "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-header.fasl"
    :FASL-MD5 "ae6c0e3d7310b6359e7ff8c1063cc4bc")
   (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
    "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/codec/cbor-float-minimal.fasl"
    :FASL-MD5 "912fe16de5e19fa123d4a84790460f47")
   (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/write.fasl"
    :FASL-MD5 "3a6f2c645a5fc25edaa48724830e1360")
   (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/types.fasl"
    :FASL-MD5 "50e351c637082604fbe9a8808da0915f")
   (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/read.fasl"
    :FASL-MD5 "692611775eb70db57dca47904d99b3c5")
   (:FILE "src/cache/package.lisp" :SOURCE-MD5
    "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/package.fasl"
    :FASL-MD5 "9ec5fc2557ee2eef61ef4d617b00fecd")
   (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/core.fasl"
    :FASL-MD5 "fbd12cde6bda481b6f5e61c3f4b4bca7")
   (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/clock.fasl"
    :FASL-MD5 "f96eaf347448763b98fbf5ed42c1d58f")
   (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/fasl/src/cache/build.fasl"
    :FASL-MD5 "540007f26a8d99e0b6cadf67fc2973d3"))
  :EXPECTED-TESTS
  ("TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP"
   "TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2"
   "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED"
   "TEST-REQ-CCH-002-SERIES-GET-FIVE-OUTCOMES-COLD-AND-HOT"
   "TEST-REQ-CCH-004-SERIES-GET-CACHE-CORRUPTION-NATIVE-FALLBACK"
   "TEST-REQ-CMP-007-SERIES-GET-WRONG-OWNER-CLEANUP"
   "TEST-REQ-AFF-004-SERIES-GET-NIL-AND-CORRUPT-ROOT-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-CORRUPT-ACTIVE-CONTENT-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-SOURCE-CONTROLLER-MISMATCH-TYPED-FAULTED"
   "TEST-REQ-IDX-001-SERIES-GET-MISSING-CLOSED-ID-FAULTED"
   "TEST-REQ-CON-004-SERIES-GET-WRONG-STATE-NO-PIN-STEAL"
   "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION"
   "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
   "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-EXCLUDES-LATER-PUBLICATION"
   "TEST-REQ-WAL-005-SERIES-GET-WRITER-FOREIGN-OWNER-BEFORE-ADOPTION"
   "TEST-REQ-WAL-005-SERIES-GET-WRITER-DUPLICATE-ACTIVE-BEFORE-ADOPTION"
   "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-ACTIVE-OWNER-AND-ID-GUARDS"
   "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-EMPTY-AND-ID-EXTREMES"
   "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-65536-GEOMETRY-SEARCH17"
   "TEST-REQ-CON-004-SERIES-GET-BUFFER-REQUIRED-FIVE-OUTCOMES-AND-RESTART"
   "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-READER-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-WRITER-ARCHIVE-FAULTED"
   "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-ADAPTERS-NATIVE"
   "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-INVALID-ROOT-FAULTED"
   "TEST-REQ-CMP-007-SERIES-GET-ACTIVE-OWNER-BEFORE-FAULTED-CONTROLLER"
   "TEST-REQ-WAL-006-SERIES-GET-ACTIVE-UNEXPECTED-PROOF-FAULTED")
  :PASSED-TESTS
  ("TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP"
   "TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2"
   "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED"
   "TEST-REQ-CCH-002-SERIES-GET-FIVE-OUTCOMES-COLD-AND-HOT"
   "TEST-REQ-CCH-004-SERIES-GET-CACHE-CORRUPTION-NATIVE-FALLBACK"
   "TEST-REQ-CMP-007-SERIES-GET-WRONG-OWNER-CLEANUP"
   "TEST-REQ-AFF-004-SERIES-GET-NIL-AND-CORRUPT-ROOT-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-CORRUPT-ACTIVE-CONTENT-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-SOURCE-CONTROLLER-MISMATCH-TYPED-FAULTED"
   "TEST-REQ-IDX-001-SERIES-GET-MISSING-CLOSED-ID-FAULTED"
   "TEST-REQ-CON-004-SERIES-GET-WRONG-STATE-NO-PIN-STEAL"
   "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION"
   "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
   "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-EXCLUDES-LATER-PUBLICATION"
   "TEST-REQ-WAL-005-SERIES-GET-WRITER-FOREIGN-OWNER-BEFORE-ADOPTION"
   "TEST-REQ-WAL-005-SERIES-GET-WRITER-DUPLICATE-ACTIVE-BEFORE-ADOPTION"
   "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-ACTIVE-OWNER-AND-ID-GUARDS"
   "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-EMPTY-AND-ID-EXTREMES"
   "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-65536-GEOMETRY-SEARCH17"
   "TEST-REQ-CON-004-SERIES-GET-BUFFER-REQUIRED-FIVE-OUTCOMES-AND-RESTART"
   "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-READER-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-WRITER-ARCHIVE-FAULTED"
   "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-ADAPTERS-NATIVE"
   "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-INVALID-ROOT-FAULTED"
   "TEST-REQ-CMP-007-SERIES-GET-ACTIVE-OWNER-BEFORE-FAULTED-CONTROLLER"
   "TEST-REQ-WAL-006-SERIES-GET-ACTIVE-UNEXPECTED-PROOF-FAULTED")
  :FAILED-TEST NIL :FAILURE-KIND NIL :SOURCE-MANIFEST
  ((:FILE "arcdocdb.asd" :MD5 "1c847de175f4954cec5ef2186308f1a7")
   (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
   (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
   (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
   (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
   (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
   (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
   (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
   (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
    "bc7a7b176e8cdd361b7c4306a1a4de4b")
   (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
   (:FILE "src/codec/cbor-minimal.lisp" :MD5
    "ecd8fe950344059c629927b38fb6e4aa")
   (:FILE "src/codec/cbor-package.lisp" :MD5
    "c3f19ffb4aacfdfe502c5e8b12a234f2")
   (:FILE "src/codec/cbor-scan-input.lisp" :MD5
    "f6488e987889432b375254021825dbe5")
   (:FILE "src/codec/cbor-scan-items.lisp" :MD5
    "706c0baa4158bf272c4b0df17c1439d2")
   (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
    "987e8ed576a21eb644ac1ef2e06edbda")
   (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
    "cf1999ddb10f879aeefbeea853742d57")
   (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
   (:FILE "src/codec/cbor-simple-write.lisp" :MD5
    "200373402e6e082dd8c7afde305302bb")
   (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
   (:FILE "src/codec/cbor-string-write.lisp" :MD5
    "b13e92b5f24a42fe283c17b649722b6a")
   (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
   (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
   (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
   (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
   (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
   (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
   (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
   (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
   (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
   (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
   (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
   (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
   (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
   (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
   (:FILE "src/execution/ready-recycle.lisp" :MD5
    "38d26f8c749dd946dfc4b9c57103a892")
   (:FILE "src/execution/ready-types.lisp" :MD5
    "a64d98c9ff429d6103d6e10ee1fd7980")
   (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
   (:FILE "src/execution/worker-boundary.lisp" :MD5
    "c24065d6c8d80d1be53994a0041743df")
   (:FILE "src/execution/worker-claim.lisp" :MD5
    "babd0a78b4185af24ae1fef870c0fabb")
   (:FILE "src/execution/worker-run.lisp" :MD5
    "aa34ca6bc07535e35fea723878d99f66")
   (:FILE "src/execution/worker-types.lisp" :MD5
    "0679ee07c46f69db330706303c70d8d2")
   (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
   (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
   (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
   (:FILE "src/foundation/conditions.lisp" :MD5
    "942b596396c19815290a57830af2121b")
   (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
   (:FILE "src/foundation/package.lisp" :MD5
    "5ee593a112958d94163dab17c5aa4ba2")
   (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
   (:FILE "src/get-directory/build.lisp" :MD5
    "cde24b2bf5c5637d5501b95bed47df31")
   (:FILE "src/get-directory/package.lisp" :MD5
    "894f6e238fe4047f2bf607fceae86846")
   (:FILE "src/get-directory/read.lisp" :MD5
    "74a694385f1aaf03ec87721545494119")
   (:FILE "src/get-directory/sources-read.lisp" :MD5
    "2b8193aab6801de19e26fa55e7c53f87")
   (:FILE "src/get-directory/sources-types.lisp" :MD5
    "b846a6348ff7d4b5f7b380b5b3ff8c17")
   (:FILE "src/get-directory/types.lisp" :MD5
    "17c957d6934a31f4ed64313e756de2d2")
   (:FILE "src/get-resolver/active-build.lisp" :MD5
    "c65593cf172f53a8e90a853bbe9504c2")
   (:FILE "src/get-resolver/active-directory.lisp" :MD5
    "6d95f29b331d335175843f47ae44a6ea")
   (:FILE "src/get-resolver/active-preflight.lisp" :MD5
    "f13d422adb6aa9e8489352884137f25a")
   (:FILE "src/get-resolver/active-read.lisp" :MD5
    "521737861e057d663964b0c030552587")
   (:FILE "src/get-resolver/active-scan.lisp" :MD5
    "d6aaec49504a96f37c8ff1bc182c977b")
   (:FILE "src/get-resolver/active-types.lisp" :MD5
    "bd7182e9871fe82530d0c828e473ccde")
   (:FILE "src/get-resolver/build.lisp" :MD5
    "bbfb2082103e6712419e180ab972245c")
   (:FILE "src/get-resolver/package.lisp" :MD5
    "6226d131f5562a475048b6444049c4ca")
   (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
   (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
   (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
   (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
   (:FILE "src/get-resolver/types.lisp" :MD5
    "9df13bcc6908e9fa601d173a671e1ccf")
   (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
   (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
   (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
   (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
   (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
   (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
   (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
   (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
   (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
   (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
   (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
   (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
   (:FILE "src/index/hash-digests.lisp" :MD5
    "43d2209225707352daec6186ef95a805")
   (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
   (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
   (:FILE "src/index/primary-arena.lisp" :MD5
    "a319691e3e28b7ea7b927de490cf69ba")
   (:FILE "src/index/primary-build.lisp" :MD5
    "ff2cfbb865290d7a1510fdf6877c7229")
   (:FILE "src/index/primary-core.lisp" :MD5
    "fa52433eae199ceeb874bf2bc47afca7")
   (:FILE "src/index/primary-directory.lisp" :MD5
    "1dd67c527257e43f17e006644ecdbd00")
   (:FILE "src/index/primary-package.lisp" :MD5
    "d65cfce399b04f905bf969929962e59a")
   (:FILE "src/index/primary-probe.lisp" :MD5
    "699ce3f1615296fc27fcde3e0d63a4bc")
   (:FILE "src/index/primary-read.lisp" :MD5
    "3f317a0d3c5ee86a73651aad36135cc3")
   (:FILE "src/index/primary-relocate.lisp" :MD5
    "5155959766645d3172ae5e73c58cc071")
   (:FILE "src/index/primary-types.lisp" :MD5
    "a59eab6425a60fa2656f86bf87d5c9ac")
   (:FILE "src/index/primary-write.lisp" :MD5
    "e8e31e599356e592af29c0cc4604872b")
   (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
   (:FILE "src/index/rebuild-budget.lisp" :MD5
    "0417dd41cb3ec1d62dfd913c19f810ad")
   (:FILE "src/index/rebuild-copy.lisp" :MD5
    "8befbbd00ed5c31c1487a11887eba495")
   (:FILE "src/index/rebuild-scan.lisp" :MD5
    "1188e7a64a7a5d9482c1233cb9acb452")
   (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
   (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
   (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
   (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
   (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
   (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
   (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
   (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
   (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
   (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
   (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
   (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
   (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
   (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
   (:FILE "src/mvcc/snapshots-core.lisp" :MD5
    "8bb066aab61a18eff175b9edb11e42a2")
   (:FILE "src/mvcc/snapshots-csn.lisp" :MD5
    "0e9365e674d1584b111f915ce1f58634")
   (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
    "ff98aea5cb9a7ae2671f6a887a003725")
   (:FILE "src/mvcc/snapshots-read.lisp" :MD5
    "ae3ad96269b5e711a9dbb455f3c0ce48")
   (:FILE "src/mvcc/snapshots-register.lisp" :MD5
    "2d5a795bcefd605c75da91c725ae83a2")
   (:FILE "src/mvcc/snapshots-types.lisp" :MD5
    "475517bd7ba04a1c37a82efeb8ff73d9")
   (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
   (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
   (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
   (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
   (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
   (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
   (:FILE "src/recovery/decisions-build.lisp" :MD5
    "1a51ef4a488bb9fde2ff7d47bae01379")
   (:FILE "src/recovery/decisions-package.lisp" :MD5
    "cbdc30f93109c474e1fc25066c9b9b13")
   (:FILE "src/recovery/decisions-query.lisp" :MD5
    "f782d1137b8ce342b91c9999cfb7accc")
   (:FILE "src/recovery/decisions-radix.lisp" :MD5
    "852149de4c289b8e067602780378d87a")
   (:FILE "src/recovery/decisions-sort.lisp" :MD5
    "b33e57a643f2fca810846f6226366253")
   (:FILE "src/recovery/decisions-types.lisp" :MD5
    "f4433fd19ebc7239dbc2628c39f3ecdb")
   (:FILE "src/recovery/inventory-build.lisp" :MD5
    "9bd6820c4feba3e552aab1a4edd87861")
   (:FILE "src/recovery/inventory-query.lisp" :MD5
    "fcea263de1938767772e5b11411ecd5e")
   (:FILE "src/recovery/inventory-types.lisp" :MD5
    "78c136d5838dcfe3019d9069643a8d8f")
   (:FILE "src/recovery/manifest-build.lisp" :MD5
    "bf65b1731eab6e0572461ef5cc60fc40")
   (:FILE "src/recovery/manifest-decode.lisp" :MD5
    "67975249aaabd751757cdfb9222cc3c4")
   (:FILE "src/recovery/manifest-fold.lisp" :MD5
    "e0d2498db1011e857b7b0daa1934f187")
   (:FILE "src/recovery/manifest-package.lisp" :MD5
    "37ace42844c11b52446ee1fc500b8e0b")
   (:FILE "src/recovery/manifest-query.lisp" :MD5
    "ebd7a54adea2213294a887e6d4db0927")
   (:FILE "src/recovery/manifest-types.lisp" :MD5
    "7b1d4054415faca7e5fca59ad83b4d4a")
   (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
   (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
   (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
   (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
   (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
   (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
   (:FILE "src/series/publication.lisp" :MD5
    "056d2c6a67c9d9f2bf9fe2d2c348d53c")
   (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
   (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
   (:FILE "src/series/routing-build.lisp" :MD5
    "d6924deff152b941bd49f0bb200b4197")
   (:FILE "src/series/routing-select.lisp" :MD5
    "e0f987d8767744050ec4d1b3ecb699ed")
   (:FILE "src/series/routing-types.lisp" :MD5
    "ce649df47dd38888d5103c98345f7e41")
   (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
   (:FILE "src/series/worker-boundary.lisp" :MD5
    "2340e0c9074f7b1bf80c74f774986bc5")
   (:FILE "src/series/worker-package.lisp" :MD5
    "a93ce2e84e8aee647b5083ad1d2b899b")
   (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
   (:FILE "src/series/worker-types.lisp" :MD5
    "2b23d468be0165fa009c5ebd5d1bbe23")
   (:FILE "src/storage/compaction-scan.lisp" :MD5
    "1cda77a357ab2147035993b72d135a37")
   (:FILE "src/storage/control-payload.lisp" :MD5
    "cb64f806b8d69eb42d865b4abfff0b27")
   (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
   (:FILE "src/storage/log-header.lisp" :MD5
    "b53d27dcc9f4badf18b50519c50bc614")
   (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
   (:FILE "src/storage/payload-record.lisp" :MD5
    "8c03f9c01dcb30f2d3970a5694968ecf")
   (:FILE "src/storage/payload-write.lisp" :MD5
    "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
   (:FILE "src/storage/segment-header.lisp" :MD5
    "d6812fa59bf8fd1252fbf85a9bfa3896")
   (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
   (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
   (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
   (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
   (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
   (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
   (:FILE "tests/foundation/support.lisp" :MD5
    "758adad069aec2f9dbe0635797314ff6")
   (:FILE "tests/get-directory/support.lisp" :MD5
    "3f868ebe4307ad4238b314c37eceed9a")
   (:FILE "tests/get-directory/construction.lisp" :MD5
    "1137938073e71d6d8d62c751fbad05d5")
   (:FILE "tests/get-directory/read.lisp" :MD5
    "d1ab36d05cc1266e4533d27c693f12f4")
   (:FILE "tests/get-directory/threads.lisp" :MD5
    "63dd01c852de1399c2c82274d481d257")
   (:FILE "tests/get-directory/series-support.lisp" :MD5
    "8d7ed4f8d3f9e8394b15c648a3a4507b")
   (:FILE "tests/get-directory/series-read.lisp" :MD5
    "3e565b431b88fb5211023601b5e3ce3b")
   (:FILE "tools/get-series-mutation.lisp" :MD5
    "2068edb227d28b9e53c4eecc125fca54")))
 :ARTIFACTS-VERIFIED T :SIGNAL NIL :EXIT-CODE 0 :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "1c847de175f4954cec5ef2186308f1a7")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "2b8193aab6801de19e26fa55e7c53f87")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54"))
 :DEADLINE-SECONDS 120 :ARGV
 ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
  "--script"
  "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/evidence/baseline/driver.lisp"
  "--child"
  "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/evidence/baseline/config.lisp")
 :NAME "baseline" :FILE NIL :RESULT :BASELINE-PASSED :STATUS :OK
 :COPY-DIRECTORY
 "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/baseline/"
 :EVIDENCE-DIRECTORY
 "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/evidence/baseline/"
 :EXPECTED-FAILURE NIL :PRODUCER-RECORD
 "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/report.lisp"
 :PRODUCER-CLOSED T :CHILD-LAUNCHED T :CHILD-REAPED T :TIMED-OUT NIL :CLEANUP
 :REAPED)
