(:FINISHED-AT-UNIVERSAL-TIME 4000908060 :CONDITION-TYPE "INVARIANT-VIOLATION"
 :DIAGNOSTIC "ArcDocDB: DIRECTORY-LOCATION-ABSENT" :SCHEMA-VERSION 1 :KIND
 :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE :TESTS :COMPILED T
 :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "3e565b431b88fb5211023601b5e3ce3b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "8d41187c5eda5c68be2aa6ec97fc63ec")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "737ed0d7dbef54891eeb1822129926d8")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "df0324b3bc1b579e3547d7d0af6dc4d6")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "d407493ec22bab58bc160ed8b13d9f51")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "dc5d893f9152ab498d496650e1a374ef")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "25895f8cee0b2167e29a30918e3347fa")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "7446150dc046c3790b955103b6b4e789")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/types.fasl"
   :FASL-MD5 "62bf9f50af816f0cde62602d4a3c1faa")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/package.fasl"
   :FASL-MD5 "6cac260e472c4be2344073cc6489be8f")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/group.fasl"
   :FASL-MD5 "9406659db8d3aa8e6e733db1fd04b3c9")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/executor.fasl"
   :FASL-MD5 "69e903fc0fa246dd18bcd6af7efdc769")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/csn.fasl"
   :FASL-MD5 "4c2dfd293c5f4aabc6612a4862c6ec39")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/builder.fasl"
   :FASL-MD5 "0b3c13fcb30aa977c591212ce2919143")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "908d58a6d48b586655f3bfe617bf0cdd")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "1199b6a078b745fcafcd0fa06b93eac2")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "411e9880e8d3f4daac9c1aa049cb1948")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/package.fasl"
   :FASL-MD5 "9044251f9bb2364a7a49be037b073f67")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "597f39bc26e6343fca56d24310db8c0f")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/formats.fasl"
   :FASL-MD5 "f10f977727af56348df9b73a26584b7b")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "63cd8894b4ea1e873e6dec05fe8bd489")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "9cf8c4defbb6087b644df9b09867b526")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "810f11f78b3eea9d11d64009c038deee")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "c1a9b1827e37f6955d04738927a83047")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "37cdd2c06da2e095083fba9a10841302")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "d77744ecec45fbbcc98a80a848e69a4c")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/types.fasl"
   :FASL-MD5 "190debfcc8077a7b744e9cab0b7b8805")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "3ead7d81973a26111bcbdea94f65f46a")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "1f095a7e147689dd96f2b13a572104ff")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "5e587029df48a7ccf2fb2db3d2c0330f")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/retirement.fasl"
   :FASL-MD5 "2560d8a247e8b3c65aa03dc9d3851a65")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/query.fasl"
   :FASL-MD5 "738b85609b32f5ed98cb9184c4ec9ec8")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/publication.fasl"
   :FASL-MD5 "b9a0654cb631e36baee0ccceba186ef3")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/package.fasl"
   :FASL-MD5 "31aace0f10beb7070dd3e88b21d3063a")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/ownership.fasl"
   :FASL-MD5 "f8aff05ae3e5ffc01a2ebfbb750f3446")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/io-events.fasl"
   :FASL-MD5 "4278cdbd068a8c8c7bc379327a8b1e5d")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/events.fasl"
   :FASL-MD5 "8501b955e9d864c332b96ac33c7b03c8")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "8436534d2deaaa223ed9c8e64dd83247")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/package.fasl"
   :FASL-MD5 "7f9f035f7b12bbaa327ad38a7844314b")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "b3d8f1412e76ed9af7b2b374bc766c52")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "3b132866360ebb203a4bc4b99df64edb")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "d5fb039fb7ce420d720c90eef75795b3")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "bc481e66f5dfe7dcec633c1e59c41f93")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "8a2543d2ca2f2a972ea53ec55539f7fb")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "708100857fb9e04beecdf43eb3e4cf16")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "6749fad2298591557e94f054a782847d")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "5186e5bfcda083b179bc747b278e24e0")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "fcc8c69a8f173a2c0e54744e06a618e7")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "a954d9cce5f80acb08e89a12f0027f9a")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "799d4657829ee7c2811f193f2c776da1")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "7b17c020519536ba2d6caced9f6e0bc3")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "02cb40a8b0fb984853284b8130f4b60e")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "0b714b1d048452f01f4429a848b73501")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "67a0e5786362e6b7f98bbea118a8a3ef")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/types.fasl"
   :FASL-MD5 "91ab7e3dcc6fae0c45f11c8e67fa79ad")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/task.fasl"
   :FASL-MD5 "6a8377a2502dfd530e4a85b31e5e31d3")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/package.fasl"
   :FASL-MD5 "993dec7c05cc2c12080572615d0a184b")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/core.fasl"
   :FASL-MD5 "64bed48fe8e60045f637af31ca9fdb1d")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/package.fasl"
   :FASL-MD5 "60ca8341f35dd7b56fbf320e6717e77f")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "7a4733540486abec94c7c3e4d17e1192")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "27957dbaec48430571003ad787f4379b")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "36012ac175678e5d24ed9e489af381db")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "b952383a55780f281c1681fe47d8c86b")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "3b08980852ae7089cd7973d891150119")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "59240005b807c016cc25ce3c464a9db7")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "abbd500ced3e62296164bfa3ed6f785b")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "0a1fea1e17c89447579c24ba14ba71a7")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/types.fasl"
   :FASL-MD5 "d1bb4723d2c8f4f7503194c9a27394a4")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/transfer.fasl"
   :FASL-MD5 "1736ed6ff83ca9c1b8bd1628808d8698")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/package.fasl"
   :FASL-MD5 "8bbc960eb08bb509e01e7fe51da66eda")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/native.fasl"
   :FASL-MD5 "68e000c30a3ffe45502adbb1565f0251")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "b9bbd2752315c3fd32cd791b7afddc6f")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/identity.fasl"
   :FASL-MD5 "b60f472a73d58362893bd2306a0b04b2")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "a19be4082c4a333a572c5278e1507bd7")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/flush.fasl"
   :FASL-MD5 "fa556bfd82b32f23d34b307c82d64d16")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/write.fasl"
   :FASL-MD5 "f5344281da3c379f5c8fa86eb4fae28c")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/validation.fasl"
   :FASL-MD5 "eeeb7f9fc990b6e74550b0fe18e3ca1f")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/types.fasl"
   :FASL-MD5 "0aee7948360a175da6d28d002803eea9")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/relocate.fasl"
   :FASL-MD5 "92784ef9b113a714385fbff858f10464")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "2b77f075e93327cd9226de80a3611e04")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "5ab1d2789235d37d6c7d4787862c50dc")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "9ba9d823de7343ad8bc15a18dc09612f")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "bdf51ccbe4563a1ac666d4498c5b0504")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/read.fasl"
   :FASL-MD5 "e6cc1ce60bf53f0f4b616b1a948d6609")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "e725ca50a26068d3781e4bd43c1749a2")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "eb4a241b7f36d0168b2c3e4560e089e7")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "a249160ce116a4ea98d1669afb9d1707")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "000a9498a2fb4bc1be0ff153c8dc4c12")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "bc165cb42dfbd99fb5f7a9013e2d5967")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "50d98eabe3e97b8790e0b62efc70a7f1")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "6ca28c4258569a78c5ba57fa55f08234")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "63df459ec9c15107ffcdec17a93bb979")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "e45b920b450c4abd8897c431e2938b6e")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "6de6b2003ecfbf1a7f6ba649d669f310")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/package.fasl"
   :FASL-MD5 "70a6c9daf7551845dd11935dadd041ec")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "4010fb52a79e200375c21dba5bc62531")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "6d9fdd5ee201cc3084ce63a06e25c429")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/core.fasl"
   :FASL-MD5 "65f2c18a93d8f3f4c740a3e412d84014")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/package.fasl"
   :FASL-MD5 "5a2486f223ff18ee215f630851992e2b")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "280ee517c0c3bb8ba3ee35df63a14745")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "47adafecbafb284f749c39ec2035dda2")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "0f76518fa47dbf781741ccfde2c751fb")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/types.fasl"
   :FASL-MD5 "d34de239fdbce29b5e05d1cba9ff4166")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/target.fasl"
   :FASL-MD5 "481441eb9a8c6dc1854b9b614ddaca04")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/segment.fasl"
   :FASL-MD5 "7feb68d3e77db10fc021ffc0b6dc8f86")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/package.fasl"
   :FASL-MD5 "82be2bb287825cb8c27331ed6c470f2e")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/lookup.fasl"
   :FASL-MD5 "90bd7bbb77790843612336023f562ed8")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "d796ad66ab32592bca2b922ae7796146")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/build.fasl"
   :FASL-MD5 "58c2822ed4bc1978ba0d307bbae4d951")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "f3e752c6ef3753ac96341804f60414d9")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "4a144860fbd6bfe40a9cce5f884a6294")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "416536f8b264f03a52f74394483cd841")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "5bb49c0735a655e2c40f6440db5cd973")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "1b0ab87d76639d5ef572f668509f5081")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "ef81cd85de36d02bc95589e916947c64")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "4ceb9e855586927b62768275a0634d71")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "38ff2a1e852189fcdca28fd7b3f0aeed")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "b22013978895ee397ad44e5026ec6fe8")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "521737861e057d663964b0c030552587" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "5eae143d8c64d34a309b006cea232f9f")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "b0f26a4fd2ee7392b8f745b7fd4c957a")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "7e596cfd72d7f0c69f2b19aeb7aeb7dd")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "cb8ec4248f7e3fbd059a0ac22d87baba")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "01d772c4e0317b7dc84804e5465975c6")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "147e21948e729466b2b0d52f86315a92")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "db44405bae8b58b9bb6519429dc016a8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "8ea412436f79bc834972d7095989835f")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "eea82df68b6247d51ce4f837314424f0")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "c83b69b2a7337d4bafdbf9520b2309f3")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "eedcec9cad09117cc1cf20a4be04e4e9")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/record.fasl"
   :FASL-MD5 "e352ef3501ec481a9bfa0f0e804ad377")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/package.fasl"
   :FASL-MD5 "48ec6d8e0d6d4d0a368ec6975c13fb86")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "e611a0bce009ccd4c63f6e56bb2bddaa")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "fde2c63e43d3fd07e12082d0110bf0cf")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "ba6a748401f90c3a43e1002cc766394c")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "46aba54c5cd14911aa7e2afa35cc3d7f")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/writer.fasl"
   :FASL-MD5 "744e0330e530e7a65d39a416e700d3bb")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "daef0c465d9a74c79dffa636b950b67b")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "84b13e2aa645624e56a2d9a5483a6771")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "932b619384b7d6ee032e64d4d62e8093")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "7b78f6e88a1c5c6cba54071109704a95")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/ready.fasl"
   :FASL-MD5 "bc557f426d25328110a09edfc3f05206")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "45c2663baf82a79e60cacec9e1e19bdd")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "5eb421c875498028b92d223d44909045")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/queue.fasl"
   :FASL-MD5 "4800903d4d7652af01dddaa8739a45fb")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/package.fasl"
   :FASL-MD5 "df3b5232bb99a4f89485fb3edd507e21")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "470c7214d07241f6f0ec2b98c016f05a")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/types.fasl"
   :FASL-MD5 "a170627f178090bf685d3b8090e4d765")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "b2dc071fd93c9a8395ee11cd984b9e2c")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "5648a216010ff4f4a9bab63736789a13")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/read.fasl"
   :FASL-MD5 "d90e769fde6a87a8a84dcc1de860aee0")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/package.fasl"
   :FASL-MD5 "824bea2f176542d20e51c38a7154e0f2")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/core.fasl"
   :FASL-MD5 "b418a833172251f63ae6dbe54d880732")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/csn/registry.fasl"
   :FASL-MD5 "8c9b11bded9f219d487c3a0dd94a07ed")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/csn/package.fasl"
   :FASL-MD5 "645cc29ac1a7e1f32682d9f03caee305")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "65545263876cd176326dc7548cdfd8bf")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/package.fasl"
   :FASL-MD5 "98a3ab0767d872adafa702165ec36833")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "ab56e2a4e34866d823bbc7924386b99c")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "817737b23e5a04f0e619fc146389bc7b")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "6bc8db85516060125dc95801e276fb60")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "6de5f4c5ef658227e5c1de46464ca15b")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "53684ff95827501d2472faed8223e3e4")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "4fa7f5e1f8dc967259f7590f1be1311e")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "31e35dfd0764edfb32ba6e0c2747b282")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "85c4879586c5feb82a897978b59aaec1")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "039ad0e832352927c30d486c0e337af0")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "f621f7050b2237641338c57811df28bd")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "82976f82a6ab644c2bca127d3c02ef0b")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "7a1cb2e1e83e230ca01f212ed327ec46")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "6f819f7902477231d016515e04612344")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/write.fasl"
   :FASL-MD5 "10705484bcd646508af2fbe1c1faf991")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/types.fasl"
   :FASL-MD5 "93aac975dee981170f62e37b9f7fa3a5")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/read.fasl"
   :FASL-MD5 "7509bb0116a20964005f4ebfc6c669e3")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/package.fasl"
   :FASL-MD5 "3f53f54a2da7844465407dec95f8322d")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/core.fasl"
   :FASL-MD5 "5f25bbcca6c48c86fc3496b07e1439a9")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/clock.fasl"
   :FASL-MD5 "62b2ff21d158fb8d3dfc172f902eda01")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/build.fasl"
   :FASL-MD5 "d1eb8be529a05bddb7d3234cf493308c"))
 :EXPECTED-TESTS ("TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED" :FAILURE-KIND
 :PRODUCT-CONDITION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "1c847de175f4954cec5ef2186308f1a7")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "db44405bae8b58b9bb6519429dc016a8")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
