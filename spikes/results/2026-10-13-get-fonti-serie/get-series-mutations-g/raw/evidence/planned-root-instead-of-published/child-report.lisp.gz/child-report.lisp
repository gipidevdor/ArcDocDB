(:FINISHED-AT-UNIVERSAL-TIME 4000908047 :CONDITION-TYPE "INVARIANT-VIOLATION"
 :DIAGNOSTIC "ArcDocDB: DIRECTORY-LOCATION-ABSENT" :SCHEMA-VERSION 1 :KIND
 :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE :TESTS :COMPILED T
 :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "3e565b431b88fb5211023601b5e3ce3b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "0552524c94c53ad8da7fb0ca7a9a4fbc")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "0c89857cc66765e4f22cf4483a4d5e2d")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "c3513d7aabdd0eb91ed94c84260f9302")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "e75cffeb1e43201598ef9d66d37b598b")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "8d54acce3cbdf0a4d7f845a4b1667493")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "d0b61b8b133c6de450297aff49c2115c")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "4a507f1dc72a3558972e7fe38713b85b")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/types.fasl"
   :FASL-MD5 "17558c3a7fe1258414e4b9fcd2b28a5c")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/package.fasl"
   :FASL-MD5 "d6558a1cc37d008866f4f6f81957f013")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/group.fasl"
   :FASL-MD5 "163fe0c96bef92071e6e2588c856672f")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/executor.fasl"
   :FASL-MD5 "431943d1589f412eac995c198f31d128")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/csn.fasl"
   :FASL-MD5 "9543a9a5bddde0d2dc0ce79dc6d1110f")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/builder.fasl"
   :FASL-MD5 "de97088a7a1b9a3be98e5e39a23d4d22")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "ead1714511c0437d54f82937ed527dda")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "064aa7b4401f975ff95e4742a811e808")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "c366bca344ede73557ac8a364be0b5af")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/package.fasl"
   :FASL-MD5 "d30d55d2867e6761f2ad926b505bb89d")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "33682c80ff78cc52747525eee3ed4c29")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/formats.fasl"
   :FASL-MD5 "b1c4293df6e780caa304116420156ac6")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "e1deef27529aa7535a6cf52f10a36c2e")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "0222d6c9c13211e014ac82511b6943a2")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "b1e4a98107015451a6f992fe45162ed2")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "74bedcd9f0166d8a59c0d4a1ccc7406b")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "bdc55b2b7ae9105476d3d9cf89581055")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "aae19761cea101ee738ccd2036aa41fa")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/types.fasl"
   :FASL-MD5 "2bbf84c0083996fbc78458d8b3aecedb")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "64bd3a4c134fdec440daef46107f0146")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "7bc3b3fe4ec80101345ab3212523a633")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "d7ad2610b549c1a21e5915f0fa41fb8f")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/retirement.fasl"
   :FASL-MD5 "7071237edd152f0e2b2aa920b7c3e05d")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/query.fasl"
   :FASL-MD5 "3286059e02b4b97a7bb26d5c1408a51f")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/publication.fasl"
   :FASL-MD5 "c119c9e69e94eff4f3decfdaca83ef2b")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/package.fasl"
   :FASL-MD5 "c3b009505efae5717f422cc397e68b8b")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/ownership.fasl"
   :FASL-MD5 "559738fe521b107bb9597db59b52d9d5")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/io-events.fasl"
   :FASL-MD5 "b545aa16906683ee74302d25e7addc53")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/events.fasl"
   :FASL-MD5 "f87d58ff6e48dbda0ce47b543a6c6da1")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "f81240b1450d0e643c50dd21b88280ac")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/package.fasl"
   :FASL-MD5 "82ddd12091890961f3473e9f47e09b99")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "77631d48e3d8e27be0ab6f66e8491e50")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "b8d6065d5d355edb48996f05ab524af4")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "ba7f3d6a217e17cd37231c83b1516d84")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "5f56d036efb4090e1b639caf29939429")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "89104cf4a0352f5d59d7a4a883db52a7")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "273c5d89339377b7b7fcf62cee92358a")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "b781e0da3870e989a7932de8a46e4009")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "c319219abc692d781571980c1ae0ddad")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "6cd938f421257a8c8e62c9efa1229349")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "cd837fd66fc57857e5250bda1159a82a")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "443204a06c56abe0827ddd9dc339a2b4")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "2f46c9bbfb4dcfb753bb7f844f2bc0ba")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "c368a381916743ebec226ad4d5238baf")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "0df5f2f352b93980a81e88362e84c16c")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "54f7f94c3a3bd4fa873f27d09bc09cdc")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/read/types.fasl"
   :FASL-MD5 "df539776b1526e058f8e46bf418fa180")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/read/task.fasl"
   :FASL-MD5 "68f65f106c17eb7f1147863591f3b849")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/read/package.fasl"
   :FASL-MD5 "97623e55be31e18dfb8a78194268e373")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/read/core.fasl"
   :FASL-MD5 "e3cdc90a74ebe6e85af95bae926beb01")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/package.fasl"
   :FASL-MD5 "07283d3b40feffeec98b800e2f63d56a")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "dbe65a29b98bd114ab6df505c0ccf4ad")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "101c80843e24431ce651732cb3181ce4")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "ed986e7c4dbaa231085a98dec6f8655a")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "bc5e3671ffa00a652e5d58a00fe0057e")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "91fa2cca7c3c1ff4f4015b291a03f491")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "735b105306feff366072a81ec087a5e9")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "a49fa6a96a832463dc940dd5ea4815e2")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "ba917b6909c0e6a7353098934f55193e")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/types.fasl"
   :FASL-MD5 "3142b71723bab49314730773ab81fb22")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/transfer.fasl"
   :FASL-MD5 "5acfe94fb20f1ebabaa6ac602d37eca0")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/package.fasl"
   :FASL-MD5 "5d6841540717ee804fed9799c51840e4")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/native.fasl"
   :FASL-MD5 "94e2688d1ca470fc6968662ea4ba8d78")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "b4fa66cd78fd3a8f5c96523c47d06250")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/identity.fasl"
   :FASL-MD5 "1aee8592451bf2d8ea0008fa230f4e54")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "cdfad64453ed351f3f3657bcb221ab27")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/flush.fasl"
   :FASL-MD5 "969189d860afa48a1526aaddc91aaabd")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/write.fasl"
   :FASL-MD5 "0c3c9a4ed68dc6fe84ecbd9c294232cb")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/validation.fasl"
   :FASL-MD5 "fb0ce791b175e717a041a271136680f6")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/types.fasl"
   :FASL-MD5 "e60a69458c52e2b20351ef3cbf82f208")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/relocate.fasl"
   :FASL-MD5 "56b9b87350dd1df49d96db819a45626c")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "b6092a10c3bf5237daa21fce5e583622")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "4db3c0e265824c171d43c2ba1ff63cba")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "2b2e4334ce714b33f9051dc786d37002")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "59b6dc074d0d3d3a3cac5371ffd6f411")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/read.fasl"
   :FASL-MD5 "61e4050f01da3c0058bf6330a8744d84")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "a84d86041f3a0737332f1a3ff768de95")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "f0680e096296e4971e1b1d48914ad644")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "2627c2bb52b44b93b964487bf7f1b991")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "0243638c6f53dbf5db0521d51d451a40")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "91b3097d7bf8701fdd07323c7bd37f07")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "d194654d0e5deeb02b910be00dc9cb6c")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "0ddd5d4c4acb360ab7ec4500b2dab8b9")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "739cf27620d0869a5d9703a68f16396d")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "8e23e2749a425bf335eccfb4c0b1c9e0")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "be27733534d68c73e0add95c79d18937")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/package.fasl"
   :FASL-MD5 "531dd2b0ad6f038746518c5c137de3a9")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "8e1c5fda4d345fbbac686c0204b9fe45")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "6ce114d62e5eb31c2c095615a3422926")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/core.fasl"
   :FASL-MD5 "9fe9727b3901c8be797acce89e33ed52")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/hash/package.fasl"
   :FASL-MD5 "f7000704264617434acae2a9d0c014b2")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "9c0956a6f5049fef3daf766c2fb0bb5f")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "316915e0feea5acc20b7c95221a4a55d")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "81ae40b457f3ee9f1e2726e429b2596b")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/types.fasl"
   :FASL-MD5 "d6c591b1bae156e3aee1b6209d73c1a5")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/target.fasl"
   :FASL-MD5 "c87280292c79ba4371b820191d3bb909")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/segment.fasl"
   :FASL-MD5 "8444dec79fc26456032846b32fd8edeb")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/package.fasl"
   :FASL-MD5 "cf6af754b88bfd06684d83ffbec7d87e")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/lookup.fasl"
   :FASL-MD5 "38b468b3531d80ddbe8baa420b012884")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "175237617c5d6ef5f00975aaa2220355")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/build.fasl"
   :FASL-MD5 "acd38b12a21b0817bad25bb55d5e2882")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "e584c1f6522f57de6a08eb00db24f562")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "02f67510b005c1787a49caa4c4a96e8b")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "4bfb6f9517d5eaff484fbd65ed3d8205")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "6bf1e54e73c9b8ee35c4146ae907b388")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "08795752d809e79ca40b03fe2f37e0e1")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "cc867166838295e404ec3db8939fc500")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "03bd22e9ecde84e166f94960be6153df")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "1629b25d33c1ba23c70cf734fbff274b")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "3e2b06f2edea91556840c5e1037e3b76")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "521737861e057d663964b0c030552587" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "e3810b223d39cce890aeab8ad257fd5f")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "9d50f1f736533688de2fa83867654aec")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "735c50bae0c55be649f03dd15da0ebac")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "1bf963bf25dfe2e90d2f4abd8df6fb03")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "82c7e75af4b5456873c3afd32fe23473")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "85b061314e3f13c6366f13e0f264a5d3")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "fe8a60fc4f720bd864c248b71cb71654" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "0b5877a53f6ddd54fd3b4b3247265636")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "9ad5ca71086e627e8d2236d29bcccc21")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "5e20c3d627ec9f4af633f65c4b0e7d3d")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "471ddaaf804e5c4ef374cc6ee97e029f")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/record.fasl"
   :FASL-MD5 "d2462bc48e9578113e3321cfda91e763")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/package.fasl"
   :FASL-MD5 "679038467c1f45fd636d668edcee8f17")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "991dd1c6e91e1d9da36e6ad4085c28ba")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "3b5952ae8fec014aae36779374151505")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "b4fd2c338067b7dc8fc67c6e09c306a3")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "d60240d94e4a5a82569c307144d6b44b")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/writer.fasl"
   :FASL-MD5 "85827fe74e1069c1b1a6263e8b875bc3")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "1db661a629942a0d74b0ddd2ef4d65ef")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "7d36eee5f77bb1e133d200aa40fb36da")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "bf0b92fe336adc900bc23ad4db74fe7a")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "b24f1ba53c1be78392c3db775735315c")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/ready.fasl"
   :FASL-MD5 "35d1350940ed62f236e93fa1a02b6880")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "d6576c9a7214749a0f6a938383969069")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "146b02b1631d2b1445910482a10077e5")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/queue.fasl"
   :FASL-MD5 "4bdaf966fee7c307cbb9fbdd0c820897")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/package.fasl"
   :FASL-MD5 "121e2f8945e43301adb28459a0846cf6")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "0c555233d0cbc58c09b66b8499beea20")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/types.fasl"
   :FASL-MD5 "68b6378c43173b0ff17d34da581b9056")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "332bcfb768b21f3051583fa27e25bb17")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "5e5ca4bf76f05e5821abe2852c3aaad5")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/read.fasl"
   :FASL-MD5 "0b5462810fdd3c405360e1a9b0546155")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/package.fasl"
   :FASL-MD5 "d97a4c5e6413538a7189b7b5a18b8e7d")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/core.fasl"
   :FASL-MD5 "79027fdb5087a897dc9005e24dbb7d71")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/csn/registry.fasl"
   :FASL-MD5 "e33706b2aa2aa724dbe5bde311b95a0e")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/csn/package.fasl"
   :FASL-MD5 "9df7b266bf10e5a13da2cceb2c37d318")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "80723ee5da466ecf61d3d76a9b6acae4")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/package.fasl"
   :FASL-MD5 "fbf1c6e7695219d7333537b0bb89b38a")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "07611d89a8a5840a6c0e0fd787f2e81d")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "a8f92460a1e908b3ee7758e0bcbfe156")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "70db0b3e6c4c6c43ab83ac5add5e2924")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "f3a1a4500e1e43ecce4ab9667d371377")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "ccfca48a0bfc980f527ee6061bd98631")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "c8859623e4833ee11d8a921ba8dcd06a")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "8d9abfdcb313012b499362d95927ccf2")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "f183b3a938c8c7dbcbbf251da024e10e")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "f26e3f56969cf4932e543caca1174ab5")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "9355e0646a7d5bd9d703b80263e33088")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "fb6a6c60451ebe797a99865defa2f582")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "bfe3abda96772d0490e8560757602579")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "2efc5e6d2c2a6fa52464f9bdccc741fd")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/write.fasl"
   :FASL-MD5 "91ab6f9484f6e88884b0e9742091c023")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/types.fasl"
   :FASL-MD5 "cf4fa60e4259d0e5fdff1a8297a3b6f2")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/read.fasl"
   :FASL-MD5 "eb52f75887a46ba43cef79fe254871a9")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/package.fasl"
   :FASL-MD5 "8e81de71f8c12d3c51a5c3a5c356226d")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/core.fasl"
   :FASL-MD5 "9589466c9a214c417100edd94e6c1ceb")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/clock.fasl"
   :FASL-MD5 "99290449d08c3f50065b31d0e299c6a0")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-g/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/build.fasl"
   :FASL-MD5 "d047e83cac5bc8a67fc9a46ca42b6928"))
 :EXPECTED-TESTS
 ("TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION"
 :FAILURE-KIND :PRODUCT-CONDITION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "1c847de175f4954cec5ef2186308f1a7")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "fe8a60fc4f720bd864c248b71cb71654")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
