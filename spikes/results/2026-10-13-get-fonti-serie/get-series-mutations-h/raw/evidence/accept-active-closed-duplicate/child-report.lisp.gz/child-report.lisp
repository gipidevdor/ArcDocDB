(:FINISHED-AT-UNIVERSAL-TIME 4000908514 :CONDITION-TYPE "SIMPLE-ERROR"
 :DIAGNOSTIC "Asserzione fallita: (HANDLER-CASE
                     (PROGN
                      (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-OPERATION
                       ARCDOCDB.GET.DIRECTORY.TESTS::OPERATION
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-CONTEXT
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE)
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-FIXTURE-CONTROLLER
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      NIL)
                     (ARCDOCDB.CONDITIONS:INVARIANT-VIOLATION (CONDITION)
                      (EQ (ARCDOCDB.CONDITIONS:ERROR-REASON CONDITION)
                          :SOURCES-ACTIVE-DUPLICATE)))"
 :SCHEMA-VERSION 1 :KIND :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE
 :TESTS :COMPILED T :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "3e565b431b88fb5211023601b5e3ce3b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "f6e5770da0a0fbe2e15c6f5bea5f5679")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "8df6deed8fd33ed8b3cae9cd1f3fc8ff")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "58aa539fdc320737fef74987f9521508")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "9671b32d30bdfe7e58e8799e808f608a")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "d5dca4386bdf781a6a27d1109cd3efc4")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "464f30d0bb28de0026996f431ddb1aca")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "738e5604ed02c485327358da8d753678")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/types.fasl"
   :FASL-MD5 "3c168391a3fa8372184b1fc55e958663")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/package.fasl"
   :FASL-MD5 "ee8ec196b3a78b8360801415c0d06096")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/group.fasl"
   :FASL-MD5 "aef6d4ce567acd829077c11d69e6fc69")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/executor.fasl"
   :FASL-MD5 "8f3509219dd8f84f3a377cf8e5ed78a9")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/csn.fasl"
   :FASL-MD5 "b4708933f965ca48e3048067796c91c2")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/wal/builder.fasl"
   :FASL-MD5 "f5357b441ba8000ec49de6092bcd2bf8")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "bf77e11d0e8f69754b3ff913b14068a3")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "ddc21b2f06dcc9a9b37751fc2557a856")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "307d4fb3334cd246e3cdaa1dc2aef7d9")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/package.fasl"
   :FASL-MD5 "840948b8e36689a702ce8fcdf8f008c2")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "33068ecc8f271a96fe04093f60b34404")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/formats.fasl"
   :FASL-MD5 "67568f31403fe8c3b55efd4dd01a4ff7")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "7dc95be8af9a26c41990a2860e76d0ab")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "c2abe18a147ce1044a5be61ceb594cbd")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "e63493a5a501b0be4e98b8fc06425ef9")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "20d7ac931aca0dede0ba647545fb7158")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "50b8377b92bcebe5011c0ab4e028b67b")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "23471a30791dc66a17d192b1572eb629")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/types.fasl"
   :FASL-MD5 "99d29dd34b8d665080771846d5989b78")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "e465dbe968a53f60ea29b9a4b4c85fa3")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "1731b5dfdbab8ac526542a4b6b5283ab")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "bcf0ef30f7b02e9c5a1f65eda4cf5607")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/retirement.fasl"
   :FASL-MD5 "e6c32a41247d390e44a068a0e76c58bd")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/query.fasl"
   :FASL-MD5 "aee6c12eb0823c207ea33d6ab759284a")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/publication.fasl"
   :FASL-MD5 "97d1f911525dab0beeef818adc669b1e")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/package.fasl"
   :FASL-MD5 "903bec63466f056ebe74a17446190ac1")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/ownership.fasl"
   :FASL-MD5 "347927a5784f74bb9853a8ab7f34693f")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/io-events.fasl"
   :FASL-MD5 "1b050e7b484563039154e1d8c1dab6ba")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/series/events.fasl"
   :FASL-MD5 "064a0ad8dcd2fc99b61f65f047e2187c")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "64acdc8a03989e5de08fd94fb7a20e21")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/package.fasl"
   :FASL-MD5 "572b4a330c9e938a2304139fe271f548")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "5af02211d9cc20d6d68953531b4cd106")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "d3c165b089472bbd6ce5dc4436454337")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "cc986ef581306ac974f42c49a45ad9f8")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "800fad50098e5fe37e4cfd41f76b8cf9")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "61fcdea05ccfff0f8e307368c52edd0c")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "b1f82907a02179005a263677c1223248")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "23160cf42ac6d89a5d247a6f0cd414ad")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "8df944ba50b8abe44887480c573841c8")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "0e6f2d7e28e2f657bfa5bc0c46a17f38")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "ec160e95d1db8018e4ab16f299625e69")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "a68f0f93a5a877991ff582ec084677a9")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "de2bc11b1efdcd35b1da88ca4957b2dd")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "33b985e5826c2e72e1a55351dd3dfdc3")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "a574d66210ac571055f7146f5efcedd8")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "bfb9c6602a0630394ec75af022f08abf")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/types.fasl"
   :FASL-MD5 "b009cdab3aef6cff819f62c1b418cdb1")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/task.fasl"
   :FASL-MD5 "afd45ffe503e7c2a52294c2dfcf4260c")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/package.fasl"
   :FASL-MD5 "031f8966fd57c57725467cfa6cc8f43d")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/read/core.fasl"
   :FASL-MD5 "e2a5f9c81e7fb4a8d7254e875344ccc6")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/package.fasl"
   :FASL-MD5 "ade709d266fd4773166db92df6f81fdc")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "a7d3d6cfe782e32498b2cf8a26a7cd60")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "d0ada11738b6a77868ff683a4e59d24f")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "8222313fa50f2714875f1269f108481b")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "7f957875e3d32ec09c41e9649b891200")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "40179094ff150f2ce7b8e5430298a40d")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "e1f21ce551efb021bac1b5a922560eca")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "10c4ae69826970f11e710766ffa7eceb")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "3549eb070675bde71600ebb40906cddb")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/types.fasl"
   :FASL-MD5 "c9ac65853761d8f6b5a8e23e659429dc")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/transfer.fasl"
   :FASL-MD5 "444e48737d778e3b1b0801b0c99e9a8a")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/package.fasl"
   :FASL-MD5 "d2f79385126a30422e5eb6ccffb5b2c4")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/native.fasl"
   :FASL-MD5 "9d6c7d23c4450019fd0188fd1b11583b")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "9dba4e65e2b06b16bee5f3c21d8bc7aa")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/identity.fasl"
   :FASL-MD5 "5dd5c4d15b3f1e09051ca94472cac834")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "2c7e63568d1d90bba15d9d3972ca0abe")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/io/flush.fasl"
   :FASL-MD5 "e4c8e4a65da1e4478a18a9fce6a5cde0")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/write.fasl"
   :FASL-MD5 "1032c57f0a7eb64216ef7fbf37ad00f9")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/validation.fasl"
   :FASL-MD5 "b25a3e4b17672a530afb2e1fe075b47f")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/types.fasl"
   :FASL-MD5 "908a40c091df6271d0abc6acac002a19")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/relocate.fasl"
   :FASL-MD5 "6a90b3ddcb31475349e959d5cddac7d9")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "b50a193988f69a88afaa2204056fbb95")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "72a61769a26a2e7ba232483adfce85eb")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "8dc5f77ef17cf4ee2e41bec3dfb481b4")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "5447be6759b075655787434e702cc649")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/read.fasl"
   :FASL-MD5 "162c235d1ead43c133e9298f1de4d006")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "7abe3edf5928e53b875bd9295af7edd3")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "b61f6e0ac82e715eb6e528285412fbdd")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "c184c4b64d8e11fd17fdcc5c45a027b8")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "22cb2e3fe0d422fb4e35cd126b1c62bf")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "c233c8f22c4cff28eb26372e66a7a551")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "1b4c8ddb8f5d78208efddb9374a6788c")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "f1e108cac2a8a9d43026b8afb3eac2c4")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "ee24b6f83b4e505d6841016badd9d492")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "6f6a8a25084312a9bfc03b35b4386412")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "3dcd978113ef52a297681e230b074e2a")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/package.fasl"
   :FASL-MD5 "a273464629bc5f4f7cd57cdec0db558d")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "90bde43c0ed25fcd252007d0af3e5de6")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "83b701fd92c7f5f266ac13636cad4d43")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/index/core.fasl"
   :FASL-MD5 "a295ce58ba0ec62e6db1810df98df709")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/package.fasl"
   :FASL-MD5 "a306a8ab40a2c95f730d95d9164bf57f")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "590c4eca56d86d0e1b50bd2434164cc2")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "c1f79431625d6c921964b56bbf98fef9")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "3e67c40f8977a6ed5108defda7a530e9")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/types.fasl"
   :FASL-MD5 "8ae889fbfd689a905ca29da31d6b8e3a")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/target.fasl"
   :FASL-MD5 "af9a4cb21649dcfce1d723816d89edfd")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/segment.fasl"
   :FASL-MD5 "7a27d1b674efdebead31a8924c0328b2")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/package.fasl"
   :FASL-MD5 "f5e6cff8a628428da9f7dc8d230029bb")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/lookup.fasl"
   :FASL-MD5 "c86b43c0aa8ed50e8ad9da57c77293d6")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "0c9f0600cd9cd4b65f5a5285785ce44c")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get/build.fasl"
   :FASL-MD5 "435b794d830d8b9dc5c1f74d20d16cfd")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "be448a7f5772d4f02d902ce214fa0991")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "c14c35365e3f312b1397af7c855c1fab")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "1fd5a59075c888c15acf0953b5a3a774")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "2d4f6e5c958828aa712e36735d6421d0")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "9a8f21e770af83869f8eb45896740fe6")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "e9eded65b53ee7fbdb25ec6d30d462af")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "d64385e51e876bf572927309b98f9e28")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "f8f05d427908fb7ee2e3844b565afe48")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "22365c2b1f4205f4b19501823af9f13b")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "521737861e057d663964b0c030552587" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "39487723820516b72d1d13e6082a8c84")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "453fcdb148f244ecafa3e1080f5ad015")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "b2d92f9b41d533445361fa31fd1e10b5")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "a1224764c99ddac8c685a16badbe036f")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "3a9186e73854362af6de16fd552ec1bb")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "e82ef3538fa9a3f7625f3ca6c5ac1afb")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "f308c6780bdb4e3839a67eb57e0bbcba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "6b5379a70a7fe8aec4857f7960626606")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "9b587e020eb57c7922c3c0cb26a211f0")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "016df8368dcad8ba242945adf1a64375")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "dc38de3ed87047fa8d6ab4197a7dec0c")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/record.fasl"
   :FASL-MD5 "66e7d3c54b8a1fe17dea35db7b1d33d0")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/package.fasl"
   :FASL-MD5 "a19fdfa288fdc94ba763c942085afc97")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "453463a7fb17d8e09b69e86cb860e3c1")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "52a5c8f9337ec499225970e09bd880c5")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "2753ab4593b30e92067b2d4cc4be44e9")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "76277315067ee34226639985288cb463")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/writer.fasl"
   :FASL-MD5 "af4525e477d3ff3d5e0bd7bc9a12c87f")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "f5245517498129e18ff419bcc10fdd92")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "5ecd94c3201c94c66b11df7df183687c")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "b72a447cecf5178591394e8c5db913ec")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "78c4acf4e645b5cff6a921b77b391e0c")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/ready.fasl"
   :FASL-MD5 "c5f32a3b08e5ccad4d7af659c13c154e")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "1957cb8b7512bfa75a881fe842ab17e4")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "c7f415e145c50cfc3b0fde51066c2db0")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/queue.fasl"
   :FASL-MD5 "012f4e888c6e9c3c24742f19cf1729d8")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/package.fasl"
   :FASL-MD5 "eb9965699fd8f3260b98386d77df105d")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "db21710c1289c0c56010f5aebeee184c")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/types.fasl"
   :FASL-MD5 "6440b6b83db372055e59060d8e700173")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "7bfeecafa328bc5ed50d9d8381d6e8c3")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "3c4eacd1475f8405e33e40d9758813e2")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/read.fasl"
   :FASL-MD5 "4dd3b986e80120614be24038f012b284")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/package.fasl"
   :FASL-MD5 "06fd15b2c0fed0e1963662b7aeeaf388")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/epochs/core.fasl"
   :FASL-MD5 "852d74e9ab0ab9e270a81c70c920a099")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/csn/registry.fasl"
   :FASL-MD5 "fb4f2a72758b9032b42f53efa5ef3cd5")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/csn/package.fasl"
   :FASL-MD5 "aba0df2f7328c80d963771c16713aad8")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "441b26dcf86ce499f2da2d47b6ae3920")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/package.fasl"
   :FASL-MD5 "6b850b8feede285157d2c63c8906e76a")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "5a27a94424334485c214793e3a389767")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "9e2a19fab279c86677030efe0aa85ff2")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "f4326eb18e9a73b7cd5b79865c284f79")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "981d0d434a8036d310d5c3978c1aad18")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "e7c739fea601f9dd26ad3f2f2774e5de")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "15d8e5b5c8b38222ecf7537939b6b6ab")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "47a918de17e9b8b1b9bcb5fd9db84f67")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "e3099a42c45fd0e7b99a24b9298059f3")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "19c95c219e45fc856a3cf6b408d0a2cf")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "5c089b426e387f47eb5ed96651d1b228")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "0a039ec18e42578427c17b5746801581")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "14d6eaab7526acb9d53226821c3633e1")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "f8f2a03d3f0d8117ad8afe2d6c2708c5")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/write.fasl"
   :FASL-MD5 "81023e8eaad04d0a88677d0c55ffd56e")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/types.fasl"
   :FASL-MD5 "19b9c19d20c16576b3712c467169effa")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/read.fasl"
   :FASL-MD5 "c0dd6cf492004790c6a56c2b84ac7cfc")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/package.fasl"
   :FASL-MD5 "1ab5d12229c29862633a74033d75e906")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/core.fasl"
   :FASL-MD5 "d886fc6297032c663411916ef91f13c6")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/clock.fasl"
   :FASL-MD5 "406d0905915633b5ef20624e619321e4")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/accept-active-closed-duplicate/fasl/src/cache/build.fasl"
   :FASL-MD5 "e787739b3c76c07538104d8d103ae371"))
 :EXPECTED-TESTS
 ("TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED" :FAILURE-KIND
 :ASSERTION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "1c847de175f4954cec5ef2186308f1a7")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "f308c6780bdb4e3839a67eb57e0bbcba")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
