(:FINISHED-AT-UNIVERSAL-TIME 4000908526 :CONDITION-TYPE "SIMPLE-ERROR"
 :DIAGNOSTIC "Asserzione fallita: (EQUAL
                     (LIST
                      (ARCDOCDB.GET.RESOLVER::SORGENTE-GET-ATTIVA-SEGMENT
                       (ARCDOCDB.GET.DIRECTORY.TESTS::DIRECTORY-SERIES-FIXTURE-SOURCE
                        ARCDOCDB.GET.DIRECTORY.TESTS::FIXTURE))
                      176 0 NIL)
                     (MULTIPLE-VALUE-LIST
                      (ARCDOCDB.GET.RESOLVER:RISOLVI-CANDIDATO-RADICE-ATTIVA-GET
                       ARCDOCDB.GET.DIRECTORY.TESTS::CONTEXT
                       ARCDOCDB.GET.DIRECTORY.TESTS::CAPTURED)))"
 :SCHEMA-VERSION 1 :KIND :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE
 :TESTS :COMPILED T :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "3e565b431b88fb5211023601b5e3ce3b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "cb8f09194d320818ce0a3b7b24c153f2")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "face5c31b83a687bdc36f906dda290e3")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "cc6142d659ca2b8861b025b4b7bcb3cc")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "6ebd870c4a2d85f1643bd04f8acf1776")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "52e1b6c04dce9679258adf9ecfe4917d")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "76ea1ff5889db4e8b1dac369a7212251")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "e5132298a0662bb8b534286dbc680903")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/types.fasl"
   :FASL-MD5 "be3f365ddcf4b71563158982b9ecde05")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/package.fasl"
   :FASL-MD5 "7ef0b7fd621416f6fff69a7c3850d337")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/group.fasl"
   :FASL-MD5 "e4e0a8b698aa613bab66a29f9501d255")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/executor.fasl"
   :FASL-MD5 "cb57ee81658fa34561a8ceba42f1e3ab")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/csn.fasl"
   :FASL-MD5 "74edeedd8893ce2b0c8f9562f3541937")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/wal/builder.fasl"
   :FASL-MD5 "66eceaada65774639beb384b04287654")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "fca6246f782432f4992fbc80f6d96e35")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "8af5293b89211c48f59afc9bbdf9e457")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "fdb0d2b9d81b573378345ea8ec3120c8")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/package.fasl"
   :FASL-MD5 "25983bdca0979e17243935bd4b8ac35a")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "cf636b018626fa0d186cedca1737adec")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/formats.fasl"
   :FASL-MD5 "d143e440959c4457cb5862d180276b1f")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "752880a9e0bc54aad2d05f36673f84ec")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "90e92b47f434fa702297e3778f1b6b5f")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "fba3437cdc9c5957b84bc3d26a1a0a8d")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "681e139a9b300c6d5dd848717b3d70c8")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "f291ba6aa0342ee505362ce313e816b2")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "53e484b7f595e6be2ca9af48070a603f")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/types.fasl"
   :FASL-MD5 "e4a3a5975f338eeb7ed62d89e7ba3910")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "aeb6709a873ed01daa91141c589abadf")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "cc1b60b9901a9288cda7e4ab14be34bd")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "ba31604d98cc828d351c85f1a4b5e8c8")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/retirement.fasl"
   :FASL-MD5 "00ea83d0833c4cdea8332afb25396915")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/query.fasl"
   :FASL-MD5 "4fcb8d2a859398fe2a7f81b1fe5e0159")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/publication.fasl"
   :FASL-MD5 "2aacd64cd11b6023ebc2cb8f5c7e2458")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/package.fasl"
   :FASL-MD5 "f197efe1231d89a41c61400eea7ecbac")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/ownership.fasl"
   :FASL-MD5 "757a455d85c39170b5b5a00187ac1345")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/io-events.fasl"
   :FASL-MD5 "a3c8805d1cc53d1eec25ce6eb1049f6f")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/series/events.fasl"
   :FASL-MD5 "ee61ba790079d7f0a32af29cf937e892")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "086f677d7436a12dd6735fac20e6a14b")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/package.fasl"
   :FASL-MD5 "3d7e26324f2576314369e85a5f204be1")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "d8f2bb445b7f6e3c6dd2335404a2926a")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "597a298c947e516413c39057063cb51a")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "7ab406fee790d2d64174341dd34e73b4")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "d26517ffe3d60167f84bf5fcf583d217")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "7865ced9353aa257ea6928599f432f5b")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "75186a70889775330b35f32e4642e16c")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "8737e64fd949182ab1d2191e1cc5b6e8")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "e81c3238b636bf5f58c8e90dea1a005c")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "2ca393254909a3008ad907bc39e65637")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "22d0afda03c9419e6eb1072eb35c54de")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "35a39c8bb40ccce18232156627340778")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "7bdd432214ef62738321d9b0617a4767")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "94ad2abe347491f812d27fb889032c4d")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "94c48174165c917cda0fa2f8f6c8655b")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "971f0efdea5c5e506ee42d29eb6165a2")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/types.fasl"
   :FASL-MD5 "0efe281f63ec5de16a411c2acac48296")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/task.fasl"
   :FASL-MD5 "80f0890d467f83ff0901931b2a20dd22")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/package.fasl"
   :FASL-MD5 "49730f29489f82e5d8023a2549cc593c")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/read/core.fasl"
   :FASL-MD5 "a75e86af3766630b5d9d6f11bce4ab7f")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/package.fasl"
   :FASL-MD5 "661909ea0195773d8f6320a5668e9ae1")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "42b6ec29a11b47b68868250a8866fb87")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "ee85adc1fc3954f3b22153dd11ffbd33")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "061d43526f469c1b5ab65d42a085665a")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "6865530fa0bec429f741ad993b137e1f")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "d5f0c67301c1113416082ad5db92cf48")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "55fd2d7852962449a9607f0ba33e1e1b")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "f1990859433f74ac665844ca58ea7600")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "5e8c1e2b29f3bce49c7aa7a9cc21d578")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/types.fasl"
   :FASL-MD5 "f789b0726dcb0ef3d53b466a44b2507f")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/transfer.fasl"
   :FASL-MD5 "0b512b64c446576e3e2c2ae212f2cb71")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/package.fasl"
   :FASL-MD5 "bdecb72be17e871e7362b181ab2b4988")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/native.fasl"
   :FASL-MD5 "e6e304508655cf3339c88ecb089c9714")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "e52b0d800d772e5c6d5caad32f5432bb")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/identity.fasl"
   :FASL-MD5 "bc4ecb606d573449e7c86b7b8a0bae6d")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "8abaf12f3fec1fa309d3e8d9fde0c5fc")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/io/flush.fasl"
   :FASL-MD5 "2b9eaccd11d9c89bccfe332288a38f1a")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/write.fasl"
   :FASL-MD5 "cee77756ff7e2b0a5c6bdc0f8ed9e251")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/validation.fasl"
   :FASL-MD5 "6d2bc4996254c991ffaf9c253a1f5994")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/types.fasl"
   :FASL-MD5 "ce4c7c970728ba4142be6f3122881e75")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/relocate.fasl"
   :FASL-MD5 "d5fac594a09c6f83e835a87253d7d851")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "923249bca8b1fa3c4a2faf8df1c8587c")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "57e71bba92f80072d380c3a1de7387dd")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "186fa4e9e4ba972197cfcf5027feec02")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "75ec13783709687d7995e8a655ba1404")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/read.fasl"
   :FASL-MD5 "a91e8ecc3673bbaae89c15cf522a9fe5")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "6a2c67f834c595ef9b81028540042546")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "6800d7e7f84cf44bda128ad4da66eabc")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "d99165f0ac4e82a0ef2150d5aa207fc3")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "4dace1df1a3fad1fe4e739e6ac7536aa")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "de2568c40f1904b40b9755bcd4e11bd9")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "7a5e9f423a40e36ab1415a5892969fd4")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "53050189f4a4e17a471eee9ec4a127ef")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "a688f013713f09a0ea308a1d8a88fbf0")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "fefaab8082452a01175d1b2846e5694c")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "e51ea73cf4eaf5d73c9de4a9775f337c")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/package.fasl"
   :FASL-MD5 "46a08a95803d41ce943fa5db433bee71")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "56eb1e58da04e24d29d316e8e939caa0")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "3815a5b94f675787a4a6e06cc254196e")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/index/core.fasl"
   :FASL-MD5 "8cfba49e040d7ea8ba04df241a4e7db4")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/package.fasl"
   :FASL-MD5 "dc94bcec6c53ce97df23b0d3888d56a6")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "2aad6b1f2b1de02c3075103b1df409e0")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "ff76d1e72f0e217c210307468476da35")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "dfc436f681bdd2e3299c28396bfd4283")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/types.fasl"
   :FASL-MD5 "0d579ef19710d74741af8216bb6e4d2f")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/target.fasl"
   :FASL-MD5 "3e28f68ca76e0e74a5d4ed4a460ec27c")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/segment.fasl"
   :FASL-MD5 "bfacccc6b47d85547c7b7bcac6575da5")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/package.fasl"
   :FASL-MD5 "1ca85497f80e5cf521ead2ecdb50cd98")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/lookup.fasl"
   :FASL-MD5 "e89b644648eba44ec700da3bb44eb424")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "c81257100230d5a1e8408a94a5ab72fd")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get/build.fasl"
   :FASL-MD5 "a3c7d11d9aef25ef188886ff2c12df08")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "304ff63622733e0de0d860f175e5e3f1")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "8515246af62b62fb03cd0ba4f30acc32")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "75ca9639b232d3b938e7fa21053fd95d")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "ed9174c84811faf123146b9e595f33a5")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "3238224cd530d5a2415a1c92bc38452c")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "c3bc8fb60a3aaf6f5faabcdbdf60425b")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "2e73bef53c43c63c596d7daec53abdb4")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "8eed5fad69c3e7a56c2327ca2d95a087")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "b66c34b07f56ed86559f4e1e1aa76009")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "96f146f885377c6d102c0af49f05bfae" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "8acf5f10b34e05afff54dfe993172b21")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "4dacb08d14258616049e536d8ea0813b")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "db561dc03284dd1002c4505d2b37c9c3")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "b8f1268c147cb96897d457bcb4157f25")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "6975ea4a322009417461cec1ec27d903")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "b6ccaf0764a0452432229a8c552f5639")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "2b8193aab6801de19e26fa55e7c53f87" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "3adca8cfc609d1a3b3019f030fb1c764")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "74b360607af7f6b23ce31f850c1d291d")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "20f2cf74f5030c0b9905109a28c063b5")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "22cc9d0ca827f22deacfdac1b3d5e60f")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/record.fasl"
   :FASL-MD5 "d4d531291afe9a3a94328a27e5eee9e6")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/package.fasl"
   :FASL-MD5 "44e6fd241e938882574a1b897f196de2")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "63fe6224ba7cded1bbe9ba9071cedd84")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "bda7adb43fd01cc161065469f44b67f9")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "15463f1ba1d0a3c7e8f5a18a5711bc8f")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "e1aa5911f0122f5396c995786b3d2ea8")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/writer.fasl"
   :FASL-MD5 "e352d4860fc96ce529f6a9abc2fa98d9")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "da2547475c472ba341dca1d581fa4d63")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "d18056f73c87330d20e70744e9e64997")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "18bf04b6e05654d41b08a1f6756560b8")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "24e934d2645e7cc139fae67f2ba56a97")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/ready.fasl"
   :FASL-MD5 "4ee5a656e669ae6459e15b8037d0fa3d")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "141229ce3a2ad9f7657eb990b426d07a")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "f8e6f4d4bb0fbc596cf98b15f46a8a2b")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/queue.fasl"
   :FASL-MD5 "64320e08cfed26123db90e05c812e297")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/package.fasl"
   :FASL-MD5 "f2b4b4ebd15e891b29cb432ff0091b57")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "37716607766be721b6af5c07fbb505c3")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/types.fasl"
   :FASL-MD5 "5a0762103f3c6e53e1ed48b6828328f6")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "c9d29509ba869774c6a1f804c6dc10d2")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "4045c152124538beb54124993b7a2f24")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/read.fasl"
   :FASL-MD5 "25a080b8c68d2cb7d18ce89c96e85598")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/package.fasl"
   :FASL-MD5 "90adb4e1203c3bbefbd62285b46682ca")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/epochs/core.fasl"
   :FASL-MD5 "950440625b2c4eb7889fe1e401a6f861")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/csn/registry.fasl"
   :FASL-MD5 "4ea60f02e68e89fc7bf508020810eb31")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/csn/package.fasl"
   :FASL-MD5 "e5d8e7a1fa108f34edf7243492a5ecf0")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "b132f6888fc3da0cb2de05c76e0dc9e9")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/package.fasl"
   :FASL-MD5 "6bbc7e58e5101597660c24c9c54ce832")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "38cc4cdb69f553e079f162a3e1c76994")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "150925a53dafed0c6a38a8ccb01eb93d")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "8f93cbbf0e9c0d5fdba053cd75da18bd")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "1fc8a2e6b0cc4852c78e5c9bd6481af0")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "2417a786fd7277e4ccb205127c1a4f15")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "00c80d225d2f5e6e911686e008a85d50")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "645fc7cc54dfd5b4e356a5e717833a13")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "3f766d24581f923c2d164033e8f02ba2")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "7e23f8e23fa9d0daccaa00ce5f221b85")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "5e6f42a9ddecbe1ecb7d742244deb4a5")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "e3fbcefd4a61bdeaaa49df5b60ecf8f4")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "43b55170ee0803623883bca96398af4b")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "90f7c2838d28982963434ce37ae0074c")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/write.fasl"
   :FASL-MD5 "f463169218dd6dcb868a0ef3189231fd")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/types.fasl"
   :FASL-MD5 "13f11a685e0c6f53d10ffe5043113fa1")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/read.fasl"
   :FASL-MD5 "b797ab7d23938ad034385cd885a4415d")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/package.fasl"
   :FASL-MD5 "0725701d33c90cb8a75630c3f5d98dbf")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/core.fasl"
   :FASL-MD5 "130bb70ac5a667ba5691c523069a38c7")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/clock.fasl"
   :FASL-MD5 "5c798db00a867e7ae66a43307cb83272")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/active-end-one-byte-overrun/fasl/src/cache/build.fasl"
   :FASL-MD5 "3a5b0b45345c370b225bc682475cf157"))
 :EXPECTED-TESTS
 ("TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
 :FAILURE-KIND :ASSERTION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "1c847de175f4954cec5ef2186308f1a7")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "2b8193aab6801de19e26fa55e7c53f87")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "96f146f885377c6d102c0af49f05bfae")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
