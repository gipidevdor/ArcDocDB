(:CHILD-REPORT
 (:FINISHED-AT-UNIVERSAL-TIME 4000908502 :SCHEMA-VERSION 1 :KIND
  :GET-SERIES-MUTATION-CHILD :STATUS :OK :PHASE :COMPLETE :COMPILED T
  :SUITE-COMPILED T :COMPILED-FILES
  ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
    "3e565b431b88fb5211023601b5e3ce3b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/tests/get-directory/series-read.fasl"
    :FASL-MD5 "f59b9e53f7f2caa33a474007de7bd1f1")
   (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
    "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/tests/get-directory/series-support.fasl"
    :FASL-MD5 "b62a75b68339a81bd160c999c3a7fd41")
   (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
    "63dd01c852de1399c2c82274d481d257" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/tests/get-directory/threads.fasl"
    :FASL-MD5 "3d044ea0d1c709b651fb4e3ae4537fa3")
   (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
    "d1ab36d05cc1266e4533d27c693f12f4" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/tests/get-directory/read.fasl"
    :FASL-MD5 "1cc39fc742b56c0182096b9fda2c24e7")
   (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
    "1137938073e71d6d8d62c751fbad05d5" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/tests/get-directory/construction.fasl"
    :FASL-MD5 "2c92ec8d1454155fffb3a8dd2910970f")
   (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
    "3f868ebe4307ad4238b314c37eceed9a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/tests/get-directory/support.fasl"
    :FASL-MD5 "faf9ee15ad315c8bc30f426fbf164fec")
   (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
    "758adad069aec2f9dbe0635797314ff6" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/tests/foundation/support.fasl"
    :FASL-MD5 "3351a4af86c07db940a56a68b9ec13a1")
   (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/wal/types.fasl"
    :FASL-MD5 "2baa2a7fbb1303e3c9284157e07dd62b")
   (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/wal/package.fasl"
    :FASL-MD5 "9d3ca7f2d50a9fec3b97a8d3d78540e1")
   (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/wal/group.fasl"
    :FASL-MD5 "a53cb1d181782bec04b8380cf76a0089")
   (:FILE "src/wal/executor.lisp" :SOURCE-MD5
    "c0340924c9130e14d0e8efedeec078f1" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/wal/executor.fasl"
    :FASL-MD5 "dab590f28fa0d49fc94beae60d0e459c")
   (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/wal/csn.fasl"
    :FASL-MD5 "99f5229059f2efc7882d79fcf563d5e9")
   (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/wal/builder.fasl"
    :FASL-MD5 "82d895896a57eac6cb5104ec1aeb6bdd")
   (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
    "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/storage/segment-header.fasl"
    :FASL-MD5 "a970b5d5e1393487a91e7a9001902e4b")
   (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
    "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/storage/payload-write.fasl"
    :FASL-MD5 "78a5f223bbc515e74b76bd5c73a56489")
   (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
    "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/storage/payload-record.fasl"
    :FASL-MD5 "3bd8cd145a0e537c83a6ba93373edd35")
   (:FILE "src/storage/package.lisp" :SOURCE-MD5
    "f86bd104f20616a76b42c02227f72844" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/storage/package.fasl"
    :FASL-MD5 "cc046bde2b97abdfc0ba335451462387")
   (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
    "b53d27dcc9f4badf18b50519c50bc614" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/storage/log-header.fasl"
    :FASL-MD5 "097f5f1926f520c70fc36e0301170e84")
   (:FILE "src/storage/formats.lisp" :SOURCE-MD5
    "061147be459d8d3b08c661bd3f91d152" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/storage/formats.fasl"
    :FASL-MD5 "46bbec65af09e494bbd408e449b801ea")
   (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
    "cb64f806b8d69eb42d865b4abfff0b27" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/storage/control-payload.fasl"
    :FASL-MD5 "89b49884687994e3078a6bf0b40f3404")
   (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
    "1cda77a357ab2147035993b72d135a37" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/storage/compaction-scan.fasl"
    :FASL-MD5 "679fbf366e851ed48154742a134bd98d")
   (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
    "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/worker-types.fasl"
    :FASL-MD5 "14310fdb3af80a4c498ac761ea5341af")
   (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
    "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/worker-run.fasl"
    :FASL-MD5 "68caa72076c68d6bbaaf65d21b2d0440")
   (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
    "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/worker-package.fasl"
    :FASL-MD5 "62ea6be61c84ef99374aaad8ac003273")
   (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
    "2340e0c9074f7b1bf80c74f774986bc5" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/worker-boundary.fasl"
    :FASL-MD5 "45070a9baa9415e16b65cda19fac9250")
   (:FILE "src/series/types.lisp" :SOURCE-MD5
    "ab19ec8d15af91511e817858c41cebc8" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/types.fasl"
    :FASL-MD5 "d0a950681acc18d6b85c6cc9911b18c1")
   (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
    "ce649df47dd38888d5103c98345f7e41" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/routing-types.fasl"
    :FASL-MD5 "ee6df7b50d94dac6f8746988f96b47eb")
   (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
    "e0f987d8767744050ec4d1b3ecb699ed" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/routing-select.fasl"
    :FASL-MD5 "adcce313bf405fd7ad4c5e2dfc36c9e3")
   (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
    "d6924deff152b941bd49f0bb200b4197" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/routing-build.fasl"
    :FASL-MD5 "ca90edaa75ed6d358ccc793c7462ce4c")
   (:FILE "src/series/retirement.lisp" :SOURCE-MD5
    "b8e04971b8ad75a1bd0c722997badfd2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/retirement.fasl"
    :FASL-MD5 "ec881d445827d801e93bdf36116422f5")
   (:FILE "src/series/query.lisp" :SOURCE-MD5
    "cb0d91405325b508e6b2ab24d178de7a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/query.fasl"
    :FASL-MD5 "901969cd9303568a62e9a3723d9a8136")
   (:FILE "src/series/publication.lisp" :SOURCE-MD5
    "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/publication.fasl"
    :FASL-MD5 "7bf07f09b83dae6f409b48efebafbf13")
   (:FILE "src/series/package.lisp" :SOURCE-MD5
    "59e3c59c90d8d0fc5731b87496a785aa" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/package.fasl"
    :FASL-MD5 "515856904b5110dc4fe616bde73afdfa")
   (:FILE "src/series/ownership.lisp" :SOURCE-MD5
    "de1aca16a35d34d16aba12ff541c0d2b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/ownership.fasl"
    :FASL-MD5 "82931cc85e909dbfb00f8be95c682ef5")
   (:FILE "src/series/io-events.lisp" :SOURCE-MD5
    "b6026a8b7bb64b45c37a65effda70d8e" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/io-events.fasl"
    :FASL-MD5 "1f8bc6984bceccc7d9fccba0cb081e26")
   (:FILE "src/series/events.lisp" :SOURCE-MD5
    "32b2156739a6f2ca996abb91df0a2603" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/series/events.fasl"
    :FASL-MD5 "04ba4ea68aa1fa24adbe2f12ea3b0686")
   (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
    "fcacd15460db25ea9cc4036065f9f096" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/scan.fasl"
    :FASL-MD5 "1d48110f6b3a68a43d0efab8b2663355")
   (:FILE "src/recovery/package.lisp" :SOURCE-MD5
    "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/package.fasl"
    :FASL-MD5 "b226fd48734acfb9d959957142e7d42a")
   (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
    "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/manifest-types.fasl"
    :FASL-MD5 "d1210e11684d5811b286ceb841d8502d")
   (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
    "ebd7a54adea2213294a887e6d4db0927" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/manifest-query.fasl"
    :FASL-MD5 "8835a160ccfc50ff22a360cd01e95a8a")
   (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
    "37ace42844c11b52446ee1fc500b8e0b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/manifest-package.fasl"
    :FASL-MD5 "54ea578577472dea81571287aeb9a729")
   (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
    "e0d2498db1011e857b7b0daa1934f187" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/manifest-fold.fasl"
    :FASL-MD5 "b695b39e3ea376d25bae3a7b9f89b40e")
   (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
    "67975249aaabd751757cdfb9222cc3c4" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/manifest-decode.fasl"
    :FASL-MD5 "bf12f4998b11b8eff7495590a4ad8447")
   (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
    "bf65b1731eab6e0572461ef5cc60fc40" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/manifest-build.fasl"
    :FASL-MD5 "b9f422210cbf200088f72baad29241b6")
   (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
    "78c136d5838dcfe3019d9069643a8d8f" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/inventory-types.fasl"
    :FASL-MD5 "05ecb8659a22f443f4d7418670f48264")
   (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
    "fcea263de1938767772e5b11411ecd5e" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/inventory-query.fasl"
    :FASL-MD5 "6d3f6bd9a1e40bbf738a79ee41f43531")
   (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
    "9bd6820c4feba3e552aab1a4edd87861" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/inventory-build.fasl"
    :FASL-MD5 "0b41b0f7ed406330135b77cca7457d99")
   (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
    "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/decisions-types.fasl"
    :FASL-MD5 "2196a173b093b7c084af46dc1205f425")
   (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
    "b33e57a643f2fca810846f6226366253" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/decisions-sort.fasl"
    :FASL-MD5 "96b87bad655065650096246e280112e7")
   (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
    "852149de4c289b8e067602780378d87a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/decisions-radix.fasl"
    :FASL-MD5 "488dd9bad60da3b39499e7719342e270")
   (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
    "f782d1137b8ce342b91c9999cfb7accc" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/decisions-query.fasl"
    :FASL-MD5 "e78a657aec6775e664263a3a49af71e0")
   (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
    "cbdc30f93109c474e1fc25066c9b9b13" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/decisions-package.fasl"
    :FASL-MD5 "bd452dc2d8c8705a568b32d06cf02bab")
   (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
    "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/recovery/decisions-build.fasl"
    :FASL-MD5 "0775d98d18be5f24d7782b8c9e60c68c")
   (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/read/types.fasl"
    :FASL-MD5 "81301fb131617506ff307f19940ccb37")
   (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/read/task.fasl"
    :FASL-MD5 "be136ee74384ab24f7ea8fb6fb0dc64b")
   (:FILE "src/read/package.lisp" :SOURCE-MD5
    "7d74d9decc5a0bc9f9331d89bd503e21" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/read/package.fasl"
    :FASL-MD5 "dade1e02ccd7f9aa65818b10216c445f")
   (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/read/core.fasl"
    :FASL-MD5 "dbd62ad6152c7d27ea75f83a6ca21dd9")
   (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/package.fasl"
    :FASL-MD5 "fb2304524acd097de8c93539473b7ef2")
   (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/mvcc/types.fasl"
    :FASL-MD5 "f27d3b936c1f06530fdef99dc84b563b")
   (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
    "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-types.fasl"
    :FASL-MD5 "f2b3119eff9f2316f0377121b6e56821")
   (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
    "2d5a795bcefd605c75da91c725ae83a2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-register.fasl"
    :FASL-MD5 "64a1cef3cadfe39ceeb4e4772001fcd4")
   (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
    "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-read.fasl"
    :FASL-MD5 "0d09667f120a1418ad7b66417d02853f")
   (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
    "ff98aea5cb9a7ae2671f6a887a003725" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-lifecycle.fasl"
    :FASL-MD5 "c406783d39d04c4641d538dd9c809259")
   (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
    "0e9365e674d1584b111f915ce1f58634" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-csn.fasl"
    :FASL-MD5 "d8719a85f8de1e5aadd31e0de73db678")
   (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
    "8bb066aab61a18eff175b9edb11e42a2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/mvcc/snapshots-core.fasl"
    :FASL-MD5 "dd701a8284bba30c91d04c65fad3fd88")
   (:FILE "src/mvcc/package.lisp" :SOURCE-MD5
    "f188d1dbd5d0adb49f53acf09157aef9" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/mvcc/package.fasl"
    :FASL-MD5 "64893318d04be5e8f486cf6ff36fd546")
   (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/io/types.fasl"
    :FASL-MD5 "8d423c3f14103e7240a4dd396d5a178f")
   (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/io/transfer.fasl"
    :FASL-MD5 "2a28893b411a9d3196ee14eea8a91b93")
   (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/io/package.fasl"
    :FASL-MD5 "95d3adfe85b722b697bba3809664ad2b")
   (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/io/native.fasl"
    :FASL-MD5 "9781252ba849317de8140e665458f30c")
   (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5
    "11c7103efbe733bbf0a13927f23c3d34" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/io/lifecycle.fasl"
    :FASL-MD5 "4235bdd7e738b7f4b5f24faefac7bf6f")
   (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/io/identity.fasl"
    :FASL-MD5 "e69be50e1b6adb3150d31d3509f58a93")
   (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
    "d354a095fb378c1b6f27397ffb902227" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/io/identity-types.fasl"
    :FASL-MD5 "22912292375831c126cfcdcae6afe2bf")
   (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/io/flush.fasl"
    :FASL-MD5 "f682601d510d0a51ce90af1260fba6e0")
   (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/write.fasl"
    :FASL-MD5 "813b072efb9e08766793f7e588204144")
   (:FILE "src/index/validation.lisp" :SOURCE-MD5
    "3384cadf737c7d80c004222022a281f6" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/validation.fasl"
    :FASL-MD5 "7db5dbfca05265ec8716588eeecd8702")
   (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/types.fasl"
    :FASL-MD5 "7464da43e6b7e4c94eca8553c49d8cb4")
   (:FILE "src/index/relocate.lisp" :SOURCE-MD5
    "475dd7d5809a836f01544b447cc8df27" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/relocate.fasl"
    :FASL-MD5 "7523c06e062294e580e94ef2517cc70d")
   (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
    "a450cac8071513365267e7024cbe94b0" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/rebuild.fasl"
    :FASL-MD5 "628f6ffae5d41f039c33195d7ad2e8b2")
   (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
    "1188e7a64a7a5d9482c1233cb9acb452" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/rebuild-scan.fasl"
    :FASL-MD5 "305a1da732a76514d2fadd9c2e0d54ce")
   (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
    "8befbbd00ed5c31c1487a11887eba495" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/rebuild-copy.fasl"
    :FASL-MD5 "9d1a3c83d6444e9e7b2c14aeddfc5f38")
   (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
    "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/rebuild-budget.fasl"
    :FASL-MD5 "df0b5c177f952421d08b9aaaba6e9dc9")
   (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/read.fasl"
    :FASL-MD5 "205c32f89debef887fbe132f9c876dae")
   (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
    "e8e31e599356e592af29c0cc4604872b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/primary-write.fasl"
    :FASL-MD5 "757b9a2269ea86ca2c1c8eeaf2b257f1")
   (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
    "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/primary-types.fasl"
    :FASL-MD5 "bd8ed570848f8dce031e158789e60cd6")
   (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
    "5155959766645d3172ae5e73c58cc071" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/primary-relocate.fasl"
    :FASL-MD5 "5e52030f1d64531664e35ff3f7757766")
   (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
    "3f317a0d3c5ee86a73651aad36135cc3" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/primary-read.fasl"
    :FASL-MD5 "2b066bdf42ceedb388cc3b9a4532fef1")
   (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
    "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/primary-probe.fasl"
    :FASL-MD5 "306b0b39bd83ca9f9e3e3b3e2ff1e2b6")
   (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
    "d65cfce399b04f905bf969929962e59a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/primary-package.fasl"
    :FASL-MD5 "d140535dbfac8d5de642a51ff9e76ba2")
   (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
    "1dd67c527257e43f17e006644ecdbd00" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/primary-directory.fasl"
    :FASL-MD5 "a3953b2f19ef8f04765434f26f5a7582")
   (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
    "fa52433eae199ceeb874bf2bc47afca7" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/primary-core.fasl"
    :FASL-MD5 "1387e32bd7c74344b8814e959b14da4c")
   (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
    "ff2cfbb865290d7a1510fdf6877c7229" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/primary-build.fasl"
    :FASL-MD5 "1d6ddbc8f134a679bbbd17e42565f145")
   (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
    "a319691e3e28b7ea7b927de490cf69ba" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/primary-arena.fasl"
    :FASL-MD5 "f03c8c2a5cadb8eb1142510bb929476c")
   (:FILE "src/index/package.lisp" :SOURCE-MD5
    "598a9b65e73151c924b2cdcaf6d96705" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/package.fasl"
    :FASL-MD5 "f82626d9a73f0f2305aa1aae86df2236")
   (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
    "45ce41749bc6fa638539815d3f802b96" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/hash-seed.fasl"
    :FASL-MD5 "0df5c61a36d0727b4b419c21b545e1a5")
   (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
    "43d2209225707352daec6186ef95a805" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/hash-digests.fasl"
    :FASL-MD5 "fc9ae81740ab9944eac30cc8e00a3fcf")
   (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/index/core.fasl"
    :FASL-MD5 "1572e3a57202d5f7d891c42a31a48a28")
   (:FILE "src/hash/package.lisp" :SOURCE-MD5
    "2d9060e41bc5252067d35e59ac70ee06" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/hash/package.fasl"
    :FASL-MD5 "f87900be966305ff0105fad801a61bd3")
   (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/hash/hash64.fasl"
    :FASL-MD5 "01534826d10e7004f2c2e47c4ceab40a")
   (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/hash/blocks.fasl"
    :FASL-MD5 "98fbc9cea3d889c926b88e956051d786")
   (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
    "b5c51802e607e3dd22de68204baf64e9" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/hash/arithmetic.fasl"
    :FASL-MD5 "bd4cc44122394162f1f7ef174aefc59d")
   (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get/types.fasl"
    :FASL-MD5 "4f7a8b48594effb9b444f72a063320ed")
   (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get/target.fasl"
    :FASL-MD5 "3d5ea27b8834a20fab2f0bd235b621e6")
   (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get/segment.fasl"
    :FASL-MD5 "a02e62c8ffff467056026bda10bc79d7")
   (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get/package.fasl"
    :FASL-MD5 "8258cc5e2c26d36a09f104cf9ce84d65")
   (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get/lookup.fasl"
    :FASL-MD5 "77a92d3a47cabdfd6c349f9b19563637")
   (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
    "e70bfeddd694336bbd088e65f8761834" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get/lifecycle.fasl"
    :FASL-MD5 "458405c557ce6b7ff6ff70086b5c08ea")
   (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get/build.fasl"
    :FASL-MD5 "774be6b0358b66b7992b038f00fcf012")
   (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
    "9df13bcc6908e9fa601d173a671e1ccf" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-resolver/types.fasl"
    :FASL-MD5 "d6c5551c0ffd3d21717f1a80f3fc0749")
   (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
    "2d869293ba47444c4721713d955c6254" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-resolver/sort.fasl"
    :FASL-MD5 "b779484b24ad669f8d46f6637ea73465")
   (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
    "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-resolver/scan.fasl"
    :FASL-MD5 "f3fc9187bc43d1b58e84941cd9e1edb2")
   (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
    "ca9002b81efd0aed9761cd1f78514762" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-resolver/rows.fasl"
    :FASL-MD5 "ca61d41c8a36fae261aa1adcacebca40")
   (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
    "1339edff0223dbf122f11ff0adbba61c" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-resolver/read.fasl"
    :FASL-MD5 "cb94e7c01464663caa3b117027653572")
   (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
    "6226d131f5562a475048b6444049c4ca" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-resolver/package.fasl"
    :FASL-MD5 "5eaceeb475e5180b0747a14417447219")
   (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
    "bbfb2082103e6712419e180ab972245c" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-resolver/build.fasl"
    :FASL-MD5 "a4279ff8552baeb079d43d0ee0e5db5e")
   (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
    "bd7182e9871fe82530d0c828e473ccde" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-resolver/active-types.fasl"
    :FASL-MD5 "368e2eba9850cbb0d42f2579ce0ca3b2")
   (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
    "d6aaec49504a96f37c8ff1bc182c977b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-resolver/active-scan.fasl"
    :FASL-MD5 "51babf0ab7826297dd73f6caa7e6d1cf")
   (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
    "521737861e057d663964b0c030552587" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-resolver/active-read.fasl"
    :FASL-MD5 "bc05cb87d38ca18b75fd7f31be4006b1")
   (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
    "f13d422adb6aa9e8489352884137f25a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-resolver/active-preflight.fasl"
    :FASL-MD5 "027f48c0762fe7f38b64b71a5106cd43")
   (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
    "6d95f29b331d335175843f47ae44a6ea" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-resolver/active-directory.fasl"
    :FASL-MD5 "6222ab793fbe7b5d6cea031528d23d56")
   (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
    "c65593cf172f53a8e90a853bbe9504c2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-resolver/active-build.fasl"
    :FASL-MD5 "7b4a37c769520decd13818bfec51e1aa")
   (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
    "17c957d6934a31f4ed64313e756de2d2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-directory/types.fasl"
    :FASL-MD5 "db96af98280a308e69b1ed53c263830d")
   (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
    "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-directory/sources-types.fasl"
    :FASL-MD5 "865a90f75f9331e86f250b042d2c63c4")
   (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
    "2b8193aab6801de19e26fa55e7c53f87" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-directory/sources-read.fasl"
    :FASL-MD5 "2f71d7a6cf3ab7b695d0d8d02b9fcd70")
   (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
    "74a694385f1aaf03ec87721545494119" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-directory/read.fasl"
    :FASL-MD5 "2a006dd8461211711d6b4c48d25e4b56")
   (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
    "894f6e238fe4047f2bf607fceae86846" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-directory/package.fasl"
    :FASL-MD5 "b75e2cb66159cd3fc8135efc7d7f2827")
   (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
    "cde24b2bf5c5637d5501b95bed47df31" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/get-directory/build.fasl"
    :FASL-MD5 "311648850cc0dda03be4e5d695fe4e03")
   (:FILE "src/foundation/record.lisp" :SOURCE-MD5
    "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/foundation/record.fasl"
    :FASL-MD5 "e6c7da96e8511a25ef2bbd2d5d97f915")
   (:FILE "src/foundation/package.lisp" :SOURCE-MD5
    "5ee593a112958d94163dab17c5aa4ba2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/foundation/package.fasl"
    :FASL-MD5 "e317ac75225844d280677a0aeb010be2")
   (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
    "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/foundation/crc32c.fasl"
    :FASL-MD5 "de072692f255a143bad57edaf9a27846")
   (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
    "942b596396c19815290a57830af2121b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/foundation/conditions.fasl"
    :FASL-MD5 "bdf8a9c57b20fa9981c8bccf6b1d0496")
   (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
    "a06115175f450776762761dce25acdb8" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/foundation/binary.fasl"
    :FASL-MD5 "7df70f1d74c5166e681a44a774509a88")
   (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
    "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/foundation/batch.fasl"
    :FASL-MD5 "5121031b29a8d45c341be4015251810f")
   (:FILE "src/execution/writer.lisp" :SOURCE-MD5
    "73019644090e2971f2b54dc36e4491f5" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/execution/writer.fasl"
    :FASL-MD5 "130e8a7c15ac7408d380b85958236c12")
   (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
    "0679ee07c46f69db330706303c70d8d2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/execution/worker-types.fasl"
    :FASL-MD5 "3fba2ff429c3cc962913867384890a2e")
   (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
    "aa34ca6bc07535e35fea723878d99f66" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/execution/worker-run.fasl"
    :FASL-MD5 "33acb31cd8d1330f02ff6cc107162153")
   (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
    "babd0a78b4185af24ae1fef870c0fabb" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/execution/worker-claim.fasl"
    :FASL-MD5 "99fe17bda0f4fb2c6fd4a01892ffed72")
   (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
    "c24065d6c8d80d1be53994a0041743df" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/execution/worker-boundary.fasl"
    :FASL-MD5 "43815339a75757346a796d60d387ac44")
   (:FILE "src/execution/ready.lisp" :SOURCE-MD5
    "2c1892002f0599bb8273093031017520" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/execution/ready.fasl"
    :FASL-MD5 "83aa7e46f4b65987ca8f3c60316e2ae8")
   (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
    "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/execution/ready-types.fasl"
    :FASL-MD5 "5ed14249e25cf83e3e43c7f7314d2906")
   (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
    "38d26f8c749dd946dfc4b9c57103a892" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/execution/ready-recycle.fasl"
    :FASL-MD5 "ee9d5d60ac272346c7d18868079af11a")
   (:FILE "src/execution/queue.lisp" :SOURCE-MD5
    "8202843bddb817da4279ac959ae3f3c4" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/execution/queue.fasl"
    :FASL-MD5 "e2be7d37e24eaf7f7d590d2592bb576e")
   (:FILE "src/execution/package.lisp" :SOURCE-MD5
    "cb5710d6c111cadb7121a50998a747fa" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/execution/package.fasl"
    :FASL-MD5 "6afa20c6cf0974f78a53939702d3b04d")
   (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
    "6b85eebe69366e78ed5fc5cc20735f00" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/execution/handoff.fasl"
    :FASL-MD5 "b7f08331439087f4897d48cfa80e992b")
   (:FILE "src/epochs/types.lisp" :SOURCE-MD5
    "82253491f995f5bc153fb5ebf30d564c" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/epochs/types.fasl"
    :FASL-MD5 "2c7ba4015e89ae2e3b46166fbdcb3b26")
   (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
    "653b974f310c09f6e2224a84acc43bbf" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/epochs/retire.fasl"
    :FASL-MD5 "8c3c0cfdfaf0e8b618340ca006cd1913")
   (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
    "036dd02adf87d33c3ae2f40735c733fa" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/epochs/reclaim.fasl"
    :FASL-MD5 "8905eebd3192da31087ea4f801532080")
   (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/epochs/read.fasl"
    :FASL-MD5 "5e1364b5ab1f9aa67b6af17331d07f35")
   (:FILE "src/epochs/package.lisp" :SOURCE-MD5
    "875201dfab0a84efd40fe9828cc293c8" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/epochs/package.fasl"
    :FASL-MD5 "01ee8cdfc7e7d4ef7f997a5f83926308")
   (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/epochs/core.fasl"
    :FASL-MD5 "7a7f86a2a26d3c908e0b8d52c388a136")
   (:FILE "src/csn/registry.lisp" :SOURCE-MD5
    "a1cdb5661fc54beba5bf00e4765f3235" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/csn/registry.fasl"
    :FASL-MD5 "8f6e97b78a017446145697375f1b98a4")
   (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/csn/package.fasl"
    :FASL-MD5 "57e7597c0d295005942db07b3b222d8c")
   (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/utf8.fasl"
    :FASL-MD5 "5734122a1376def9a99c09e0e7eac120")
   (:FILE "src/codec/package.lisp" :SOURCE-MD5
    "d885bd2a9860eb60aec1a775e5031d5e" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/package.fasl"
    :FASL-MD5 "33c42689cb012d885925353018abe569")
   (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
    "69e77bcd15b5413a815a65c5081229db" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/cbor-write.fasl"
    :FASL-MD5 "6912c7d5cc6d5fc406053810eb943e21")
   (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
    "b13e92b5f24a42fe283c17b649722b6a" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/cbor-string-write.fasl"
    :FASL-MD5 "c2fe4a4f8f2f6aab5cd748fddfe7d1af")
   (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
    "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/cbor-space.fasl"
    :FASL-MD5 "ea9229e13d0bda3593a429926088f50a")
   (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
    "200373402e6e082dd8c7afde305302bb" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/cbor-simple-write.fasl"
    :FASL-MD5 "f295e1deed46c042c3113951868dcbde")
   (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
    "0c33aedcdb352e78a3c694cf796e6692" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan.fasl"
    :FASL-MD5 "37811197f351c4886a35be5c51952305")
   (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
    "cf1999ddb10f879aeefbeea853742d57" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-stack.fasl"
    :FASL-MD5 "a6c406b4e6c9bc3944b03538f448c7ae")
   (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
    "987e8ed576a21eb644ac1ef2e06edbda" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-minimal.fasl"
    :FASL-MD5 "72e1f7a451253a559e35b2fc04d6f227")
   (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
    "706c0baa4158bf272c4b0df17c1439d2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-items.fasl"
    :FASL-MD5 "90ea48591cbc17cbb892573539f7b6db")
   (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
    "f6488e987889432b375254021825dbe5" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/cbor-scan-input.fasl"
    :FASL-MD5 "b3751d748771c1bdf2f0f57b9080884b")
   (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
    "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/cbor-package.fasl"
    :FASL-MD5 "04d2efaeedf25b254808d5465af973e6")
   (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
    "ecd8fe950344059c629927b38fb6e4aa" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/cbor-minimal.fasl"
    :FASL-MD5 "f7f5df2b83178d7012700c3799711488")
   (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
    "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/cbor-header.fasl"
    :FASL-MD5 "bb0f5c2a9168406ed0793e4d815e91eb")
   (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
    "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/codec/cbor-float-minimal.fasl"
    :FASL-MD5 "c9d6b84b96d02516be40a9305efa88e8")
   (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/cache/write.fasl"
    :FASL-MD5 "8d89b2b619dac91280f6ed24a98526ef")
   (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/cache/types.fasl"
    :FASL-MD5 "46af370e84940766d761ec0aeedd73fa")
   (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/cache/read.fasl"
    :FASL-MD5 "96527144810f7ea3d60601b11c3ca898")
   (:FILE "src/cache/package.lisp" :SOURCE-MD5
    "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/cache/package.fasl"
    :FASL-MD5 "b8f6ba45c38c962ad46c501dfafb7d51")
   (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/cache/core.fasl"
    :FASL-MD5 "c01af56cbd58d85d9246e57f3a32b6c5")
   (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/cache/clock.fasl"
    :FASL-MD5 "b6121b07d2dd96c6fc3d0ca327ae7341")
   (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
    :FASL
    "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/fasl/src/cache/build.fasl"
    :FASL-MD5 "1e0517bb49e55cc41f5f2c086e18142c"))
  :EXPECTED-TESTS
  ("TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP"
   "TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2"
   "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED"
   "TEST-REQ-CCH-002-SERIES-GET-FIVE-OUTCOMES-COLD-AND-HOT"
   "TEST-REQ-CCH-004-SERIES-GET-CACHE-CORRUPTION-NATIVE-FALLBACK"
   "TEST-REQ-CMP-007-SERIES-GET-WRONG-OWNER-CLEANUP"
   "TEST-REQ-AFF-004-SERIES-GET-NIL-AND-CORRUPT-ROOT-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-CORRUPT-ACTIVE-CONTENT-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-SOURCE-CONTROLLER-MISMATCH-TYPED-FAULTED"
   "TEST-REQ-IDX-001-SERIES-GET-MISSING-CLOSED-ID-FAULTED"
   "TEST-REQ-CON-004-SERIES-GET-WRONG-STATE-NO-PIN-STEAL"
   "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION"
   "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
   "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-EXCLUDES-LATER-PUBLICATION"
   "TEST-REQ-WAL-005-SERIES-GET-WRITER-FOREIGN-OWNER-BEFORE-ADOPTION"
   "TEST-REQ-WAL-005-SERIES-GET-WRITER-DUPLICATE-ACTIVE-BEFORE-ADOPTION"
   "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-ACTIVE-OWNER-AND-ID-GUARDS"
   "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-EMPTY-AND-ID-EXTREMES"
   "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-65536-GEOMETRY-SEARCH17"
   "TEST-REQ-CON-004-SERIES-GET-BUFFER-REQUIRED-FIVE-OUTCOMES-AND-RESTART"
   "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-READER-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-WRITER-ARCHIVE-FAULTED"
   "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-ADAPTERS-NATIVE"
   "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-INVALID-ROOT-FAULTED"
   "TEST-REQ-CMP-007-SERIES-GET-ACTIVE-OWNER-BEFORE-FAULTED-CONTROLLER"
   "TEST-REQ-WAL-006-SERIES-GET-ACTIVE-UNEXPECTED-PROOF-FAULTED")
  :PASSED-TESTS
  ("TEST-REQ-IDX-001-SERIES-GET-CONTENT-ROUNDTRIP"
   "TEST-REQ-IDX-001-SERIES-GET-CLOSED-CONTROLLER-NATIVE-V1-V2"
   "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED"
   "TEST-REQ-CCH-002-SERIES-GET-FIVE-OUTCOMES-COLD-AND-HOT"
   "TEST-REQ-CCH-004-SERIES-GET-CACHE-CORRUPTION-NATIVE-FALLBACK"
   "TEST-REQ-CMP-007-SERIES-GET-WRONG-OWNER-CLEANUP"
   "TEST-REQ-AFF-004-SERIES-GET-NIL-AND-CORRUPT-ROOT-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-CORRUPT-ACTIVE-CONTENT-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-SOURCE-CONTROLLER-MISMATCH-TYPED-FAULTED"
   "TEST-REQ-IDX-001-SERIES-GET-MISSING-CLOSED-ID-FAULTED"
   "TEST-REQ-CON-004-SERIES-GET-WRONG-STATE-NO-PIN-STEAL"
   "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION"
   "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-PRESERVES-CAPTURED-PAGE"
   "TEST-REQ-WAL-006-SERIES-GET-EXPLICIT-ROOT-EXCLUDES-LATER-PUBLICATION"
   "TEST-REQ-WAL-005-SERIES-GET-WRITER-FOREIGN-OWNER-BEFORE-ADOPTION"
   "TEST-REQ-WAL-005-SERIES-GET-WRITER-DUPLICATE-ACTIVE-BEFORE-ADOPTION"
   "TEST-REQ-AFF-004-SERIES-GET-PUBLISHED-ACTIVE-DUPLICATE-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-ACTIVE-OWNER-AND-ID-GUARDS"
   "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-EMPTY-AND-ID-EXTREMES"
   "TEST-REQ-IDX-001-SERIES-GET-CONTAINS-65536-GEOMETRY-SEARCH17"
   "TEST-REQ-CON-004-SERIES-GET-BUFFER-REQUIRED-FIVE-OUTCOMES-AND-RESTART"
   "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-READER-FAULTED"
   "TEST-REQ-AFF-004-SERIES-GET-DIRECTORY-GEOMETRY-WRITER-ARCHIVE-FAULTED"
   "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-ADAPTERS-NATIVE"
   "TEST-REQ-WAL-006-SERIES-GET-LEGACY-ACTIVE-INVALID-ROOT-FAULTED"
   "TEST-REQ-CMP-007-SERIES-GET-ACTIVE-OWNER-BEFORE-FAULTED-CONTROLLER"
   "TEST-REQ-WAL-006-SERIES-GET-ACTIVE-UNEXPECTED-PROOF-FAULTED")
  :FAILED-TEST NIL :FAILURE-KIND NIL :SOURCE-MANIFEST
  ((:FILE "arcdocdb.asd" :MD5 "1c847de175f4954cec5ef2186308f1a7")
   (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
   (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
   (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
   (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
   (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
   (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
   (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
   (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
    "bc7a7b176e8cdd361b7c4306a1a4de4b")
   (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
   (:FILE "src/codec/cbor-minimal.lisp" :MD5
    "ecd8fe950344059c629927b38fb6e4aa")
   (:FILE "src/codec/cbor-package.lisp" :MD5
    "c3f19ffb4aacfdfe502c5e8b12a234f2")
   (:FILE "src/codec/cbor-scan-input.lisp" :MD5
    "f6488e987889432b375254021825dbe5")
   (:FILE "src/codec/cbor-scan-items.lisp" :MD5
    "706c0baa4158bf272c4b0df17c1439d2")
   (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
    "987e8ed576a21eb644ac1ef2e06edbda")
   (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
    "cf1999ddb10f879aeefbeea853742d57")
   (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
   (:FILE "src/codec/cbor-simple-write.lisp" :MD5
    "200373402e6e082dd8c7afde305302bb")
   (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
   (:FILE "src/codec/cbor-string-write.lisp" :MD5
    "b13e92b5f24a42fe283c17b649722b6a")
   (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
   (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
   (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
   (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
   (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
   (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
   (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
   (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
   (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
   (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
   (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
   (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
   (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
   (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
   (:FILE "src/execution/ready-recycle.lisp" :MD5
    "38d26f8c749dd946dfc4b9c57103a892")
   (:FILE "src/execution/ready-types.lisp" :MD5
    "a64d98c9ff429d6103d6e10ee1fd7980")
   (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
   (:FILE "src/execution/worker-boundary.lisp" :MD5
    "c24065d6c8d80d1be53994a0041743df")
   (:FILE "src/execution/worker-claim.lisp" :MD5
    "babd0a78b4185af24ae1fef870c0fabb")
   (:FILE "src/execution/worker-run.lisp" :MD5
    "aa34ca6bc07535e35fea723878d99f66")
   (:FILE "src/execution/worker-types.lisp" :MD5
    "0679ee07c46f69db330706303c70d8d2")
   (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
   (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
   (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
   (:FILE "src/foundation/conditions.lisp" :MD5
    "942b596396c19815290a57830af2121b")
   (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
   (:FILE "src/foundation/package.lisp" :MD5
    "5ee593a112958d94163dab17c5aa4ba2")
   (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
   (:FILE "src/get-directory/build.lisp" :MD5
    "cde24b2bf5c5637d5501b95bed47df31")
   (:FILE "src/get-directory/package.lisp" :MD5
    "894f6e238fe4047f2bf607fceae86846")
   (:FILE "src/get-directory/read.lisp" :MD5
    "74a694385f1aaf03ec87721545494119")
   (:FILE "src/get-directory/sources-read.lisp" :MD5
    "2b8193aab6801de19e26fa55e7c53f87")
   (:FILE "src/get-directory/sources-types.lisp" :MD5
    "b846a6348ff7d4b5f7b380b5b3ff8c17")
   (:FILE "src/get-directory/types.lisp" :MD5
    "17c957d6934a31f4ed64313e756de2d2")
   (:FILE "src/get-resolver/active-build.lisp" :MD5
    "c65593cf172f53a8e90a853bbe9504c2")
   (:FILE "src/get-resolver/active-directory.lisp" :MD5
    "6d95f29b331d335175843f47ae44a6ea")
   (:FILE "src/get-resolver/active-preflight.lisp" :MD5
    "f13d422adb6aa9e8489352884137f25a")
   (:FILE "src/get-resolver/active-read.lisp" :MD5
    "521737861e057d663964b0c030552587")
   (:FILE "src/get-resolver/active-scan.lisp" :MD5
    "d6aaec49504a96f37c8ff1bc182c977b")
   (:FILE "src/get-resolver/active-types.lisp" :MD5
    "bd7182e9871fe82530d0c828e473ccde")
   (:FILE "src/get-resolver/build.lisp" :MD5
    "bbfb2082103e6712419e180ab972245c")
   (:FILE "src/get-resolver/package.lisp" :MD5
    "6226d131f5562a475048b6444049c4ca")
   (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
   (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
   (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
   (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
   (:FILE "src/get-resolver/types.lisp" :MD5
    "9df13bcc6908e9fa601d173a671e1ccf")
   (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
   (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
   (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
   (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
   (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
   (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
   (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
   (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
   (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
   (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
   (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
   (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
   (:FILE "src/index/hash-digests.lisp" :MD5
    "43d2209225707352daec6186ef95a805")
   (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
   (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
   (:FILE "src/index/primary-arena.lisp" :MD5
    "a319691e3e28b7ea7b927de490cf69ba")
   (:FILE "src/index/primary-build.lisp" :MD5
    "ff2cfbb865290d7a1510fdf6877c7229")
   (:FILE "src/index/primary-core.lisp" :MD5
    "fa52433eae199ceeb874bf2bc47afca7")
   (:FILE "src/index/primary-directory.lisp" :MD5
    "1dd67c527257e43f17e006644ecdbd00")
   (:FILE "src/index/primary-package.lisp" :MD5
    "d65cfce399b04f905bf969929962e59a")
   (:FILE "src/index/primary-probe.lisp" :MD5
    "699ce3f1615296fc27fcde3e0d63a4bc")
   (:FILE "src/index/primary-read.lisp" :MD5
    "3f317a0d3c5ee86a73651aad36135cc3")
   (:FILE "src/index/primary-relocate.lisp" :MD5
    "5155959766645d3172ae5e73c58cc071")
   (:FILE "src/index/primary-types.lisp" :MD5
    "a59eab6425a60fa2656f86bf87d5c9ac")
   (:FILE "src/index/primary-write.lisp" :MD5
    "e8e31e599356e592af29c0cc4604872b")
   (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
   (:FILE "src/index/rebuild-budget.lisp" :MD5
    "0417dd41cb3ec1d62dfd913c19f810ad")
   (:FILE "src/index/rebuild-copy.lisp" :MD5
    "8befbbd00ed5c31c1487a11887eba495")
   (:FILE "src/index/rebuild-scan.lisp" :MD5
    "1188e7a64a7a5d9482c1233cb9acb452")
   (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
   (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
   (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
   (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
   (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
   (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
   (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
   (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
   (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
   (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
   (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
   (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
   (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
   (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
   (:FILE "src/mvcc/snapshots-core.lisp" :MD5
    "8bb066aab61a18eff175b9edb11e42a2")
   (:FILE "src/mvcc/snapshots-csn.lisp" :MD5
    "0e9365e674d1584b111f915ce1f58634")
   (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
    "ff98aea5cb9a7ae2671f6a887a003725")
   (:FILE "src/mvcc/snapshots-read.lisp" :MD5
    "ae3ad96269b5e711a9dbb455f3c0ce48")
   (:FILE "src/mvcc/snapshots-register.lisp" :MD5
    "2d5a795bcefd605c75da91c725ae83a2")
   (:FILE "src/mvcc/snapshots-types.lisp" :MD5
    "475517bd7ba04a1c37a82efeb8ff73d9")
   (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
   (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
   (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
   (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
   (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
   (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
   (:FILE "src/recovery/decisions-build.lisp" :MD5
    "1a51ef4a488bb9fde2ff7d47bae01379")
   (:FILE "src/recovery/decisions-package.lisp" :MD5
    "cbdc30f93109c474e1fc25066c9b9b13")
   (:FILE "src/recovery/decisions-query.lisp" :MD5
    "f782d1137b8ce342b91c9999cfb7accc")
   (:FILE "src/recovery/decisions-radix.lisp" :MD5
    "852149de4c289b8e067602780378d87a")
   (:FILE "src/recovery/decisions-sort.lisp" :MD5
    "b33e57a643f2fca810846f6226366253")
   (:FILE "src/recovery/decisions-types.lisp" :MD5
    "f4433fd19ebc7239dbc2628c39f3ecdb")
   (:FILE "src/recovery/inventory-build.lisp" :MD5
    "9bd6820c4feba3e552aab1a4edd87861")
   (:FILE "src/recovery/inventory-query.lisp" :MD5
    "fcea263de1938767772e5b11411ecd5e")
   (:FILE "src/recovery/inventory-types.lisp" :MD5
    "78c136d5838dcfe3019d9069643a8d8f")
   (:FILE "src/recovery/manifest-build.lisp" :MD5
    "bf65b1731eab6e0572461ef5cc60fc40")
   (:FILE "src/recovery/manifest-decode.lisp" :MD5
    "67975249aaabd751757cdfb9222cc3c4")
   (:FILE "src/recovery/manifest-fold.lisp" :MD5
    "e0d2498db1011e857b7b0daa1934f187")
   (:FILE "src/recovery/manifest-package.lisp" :MD5
    "37ace42844c11b52446ee1fc500b8e0b")
   (:FILE "src/recovery/manifest-query.lisp" :MD5
    "ebd7a54adea2213294a887e6d4db0927")
   (:FILE "src/recovery/manifest-types.lisp" :MD5
    "7b1d4054415faca7e5fca59ad83b4d4a")
   (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
   (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
   (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
   (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
   (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
   (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
   (:FILE "src/series/publication.lisp" :MD5
    "056d2c6a67c9d9f2bf9fe2d2c348d53c")
   (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
   (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
   (:FILE "src/series/routing-build.lisp" :MD5
    "d6924deff152b941bd49f0bb200b4197")
   (:FILE "src/series/routing-select.lisp" :MD5
    "e0f987d8767744050ec4d1b3ecb699ed")
   (:FILE "src/series/routing-types.lisp" :MD5
    "ce649df47dd38888d5103c98345f7e41")
   (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
   (:FILE "src/series/worker-boundary.lisp" :MD5
    "2340e0c9074f7b1bf80c74f774986bc5")
   (:FILE "src/series/worker-package.lisp" :MD5
    "a93ce2e84e8aee647b5083ad1d2b899b")
   (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
   (:FILE "src/series/worker-types.lisp" :MD5
    "2b23d468be0165fa009c5ebd5d1bbe23")
   (:FILE "src/storage/compaction-scan.lisp" :MD5
    "1cda77a357ab2147035993b72d135a37")
   (:FILE "src/storage/control-payload.lisp" :MD5
    "cb64f806b8d69eb42d865b4abfff0b27")
   (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
   (:FILE "src/storage/log-header.lisp" :MD5
    "b53d27dcc9f4badf18b50519c50bc614")
   (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
   (:FILE "src/storage/payload-record.lisp" :MD5
    "8c03f9c01dcb30f2d3970a5694968ecf")
   (:FILE "src/storage/payload-write.lisp" :MD5
    "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
   (:FILE "src/storage/segment-header.lisp" :MD5
    "d6812fa59bf8fd1252fbf85a9bfa3896")
   (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
   (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
   (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
   (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
   (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
   (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
   (:FILE "tests/foundation/support.lisp" :MD5
    "758adad069aec2f9dbe0635797314ff6")
   (:FILE "tests/get-directory/support.lisp" :MD5
    "3f868ebe4307ad4238b314c37eceed9a")
   (:FILE "tests/get-directory/construction.lisp" :MD5
    "1137938073e71d6d8d62c751fbad05d5")
   (:FILE "tests/get-directory/read.lisp" :MD5
    "d1ab36d05cc1266e4533d27c693f12f4")
   (:FILE "tests/get-directory/threads.lisp" :MD5
    "63dd01c852de1399c2c82274d481d257")
   (:FILE "tests/get-directory/series-support.lisp" :MD5
    "8d7ed4f8d3f9e8394b15c648a3a4507b")
   (:FILE "tests/get-directory/series-read.lisp" :MD5
    "3e565b431b88fb5211023601b5e3ce3b")
   (:FILE "tools/get-series-mutation.lisp" :MD5
    "2068edb227d28b9e53c4eecc125fca54")))
 :ARTIFACTS-VERIFIED T :SIGNAL NIL :EXIT-CODE 0 :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "1c847de175f4954cec5ef2186308f1a7")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "2b8193aab6801de19e26fa55e7c53f87")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54"))
 :DEADLINE-SECONDS 120 :ARGV
 ("sbcl" "--noinform" "--no-userinit" "--no-sysinit" "--disable-debugger"
  "--script"
  "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/evidence/baseline/driver.lisp"
  "--child"
  "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/evidence/baseline/config.lisp")
 :NAME "baseline" :FILE NIL :RESULT :BASELINE-PASSED :STATUS :OK
 :COPY-DIRECTORY
 "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/baseline/"
 :EVIDENCE-DIRECTORY
 "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/evidence/baseline/"
 :EXPECTED-FAILURE NIL :PRODUCER-RECORD
 "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/report.lisp"
 :PRODUCER-CLOSED T :CHILD-LAUNCHED T :CHILD-REAPED T :TIMED-OUT NIL :CLEANUP
 :REAPED)
