(:FINISHED-AT-UNIVERSAL-TIME 4000908520 :CONDITION-TYPE "INVARIANT-VIOLATION"
 :DIAGNOSTIC "ArcDocDB: DIRECTORY-LOCATION-ABSENT" :SCHEMA-VERSION 1 :KIND
 :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE :TESTS :COMPILED T
 :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "3e565b431b88fb5211023601b5e3ce3b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "a368756ec3fabb272e7ae1ead644e532")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "26cbd5f4d9b0252db5b8f3f5e6508060")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "58684a1baa0d4e71f58fa45e03ab3f74")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "bb187d30689c57841cb19fe4d7c0a94d")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "04087b419999098fb35b5179ce027086")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "1402dc318b75f367b0a34578b7774c9a")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "294d7efc3803b75146e84ae0b9b7fa7f")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/types.fasl"
   :FASL-MD5 "65ac62683703b1739c334491531b6ade")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/package.fasl"
   :FASL-MD5 "f56580024fdedfca9f10883fc0408c0a")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/group.fasl"
   :FASL-MD5 "561641fe76ea25d1dd1cc85ea5be0abf")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/executor.fasl"
   :FASL-MD5 "da20267c3a84f5a3b1d9c013c8b97c17")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/csn.fasl"
   :FASL-MD5 "044cb14c295c5712a7d49ce91741fa95")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/wal/builder.fasl"
   :FASL-MD5 "7fe864f70d2243b048a859891bd8c883")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "a6f8e53069d0e15e83925408bd139dc6")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "2cb11733f190479e602a49b457496ed9")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "30dd0bf4d4a9d47db227ae2c2f0c951d")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/package.fasl"
   :FASL-MD5 "3c4544b7386e2fb49c05ba35f57f6aa1")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "8d94830e800f40966ddb1a60650e5016")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/formats.fasl"
   :FASL-MD5 "e7da5d659eea3e59521fe48e38032cd2")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "a460433ac1df5d1fff94cc525c4fa59e")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "3a272ca73d5a6bc8a0e8446d6178bb52")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "d065293d5de94741a22402af05d2d591")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "1dd3b137cd20989cfa8174a82e81f53d")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "d98cb66caabea64c086390f964ea3edd")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "90481360f713859c2741de63e4a87ff4")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/types.fasl"
   :FASL-MD5 "6eaf0bc27f3086aa24f5f0f7da592ab0")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "6ca469d13ed0236a3de6262ded2cc3d3")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "268361ca8bc7e532450738a04f09f677")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "aaab63ab4e9c3e1260ae034a31346955")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/retirement.fasl"
   :FASL-MD5 "6057845205a95eabdeedf7b1252217ef")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/query.fasl"
   :FASL-MD5 "e28fb6cff7170d7ee7755943d7eaccaa")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/publication.fasl"
   :FASL-MD5 "64d42456b2ced87fa3a1fefe5a2fc400")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/package.fasl"
   :FASL-MD5 "2e421caa60aa406d1beb947cd0101d3b")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/ownership.fasl"
   :FASL-MD5 "fe00b41f326e1b3b16d5627fc7c6597c")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/io-events.fasl"
   :FASL-MD5 "c746227df154e719dbcd50aabf279260")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/series/events.fasl"
   :FASL-MD5 "d14e50f9922ce1fcbb3bb9a91b53a50f")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "2a7b06624c60a4976ad28a92d6a84433")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/package.fasl"
   :FASL-MD5 "65901c43292e76ccdcd3caf953aa8678")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "50aa0292673f6644e8642efa468ed19d")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "3e5e0828b79b1a039ba123685bbd0f51")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "55170eac8c0da932742d4fbd0096f6a9")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "855d9a53d06373814b53b482b30d88b4")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "e32c9f584b9b133b65bd0d435b728127")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "cef484fd5ba0ec9aa32f6f7ba5d61504")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "78464c06f3e84fcb189a8bdcc35a9157")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "d8cc49f0c57612d70836f0dab39075ff")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "ddd2744d9cc684feb5003ad2865bb95d")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "11b7168b49160f3d078ba961e457a58a")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "87f300b0c88b5d31cc36e9993f9d2b92")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "4a0fc21825b372180ce1bb6acd7f8573")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "714ba2820cc97aa16b9c7361e1016b78")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "1239f6f9ad4f8030399cecbe5d66fff2")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "98155d13148aa605626fa7457ff3aa1a")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/types.fasl"
   :FASL-MD5 "e3425b78aa2979128f2a37f11f7a14ab")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/task.fasl"
   :FASL-MD5 "756ce36244a61af03af6019b19c97296")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/package.fasl"
   :FASL-MD5 "14fd72acba72478739a16afc90814fb7")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/read/core.fasl"
   :FASL-MD5 "89ee73686f80c4db2c04764e3232d441")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/package.fasl"
   :FASL-MD5 "63be102cfd0f24bc8af266bfa82a7a41")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "046dae4695fd0561234f1b62f46858e6")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "1791bacd871c581e7dc88afdd0d70825")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "e209b735f38d2b6fcc8f7bc846148fd9")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "c8b012cd8ee9460f831bf99f0b9da6de")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "64253794aec305ba5e7f82dea001d057")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "65c8d726068c337719aa3bb51578e88c")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "21f48aa6fc7a80f296539e85584f46d9")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "a945bb41104b17bee44167492823eeb0")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/types.fasl"
   :FASL-MD5 "afc9c1509dc8ce746d045cbca5a8368c")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/transfer.fasl"
   :FASL-MD5 "9f1ffbaf142eaf49959729bfa4469618")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/package.fasl"
   :FASL-MD5 "e67cd72852f30144edfef81f5dac9d74")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/native.fasl"
   :FASL-MD5 "4bf287d5b0ff24548dab572fe57b1ed9")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "c0cc6a2ebfad84097f185debc037608f")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/identity.fasl"
   :FASL-MD5 "b4034d2f911f08e354661e49b49fa9d7")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "3a5e50e35b09abfd31889e09a1f4b5df")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/io/flush.fasl"
   :FASL-MD5 "087d09034d3968d8172898688cae669b")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/write.fasl"
   :FASL-MD5 "2c64c71ad84f529a37df5e225f896020")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/validation.fasl"
   :FASL-MD5 "30371af933cf09fc0750144f9639c3c6")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/types.fasl"
   :FASL-MD5 "f7c1defe0594ed30bf6a3b83ac9ea965")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/relocate.fasl"
   :FASL-MD5 "3ab04b7982aaa6a0add90f0b7030fe38")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "1a40f1ca947731c5dae3e2b6f0af22b5")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "9850f0fc21609ee581c25e1203dd9b5f")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "760921cb7fea45bc7460175fb7276c31")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "55b50cb2b44124340d78e5a6b061e494")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/read.fasl"
   :FASL-MD5 "599079e7ea35d5321a15c8319c47a80c")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "2ab8df8cc9e05ac3630ebb8830d046ff")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "dd1b3e2c5d1afcf641874d5b406d0812")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "a15a8aeaaede35f43cc1a7300ab754c2")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "c79169c60513873226f23b881ace101f")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "867a26685ef367873fa0f2ccef6ac667")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "a99170422a591428249ab977367390ed")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "6f6037bb59c607433a3cac26228f5571")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "7312afe1b0343ee75e41673b3d44894a")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "8a1e8d61e2ca63bd8b0c58a8b9b2f10c")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "2142e006b18711778f7e48e981422dd9")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/package.fasl"
   :FASL-MD5 "27e1a865dcb1d710b1168e386e3dcfdc")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "c0a0d2ef3f4bd8f6ebe73a66b221d6b2")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "8c7b7bea02a15c4b1ebc9f011ec57d43")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/index/core.fasl"
   :FASL-MD5 "92386917d3e7518d63c5a73373b48684")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/package.fasl"
   :FASL-MD5 "610e048b99c6bc9cf887d83593015b55")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "0b53570ac764d5a45a36a0945a6dd234")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "014c3ffa0fa14a71d388f8cb724640d4")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "f38f913972eea37ef48d002a621e75cb")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/types.fasl"
   :FASL-MD5 "0196dabb92531b93f70681b7df64ffd6")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/target.fasl"
   :FASL-MD5 "0f32def6ee4eb1fbe640874334f58ff1")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/segment.fasl"
   :FASL-MD5 "46ababd6c02055daa2821208b7734ed3")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/package.fasl"
   :FASL-MD5 "da1e35784cdeadd810df44586e8db6fb")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/lookup.fasl"
   :FASL-MD5 "1952eb7245835cc6fb9745bd1472d1dd")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "c893d7123128fe8883909c7b7ab72117")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get/build.fasl"
   :FASL-MD5 "d6a25a0cbdf1289f076803017136d6f4")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "dca3f0dfdf5b07652028670dad9794df")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "7fca5b3ab7cd0707d6ba034d502fce3a")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "6b2ec90c50e010994d66611f36281867")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "366988911f6a5acb37bbbf0f22504760")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "ae5229cb54c9f09a513e80ed36d45f38")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "d772ec8188a17340c7b5561f7abb7026")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "c4ac48e3f7596efb75078d235bbed1fb")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "6c12c2b99cc631fe7ff9e41ef496fd4e")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "d693be5255c2b5d9ecabe7e0f9b53618")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "521737861e057d663964b0c030552587" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "c97d858158a878c3614dac74dddeb453")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "28151bbf3cb6e5c8ca4e2b6bc885db7a")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "4b390581c382ec2e05a31e51699c580e")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "b228d9c5d4cf3f4c1f380322ea0ac580")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "2e1ee9b6257d5e3835ad389597f0f584")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "112bf6284d3f4ffd49b63a35b20954e4")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "db44405bae8b58b9bb6519429dc016a8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "6cedc8a7b78f1622b8ac672f45d553b2")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "84f76379fd87a349578a81c1e2684e27")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "143010ed884ff6dc638e465ae1378cf5")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "c941d7a5ea7cfe11ef92a34718848b4e")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/record.fasl"
   :FASL-MD5 "8bb886d45c03b3d575d27827a335b990")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/package.fasl"
   :FASL-MD5 "d2bf0dd36de809c2bcf81d7fc2dba943")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "3b0888394b107adf7dba850fd49d9d5e")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "d20eb842ef30e72efe55735d73fcf9bf")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "dd152091cbf825cbac96ba16ee810a03")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "f6e5657126e9adafaf407783379ac747")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/writer.fasl"
   :FASL-MD5 "d8704e8343341a8985f81423adf61288")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "774857cdbdfb104e90db008b8aa0417d")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "88f933df670757bc0167c83b49e20871")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "52d1b2d5879e821e713c913e15c09556")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "360d94728c5c4280959c7f0cfd9b592b")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/ready.fasl"
   :FASL-MD5 "7d315b5a7b7c15c9812baf0a943e9d51")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "bb7623229fc26d97d16009e9ae6c4741")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "212713f7c5fbe0342045451cf4217c3b")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/queue.fasl"
   :FASL-MD5 "add251f0704a94346cf83249eaa9f29f")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/package.fasl"
   :FASL-MD5 "ee7ec97d794e0a17d7bdc01f241f1c63")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "a3eb4a2a851b41e95146f49e877adab5")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/types.fasl"
   :FASL-MD5 "6b0f7acf2c84481e6c3c2f7877233a7f")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "a47dfc36d3da6a8e43c34e479d9dd3ef")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "2ea469be530b1daff926ae59ec6b8583")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/read.fasl"
   :FASL-MD5 "dd8f737037fbe979e22e583c3960ef7a")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/package.fasl"
   :FASL-MD5 "231907929860f56d378468e07c095cb8")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/epochs/core.fasl"
   :FASL-MD5 "ff527bdb7e44577c1714ab692ae6312e")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/csn/registry.fasl"
   :FASL-MD5 "42487f80984e342fc2a47048cf832056")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/csn/package.fasl"
   :FASL-MD5 "355d3680a664b15c9155d5e853115678")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "60b6a1f8d965ac4a1559d95a1837abaf")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/package.fasl"
   :FASL-MD5 "6c22aaf0cef8eaabe7fe100ec23dec83")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "53e7cd3ab96eade57ac83c9cc229bc92")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "d880980bd4b7b96c87f47b1b98bf11d5")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "07535b4096f24f52e6a271e03f33641b")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "6fbccd16eb73bf1e15f62aedf2f6c9a1")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "df5f347944649116b6f17383f4ec1418")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "e1019e00c9f7903746fe05557f73dd31")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "1df1e7cd32b5929580287bf518141928")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "d603cdc208b40b8611b68e3af7cf215b")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "58cb72491e4a239418d982444fddd10c")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "57d760bea408ad72140d26ffa32ea3d5")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "72d5df0deefe9e0687b15a95b97c920a")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "80da7059719fe3d6ce6845be0cdfc869")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "ba84aeeacbc7d1a0dcc9f3b43b5d0666")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/write.fasl"
   :FASL-MD5 "f58a09ba23e1a9e723ab6fa750dc775d")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/types.fasl"
   :FASL-MD5 "8c57cda9cd077125f89929a401db4823")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/read.fasl"
   :FASL-MD5 "672388fb50d3cbd5658d340d20a0a09b")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/package.fasl"
   :FASL-MD5 "d56cfeb6c0b0abaad4a53e59da28934a")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/core.fasl"
   :FASL-MD5 "f70118c1e8d8f6e88e69e44b5490ad60")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/clock.fasl"
   :FASL-MD5 "534da0f7e9c4e4b7aff1c060eb76bd49")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/dispatch-active-to-closed/fasl/src/cache/build.fasl"
   :FASL-MD5 "d4051571902564accf1522857a7411f6"))
 :EXPECTED-TESTS ("TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-IDX-001-SERIES-GET-ACTIVE-AND-CLOSED-MIXED" :FAILURE-KIND
 :PRODUCT-CONDITION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "1c847de175f4954cec5ef2186308f1a7")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "db44405bae8b58b9bb6519429dc016a8")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
