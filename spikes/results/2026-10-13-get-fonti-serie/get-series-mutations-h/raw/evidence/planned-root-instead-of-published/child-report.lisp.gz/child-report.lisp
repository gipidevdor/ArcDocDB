(:FINISHED-AT-UNIVERSAL-TIME 4000908508 :CONDITION-TYPE "INVARIANT-VIOLATION"
 :DIAGNOSTIC "ArcDocDB: DIRECTORY-LOCATION-ABSENT" :SCHEMA-VERSION 1 :KIND
 :GET-SERIES-MUTATION-CHILD :STATUS :FAILED :PHASE :TESTS :COMPILED T
 :SUITE-COMPILED T :COMPILED-FILES
 ((:FILE "tests/get-directory/series-read.lisp" :SOURCE-MD5
   "3e565b431b88fb5211023601b5e3ce3b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/series-read.fasl"
   :FASL-MD5 "29bcdb5958eefe5168d61a67dcc52741")
  (:FILE "tests/get-directory/series-support.lisp" :SOURCE-MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/series-support.fasl"
   :FASL-MD5 "ff5f163a72f860f8d4b554869195823b")
  (:FILE "tests/get-directory/threads.lisp" :SOURCE-MD5
   "63dd01c852de1399c2c82274d481d257" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/threads.fasl"
   :FASL-MD5 "aa3093d5ef0d02c1d5b8e93e134b122b")
  (:FILE "tests/get-directory/read.lisp" :SOURCE-MD5
   "d1ab36d05cc1266e4533d27c693f12f4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/read.fasl"
   :FASL-MD5 "7654d70538c872b12c962c21d3bc5e40")
  (:FILE "tests/get-directory/construction.lisp" :SOURCE-MD5
   "1137938073e71d6d8d62c751fbad05d5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/construction.fasl"
   :FASL-MD5 "2ae9f1a60a14c918fc4df5f586c2e1e3")
  (:FILE "tests/get-directory/support.lisp" :SOURCE-MD5
   "3f868ebe4307ad4238b314c37eceed9a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/get-directory/support.fasl"
   :FASL-MD5 "8c1b1ff3131bfc5e126bdd59a7c4ca27")
  (:FILE "tests/foundation/support.lisp" :SOURCE-MD5
   "758adad069aec2f9dbe0635797314ff6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/tests/foundation/support.fasl"
   :FASL-MD5 "bf39cf944a67423c2bc503b43a02cadb")
  (:FILE "src/wal/types.lisp" :SOURCE-MD5 "f799f27a8ac1a4c736c04796c1e543f9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/types.fasl"
   :FASL-MD5 "df8e529abcf9dd32a4955d0f16ec3452")
  (:FILE "src/wal/package.lisp" :SOURCE-MD5 "96c41b1d417135a24fc65659ea3abe11"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/package.fasl"
   :FASL-MD5 "8ee32302f3248fb2a2fbe95b4bbea2c6")
  (:FILE "src/wal/group.lisp" :SOURCE-MD5 "7a0e7c99ab70b4720cbb091156560f5e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/group.fasl"
   :FASL-MD5 "92b1a9bdf2d803f8ffee5c35660c1eff")
  (:FILE "src/wal/executor.lisp" :SOURCE-MD5 "c0340924c9130e14d0e8efedeec078f1"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/executor.fasl"
   :FASL-MD5 "a7db17f5ef66db3700e58b274a4630c5")
  (:FILE "src/wal/csn.lisp" :SOURCE-MD5 "42b990e3b254e6fb488c0ab91b6a6502"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/csn.fasl"
   :FASL-MD5 "120d28a1253dbd99da6bf60b2af5a7cd")
  (:FILE "src/wal/builder.lisp" :SOURCE-MD5 "a229f76f7036f3573a6e528dcd390a19"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/wal/builder.fasl"
   :FASL-MD5 "d5b9da550062bb06da99b2ea7c2ae447")
  (:FILE "src/storage/segment-header.lisp" :SOURCE-MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/segment-header.fasl"
   :FASL-MD5 "fefed2b9a7e70dd81ce72aea64ad42d6")
  (:FILE "src/storage/payload-write.lisp" :SOURCE-MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/payload-write.fasl"
   :FASL-MD5 "417933b8d85aa2480098958c7f4f01e3")
  (:FILE "src/storage/payload-record.lisp" :SOURCE-MD5
   "8c03f9c01dcb30f2d3970a5694968ecf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/payload-record.fasl"
   :FASL-MD5 "a255644e6027b29a444282c28ca2dbcf")
  (:FILE "src/storage/package.lisp" :SOURCE-MD5
   "f86bd104f20616a76b42c02227f72844" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/package.fasl"
   :FASL-MD5 "672d51211ded75816ba1a879ca930f32")
  (:FILE "src/storage/log-header.lisp" :SOURCE-MD5
   "b53d27dcc9f4badf18b50519c50bc614" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/log-header.fasl"
   :FASL-MD5 "06d6de08d887870b884c23a8f6f08887")
  (:FILE "src/storage/formats.lisp" :SOURCE-MD5
   "061147be459d8d3b08c661bd3f91d152" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/formats.fasl"
   :FASL-MD5 "25b94987aa35f17ffe1e8ccb84593a25")
  (:FILE "src/storage/control-payload.lisp" :SOURCE-MD5
   "cb64f806b8d69eb42d865b4abfff0b27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/control-payload.fasl"
   :FASL-MD5 "07e8b71bd9324ff5d26308597f8ebfe5")
  (:FILE "src/storage/compaction-scan.lisp" :SOURCE-MD5
   "1cda77a357ab2147035993b72d135a37" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/storage/compaction-scan.fasl"
   :FASL-MD5 "155db050d750525ba7e7323c035c16d4")
  (:FILE "src/series/worker-types.lisp" :SOURCE-MD5
   "2b23d468be0165fa009c5ebd5d1bbe23" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/worker-types.fasl"
   :FASL-MD5 "c3511bec4145d6b653ca6e536d699774")
  (:FILE "src/series/worker-run.lisp" :SOURCE-MD5
   "f0fee18adf357bad98e8a3c3e8c70c0c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/worker-run.fasl"
   :FASL-MD5 "c596deaa99ff2b126b083520f60a87c9")
  (:FILE "src/series/worker-package.lisp" :SOURCE-MD5
   "a93ce2e84e8aee647b5083ad1d2b899b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/worker-package.fasl"
   :FASL-MD5 "094a978e4e22c4495bc2915d4e729b29")
  (:FILE "src/series/worker-boundary.lisp" :SOURCE-MD5
   "2340e0c9074f7b1bf80c74f774986bc5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/worker-boundary.fasl"
   :FASL-MD5 "d049fe169f45dc0fe76ee0cbd367aa17")
  (:FILE "src/series/types.lisp" :SOURCE-MD5 "ab19ec8d15af91511e817858c41cebc8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/types.fasl"
   :FASL-MD5 "c98df0cade95773b53ef5d93723aae70")
  (:FILE "src/series/routing-types.lisp" :SOURCE-MD5
   "ce649df47dd38888d5103c98345f7e41" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/routing-types.fasl"
   :FASL-MD5 "403f844f90f4c3d2e5e5b3b2e37ae88a")
  (:FILE "src/series/routing-select.lisp" :SOURCE-MD5
   "e0f987d8767744050ec4d1b3ecb699ed" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/routing-select.fasl"
   :FASL-MD5 "40f289b404cf317206e54f09397aaa8b")
  (:FILE "src/series/routing-build.lisp" :SOURCE-MD5
   "d6924deff152b941bd49f0bb200b4197" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/routing-build.fasl"
   :FASL-MD5 "6cde6de03d5a66e58d61c31fb0a5f7a8")
  (:FILE "src/series/retirement.lisp" :SOURCE-MD5
   "b8e04971b8ad75a1bd0c722997badfd2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/retirement.fasl"
   :FASL-MD5 "915eb6ea9dff4cab2efd0699bd381922")
  (:FILE "src/series/query.lisp" :SOURCE-MD5 "cb0d91405325b508e6b2ab24d178de7a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/query.fasl"
   :FASL-MD5 "c0f1849da0d590f698334205f277aded")
  (:FILE "src/series/publication.lisp" :SOURCE-MD5
   "056d2c6a67c9d9f2bf9fe2d2c348d53c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/publication.fasl"
   :FASL-MD5 "97f3b29ed64cebb79a10a4735e34063c")
  (:FILE "src/series/package.lisp" :SOURCE-MD5
   "59e3c59c90d8d0fc5731b87496a785aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/package.fasl"
   :FASL-MD5 "792ad4ee6b46a32a75525fb31bafe5a5")
  (:FILE "src/series/ownership.lisp" :SOURCE-MD5
   "de1aca16a35d34d16aba12ff541c0d2b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/ownership.fasl"
   :FASL-MD5 "8518300efcaeb28c7ffdc1d8dd4a0c14")
  (:FILE "src/series/io-events.lisp" :SOURCE-MD5
   "b6026a8b7bb64b45c37a65effda70d8e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/io-events.fasl"
   :FASL-MD5 "286a52d89f38f5d43bc04453604a5478")
  (:FILE "src/series/events.lisp" :SOURCE-MD5
   "32b2156739a6f2ca996abb91df0a2603" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/series/events.fasl"
   :FASL-MD5 "b1862ebc6bcc985c920fc7a90f43bf6a")
  (:FILE "src/recovery/scan.lisp" :SOURCE-MD5
   "fcacd15460db25ea9cc4036065f9f096" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/scan.fasl"
   :FASL-MD5 "ac194960f8f687bdb35c3d17c21d6ced")
  (:FILE "src/recovery/package.lisp" :SOURCE-MD5
   "1c1c8ad0cd15b1703a2fe19cbf3f13c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/package.fasl"
   :FASL-MD5 "1e8fce8d1c52062cb97d36522e096d06")
  (:FILE "src/recovery/manifest-types.lisp" :SOURCE-MD5
   "7b1d4054415faca7e5fca59ad83b4d4a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-types.fasl"
   :FASL-MD5 "3bec86ba8fa802ca34f04959053638f6")
  (:FILE "src/recovery/manifest-query.lisp" :SOURCE-MD5
   "ebd7a54adea2213294a887e6d4db0927" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-query.fasl"
   :FASL-MD5 "ddd6e4f68cb7c54d8c97616d363ec2ec")
  (:FILE "src/recovery/manifest-package.lisp" :SOURCE-MD5
   "37ace42844c11b52446ee1fc500b8e0b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-package.fasl"
   :FASL-MD5 "51b64a95413b2a1e6cc07aef6c405762")
  (:FILE "src/recovery/manifest-fold.lisp" :SOURCE-MD5
   "e0d2498db1011e857b7b0daa1934f187" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-fold.fasl"
   :FASL-MD5 "b246d5f5cefbf71a0538619abf3f6d19")
  (:FILE "src/recovery/manifest-decode.lisp" :SOURCE-MD5
   "67975249aaabd751757cdfb9222cc3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-decode.fasl"
   :FASL-MD5 "4eda6146778a051c7abb5bedae7ac1c8")
  (:FILE "src/recovery/manifest-build.lisp" :SOURCE-MD5
   "bf65b1731eab6e0572461ef5cc60fc40" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/manifest-build.fasl"
   :FASL-MD5 "179ceda9098d62a5906bc88a2baa114b")
  (:FILE "src/recovery/inventory-types.lisp" :SOURCE-MD5
   "78c136d5838dcfe3019d9069643a8d8f" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/inventory-types.fasl"
   :FASL-MD5 "3869428a75f348a3f0cad0c8e4537768")
  (:FILE "src/recovery/inventory-query.lisp" :SOURCE-MD5
   "fcea263de1938767772e5b11411ecd5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/inventory-query.fasl"
   :FASL-MD5 "945dd4c202f5d51c3cfcaf08f0b8123d")
  (:FILE "src/recovery/inventory-build.lisp" :SOURCE-MD5
   "9bd6820c4feba3e552aab1a4edd87861" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/inventory-build.fasl"
   :FASL-MD5 "64e3550f4b5b1022168ed1d09e0d589b")
  (:FILE "src/recovery/decisions-types.lisp" :SOURCE-MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-types.fasl"
   :FASL-MD5 "55ef5f665e760a8c1da2c54abec0c718")
  (:FILE "src/recovery/decisions-sort.lisp" :SOURCE-MD5
   "b33e57a643f2fca810846f6226366253" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-sort.fasl"
   :FASL-MD5 "ebc9b014d790225398cca4bdb245fd87")
  (:FILE "src/recovery/decisions-radix.lisp" :SOURCE-MD5
   "852149de4c289b8e067602780378d87a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-radix.fasl"
   :FASL-MD5 "b61f75b8b02ebe0512af423090be5676")
  (:FILE "src/recovery/decisions-query.lisp" :SOURCE-MD5
   "f782d1137b8ce342b91c9999cfb7accc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-query.fasl"
   :FASL-MD5 "8b32d05de7ada748995899668fbf90f1")
  (:FILE "src/recovery/decisions-package.lisp" :SOURCE-MD5
   "cbdc30f93109c474e1fc25066c9b9b13" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-package.fasl"
   :FASL-MD5 "1a2a93eedd7f9a336c8057501355e0e0")
  (:FILE "src/recovery/decisions-build.lisp" :SOURCE-MD5
   "1a51ef4a488bb9fde2ff7d47bae01379" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/recovery/decisions-build.fasl"
   :FASL-MD5 "403d23d57baa73752a661b4ba896c0a7")
  (:FILE "src/read/types.lisp" :SOURCE-MD5 "9c37ff8237fcc9fe9ae4f44316e854e3"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/read/types.fasl"
   :FASL-MD5 "fc9934c44fa90fe22cd275a95c81d8e6")
  (:FILE "src/read/task.lisp" :SOURCE-MD5 "9e0baf22c53329d393e047c669679645"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/read/task.fasl"
   :FASL-MD5 "c33c8524fa6e8c38ca0a7a71542e4f49")
  (:FILE "src/read/package.lisp" :SOURCE-MD5 "7d74d9decc5a0bc9f9331d89bd503e21"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/read/package.fasl"
   :FASL-MD5 "60267feadbc738873b8d966f1165f9bd")
  (:FILE "src/read/core.lisp" :SOURCE-MD5 "4040905f4a64ba704a480d82e87ec748"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/read/core.fasl"
   :FASL-MD5 "30a1a4ae57717bc608643d855e8b71b7")
  (:FILE "src/package.lisp" :SOURCE-MD5 "becf5c78049c85f2c05cd1ef54454032"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/package.fasl"
   :FASL-MD5 "ee9749081d911b86a5dcca705828a7f5")
  (:FILE "src/mvcc/types.lisp" :SOURCE-MD5 "a9bc70eab6720b5c6f8503178e2c966b"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/types.fasl"
   :FASL-MD5 "5d0be9369e82ab55382764d93963771c")
  (:FILE "src/mvcc/snapshots-types.lisp" :SOURCE-MD5
   "475517bd7ba04a1c37a82efeb8ff73d9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-types.fasl"
   :FASL-MD5 "56cabc3f9690811da25ca329c79140ce")
  (:FILE "src/mvcc/snapshots-register.lisp" :SOURCE-MD5
   "2d5a795bcefd605c75da91c725ae83a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-register.fasl"
   :FASL-MD5 "4bd011b42fc61d1504f87d674094b68d")
  (:FILE "src/mvcc/snapshots-read.lisp" :SOURCE-MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-read.fasl"
   :FASL-MD5 "16b2edd4489ab8ab2631f7569b11df6d")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :SOURCE-MD5
   "ff98aea5cb9a7ae2671f6a887a003725" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-lifecycle.fasl"
   :FASL-MD5 "a4610635a8471dfb897dd29c60353a59")
  (:FILE "src/mvcc/snapshots-csn.lisp" :SOURCE-MD5
   "0e9365e674d1584b111f915ce1f58634" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-csn.fasl"
   :FASL-MD5 "ccf55fe6154d6c9caa1a6198723c1647")
  (:FILE "src/mvcc/snapshots-core.lisp" :SOURCE-MD5
   "8bb066aab61a18eff175b9edb11e42a2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/snapshots-core.fasl"
   :FASL-MD5 "cca012fa2d34e76b19ec0719835b0882")
  (:FILE "src/mvcc/package.lisp" :SOURCE-MD5 "f188d1dbd5d0adb49f53acf09157aef9"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/mvcc/package.fasl"
   :FASL-MD5 "efa68624b2178f351cf01241e143b6ed")
  (:FILE "src/io/types.lisp" :SOURCE-MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/types.fasl"
   :FASL-MD5 "ae93fd254510be67e7348b8b2b41911c")
  (:FILE "src/io/transfer.lisp" :SOURCE-MD5 "a5e7108e80664eb3b562fbd7e680801f"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/transfer.fasl"
   :FASL-MD5 "5de9606db7176c4dc67e533cf0f17174")
  (:FILE "src/io/package.lisp" :SOURCE-MD5 "c43618d5b3d8725e167f72cb90d9369a"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/package.fasl"
   :FASL-MD5 "e17e012ca6d336766cafa898d9f8e8c2")
  (:FILE "src/io/native.lisp" :SOURCE-MD5 "58030bc0c811248a6537e2909d8762d6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/native.fasl"
   :FASL-MD5 "c6f082039a95a8fc05bb7df886e45241")
  (:FILE "src/io/lifecycle.lisp" :SOURCE-MD5 "11c7103efbe733bbf0a13927f23c3d34"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/lifecycle.fasl"
   :FASL-MD5 "7b29e6639624d9fae874f7da96fb6380")
  (:FILE "src/io/identity.lisp" :SOURCE-MD5 "06ea105db71f021ea60b2c59645273b4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/identity.fasl"
   :FASL-MD5 "6a3d0e8f6861a0e8b17ca05a6142b786")
  (:FILE "src/io/identity-types.lisp" :SOURCE-MD5
   "d354a095fb378c1b6f27397ffb902227" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/identity-types.fasl"
   :FASL-MD5 "7625986908a4344c487237ba41cf22a9")
  (:FILE "src/io/flush.lisp" :SOURCE-MD5 "716866194d6b9f076e102e84187229c0"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/io/flush.fasl"
   :FASL-MD5 "4156d2a46bc3c4a26a98a56dbf9bf686")
  (:FILE "src/index/write.lisp" :SOURCE-MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/write.fasl"
   :FASL-MD5 "7000054a7a7cae25b990bc634d59877d")
  (:FILE "src/index/validation.lisp" :SOURCE-MD5
   "3384cadf737c7d80c004222022a281f6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/validation.fasl"
   :FASL-MD5 "a7f836dea099aa66f848eb269d6a947a")
  (:FILE "src/index/types.lisp" :SOURCE-MD5 "5157fd03ee806ee998ad8f0002d56268"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/types.fasl"
   :FASL-MD5 "6293537d831184ee75ad63c2e64d89ef")
  (:FILE "src/index/relocate.lisp" :SOURCE-MD5
   "475dd7d5809a836f01544b447cc8df27" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/relocate.fasl"
   :FASL-MD5 "01283610d1ffafb7429619b87cbc6763")
  (:FILE "src/index/rebuild.lisp" :SOURCE-MD5
   "a450cac8071513365267e7024cbe94b0" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/rebuild.fasl"
   :FASL-MD5 "9fc7492a5db6a365c52619e192c47593")
  (:FILE "src/index/rebuild-scan.lisp" :SOURCE-MD5
   "1188e7a64a7a5d9482c1233cb9acb452" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/rebuild-scan.fasl"
   :FASL-MD5 "80f1d7b0a9e48f07e845064aeba6ca18")
  (:FILE "src/index/rebuild-copy.lisp" :SOURCE-MD5
   "8befbbd00ed5c31c1487a11887eba495" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/rebuild-copy.fasl"
   :FASL-MD5 "d5dda55f01c9967646eeda704114363f")
  (:FILE "src/index/rebuild-budget.lisp" :SOURCE-MD5
   "0417dd41cb3ec1d62dfd913c19f810ad" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/rebuild-budget.fasl"
   :FASL-MD5 "1c691be869f4a7217d5cf931f421e8bf")
  (:FILE "src/index/read.lisp" :SOURCE-MD5 "5b22b90cfe8534086f6aff96d156713e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/read.fasl"
   :FASL-MD5 "451a416346ea3982a2d1d7202546b32a")
  (:FILE "src/index/primary-write.lisp" :SOURCE-MD5
   "e8e31e599356e592af29c0cc4604872b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-write.fasl"
   :FASL-MD5 "6bac717134f2bfce75e39201fbb6e853")
  (:FILE "src/index/primary-types.lisp" :SOURCE-MD5
   "a59eab6425a60fa2656f86bf87d5c9ac" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-types.fasl"
   :FASL-MD5 "4580a5c8c141a119b66d88efff339798")
  (:FILE "src/index/primary-relocate.lisp" :SOURCE-MD5
   "5155959766645d3172ae5e73c58cc071" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-relocate.fasl"
   :FASL-MD5 "d3b567c7c6c225004d2e8a648ea96732")
  (:FILE "src/index/primary-read.lisp" :SOURCE-MD5
   "3f317a0d3c5ee86a73651aad36135cc3" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-read.fasl"
   :FASL-MD5 "963c6a6fd4e4b960d348f031fcb5b0d6")
  (:FILE "src/index/primary-probe.lisp" :SOURCE-MD5
   "699ce3f1615296fc27fcde3e0d63a4bc" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-probe.fasl"
   :FASL-MD5 "f8482a8eccc8ccbcfbddd7acdcc8e937")
  (:FILE "src/index/primary-package.lisp" :SOURCE-MD5
   "d65cfce399b04f905bf969929962e59a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-package.fasl"
   :FASL-MD5 "79b200630c94ac1cf6957f98862c1985")
  (:FILE "src/index/primary-directory.lisp" :SOURCE-MD5
   "1dd67c527257e43f17e006644ecdbd00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-directory.fasl"
   :FASL-MD5 "fd3eb741f9f86f75e7629e02ab8d8266")
  (:FILE "src/index/primary-core.lisp" :SOURCE-MD5
   "fa52433eae199ceeb874bf2bc47afca7" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-core.fasl"
   :FASL-MD5 "87f3008a00ec67562a4b44a127cdb1ce")
  (:FILE "src/index/primary-build.lisp" :SOURCE-MD5
   "ff2cfbb865290d7a1510fdf6877c7229" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-build.fasl"
   :FASL-MD5 "326d212617ce21c33982c9c11df6c7ec")
  (:FILE "src/index/primary-arena.lisp" :SOURCE-MD5
   "a319691e3e28b7ea7b927de490cf69ba" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/primary-arena.fasl"
   :FASL-MD5 "8aab01b01f7163d667355ab51deb0f90")
  (:FILE "src/index/package.lisp" :SOURCE-MD5
   "598a9b65e73151c924b2cdcaf6d96705" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/package.fasl"
   :FASL-MD5 "72f8d05f14f6255e7aa8432a08bc3eac")
  (:FILE "src/index/hash-seed.lisp" :SOURCE-MD5
   "45ce41749bc6fa638539815d3f802b96" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/hash-seed.fasl"
   :FASL-MD5 "35f54196a852cc79e703e8b3cc0a4e4a")
  (:FILE "src/index/hash-digests.lisp" :SOURCE-MD5
   "43d2209225707352daec6186ef95a805" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/hash-digests.fasl"
   :FASL-MD5 "6f3fbfad54e7aa34f441d38f667eaa7d")
  (:FILE "src/index/core.lisp" :SOURCE-MD5 "65076c355c099b5dc73d185948d3bec4"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/index/core.fasl"
   :FASL-MD5 "760c62402e5e8ed7fb5fd67dc324aeb4")
  (:FILE "src/hash/package.lisp" :SOURCE-MD5 "2d9060e41bc5252067d35e59ac70ee06"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/hash/package.fasl"
   :FASL-MD5 "0ca8ffd1cb97e4cd3a7baac8500c70fc")
  (:FILE "src/hash/hash64.lisp" :SOURCE-MD5 "886b7c08b9929283e8968831cbe5c039"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/hash/hash64.fasl"
   :FASL-MD5 "aa6d0e6ea04e320a187df415ebc3f29a")
  (:FILE "src/hash/blocks.lisp" :SOURCE-MD5 "bef497b9a267c7306d4100000491c814"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/hash/blocks.fasl"
   :FASL-MD5 "3c9b388b1be6db139b6ff2c177376df3")
  (:FILE "src/hash/arithmetic.lisp" :SOURCE-MD5
   "b5c51802e607e3dd22de68204baf64e9" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/hash/arithmetic.fasl"
   :FASL-MD5 "ad4b6b3e5aab2f29126010fee5629a3d")
  (:FILE "src/get/types.lisp" :SOURCE-MD5 "c394e5684de5e2d938991c7cb348b93c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/types.fasl"
   :FASL-MD5 "9f7aaf4c385059726a2ccf943221f537")
  (:FILE "src/get/target.lisp" :SOURCE-MD5 "1b70dac05d6d2418909eb5105b808e81"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/target.fasl"
   :FASL-MD5 "0e2f892af53fe21f91f63b8e65f44842")
  (:FILE "src/get/segment.lisp" :SOURCE-MD5 "811869eb6a197d3c4e26af4322e52652"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/segment.fasl"
   :FASL-MD5 "64a0b6f168e55ef90ed244325dbe27c6")
  (:FILE "src/get/package.lisp" :SOURCE-MD5 "c72633d15c3488699072eb610ebde7c8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/package.fasl"
   :FASL-MD5 "4a8f63e55398eabc82f4b0d91c793960")
  (:FILE "src/get/lookup.lisp" :SOURCE-MD5 "82258ec87aca513a508bc5dee8410dd6"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/lookup.fasl"
   :FASL-MD5 "18f2f5e25da89c8b5eec24b62205458a")
  (:FILE "src/get/lifecycle.lisp" :SOURCE-MD5
   "e70bfeddd694336bbd088e65f8761834" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/lifecycle.fasl"
   :FASL-MD5 "1a62f1a0a5a96bf4b1ebc2259c05f50e")
  (:FILE "src/get/build.lisp" :SOURCE-MD5 "c5cc36884b238221cc13ca0c087ec7c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get/build.fasl"
   :FASL-MD5 "cfef316e84a3f952aa7b3ab9d24cdc74")
  (:FILE "src/get-resolver/types.lisp" :SOURCE-MD5
   "9df13bcc6908e9fa601d173a671e1ccf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/types.fasl"
   :FASL-MD5 "e6d16ef8fca121268cf6c85b1b5a0e8c")
  (:FILE "src/get-resolver/sort.lisp" :SOURCE-MD5
   "2d869293ba47444c4721713d955c6254" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/sort.fasl"
   :FASL-MD5 "22863632a534803e69ee63353eedf7dd")
  (:FILE "src/get-resolver/scan.lisp" :SOURCE-MD5
   "536e9dc4ed51072b8a6d1528d3ec18bf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/scan.fasl"
   :FASL-MD5 "62ee0d9e248bd7add25366dc34e36a5c")
  (:FILE "src/get-resolver/rows.lisp" :SOURCE-MD5
   "ca9002b81efd0aed9761cd1f78514762" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/rows.fasl"
   :FASL-MD5 "f1164a622d36a2374ee01ff58abaf5d2")
  (:FILE "src/get-resolver/read.lisp" :SOURCE-MD5
   "1339edff0223dbf122f11ff0adbba61c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/read.fasl"
   :FASL-MD5 "602499a8e93cc24316a9e5bc4c207901")
  (:FILE "src/get-resolver/package.lisp" :SOURCE-MD5
   "6226d131f5562a475048b6444049c4ca" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/package.fasl"
   :FASL-MD5 "25630d8c82faf6b31d7f80a13b337d31")
  (:FILE "src/get-resolver/build.lisp" :SOURCE-MD5
   "bbfb2082103e6712419e180ab972245c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/build.fasl"
   :FASL-MD5 "284d3b5b06241ee01e2eea213caa3231")
  (:FILE "src/get-resolver/active-types.lisp" :SOURCE-MD5
   "bd7182e9871fe82530d0c828e473ccde" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-types.fasl"
   :FASL-MD5 "52dfac59d025682fcccf35c7e68d3760")
  (:FILE "src/get-resolver/active-scan.lisp" :SOURCE-MD5
   "d6aaec49504a96f37c8ff1bc182c977b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-scan.fasl"
   :FASL-MD5 "3ae089f03aca18ae4e9dc8d59c986a93")
  (:FILE "src/get-resolver/active-read.lisp" :SOURCE-MD5
   "521737861e057d663964b0c030552587" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-read.fasl"
   :FASL-MD5 "2ef7fdeb445bb0afe736fcf88d93fac1")
  (:FILE "src/get-resolver/active-preflight.lisp" :SOURCE-MD5
   "f13d422adb6aa9e8489352884137f25a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-preflight.fasl"
   :FASL-MD5 "706e69ba9f9322057eae64de11cf9bd2")
  (:FILE "src/get-resolver/active-directory.lisp" :SOURCE-MD5
   "6d95f29b331d335175843f47ae44a6ea" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-directory.fasl"
   :FASL-MD5 "d869e6e6534ce6312ca5eeaf0d58f765")
  (:FILE "src/get-resolver/active-build.lisp" :SOURCE-MD5
   "c65593cf172f53a8e90a853bbe9504c2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-resolver/active-build.fasl"
   :FASL-MD5 "fe07f97c66152e6470a5ed0a40250b35")
  (:FILE "src/get-directory/types.lisp" :SOURCE-MD5
   "17c957d6934a31f4ed64313e756de2d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/types.fasl"
   :FASL-MD5 "6770d9e25964d862f4550625b961702f")
  (:FILE "src/get-directory/sources-types.lisp" :SOURCE-MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/sources-types.fasl"
   :FASL-MD5 "0030a2e3c67923339beb4af108db783d")
  (:FILE "src/get-directory/sources-read.lisp" :SOURCE-MD5
   "fe8a60fc4f720bd864c248b71cb71654" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/sources-read.fasl"
   :FASL-MD5 "0b6fbd9e89a9b23739e3c91f55498398")
  (:FILE "src/get-directory/read.lisp" :SOURCE-MD5
   "74a694385f1aaf03ec87721545494119" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/read.fasl"
   :FASL-MD5 "700aa6323b232059136cf35a380cdcb6")
  (:FILE "src/get-directory/package.lisp" :SOURCE-MD5
   "894f6e238fe4047f2bf607fceae86846" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/package.fasl"
   :FASL-MD5 "14fcf91d1fcf36657eb8d43e47ce3043")
  (:FILE "src/get-directory/build.lisp" :SOURCE-MD5
   "cde24b2bf5c5637d5501b95bed47df31" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/get-directory/build.fasl"
   :FASL-MD5 "7c799d71b0d9dad77ebb16c7ab838bb7")
  (:FILE "src/foundation/record.lisp" :SOURCE-MD5
   "c3ed0f09fa3fa6fe20c98e2ed6e69abe" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/record.fasl"
   :FASL-MD5 "99fbacbd788772ea5776fcab9aa2f8ed")
  (:FILE "src/foundation/package.lisp" :SOURCE-MD5
   "5ee593a112958d94163dab17c5aa4ba2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/package.fasl"
   :FASL-MD5 "fe2dfb57f8f4df455187a418926f1713")
  (:FILE "src/foundation/crc32c.lisp" :SOURCE-MD5
   "4db58e2f48bf77d751f1b83bb9f84b5c" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/crc32c.fasl"
   :FASL-MD5 "8567ffe1db5c6e8adcb934a5056575ba")
  (:FILE "src/foundation/conditions.lisp" :SOURCE-MD5
   "942b596396c19815290a57830af2121b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/conditions.fasl"
   :FASL-MD5 "9e22e85ea84a1b85b01c7133d6a8bb6d")
  (:FILE "src/foundation/binary.lisp" :SOURCE-MD5
   "a06115175f450776762761dce25acdb8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/binary.fasl"
   :FASL-MD5 "fb3ab402baf3c5f3f85f94b826dce9bf")
  (:FILE "src/foundation/batch.lisp" :SOURCE-MD5
   "ca642ea47e4bff76f78f5b6d7287d6bd" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/foundation/batch.fasl"
   :FASL-MD5 "9b97857ad170f5efd37bf62d30097e62")
  (:FILE "src/execution/writer.lisp" :SOURCE-MD5
   "73019644090e2971f2b54dc36e4491f5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/writer.fasl"
   :FASL-MD5 "c3ff08516fbf1a57eb9acfd0a8451835")
  (:FILE "src/execution/worker-types.lisp" :SOURCE-MD5
   "0679ee07c46f69db330706303c70d8d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/worker-types.fasl"
   :FASL-MD5 "4f5deeca890aed9ff32e4f4609e00947")
  (:FILE "src/execution/worker-run.lisp" :SOURCE-MD5
   "aa34ca6bc07535e35fea723878d99f66" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/worker-run.fasl"
   :FASL-MD5 "98e1b5b19616ca4898eccd426cf408e7")
  (:FILE "src/execution/worker-claim.lisp" :SOURCE-MD5
   "babd0a78b4185af24ae1fef870c0fabb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/worker-claim.fasl"
   :FASL-MD5 "7462fbdc2469579ac9423f3fa953bfae")
  (:FILE "src/execution/worker-boundary.lisp" :SOURCE-MD5
   "c24065d6c8d80d1be53994a0041743df" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/worker-boundary.fasl"
   :FASL-MD5 "8dfd106dfd0691e6e2779daf7a4a7739")
  (:FILE "src/execution/ready.lisp" :SOURCE-MD5
   "2c1892002f0599bb8273093031017520" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/ready.fasl"
   :FASL-MD5 "4b417d9fed1f327326e38c68dbf9f857")
  (:FILE "src/execution/ready-types.lisp" :SOURCE-MD5
   "a64d98c9ff429d6103d6e10ee1fd7980" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/ready-types.fasl"
   :FASL-MD5 "b17174d8be02ab31a03b300d387ea9c2")
  (:FILE "src/execution/ready-recycle.lisp" :SOURCE-MD5
   "38d26f8c749dd946dfc4b9c57103a892" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/ready-recycle.fasl"
   :FASL-MD5 "2029847d4b09ffb3969da928aca4b9d4")
  (:FILE "src/execution/queue.lisp" :SOURCE-MD5
   "8202843bddb817da4279ac959ae3f3c4" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/queue.fasl"
   :FASL-MD5 "629bcf60d8af915294f25da4bd08e106")
  (:FILE "src/execution/package.lisp" :SOURCE-MD5
   "cb5710d6c111cadb7121a50998a747fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/package.fasl"
   :FASL-MD5 "26fbdff962d7febdbfab409c07ebaffe")
  (:FILE "src/execution/handoff.lisp" :SOURCE-MD5
   "6b85eebe69366e78ed5fc5cc20735f00" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/execution/handoff.fasl"
   :FASL-MD5 "1399aed1efb86e75a25a51428ec699bf")
  (:FILE "src/epochs/types.lisp" :SOURCE-MD5 "82253491f995f5bc153fb5ebf30d564c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/types.fasl"
   :FASL-MD5 "ce53e5a769c9b1441b80f6645e5aab13")
  (:FILE "src/epochs/retire.lisp" :SOURCE-MD5
   "653b974f310c09f6e2224a84acc43bbf" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/retire.fasl"
   :FASL-MD5 "5ebabe0009c853635a45038733f0b66e")
  (:FILE "src/epochs/reclaim.lisp" :SOURCE-MD5
   "036dd02adf87d33c3ae2f40735c733fa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/reclaim.fasl"
   :FASL-MD5 "0e48a55d17ca63fa2a42e55a70faa72c")
  (:FILE "src/epochs/read.lisp" :SOURCE-MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/read.fasl"
   :FASL-MD5 "6f107901ac09577de597498665f4fdb9")
  (:FILE "src/epochs/package.lisp" :SOURCE-MD5
   "875201dfab0a84efd40fe9828cc293c8" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/package.fasl"
   :FASL-MD5 "f0f2d2a1ed3432d7a9ce14d092ca60c7")
  (:FILE "src/epochs/core.lisp" :SOURCE-MD5 "765d14c88cd288093a77a57930cd6999"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/epochs/core.fasl"
   :FASL-MD5 "aa251ca6cb89db5a5a42de9db54b80f0")
  (:FILE "src/csn/registry.lisp" :SOURCE-MD5 "a1cdb5661fc54beba5bf00e4765f3235"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/csn/registry.fasl"
   :FASL-MD5 "59cfa4ae72375612edb76a8c5f754a04")
  (:FILE "src/csn/package.lisp" :SOURCE-MD5 "1130012fc5613a5648d22ed8628be0e8"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/csn/package.fasl"
   :FASL-MD5 "b80a2b831ce95a68f8703819940a7d41")
  (:FILE "src/codec/utf8.lisp" :SOURCE-MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/utf8.fasl"
   :FASL-MD5 "09522d0b659f83dcace7e9529f5dcdc2")
  (:FILE "src/codec/package.lisp" :SOURCE-MD5
   "d885bd2a9860eb60aec1a775e5031d5e" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/package.fasl"
   :FASL-MD5 "29ec66d229a072dafd44bd61ba1d7e09")
  (:FILE "src/codec/cbor-write.lisp" :SOURCE-MD5
   "69e77bcd15b5413a815a65c5081229db" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-write.fasl"
   :FASL-MD5 "4515d353628cbb35439f25be2543e947")
  (:FILE "src/codec/cbor-string-write.lisp" :SOURCE-MD5
   "b13e92b5f24a42fe283c17b649722b6a" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-string-write.fasl"
   :FASL-MD5 "6a521487158ac4991f290d00e4788d47")
  (:FILE "src/codec/cbor-space.lisp" :SOURCE-MD5
   "c33cdcc45f45218aa3e8bf26ce0ee575" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-space.fasl"
   :FASL-MD5 "f1f0104bbcd69e2239f1760988894ef4")
  (:FILE "src/codec/cbor-simple-write.lisp" :SOURCE-MD5
   "200373402e6e082dd8c7afde305302bb" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-simple-write.fasl"
   :FASL-MD5 "320fa0f9858954f3e56ff4bfc942bf71")
  (:FILE "src/codec/cbor-scan.lisp" :SOURCE-MD5
   "0c33aedcdb352e78a3c694cf796e6692" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan.fasl"
   :FASL-MD5 "e4b9e4f2e9f5eee3923a03ac30ee29d2")
  (:FILE "src/codec/cbor-scan-stack.lisp" :SOURCE-MD5
   "cf1999ddb10f879aeefbeea853742d57" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan-stack.fasl"
   :FASL-MD5 "d4a3cb6d5ab6b7d8e935b5a9981c2e51")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :SOURCE-MD5
   "987e8ed576a21eb644ac1ef2e06edbda" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan-minimal.fasl"
   :FASL-MD5 "7f0653d51504ce950bb7d8435ae4e161")
  (:FILE "src/codec/cbor-scan-items.lisp" :SOURCE-MD5
   "706c0baa4158bf272c4b0df17c1439d2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan-items.fasl"
   :FASL-MD5 "00fafa4229451a0bce27dbe0ba9a8b43")
  (:FILE "src/codec/cbor-scan-input.lisp" :SOURCE-MD5
   "f6488e987889432b375254021825dbe5" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-scan-input.fasl"
   :FASL-MD5 "0abe65e12eeb8d8a71ee6096073bfe9c")
  (:FILE "src/codec/cbor-package.lisp" :SOURCE-MD5
   "c3f19ffb4aacfdfe502c5e8b12a234f2" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-package.fasl"
   :FASL-MD5 "26c44705b8533dd8d0b18781e4bec30e")
  (:FILE "src/codec/cbor-minimal.lisp" :SOURCE-MD5
   "ecd8fe950344059c629927b38fb6e4aa" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-minimal.fasl"
   :FASL-MD5 "055f995fc03a323c9778f2e8fee3fb1c")
  (:FILE "src/codec/cbor-header.lisp" :SOURCE-MD5
   "6e8c6a49314c2f460aa6f8a1759200b6" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-header.fasl"
   :FASL-MD5 "128a984c3ca25c1347ee4c16fc63e642")
  (:FILE "src/codec/cbor-float-minimal.lisp" :SOURCE-MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/codec/cbor-float-minimal.fasl"
   :FASL-MD5 "2b09a6b6e4a52cd77697d53a8f777d5a")
  (:FILE "src/cache/write.lisp" :SOURCE-MD5 "fc09021f74fb50aac57589614dae04d7"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/write.fasl"
   :FASL-MD5 "06ac4ce5d8f0049b26ea95094824a43c")
  (:FILE "src/cache/types.lisp" :SOURCE-MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/types.fasl"
   :FASL-MD5 "e70c365db450cd91c5d66c41ba48fe32")
  (:FILE "src/cache/read.lisp" :SOURCE-MD5 "82f937b7b08bd1696ad9c88da2e1c60c"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/read.fasl"
   :FASL-MD5 "6965701512c54a211eb3300a362285f8")
  (:FILE "src/cache/package.lisp" :SOURCE-MD5
   "a1f6a8e7aa4faed88e984b39871d1e53" :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/package.fasl"
   :FASL-MD5 "c9d31504cdf463538ab0f9b5b01193c8")
  (:FILE "src/cache/core.lisp" :SOURCE-MD5 "72f3a33ce27ddf94c49c495580520004"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/core.fasl"
   :FASL-MD5 "fa76eef2a061b5a30d7fa890f16e2ec7")
  (:FILE "src/cache/clock.lisp" :SOURCE-MD5 "3546cf7f5c5ed138068548c20064f499"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/clock.fasl"
   :FASL-MD5 "b8749811e69fe9aa47f75dae45cd4bfa")
  (:FILE "src/cache/build.lisp" :SOURCE-MD5 "5d70197c8b64ad6f20c8be47a60c73ca"
   :FASL
   "/Users/gpicchiarelli/.codex/worktrees/get-controller/ArcDocDB/spikes/out/get-series-mutations-h/raw/isolatedtests/planned-root-instead-of-published/fasl/src/cache/build.fasl"
   :FASL-MD5 "e2ea833f6f80b461a5f28426f07a78c1"))
 :EXPECTED-TESTS
 ("TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION")
 :PASSED-TESTS NIL :FAILED-TEST
 "TEST-REQ-WAL-006-SERIES-GET-ONE-ROOT-AFTER-PIN-DURING-PUBLICATION"
 :FAILURE-KIND :PRODUCT-CONDITION :SOURCE-MANIFEST
 ((:FILE "arcdocdb.asd" :MD5 "1c847de175f4954cec5ef2186308f1a7")
  (:FILE "src/cache/build.lisp" :MD5 "5d70197c8b64ad6f20c8be47a60c73ca")
  (:FILE "src/cache/clock.lisp" :MD5 "3546cf7f5c5ed138068548c20064f499")
  (:FILE "src/cache/core.lisp" :MD5 "72f3a33ce27ddf94c49c495580520004")
  (:FILE "src/cache/package.lisp" :MD5 "a1f6a8e7aa4faed88e984b39871d1e53")
  (:FILE "src/cache/read.lisp" :MD5 "82f937b7b08bd1696ad9c88da2e1c60c")
  (:FILE "src/cache/types.lisp" :MD5 "a25648d870eaa4f0b6e1e3b2cf76e28e")
  (:FILE "src/cache/write.lisp" :MD5 "fc09021f74fb50aac57589614dae04d7")
  (:FILE "src/codec/cbor-float-minimal.lisp" :MD5
   "bc7a7b176e8cdd361b7c4306a1a4de4b")
  (:FILE "src/codec/cbor-header.lisp" :MD5 "6e8c6a49314c2f460aa6f8a1759200b6")
  (:FILE "src/codec/cbor-minimal.lisp" :MD5 "ecd8fe950344059c629927b38fb6e4aa")
  (:FILE "src/codec/cbor-package.lisp" :MD5 "c3f19ffb4aacfdfe502c5e8b12a234f2")
  (:FILE "src/codec/cbor-scan-input.lisp" :MD5
   "f6488e987889432b375254021825dbe5")
  (:FILE "src/codec/cbor-scan-items.lisp" :MD5
   "706c0baa4158bf272c4b0df17c1439d2")
  (:FILE "src/codec/cbor-scan-minimal.lisp" :MD5
   "987e8ed576a21eb644ac1ef2e06edbda")
  (:FILE "src/codec/cbor-scan-stack.lisp" :MD5
   "cf1999ddb10f879aeefbeea853742d57")
  (:FILE "src/codec/cbor-scan.lisp" :MD5 "0c33aedcdb352e78a3c694cf796e6692")
  (:FILE "src/codec/cbor-simple-write.lisp" :MD5
   "200373402e6e082dd8c7afde305302bb")
  (:FILE "src/codec/cbor-space.lisp" :MD5 "c33cdcc45f45218aa3e8bf26ce0ee575")
  (:FILE "src/codec/cbor-string-write.lisp" :MD5
   "b13e92b5f24a42fe283c17b649722b6a")
  (:FILE "src/codec/cbor-write.lisp" :MD5 "69e77bcd15b5413a815a65c5081229db")
  (:FILE "src/codec/package.lisp" :MD5 "d885bd2a9860eb60aec1a775e5031d5e")
  (:FILE "src/codec/utf8.lisp" :MD5 "0f67dd5c51bf6a63bc292ab4e2a280c2")
  (:FILE "src/csn/package.lisp" :MD5 "1130012fc5613a5648d22ed8628be0e8")
  (:FILE "src/csn/registry.lisp" :MD5 "a1cdb5661fc54beba5bf00e4765f3235")
  (:FILE "src/epochs/core.lisp" :MD5 "765d14c88cd288093a77a57930cd6999")
  (:FILE "src/epochs/package.lisp" :MD5 "875201dfab0a84efd40fe9828cc293c8")
  (:FILE "src/epochs/read.lisp" :MD5 "975b5f74e0c5a38ce978f4d9c7fcc6b8")
  (:FILE "src/epochs/reclaim.lisp" :MD5 "036dd02adf87d33c3ae2f40735c733fa")
  (:FILE "src/epochs/retire.lisp" :MD5 "653b974f310c09f6e2224a84acc43bbf")
  (:FILE "src/epochs/types.lisp" :MD5 "82253491f995f5bc153fb5ebf30d564c")
  (:FILE "src/execution/handoff.lisp" :MD5 "6b85eebe69366e78ed5fc5cc20735f00")
  (:FILE "src/execution/package.lisp" :MD5 "cb5710d6c111cadb7121a50998a747fa")
  (:FILE "src/execution/queue.lisp" :MD5 "8202843bddb817da4279ac959ae3f3c4")
  (:FILE "src/execution/ready-recycle.lisp" :MD5
   "38d26f8c749dd946dfc4b9c57103a892")
  (:FILE "src/execution/ready-types.lisp" :MD5
   "a64d98c9ff429d6103d6e10ee1fd7980")
  (:FILE "src/execution/ready.lisp" :MD5 "2c1892002f0599bb8273093031017520")
  (:FILE "src/execution/worker-boundary.lisp" :MD5
   "c24065d6c8d80d1be53994a0041743df")
  (:FILE "src/execution/worker-claim.lisp" :MD5
   "babd0a78b4185af24ae1fef870c0fabb")
  (:FILE "src/execution/worker-run.lisp" :MD5
   "aa34ca6bc07535e35fea723878d99f66")
  (:FILE "src/execution/worker-types.lisp" :MD5
   "0679ee07c46f69db330706303c70d8d2")
  (:FILE "src/execution/writer.lisp" :MD5 "73019644090e2971f2b54dc36e4491f5")
  (:FILE "src/foundation/batch.lisp" :MD5 "ca642ea47e4bff76f78f5b6d7287d6bd")
  (:FILE "src/foundation/binary.lisp" :MD5 "a06115175f450776762761dce25acdb8")
  (:FILE "src/foundation/conditions.lisp" :MD5
   "942b596396c19815290a57830af2121b")
  (:FILE "src/foundation/crc32c.lisp" :MD5 "4db58e2f48bf77d751f1b83bb9f84b5c")
  (:FILE "src/foundation/package.lisp" :MD5 "5ee593a112958d94163dab17c5aa4ba2")
  (:FILE "src/foundation/record.lisp" :MD5 "c3ed0f09fa3fa6fe20c98e2ed6e69abe")
  (:FILE "src/get-directory/build.lisp" :MD5
   "cde24b2bf5c5637d5501b95bed47df31")
  (:FILE "src/get-directory/package.lisp" :MD5
   "894f6e238fe4047f2bf607fceae86846")
  (:FILE "src/get-directory/read.lisp" :MD5 "74a694385f1aaf03ec87721545494119")
  (:FILE "src/get-directory/sources-read.lisp" :MD5
   "fe8a60fc4f720bd864c248b71cb71654")
  (:FILE "src/get-directory/sources-types.lisp" :MD5
   "b846a6348ff7d4b5f7b380b5b3ff8c17")
  (:FILE "src/get-directory/types.lisp" :MD5
   "17c957d6934a31f4ed64313e756de2d2")
  (:FILE "src/get-resolver/active-build.lisp" :MD5
   "c65593cf172f53a8e90a853bbe9504c2")
  (:FILE "src/get-resolver/active-directory.lisp" :MD5
   "6d95f29b331d335175843f47ae44a6ea")
  (:FILE "src/get-resolver/active-preflight.lisp" :MD5
   "f13d422adb6aa9e8489352884137f25a")
  (:FILE "src/get-resolver/active-read.lisp" :MD5
   "521737861e057d663964b0c030552587")
  (:FILE "src/get-resolver/active-scan.lisp" :MD5
   "d6aaec49504a96f37c8ff1bc182c977b")
  (:FILE "src/get-resolver/active-types.lisp" :MD5
   "bd7182e9871fe82530d0c828e473ccde")
  (:FILE "src/get-resolver/build.lisp" :MD5 "bbfb2082103e6712419e180ab972245c")
  (:FILE "src/get-resolver/package.lisp" :MD5
   "6226d131f5562a475048b6444049c4ca")
  (:FILE "src/get-resolver/read.lisp" :MD5 "1339edff0223dbf122f11ff0adbba61c")
  (:FILE "src/get-resolver/rows.lisp" :MD5 "ca9002b81efd0aed9761cd1f78514762")
  (:FILE "src/get-resolver/scan.lisp" :MD5 "536e9dc4ed51072b8a6d1528d3ec18bf")
  (:FILE "src/get-resolver/sort.lisp" :MD5 "2d869293ba47444c4721713d955c6254")
  (:FILE "src/get-resolver/types.lisp" :MD5 "9df13bcc6908e9fa601d173a671e1ccf")
  (:FILE "src/get/build.lisp" :MD5 "c5cc36884b238221cc13ca0c087ec7c2")
  (:FILE "src/get/lifecycle.lisp" :MD5 "e70bfeddd694336bbd088e65f8761834")
  (:FILE "src/get/lookup.lisp" :MD5 "82258ec87aca513a508bc5dee8410dd6")
  (:FILE "src/get/package.lisp" :MD5 "c72633d15c3488699072eb610ebde7c8")
  (:FILE "src/get/segment.lisp" :MD5 "811869eb6a197d3c4e26af4322e52652")
  (:FILE "src/get/target.lisp" :MD5 "1b70dac05d6d2418909eb5105b808e81")
  (:FILE "src/get/types.lisp" :MD5 "c394e5684de5e2d938991c7cb348b93c")
  (:FILE "src/hash/arithmetic.lisp" :MD5 "b5c51802e607e3dd22de68204baf64e9")
  (:FILE "src/hash/blocks.lisp" :MD5 "bef497b9a267c7306d4100000491c814")
  (:FILE "src/hash/hash64.lisp" :MD5 "886b7c08b9929283e8968831cbe5c039")
  (:FILE "src/hash/package.lisp" :MD5 "2d9060e41bc5252067d35e59ac70ee06")
  (:FILE "src/index/core.lisp" :MD5 "65076c355c099b5dc73d185948d3bec4")
  (:FILE "src/index/hash-digests.lisp" :MD5 "43d2209225707352daec6186ef95a805")
  (:FILE "src/index/hash-seed.lisp" :MD5 "45ce41749bc6fa638539815d3f802b96")
  (:FILE "src/index/package.lisp" :MD5 "598a9b65e73151c924b2cdcaf6d96705")
  (:FILE "src/index/primary-arena.lisp" :MD5
   "a319691e3e28b7ea7b927de490cf69ba")
  (:FILE "src/index/primary-build.lisp" :MD5
   "ff2cfbb865290d7a1510fdf6877c7229")
  (:FILE "src/index/primary-core.lisp" :MD5 "fa52433eae199ceeb874bf2bc47afca7")
  (:FILE "src/index/primary-directory.lisp" :MD5
   "1dd67c527257e43f17e006644ecdbd00")
  (:FILE "src/index/primary-package.lisp" :MD5
   "d65cfce399b04f905bf969929962e59a")
  (:FILE "src/index/primary-probe.lisp" :MD5
   "699ce3f1615296fc27fcde3e0d63a4bc")
  (:FILE "src/index/primary-read.lisp" :MD5 "3f317a0d3c5ee86a73651aad36135cc3")
  (:FILE "src/index/primary-relocate.lisp" :MD5
   "5155959766645d3172ae5e73c58cc071")
  (:FILE "src/index/primary-types.lisp" :MD5
   "a59eab6425a60fa2656f86bf87d5c9ac")
  (:FILE "src/index/primary-write.lisp" :MD5
   "e8e31e599356e592af29c0cc4604872b")
  (:FILE "src/index/read.lisp" :MD5 "5b22b90cfe8534086f6aff96d156713e")
  (:FILE "src/index/rebuild-budget.lisp" :MD5
   "0417dd41cb3ec1d62dfd913c19f810ad")
  (:FILE "src/index/rebuild-copy.lisp" :MD5 "8befbbd00ed5c31c1487a11887eba495")
  (:FILE "src/index/rebuild-scan.lisp" :MD5 "1188e7a64a7a5d9482c1233cb9acb452")
  (:FILE "src/index/rebuild.lisp" :MD5 "a450cac8071513365267e7024cbe94b0")
  (:FILE "src/index/relocate.lisp" :MD5 "475dd7d5809a836f01544b447cc8df27")
  (:FILE "src/index/types.lisp" :MD5 "5157fd03ee806ee998ad8f0002d56268")
  (:FILE "src/index/validation.lisp" :MD5 "3384cadf737c7d80c004222022a281f6")
  (:FILE "src/index/write.lisp" :MD5 "f0c8c579cd7db466d243ed3ea9f8e8aa")
  (:FILE "src/io/flush.lisp" :MD5 "716866194d6b9f076e102e84187229c0")
  (:FILE "src/io/identity-types.lisp" :MD5 "d354a095fb378c1b6f27397ffb902227")
  (:FILE "src/io/identity.lisp" :MD5 "06ea105db71f021ea60b2c59645273b4")
  (:FILE "src/io/lifecycle.lisp" :MD5 "11c7103efbe733bbf0a13927f23c3d34")
  (:FILE "src/io/native.lisp" :MD5 "58030bc0c811248a6537e2909d8762d6")
  (:FILE "src/io/package.lisp" :MD5 "c43618d5b3d8725e167f72cb90d9369a")
  (:FILE "src/io/transfer.lisp" :MD5 "a5e7108e80664eb3b562fbd7e680801f")
  (:FILE "src/io/types.lisp" :MD5 "e7b6ee5fd2d57281dbd32bf9b07d0fa6")
  (:FILE "src/mvcc/package.lisp" :MD5 "f188d1dbd5d0adb49f53acf09157aef9")
  (:FILE "src/mvcc/snapshots-core.lisp" :MD5
   "8bb066aab61a18eff175b9edb11e42a2")
  (:FILE "src/mvcc/snapshots-csn.lisp" :MD5 "0e9365e674d1584b111f915ce1f58634")
  (:FILE "src/mvcc/snapshots-lifecycle.lisp" :MD5
   "ff98aea5cb9a7ae2671f6a887a003725")
  (:FILE "src/mvcc/snapshots-read.lisp" :MD5
   "ae3ad96269b5e711a9dbb455f3c0ce48")
  (:FILE "src/mvcc/snapshots-register.lisp" :MD5
   "2d5a795bcefd605c75da91c725ae83a2")
  (:FILE "src/mvcc/snapshots-types.lisp" :MD5
   "475517bd7ba04a1c37a82efeb8ff73d9")
  (:FILE "src/mvcc/types.lisp" :MD5 "a9bc70eab6720b5c6f8503178e2c966b")
  (:FILE "src/package.lisp" :MD5 "becf5c78049c85f2c05cd1ef54454032")
  (:FILE "src/read/core.lisp" :MD5 "4040905f4a64ba704a480d82e87ec748")
  (:FILE "src/read/package.lisp" :MD5 "7d74d9decc5a0bc9f9331d89bd503e21")
  (:FILE "src/read/task.lisp" :MD5 "9e0baf22c53329d393e047c669679645")
  (:FILE "src/read/types.lisp" :MD5 "9c37ff8237fcc9fe9ae4f44316e854e3")
  (:FILE "src/recovery/decisions-build.lisp" :MD5
   "1a51ef4a488bb9fde2ff7d47bae01379")
  (:FILE "src/recovery/decisions-package.lisp" :MD5
   "cbdc30f93109c474e1fc25066c9b9b13")
  (:FILE "src/recovery/decisions-query.lisp" :MD5
   "f782d1137b8ce342b91c9999cfb7accc")
  (:FILE "src/recovery/decisions-radix.lisp" :MD5
   "852149de4c289b8e067602780378d87a")
  (:FILE "src/recovery/decisions-sort.lisp" :MD5
   "b33e57a643f2fca810846f6226366253")
  (:FILE "src/recovery/decisions-types.lisp" :MD5
   "f4433fd19ebc7239dbc2628c39f3ecdb")
  (:FILE "src/recovery/inventory-build.lisp" :MD5
   "9bd6820c4feba3e552aab1a4edd87861")
  (:FILE "src/recovery/inventory-query.lisp" :MD5
   "fcea263de1938767772e5b11411ecd5e")
  (:FILE "src/recovery/inventory-types.lisp" :MD5
   "78c136d5838dcfe3019d9069643a8d8f")
  (:FILE "src/recovery/manifest-build.lisp" :MD5
   "bf65b1731eab6e0572461ef5cc60fc40")
  (:FILE "src/recovery/manifest-decode.lisp" :MD5
   "67975249aaabd751757cdfb9222cc3c4")
  (:FILE "src/recovery/manifest-fold.lisp" :MD5
   "e0d2498db1011e857b7b0daa1934f187")
  (:FILE "src/recovery/manifest-package.lisp" :MD5
   "37ace42844c11b52446ee1fc500b8e0b")
  (:FILE "src/recovery/manifest-query.lisp" :MD5
   "ebd7a54adea2213294a887e6d4db0927")
  (:FILE "src/recovery/manifest-types.lisp" :MD5
   "7b1d4054415faca7e5fca59ad83b4d4a")
  (:FILE "src/recovery/package.lisp" :MD5 "1c1c8ad0cd15b1703a2fe19cbf3f13c2")
  (:FILE "src/recovery/scan.lisp" :MD5 "fcacd15460db25ea9cc4036065f9f096")
  (:FILE "src/series/events.lisp" :MD5 "32b2156739a6f2ca996abb91df0a2603")
  (:FILE "src/series/io-events.lisp" :MD5 "b6026a8b7bb64b45c37a65effda70d8e")
  (:FILE "src/series/ownership.lisp" :MD5 "de1aca16a35d34d16aba12ff541c0d2b")
  (:FILE "src/series/package.lisp" :MD5 "59e3c59c90d8d0fc5731b87496a785aa")
  (:FILE "src/series/publication.lisp" :MD5 "056d2c6a67c9d9f2bf9fe2d2c348d53c")
  (:FILE "src/series/query.lisp" :MD5 "cb0d91405325b508e6b2ab24d178de7a")
  (:FILE "src/series/retirement.lisp" :MD5 "b8e04971b8ad75a1bd0c722997badfd2")
  (:FILE "src/series/routing-build.lisp" :MD5
   "d6924deff152b941bd49f0bb200b4197")
  (:FILE "src/series/routing-select.lisp" :MD5
   "e0f987d8767744050ec4d1b3ecb699ed")
  (:FILE "src/series/routing-types.lisp" :MD5
   "ce649df47dd38888d5103c98345f7e41")
  (:FILE "src/series/types.lisp" :MD5 "ab19ec8d15af91511e817858c41cebc8")
  (:FILE "src/series/worker-boundary.lisp" :MD5
   "2340e0c9074f7b1bf80c74f774986bc5")
  (:FILE "src/series/worker-package.lisp" :MD5
   "a93ce2e84e8aee647b5083ad1d2b899b")
  (:FILE "src/series/worker-run.lisp" :MD5 "f0fee18adf357bad98e8a3c3e8c70c0c")
  (:FILE "src/series/worker-types.lisp" :MD5
   "2b23d468be0165fa009c5ebd5d1bbe23")
  (:FILE "src/storage/compaction-scan.lisp" :MD5
   "1cda77a357ab2147035993b72d135a37")
  (:FILE "src/storage/control-payload.lisp" :MD5
   "cb64f806b8d69eb42d865b4abfff0b27")
  (:FILE "src/storage/formats.lisp" :MD5 "061147be459d8d3b08c661bd3f91d152")
  (:FILE "src/storage/log-header.lisp" :MD5 "b53d27dcc9f4badf18b50519c50bc614")
  (:FILE "src/storage/package.lisp" :MD5 "f86bd104f20616a76b42c02227f72844")
  (:FILE "src/storage/payload-record.lisp" :MD5
   "8c03f9c01dcb30f2d3970a5694968ecf")
  (:FILE "src/storage/payload-write.lisp" :MD5
   "c4ece3c4fa8d9492d2a80df7c0a4f5a0")
  (:FILE "src/storage/segment-header.lisp" :MD5
   "d6812fa59bf8fd1252fbf85a9bfa3896")
  (:FILE "src/wal/builder.lisp" :MD5 "a229f76f7036f3573a6e528dcd390a19")
  (:FILE "src/wal/csn.lisp" :MD5 "42b990e3b254e6fb488c0ab91b6a6502")
  (:FILE "src/wal/executor.lisp" :MD5 "c0340924c9130e14d0e8efedeec078f1")
  (:FILE "src/wal/group.lisp" :MD5 "7a0e7c99ab70b4720cbb091156560f5e")
  (:FILE "src/wal/package.lisp" :MD5 "96c41b1d417135a24fc65659ea3abe11")
  (:FILE "src/wal/types.lisp" :MD5 "f799f27a8ac1a4c736c04796c1e543f9")
  (:FILE "tests/foundation/support.lisp" :MD5
   "758adad069aec2f9dbe0635797314ff6")
  (:FILE "tests/get-directory/support.lisp" :MD5
   "3f868ebe4307ad4238b314c37eceed9a")
  (:FILE "tests/get-directory/construction.lisp" :MD5
   "1137938073e71d6d8d62c751fbad05d5")
  (:FILE "tests/get-directory/read.lisp" :MD5
   "d1ab36d05cc1266e4533d27c693f12f4")
  (:FILE "tests/get-directory/threads.lisp" :MD5
   "63dd01c852de1399c2c82274d481d257")
  (:FILE "tests/get-directory/series-support.lisp" :MD5
   "8d7ed4f8d3f9e8394b15c648a3a4507b")
  (:FILE "tests/get-directory/series-read.lisp" :MD5
   "3e565b431b88fb5211023601b5e3ce3b")
  (:FILE "tools/get-series-mutation.lisp" :MD5
   "2068edb227d28b9e53c4eecc125fca54")))
