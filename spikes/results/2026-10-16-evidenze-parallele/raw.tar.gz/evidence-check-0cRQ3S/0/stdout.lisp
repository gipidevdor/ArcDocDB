(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-U4zCh4/case-12-invalid-leaf-11/input/2026-10-16-00/catalogo.lisp"
 :STATUS :FAILED :DIAGNOSTIC "Evidenza non valida: ...")
