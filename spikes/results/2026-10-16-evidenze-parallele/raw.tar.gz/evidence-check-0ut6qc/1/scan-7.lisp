(:SCHEMA-VERSION 1 :KIND :PROCESS-SNAPSHOT :COMMAND ("ps" "-axo" "pid=")
 :EXIT-CODE 0 :SIGNAL NIL :STDOUT
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/tools/../spikes/out/evidence-check-0ut6qc/1/scan-7.stdout.log"
 :STDERR
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/tools/../spikes/out/evidence-check-0ut6qc/1/scan-7.stderr.log")