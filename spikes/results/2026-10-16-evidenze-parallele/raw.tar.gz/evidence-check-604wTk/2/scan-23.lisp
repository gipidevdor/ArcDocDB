(:SCHEMA-VERSION 1 :KIND :PROCESS-SNAPSHOT :COMMAND ("ps" "-axo" "pid=")
 :EXIT-CODE 0 :SIGNAL NIL :STDOUT
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/tools/../spikes/out/evidence-check-604wTk/2/scan-23.stdout.log"
 :STDERR
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/tools/../spikes/out/evidence-check-604wTk/2/scan-23.stderr.log")