(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-XhzTXd/case-19-missing-artifact/input/2026-10-16-00/catalogo.lisp"
 :STATUS :FAILED :DIAGNOSTIC
 "Evidenza non valida: /Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-XhzTXd/case-19-missing-artifact/input/2026-10-16-00/catalogo.lisp.")
