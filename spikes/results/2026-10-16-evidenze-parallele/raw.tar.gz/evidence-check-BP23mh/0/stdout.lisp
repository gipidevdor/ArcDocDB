(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-s2MlGJ/case-15-invalid-leaf-14/input/2026-10-16-00/catalogo.lisp"
 :STATUS :FAILED :DIAGNOSTIC "Evidenza non valida: sub\\file.lisp.")
