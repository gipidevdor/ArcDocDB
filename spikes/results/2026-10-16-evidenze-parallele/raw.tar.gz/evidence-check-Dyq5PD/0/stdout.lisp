(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-9jdqsQ/case-29-compressed-hash/input/2026-10-16/catalogo.lisp"
 :STATUS :FAILED :DIAGNOSTIC
 "Evidenza non valida /Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-9jdqsQ/case-29-compressed-hash/input/2026-10-16/artifact.lisp: SHA256 del PAYLOAD diverso da COMPRESSED-SHA256.")
