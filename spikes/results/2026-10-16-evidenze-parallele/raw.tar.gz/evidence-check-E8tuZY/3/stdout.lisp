(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 #A((190) BASE-CHAR
    . "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-qfz1vx/case-35-worker-protocol-duplicate-key/input/2026-10-16-03/catalogo.lisp")
 :STATUS :OK :ARTIFACT-REFERENCES 6 :STATUS :OK)
