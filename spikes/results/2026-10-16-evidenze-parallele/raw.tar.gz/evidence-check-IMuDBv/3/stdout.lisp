(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-XhzTXd/case-37-process-bound-four/input/2026-10-16-03/catalogo.lisp"
 :STATUS :OK :ARTIFACT-REFERENCES 6)
