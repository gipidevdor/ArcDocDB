(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-XhzTXd/case-36-process-bound-two/input/2026-10-16-00/catalogo.lisp"
 :STATUS :OK :ARTIFACT-REFERENCES 6)
