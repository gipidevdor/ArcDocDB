(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-qfz1vx/case-25-trailing/input/2026-10-16-00/catalogo.lisp"
 :STATUS :FAILED :DIAGNOSTIC
 "Evidenza non valida /Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-qfz1vx/case-25-trailing/input/2026-10-16-00/artifact.lisp: Il file contiene più di una forma Lisp.")
