(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 #A((186) BASE-CHAR
    . "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-U4zCh4/case-34-worker-protocol-extra-key/input/2026-10-16-01/catalogo.lisp")
 :STATUS :OK :ARTIFACT-REFERENCES 6 :UNEXPECTED-KEY 0)
