(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-U4zCh4/case-21-artifact-schema/input/2026-10-16-00/catalogo.lisp"
 :STATUS :FAILED :DIAGNOSTIC
 "Evidenza non valida: /Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-U4zCh4/case-21-artifact-schema/input/2026-10-16-00/artifact.lisp.")
