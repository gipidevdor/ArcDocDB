(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-U4zCh4/case-28-compressed-positive/input/2026-10-16/catalogo.lisp"
 :STATUS :OK :ARTIFACT-REFERENCES 6)
