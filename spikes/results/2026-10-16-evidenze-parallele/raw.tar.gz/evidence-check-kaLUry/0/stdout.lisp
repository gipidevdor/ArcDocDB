(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-XhzTXd/case-16-invalid-leaf-15/input/2026-10-16-00/catalogo.lisp"
 :STATUS :FAILED :DIAGNOSTIC "Evidenza non valida: 7.")
