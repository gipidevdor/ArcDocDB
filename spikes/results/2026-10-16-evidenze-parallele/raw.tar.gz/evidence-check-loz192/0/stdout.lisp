(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/out/evidence-parallel-self-test-9jdqsQ/case-13-invalid-leaf-12/input/2026-10-16-00/catalogo.lisp"
 :STATUS :FAILED :DIAGNOSTIC "Evidenza non valida: ../escape.lisp.")
