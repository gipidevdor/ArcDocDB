(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/results/2026-10-09-cbor-header/catalogo.lisp"
 :STATUS :OK :ARTIFACT-REFERENCES 38)
