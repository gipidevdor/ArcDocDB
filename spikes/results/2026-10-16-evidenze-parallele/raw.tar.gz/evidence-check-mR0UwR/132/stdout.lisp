(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/results/2026-10-15-nntp-direction/catalogo.lisp"
 :STATUS :OK :ARTIFACT-REFERENCES 4)
