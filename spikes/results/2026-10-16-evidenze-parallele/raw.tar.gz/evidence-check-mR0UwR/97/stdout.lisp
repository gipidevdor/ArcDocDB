(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/command-archive-collector/ArcDocDB/spikes/results/2026-10-14-active-recovery/catalogo.lisp"
 :STATUS :OK :ARTIFACT-REFERENCES 37)
