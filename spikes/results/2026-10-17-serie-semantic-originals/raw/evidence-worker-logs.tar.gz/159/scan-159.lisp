(:SCHEMA-VERSION 1 :KIND :PROCESS-SNAPSHOT :COMMAND ("ps" "-axo" "pid=")
 :EXIT-CODE 0 :SIGNAL NIL :STDOUT
 "/Users/gpicchiarelli/.codex/worktrees/serie-semantic-recovery/ArcDocDB/tools/../spikes/out/evidence-check-e9F1Wq/159/scan-159.stdout.log"
 :STDERR
 "/Users/gpicchiarelli/.codex/worktrees/serie-semantic-recovery/ArcDocDB/tools/../spikes/out/evidence-check-e9F1Wq/159/scan-159.stderr.log")