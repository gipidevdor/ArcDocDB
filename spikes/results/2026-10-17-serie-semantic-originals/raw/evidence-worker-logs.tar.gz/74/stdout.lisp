(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/serie-semantic-recovery/ArcDocDB/spikes/results/2026-10-13-active-init/catalogo.lisp"
 :STATUS :OK :ARTIFACT-REFERENCES 48)
