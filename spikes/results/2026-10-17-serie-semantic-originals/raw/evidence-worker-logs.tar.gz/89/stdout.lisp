(:SCHEMA-VERSION 1 :KIND :EVIDENCE-CATALOG-CHECK :CATALOG
 "/Users/gpicchiarelli/.codex/worktrees/serie-semantic-recovery/ArcDocDB/spikes/results/2026-10-13-get-fonti-serie/catalogo.lisp"
 :STATUS :OK :ARTIFACT-REFERENCES 217)
