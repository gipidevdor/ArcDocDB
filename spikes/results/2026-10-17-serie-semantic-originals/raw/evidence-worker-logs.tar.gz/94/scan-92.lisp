(:SCHEMA-VERSION 1 :KIND :PROCESS-SNAPSHOT :COMMAND ("ps" "-axo" "pid=")
 :EXIT-CODE 0 :SIGNAL NIL :STDOUT
 "/Users/gpicchiarelli/.codex/worktrees/serie-semantic-recovery/ArcDocDB/tools/../spikes/out/evidence-check-e9F1Wq/94/scan-92.stdout.log"
 :STDERR
 "/Users/gpicchiarelli/.codex/worktrees/serie-semantic-recovery/ArcDocDB/tools/../spikes/out/evidence-check-e9F1Wq/94/scan-92.stderr.log")