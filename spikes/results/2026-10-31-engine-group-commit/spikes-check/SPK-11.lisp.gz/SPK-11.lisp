(:SCHEMA-VERSION 1 :ID "SPK-11" :COMMAND
 (#A((48) BASE-CHAR . "/opt/homebrew/Cellar/sbcl/2.6.9/libexec/bin/sbcl")
  "--dynamic-space-size" "4096" "--noinform" "--no-userinit" "--no-sysinit"
  "--script" "spikes/SPK-11-unix-socket/run.lisp"
  #A((7) BASE-CHAR . "--check"))
 :EXIT-CODE 0 :STARTED-AT-UNIVERSAL-TIME 4002475963 :FINISHED-AT-UNIVERSAL-TIME
 4002475973 :WALL-SECONDS 9.737351d0 :STATUS :OK :SOURCE-BLOBS-BEFORE
 ((:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH #A((35) BASE-CHAR . "spikes/SPK-11-unix-socket/core.lisp") :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf"))
 :SOURCE-BLOBS-AFTER
 ((:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH #A((35) BASE-CHAR . "spikes/SPK-11-unix-socket/core.lisp") :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf"))
 :SOURCE-CONSISTENCY :STABLE :RESULT
 (:STATUS :OK :SPIKE :SPK-11 :FRAMING
  (:STATUS :OK :SPLIT-POINTS 21 :INVALID-LENGTHS 3 :TRUNCATED-PREFIX-OR-BODY 9
   :MAXIMUM-FRAME-BYTES 17825792 :ORACLE-NEGATIVE-CONTROLS 3)
  :SESSION
  (:STATUS :OK :CASES
   ((:CASE #A((18) BASE-CHAR . "CHECK-SESSION-WIRE") :STATUS :OK)
    (:CASE #A((18) BASE-CHAR . "CHECK-SESSION-MAPS") :STATUS :OK)
    (:CASE #A((25) BASE-CHAR . "CHECK-SESSION-NEGOTIATION") :STATUS :OK)
    (:CASE #A((20) BASE-CHAR . "CHECK-SESSION-CREDIT") :STATUS :OK)
    (:CASE #A((25) BASE-CHAR . "CHECK-SESSION-CORRELATION") :STATUS :OK)
    (:CASE #A((18) BASE-CHAR . "CHECK-SESSION-TIME") :STATUS :OK)
    (:CASE #A((23) BASE-CHAR . "CHECK-SESSION-ISOLATION") :STATUS :OK)
    (:CASE #A((25) BASE-CHAR . "CHECK-SESSION-SENSITIVITY") :STATUS :OK))
   :SENSITIVITY-CONTROLS 4 :PROFILE-BYTES 4096 :LIMITS
   (:C4-MODEL :SIMULATED-GATE-AND-CLOCK :NO-ENGINE
    :NO-PRODUCTION-ALLOCATION-CLAIM))
  :NATIVE-IO
  (:STATUS :OK :SCRIPTS
   (:STATUS :OK :SHORT-AND-RETRY T :PREFLIGHT-AND-DEADLINES T :TERMINAL-ERRORS
    T :INVALID-RESULTS T :ORACLE-NEGATIVE-CONTROLS 4)
   :EMPTY-AND-CLOSED
   (:STATUS :OK :EMPTY-ERRNO 35 :CLOSED-ERRNO 32 :SIGPIPE-SURVIVED T)
   :SATURATION
   (:STATUS :OK :CONFIRMED-BYTES 4096 :CALLS 2 :ERRNO 35 :STATE :ACTIVE)
   :ALLOCATION
   (:STATUS :OK :ITERATIONS 4096 :SUCCESS-BEFORE 420881728 :SUCCESS-AFTER
    420881728 :SUCCESS-BYTES-CONSED 0 :EMPTY-BEFORE 420881728 :EMPTY-AFTER
    420881728 :EMPTY-BYTES-CONSED 0 :POSITIVE-CONTROL-PAYLOAD 2097152
    :POSITIVE-BEFORE 420881728 :POSITIVE-MINIMUM-DETECTED 1048576
    :POSITIVE-AFTER 422935696 :POSITIVE-BYTES-CONSED 2053968
    :NATIVE-ALLOCATOR-TRACED NIL)
   :DISASSEMBLY
   ((:FUNCTION #A((16) BASE-CHAR . "NATIVE-RECV-SPAN") :CODE
     "; disassembly for ARCDOCDB.SPK11::NATIVE-RECV-SPAN
; Size: 360 bytes. Origin: #x801267C698                       ; ARCDOCDB.SPK11::NATIVE-RECV-SPAN
; 698:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; 69C:       AA0F00F9         STR R0, [CFP, #24]
; 6A0:       ADEA40F9         LDR R3, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 6A4:       693F0091         ADD TMP, CSP, #15
; 6A8:       29ED7C92         AND TMP, TMP, #18446744073709551600
; 6AC:       3B410091         ADD CSP, TMP, #16
; 6B0:       2C1D0091         ADD R2, TMP, #7
; 6B4:       AB1740F9         LDR R1, [CFP, #40]
; 6B8:       2B3500A9         STP R1, R3, [TMP]
; 6BC:       A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 6C0:       20400091         ADD NL0, NL1, #16
; 6C4:       A00A00F9         STR NL0, [THREAD, #16]          ; binding-stack-pointer
; 6C8:       003A80D2         MOVZ NL0, #464
; 6CC:       AAEA40F9         LDR R0, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 6D0:       2A0000A9         STP R0, NL0, [NL1]
; 6D4:       AC6A20F8         STR R2, [THREAD, NL0]
; 6D8:       AA1740F9         LDR R0, [CFP, #40]
; 6DC:       41050091         ADD NL1, R0, #1
; 6E0:       A01B40F9         LDR NL0, [CFP, #48]
; 6E4:       00FC4193         ASR NL0, NL0, #1
; 6E8:       2100008B         ADD NL1, NL1, NL0
; 6EC:       AA1340F9         LDR R0, [CFP, #32]
; 6F0:       AD1F40F9         LDR R3, [CFP, #56]
; 6F4:       041080D2         MOVZ NL4, #128
; 6F8:       40FD4193         ASR NL0, R0, #1
; 6FC:       A2FD4193         ASR NL2, R3, #1
; 700:       E30304AA         MOV NL3, NL4
; 704:       74430091         ADD R10, CSP, #16
; 708:       D6010010         ADR LEXENV, L0
; 70C:       7D5B00A9         STP CFP, LEXENV, [CSP]
; 710:       BB5210A9         STP CSP, R10, [THREAD, #256]    ; control-frame-pointer, control-stack-pointer
; 714:       B3F7FF58         LDR R9, #x801267C608            ; recv
; 718:       60023FD6         BLR R9
; 71C:       110080D2         MOVZ R7, #0
; 720:       100080D2         MOVZ R6, #0
; 724:       0F0080D2         MOVZ R5, #0
; 728:       0E0080D2         MOVZ R4, #0
; 72C:       0D0080D2         MOVZ R3, #0
; 730:       0C0080D2         MOVZ R2, #0
; 734:       0B0080D2         MOVZ R1, #0
; 738:       0A0080D2         MOVZ R0, #0
; 73C:       BF8600F9         STR ZR, [THREAD, #264]          ; control-stack-pointer
; 740: L0:   0C0000AB         ADDS R2, NL0, NL0
; 744:       E7010054         BVC L2
; 748:       BA2A00B9         STR WNULL, [THREAD, #40]        ; pseudo-atomic-bits
; 74C:       A97A47A9         LDP TMP, LR, [THREAD, #112]     ; mixed-tlab.{free-pointer, end-addr}
; 750:       2C410091         ADD R2, TMP, #16
; 754:       9F011EEB         CMP R2, LR
; 758:       C8040054         BHI L5
; 75C:       AC3A00F9         STR R2, [THREAD, #112]          ; mixed-tlab
; 760: L1:   2C3D0091         ADD R2, TMP, #15
; 764:       3E2280D2         MOVZ LR, #273
; 768:       3E0100A9         STP LR, NL0, [TMP]
; 76C:       BF3A03D5         DMB ISHST
; 770:       BF2A00B9         STR WZR, [THREAD, #40]          ; pseudo-atomic-bits
; 774:       BE2E40B9         LDR WLR, [THREAD, #44]          ; pseudo-atomic-bits
; 778:       5E0000B4         CBZ LR, L2
; 77C:       200120D4         BRK #9                          ; Pending interrupt trap
; 780: L2:   9F0900B1         CMN R2, #2
; 784:       01030054         BNE L4
; 788:       AC2300F9         STR R2, [CFP, #64]
; 78C:       7D0300F9         STR CFP, [CSP]
; 790:       96F2FF58         LDR LEXENV, #x801267C5E0        ; #<SB-KERNEL:FDEFN GET-ERRNO>
; 794:       170080D2         MOVZ NARGS, #0
; 798:       DE9240F8         LDR LR, [LEXENV, #9]
; 79C:       FD031BAA         MOV CFP, CSP
; 7A0:       C0033FD6         BLR LR
; 7A4:       AC2340F9         LDR R2, [CFP, #64]
; 7A8:       EB030AAA         MOV R1, R0
; 7AC: L3:   A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 7B0:       2A007FA9         LDP R0, NL0, [NL1, #-16]
; 7B4:       AA6A20F8         STR R0, [THREAD, NL0]
; 7B8:       3F7CBFA9         STP ZR, ZR, [NL1, #-16]!
; 7BC:       A10A00F9         STR NL1, [THREAD, #16]          ; binding-stack-pointer
; 7C0:       EA030CAA         MOV R0, R2
; 7C4:       F9031DAA         MOV OCFP, CFP
; 7C8:       3B430091         ADD CSP, OCFP, #16
; 7CC:       970080D2         MOVZ NARGS, #4
; 7D0:       EC031AAA         MOV R2, NULL
; 7D4:       ED031AAA         MOV R3, NULL
; 7D8:       FF031FEB         CMP ZR, ZR
; 7DC:       BD7B40A9         LDP CFP, LR, [CFP]
; 7E0:       C0035FD6         RET
; 7E4: L4:   0B0080D2         MOVZ R1, #0
; 7E8:       F1FFFF17         B L3
; 7EC:       E00120D4         BRK #15                         ; Invalid argument count trap
; 7F0: L5:   090280D2         MOVZ TMP, #16
; 7F4:       ECF0FF58         LDR R2, #x801267C610            ; SB-VM::ALLOC-TRAMP
; 7F8:       80013FD6         BLR R2
; 7FC:       D9FFFF17         B L1
")
    (:FUNCTION #A((16) BASE-CHAR . "NATIVE-SEND-SPAN") :CODE
     "; disassembly for ARCDOCDB.SPK11::NATIVE-SEND-SPAN
; Size: 364 bytes. Origin: #x8012677818                       ; ARCDOCDB.SPK11::NATIVE-SEND-SPAN
; 818:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; 81C:       AA0F00F9         STR R0, [CFP, #24]
; 820:       ADEA40F9         LDR R3, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 824:       693F0091         ADD TMP, CSP, #15
; 828:       29ED7C92         AND TMP, TMP, #18446744073709551600
; 82C:       3B410091         ADD CSP, TMP, #16
; 830:       2C1D0091         ADD R2, TMP, #7
; 834:       AB1740F9         LDR R1, [CFP, #40]
; 838:       2B3500A9         STP R1, R3, [TMP]
; 83C:       A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 840:       20400091         ADD NL0, NL1, #16
; 844:       A00A00F9         STR NL0, [THREAD, #16]          ; binding-stack-pointer
; 848:       003A80D2         MOVZ NL0, #464
; 84C:       AAEA40F9         LDR R0, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 850:       2A0000A9         STP R0, NL0, [NL1]
; 854:       AC6A20F8         STR R2, [THREAD, NL0]
; 858:       AA1740F9         LDR R0, [CFP, #40]
; 85C:       41050091         ADD NL1, R0, #1
; 860:       A01B40F9         LDR NL0, [CFP, #48]
; 864:       00FC4193         ASR NL0, NL0, #1
; 868:       2100008B         ADD NL1, NL1, NL0
; 86C:       AA1340F9         LDR R0, [CFP, #32]
; 870:       AD1F40F9         LDR R3, [CFP, #56]
; 874:       E4036DB2         MOV NL4, #524288
; 878:       041080F2         MOVK NL4, #128
; 87C:       40FD4193         ASR NL0, R0, #1
; 880:       A2FD4193         ASR NL2, R3, #1
; 884:       E30304AA         MOV NL3, NL4
; 888:       74430091         ADD R10, CSP, #16
; 88C:       D6010010         ADR LEXENV, L0
; 890:       7D5B00A9         STP CFP, LEXENV, [CSP]
; 894:       BB5210A9         STP CSP, R10, [THREAD, #256]    ; control-frame-pointer, control-stack-pointer
; 898:       93F7FF58         LDR R9, #x8012677788            ; send
; 89C:       60023FD6         BLR R9
; 8A0:       110080D2         MOVZ R7, #0
; 8A4:       100080D2         MOVZ R6, #0
; 8A8:       0F0080D2         MOVZ R5, #0
; 8AC:       0E0080D2         MOVZ R4, #0
; 8B0:       0D0080D2         MOVZ R3, #0
; 8B4:       0C0080D2         MOVZ R2, #0
; 8B8:       0B0080D2         MOVZ R1, #0
; 8BC:       0A0080D2         MOVZ R0, #0
; 8C0:       BF8600F9         STR ZR, [THREAD, #264]          ; control-stack-pointer
; 8C4: L0:   0C0000AB         ADDS R2, NL0, NL0
; 8C8:       E7010054         BVC L2
; 8CC:       BA2A00B9         STR WNULL, [THREAD, #40]        ; pseudo-atomic-bits
; 8D0:       A97A47A9         LDP TMP, LR, [THREAD, #112]     ; mixed-tlab.{free-pointer, end-addr}
; 8D4:       2C410091         ADD R2, TMP, #16
; 8D8:       9F011EEB         CMP R2, LR
; 8DC:       C8040054         BHI L5
; 8E0:       AC3A00F9         STR R2, [THREAD, #112]          ; mixed-tlab
; 8E4: L1:   2C3D0091         ADD R2, TMP, #15
; 8E8:       3E2280D2         MOVZ LR, #273
; 8EC:       3E0100A9         STP LR, NL0, [TMP]
; 8F0:       BF3A03D5         DMB ISHST
; 8F4:       BF2A00B9         STR WZR, [THREAD, #40]          ; pseudo-atomic-bits
; 8F8:       BE2E40B9         LDR WLR, [THREAD, #44]          ; pseudo-atomic-bits
; 8FC:       5E0000B4         CBZ LR, L2
; 900:       200120D4         BRK #9                          ; Pending interrupt trap
; 904: L2:   9F0900B1         CMN R2, #2
; 908:       01030054         BNE L4
; 90C:       AC2300F9         STR R2, [CFP, #64]
; 910:       7D0300F9         STR CFP, [CSP]
; 914:       76F2FF58         LDR LEXENV, #x8012677760        ; #<SB-KERNEL:FDEFN GET-ERRNO>
; 918:       170080D2         MOVZ NARGS, #0
; 91C:       DE9240F8         LDR LR, [LEXENV, #9]
; 920:       FD031BAA         MOV CFP, CSP
; 924:       C0033FD6         BLR LR
; 928:       AC2340F9         LDR R2, [CFP, #64]
; 92C:       EB030AAA         MOV R1, R0
; 930: L3:   A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 934:       2A007FA9         LDP R0, NL0, [NL1, #-16]
; 938:       AA6A20F8         STR R0, [THREAD, NL0]
; 93C:       3F7CBFA9         STP ZR, ZR, [NL1, #-16]!
; 940:       A10A00F9         STR NL1, [THREAD, #16]          ; binding-stack-pointer
; 944:       EA030CAA         MOV R0, R2
; 948:       F9031DAA         MOV OCFP, CFP
; 94C:       3B430091         ADD CSP, OCFP, #16
; 950:       970080D2         MOVZ NARGS, #4
; 954:       EC031AAA         MOV R2, NULL
; 958:       ED031AAA         MOV R3, NULL
; 95C:       FF031FEB         CMP ZR, ZR
; 960:       BD7B40A9         LDP CFP, LR, [CFP]
; 964:       C0035FD6         RET
; 968: L4:   0B0080D2         MOVZ R1, #0
; 96C:       F1FFFF17         B L3
; 970:       E00120D4         BRK #15                         ; Invalid argument count trap
; 974: L5:   090280D2         MOVZ TMP, #16
; 978:       CCF0FF58         LDR R2, #x8012677790            ; SB-VM::ALLOC-TRAMP
; 97C:       80013FD6         BLR R2
; 980:       D9FFFF17         B L1
")
    (:FUNCTION #A((7) BASE-CHAR . "IO-STEP") :CODE
     "; disassembly for ARCDOCDB.SPK11::IO-STEP
; Size: 468 bytes. Origin: #x801267B600                       ; ARCDOCDB.SPK11::IO-STEP
; 600:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; 604:       AA0F00F9         STR R0, [CFP, #24]
; 608:       EED146F8         LDR R4, [R5, #109]
; 60C:       EAF9FF58         LDR R0, #x801267B548            ; :ACTIVE
; 610:       DF010AEB         CMP R4, R0
; 614:       C0000054         BEQ L1
; 618:       EAD146F8         LDR R0, [R5, #109]
; 61C: L0:   FB031DAA         MOV CSP, CFP
; 620:       5F0300F1         CMP NULL, #0
; 624:       BD7B40A9         LDP CFP, LR, [CFP]
; 628:       C0035FD6         RET
; 62C: L1:   E15144F8         LDR NL1, [R5, #69]
; 630:       A01340F9         LDR NL0, [CFP, #32]
; 634:       1F0001EB         CMP NL0, NL1
; 638:       4AE30091         ADD R0, NULL, #56               ; T
; 63C:       4AB38A9A         CSEL R0, NULL, R0, LT
; 640:       AF1700F9         STR R5, [CFP, #40]
; 644:       7D0300F9         STR CFP, [CSP]
; 648:       4BF8FF58         LDR R1, #x801267B550            ; :IO-CLOCK
; 64C:       B6F6FF58         LDR LEXENV, #x801267B520        ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::DEMAND>
; 650:       970080D2         MOVZ NARGS, #4
; 654:       DE9240F8         LDR LR, [LEXENV, #9]
; 658:       FD031BAA         MOV CFP, CSP
; 65C:       C0033FD6         BLR LR
; 660:       3B039B9A         CSEL CSP, OCFP, CSP, EQ
; 664:       AF1740F9         LDR R5, [CFP, #40]
; 668:       AB1340F9         LDR R1, [CFP, #32]
; 66C:       EB5104F8         STR R1, [R5, #69]
; 670:       E1D143F8         LDR NL1, [R5, #61]
; 674:       A01340F9         LDR NL0, [CFP, #32]
; 678:       1F0001EB         CMP NL0, NL1
; 67C:       8A090054         BGE L7
; 680:       E25143F8         LDR NL2, [R5, #53]
; 684:       E35142F8         LDR NL3, [R5, #37]
; 688:       E15145F8         LDR NL1, [R5, #85]
; 68C:       610001CB         SUB NL1, NL3, NL1
; 690:       3F0002EB         CMP NL1, NL2
; 694:       21B0829A         CSEL NL1, NL1, NL2, LT
; 698:       E20301AA         MOV NL2, NL1
; 69C:       EED144F8         LDR R4, [R5, #77]
; 6A0:       AE061037         TBNZ WR4, #2, L5
; 6A4:       F6030EAA         MOV LEXENV, R4
; 6A8: L2:   AF8B02A9         STP R5, NL2, [CFP, #40]
; 6AC:       E1D145F8         LDR NL1, [R5, #93]
; 6B0:       210800B1         ADDS NL1, NL1, #2
; 6B4:       A6080054         BVS L8
; 6B8:       E1D105F8         STR NL1, [R5, #93]
; 6BC:       EAD140F8         LDR R0, [R5, #13]
; 6C0:       EB5141F8         LDR R1, [R5, #21]
; 6C4:       EC5145F8         LDR R2, [R5, #85]
; 6C8:       7D0300F9         STR CFP, [CSP]
; 6CC:       ED0302AA         MOV R3, NL2
; 6D0:       170180D2         MOVZ NARGS, #8
; 6D4:       DED25FF8         LDR LR, [LEXENV, #-3]
; 6D8:       FD031BAA         MOV CFP, CSP
; 6DC:       C0033FD6         BLR LR
; 6E0:       4B138B9A         CSEL R1, NULL, R1, NE
; 6E4:       3B039B9A         CSEL CSP, OCFP, CSP, EQ
; 6E8:       AF8B42A9         LDP R5, NL2, [CFP, #40]
; 6EC:       F0030AAA         MOV R6, R0
; 6F0:       EE030BAA         MOV R4, R1
; 6F4:       F0000036         TBZ WR6, #0, L3
; 6F8:       010E4092         AND NL1, R6, #15
; 6FC:       3F3C00F1         CMP NL1, #15
; 700:       C1010054         BNE L4
; 704:       01125FF8         LDR NL1, [R6, #-15]
; 708:       3F4404F1         CMP NL1, #273
; 70C:       61010054         BNE L4
; 710: L3:   4E010037         TBNZ WR4, #0, L4
; 714:       EA030FAA         MOV R0, R5
; 718:       EB0310AA         MOV R1, R6
; 71C:       EC030EAA         MOV R2, R4
; 720:       ED0302AA         MOV R3, NL2
; 724:       36F0FF58         LDR LEXENV, #x801267B528        ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::IO-RESULT>
; 728:       170180D2         MOVZ NARGS, #8
; 72C:       DE9240F8         LDR LR, [LEXENV, #9]
; 730:       DE130091         ADD LR, LR, #4
; 734:       C0031FD6         BR LR
; 738: L4:   AF1700F9         STR R5, [CFP, #40]
; 73C:       EAF0FF58         LDR R0, #x801267B558            ; :FAULTED
; 740:       E97D4BD3         UBFM TMP, R5, #11, #31
; 744:       9F6B2938         STRB WZR, [CARDTABLE, TMP]
; 748:       EAD106F8         STR R0, [R5, #109]
; 74C:       7D0300F9         STR CFP, [CSP]
; 750:       8AF0FF58         LDR R0, #x801267B560            ; 'ARCDOCDB.SPK11::REJECTION
; 754:       ABF0FF58         LDR R1, #x801267B568            ; :REASON
; 758:       CCF0FF58         LDR R2, #x801267B570            ; :IO-RESULT
; 75C:       29A680D2         MOVZ TMP, #1329
; 760:       5E6B69F8         LDR LR, [NULL, TMP]             ; ERROR
; 764:       D70080D2         MOVZ NARGS, #6
; 768:       FD031BAA         MOV CFP, CSP
; 76C:       C0033FD6         BLR LR
; 770:       AF1740F9         LDR R5, [CFP, #40]
; 774: L5:   EED142F8         LDR R4, [R5, #45]
; 778:       0AF0FF58         LDR R0, #x801267B578            ; :INPUT
; 77C:       DF010AEB         CMP R4, R0
; 780:       C0000054         BEQ L6
; 784:       6AEDFF58         LDR R0, #x801267B530            ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::NATIVE-SEND-SPAN>
; 788:       561140F8         LDR LEXENV, [R0, #1]
; 78C:       DF021AEB         CMP LEXENV, NULL
; 790:       E0010054         BEQ L9
; 794:       C5FFFF17         B L2
; 798: L6:   0AEDFF58         LDR R0, #x801267B538            ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::NATIVE-RECV-SPAN>
; 79C:       561140F8         LDR LEXENV, [R0, #1]
; 7A0:       DF021AEB         CMP LEXENV, NULL
; 7A4:       60010054         BEQ L10
; 7A8:       C0FFFF17         B L2
; 7AC: L7:   AAEEFF58         LDR R0, #x801267B580            ; :EXPIRED
; 7B0:       E97D4BD3         UBFM TMP, R5, #11, #31
; 7B4:       9F6B2938         STRB WZR, [CARDTABLE, TMP]
; 7B8:       EAD106F8         STR R0, [R5, #109]
; 7BC:       2AEEFF58         LDR R0, #x801267B580            ; :EXPIRED
; 7C0:       97FFFF17         B L0
; 7C4:       E00120D4         BRK #15                         ; Invalid argument count trap
; 7C8: L8:   A02520D4         BRK #301                        ; ADD-SUB-OVERFLOW-ERROR
                                                              ; NL1
; 7CC: L9:   204221D4         BRK #2577                       ; UNDEFINED-FUN-ERROR
                                                              ; R0
; 7D0: L10:  204221D4         BRK #2577                       ; UNDEFINED-FUN-ERROR
                                                              ; R0
")))
  :PROCESSES
  ((:STATUS :OK :MODE "fragmented" :SERVER-PID 60038 :CLIENT-PID 60044 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "fragmented"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
    "(:STATUS :OK :MODE #A((10) BASE-CHAR . \"fragmented\") :PID 60044)
"
    :STDERR "")
   (:STATUS :OK :MODE "coalesced" :SERVER-PID 60038 :CLIENT-PID 60048 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "coalesced"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
    "(:STATUS :OK :MODE #A((9) BASE-CHAR . \"coalesced\") :PID 60048)
"
    :STDERR "")
   (:STATUS :OK :MODE "maximum" :SERVER-PID 60038 :CLIENT-PID 60052 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "maximum"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION 10 :STDOUT
    "(:STATUS :OK :MODE #A((7) BASE-CHAR . \"maximum\") :PID 60052)
"
    :STDERR "")
   (:STATUS :OK :MODE "zero" :SERVER-PID 60038 :CLIENT-PID 60053 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "zero"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
    "(:STATUS :OK :MODE #A((4) BASE-CHAR . \"zero\") :PID 60053)
"
    :STDERR "")
   (:STATUS :OK :MODE "oversize" :SERVER-PID 60038 :CLIENT-PID 60054 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "oversize"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
    "(:STATUS :OK :MODE #A((8) BASE-CHAR . \"oversize\") :PID 60054)
"
    :STDERR "")
   (:STATUS :OK :MODE "truncated" :SERVER-PID 60038 :CLIENT-PID 60055 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "truncated"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
    "(:STATUS :OK :MODE #A((9) BASE-CHAR . \"truncated\") :PID 60055)
"
    :STDERR "")
   (:STATUS :OK :MODE "session" :SERVER-PID 60038 :CLIENT-PID 60056 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "session"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
     2 :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT "(:STATUS :OK :MODE #A((7) BASE-CHAR . \"session\") :PID 60056)
"
    :STDERR "")
   (:STATUS :OK :MODE "session-invalid-hello" :SERVER-PID 60038 :CLIENT-PID
    60057 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "session-invalid-hello"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
     :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((21) BASE-CHAR . \"session-invalid-hello\") :PID 60057)
"
    :STDERR "")
   (:STATUS :OK :MODE "session-pre-hello" :SERVER-PID 60038 :CLIENT-PID 60059
    :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "session-pre-hello"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
     :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((17) BASE-CHAR . \"session-pre-hello\") :PID 60059)
"
    :STDERR "")
   (:STATUS :OK :MODE "session-oversize-hello" :SERVER-PID 60038 :CLIENT-PID
    60060 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "session-oversize-hello"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
     :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((22) BASE-CHAR . \"session-oversize-hello\") :PID 60060)
"
    :STDERR "")
   (:STATUS :OK :MODE "session-id-reuse" :SERVER-PID 60038 :CLIENT-PID 60061
    :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "session-id-reuse"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
     1 :PENDING-AT-CLOSE 1 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((16) BASE-CHAR . \"session-id-reuse\") :PID 60061)
"
    :STDERR "")
   (:STATUS :OK :MODE "native-server" :SERVER-PID 60038 :CLIENT-PID 60062 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "native-server"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :NATIVE-SIDE :SERVER :RESPONSE-ORDER (2 1) :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((13) BASE-CHAR . \"native-server\") :PID 60062)
"
    :STDERR "")
   (:STATUS :OK :MODE "native-client" :SERVER-PID 60038 :CLIENT-PID 60063 :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "native-client"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION
    (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
     2 :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
    :STDOUT
    "(:STATUS :OK :MODE #A((13) BASE-CHAR . \"native-client\") :PID 60063)
"
    :STDERR "")
   (:STATUS :OK :MODE "native-truncated" :SERVER-PID 60038 :CLIENT-PID 60064
    :ARGV
    ("--noinform" "--no-userinit" "--no-sysinit" "--script"
     #A((108) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp")
     "--client" "/tmp/arcdocdb-spk11-z4qN8k/ipc.sock" "native-truncated"
     #A((117) BASE-CHAR
        . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/"))
    :EXIT-CODE 0 :OBSERVATION (:STATUS :OK :CONFIRMED-BYTES 5 :STATE :EOF)
    :STDOUT
    "(:STATUS :OK :MODE #A((16) BASE-CHAR . \"native-truncated\") :PID 60064)
"
    :STDERR ""))
  :NAMESPACE
  (:STATUS :OK :OCCUPIED-NODES (:LISTENER :ORPHAN :FILE :SYMLINK)
   :REPLACEMENT-PRESERVED T)
  :NATIVE-SYMLINK-BIND
  (:BIND-RESULT :BOUND :LINK (16777232 1566737188 41453) :TARGET
   (16777232 1566737189 49645))
  :LIMITS
  (:TRANSPORT-AND-CONTROL-MODEL :NO-ENGINE-ADMISSION :NO-DURABILITY
   :NO-DISTINCT-UID :NO-PERFORMANCE-MEASUREMENT))
 :STDOUT "(:STATUS :OK :SPIKE :SPK-11 :FRAMING
 (:STATUS :OK :SPLIT-POINTS 21 :INVALID-LENGTHS 3 :TRUNCATED-PREFIX-OR-BODY 9
  :MAXIMUM-FRAME-BYTES 17825792 :ORACLE-NEGATIVE-CONTROLS 3)
 :SESSION
 (:STATUS :OK :CASES
  ((:CASE #A((18) BASE-CHAR . \"CHECK-SESSION-WIRE\") :STATUS :OK)
   (:CASE #A((18) BASE-CHAR . \"CHECK-SESSION-MAPS\") :STATUS :OK)
   (:CASE #A((25) BASE-CHAR . \"CHECK-SESSION-NEGOTIATION\") :STATUS :OK)
   (:CASE #A((20) BASE-CHAR . \"CHECK-SESSION-CREDIT\") :STATUS :OK)
   (:CASE #A((25) BASE-CHAR . \"CHECK-SESSION-CORRELATION\") :STATUS :OK)
   (:CASE #A((18) BASE-CHAR . \"CHECK-SESSION-TIME\") :STATUS :OK)
   (:CASE #A((23) BASE-CHAR . \"CHECK-SESSION-ISOLATION\") :STATUS :OK)
   (:CASE #A((25) BASE-CHAR . \"CHECK-SESSION-SENSITIVITY\") :STATUS :OK))
  :SENSITIVITY-CONTROLS 4 :PROFILE-BYTES 4096 :LIMITS
  (:C4-MODEL :SIMULATED-GATE-AND-CLOCK :NO-ENGINE
   :NO-PRODUCTION-ALLOCATION-CLAIM))
 :NATIVE-IO
 (:STATUS :OK :SCRIPTS
  (:STATUS :OK :SHORT-AND-RETRY T :PREFLIGHT-AND-DEADLINES T :TERMINAL-ERRORS T
   :INVALID-RESULTS T :ORACLE-NEGATIVE-CONTROLS 4)
  :EMPTY-AND-CLOSED
  (:STATUS :OK :EMPTY-ERRNO 35 :CLOSED-ERRNO 32 :SIGPIPE-SURVIVED T)
  :SATURATION
  (:STATUS :OK :CONFIRMED-BYTES 4096 :CALLS 2 :ERRNO 35 :STATE :ACTIVE)
  :ALLOCATION
  (:STATUS :OK :ITERATIONS 4096 :SUCCESS-BEFORE 420881728 :SUCCESS-AFTER
   420881728 :SUCCESS-BYTES-CONSED 0 :EMPTY-BEFORE 420881728 :EMPTY-AFTER
   420881728 :EMPTY-BYTES-CONSED 0 :POSITIVE-CONTROL-PAYLOAD 2097152
   :POSITIVE-BEFORE 420881728 :POSITIVE-MINIMUM-DETECTED 1048576
   :POSITIVE-AFTER 422935696 :POSITIVE-BYTES-CONSED 2053968
   :NATIVE-ALLOCATOR-TRACED NIL)
  :DISASSEMBLY
  ((:FUNCTION #A((16) BASE-CHAR . \"NATIVE-RECV-SPAN\") :CODE
    \"; disassembly for ARCDOCDB.SPK11::NATIVE-RECV-SPAN
; Size: 360 bytes. Origin: #x801267C698                       ; ARCDOCDB.SPK11::NATIVE-RECV-SPAN
; 698:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; 69C:       AA0F00F9         STR R0, [CFP, #24]
; 6A0:       ADEA40F9         LDR R3, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 6A4:       693F0091         ADD TMP, CSP, #15
; 6A8:       29ED7C92         AND TMP, TMP, #18446744073709551600
; 6AC:       3B410091         ADD CSP, TMP, #16
; 6B0:       2C1D0091         ADD R2, TMP, #7
; 6B4:       AB1740F9         LDR R1, [CFP, #40]
; 6B8:       2B3500A9         STP R1, R3, [TMP]
; 6BC:       A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 6C0:       20400091         ADD NL0, NL1, #16
; 6C4:       A00A00F9         STR NL0, [THREAD, #16]          ; binding-stack-pointer
; 6C8:       003A80D2         MOVZ NL0, #464
; 6CC:       AAEA40F9         LDR R0, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 6D0:       2A0000A9         STP R0, NL0, [NL1]
; 6D4:       AC6A20F8         STR R2, [THREAD, NL0]
; 6D8:       AA1740F9         LDR R0, [CFP, #40]
; 6DC:       41050091         ADD NL1, R0, #1
; 6E0:       A01B40F9         LDR NL0, [CFP, #48]
; 6E4:       00FC4193         ASR NL0, NL0, #1
; 6E8:       2100008B         ADD NL1, NL1, NL0
; 6EC:       AA1340F9         LDR R0, [CFP, #32]
; 6F0:       AD1F40F9         LDR R3, [CFP, #56]
; 6F4:       041080D2         MOVZ NL4, #128
; 6F8:       40FD4193         ASR NL0, R0, #1
; 6FC:       A2FD4193         ASR NL2, R3, #1
; 700:       E30304AA         MOV NL3, NL4
; 704:       74430091         ADD R10, CSP, #16
; 708:       D6010010         ADR LEXENV, L0
; 70C:       7D5B00A9         STP CFP, LEXENV, [CSP]
; 710:       BB5210A9         STP CSP, R10, [THREAD, #256]    ; control-frame-pointer, control-stack-pointer
; 714:       B3F7FF58         LDR R9, #x801267C608            ; recv
; 718:       60023FD6         BLR R9
; 71C:       110080D2         MOVZ R7, #0
; 720:       100080D2         MOVZ R6, #0
; 724:       0F0080D2         MOVZ R5, #0
; 728:       0E0080D2         MOVZ R4, #0
; 72C:       0D0080D2         MOVZ R3, #0
; 730:       0C0080D2         MOVZ R2, #0
; 734:       0B0080D2         MOVZ R1, #0
; 738:       0A0080D2         MOVZ R0, #0
; 73C:       BF8600F9         STR ZR, [THREAD, #264]          ; control-stack-pointer
; 740: L0:   0C0000AB         ADDS R2, NL0, NL0
; 744:       E7010054         BVC L2
; 748:       BA2A00B9         STR WNULL, [THREAD, #40]        ; pseudo-atomic-bits
; 74C:       A97A47A9         LDP TMP, LR, [THREAD, #112]     ; mixed-tlab.{free-pointer, end-addr}
; 750:       2C410091         ADD R2, TMP, #16
; 754:       9F011EEB         CMP R2, LR
; 758:       C8040054         BHI L5
; 75C:       AC3A00F9         STR R2, [THREAD, #112]          ; mixed-tlab
; 760: L1:   2C3D0091         ADD R2, TMP, #15
; 764:       3E2280D2         MOVZ LR, #273
; 768:       3E0100A9         STP LR, NL0, [TMP]
; 76C:       BF3A03D5         DMB ISHST
; 770:       BF2A00B9         STR WZR, [THREAD, #40]          ; pseudo-atomic-bits
; 774:       BE2E40B9         LDR WLR, [THREAD, #44]          ; pseudo-atomic-bits
; 778:       5E0000B4         CBZ LR, L2
; 77C:       200120D4         BRK #9                          ; Pending interrupt trap
; 780: L2:   9F0900B1         CMN R2, #2
; 784:       01030054         BNE L4
; 788:       AC2300F9         STR R2, [CFP, #64]
; 78C:       7D0300F9         STR CFP, [CSP]
; 790:       96F2FF58         LDR LEXENV, #x801267C5E0        ; #<SB-KERNEL:FDEFN GET-ERRNO>
; 794:       170080D2         MOVZ NARGS, #0
; 798:       DE9240F8         LDR LR, [LEXENV, #9]
; 79C:       FD031BAA         MOV CFP, CSP
; 7A0:       C0033FD6         BLR LR
; 7A4:       AC2340F9         LDR R2, [CFP, #64]
; 7A8:       EB030AAA         MOV R1, R0
; 7AC: L3:   A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 7B0:       2A007FA9         LDP R0, NL0, [NL1, #-16]
; 7B4:       AA6A20F8         STR R0, [THREAD, NL0]
; 7B8:       3F7CBFA9         STP ZR, ZR, [NL1, #-16]!
; 7BC:       A10A00F9         STR NL1, [THREAD, #16]          ; binding-stack-pointer
; 7C0:       EA030CAA         MOV R0, R2
; 7C4:       F9031DAA         MOV OCFP, CFP
; 7C8:       3B430091         ADD CSP, OCFP, #16
; 7CC:       970080D2         MOVZ NARGS, #4
; 7D0:       EC031AAA         MOV R2, NULL
; 7D4:       ED031AAA         MOV R3, NULL
; 7D8:       FF031FEB         CMP ZR, ZR
; 7DC:       BD7B40A9         LDP CFP, LR, [CFP]
; 7E0:       C0035FD6         RET
; 7E4: L4:   0B0080D2         MOVZ R1, #0
; 7E8:       F1FFFF17         B L3
; 7EC:       E00120D4         BRK #15                         ; Invalid argument count trap
; 7F0: L5:   090280D2         MOVZ TMP, #16
; 7F4:       ECF0FF58         LDR R2, #x801267C610            ; SB-VM::ALLOC-TRAMP
; 7F8:       80013FD6         BLR R2
; 7FC:       D9FFFF17         B L1
\")
   (:FUNCTION #A((16) BASE-CHAR . \"NATIVE-SEND-SPAN\") :CODE
    \"; disassembly for ARCDOCDB.SPK11::NATIVE-SEND-SPAN
; Size: 364 bytes. Origin: #x8012677818                       ; ARCDOCDB.SPK11::NATIVE-SEND-SPAN
; 818:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; 81C:       AA0F00F9         STR R0, [CFP, #24]
; 820:       ADEA40F9         LDR R3, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 824:       693F0091         ADD TMP, CSP, #15
; 828:       29ED7C92         AND TMP, TMP, #18446744073709551600
; 82C:       3B410091         ADD CSP, TMP, #16
; 830:       2C1D0091         ADD R2, TMP, #7
; 834:       AB1740F9         LDR R1, [CFP, #40]
; 838:       2B3500A9         STP R1, R3, [TMP]
; 83C:       A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 840:       20400091         ADD NL0, NL1, #16
; 844:       A00A00F9         STR NL0, [THREAD, #16]          ; binding-stack-pointer
; 848:       003A80D2         MOVZ NL0, #464
; 84C:       AAEA40F9         LDR R0, [THREAD, #464]          ; tls: SB-VM::*PINNED-OBJECTS*
; 850:       2A0000A9         STP R0, NL0, [NL1]
; 854:       AC6A20F8         STR R2, [THREAD, NL0]
; 858:       AA1740F9         LDR R0, [CFP, #40]
; 85C:       41050091         ADD NL1, R0, #1
; 860:       A01B40F9         LDR NL0, [CFP, #48]
; 864:       00FC4193         ASR NL0, NL0, #1
; 868:       2100008B         ADD NL1, NL1, NL0
; 86C:       AA1340F9         LDR R0, [CFP, #32]
; 870:       AD1F40F9         LDR R3, [CFP, #56]
; 874:       E4036DB2         MOV NL4, #524288
; 878:       041080F2         MOVK NL4, #128
; 87C:       40FD4193         ASR NL0, R0, #1
; 880:       A2FD4193         ASR NL2, R3, #1
; 884:       E30304AA         MOV NL3, NL4
; 888:       74430091         ADD R10, CSP, #16
; 88C:       D6010010         ADR LEXENV, L0
; 890:       7D5B00A9         STP CFP, LEXENV, [CSP]
; 894:       BB5210A9         STP CSP, R10, [THREAD, #256]    ; control-frame-pointer, control-stack-pointer
; 898:       93F7FF58         LDR R9, #x8012677788            ; send
; 89C:       60023FD6         BLR R9
; 8A0:       110080D2         MOVZ R7, #0
; 8A4:       100080D2         MOVZ R6, #0
; 8A8:       0F0080D2         MOVZ R5, #0
; 8AC:       0E0080D2         MOVZ R4, #0
; 8B0:       0D0080D2         MOVZ R3, #0
; 8B4:       0C0080D2         MOVZ R2, #0
; 8B8:       0B0080D2         MOVZ R1, #0
; 8BC:       0A0080D2         MOVZ R0, #0
; 8C0:       BF8600F9         STR ZR, [THREAD, #264]          ; control-stack-pointer
; 8C4: L0:   0C0000AB         ADDS R2, NL0, NL0
; 8C8:       E7010054         BVC L2
; 8CC:       BA2A00B9         STR WNULL, [THREAD, #40]        ; pseudo-atomic-bits
; 8D0:       A97A47A9         LDP TMP, LR, [THREAD, #112]     ; mixed-tlab.{free-pointer, end-addr}
; 8D4:       2C410091         ADD R2, TMP, #16
; 8D8:       9F011EEB         CMP R2, LR
; 8DC:       C8040054         BHI L5
; 8E0:       AC3A00F9         STR R2, [THREAD, #112]          ; mixed-tlab
; 8E4: L1:   2C3D0091         ADD R2, TMP, #15
; 8E8:       3E2280D2         MOVZ LR, #273
; 8EC:       3E0100A9         STP LR, NL0, [TMP]
; 8F0:       BF3A03D5         DMB ISHST
; 8F4:       BF2A00B9         STR WZR, [THREAD, #40]          ; pseudo-atomic-bits
; 8F8:       BE2E40B9         LDR WLR, [THREAD, #44]          ; pseudo-atomic-bits
; 8FC:       5E0000B4         CBZ LR, L2
; 900:       200120D4         BRK #9                          ; Pending interrupt trap
; 904: L2:   9F0900B1         CMN R2, #2
; 908:       01030054         BNE L4
; 90C:       AC2300F9         STR R2, [CFP, #64]
; 910:       7D0300F9         STR CFP, [CSP]
; 914:       76F2FF58         LDR LEXENV, #x8012677760        ; #<SB-KERNEL:FDEFN GET-ERRNO>
; 918:       170080D2         MOVZ NARGS, #0
; 91C:       DE9240F8         LDR LR, [LEXENV, #9]
; 920:       FD031BAA         MOV CFP, CSP
; 924:       C0033FD6         BLR LR
; 928:       AC2340F9         LDR R2, [CFP, #64]
; 92C:       EB030AAA         MOV R1, R0
; 930: L3:   A10A40F9         LDR NL1, [THREAD, #16]          ; binding-stack-pointer
; 934:       2A007FA9         LDP R0, NL0, [NL1, #-16]
; 938:       AA6A20F8         STR R0, [THREAD, NL0]
; 93C:       3F7CBFA9         STP ZR, ZR, [NL1, #-16]!
; 940:       A10A00F9         STR NL1, [THREAD, #16]          ; binding-stack-pointer
; 944:       EA030CAA         MOV R0, R2
; 948:       F9031DAA         MOV OCFP, CFP
; 94C:       3B430091         ADD CSP, OCFP, #16
; 950:       970080D2         MOVZ NARGS, #4
; 954:       EC031AAA         MOV R2, NULL
; 958:       ED031AAA         MOV R3, NULL
; 95C:       FF031FEB         CMP ZR, ZR
; 960:       BD7B40A9         LDP CFP, LR, [CFP]
; 964:       C0035FD6         RET
; 968: L4:   0B0080D2         MOVZ R1, #0
; 96C:       F1FFFF17         B L3
; 970:       E00120D4         BRK #15                         ; Invalid argument count trap
; 974: L5:   090280D2         MOVZ TMP, #16
; 978:       CCF0FF58         LDR R2, #x8012677790            ; SB-VM::ALLOC-TRAMP
; 97C:       80013FD6         BLR R2
; 980:       D9FFFF17         B L1
\")
   (:FUNCTION #A((7) BASE-CHAR . \"IO-STEP\") :CODE
    \"; disassembly for ARCDOCDB.SPK11::IO-STEP
; Size: 468 bytes. Origin: #x801267B600                       ; ARCDOCDB.SPK11::IO-STEP
; 600:       AA0A40F9         LDR R0, [THREAD, #16]           ; binding-stack-pointer
; 604:       AA0F00F9         STR R0, [CFP, #24]
; 608:       EED146F8         LDR R4, [R5, #109]
; 60C:       EAF9FF58         LDR R0, #x801267B548            ; :ACTIVE
; 610:       DF010AEB         CMP R4, R0
; 614:       C0000054         BEQ L1
; 618:       EAD146F8         LDR R0, [R5, #109]
; 61C: L0:   FB031DAA         MOV CSP, CFP
; 620:       5F0300F1         CMP NULL, #0
; 624:       BD7B40A9         LDP CFP, LR, [CFP]
; 628:       C0035FD6         RET
; 62C: L1:   E15144F8         LDR NL1, [R5, #69]
; 630:       A01340F9         LDR NL0, [CFP, #32]
; 634:       1F0001EB         CMP NL0, NL1
; 638:       4AE30091         ADD R0, NULL, #56               ; T
; 63C:       4AB38A9A         CSEL R0, NULL, R0, LT
; 640:       AF1700F9         STR R5, [CFP, #40]
; 644:       7D0300F9         STR CFP, [CSP]
; 648:       4BF8FF58         LDR R1, #x801267B550            ; :IO-CLOCK
; 64C:       B6F6FF58         LDR LEXENV, #x801267B520        ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::DEMAND>
; 650:       970080D2         MOVZ NARGS, #4
; 654:       DE9240F8         LDR LR, [LEXENV, #9]
; 658:       FD031BAA         MOV CFP, CSP
; 65C:       C0033FD6         BLR LR
; 660:       3B039B9A         CSEL CSP, OCFP, CSP, EQ
; 664:       AF1740F9         LDR R5, [CFP, #40]
; 668:       AB1340F9         LDR R1, [CFP, #32]
; 66C:       EB5104F8         STR R1, [R5, #69]
; 670:       E1D143F8         LDR NL1, [R5, #61]
; 674:       A01340F9         LDR NL0, [CFP, #32]
; 678:       1F0001EB         CMP NL0, NL1
; 67C:       8A090054         BGE L7
; 680:       E25143F8         LDR NL2, [R5, #53]
; 684:       E35142F8         LDR NL3, [R5, #37]
; 688:       E15145F8         LDR NL1, [R5, #85]
; 68C:       610001CB         SUB NL1, NL3, NL1
; 690:       3F0002EB         CMP NL1, NL2
; 694:       21B0829A         CSEL NL1, NL1, NL2, LT
; 698:       E20301AA         MOV NL2, NL1
; 69C:       EED144F8         LDR R4, [R5, #77]
; 6A0:       AE061037         TBNZ WR4, #2, L5
; 6A4:       F6030EAA         MOV LEXENV, R4
; 6A8: L2:   AF8B02A9         STP R5, NL2, [CFP, #40]
; 6AC:       E1D145F8         LDR NL1, [R5, #93]
; 6B0:       210800B1         ADDS NL1, NL1, #2
; 6B4:       A6080054         BVS L8
; 6B8:       E1D105F8         STR NL1, [R5, #93]
; 6BC:       EAD140F8         LDR R0, [R5, #13]
; 6C0:       EB5141F8         LDR R1, [R5, #21]
; 6C4:       EC5145F8         LDR R2, [R5, #85]
; 6C8:       7D0300F9         STR CFP, [CSP]
; 6CC:       ED0302AA         MOV R3, NL2
; 6D0:       170180D2         MOVZ NARGS, #8
; 6D4:       DED25FF8         LDR LR, [LEXENV, #-3]
; 6D8:       FD031BAA         MOV CFP, CSP
; 6DC:       C0033FD6         BLR LR
; 6E0:       4B138B9A         CSEL R1, NULL, R1, NE
; 6E4:       3B039B9A         CSEL CSP, OCFP, CSP, EQ
; 6E8:       AF8B42A9         LDP R5, NL2, [CFP, #40]
; 6EC:       F0030AAA         MOV R6, R0
; 6F0:       EE030BAA         MOV R4, R1
; 6F4:       F0000036         TBZ WR6, #0, L3
; 6F8:       010E4092         AND NL1, R6, #15
; 6FC:       3F3C00F1         CMP NL1, #15
; 700:       C1010054         BNE L4
; 704:       01125FF8         LDR NL1, [R6, #-15]
; 708:       3F4404F1         CMP NL1, #273
; 70C:       61010054         BNE L4
; 710: L3:   4E010037         TBNZ WR4, #0, L4
; 714:       EA030FAA         MOV R0, R5
; 718:       EB0310AA         MOV R1, R6
; 71C:       EC030EAA         MOV R2, R4
; 720:       ED0302AA         MOV R3, NL2
; 724:       36F0FF58         LDR LEXENV, #x801267B528        ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::IO-RESULT>
; 728:       170180D2         MOVZ NARGS, #8
; 72C:       DE9240F8         LDR LR, [LEXENV, #9]
; 730:       DE130091         ADD LR, LR, #4
; 734:       C0031FD6         BR LR
; 738: L4:   AF1700F9         STR R5, [CFP, #40]
; 73C:       EAF0FF58         LDR R0, #x801267B558            ; :FAULTED
; 740:       E97D4BD3         UBFM TMP, R5, #11, #31
; 744:       9F6B2938         STRB WZR, [CARDTABLE, TMP]
; 748:       EAD106F8         STR R0, [R5, #109]
; 74C:       7D0300F9         STR CFP, [CSP]
; 750:       8AF0FF58         LDR R0, #x801267B560            ; 'ARCDOCDB.SPK11::REJECTION
; 754:       ABF0FF58         LDR R1, #x801267B568            ; :REASON
; 758:       CCF0FF58         LDR R2, #x801267B570            ; :IO-RESULT
; 75C:       29A680D2         MOVZ TMP, #1329
; 760:       5E6B69F8         LDR LR, [NULL, TMP]             ; ERROR
; 764:       D70080D2         MOVZ NARGS, #6
; 768:       FD031BAA         MOV CFP, CSP
; 76C:       C0033FD6         BLR LR
; 770:       AF1740F9         LDR R5, [CFP, #40]
; 774: L5:   EED142F8         LDR R4, [R5, #45]
; 778:       0AF0FF58         LDR R0, #x801267B578            ; :INPUT
; 77C:       DF010AEB         CMP R4, R0
; 780:       C0000054         BEQ L6
; 784:       6AEDFF58         LDR R0, #x801267B530            ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::NATIVE-SEND-SPAN>
; 788:       561140F8         LDR LEXENV, [R0, #1]
; 78C:       DF021AEB         CMP LEXENV, NULL
; 790:       E0010054         BEQ L9
; 794:       C5FFFF17         B L2
; 798: L6:   0AEDFF58         LDR R0, #x801267B538            ; #<SB-KERNEL:FDEFN ARCDOCDB.SPK11::NATIVE-RECV-SPAN>
; 79C:       561140F8         LDR LEXENV, [R0, #1]
; 7A0:       DF021AEB         CMP LEXENV, NULL
; 7A4:       60010054         BEQ L10
; 7A8:       C0FFFF17         B L2
; 7AC: L7:   AAEEFF58         LDR R0, #x801267B580            ; :EXPIRED
; 7B0:       E97D4BD3         UBFM TMP, R5, #11, #31
; 7B4:       9F6B2938         STRB WZR, [CARDTABLE, TMP]
; 7B8:       EAD106F8         STR R0, [R5, #109]
; 7BC:       2AEEFF58         LDR R0, #x801267B580            ; :EXPIRED
; 7C0:       97FFFF17         B L0
; 7C4:       E00120D4         BRK #15                         ; Invalid argument count trap
; 7C8: L8:   A02520D4         BRK #301                        ; ADD-SUB-OVERFLOW-ERROR
                                                              ; NL1
; 7CC: L9:   204221D4         BRK #2577                       ; UNDEFINED-FUN-ERROR
                                                              ; R0
; 7D0: L10:  204221D4         BRK #2577                       ; UNDEFINED-FUN-ERROR
                                                              ; R0
\")))
 :PROCESSES
 ((:STATUS :OK :MODE \"fragmented\" :SERVER-PID 60038 :CLIENT-PID 60044 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"fragmented\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
   \"(:STATUS :OK :MODE #A((10) BASE-CHAR . \\\"fragmented\\\") :PID 60044)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"coalesced\" :SERVER-PID 60038 :CLIENT-PID 60048 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"coalesced\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
   \"(:STATUS :OK :MODE #A((9) BASE-CHAR . \\\"coalesced\\\") :PID 60048)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"maximum\" :SERVER-PID 60038 :CLIENT-PID 60052 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"maximum\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION 10 :STDOUT
   \"(:STATUS :OK :MODE #A((7) BASE-CHAR . \\\"maximum\\\") :PID 60052)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"zero\" :SERVER-PID 60038 :CLIENT-PID 60053 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"zero\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
   \"(:STATUS :OK :MODE #A((4) BASE-CHAR . \\\"zero\\\") :PID 60053)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"oversize\" :SERVER-PID 60038 :CLIENT-PID 60054 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"oversize\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
   \"(:STATUS :OK :MODE #A((8) BASE-CHAR . \\\"oversize\\\") :PID 60054)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"truncated\" :SERVER-PID 60038 :CLIENT-PID 60055 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"truncated\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
   \"(:STATUS :OK :MODE #A((9) BASE-CHAR . \\\"truncated\\\") :PID 60055)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session\" :SERVER-PID 60038 :CLIENT-PID 60056 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"session\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
    2 :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT \"(:STATUS :OK :MODE #A((7) BASE-CHAR . \\\"session\\\") :PID 60056)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session-invalid-hello\" :SERVER-PID 60038 :CLIENT-PID
   60057 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"session-invalid-hello\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
    :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((21) BASE-CHAR . \\\"session-invalid-hello\\\") :PID 60057)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session-pre-hello\" :SERVER-PID 60038 :CLIENT-PID 60059
   :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"session-pre-hello\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
    :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((17) BASE-CHAR . \\\"session-pre-hello\\\") :PID 60059)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session-oversize-hello\" :SERVER-PID 60038 :CLIENT-PID
   60060 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"session-oversize-hello\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
    :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((22) BASE-CHAR . \\\"session-oversize-hello\\\") :PID 60060)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"session-id-reuse\" :SERVER-PID 60038 :CLIENT-PID 60061
   :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"session-id-reuse\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
    1 :PENDING-AT-CLOSE 1 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((16) BASE-CHAR . \\\"session-id-reuse\\\") :PID 60061)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"native-server\" :SERVER-PID 60038 :CLIENT-PID 60062 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"native-server\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :NATIVE-SIDE :SERVER :RESPONSE-ORDER (2 1) :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((13) BASE-CHAR . \\\"native-server\\\") :PID 60062)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"native-client\" :SERVER-PID 60038 :CLIENT-PID 60063 :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"native-client\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION
   (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS
    2 :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
   :STDOUT
   \"(:STATUS :OK :MODE #A((13) BASE-CHAR . \\\"native-client\\\") :PID 60063)
\"
   :STDERR \"\")
  (:STATUS :OK :MODE \"native-truncated\" :SERVER-PID 60038 :CLIENT-PID 60064
   :ARGV
   (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
    #A((108) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
    \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"native-truncated\"
    #A((117) BASE-CHAR
       . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
   :EXIT-CODE 0 :OBSERVATION (:STATUS :OK :CONFIRMED-BYTES 5 :STATE :EOF)
   :STDOUT
   \"(:STATUS :OK :MODE #A((16) BASE-CHAR . \\\"native-truncated\\\") :PID 60064)
\"
   :STDERR \"\"))
 :NAMESPACE
 (:STATUS :OK :OCCUPIED-NODES (:LISTENER :ORPHAN :FILE :SYMLINK)
  :REPLACEMENT-PRESERVED T)
 :NATIVE-SYMLINK-BIND
 (:BIND-RESULT :BOUND :LINK (16777232 1566737188 41453) :TARGET
  (16777232 1566737189 49645))
 :LIMITS
 (:TRANSPORT-AND-CONTROL-MODEL :NO-ENGINE-ADMISSION :NO-DURABILITY
  :NO-DISTINCT-UID :NO-PERFORMANCE-MEASUREMENT))
"
 :STDERR
 "(:STATUS :OK :MODE \"fragmented\" :SERVER-PID 60038 :CLIENT-PID 60044 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"fragmented\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
 \"(:STATUS :OK :MODE #A((10) BASE-CHAR . \\\"fragmented\\\") :PID 60044)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"coalesced\" :SERVER-PID 60038 :CLIENT-PID 60048 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"coalesced\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION 20 :STDOUT
 \"(:STATUS :OK :MODE #A((9) BASE-CHAR . \\\"coalesced\\\") :PID 60048)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"maximum\" :SERVER-PID 60038 :CLIENT-PID 60052 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"maximum\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION 10 :STDOUT
 \"(:STATUS :OK :MODE #A((7) BASE-CHAR . \\\"maximum\\\") :PID 60052)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"zero\" :SERVER-PID 60038 :CLIENT-PID 60053 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"zero\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
 \"(:STATUS :OK :MODE #A((4) BASE-CHAR . \\\"zero\\\") :PID 60053)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"oversize\" :SERVER-PID 60038 :CLIENT-PID 60054 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"oversize\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
 \"(:STATUS :OK :MODE #A((8) BASE-CHAR . \\\"oversize\\\") :PID 60054)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"truncated\" :SERVER-PID 60038 :CLIENT-PID 60055 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"truncated\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION NIL :STDOUT
 \"(:STATUS :OK :MODE #A((9) BASE-CHAR . \\\"truncated\\\") :PID 60055)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session\" :SERVER-PID 60038 :CLIENT-PID 60056 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"session\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS 2
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT \"(:STATUS :OK :MODE #A((7) BASE-CHAR . \\\"session\\\") :PID 60056)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session-invalid-hello\" :SERVER-PID 60038 :CLIENT-PID 60057
 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"session-invalid-hello\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT
 \"(:STATUS :OK :MODE #A((21) BASE-CHAR . \\\"session-invalid-hello\\\") :PID 60057)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session-pre-hello\" :SERVER-PID 60038 :CLIENT-PID 60059
 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"session-pre-hello\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT
 \"(:STATUS :OK :MODE #A((17) BASE-CHAR . \\\"session-pre-hello\\\") :PID 60059)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session-oversize-hello\" :SERVER-PID 60038 :CLIENT-PID 60060
 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"session-oversize-hello\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 0 :MAX-INFLIGHT 0 :MODEL-CALLS 0
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT
 \"(:STATUS :OK :MODE #A((22) BASE-CHAR . \\\"session-oversize-hello\\\") :PID 60060)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"session-id-reuse\" :SERVER-PID 60038 :CLIENT-PID 60061 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"session-id-reuse\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS 1
  :PENDING-AT-CLOSE 1 :ENGINE-CALLED NIL)
 :STDOUT
 \"(:STATUS :OK :MODE #A((16) BASE-CHAR . \\\"session-id-reuse\\\") :PID 60061)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"native-server\" :SERVER-PID 60038 :CLIENT-PID 60062 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"native-server\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :NATIVE-SIDE :SERVER :RESPONSE-ORDER (2 1) :ENGINE-CALLED NIL)
 :STDOUT \"(:STATUS :OK :MODE #A((13) BASE-CHAR . \\\"native-server\\\") :PID 60062)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"native-client\" :SERVER-PID 60038 :CLIENT-PID 60063 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"native-client\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION
 (:STATUS :OK :PROFILE :CONTROL :MAX-FRAME 4096 :MAX-INFLIGHT 2 :MODEL-CALLS 2
  :PENDING-AT-CLOSE 0 :ENGINE-CALLED NIL)
 :STDOUT \"(:STATUS :OK :MODE #A((13) BASE-CHAR . \\\"native-client\\\") :PID 60063)
\"
 :STDERR \"\")
(:STATUS :OK :MODE \"native-truncated\" :SERVER-PID 60038 :CLIENT-PID 60064 :ARGV
 (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\"
  #A((108) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/run.lisp\")
  \"--client\" \"/tmp/arcdocdb-spk11-z4qN8k/ipc.sock\" \"native-truncated\"
  #A((117) BASE-CHAR
     . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/SPK-11-unix-socket/out/build-rQYoCf/\"))
 :EXIT-CODE 0 :OBSERVATION (:STATUS :OK :CONFIRMED-BYTES 5 :STATE :EOF) :STDOUT
 \"(:STATUS :OK :MODE #A((16) BASE-CHAR . \\\"native-truncated\\\") :PID 60064)
\"
 :STDERR \"\")
")
