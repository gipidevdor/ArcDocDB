(:SOURCE-CONSISTENCY :STABLE :SOURCE-BLOBS-AFTER
 ((:PATH ".gitattributes" :GIT-BLOB "d22cbb201cb1d3384baa7e8422aa9d6ee8aea1f9")
  (:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "4ed9445eb02f439a3c781878622809125ed924e6")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "711b96fd6fb677d15473213023c40c35affb47c0")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "ea5cf67447809b2e413026d50e2f61609cb9e438")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "80da41aac60230141d5d2d0819c9b6c2c3b3ce91")
  (:PATH ".github/ci-toolchain.lock.lisp" :GIT-BLOB
   "c01b06c5b208014ab30bb000dc10acfc9e72cc89")
  (:PATH ".github/workflows/ci-results.yml" :GIT-BLOB
   "d5029660830b7dbef56d6648bbf0a9bbaa400c56")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "49fc8ba897e94dc36c31d973e6e12efeab51b715")
  (:PATH ".github/workflows/docs.yml" :GIT-BLOB
   "6eef2de086d133233892870f80f5771f90ab1676")
  (:PATH ".gitignore" :GIT-BLOB "a3a191b534821cfe86f062a09dbc2cb19ba153bf")
  (:PATH "CHANGELOG.md" :GIT-BLOB "87840f1089d9c2ec1ba7b282874276890a28d254")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bc7dba35611947cb7c1e9fb898e294b00f9f2de1")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "20743e1dd5a32d14e0af066e27987eaa16c94964")
  (:PATH "README.md" :GIT-BLOB "9e6430d753813af59152d82a3959a45d70abfa94")
  (:PATH "SECURITY.md" :GIT-BLOB "331a1316c300159882e3a30f9f2c8575a8e586a9")
  (:PATH "THIRD-PARTY-NOTICES.txt" :GIT-BLOB
   "0c5bc85db048fb8970c3cc42fb128337eff77e39")
  (:PATH "arcdocdb.asd" :GIT-BLOB "b3226747355fcac8bc4d2a210b8f54848eb689ea")
  (:PATH "assets/README.md" :GIT-BLOB
   "c30d58ba88d9dd9f146df6f03aeedbdea3df5c72")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "a024e50336c5d93b7619048432219020d84eb688")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "0bb1c4dcc1aef96287b5edf18db288467e37f9c1")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "data/unicode/18.0.0/CaseFolding.txt" :GIT-BLOB
   "9ee0a2dd654f6fa520cd932be19ac5c00ffacded")
  (:PATH "data/unicode/18.0.0/DerivedNormalizationProps.txt" :GIT-BLOB
   "32227e8f297e96f98954281d99c38839a7834d7c")
  (:PATH "data/unicode/18.0.0/LICENSE.txt" :GIT-BLOB
   "56da58912807030b451a4700687d5bd02c72d6ed")
  (:PATH "data/unicode/18.0.0/NormalizationTest.txt" :GIT-BLOB
   "730c1a013ac78f6a63118e670c72556d4f112eab")
  (:PATH "data/unicode/18.0.0/README.md" :GIT-BLOB
   "06ab2a1368779a5535c48e90a7e2fb77e44080c9")
  (:PATH "data/unicode/18.0.0/ReadMe.txt" :GIT-BLOB
   "aa18f7175c4a46df644c7c6435ad95a8ad3cd724")
  (:PATH "data/unicode/18.0.0/UnicodeData.txt" :GIT-BLOB
   "ebccf021c4fcf31c2ecbb9bd7da3f5eb7ed44851")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakProperty.txt" :GIT-BLOB
   "313ae91aad579445a1e06556a1d7a2edd0c782a2")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakTest.txt" :GIT-BLOB
   "8d734a2690b9f06018e02b0b4f165acc4d0d2853")
  (:PATH "data/unicode/18.0.0/emoji/emoji-data.txt" :GIT-BLOB
   "7a383f0dcfd6ad65a2b7b5e90f701e38485f151f")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "a677288d5fd65a8de671c8cb513fef7c9cb013d5")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "0f68efcd275602bc60b1ee3a2a104f8a49bc6b80")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "1445703c53c2f1b82ced7dd78f34ad4ab8aae7d1")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "3c1c28fb8949660be6391180be187f55d14d5bb6")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "4c0ad12a7532b5d518b0581301f28a3601228d94")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "fce97d7d8c70a6c8f5425cd47ade5a2db5892a11")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "d3973b8d3cca6c9df25ab1c2e76c305bdc28c51b")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "85c9f51f242e4e5c3239edb58eea0a3ae0013011")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "5e10ff0c486bc5e08163bcd5df5bd5736de102f0")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "8720f145cca1d03da5446c5398ad4417a6243a18")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "30462b46bdd4dffdc7a8217adb6ec89571bf8b89")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "c05d0f0f5f69c9ddd9a85769c4bb11cc5a921c75")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "4ccdd9d66495ccff8d47d70ab80b04fa3bc601ca")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "b6a6a520f82271f96513a10457ad400c3f86f2bd")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "b75830dd78d106f8db76e65c08d4e8f3b2a488e4")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "d102ba1c248c77c71c437e46675cd5fc913fcdc5")
  (:PATH "docs/README.md" :GIT-BLOB "db925522d2e683e87137b5f3bca8d234cfe435bc")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "641a7c9e540ff2ec1136bcaa53c6558691578577")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "85d24f91157ac79e6af8c3ac908ca03921913922")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "9baef4c50046aca7c2d9740896af96a9dc5974f3")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "c949015de0fa3a2c25e597b523cb9a00409549b7")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "dd5d59a612a804976a08a475b0cce0de5daba1e3")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "49c294e438f29b383bc825210ba12f070f24a7a1")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "b56195d0f7f43e7bdb91a3af0d1a33f161b8d36e")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "26cb290c6bed61bf397cf4f9dbad7ca81d97e8b0")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "289e40fc2198e9295b90cddd5444d061cccdacfc")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "570458150a9f118174d72cbf90b0b13400237997")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "86c3d28f5a8ecdcf0dbbff34e5eeddf69bea5c48")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "3a490fbb3a23a5de59e08a86b5d656e559ec3696")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "c6b0803782b4595bce94f73f37bfb3de06ef58e3")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "811067eb4311ef4ed3c3b5450325345c04d444e4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "c863c2471e2f6e2b6bb0cb79f9c303dda902f572")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "5117c423e298e8aee4e02b2daea95cdfa6747784")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "813ecfb7741a73bbe4065c0914eab22495bbca3e")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "c5fc54a10372cec9bbf1fd3cbb436a6e835cd079")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "08a71d783f74d8dc0c02db312902f4256668d49d")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "085506a53a59d44f70b63f9f550df428a1f7c564")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "6399188b2711a8860f5895fb92dfabb34fa2dafa")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "13e62eb82f21f3b5490511d47823439541edba33")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "7785da60ce293bc328817518fbf2be3f9ab9a7b8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "57f594b6143b04e40bc3fea9394ebe938ca799ee")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "6b41728bd67274b11b1fde42cfb6ac2b71b0340b")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "0ec3e4cb8daeb741d6be9428099f1da284b0f895")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "50cded21f18bd019fc190b08edb348945d05829f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "e0e408989c0d8b1a8594a31a9f4cda888232b8c7")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "51ecdb8e1af48f87cd2e53d8c3c334b4a4dd7062")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "8589ad553a5b18f96e5dbab682a024f90b671c2e")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "138cf9abbe606df8f544a669069ed94844c9960f")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "c6ee53cf623ad6294ab2ab7e46ee16a3304dfdda")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "0af09ca66b38c35361d30ddbd028a0cb7fcac4e8")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "98cad23c9c529f3f83ccf02dc9bd1a4cb1e6f318")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "2d7ba68f4a56fa80700825d44f2b4335b4d342f4")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "5150eca7a1e85c342e20519179c0560e19c816c4")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "3aa06135165157067c6eaf64d8317a43d32086f6")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "b352146cf5138b099155a819a2c0c19780a31af7")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "05cc183bb8bd0b7b468a7225065c4dc75dd6cd33")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "452553489ad4b466a118e5ec3f08a79223ba7f69")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "7323f9c4e7d6a41ee0e8edbc7c21f6c40fae7258")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c12ccb4a82f5e97c40c2e2df05f085c28f9356af")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "c5ccb103deb265db77ca14be9e4fb60ebb7395f3")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "d0ce5bcc0bbfbf2fa92187bbd09d0ff320d54e69")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "a52656154964c4588477288a15fb10284ac888a4")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "d23b7ee9ef2e3e178a663dbfb004ccc8fed2c542")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2c0669b7a0226ff342e15158899a06d75a30abbc")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "5ba95841ff8f467ed496f51101ddd832dca4fab1")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "2787435e8647b4c1702b7fb4f35f40cd64197fa0")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "18cf324a65ccb0d7684d357bbb8eeb6aeed6a11a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "6754d79f26141153b55bbe1bcaa4a82825f95700")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "fd7e70d402194978a3ffdad705318afb0431f04e")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "2c3d966a83d6f5c1ba122e38ee510b5277a1e89e")
  (:PATH "docs/adr/0053-ricerca-full-text-indici-invertiti.md" :GIT-BLOB
   "ed37b13d26276ccec88bc4eb7e9259bc8ea270a0")
  (:PATH "docs/adr/0054-contratto-e-formato-full-text.md" :GIT-BLOB
   "239a1b5bbb0be77e0a60cb3f0360d8f4906d0b46")
  (:PATH "docs/adr/0055-interfaccia-locale-unix-socket.md" :GIT-BLOB
   "3a1a8acc98918b9eff3f9c319da1d089bd55bf1b")
  (:PATH "docs/adr/0056-sessione-locale-m16.md" :GIT-BLOB
   "09aa317be40281eb6dfeedfb16c27bf4ee227782")
  (:PATH "docs/adr/0057-selezione-automatica-indice.md" :GIT-BLOB
   "dd056fe207e34cc13582ef67686f5cef50da0d52")
  (:PATH "docs/adr/0058-pagine-indice-primario.md" :GIT-BLOB
   "aace2fae9377ecc39befa24f30a71fa3544aa82f")
  (:PATH "docs/adr/0059-crc32c-arm64-sbcl.md" :GIT-BLOB
   "8abf118f525ac8e4bfb3657e7b9c2389825e3734")
  (:PATH "docs/adr/0060-crc32c-caricamento-portabile.md" :GIT-BLOB
   "e525cdb37bc853b13c077a139869132a6c8a3296")
  (:PATH "docs/adr/0061-conservazione-esterna-delle-prove.md" :GIT-BLOB
   "f72ff61077518b492f247dde021f8ae8d5749777")
  (:PATH "docs/adr/0062-cronologia-git-due-commit.md" :GIT-BLOB
   "d17a19b8086aeb412bb8622fe8dc5301fd3265d0")
  (:PATH "docs/adr/0063-immagini-sigillate-indice-primario.md" :GIT-BLOB
   "6bf24e2c250857907d5d36e6ea7f2d93cf2dcf63")
  (:PATH "docs/adr/0064-adozione-indice-paginato-m1.md" :GIT-BLOB
   "8b4f945e8e06c194b517c1563c2a78fe1ddbd609")
  (:PATH "docs/adr/0065-costruzione-immagini-dal-motore.md" :GIT-BLOB
   "09314a89fa7875d648062095cfd24081055e34f5")
  (:PATH "docs/adr/0066-attivazione-seriale-immagini-m1.md" :GIT-BLOB
   "ca6fd5d38685053ceb12922973a932f72fce5fd8")
  (:PATH "docs/adr/0067-delta-seriale-indice-m1.md" :GIT-BLOB
   "03ea9916428820920370aaeef7c422b0478d3b4e")
  (:PATH "docs/adr/0068-rinnovo-seriale-immagini-m1.md" :GIT-BLOB
   "2240c84c7e57c86d33df08772b173cc9d0d11aba")
  (:PATH "docs/adr/0069-manutenzione-a-soglie-delta-m1.md" :GIT-BLOB
   "7433e9b73ae1548f198181002505a8aabec65ceb")
  (:PATH "docs/adr/0070-scoperta-readonly-immagini-m1.md" :GIT-BLOB
   "f4a496e4556b220282b4a962a57a723ad2ccbf50")
  (:PATH "docs/adr/0071-delta-location-indice-m1.md" :GIT-BLOB
   "5f06b390d2223e5e5e85f38f5de73cf1ad668f5f")
  (:PATH "docs/adr/0072-rinnovo-automatico-delta-m1.md" :GIT-BLOB
   "99ae69d3d9fa5d6d69f9cb5efede395fe33ae408")
  (:PATH "docs/adr/0073-indice-automatico-operativo-m1.md" :GIT-BLOB
   "8f7677e90411d564c161e07d5f46fe774e32384e")
  (:PATH "docs/adr/0074-crc32c-sbcl-2.6.10.md" :GIT-BLOB
   "0d32b3a9bfe16d3755cc163e1ec2ec09394ca598")
  (:PATH "docs/adr/0075-codex-documentation-toolchain.md" :GIT-BLOB
   "60f2fca9be7d793cffd1f13dc43a80365df700a5")
  (:PATH "docs/adr/0076-rotazione-live-m1.md" :GIT-BLOB
   "1da6f99e64dbce919e88440c8a4662d9abc9ba82")
  (:PATH "docs/adr/0077-source-derived-code-reference.md" :GIT-BLOB
   "100230816ee9e513dfc78ba3c57c992bef61eec5")
  (:PATH "docs/adr/0078-compattazione-prefix-m1.md" :GIT-BLOB
   "89e9e72b6eb4aaf2a0fd494de6a72a33810a52b0")
  (:PATH "docs/adr/0079-cache-record-m1.md" :GIT-BLOB
   "114135347b465d247f7e05b091858c9791f88382")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "b885270db66dd618a2984415182e1bc6eb8c9edc")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "da6af58f171fe105407b444a400905f554110ec9")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "09805b5022bf9b338522c4078feae7334825c50a")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "2b878e6c0b9ea5576635f16b1d9e7433c956458f")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "0b92053bbe5abc8b74a59472a0ddaad7be9ba399")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "35ce8a542e4e77ba28c497e4a33358f308708bd0")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "5729dba5379c1eaf1366302e6243fa5219f60cd0")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "2325e50c80180c368d7e13c9181bb6e6fd8ff831")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "5f74a1692a934ddc9425d91ff0cadbf842c95bb2")
  (:PATH "docs/code-reference.md" :GIT-BLOB
   "ce9a8a5a9a8ef8d58833bb239199bbd2e1f6019a")
  (:PATH "docs/editorial-policy.md" :GIT-BLOB
   "23c70f794c8640f050be6eda8d1f75fbeeb13540")
  (:PATH "docs/editorial-review.md" :GIT-BLOB
   "9264d1e4e9b0189d3b3f5a5f3c8cebe5f5d728ec")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "d83cff978b0e2c61bfbf1308e4fdcdbd38fb4ebf")
  (:PATH "docs/formato-indice-full-text.md" :GIT-BLOB
   "be3b1b6661023f58d985a26c07c15216cb099a66")
  (:PATH "docs/full-text.md" :GIT-BLOB
   "29a9ee662cd39c103edaaf046bc8b68731bd8df4")
  (:PATH "docs/github-pages.md" :GIT-BLOB
   "1d624b0c03aa60ee582ce4c98c83b38272c0dc75")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "8c460a969441f5be9d94766fff808f15d6d33f36")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "0c946fd449c68453ea89231234ec67431189414d")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "af4e816a0da1be43b48fc88866c6e07d68447d2a")
  (:PATH "docs/implementazione/active-recovery-metodo.md" :GIT-BLOB
   "5724560732e14d6d374483aa71ca0f7802541df5")
  (:PATH "docs/implementazione/active-recuperato-metodo.md" :GIT-BLOB
   "32524af882ad0a043f6d939994c9a6a11769fef9")
  (:PATH "docs/implementazione/active-recuperato-verifica.md" :GIT-BLOB
   "23af8d8e23577a92d5c0e74884061cb56639d55d")
  (:PATH "docs/implementazione/active-recuperato.md" :GIT-BLOB
   "0b685aa69fd7c078994b5d1feaa4b5b93c1cafc8")
  (:PATH "docs/implementazione/adozione-closed-runtime.md" :GIT-BLOB
   "21630d85433210b2f061c422c931ef0f14ad0b61")
  (:PATH "docs/implementazione/adozione-controller-runtime.md" :GIT-BLOB
   "f2f7826b7eb58b681d334e29834ddd1cf09fed06")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "797a1998753834a3204075954c9cfe81a0f064d4")
  (:PATH "docs/implementazione/archivio-csn-revisione.md" :GIT-BLOB
   "c886079a0ad9f47ae864fbb63084960f897e55fa")
  (:PATH "docs/implementazione/archivio-csn-verifica.md" :GIT-BLOB
   "873f06c415107bac58d781df316e5b484222316a")
  (:PATH "docs/implementazione/associazione-file.md" :GIT-BLOB
   "02e39a32261a5a901ca45e15dcc7505819a969e0")
  (:PATH "docs/implementazione/attivazione-indice-m1.md" :GIT-BLOB
   "cd609a5e9645be680b23798e0bda841d8507d772")
  (:PATH "docs/implementazione/cache-pagine.md" :GIT-BLOB
   "1eaeb517c655d918d307d46423e4aee54f39290b")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "3dbae0d9e595f509621e6bf6dd3380a5ed844f1d")
  (:PATH "docs/implementazione/cbor-array-decisioni.md" :GIT-BLOB
   "948258bd302c1820210e439862d432d8c5554e9e")
  (:PATH "docs/implementazione/cbor-array-lettura.md" :GIT-BLOB
   "c419ecc31f9e905f4d053fd4473c8b605415dc4d")
  (:PATH "docs/implementazione/cbor-array-metodo.md" :GIT-BLOB
   "a5e53c22e391f72573f89c01f58ae28fa1c40376")
  (:PATH "docs/implementazione/cbor-array-revisione.md" :GIT-BLOB
   "f992654650b2fb08a59058b337fef63f901bf75c")
  (:PATH "docs/implementazione/cbor-array-risultati.md" :GIT-BLOB
   "e4c253fcfbe86fd2dfce2bd3354614a67f4b97f5")
  (:PATH "docs/implementazione/cbor-array.md" :GIT-BLOB
   "0f8fa2876a7366cd62bd1b8669251e2107b19b7d")
  (:PATH "docs/implementazione/cbor-float-scrittura-copertura.md" :GIT-BLOB
   "c1f596a69e83504ff3fd2c7cf569f234e1c6554b")
  (:PATH "docs/implementazione/cbor-float-scrittura-dati.md" :GIT-BLOB
   "618a4fdc1d5fbb230414931295ff0f7ef9367c84")
  (:PATH "docs/implementazione/cbor-float-scrittura-decisioni.md" :GIT-BLOB
   "cd76b3d2b02c6c021849b2b85d1a403d76e38f78")
  (:PATH "docs/implementazione/cbor-float-scrittura-lettura.md" :GIT-BLOB
   "11a065b51085a23f42df7ca75e315cbee0328e70")
  (:PATH "docs/implementazione/cbor-float-scrittura-metodo.md" :GIT-BLOB
   "6c046bb92cc291fb00914da89e0eefb705b4ae65")
  (:PATH "docs/implementazione/cbor-float-scrittura-revisione.md" :GIT-BLOB
   "870474964d88a8b4099bf00cc31c0b2bc542f94a")
  (:PATH "docs/implementazione/cbor-float-scrittura-risultati.md" :GIT-BLOB
   "84faa8d4bbf5150c4b9df17879b5dd0b39a286d4")
  (:PATH "docs/implementazione/cbor-float-scrittura.md" :GIT-BLOB
   "c14c7bbaebcd803c24f62adcda19259b16f00e52")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c7fe2a7bad385932a72141de4ae46f04bbd8ce18")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "dd7621ec9feea82adec89e00ed232b22d8aead35")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "4984c8c845da1437c212f47a7a345979df1c5acc")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "ba09a11d806999c55e0cb75f5b638d1fe2cb0476")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "29f9c13299d7b2fbcea64db535c0ec3fd4456f73")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "fb04b79a27ae65e2097c21ace50ee70f26bb0e8a")
  (:PATH "docs/implementazione/cbor-item-decisioni.md" :GIT-BLOB
   "800cefe6cf8f8a8000dad71d3807df7e7efdd210")
  (:PATH "docs/implementazione/cbor-item-lettura.md" :GIT-BLOB
   "57bcf4f8d1c40334c68d53ad2b4a2092e769d8d1")
  (:PATH "docs/implementazione/cbor-item-metodo.md" :GIT-BLOB
   "05b4a0d45c993c6bfebb0555098334f40db82f33")
  (:PATH "docs/implementazione/cbor-item-revisione.md" :GIT-BLOB
   "de0ef7bc19fe539d4aef7cdc1c1f5345b8002a94")
  (:PATH "docs/implementazione/cbor-item-risultati.md" :GIT-BLOB
   "8b02e00a9d43febf09b846d1bf6a01ebee2b3005")
  (:PATH "docs/implementazione/cbor-item.md" :GIT-BLOB
   "8548c091f11308380d4ac4e01ff884644b470281")
  (:PATH "docs/implementazione/cbor-map-decisioni.md" :GIT-BLOB
   "f44e789f6d2bf153580332fb136e46cb9e57194a")
  (:PATH "docs/implementazione/cbor-map-lettura.md" :GIT-BLOB
   "23a1f7f9653522ebf02619977dc2d74ed275f891")
  (:PATH "docs/implementazione/cbor-map-metodo.md" :GIT-BLOB
   "50ad5d1f64b5dbd37f4285306c5430789e0c581e")
  (:PATH "docs/implementazione/cbor-map-revisione.md" :GIT-BLOB
   "4f9c6c7a2e2eed16e73bbb314f5936182d371420")
  (:PATH "docs/implementazione/cbor-map-risultati.md" :GIT-BLOB
   "5322d5cdd93ea61e00830138091c72eadd5effe9")
  (:PATH "docs/implementazione/cbor-map.md" :GIT-BLOB
   "3f4f8e64c19f21958bcc913a1ee701cc55a18f06")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "998d3f4d69a4915bd3d5ac13381d89b15a22afaf")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "1c7b8bc426f5054aa88e7b2cf8ce1d0c339e112b")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "d34c7e0e8b9347228e9c3121358824f106d1e663")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "8beb9758140566348297f59d8a85a1c6816c70ae")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "464af7d4e2264a4c7e0336b2219a0e886cd04c2b")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "a0a4beb749f27b8fdd721492a338ff29acd18420")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "3ac17f24029e9c242146cd994a7b2b907ef8177d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "1a2a1bc130b5e3f343f110bd9ccca2de3486a19b")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "ef1defbeb7d0f2f52a289e03fa52b7922bd8fff2")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "980896a21ef91e13e4c3a4d414d72115eb27fee1")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "a0533ae26074d23c19b098bcf11d7f3959c3b609")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "c3bd5167d49e4e2bc59bff90b6e62e3435ed43b6")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "556fddff139cb8660db889b3b1cb39046972c01f")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "d0bb1a35f08dc97dcb4e03e70e521707c8a8d29c")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "05a927871e8257d31d40c727f88858cc10f3f5b3")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "7b606f5d5c44abd25a7cea635c2e3086f7b08d7a")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "0c3f81227199b06df304e9e3bcbc6c98660bacc8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "54852d32fb4a642db32067148adbf6d9fb22a066")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "ab773c5d9261846c39c09f6cf06566344acd4ff9")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "a3e52d83ef8dab364c1e290a003fbcac3e4703b5")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "943ce8b93716e53b1048dbb672ecb01ecf2ecf2c")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "3bc420d5c29b2005395fdbf72ba1fe12fa0feb20")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "12ed41add43b64cf9a0cf317dab6a09a0f6a8f5e")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "7299368dd4c077d8e620e6a3f6b91dde5cde96c3")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "ee75788591cf776a011eddef4384ce6c9b0c1cf8")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "b5e504a3508da8c72295f9fa7a18ba44a482b547")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e5b9990f00978da272fac6353b4706e9cdb3e80e")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "46f011d10fbd376c7387ffe48a9730a3a2620b05")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "d33e32c7e570f1958c8af75a789ea3a6583e4289")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "032c6c20aa5e116d2c1fa4214a0701e40620b966")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "77e0e458eb0cfbeb0796d176ff54805fcec9fc13")
  (:PATH "docs/implementazione/cbor-stringa-lettura-decisioni.md" :GIT-BLOB
   "a307a12444fd16df6ad92dcdf8717f02e76ac7a8")
  (:PATH "docs/implementazione/cbor-stringa-lettura-metodo.md" :GIT-BLOB
   "3378a194f4eded0fc1316be064956d77b3132fb3")
  (:PATH "docs/implementazione/cbor-stringa-lettura-prima-revisione.md"
   :GIT-BLOB "6fb1e3c3cd8a7512958b54095940826c30980eed")
  (:PATH "docs/implementazione/cbor-stringa-lettura-risultati.md" :GIT-BLOB
   "b50555a7cf2b592b5c36b2d094d7500225581f06")
  (:PATH "docs/implementazione/cbor-stringa-lettura-seconda-revisione.md"
   :GIT-BLOB "ebfc3d0bbdd1a19a295c55770a6d505ddbd4aa84")
  (:PATH "docs/implementazione/cbor-stringa-lettura.md" :GIT-BLOB
   "9eecb30c6b1887b9a0a5f5aabe3516916c3ba025")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "82f1683ba3774d33e82fd23e118790e401c11085")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "ff78a1940b29beef1c4e685e2084767c948f9da0")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "280b19d5e97d5487ba6be4f59da8b015063074bf")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "7ac03f1075bd778be47916ef9eef72e5bcdc90ff")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "08f016eb4a073cf59dbb3c5c9b23791d4a1285ef")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "c17e8ed2fb902df4c971d0300c1c7842dd46a764")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "16b04b9a5451b880ea2449104f65e261ba7f6c7d")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "66c94d76bdb2c46714ea86774489f31580ac63c9")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "d64b31030580f02466562e86efae7cc27451d0a2")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "16ffa1f24020338735660b5b008fb3e00c498ea4")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "39fa55a82334440ea17d53dbefe050d53db6a716")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "5e801a7632e7ce46f56e79cad2073b3e155eae99")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "c77993b00f09e89d21d2ab2eb319964e9e2fa819")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "2221900158acbbd5cdaa39d3301b08501c071e97")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "e29635a7ce3cd150ea0801c4610ddd03af941c8c")
  (:PATH "docs/implementazione/cbor-tag-decisioni.md" :GIT-BLOB
   "f0329ac5196815f633bf7abc82c97730cee832a5")
  (:PATH "docs/implementazione/cbor-tag-lettura.md" :GIT-BLOB
   "49146a982d1297edaf0c31daca7c5eb6150a6ea7")
  (:PATH "docs/implementazione/cbor-tag-metodo.md" :GIT-BLOB
   "ffa487840cb2e0964e7fa7a7cd55d57fbeed3de4")
  (:PATH "docs/implementazione/cbor-tag-revisione.md" :GIT-BLOB
   "b61c84f5f4a70f3009748536709d37c2609d89cd")
  (:PATH "docs/implementazione/cbor-tag-risultati.md" :GIT-BLOB
   "a78c3f04408c306f2cddcc617274f2335b17fc81")
  (:PATH "docs/implementazione/cbor-tag.md" :GIT-BLOB
   "a67789164c1ca9ab5be6435322ae77606314831f")
  (:PATH "docs/implementazione/checkpoint-control.md" :GIT-BLOB
   "2e2d90188ad3b3bec79f9a2c90e9f2cff58f3c42")
  (:PATH "docs/implementazione/checkpoint-recovery.md" :GIT-BLOB
   "fd1444d3e09f58457eb3babe639bc93634e32aa3")
  (:PATH "docs/implementazione/ci-provenienza-pr.md" :GIT-BLOB
   "cfe42a5fe0ebb52b0c1217926a15078d8baf4cea")
  (:PATH "docs/implementazione/ci-statistiche.md" :GIT-BLOB
   "6d6d3ad1d0381ab4bf946a6c1e7561f5266ad494")
  (:PATH "docs/implementazione/ci-wire-processi.md" :GIT-BLOB
   "537159570d4bdc8e7dbcddb5be3dd9e2d57c26eb")
  (:PATH "docs/implementazione/closed-recuperato-revisione.md" :GIT-BLOB
   "38373f1de3d42b5e9056e60d30f215083a80c845")
  (:PATH "docs/implementazione/closed-recuperato-verifica.md" :GIT-BLOB
   "1c4b3e4f0e6c3d3c4519dcdd56c7a2ca8ca2d47d")
  (:PATH "docs/implementazione/closed-recuperato.md" :GIT-BLOB
   "3675c4a21cd14e15f136f1bdcd6e0c64f28564bc")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "07c702f3b926311b7af6950382459286f20c9d05")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "7c9473c0d5149a7cefab4ef33076c7f44bfe9f30")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "2dd9f8ab7dbdc2df6a41874a63aa62f45fa11ba8")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "714da56672b38ed721a71f7d81986f66ca3915e6")
  (:PATH "docs/implementazione/control-recuperato.md" :GIT-BLOB
   "050723cbdec05ccf343e6cf651023dbba053fa60")
  (:PATH "docs/implementazione/control-transizione-metodo.md" :GIT-BLOB
   "4af36a8e4c9c409cccb82beacd9a7243057c2b76")
  (:PATH "docs/implementazione/control-verifica-metodo.md" :GIT-BLOB
   "8ffecd3625f0d1c3b4cf5786e17354cd170a127f")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4e75306fe31c84d552c342f4294894121d647097")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "4c8e017a2fc5e52b4a26d3f90c50d2e89f90e5f1")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "a294f643c70035056ce585a186fe4fb0ad1f01f3")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "6a48c794b8d8619e762c0c33108175d26dab2235")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "e3bc4006b2c53306af00f16d8967e002be5be7f2")
  (:PATH "docs/implementazione/controllore-pool-decisioni.md" :GIT-BLOB
   "e45a4a1609e6ad2c4a8c507a3b6474b34329fc7e")
  (:PATH "docs/implementazione/controllore-pool-metodo.md" :GIT-BLOB
   "9452ebefc6280a045c051c394e3ab55a9b5b7b90")
  (:PATH "docs/implementazione/controllore-pool-revisione-2.md" :GIT-BLOB
   "f4b54f7f20f0dbc620c95098dfe8f7d11e00eb84")
  (:PATH "docs/implementazione/controllore-pool-revisione.md" :GIT-BLOB
   "8331ccdab4e1957b7eaa4ff7404ab2ed263fa924")
  (:PATH "docs/implementazione/controllore-pool-risultati.md" :GIT-BLOB
   "e0738c5de4ceb793d70419ac8fece82e1de2359d")
  (:PATH "docs/implementazione/controllore-pool.md" :GIT-BLOB
   "32a0876c84705abfb03a324d93c0e09997e8caaf")
  (:PATH "docs/implementazione/costruzione-indice-m1.md" :GIT-BLOB
   "954e5c11aac01cdcdbbe1300ab7ad5904a31186f")
  (:PATH "docs/implementazione/costruzione-indice-paginato.md" :GIT-BLOB
   "6f4a25f0f4a8c5c5ef123b587f34313cf18493ae")
  (:PATH "docs/implementazione/crc32c-arm64-metodo.md" :GIT-BLOB
   "fd0a6f8b0203eb527434d5c85b5a21bffaa83842")
  (:PATH "docs/implementazione/crc32c-arm64.md" :GIT-BLOB
   "9d44dfe4836c393debf1e2fedd781ba8d64ac854")
  (:PATH "docs/implementazione/crc32c-piattaforme.md" :GIT-BLOB
   "c48393540f18a1982fa9523d82684488f2d0e9ed")
  (:PATH "docs/implementazione/crc32c-unroll32.md" :GIT-BLOB
   "f9b81bfbbfe41d6f0433df1275b14e0ddb277521")
  (:PATH "docs/implementazione/csn-archivio-recovery.md" :GIT-BLOB
   "0501c6e7d687db9aa0196637ea4ceb5032d398b9")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "f3c71d7a014741290c658cd958ca5d5b6e5076a7")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "6809b9ff79f77032c94c726a67913fd86ed590f4")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "87df34a5915fead7f06bff837dfa0b904f9eb664")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "ac014f8282cf46645dd18f92f16bff17ac1da0b4")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "3d69beb591d794d62111bb695cf87fc6c4726e2c")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "7979e6edd61ac9300d6560b493a61948a4fd0d92")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "62df2e33eb3daa289da2fd2d544db1e367495b76")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "2ab09dc900d919686bd211a1fc0c9e233d6d8bbe")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "26b8a34a0c455ffa1244cd8930718ad68067983d")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "475fcdde02949a8500168f29ab43891d70fe7fa9")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "7e01085ba74008ba3f3715415c7196de10efe61f")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "a2f17134ae38a241a5610af3f00051f0e1c6bca5")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "04724b6857c83e623ba245bef65c657f416bbced")
  (:PATH "docs/implementazione/decisioni-recuperate-revisione.md" :GIT-BLOB
   "e8ec567a22d4a0b7f365d7649622e9a3405e69e4")
  (:PATH "docs/implementazione/decisioni-recuperate-verifica.md" :GIT-BLOB
   "efae51de3ab17894525f9803c2caa2dab2caa737")
  (:PATH "docs/implementazione/decisioni-recuperate.md" :GIT-BLOB
   "877dab2bc85bec554965e906163a950fa7f42dbb")
  (:PATH "docs/implementazione/delta-indice-m1.md" :GIT-BLOB
   "74b4d0337972db90f897380d1acf29cf56b5387d")
  (:PATH "docs/implementazione/delta-location-m1-metodo.md" :GIT-BLOB
   "546cbb2eb9169663e412972c9ffa3dfdd7a44eb7")
  (:PATH "docs/implementazione/delta-location-m1.md" :GIT-BLOB
   "dd39d0fa56ef87edaac933052523fb1092af9891")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "23c6bd3464be1c5de0e85dd1ceef49cb072e2610")
  (:PATH "docs/implementazione/evidenze-parallele.md" :GIT-BLOB
   "c1cf798f1d7aa870e6fc08666fb089bd0078f1b2")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "9ce191f9a921d27dd12773f67b2ea9dc2b724c11")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "5988fea2f0c49b45d4da2152cd2f213f7d4a3bbe")
  (:PATH "docs/implementazione/fonti-recovery-metodo.md" :GIT-BLOB
   "71889d31dc82e1ce9cb80228debcd2aaae265ca3")
  (:PATH "docs/implementazione/fonti-recovery.md" :GIT-BLOB
   "b613cfd01ebf4f093fd8d5b4f6ea14c2c43b1156")
  (:PATH "docs/implementazione/full-text-codec-decisioni.md" :GIT-BLOB
   "d84b4a8ea730f7eb6a08f7578322a9cbab97cc27")
  (:PATH "docs/implementazione/full-text-codec.md" :GIT-BLOB
   "dd648030eb25834fe6d66bf6fb61fad777ef7906")
  (:PATH "docs/implementazione/full-text-decisioni.md" :GIT-BLOB
   "891a19e59ded15ce976428e647431e6087fcda8b")
  (:PATH "docs/implementazione/full-text-documenti-decisioni.md" :GIT-BLOB
   "6df6ad62e11ea8977a258a6e11e774488c131e97")
  (:PATH "docs/implementazione/full-text-documenti.md" :GIT-BLOB
   "813e65fa97477a4d4451c483e137540af95cd667")
  (:PATH "docs/implementazione/full-text-put-metodo.md" :GIT-BLOB
   "2526a07b957970e7abc7f6baae970c2162d9b68e")
  (:PATH "docs/implementazione/full-text-put.md" :GIT-BLOB
   "a480bcb65e37731737a70f16554ca9e5e8cf8ee0")
  (:PATH "docs/implementazione/full-text-riferimenti-metodo.md" :GIT-BLOB
   "0cb603ba80950501cb439b61b4645274188ec75d")
  (:PATH "docs/implementazione/full-text-riferimenti.md" :GIT-BLOB
   "d363ee6d5e8e55f35668fbb129c2cf1f626a6d16")
  (:PATH "docs/implementazione/full-text-righe-metodo.md" :GIT-BLOB
   "2f576876ff695c0b662b91f8deea5b3793c3bc5b")
  (:PATH "docs/implementazione/full-text-righe.md" :GIT-BLOB
   "c6b643c4cf20d6b4378f7bfe7f05132cd4ba1d10")
  (:PATH "docs/implementazione/full-text-riserve-metodo.md" :GIT-BLOB
   "17663cca4a20e28e53be920eaa83792b520354a4")
  (:PATH "docs/implementazione/full-text-riserve.md" :GIT-BLOB
   "154f11b6ffc05e72273d3ab4a0b7a5d3867ad3a7")
  (:PATH "docs/implementazione/full-text.md" :GIT-BLOB
   "10317557bc507e5b786a0564626bc3109e851c46")
  (:PATH "docs/implementazione/get-active-metodo.md" :GIT-BLOB
   "de07ae6a11977904595cd321e2fdfb229cb0bbc0")
  (:PATH "docs/implementazione/get-active-preflight-metodo.md" :GIT-BLOB
   "2557776ad0c8c99e3c479ebfd557b6c912dd503d")
  (:PATH "docs/implementazione/get-active-preflight-verifica.md" :GIT-BLOB
   "2616f8e780fbc697519bc3517591c54197bd37f5")
  (:PATH "docs/implementazione/get-active-verifica.md" :GIT-BLOB
   "f46fdd16bd2ff24d0caa1426706db284b6e9f583")
  (:PATH "docs/implementazione/get-active-vuoto.md" :GIT-BLOB
   "4a9988d8277e40527ee761df7b55a44897c827db")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "3f09685689be3207d6d3689b3e2383060092c9e4")
  (:PATH "docs/implementazione/get-costi-metodo.md" :GIT-BLOB
   "fb1926959f835883b7d88a5dda7bdea7f30998b8")
  (:PATH "docs/implementazione/get-costi-risultati.md" :GIT-BLOB
   "655b8a35ae16b285e8c5da3ee0249d47a7629c57")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "56133e69f5a305d3d7ed173361a60d11dc8083a1")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "242e710cf037c17f94ce2c6213210b87e1cd5108")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "017acf3977bd60a59c7cc3c093c084dc5742d8d6")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "d25a0d6bb499867c8e74865f76064205c70a904a")
  (:PATH "docs/implementazione/get-fonti-serie-metodo.md" :GIT-BLOB
   "0b3f2db806973acd21c7b0cb4fe203656db06baf")
  (:PATH "docs/implementazione/get-fonti-serie-revisione.md" :GIT-BLOB
   "91c14197cca8cfa11f46b4f5e2ef5cc03e269507")
  (:PATH "docs/implementazione/get-fonti-serie.md" :GIT-BLOB
   "ef7f5f3ae5748673a74ca960d3c5bb1c6e1dd44d")
  (:PATH "docs/implementazione/get-lifetime.md" :GIT-BLOB
   "3c83a87b6b59b2432c54145ff6d8e5144c7864be")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "953b28082bc52d2925a43c6e78ef19e9cd7710b6")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "adad30953d4d419ccd39475545619fb9e32b1392")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "a85bb276b698a7c20da89fb2fb23e19aef2bf5e0")
  (:PATH "docs/implementazione/get-resolver-metodo.md" :GIT-BLOB
   "fe7942c088ae3aa68d0e15e04c9f46faf05622ac")
  (:PATH "docs/implementazione/get-resolver-verifica.md" :GIT-BLOB
   "67b906cd6e8b8569f97a766b66deebd57f4be501")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "753deeb7ec87fcfdc7c8c1275368fa947827ac37")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "5d14690cdad3e3517bcd32522fd9b26f10475eac")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "4515dcc663abeaa09a60ea4c8b3bd6df1baad2d9")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "9a6c1470083bbd595277d9a9f3b430ff0c5f85d6")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "b8204499bb41f33cea556a86eab9551f8709de40")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "695650c8c40cd1cbe9ad38eed29698b7b71ba97f")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "78a7da074a3daca5f05793f03b88fc4ce45321aa")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "c1a36112a2dbf6afef54a654c262389ba9037ba2")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "83b6d477b9d16697c2002989891657ba95ee4e6a")
  (:PATH "docs/implementazione/id-directory-recovery.md" :GIT-BLOB
   "6ea173a4f8c1210432f00d11e6ce6aae4ad1174b")
  (:PATH "docs/implementazione/id-segmento-recovery.md" :GIT-BLOB
   "f2fa99ae8a932406bb74666fa401e0aa9b2655a0")
  (:PATH "docs/implementazione/immagini-indice-paginato.md" :GIT-BLOB
   "8e88cc05ab5ee90c1a1c98d9b20859b652a97bf3")
  (:PATH "docs/implementazione/indice-automatico-completamento-metodo.md"
   :GIT-BLOB "c354d887b3102978bf827b1959e323b7d9b18b27")
  (:PATH "docs/implementazione/indice-automatico-operativo.md" :GIT-BLOB
   "e70a739bfd63091d2ba9cec5c6fd6aa821e4d669")
  (:PATH "docs/implementazione/indice-automatico-risultati.md" :GIT-BLOB
   "d8823f505faa11809cea64f9f3c90675b0198fb0")
  (:PATH "docs/implementazione/indice-automatico.md" :GIT-BLOB
   "614b528773e7b34f955143e0afea744d431e2e1e")
  (:PATH "docs/implementazione/indice-da-recovery.md" :GIT-BLOB
   "486481170704785730c471af7dfd1a5816243a04")
  (:PATH "docs/implementazione/indice-paginato-m1.md" :GIT-BLOB
   "fe476e799ce3ec29caebbecb1a112a2e04bbe2f7")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "4e34fc8e0ffc4413a921b5538edd63693281b70e")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "439aa57177f9323735aaf1e8c4677cdf17e29ad7")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "3935af00f6b06ca6fbca8ab7a8c977eab164322c")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "32dd19680071319c88e9a91a0132260e921573d2")
  (:PATH "docs/implementazione/inizializzazione-active.md" :GIT-BLOB
   "d4c99e5ce4fb98ef862944a7cc41c08205cf60f7")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "56795353bfac9ce5c3ebc0b69f704890d306c194")
  (:PATH "docs/implementazione/inventario-directory-metodo.md" :GIT-BLOB
   "1c6d345a7b2d02c2687f08474a7805e79160b615")
  (:PATH "docs/implementazione/inventario-directory-revisione.md" :GIT-BLOB
   "42511becdd73740fd1ea37f271dc7d4482ddeb74")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "caab01e598ef66377c6da22dbcec17db820b8b91")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "7fcabec950c4e85735ab5bd7960cba65d0b1b494")
  (:PATH "docs/implementazione/io-apertura-relativa-metodo.md" :GIT-BLOB
   "fa44089871f66bddf1309fa5d75b4678eef58902")
  (:PATH "docs/implementazione/io-apertura-relativa-revisione.md" :GIT-BLOB
   "8b13ab5dd4831710adfa606e5edf659e31c8a714")
  (:PATH "docs/implementazione/io-apertura-relativa.md" :GIT-BLOB
   "975eed05b2318ed9b85f4d6f860c2431248f1db7")
  (:PATH "docs/implementazione/io-completamento.md" :GIT-BLOB
   "b5982e35ea000c4c9dcc91021374849d6670638b")
  (:PATH "docs/implementazione/io-creazione-relativa-metodo.md" :GIT-BLOB
   "84b9f6ac1bf934fb7c34e178542cce9dae62fdc6")
  (:PATH "docs/implementazione/io-creazione-relativa-revisione.md" :GIT-BLOB
   "6ad24b936952f03d7a70827f10314ac7f0ad1dfb")
  (:PATH "docs/implementazione/io-creazione-relativa.md" :GIT-BLOB
   "0a0d30b8c6cf826cb906b7d7d26bc8c4c68b3b8d")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "d6eb46b50c73b0150eddbc34cc93f127e82163dc")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "92c01fe2ab85af78f2f3cbf68cdaababa61f5ed9")
  (:PATH "docs/implementazione/io-pubblicazione-metodo.md" :GIT-BLOB
   "bdf72add9058e53ae707719af4ead4d18f462946")
  (:PATH "docs/implementazione/io-pubblicazione.md" :GIT-BLOB
   "f56f5f2f22e43b665a472d8560143b9430ea9ded")
  (:PATH "docs/implementazione/io-rinomina.md" :GIT-BLOB
   "d699c8433a309044b041ec1e2a0713ddb7d6f120")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "3db1a3257313b7040dd2b1222f4de77166de75da")
  (:PATH "docs/implementazione/lettura-indice-paginato.md" :GIT-BLOB
   "ce43161a04c6068b3ddce5b8eee94f35e46c5872")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "1fa26d055d5ee76d3a9bc6f6e6e31a3af3c0e0f1")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "91b0ee252ceff9071c62a573b7b499b8e36e1964")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "4b69dba2809dc40a4d039a6106dd02e560c8e26c")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "20b9246ebddba96db237e5ebcbf2529afbd26a91")
  (:PATH "docs/implementazione/manutenzione-indice-m1.md" :GIT-BLOB
   "bcf08f6c98961ee5660483cd627244c1243f2a99")
  (:PATH "docs/implementazione/merge-main-2026-10-23.md" :GIT-BLOB
   "cb672d06673d639a152ef3bea52b73f258513473")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "332563a00301c759a56fa56efeb0c733f5d8acb5")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "daca7cad14916fbc0b10743a6898bfba4f6c47ad")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "2789dc59d0173d4e0af289cfac129ab12d1bec00")
  (:PATH "docs/implementazione/moduli.md" :GIT-BLOB
   "04085bb65a97af3cf46e9a0ad4a3b491c3009648")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "48ffbd9f476751940bbae8713788bd1d812a6002")
  (:PATH "docs/implementazione/pagine-indice-risultati.md" :GIT-BLOB
   "e8889ba9c0d836e73050037bd49faa9ae016a5a6")
  (:PATH "docs/implementazione/pagine-indice.md" :GIT-BLOB
   "34c6c7dec3f852d8dc6245a6c05a7f26ef2d09a5")
  (:PATH "docs/implementazione/pool-begin-metodo.md" :GIT-BLOB
   "8d10cde6f53e6e75cd936fa109121d0caab09d5f")
  (:PATH "docs/implementazione/pool-begin-revisione.md" :GIT-BLOB
   "95657e20c25dd27baddab5c04a2053170af45b96")
  (:PATH "docs/implementazione/pool-begin-risultati.md" :GIT-BLOB
   "c4049dcf13b516abf81bbea4d32aff64cb425c7f")
  (:PATH "docs/implementazione/pool-begin.md" :GIT-BLOB
   "06bd817d57eb415225973e0981778132621cf230")
  (:PATH "docs/implementazione/pool-catena-metodo.md" :GIT-BLOB
   "758327137a15f0f1ef344d51370add33a3a2c6cd")
  (:PATH "docs/implementazione/pool-catena-risultati.md" :GIT-BLOB
   "8bf6c0fe47438107778c68195e6f98ccb42b0b9c")
  (:PATH "docs/implementazione/pool-dispatch-metodo.md" :GIT-BLOB
   "eb6709befc9bdb0d67b04fd5c4c4f98a01ab94de")
  (:PATH "docs/implementazione/pool-dispatch-revisione.md" :GIT-BLOB
   "abda6bf2dbaa1fc5fdc6e55cc22bb0ee931513f2")
  (:PATH "docs/implementazione/pool-dispatch-risultati.md" :GIT-BLOB
   "ab68af4bc1ab1552d74c694ce96c1e1c4222920f")
  (:PATH "docs/implementazione/pool-dispatch.md" :GIT-BLOB
   "a540afacd7952495cc3300e0bced676639c55337")
  (:PATH "docs/implementazione/pool-prepara-metodo.md" :GIT-BLOB
   "4da00d6f92b7f949ec8acafbd3a97dd56bbbb367")
  (:PATH "docs/implementazione/pool-prepara-revisione.md" :GIT-BLOB
   "2c5e9f14f01fedcb7e3dc7a3b4ade9b8bfdcc9b6")
  (:PATH "docs/implementazione/pool-prepara-risultati.md" :GIT-BLOB
   "8c5a986a075da0555e225369bb08b72e4994558b")
  (:PATH "docs/implementazione/pool-prepara.md" :GIT-BLOB
   "84dcb4f1603e43af42c335d58a1d67ebe6347ae0")
  (:PATH "docs/implementazione/pool-recycle-metodo.md" :GIT-BLOB
   "2c811c8f11f65e5142e23c6d8e306b44e412d1e0")
  (:PATH "docs/implementazione/pool-recycle-revisione.md" :GIT-BLOB
   "100e57b2835ce7bc6b5dc68912cf99ae1e637c30")
  (:PATH "docs/implementazione/pool-recycle-risultati.md" :GIT-BLOB
   "4a192b8293368b041956bf12a8e266bd08d86cb5")
  (:PATH "docs/implementazione/pool-recycle.md" :GIT-BLOB
   "40dcde9abd1d21cf1d0d56cecc3b66c641b607b8")
  (:PATH "docs/implementazione/pool-step-metodo.md" :GIT-BLOB
   "e44a4958a4c0a67213243b112bc7362f0573e914")
  (:PATH "docs/implementazione/pool-step-revisione.md" :GIT-BLOB
   "66ab0543f271b9a5c96cb6aa2247be4d6925fd59")
  (:PATH "docs/implementazione/pool-step-risultati.md" :GIT-BLOB
   "470c7dc02213e5d01719829413da36ec08cc5d4c")
  (:PATH "docs/implementazione/pool-step.md" :GIT-BLOB
   "09a4edba6f17bed9682708707ecbe188b2b8e101")
  (:PATH "docs/implementazione/pool-worker-claim-metodo.md" :GIT-BLOB
   "b1b933f896ebb4b2c54a2a714a4c4291c431662d")
  (:PATH "docs/implementazione/pool-worker-claim-revisione.md" :GIT-BLOB
   "18aef79552d243af35866c3d2955e2d11761935d")
  (:PATH "docs/implementazione/pool-worker-claim-risultati.md" :GIT-BLOB
   "f0ce19f06da992cf25de5b3dd396258b7197105c")
  (:PATH "docs/implementazione/pool-worker-claim.md" :GIT-BLOB
   "5a69ddd2dad8066ee9d03792f8548abb9225222f")
  (:PATH "docs/implementazione/pool-worker-lifecycle-metodo.md" :GIT-BLOB
   "d32a1e07253c9138b176912091366712ff3037a4")
  (:PATH "docs/implementazione/pool-worker-lifecycle-revisione.md" :GIT-BLOB
   "9638731f43392e0a33b7f4ed84b19d6c46d1b0fa")
  (:PATH "docs/implementazione/pool-worker-lifecycle-risultati.md" :GIT-BLOB
   "d26d034ded38c3feb056a5a272e5147d790b36f6")
  (:PATH "docs/implementazione/pool-worker-lifecycle.md" :GIT-BLOB
   "5a1af3956ec7cb503cfe7b561acc66e3b32029ad")
  (:PATH "docs/implementazione/prestazioni-local-m1.md" :GIT-BLOB
   "d09055552b7b9fa8d15cd552465dc1025defa2d6")
  (:PATH "docs/implementazione/production-engine-bootstrap-metodo.md" :GIT-BLOB
   "92ea9255903acb119f72d1a61affda35f94a9358")
  (:PATH "docs/implementazione/production-engine-bootstrap.md" :GIT-BLOB
   "110fc6b64792152c41674c8a9e51ca47f45d653a")
  (:PATH "docs/implementazione/production-unix-m1.md" :GIT-BLOB
   "d96cdb1e30cf8112586f6707267a0533e1b1fa30")
  (:PATH "docs/implementazione/prova-verticale.md" :GIT-BLOB
   "3b9642adce018f1bba63fca6cfaad10924f0351f")
  (:PATH "docs/implementazione/pubblicazione-control.md" :GIT-BLOB
   "8dee23aebeb7bd74de78153bff357b6810162ca0")
  (:PATH "docs/implementazione/raccolta-comandi-risultati.md" :GIT-BLOB
   "0e8a853a5618a1906dd4adbb7c9b18840959d03e")
  (:PATH "docs/implementazione/raccolta-comandi.md" :GIT-BLOB
   "69a9ac538805c31b2857a55f2d5b5c32c0a71b38")
  (:PATH "docs/implementazione/recovery-archivio.md" :GIT-BLOB
   "728fcfa388c5032d170b4f1924b6d614857baee7")
  (:PATH "docs/implementazione/recovery-csn.md" :GIT-BLOB
   "0a3b62e567853df795b710c8e080e3e4319d5153")
  (:PATH "docs/implementazione/recovery-serie.md" :GIT-BLOB
   "fb61bc33d840d815c72dcb3eb4c74c909708d42c")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "09620fc2b2248bec312b075e411f6864a5ebf16f")
  (:PATH "docs/implementazione/replay-closed.md" :GIT-BLOB
   "bb4499a07188b2887c5960e3eba59c951d80a159")
  (:PATH "docs/implementazione/rinnovo-automatico-m1-metodo.md" :GIT-BLOB
   "061f7030b0c9486754cea7333ee3838cf5f00e59")
  (:PATH "docs/implementazione/rinnovo-automatico-m1.md" :GIT-BLOB
   "29fbd690f61f74593e280c1be93b64d74b2609cd")
  (:PATH "docs/implementazione/rinnovo-indice-m1.md" :GIT-BLOB
   "048fb5e263d00771553c8de699ebe0e585c9c780")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "d7b9c49b07bae6f01a5562d15a2cdabcbb979878")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "2709d9ad98b8dd8028b36f0163ba09bf2f49ae14")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "fa341fd666506b060c4d1253773dd87859014238")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "569fb428d702f4a60440c10cb0d9a1a360670fd1")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "ac6b5e1ea180807849dc24481de16eb79e4999af")
  (:PATH "docs/implementazione/runtime-archivio-revisione.md" :GIT-BLOB
   "bba7a3fa2b7e2139ea24ec86cc97fb4b02909aff")
  (:PATH "docs/implementazione/runtime-archivio.md" :GIT-BLOB
   "f8efbf185c6e21920a72d7982f396f5f6e4360d8")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "54739f1b4f681ee51b684fd5f1706028a8922b11")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "24f4832f44e05b4958ee59a8b9b899228f5afa6d")
  (:PATH "docs/implementazione/scoperta-indice-local-m1.md" :GIT-BLOB
   "c6a2000090f8bf5b356b49804799739acccd1344")
  (:PATH "docs/implementazione/scoperta-indice-m1.md" :GIT-BLOB
   "4f05d679dfd56ea2922507433e26c876de136b00")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "40197f19d765e646a0e3ce558386997294130ab1")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "16a6ec600581f9c958650a8578117ad7d7d79584")
  (:PATH "docs/implementazione/selezione-versioni-recovery.md" :GIT-BLOB
   "47d2caa2887778182456420705e0228179305769")
  (:PATH "docs/implementazione/sessione-locale.md" :GIT-BLOB
   "2ecf722d1f5009738a021d2b451e71bfcf0a6c2a")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "3badf8773cc33d0a772b9bde5741af120be1db29")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "52ce3f078d06cad8ffac89ea2baa6ad830c0df34")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "d0ce2c9951518f30ccec2391bc8d9e3e508eaa19")
  (:PATH "docs/implementazione/stabilizzazione-archivio-metodo.md" :GIT-BLOB
   "e29923b3ea68b49f0d100baa7b41f221663d26f9")
  (:PATH "docs/implementazione/stabilizzazione-archivio.md" :GIT-BLOB
   "51adacc370255a8a7d7bb9cb32d5efd9d98cc21f")
  (:PATH "docs/implementazione/stabilizzazione-esclusiva-metodo.md" :GIT-BLOB
   "862b15afa8262596760a2b84e08ba266369e101a")
  (:PATH "docs/implementazione/stabilizzazione-nomi-recovery.md" :GIT-BLOB
   "19c7b3f57ea810a35ebe212071e06e27f61c3a21")
  (:PATH "docs/implementazione/stabilizzazione-serie-metodo.md" :GIT-BLOB
   "89673b60a8a5690b772ef365b2194470238efd14")
  (:PATH "docs/implementazione/stabilizzazione-serie.md" :GIT-BLOB
   "960b956f4841ce0d3a6e38612feee69f2666ab37")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "ec3c6b8f92c54a84bc98d5ac21e58758152de542")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "a60c8e7ee23f78e8a53a516e2c161fc0827ff699")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "e7cf6d0c9962ed26216d07d63d052d45bb9f03e7")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "1a94e0e95ab7446193da420d97bedc24a721d387")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "8ab0ba990681d1b185ab87aad114593c0abb305a")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "f08e66f8b7925a5bcec55f2edf1380fc66d6c0a2")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "353a2d053b16ec57b6572aed1f17d1b49d8a232f")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "15c437c7c71674f8fc1cd5a72b3162f4f1715eba")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "e20c5c59567d8ce4800dc19e8dc5fdc2f7f0606f")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "f4edff819e12b287df3cf5f00ecd3550e930f9e0")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "82bd2785271ce7480c4c8d137349c8d41dfee729")
  (:PATH "docs/implementazione/worker-cbor-interleaving.md" :GIT-BLOB
   "02c902149e07d4ac4dfc6f6170799eb34574f09a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "ab3e69cc7051d3ce33f9b4d94cd0e2b20b49807c")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "2c5bcfdaa1783a21adba6911300d0baf7d12f339")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "8fcb335ad6bc807d58ab2ec9033f948421737de5")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "8fa6801e99ffb1abca08a0861883ace20672bd2c")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "63c27916925bec8cfbc39c0c9d558eb444e6dad2")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "f35b46574ff72f1ddac7498c601be30c990d859e")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "ebea51d87dc4f0c750be5834f48d66aac19c7e2d")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "9cd61461e8bfad2d757011db0307229f1517a0d2")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "865c639e5d48a0a77133b6fbe033d78113f703ac")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "1dd65b133120e4f660ed14e674caa8d9af55cfc9")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "4812ec2f65bf772695877b5760a2528fb69a70ef")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "debe8bfd28a95306a16004ca1ccb20ff2bf85fd6")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "7a1ffa13a41b58db26e43bb4090a5d7b6732e512")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "f0ab347bf7c6974b7968e96b9615238b2b14713d")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "b3d19a3668170d14b2ee8a1cec101a27334a8d41")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "14bca7f6cd2c9976cbfdbe3a24a146bc46a34d79")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "f0fd5c63f1adaf9e08e3a7f03dd3fa62bc10aea5")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "c96e7d84ba793911aca73e1deafe6da49509b879")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "8543024839bb87730a16489183b141a010d48cfc")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "234ef34a0065f902f68cdc9432513444a303731c")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ae34240b8fcb8fecbda5492828281de203dc5327")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "07bc53c1a476b0f93bf860fa18c97573d96c656f")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "e120e67c134bd2b9ddbbf55259f5195a3ef4989c")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "85cdbcee3cc2985f6935c6508b71ae9eccf58c99")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "a7329d98d65dd7a94773a87d27f7e3d3871469bf")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "370e2848280af70fbee9085f4c5f1fb44b110889")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "3a9260af22a77d11d636a787613bd50668ffc1cd")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "1600a7f92e73a45f44214bfb2074d0c5cf6decec")
  (:PATH "docs/legal/README.md" :GIT-BLOB
   "149c30dbb116c197f5046d245f765803ed6112f4")
  (:PATH "docs/legal/accessibility.md" :GIT-BLOB
   "f0075a299d3f10c36f250343da01908f39bfc447")
  (:PATH "docs/legal/distribution.md" :GIT-BLOB
   "60ae06a99a28b346e28a28dba81925e38b762192")
  (:PATH "docs/legal/privacy.md" :GIT-BLOB
   "668c2ffde82f4149697d070851e5fdbf281937b0")
  (:PATH "docs/legal/review-2026-10-31.md" :GIT-BLOB
   "8e4053b788081e583340d3531e8c618eba2ef312")
  (:PATH "docs/legal/third-party.md" :GIT-BLOB
   "308d64af3e3901e8c8ea6209ec772f65bd55796e")
  (:PATH "docs/limiti.md" :GIT-BLOB "18a03d0c1262b4ddaddf5ff1cb3dd1777f216c3c")
  (:PATH "docs/lisp-api.md" :GIT-BLOB
   "a53a254f4225afdd5d59dffc7aebeb158b40bec3")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "f639c868ec4145ce4d712345973822ada77abb6a")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "6c2425c43abbc961ab2845fca2e3ea069b39eb81")
  (:PATH "docs/riferimenti.md" :GIT-BLOB
   "9addadca061376e75319617301e590e010ab8467")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "6d219aec5deaa4e99116741b6ba788d699868456")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "113bbeaa93a2032b3a642d626836c1d5f5d16c4f")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "df1e19c126d44b07fecbf153fcafa2c9af44e861")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "935cef690625235efeb2d36dbacb38fb83685047")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "1ae3fc90e1a01aa296c51d3f25c6d65c1bcdb5da")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "b7ef23de41612f981d34a97641e52902a1840a50")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "33f78a2faae61cd73459658d3ba2a88e2ecafe81")
  (:PATH "docs/valutazione/caso-duso-nntp.md" :GIT-BLOB
   "b6a035e1d66b869f40a42e07f2021a42d7de2859")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "972ca495cf51f54d16f3c33ca31fe890b6db7806")
  (:PATH "docs/valutazione/cronologia.md" :GIT-BLOB
   "be43f507343a1c75d71d9e4ada287a9c2fc0de12")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "32026027782790da44884b029c4bae89d5f4e1fd")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "32e72f3b579ee02d5a5e0e897a7618434b02e60d")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "2eeb123c80d9f061d21d2f1a31c57613d7707506")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "a01e78e3fd9dbfe2705fa6fda631d9c387b3bc91")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "c3173768fe23a50691d7106bddbc8c46bb8cd040")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "ed0b8c472645dd6e31178034268a7e60a34e09be")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "603665f1033eb1a62f8b9a4115250a16cf39b429")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "dca0a8b0aa20c8d038dcbc11023182fd552de10f")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "45bf66ebba21b28f569e6f12344277dce7245cd9")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "11d712a7a3432a89299a2f5d7f23736d596d7e40")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "f3eecb3e77252633aac4a62f1100a77b64ca91e0")
  (:PATH "examples/local-roundtrip.lisp" :GIT-BLOB
   "f814d10935f22272e5a440e92e7c8109dda16be8")
  (:PATH "legal/algorithms/xxHash-v0.8.3-NOTICES.txt" :GIT-BLOB
   "1ac346f5f0bff517073cca31f1509f39a5818d55")
  (:PATH "legal/notice-files.lisp" :GIT-BLOB
   "30a68c858f462c6ef601c270ac48603374b149d9")
  (:PATH "legal/runtime/SBCL-2.6.9-COPYING.txt" :GIT-BLOB
   "4220b33974e7fc04036b2b5600cb3ca88ce2c4c3")
  (:PATH "spikes/README.md" :GIT-BLOB
   "f835fdd46c43312889de749d525290e541e891f3")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "c2c2487c33cadbec5444b81073eb9e417a16c42f")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "03a90c690b4673695f0380f81f0cf68e4da8eda4")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "049ff2032103d3d6a6a8049fa9d803d6f82beeaf")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "cd79005b8100b79cbbca35a5677125af54f5e854")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "b388bbb2a067537c8b03b046d63ed6fd5201fa58")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "be57e2f216618fb65d5dde48e8d29938d377a009")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "6452906fa525035cf6abe7967f05778aeaf17f76")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "014f488b7b50a9439b36f49afd6b6f0f11295d84")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "badf96cfb95709afc9174e40b521ac75c6adac8c")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "1a46426b6521ca207a747cd0d2a7fed0ad4ecfd1")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "0061c53057783cc076b2dcb9596e91017e473c47")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "7edbb7459ca78fb41cb812d82ce1dc1c68176ea6")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "18246e75e94db5f4517e96e827469d6a006b30d2")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "0597672e814ccc60c541439e838b7e4eb491788a")
  (:PATH "spikes/SPK-07-protocols/metodo-page-lifetime.md" :GIT-BLOB
   "fba367b24467642a6e544ff86e099b143a73a925")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "6c0034a70670b4249cd2b525c9fca3e140dbd94e")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "517286df830984ba4a6ff39b03175e445afd65d7")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "163e4c3222c4e5771660e6463367ec6b1bc914af")
  (:PATH "spikes/SPK-07-protocols/page-lifetime.lisp" :GIT-BLOB
   "c032387167188be066737f75583738843b12c883")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "1ec5a1db56a76daacbc7488d8b7940aa0e16eca0")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "95ab6095de30d013dbf5c426f7b6c0a99d5663e6")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "9daf0b57d92db583544653384217105121c8627d")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "4712fb08742000724dbbf5c1f7fac4505ca6ad4c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/comparison.lisp" :GIT-BLOB
   "b8b8ebfa609d6bfe9b710833f22cdff693ef46bd")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/crc32c-unroll32.lisp" :GIT-BLOB
   "6dbbe7218c7b5185329f099a8c1407e0f48d8648")
  (:PATH "spikes/SPK-08-generated-code/crc32c.lisp" :GIT-BLOB
   "72bccfafe9c5cb0fd5dc6392534c5be404774a64")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "680b5d9c4e112747e903e124e07cab8adbf97da9")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c-unroll32.md" :GIT-BLOB
   "d722f4f0145cca93b8cb46aa0572538df99a12e0")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c.md" :GIT-BLOB
   "fbbb491611d807c1022c50236fe29c8d7accb2c0")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "4a57493b511201112c533418f1846acdf96f35c8")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "1bbf37c97bcc7d527c3d5aa90cbb9217b807f3ee")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c-unroll32.lisp" :GIT-BLOB
   "79033530456f565b3b14e25b56146039b5356860")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c.lisp" :GIT-BLOB
   "a45f0c3e862c2174b64ac63d4ca97ae3ddf21569")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "7c797afe4a6060782ce58f0cfc06f539006d117a")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "2ed0e101d31cef0967820fc70155ddd4561140fa")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "740e01ad7ddd2dc170e50454befe9a63b9eff276")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "1e54780546d2bcdd623f7fa6c2faaf127bf15dae")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69ac8ef15f356257dae151e035689d8124e9a9eb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "95928362ab8fbde280a5f74be905ae2ca58729ab")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "df0869dea4916cdb5b671a79ffa812369d043773")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "spikes/SPK-11-unix-socket/README.md" :GIT-BLOB
   "47d0cf7d3d5b5541e38cb47814dbb1f0197ffbdc")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "spikes/SPK-11-unix-socket/core.lisp" :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/native-io-method.md" :GIT-BLOB
   "a90da59a3ecad08654d619a56c2ced177db88a40")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-method.md" :GIT-BLOB
   "ebd5dce74e96860ace17a05cf7e14f940adb126f")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/evidence/README.md" :GIT-BLOB
   "d0dd48506d19490ae1c864f86f4606845241a15d")
  (:PATH "spikes/evidence/history.lisp" :GIT-BLOB
   "f210350eb462c1f3d45f24217f004775496b0eaa")
  (:PATH "spikes/evidence/snapshot.lisp" :GIT-BLOB
   "9ea68544e9490d6598d6361ae0bac6e27a69ce4e")
  (:PATH "src/active/package.lisp" :GIT-BLOB
   "fbd3a32b30808508424c007ece26c9f3ea9ad0a9")
  (:PATH "src/active/preflight.lisp" :GIT-BLOB
   "9a7da536a7286f5996bf1720db7f9b9dbf20abff")
  (:PATH "src/active/prepare.lisp" :GIT-BLOB
   "e6739a357bdce50ca6bfda7dcd147ce8ffb790fd")
  (:PATH "src/active/source.lisp" :GIT-BLOB
   "cc25d0713721585fa74d4c1a89a994ef3f753c69")
  (:PATH "src/active/types.lisp" :GIT-BLOB
   "fc4c2d3ac0839aab37b91d4e017cdaf18bc5041e")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "b0230656edbe3dea63568e74a97e5193cab7c54a")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "a1db79505e00f465b0f0debacbcbd8aad60c5b75")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9725836f0c142b5e292fea4d073f5fbc52b99825")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "84b090e318216a832ab684fc5a936c68e465c169")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "93ecc29914d02b4b6066896de8c2590906ca91bc")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "03bdfeeef2e2639030d3509bd6905364c55f345a")
  (:PATH "src/codec/cbor-array-input.lisp" :GIT-BLOB
   "1b028f9e5f945266f1144b664bf206e89f603863")
  (:PATH "src/codec/cbor-array-write.lisp" :GIT-BLOB
   "625b61e204f7485e1015d109426810ef9d92827c")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-float-narrow.lisp" :GIT-BLOB
   "a2424c60204a55c7ec315de4446e41e243a1afca")
  (:PATH "src/codec/cbor-float-write.lisp" :GIT-BLOB
   "5a44cea28eb51016ce5155ebdf5750b93d15a1b3")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-item-read.lisp" :GIT-BLOB
   "e95db7d9f407e9e0039dc8892e4af8065490d99d")
  (:PATH "src/codec/cbor-map-input.lisp" :GIT-BLOB
   "87c9fd9dd6eb1f3ee1b79bdf2957801762601d97")
  (:PATH "src/codec/cbor-map-write.lisp" :GIT-BLOB
   "84887090a1fa543da817bd096528b576f3d58d9e")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "d9c686fef43c16c5cbf85672b2480a3d0340edfc")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-string-read.lisp" :GIT-BLOB
   "446498b0f3b0f014471312eeb01b3d9a254b6535")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a9028c0b30a22367baad2711346a5517089b1940")
  (:PATH "src/codec/cbor-tag-input.lisp" :GIT-BLOB
   "760e81952f8eb3210465a6cea5c0b89c3f15c5a4")
  (:PATH "src/codec/cbor-tag-write.lisp" :GIT-BLOB
   "4680d759cf12aaa61df5823cb86e71ed7379914c")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "159033291735d23258b340f8da17ad6bd001ccbf")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/control/build.lisp" :GIT-BLOB
   "d5aca4f9ade3c126e88709f1ada1a9e39132b6a1")
  (:PATH "src/control/dependency.lisp" :GIT-BLOB
   "144f908c5cafddc397dd8a1cab04cd641d93a32c")
  (:PATH "src/control/package.lisp" :GIT-BLOB
   "e56a6bb83abe9441350baa46573d74c6d55edf4e")
  (:PATH "src/control/preflight.lisp" :GIT-BLOB
   "850a8f3bedb592dad251e36d7e95ad9fa993979d")
  (:PATH "src/control/prepare.lisp" :GIT-BLOB
   "51cdc2f60ef3da074e98f5bbabd1bb1b4ffbd6ed")
  (:PATH "src/control/publication-read.lisp" :GIT-BLOB
   "a5ebb2f8fafe283f3816d48e633ef8471bfbf4ba")
  (:PATH "src/control/publication.lisp" :GIT-BLOB
   "c8c482c65af3a94bea9acc38b3b93f04933c93b1")
  (:PATH "src/control/recovery-publication.lisp" :GIT-BLOB
   "b01545b6647f5dbac8097dcab394260fb7f9d3cd")
  (:PATH "src/control/recovery-read.lisp" :GIT-BLOB
   "430665c20905e5f7d67245e2d7503bb0f9e0c11f")
  (:PATH "src/control/recovery-types.lisp" :GIT-BLOB
   "2ac4f985eec224f17cea5658cd9d42f4aed99cce")
  (:PATH "src/control/transfer.lisp" :GIT-BLOB
   "69bb7c2e27817201c5533fa4d6099a26750a38b7")
  (:PATH "src/control/types.lisp" :GIT-BLOB
   "7eaa6e2298ac264b7d64c1f7a78de8d1fab8ce09")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "9eb660cca8f097e25ca3c1535cace8c20bc1e238")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "f3788232dd7828d3271688399f1d382393301cbd")
  (:PATH "src/dispatch/begin.lisp" :GIT-BLOB
   "bb45bcad39e438aa082e92d01358d1059cc5fd20")
  (:PATH "src/dispatch/build.lisp" :GIT-BLOB
   "9d1c974830e92918b572af978e8a2b4acae257b6")
  (:PATH "src/dispatch/claim.lisp" :GIT-BLOB
   "a9d55f610fbd14b5bff7f9d6c2a6c8abb7ba405c")
  (:PATH "src/dispatch/package.lisp" :GIT-BLOB
   "db21c798588ff4a88be5b69b5fbe72bc84811a46")
  (:PATH "src/dispatch/recycle.lisp" :GIT-BLOB
   "57955f63a0cfc4efc3f7f742fd479c032dcec5b2")
  (:PATH "src/dispatch/start.lisp" :GIT-BLOB
   "4d519c9fba0c085d5789c2883c8d04079e3933ea")
  (:PATH "src/dispatch/step.lisp" :GIT-BLOB
   "36c8c1e84c7329f4a0b24186e09a40b2ce2d2b61")
  (:PATH "src/dispatch/types.lisp" :GIT-BLOB
   "6f3b3841a3158cac6daf70cc8a1ae3984f52566c")
  (:PATH "src/engine/adopt.lisp" :GIT-BLOB
   "f2cc0f5a3263a605de7f50175e362c55158cb763")
  (:PATH "src/engine/compaction-control.lisp" :GIT-BLOB
   "02cbb0127a3e9519ed0dc90730f077ade17fb5dd")
  (:PATH "src/engine/compaction-install.lisp" :GIT-BLOB
   "167777a12cf87a02b36a73c5609d098d9d8d1b46")
  (:PATH "src/engine/compaction-plan.lisp" :GIT-BLOB
   "d255c8440ee3abb0c190801e7c5b2e1a4872b47e")
  (:PATH "src/engine/compaction-reclaim.lisp" :GIT-BLOB
   "00076045f47b9b8a5a4a0aeee449a3a0cc5e2047")
  (:PATH "src/engine/compaction-relocate.lisp" :GIT-BLOB
   "3f316d79bf63b30bb5fa0cbac38927cf2a6e540d")
  (:PATH "src/engine/compaction-scan.lisp" :GIT-BLOB
   "942e0b2ba2be30a2e94efa1c80564dd7159e322a")
  (:PATH "src/engine/compaction-types.lisp" :GIT-BLOB
   "ee6f36958a147af9cdabdfee2ebe77752476da74")
  (:PATH "src/engine/compaction-verify.lisp" :GIT-BLOB
   "57628bb40f5be4c42b4366e81a0662f7f98c0137")
  (:PATH "src/engine/compaction-write.lisp" :GIT-BLOB
   "41cc966628e64d765c8a8f9d132321451025a3bd")
  (:PATH "src/engine/compaction.lisp" :GIT-BLOB
   "1eac672cf412fc36ae6fbfe5d8b4e7b93dcf480e")
  (:PATH "src/engine/config.lisp" :GIT-BLOB
   "354198f7b04489a46d0a67018d181a4c8668a42e")
  (:PATH "src/engine/delta-location.lisp" :GIT-BLOB
   "367601a853f8d2dd155b1dc0002b86d1b4bcdd5b")
  (:PATH "src/engine/delta-types.lisp" :GIT-BLOB
   "539f08cdb3736546b2b1556f81050d6c5d09ece9")
  (:PATH "src/engine/delta.lisp" :GIT-BLOB
   "b865dc6c8be351c3e89fcddbce61a4e0d7a2dd5d")
  (:PATH "src/engine/files.lisp" :GIT-BLOB
   "eda0f6adb8eb34225b6775b8ef666224e753deda")
  (:PATH "src/engine/image-activation.lisp" :GIT-BLOB
   "51ef93215340364bc2c881f3e7efa6a47aac6aa8")
  (:PATH "src/engine/image-auto-types.lisp" :GIT-BLOB
   "8879e3aa9b00d18cb138da9ca6d04028816502af")
  (:PATH "src/engine/image-auto-write.lisp" :GIT-BLOB
   "ac1ad97829a4b076b6f223e9e010c55752bf3066")
  (:PATH "src/engine/image-auto.lisp" :GIT-BLOB
   "0449392da3326308f5697fc231d24d329a691db8")
  (:PATH "src/engine/image-build-io.lisp" :GIT-BLOB
   "fbd185cd56d4d980575c4d0fec5597b715074f61")
  (:PATH "src/engine/image-build-plan.lisp" :GIT-BLOB
   "ccd01ee41d0d7a103680785731c5271a54f6f2df")
  (:PATH "src/engine/image-build-read.lisp" :GIT-BLOB
   "b11e63f292b93ddaee8b0c645d525a175a1906b0")
  (:PATH "src/engine/image-build-tree.lisp" :GIT-BLOB
   "d9a657c2fbdbb294e34fe8ba40c4fe8c8df11f03")
  (:PATH "src/engine/image-build-types.lisp" :GIT-BLOB
   "d2aacfe57703a7a99354657e4823a641d6eabb43")
  (:PATH "src/engine/image-build.lisp" :GIT-BLOB
   "a4c8ad027a796610299f457399f566ac0ca4284d")
  (:PATH "src/engine/image-config.lisp" :GIT-BLOB
   "47becee77666bb573500cc1d23735e627e65411b")
  (:PATH "src/engine/image-discovery-config.lisp" :GIT-BLOB
   "66c7f2c7f7eb87e0147d858c11787ffdd06b14bb")
  (:PATH "src/engine/image-discovery.lisp" :GIT-BLOB
   "aa41ecbc41a335a25fd3f62761147be516ebce6c")
  (:PATH "src/engine/image-maintenance-config.lisp" :GIT-BLOB
   "cbd5f1cdde00a60ee8cd952898c06e205c8edf1c")
  (:PATH "src/engine/image-maintenance.lisp" :GIT-BLOB
   "44bdff3e98ff1176b51b1bbc20bb8f54b94f5f3d")
  (:PATH "src/engine/image-recovery.lisp" :GIT-BLOB
   "f42286cf6d43cd486d9c4a79f764c99c35e2aa37")
  (:PATH "src/engine/image-renewal.lisp" :GIT-BLOB
   "0e6c21fcdec1d316551417b024e1ba5bda472abc")
  (:PATH "src/engine/image-source.lisp" :GIT-BLOB
   "8b7c7ecdebbf07ada9b68037976be5af53a6a106")
  (:PATH "src/engine/index-auto-api.lisp" :GIT-BLOB
   "1241871a3195c1c42b890e08373803a816809817")
  (:PATH "src/engine/index-auto-apply.lisp" :GIT-BLOB
   "7062c70c0f6322cda8de3f089bab2a216dae3d44")
  (:PATH "src/engine/index-auto-files.lisp" :GIT-BLOB
   "2c79ded6eb822d4f238f31cd7756bcdc79d5be7d")
  (:PATH "src/engine/index-auto-memory.lisp" :GIT-BLOB
   "8199f78030cc2d21af63d223c7d9cb99cb22b4fb")
  (:PATH "src/engine/index-auto-migrate.lisp" :GIT-BLOB
   "52e44cd130f7dc77bf6fa0be130dfc4827b4ec59")
  (:PATH "src/engine/index-auto-resolver.lisp" :GIT-BLOB
   "82554d4e3b9382c60bbdb0cf2986a4e75af1dafa")
  (:PATH "src/engine/index-auto-types.lisp" :GIT-BLOB
   "7d848c894841cdcf2abf615cd8140568a264351c")
  (:PATH "src/engine/index.lisp" :GIT-BLOB
   "650e3e008a6e489ebc3972366724edab5a3189c0")
  (:PATH "src/engine/initialize.lisp" :GIT-BLOB
   "8c39b866a402a30b1aa1ef7409e675f367e4ec97")
  (:PATH "src/engine/lifecycle.lisp" :GIT-BLOB
   "eb8dc8c0fa0c8f510502ed95b6d001229f1dcb4d")
  (:PATH "src/engine/package.lisp" :GIT-BLOB
   "2fa6abaec0ae44e0cae76e414df34afdc5eb5699")
  (:PATH "src/engine/preflight.lisp" :GIT-BLOB
   "272b6ffeb63fa9536bade7a0fd48764340128e4c")
  (:PATH "src/engine/read.lisp" :GIT-BLOB
   "658f1224eabea55171889037f09cbd030c9836c9")
  (:PATH "src/engine/record-cache.lisp" :GIT-BLOB
   "6d00296bffb12094dafd46a4ac898c9a20f81dfa")
  (:PATH "src/engine/recovery.lisp" :GIT-BLOB
   "05b64c0a49c59c209af8bac92f6823c193a92122")
  (:PATH "src/engine/rotation.lisp" :GIT-BLOB
   "bc4d8783b4cc930f424cc7312579bcfe3b73d772")
  (:PATH "src/engine/startup.lisp" :GIT-BLOB
   "5245c459ca92fa0f69ff1810befc748fbb303f7f")
  (:PATH "src/engine/types.lisp" :GIT-BLOB
   "a6332ea2bdbfa4e7c87c3c3e3e8390d949b27238")
  (:PATH "src/engine/write.lisp" :GIT-BLOB
   "3b83c17a8bf510c110648b4257fe9b8df43b6bf5")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "93dbc244d3e8a86e64254b31e2954102f65ab149")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "0fc4c81f23e27dabfe52485a3976ec3eb390eb4c")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "e0d503d2ad85689ac6162636857f4e44f2b5c7f9")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "474ddacfc871629aad94b6d59b87de7cd4349475")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "838611d288696767dc539b155fcfefe3feec79e2")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "bbed8c36a799b57baebe6350dd96c3a968dd05e7")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "b27df62179c9f43132c445c82f0c2bf4ee78f366")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "5d4e27472170bfffa85a6e8aac0760236e7fefb6")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "f79bbd85269d50eb929816276353b2fbb85f92c9")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "a36b9bc921e8d58f9cf3a10a8426eb388e710226")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "c066712083a07bc574481ae3a3cdcc996c9303a8")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "3c970d0cbd3866d837c07bd03d7e4e0fae24f21f")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "c048d0e7321d26e5ec3ec4eb7d3bd79b4714aef5")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "7170e6de30721bcb89cb94b56e9d3c579a1269be")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8be80a716738875d5e6fe056c5f3c81d2ffad2e5")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "5560532f4cae67478c11adc65e632cfe3da10ad7")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/crc32c-native.lisp" :GIT-BLOB
   "2e80dc72cce0064a460b8ee78970acae71a9da35")
  (:PATH "src/foundation/crc32c-vops.lisp" :GIT-BLOB
   "0677d1d29c7fc16dbd8bda529cffa5f1076327a8")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "3dee5a43950d683f83deffaa6f329d6dcbc6cfc2")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "6fca7bd583990cf07093243c95f399d294b74d45")
  (:PATH "src/fulltext-admission/build.lisp" :GIT-BLOB
   "ba813f4178d646f412363e8b3f86f7309878a4a1")
  (:PATH "src/fulltext-admission/copy.lisp" :GIT-BLOB
   "43488c42525991544b355bfc061c2c753e866c88")
  (:PATH "src/fulltext-admission/guards.lisp" :GIT-BLOB
   "c4734194dc53a5f98397bd0b35079c5739f95a41")
  (:PATH "src/fulltext-admission/lifecycle.lisp" :GIT-BLOB
   "088b775f74cf633ecb3b84a0c0b9445209cc4b93")
  (:PATH "src/fulltext-admission/package.lisp" :GIT-BLOB
   "74d06aa6d0d0b263b806f678b23cec40b5db3ef1")
  (:PATH "src/fulltext-admission/preflight.lisp" :GIT-BLOB
   "eeff3e04503f0dac81da9816112f2da68e384dc2")
  (:PATH "src/fulltext-admission/query.lisp" :GIT-BLOB
   "a8aac3c938ada73cb2b18abfaf44d7bc1ff4cfa5")
  (:PATH "src/fulltext-admission/reserve.lisp" :GIT-BLOB
   "374c03ecf29417aad8e760dd432ff3e5a6383e4c")
  (:PATH "src/fulltext-admission/row-update.lisp" :GIT-BLOB
   "1d77f5d5c6e1ddb8ab08136d7d7afaf1f79a7f79")
  (:PATH "src/fulltext-admission/rows.lisp" :GIT-BLOB
   "f1c6dc8236477b5de6b2f0e5db4bab8a02fcbe95")
  (:PATH "src/fulltext-admission/types.lisp" :GIT-BLOB
   "b4766a5b561c1a1f3e53bfc9485f72b128dfb1d1")
  (:PATH "src/fulltext-put/append.lisp" :GIT-BLOB
   "df244937278aebfabba27f14555b36476e6d9858")
  (:PATH "src/fulltext-put/binding.lisp" :GIT-BLOB
   "c47d939287b3be63ec090d24bd64903556b2b86a")
  (:PATH "src/fulltext-put/build.lisp" :GIT-BLOB
   "1f4113fb6ce043099672cf72c995b976c9543cea")
  (:PATH "src/fulltext-put/package.lisp" :GIT-BLOB
   "0ffd3fb459d14ef6da0ab6789930b8ee54b78fe5")
  (:PATH "src/fulltext-put/physical-header.lisp" :GIT-BLOB
   "8fbb48b2ceb0ccb9c73b9344e14fbb025174b7e4")
  (:PATH "src/fulltext-put/physical.lisp" :GIT-BLOB
   "f7a1a29690b384cdd8bf791e62ac2d98deb7495b")
  (:PATH "src/fulltext-put/prepare.lisp" :GIT-BLOB
   "5a6929f64ba29f63efa2717a79fb79c93206b74c")
  (:PATH "src/fulltext-put/reserve.lisp" :GIT-BLOB
   "81642e379bb158bed9bec2f0fa9c70190a637567")
  (:PATH "src/fulltext-put/row-reference.lisp" :GIT-BLOB
   "b24f1dc1bd7ea08b7efe05e954cd30190f8a1aa1")
  (:PATH "src/fulltext-put/start.lisp" :GIT-BLOB
   "8c6677841d374a7bfc1834a83ccf610eecce0890")
  (:PATH "src/fulltext-put/types.lisp" :GIT-BLOB
   "c0bb31863f4f17894f85f69df42d5476d988f9da")
  (:PATH "src/fulltext/analysis-emit.lisp" :GIT-BLOB
   "17bcef98c46d7a035d2945be0c7407ed178e3da7")
  (:PATH "src/fulltext/analysis-nfc.lisp" :GIT-BLOB
   "e3e34d111a4cbab7a860d995e0658e154f1a4031")
  (:PATH "src/fulltext/analysis-package.lisp" :GIT-BLOB
   "5729cfba660c391cf9dee6fc3d5e6ccbddcd2552")
  (:PATH "src/fulltext/analysis-properties.lisp" :GIT-BLOB
   "320a03b22e01f755184d3d8b6aa1a61b009ce538")
  (:PATH "src/fulltext/analysis-space.lisp" :GIT-BLOB
   "7ab493596664f1488b369fc0b14b083e9eee31af")
  (:PATH "src/fulltext/analysis-word-context.lisp" :GIT-BLOB
   "023c1d7676f5f1325e7b112ba38a132a010f36e8")
  (:PATH "src/fulltext/analysis-word-rules.lisp" :GIT-BLOB
   "0278fccb36c8320d8b0b11b26e067773b8435e1a")
  (:PATH "src/fulltext/analysis.lisp" :GIT-BLOB
   "496c3196aa6efc23695486f15253f9275b58c1c6")
  (:PATH "src/fulltext/codec-input.lisp" :GIT-BLOB
   "ff8ede224c154fa075b7f1eb53cacecbcc7d73c3")
  (:PATH "src/fulltext/codec-package.lisp" :GIT-BLOB
   "fcd63be08134216e7a0d79c68ba6fc1120415689")
  (:PATH "src/fulltext/codec-plan.lisp" :GIT-BLOB
   "b614382a5beec3c0ccc3134f0e2abffc0fb44e87")
  (:PATH "src/fulltext/codec-query.lisp" :GIT-BLOB
   "1047b265bf2140ea5d14ea55987f1bdfae2f6e0c")
  (:PATH "src/fulltext/codec-read-base.lisp" :GIT-BLOB
   "5a24b81342a564255563e9309efcc9f043aa33a4")
  (:PATH "src/fulltext/codec-read-dict.lisp" :GIT-BLOB
   "5958a63148c0942343fa93fce59a59d614850bb2")
  (:PATH "src/fulltext/codec-read-lengths.lisp" :GIT-BLOB
   "91b77b0ef9cc16fb29c437130453ca97c19de60f")
  (:PATH "src/fulltext/codec-read-postings.lisp" :GIT-BLOB
   "46fc1a96ed8bd3e616392ac6c891a678b4e8f33a")
  (:PATH "src/fulltext/codec-read-term.lisp" :GIT-BLOB
   "bf77c4c7d7f7faeaa68077cc1dfbb8349ff6eeb7")
  (:PATH "src/fulltext/codec-run.lisp" :GIT-BLOB
   "fbe693aa1579466dc55fc03fe88a1bb04d7c097f")
  (:PATH "src/fulltext/codec-space.lisp" :GIT-BLOB
   "48e907be585f73c58fd7fa4e89a0b5cdfbfef309")
  (:PATH "src/fulltext/codec-view.lisp" :GIT-BLOB
   "49a4547d0153a45281e2bd2188891f2c5517523d")
  (:PATH "src/fulltext/codec-write-entries.lisp" :GIT-BLOB
   "035e0c6d0826d7be8e5308c3dbabf9f4b6b94b50")
  (:PATH "src/fulltext/codec-write.lisp" :GIT-BLOB
   "64731ed8f9fc9f1246a62c659b18fa85ae2a0f3e")
  (:PATH "src/fulltext/descriptor.lisp" :GIT-BLOB
   "d53475000e9a1f3f3ab97f29780b526b39c43e58")
  (:PATH "src/fulltext/document-analysis.lisp" :GIT-BLOB
   "5f4635b04bf39a7673c4071ac423f3c23b595c57")
  (:PATH "src/fulltext/document-bound.lisp" :GIT-BLOB
   "6eb42da6fa77f01a38b92559b1eccc32f1313d43")
  (:PATH "src/fulltext/document-config-input.lisp" :GIT-BLOB
   "f9522d52f03c808c9e31903ac6393ba113c487f0")
  (:PATH "src/fulltext/document-config.lisp" :GIT-BLOB
   "4d28290bec4b6bca2f8a79338323fa1e4b2ed617")
  (:PATH "src/fulltext/document-package.lisp" :GIT-BLOB
   "c699e405a2ce6c5a18cc27842352f8ad43647e4b")
  (:PATH "src/fulltext/document-paths.lisp" :GIT-BLOB
   "dc31d23d3316043885526af964aab860fe4a6f45")
  (:PATH "src/fulltext/document-scan.lisp" :GIT-BLOB
   "62df7660d399fe08ccb948a21fe6ceb0bbca507b")
  (:PATH "src/fulltext/document-space.lisp" :GIT-BLOB
   "ab484dddcbd81d464e8739e4aa28a1be667accc1")
  (:PATH "src/fulltext/document-start.lisp" :GIT-BLOB
   "d59279a55290ed8b35e722dd9ee47cef68502a1a")
  (:PATH "src/fulltext/document.lisp" :GIT-BLOB
   "447a0f0d27d1e197483f839e7a03d75bce92585d")
  (:PATH "src/fulltext/format-constants.lisp" :GIT-BLOB
   "cc040653f809c725a063eee35fff6e2f9570b675")
  (:PATH "src/fulltext/format-input.lisp" :GIT-BLOB
   "891ad11bf97386317a7a56d6e81c7d425745dfdb")
  (:PATH "src/fulltext/format-package.lisp" :GIT-BLOB
   "1f72e2d40467a20422c5bfaa2564bb5b84fedf29")
  (:PATH "src/fulltext/format-read.lisp" :GIT-BLOB
   "323807f0a973049dd290dd7dad4d2266301e6e57")
  (:PATH "src/fulltext/format-write.lisp" :GIT-BLOB
   "2b89b266d96de0264d92b164b4d59e4e27079f82")
  (:PATH "src/fulltext/index-build.lisp" :GIT-BLOB
   "54ae060c29f1345430a44b2b378c8cb43039dcdc")
  (:PATH "src/fulltext/index-lookup.lisp" :GIT-BLOB
   "9ef394661c96beef9e4cbf3f2e8e5812ec6828c6")
  (:PATH "src/fulltext/index-package.lisp" :GIT-BLOB
   "20bfb93adc06f0782e20fe842f4805b2249d440a")
  (:PATH "src/fulltext/index-sort.lisp" :GIT-BLOB
   "369d3de6ee0ecee94aadfe6ebbce619b84e8147b")
  (:PATH "src/fulltext/index-step.lisp" :GIT-BLOB
   "9206fd68138b97057494978f7713618063510654")
  (:PATH "src/fulltext/meta-fields.lisp" :GIT-BLOB
   "afaeeadd5831bac5804c57a9b67428a3e3c2eaa0")
  (:PATH "src/fulltext/meta-read.lisp" :GIT-BLOB
   "9a4f5a543e68b9c585126096feadaa754f10c6d7")
  (:PATH "src/fulltext/unicode-tables.lisp" :GIT-BLOB
   "a0b079ee4bfba2d1a6ca83b4bb9c555462b75b3c")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "4ebfa97211671287aa2c972a8923654c2390d0f9")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "8dcddeb0536c1104af92c722ffbfab2059601c74")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "a957b1f91e495637b700756736a96baafd233abe")
  (:PATH "src/get-directory/sources-read.lisp" :GIT-BLOB
   "fbb8b26fcfd9de939bf4f3c61d5fd0c5c335754c")
  (:PATH "src/get-directory/sources-types.lisp" :GIT-BLOB
   "ce426ea6409d588e0ca6add8e6c95a1c594e0c89")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "564cdaea8cb9aae672cbbd4328ea7e76b4430f4a")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "4a4b68bd8da051f2673def534aadec8febb11caa")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "3a3dae662d06b1e2b6bc936b227894d2f0396b6d")
  (:PATH "src/get-resolver/active-init.lisp" :GIT-BLOB
   "df5a754f6cf7b5c61ea4c9dc1df1c94b33e3f106")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "93a32b00aef08a29b4ae7d638eaf16cc68a284ff")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "a71e3a410808705bb3393b4839a71fb7f54b9d48")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "0ca652d2dc2a7a2a4474e4c32adc90e9b2ac13d4")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "75a6c0dae936931d0d13623291a17ee1596c084f")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "d6854c7ec8b7125b33391a27760be11cd01c89db")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "33d7b898b5f5a7b20c8112484191c14df44b770e")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "c46dd43cba38117155ee217a08c02448a0a0d3ee")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "b747d3a4b6517d7574225dc26cab8703747f0e05")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "c0f1a6b32a1725b6e9ae05e00e130a3e0097be78")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "7f2f8b496d65b70d83eee58c19b5b679b5d632ba")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "77b07c57b7e57505ff35724dc36a90cb554679ee")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "76ac8e35c01b887cec70ccd78d29d87690557eae")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "2a393aae53a7b13b567dc5a44b5d0d1da83714f3")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "01233e1565f301c96ce6ee3bb33a50f10cb2e937")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "7a3600dfe26168cc956e1ef62d07221a6d51a61f")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "fe1475f001e9b5719980f7e7507f735edc7e208a")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "4dd3840c525e54acc7d1577b45aadff217a77c4b")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "f1a5060bb6071bec929476a9151fba0ec68e1604")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "db2d060ad9f747deaa7f5016d09eb8ff0299d36e")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "9827cb4af0343e4241d2fed6e3c62830455f8749")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index-disk/api.lisp" :GIT-BLOB
   "daeaeeaef31f8cd903ad02f6cd60193611714643")
  (:PATH "src/index-disk/balance.lisp" :GIT-BLOB
   "c1189c5fcb2a3389004a0b2d19357c4f93e9e026")
  (:PATH "src/index-disk/build.lisp" :GIT-BLOB
   "85d0f397ea8062235c537806caa21fe03d790589")
  (:PATH "src/index-disk/cache.lisp" :GIT-BLOB
   "e61013c7d4d60aa0711024615dcdf42476c69ecb")
  (:PATH "src/index-disk/copy.lisp" :GIT-BLOB
   "b26cdc656f9112ab344983c5a7f473e97442c8e3")
  (:PATH "src/index-disk/mutate.lisp" :GIT-BLOB
   "ac7a72b3d506de92ec80bbb9653904188b98d8f8")
  (:PATH "src/index-disk/package.lisp" :GIT-BLOB
   "23536e507f5fee4b20554184835addebab23ba3e")
  (:PATH "src/index-disk/read.lisp" :GIT-BLOB
   "20599afde6adbb9cd9decdc852f0de469a5d72e5")
  (:PATH "src/index-disk/relocate.lisp" :GIT-BLOB
   "34399623c2c31e68c16d069f57d1b7e6b9bd4ab2")
  (:PATH "src/index-disk/types.lisp" :GIT-BLOB
   "df13ba528aa6bba71981c44b8fbf14c69fa4551e")
  (:PATH "src/index-disk/visit.lisp" :GIT-BLOB
   "ec8ae71e8f2d27b7e2a49cefbeb2c86e7367bbe2")
  (:PATH "src/index-disk/write.lisp" :GIT-BLOB
   "7b6e37218626e782f22cc2903328c40f23d52fac")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "64be10d7b2dc85c6dd6c31becefbb6ee3ae74d21")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "ec86f5be5b5d465d5e32dc3c492cbc0c90daaba5")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "6dc9775423900dd855c71c06079cdc5e69411c5b")
  (:PATH "src/index/image-codec.lisp" :GIT-BLOB
   "e3b96642767e7e0d116481f41e279274646c2b12")
  (:PATH "src/index/image-constants.lisp" :GIT-BLOB
   "6c123802b75884937c2e9bcd7cfe4e214173ab9e")
  (:PATH "src/index/image-publication.lisp" :GIT-BLOB
   "7733d528d07acc24ec9f8c00c6767c2e3b09975e")
  (:PATH "src/index/image-recovery.lisp" :GIT-BLOB
   "ea1a681932b0fa2a1a7a3f44238816657505e55c")
  (:PATH "src/index/image-seal.lisp" :GIT-BLOB
   "f788cc87a9f2f963210d5bb54310f359df78adba")
  (:PATH "src/index/image-types.lisp" :GIT-BLOB
   "69315a89f5b007ebfbb838bc87dde37221fa69c8")
  (:PATH "src/index/image-verify-edges.lisp" :GIT-BLOB
   "2bdfd22b88408ff57efe6dc6e8c61fb5bb4f2fa1")
  (:PATH "src/index/image-verify-entry.lisp" :GIT-BLOB
   "6d240011e6b3f2c8795537bdead86763cd5a0dd5")
  (:PATH "src/index/image-verify-key.lisp" :GIT-BLOB
   "c7bde57d3d327f32321c29d358cb84eb90f1eadc")
  (:PATH "src/index/image-verify-types.lisp" :GIT-BLOB
   "a7f39bfa563402bb113c3430c5229926c0354ff9")
  (:PATH "src/index/mode-package.lisp" :GIT-BLOB
   "53da3230da115c0d702cc762d3f2ab69e6af253e")
  (:PATH "src/index/mode-policy.lisp" :GIT-BLOB
   "2acdfd94b5a0e5bfc04135cf9f39b4a72ef93482")
  (:PATH "src/index/mode-types.lisp" :GIT-BLOB
   "9e42e46cfa22a400da7635e45ab7c8192e25204c")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/page-body.lisp" :GIT-BLOB
   "c4143fd0c6350883ff10db74c2f8b9c7320b7600")
  (:PATH "src/index/page-bucket.lisp" :GIT-BLOB
   "f6f9c5b2076c8f3c1ae9dd1c23bdab00cbd69005")
  (:PATH "src/index/page-build-config.lisp" :GIT-BLOB
   "8d34342f4e34d3edacf6edb07a3059b8cd199d62")
  (:PATH "src/index/page-build-emit.lisp" :GIT-BLOB
   "479818ed5d901eee9ecfee456e39b66d4f02c620")
  (:PATH "src/index/page-build-plan.lisp" :GIT-BLOB
   "86bf82eb3913ca8dad0f7e1dbe1e9016da5b18a9")
  (:PATH "src/index/page-build-proof.lisp" :GIT-BLOB
   "f86fd7f850a9f1559e9af7fdf445971e07020eff")
  (:PATH "src/index/page-build-types.lisp" :GIT-BLOB
   "4fb20f67faa960088aadf112246f84a98f58117a")
  (:PATH "src/index/page-build.lisp" :GIT-BLOB
   "b632710d7d32cac680b10a9312bd9c4878024fd0")
  (:PATH "src/index/page-cache-types.lisp" :GIT-BLOB
   "bbea574ced62361daf59b1d03fb6f06cdb840991")
  (:PATH "src/index/page-cache.lisp" :GIT-BLOB
   "e66d3fa17f78dde39eff02eb8993a7c68f9ba9f5")
  (:PATH "src/index/page-constants.lisp" :GIT-BLOB
   "de904d211f301a087b3d1d53fa47a8054ccf2eb7")
  (:PATH "src/index/page-lookup-key.lisp" :GIT-BLOB
   "9e2e8f43e9a787b7a9223d57dcbab979dbbc233e")
  (:PATH "src/index/page-lookup-types.lisp" :GIT-BLOB
   "9abfe5a3024425124a8e9cc3b0a7087ad5cad1ff")
  (:PATH "src/index/page-lookup.lisp" :GIT-BLOB
   "9dde416acf27111c21e3f439dd2c948d27517eb7")
  (:PATH "src/index/page-package.lisp" :GIT-BLOB
   "d3f1ff0b939b5a4a1e2df7f22fb04077886220ea")
  (:PATH "src/index/page-read.lisp" :GIT-BLOB
   "0386ec4059fbb6a01d34a137e5bf5a6f44a6f589")
  (:PATH "src/index/page-types.lisp" :GIT-BLOB
   "74a9db44b348db25a046c9250f092a0e03f82ca0")
  (:PATH "src/index/page-validation.lisp" :GIT-BLOB
   "a45eb2aa3d449c9500a95950709cb6019fb8f76b")
  (:PATH "src/index/page-write.lisp" :GIT-BLOB
   "6206be6610c55d48389763a3205ff80ebd79a6d8")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "27c03d2d3e8bfb6b93088bb55bd6e615350261d0")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "83fe7ca83cad1b84f41a579d56bb02ee0bac881e")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "86debb0798063a5e05be0a96f125dece7edd0f0a")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "5afb91ab551d915d29f6630573a17328839cc616")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "099d59bb9acc155380a3baaa3a10816e0902d8ca")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "d054587f29d5108d65704fe8b5b6794178923902")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "7cc651a3e3de17decfe71f3ee9b826dfa7b3ca2f")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "fde846254989ef432159c1ffcfc25fb3f950dbcc")
  (:PATH "src/index/primary-restore.lisp" :GIT-BLOB
   "252bd2cb57700c33fd4ec94749ea6f0b80ae6817")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "179de5b6f466cfcb72c719c49a0e885b5bcf6a12")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "621a82743aceafa1653340330e413bc902c58ebb")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "0187f4d9603d23a6ddb0a76d282af9c811080534")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "589e1557b2906a15c6c874f126968669206ceed9")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "bebb4f103854e0b3dbfc248cae5b82cdeafb0b57")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "ad43248f2f9ec4978a07df5bb696c49a1c055ea7")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "6a55454412edc8466e9c7972f9c81d9a3c945697")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "d42c883908d8a8c9c467342b8977498f38dcf33b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "83bec7e5e8d66f78d9b127c5310b2058b3c3fed6")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "ab3fd8e8abe4fd803038cf11e13c3fef75a8144b")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "0e8ca5847c6683a89cdd47e3476665b1bd46e6da")
  (:PATH "src/io/cpu-build.lisp" :GIT-BLOB
   "0dd046093289729dbc7817a3eeb7dff004f0e9fa")
  (:PATH "src/io/cpu-features.lisp" :GIT-BLOB
   "80653c6c8871127b3d76cc631d47ba0e711b6e5d")
  (:PATH "src/io/cpu-package.lisp" :GIT-BLOB
   "baf8aa6f2ef5231eb6462bca65d83ac1886d09e5")
  (:PATH "src/io/create-relative.lisp" :GIT-BLOB
   "eb4a8c292b30a3083cd256eda697b05737553022")
  (:PATH "src/io/derived-remove.lisp" :GIT-BLOB
   "a0631348bc17fc4e5c1638522be73ae87fa53a97")
  (:PATH "src/io/directory-lock.lisp" :GIT-BLOB
   "f0135b3b43625d9535db6196507b55154d36f852")
  (:PATH "src/io/directory.lisp" :GIT-BLOB
   "8b3fb30b5fa092a5f88ce55cbcf5ebfa6bddf993")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "9b04b83cf53f493aaf75d1c19a6d5f9f4ee0971f")
  (:PATH "src/io/identity-types.lisp" :GIT-BLOB
   "d53f8c4793af7e98dcab62ee5c94571dd8d520a2")
  (:PATH "src/io/identity.lisp" :GIT-BLOB
   "0cb49ca63800c1fc25bee5bf94c2811969511a07")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "9ea7d77f1bccbb7051123ac2e5793d38b770ffbf")
  (:PATH "src/io/namespace.lisp" :GIT-BLOB
   "1f73f6bf5c4b8f12064b515008d6c8f9076518ce")
  (:PATH "src/io/native-create-relative.lisp" :GIT-BLOB
   "9d715484a72332fb056b8102d2277140128b2f59")
  (:PATH "src/io/native-directory.lisp" :GIT-BLOB
   "95ea1018b8693a89e0967f9a7a6dea95542d6005")
  (:PATH "src/io/native-namespace.lisp" :GIT-BLOB
   "599c21713f3d82b6bc9faac71e42a45da0e6cd90")
  (:PATH "src/io/native-open-relative.lisp" :GIT-BLOB
   "d924a8a202ab02406cdae147cfa0cb742a0917e6")
  (:PATH "src/io/native-publish.lisp" :GIT-BLOB
   "d62f716c3965b838e0cdb7a629c78bdf845bbdc2")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "37f1e1782e0e3580447aa0ef56cb0942cfbd0e66")
  (:PATH "src/io/open-relative.lisp" :GIT-BLOB
   "e712b098ddbd883b77382c60b1b511427e8c4db7")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "c0be7a664e6642b7dcc6362d6194090fa9a8290e")
  (:PATH "src/io/publish.lisp" :GIT-BLOB
   "cb759a6c4c6d4b9300c1bb9e1e7b7d781f629f65")
  (:PATH "src/io/readiness.lisp" :GIT-BLOB
   "8ae8de38729e3866227360cc1cf6022c9220490b")
  (:PATH "src/io/rename.lisp" :GIT-BLOB
   "38a7d50880a012266e59eb915edafe64f2047e4e")
  (:PATH "src/io/segment-remove.lisp" :GIT-BLOB
   "8530ef67554d751b20d1004a9af49f20b8fc1861")
  (:PATH "src/io/stabilize-preflight.lisp" :GIT-BLOB
   "290915923be47b7739c3f44560a62f9819c7a26e")
  (:PATH "src/io/stabilize.lisp" :GIT-BLOB
   "504c9dca2fece31bc79f8788f7524d7397a1fee2")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "b66a02dbc2eda6d43388a0946ae46b795efb2a76")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "8e7b3506c6f1da4493bba4817d8b1f6c57585aaf")
  (:PATH "src/local/cli.lisp" :GIT-BLOB
   "801ea182eab95273f82e3b5687605dfbf31aef75")
  (:PATH "src/local/client.lisp" :GIT-BLOB
   "e7f09f4789f50fb79aeef0722c9461f0915cb084")
  (:PATH "src/local/dispatch.lisp" :GIT-BLOB
   "143123455d4733f499a652b174f120da18eec3ea")
  (:PATH "src/local/native.lisp" :GIT-BLOB
   "380f655e5da39eaff4daeef4c6eaf63217762a48")
  (:PATH "src/local/package.lisp" :GIT-BLOB
   "74489fef066b33ac706cb0dd8c757d440e0bfebf")
  (:PATH "src/local/readiness.lisp" :GIT-BLOB
   "bbc9fce59ab612aa4dd003d90a854506c7b047f1")
  (:PATH "src/local/server.lisp" :GIT-BLOB
   "4b9672242fb9e0a0f0d46e47ff6489ff9870e469")
  (:PATH "src/local/state.lisp" :GIT-BLOB
   "de28dd14714908a96f1355a8aa3f9d8953900134")
  (:PATH "src/local/wire.lisp" :GIT-BLOB
   "60a5c872e2da0baa0fee22fd4909b66342c2c387")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "fdeac572e64c3591208a87872b8aa9d520c3bde7")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "74ebd63accc8216dfe5a1794c0e430bb9bccd29e")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "a05a5732511ffca3591110f617e3a19be819b47b")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "158b5a6d1eb171d07bd4f67addc2f4be5495d54b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "06a0af0e813b9c22ce98d523d42c031c79ca3734")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "95f5a8c59ff1fef05bcd3fd220d6a14d9c332d61")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "e5130ba55ee942238a5a98ecc51e07725e1c9655")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "2de7b390c89ab19f8be03767ecb07af8fe1e4fb1")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "172a43f86726ec68af730700c99098d66500ad66")
  (:PATH "src/recovery-active/build.lisp" :GIT-BLOB
   "0fa0e554f7e3aa6990d861dec7cbf8408db28068")
  (:PATH "src/recovery-active/closure.lisp" :GIT-BLOB
   "326b2070076e6e9a8d8ee66567d05b5c19329467")
  (:PATH "src/recovery-active/csn.lisp" :GIT-BLOB
   "42b1279ccd9910816bd8d0887b60bcfe9b6e252a")
  (:PATH "src/recovery-active/frames.lisp" :GIT-BLOB
   "3d01c07ff8118b92e5de7b31ca72b19db5ec72ff")
  (:PATH "src/recovery-active/package.lisp" :GIT-BLOB
   "474cd54f2a31f4ded95fd723b4170bee8addece4")
  (:PATH "src/recovery-active/publication.lisp" :GIT-BLOB
   "38542ec938fd3409d73d7531e90fc6474ef42fad")
  (:PATH "src/recovery-active/query.lisp" :GIT-BLOB
   "e2a5aea0f5a97670cc20a583ed312c89df1c7187")
  (:PATH "src/recovery-active/read.lisp" :GIT-BLOB
   "f801950d67755cd15804ef43f1461d435eda54a6")
  (:PATH "src/recovery-active/resolve.lisp" :GIT-BLOB
   "66f4ada585e085a8403d4cdbc9a3dfee31754bce")
  (:PATH "src/recovery-active/types.lisp" :GIT-BLOB
   "069ca4b815c98d82695dd7eb9337a83c5f35b98b")
  (:PATH "src/recovery-archive-csn/build.lisp" :GIT-BLOB
   "ea5a6abf3d6b0817cfa99db490e9e5df57cb200a")
  (:PATH "src/recovery-archive-csn/package.lisp" :GIT-BLOB
   "bacf4fc95e38a8d0416110c6b87b506d561a7e59")
  (:PATH "src/recovery-archive-csn/preflight.lisp" :GIT-BLOB
   "a7a20c65ba54da28dd88c941736fb374065d580f")
  (:PATH "src/recovery-archive-csn/query.lisp" :GIT-BLOB
   "28f8acd47abad20efb95ec0ea8bd765bfa10baff")
  (:PATH "src/recovery-archive-csn/series.lisp" :GIT-BLOB
   "f8eb49763d533cd34cdf05593d2416a63c5f1d0c")
  (:PATH "src/recovery-archive-csn/types.lisp" :GIT-BLOB
   "d30bb8cb36fd1c64a720073fd3f4b4921e507cad")
  (:PATH "src/recovery-archive/active.lisp" :GIT-BLOB
   "5eb16b6f93d24ac3c6f06af8ed3c005328b457a5")
  (:PATH "src/recovery-archive/build.lisp" :GIT-BLOB
   "81a581f63c21154b8a55f2f429ec28ee32a659b3")
  (:PATH "src/recovery-archive/package.lisp" :GIT-BLOB
   "82c707853b1a5b2b6d657e120c7e0ecb82404134")
  (:PATH "src/recovery-archive/query.lisp" :GIT-BLOB
   "8ae65f7a41d2b4a395d6e6a1829d334dfbe88878")
  (:PATH "src/recovery-archive/read.lisp" :GIT-BLOB
   "07ee8571028ca0ec5f754ec9f8478077650ee48d")
  (:PATH "src/recovery-archive/types.lisp" :GIT-BLOB
   "80d29b79c185d0007d0b0e4baa913ed18ec0524c")
  (:PATH "src/recovery-bootstrap/build.lisp" :GIT-BLOB
   "60d549030aa9d16b823fcb98398f14cd3786f73b")
  (:PATH "src/recovery-bootstrap/package.lisp" :GIT-BLOB
   "29ce39efa53a72cd766810b81a08c9a2f86afc91")
  (:PATH "src/recovery-bootstrap/preflight.lisp" :GIT-BLOB
   "601685cad9fd3829ea36672e86b94952f3fe4493")
  (:PATH "src/recovery-bootstrap/shape.lisp" :GIT-BLOB
   "56e6694b910c05854961e920deeb0da390d4a428")
  (:PATH "src/recovery-bootstrap/stabilize-preflight.lisp" :GIT-BLOB
   "5c05f4f7b52c72cce8f3a086a64c4d190e7de36e")
  (:PATH "src/recovery-bootstrap/stabilize-shape.lisp" :GIT-BLOB
   "649080985356be430b25c841c7d345e9d24cb543")
  (:PATH "src/recovery-bootstrap/stabilize.lisp" :GIT-BLOB
   "2ef2dda4858003135215d7d36f816f4929d214a3")
  (:PATH "src/recovery-checkpoint/build.lisp" :GIT-BLOB
   "c274d47f45d845a6e16049e2a573e8d9d76fbc3a")
  (:PATH "src/recovery-checkpoint/order.lisp" :GIT-BLOB
   "a265f08779f2abc94be058454cf75643c33272ca")
  (:PATH "src/recovery-checkpoint/package.lisp" :GIT-BLOB
   "7b191ecff3dbac6b5f690ad221c68b4762a9f0aa")
  (:PATH "src/recovery-checkpoint/preflight.lisp" :GIT-BLOB
   "61e245a5495de984a94fef573f88d11245e86b71")
  (:PATH "src/recovery-checkpoint/sections.lisp" :GIT-BLOB
   "eb05b6c58fe3131fbd597dff5655e4a476b55092")
  (:PATH "src/recovery-closed/build.lisp" :GIT-BLOB
   "bab6c80812e70ffb31a59f29ffaaa6f90678cea1")
  (:PATH "src/recovery-closed/csn-serie.lisp" :GIT-BLOB
   "078d9bbd66289b667c4273053f706a3a2af120e6")
  (:PATH "src/recovery-closed/csn.lisp" :GIT-BLOB
   "41144f854694ff9338e0067d2f59b3312119c5b2")
  (:PATH "src/recovery-closed/package.lisp" :GIT-BLOB
   "49ac245e2430e719b1d417b91b0ffcd53555e47d")
  (:PATH "src/recovery-closed/publication.lisp" :GIT-BLOB
   "fc512bece4fead39a0c75c943cc5d10bbfb810b4")
  (:PATH "src/recovery-closed/read.lisp" :GIT-BLOB
   "08bcf5a490ceba1ae7a94258f1c0bd9ca148cdaa")
  (:PATH "src/recovery-closed/resolve.lisp" :GIT-BLOB
   "2f107b18e7060dc54e902dbe0363d836285ace5f")
  (:PATH "src/recovery-closed/types.lisp" :GIT-BLOB
   "a403121cd1459db7eb753981a402152615541caa")
  (:PATH "src/recovery-closed/verify.lisp" :GIT-BLOB
   "bac75f2ed61947826ca194cf57f8d2feb003f7fc")
  (:PATH "src/recovery-replay/package.lisp" :GIT-BLOB
   "8639d959e29e9f36270a94831eace49f6535a863")
  (:PATH "src/recovery-replay/read.lisp" :GIT-BLOB
   "05eade0aed1e83cf2df5f5e2bab563d31c95081a")
  (:PATH "src/recovery-replay/resolve.lisp" :GIT-BLOB
   "85eb7133fe1463016604e6a6c9ca26dea7bb5633")
  (:PATH "src/recovery-replay/visit.lisp" :GIT-BLOB
   "0c94187caae5986c8481cf1a8e8bc060db2a7b53")
  (:PATH "src/recovery-selection/frame.lisp" :GIT-BLOB
   "101813cb3536365ac914f10e926f424dec18647e")
  (:PATH "src/recovery-selection/index-preflight.lisp" :GIT-BLOB
   "c3d336e63fbb2b5d972a314a86edd123f050aa7b")
  (:PATH "src/recovery-selection/index.lisp" :GIT-BLOB
   "b4b3488404b09fd1df4f351910043b333c1f355e")
  (:PATH "src/recovery-selection/key.lisp" :GIT-BLOB
   "f751a1ed921903353ab48e52e9fa24d374202ed1")
  (:PATH "src/recovery-selection/package.lisp" :GIT-BLOB
   "9dd583b4bf868183f7555b1e4f7c29f2a13c244c")
  (:PATH "src/recovery-selection/read.lisp" :GIT-BLOB
   "04903a7aa14fe3c332bad4255ff62f87d2e69b77")
  (:PATH "src/recovery-selection/select.lisp" :GIT-BLOB
   "dc4345cbad0fd4223eb50ed2d0ed6bcccb8ec709")
  (:PATH "src/recovery-selection/types.lisp" :GIT-BLOB
   "85930de29d2bc071ea7bbb8677d9aa0ac4e1310e")
  (:PATH "src/recovery-series/build.lisp" :GIT-BLOB
   "998f3c94e5ec1fd83f6146adc88f16350e1a941d")
  (:PATH "src/recovery-series/entry.lisp" :GIT-BLOB
   "a37b7c87eff82670540beb78aa78cb40fab88455")
  (:PATH "src/recovery-series/package.lisp" :GIT-BLOB
   "51f3d64796df1a2180cb977adb8a094e7c7fd94b")
  (:PATH "src/recovery-series/preflight.lisp" :GIT-BLOB
   "0daff10989f88386221d11ff4123384a67092075")
  (:PATH "src/recovery-series/read.lisp" :GIT-BLOB
   "d7ec011280d40883408a816425210f60f4ae4561")
  (:PATH "src/recovery-series/stabilize-preflight.lisp" :GIT-BLOB
   "4e6d9e8047e76ce2fa5324ebca9456d29bd69c2f")
  (:PATH "src/recovery-series/stabilize-set-preflight.lisp" :GIT-BLOB
   "81cc2dcf0e684ccc710e51b221b84c10f057db8f")
  (:PATH "src/recovery-series/stabilize-set.lisp" :GIT-BLOB
   "7fe9646c0721b02d48f8ee99cf3f2e5fa020d4c5")
  (:PATH "src/recovery-series/stabilize.lisp" :GIT-BLOB
   "1fe16c3863409635d882ebce5a9f5abc03ad5ecc")
  (:PATH "src/recovery-series/types.lisp" :GIT-BLOB
   "eb8d4a347b96aca4e5277435fe1361ed794f39b6")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "d7ac44761869f57e333497212510416fd1e794c9")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "58a3e620a8def39d2b24cd210d9283184c247ed2")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "b30dd16f31dcb00316d6983c7cfc5cb2948ce0ee")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "54b5092b76b1c609ee195c44bd9206c1800542c4")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "c7bd0b41e7a84ef73829aeaef3a113f12e7a6031")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "c2fab3b7b2cec568adfe88f0037fc216f83765c9")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "2059363677925a732eb1c70fc1ed1be94d715ea9")
  (:PATH "src/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "7b7f3c4c1bbcd252583249b650f82ab968409e24")
  (:PATH "src/recovery/inventory-directory.lisp" :GIT-BLOB
   "4f253cf7dbe6dad5814749ff53d40759ab882d73")
  (:PATH "src/recovery/inventory-id.lisp" :GIT-BLOB
   "c6dabcd733010fe6966aa1d27656b0760744e55d")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47bc32082a709eb46a5fdb5a5b3011d2c4377f80")
  (:PATH "src/recovery/inventory-sources-build.lisp" :GIT-BLOB
   "149e9ca5fc1bf3ed1f473beb075d5c35b6099886")
  (:PATH "src/recovery/inventory-sources-query.lisp" :GIT-BLOB
   "9742c023b3347d38f678c7a1752a9cc37b665996")
  (:PATH "src/recovery/inventory-sources-types.lisp" :GIT-BLOB
   "b52908d02b1cda451190be58333ef9c9508fddf9")
  (:PATH "src/recovery/inventory-sources.lisp" :GIT-BLOB
   "3619190b49dcbaa32ef4dd2111995df5beace5c5")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "1cbb826a8999579a98e51b9c0ecd1cd6a6ff9661")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "1a98289ea132f2b68309efb3a7552f99a514796e")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "801976598bd390814c4ddfaf00377ee38369405c")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "2ddd4fb6d4c1717a25c369c6a7252f9f80769221")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "9754b563a1d0fbfcda0f306e94b1b6d0257dfb0e")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "43af5d7e8cf2c8465492531133ea9647f614e613")
  (:PATH "src/recovery/manifest-transition.lisp" :GIT-BLOB
   "c871c345eb51367427adbb9bda778a6857a97510")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "40c49f4692e11b4c7f9f55b93bae69210adbdcbb")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "eb0e60664ad7abeefde7a4fc81fa7b3fa38ac57f")
  (:PATH "src/runtime/active.lisp" :GIT-BLOB
   "d7889b0103e18eb47878a88c760cae38de48b3fa")
  (:PATH "src/runtime/build.lisp" :GIT-BLOB
   "4fbf71ebd764f7d90977d027372437e113fdeed3")
  (:PATH "src/runtime/closed-preflight.lisp" :GIT-BLOB
   "5e10ae83ae0e4cd3adbbdae389629a0a854182a2")
  (:PATH "src/runtime/closed-transfer.lisp" :GIT-BLOB
   "3db2e73c10bf24d3931cbf993f240aac45e88e0f")
  (:PATH "src/runtime/closed.lisp" :GIT-BLOB
   "b06f0ae33a9c084c5101cfa5170e358bd4f7fe55")
  (:PATH "src/runtime/package.lisp" :GIT-BLOB
   "5eb61dac53e09bdaf493680967ab65938b6b8f63")
  (:PATH "src/runtime/preflight.lisp" :GIT-BLOB
   "7babef89ceacca9a7c8fac7068b54f653a4a3c58")
  (:PATH "src/runtime/query.lisp" :GIT-BLOB
   "34a7a4ebe5d0baeb93acca991f02a38b0cad2204")
  (:PATH "src/runtime/types.lisp" :GIT-BLOB
   "19fe3cc6004382550ea7939c5bf100d1fcc92607")
  (:PATH "src/scheduler/build.lisp" :GIT-BLOB
   "a55b8e7089ba3880ffa69cee4adb13dc0543069c")
  (:PATH "src/scheduler/lifecycle-build.lisp" :GIT-BLOB
   "7dfa330d606ef9c4dbceeb83845a32e75eb62fe6")
  (:PATH "src/scheduler/lifecycle-read.lisp" :GIT-BLOB
   "3b7ece551dae47957d9350c49285617d60b6ee3f")
  (:PATH "src/scheduler/lifecycle-types.lisp" :GIT-BLOB
   "5a03c1176d6bc019bcd230b0fd665cc48d555395")
  (:PATH "src/scheduler/lifecycle-update.lisp" :GIT-BLOB
   "47d323541ba45f5fb507ebcdb2eae9dd701533a2")
  (:PATH "src/scheduler/lifecycle-worker.lisp" :GIT-BLOB
   "8ae274af549a3464fd5f03d64e3c10ac73145630")
  (:PATH "src/scheduler/package.lisp" :GIT-BLOB
   "cadff5f2e29e7c5b625b95f9387faf29aad02178")
  (:PATH "src/scheduler/policy.lisp" :GIT-BLOB
   "37ed8717cf05ca8f03c06204641f47af18858a7b")
  (:PATH "src/scheduler/pool-claim.lisp" :GIT-BLOB
   "9ba00e2b77cbca2189e947e00b435fb81145668e")
  (:PATH "src/scheduler/read.lisp" :GIT-BLOB
   "ea882e41d231cc0dbafc9eac66bdd1f935433f00")
  (:PATH "src/scheduler/types.lisp" :GIT-BLOB
   "6fcd3d494dc339f8061a64fcce4133b9c86708b3")
  (:PATH "src/scheduler/update.lisp" :GIT-BLOB
   "eb0ad7a3abf119d733ae571d98695980ca4fe694")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "b1aeaa0032d7418cd3c9a7dcbc35add751fb17ce")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "5b189fb0ff0e54abaf72adcb05e5da58ebecb741")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "f81c0946f3e173fa6bf87c24e7c51999afc46363")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "6fd26253982dba01e9eef2702c5f4ede6ba70659")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "95cf61b5df1cdd57975f64a05f890528568046b1")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "79cc08666f83630adba9cab148bb71c2f6d46253")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "f21cae5c4f5cfd94d5d4b6a437ac2ede15750b5d")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "4d09a75d977a0eed0819e7c7d61737d245514b00")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "dee5f67f723edb5ba47b78e68baeee49eb56015c")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "18a29843546af6fc28fa36742a175fc3e6f19e1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "3b6335d3c665f5fe66771242c4d43db3de10b333")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "16700994fa5959633b21d4c7eb21483cd489f0c4")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "2a15783bbd1f5fdd1adb0ae4a045449970f46650")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "d7c667389bf8ad8ec4a04ce2b1bc9ec90e64a54d")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "fd552f6657ade1482eeada765c0880b6afe8a73f")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "6643873870526ee603a5c5b554a91650e5be0e6f")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "028c7b1111e43c0749479067451894b38479a7ec")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "10af1f2b835f387f7c5c69011b712c37bce142f9")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0548df3e81bff3332c67897fc70d7aece4c822ea")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "0e6f1849a77fd2de1109e3576f174f13e2eca665")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "05cb8e127c9384da1c40d21c7566f5d57b705ecf")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "65b17519d6d6e5d9e104bc37b2c4eb4d3b93f132")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "51110c6784e99fc94ddf5a2344e0d85262c297d5")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "cad0373b4932d1b28a19b940936a817774de9eae")
  (:PATH "src/wal/frame.lisp" :GIT-BLOB
   "2f2f1af60a399d9263f15ce4565502da1c70f173")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "17858cffba82609484a6f4a32d082d14ceec1c4b")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "e0ea179069a7b297c7c26f6c294c7d4aea3db671")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "d9f682a05cf5adb22850728a839228f02744c5f2")
  (:PATH "tests/cache/README.md" :GIT-BLOB
   "3836e59b86c5a731e772fbf0a6cca376b14806af")
  (:PATH "tests/cache/guards.lisp" :GIT-BLOB
   "af881fd91c3820ab19d1daa2d56f1fe57257d08f")
  (:PATH "tests/cache/support.lisp" :GIT-BLOB
   "fd829e7352ba878e73df30d979e9558ff6ccba14")
  (:PATH "tests/cache/threads.lisp" :GIT-BLOB
   "ca03c59f0fada09cae8c452fed6490de32d4a3a6")
  (:PATH "tests/ci-catalog.lisp" :GIT-BLOB
   "15b3b3126a8dc57fe98d4dccd5c85d1fcb88204b")
  (:PATH "tests/codec/cbor-array-write-support.lisp" :GIT-BLOB
   "2a47078354c45a5775f48f6dd8f5d784da7de202")
  (:PATH "tests/codec/cbor-array-write-threads.lisp" :GIT-BLOB
   "43bac6c9604140af2594d85b76c14c3101b6925b")
  (:PATH "tests/codec/cbor-array-write.lisp" :GIT-BLOB
   "b13f58264f3cd97e1947ee52936732a7fcebe672")
  (:PATH "tests/codec/cbor-float-write-support.lisp" :GIT-BLOB
   "5416b62340ae8f3332915f8891529d95549a5fba")
  (:PATH "tests/codec/cbor-float-write-threads.lisp" :GIT-BLOB
   "3b0840150945cd4f118516b1d6d61524fa6856fa")
  (:PATH "tests/codec/cbor-float-write.lisp" :GIT-BLOB
   "747cd8a72445a3ea638cd1910bc9faa63f4cdc33")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-item-read-support.lisp" :GIT-BLOB
   "0326100362a1c4b24d2c7e511e45357f09a56d33")
  (:PATH "tests/codec/cbor-item-read-threads.lisp" :GIT-BLOB
   "a0da65545ed80ede0a967cadbb337731f6fe1ce9")
  (:PATH "tests/codec/cbor-item-read.lisp" :GIT-BLOB
   "b2cbdcb4255c51d9da4fe73b28939c1cb923fefe")
  (:PATH "tests/codec/cbor-map-write-support.lisp" :GIT-BLOB
   "113bfc4529199f69dea1862baec0aa7403c6fa97")
  (:PATH "tests/codec/cbor-map-write-threads.lisp" :GIT-BLOB
   "892d30fd1c7a8f12430c6caa6f43ee872574eb09")
  (:PATH "tests/codec/cbor-map-write.lisp" :GIT-BLOB
   "6ad0e9b5a48ba9c32c46d720f2f7f1821368d6c8")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "532c3f1d5898083364f17f9fc9cbf0da7b798bda")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "d88b573a98689b5e1c0cbade8f8a7ac69470554f")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "0989d7f8e43ec7213df856b842b1e9149df96d9f")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "186f1772335ce33e4e3d1d933bf4d4e91fe0763f")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-read-support.lisp" :GIT-BLOB
   "cfd55cd47d782673113e67af625c1360195a345c")
  (:PATH "tests/codec/cbor-string-read-threads.lisp" :GIT-BLOB
   "c3686d6e47ad56e53db556747ee2d49cea527df5")
  (:PATH "tests/codec/cbor-string-read.lisp" :GIT-BLOB
   "8437bdcaa4cf308dbf4614e748cdab4be2ae6d62")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "66b5d03695f522cca8013ccdad3ede690cc63412")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "16cc32f2c51d28f75a64b93ead642340f88e9c05")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "595d51a96ee3767c13797910ea324061a4788617")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-tag-write-support.lisp" :GIT-BLOB
   "e6e1e91e5ed95019e20b11d2dc0e408911acb46e")
  (:PATH "tests/codec/cbor-tag-write-threads.lisp" :GIT-BLOB
   "1c731f7ed83f703e3d2a8a4c57e6c702ef127887")
  (:PATH "tests/codec/cbor-tag-write.lisp" :GIT-BLOB
   "df97950ec8d24157bb6566c7995262f7beea7742")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "0f66cc1f8b493598d436b1d62d7211f4196fb430")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "7717054be474eba254f3f645fc62ec4ef65a511c")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "0c1a6d9fbe44a95b951a7e1a9aad90f65cef961b")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/control/native.lisp" :GIT-BLOB
   "2107cb66de45ded987c7fb1392155ff6afebbed6")
  (:PATH "tests/control/publication.lisp" :GIT-BLOB
   "f987c9317990ce977ecadb747268b39d2612eba1")
  (:PATH "tests/control/recovery-guards.lisp" :GIT-BLOB
   "b2e877dfcc35468cfafd95f398f33d1415692c1f")
  (:PATH "tests/control/recovery-publication.lisp" :GIT-BLOB
   "cd99169af8aecf204ce9cd2e6e1f2a9fbb081f68")
  (:PATH "tests/control/recovery-read.lisp" :GIT-BLOB
   "21f33af3220a237d7a8dc2ff3a98bfd4c41fa201")
  (:PATH "tests/control/support.lisp" :GIT-BLOB
   "053d81269526d2e7c78181fbe2f8e58ac3f878f3")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/engine/compaction.lisp" :GIT-BLOB
   "4e46ba4400a7af10db08d35e191be80204237234")
  (:PATH "tests/engine/delta-location.lisp" :GIT-BLOB
   "3ab2c0e5c6d45ed746de955c72192327c525c71c")
  (:PATH "tests/engine/delta.lisp" :GIT-BLOB
   "5160313851bdfa637e80b76095679b9e965f22a7")
  (:PATH "tests/engine/image-activation.lisp" :GIT-BLOB
   "bb8b9470cae4854efd1336bc5a289d7305faed54")
  (:PATH "tests/engine/image-auto.lisp" :GIT-BLOB
   "19215e89154e8f65ba0e83e21b04d3d069c93a69")
  (:PATH "tests/engine/image-build.lisp" :GIT-BLOB
   "8543c508064d8198957a25f93e6da3c343d6c26a")
  (:PATH "tests/engine/image-discovery.lisp" :GIT-BLOB
   "50891fbd9ded0ece20969b466f24f1f591bd1439")
  (:PATH "tests/engine/image-maintenance.lisp" :GIT-BLOB
   "3b28dcea4388823fe8999b1fd67edb7a0da5343d")
  (:PATH "tests/engine/image-renewal.lisp" :GIT-BLOB
   "01e55612ec38f31fe281c0f1707bf1aa50aa1345")
  (:PATH "tests/engine/images.lisp" :GIT-BLOB
   "7ea979d2249807380c4532acc52e2ad299dcc0ad")
  (:PATH "tests/engine/index-auto-disk.lisp" :GIT-BLOB
   "57efb3be2095d695461717b131b95f2b6c1131f7")
  (:PATH "tests/engine/index-automatic.lisp" :GIT-BLOB
   "d2f9514760932005ab95e12f037606cf0dd94fde")
  (:PATH "tests/engine/lifecycle.lisp" :GIT-BLOB
   "55f8a525a7fb68846724b869d15eee8238924fe3")
  (:PATH "tests/engine/processes.lisp" :GIT-BLOB
   "f88f26beb525183b9a7840b72ae5f8fae727be7f")
  (:PATH "tests/engine/record-cache.lisp" :GIT-BLOB
   "7dc3029e1048aedb7aab3bfb2649a69731e01734")
  (:PATH "tests/engine/rotation.lisp" :GIT-BLOB
   "f0de9a0e81ab82a161ba5e19a0706aae803e63e5")
  (:PATH "tests/engine/support.lisp" :GIT-BLOB
   "4f050bd297add4aff17a15bb24b3f499785018fd")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "b1e71783b65b85e6253f733098c3153d41c4971c")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ca77be5b92c1cec98860dd5f59b278e9dcaf8ae4")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/fulltext/admission-concurrency.lisp" :GIT-BLOB
   "fbc2b0294a9369c4812bf206f001399be2af0ff3")
  (:PATH "tests/fulltext/admission-guards.lisp" :GIT-BLOB
   "b3475774a8a7f31269ea0e1b33bb659e230f67c7")
  (:PATH "tests/fulltext/admission-lifecycle.lisp" :GIT-BLOB
   "175c3e3bd33b163bc7593066ade68eb426e8e757")
  (:PATH "tests/fulltext/admission-resources.lisp" :GIT-BLOB
   "29ac6bf4b0b392579997b79c10142b2f491a5eb7")
  (:PATH "tests/fulltext/admission-rows-support.lisp" :GIT-BLOB
   "1713cd556e5e37525af25a15b4f5b36474967d88")
  (:PATH "tests/fulltext/admission-rows.lisp" :GIT-BLOB
   "6e2d6c65c8046ad7dee030a4e95330f3ce3993dd")
  (:PATH "tests/fulltext/admission-support.lisp" :GIT-BLOB
   "1eaef196dc555b086cd53584731041bfb97cda59")
  (:PATH "tests/fulltext/admission.lisp" :GIT-BLOB
   "74ed0e49ce0c839cb5e74d854704d21cb8dbbf68")
  (:PATH "tests/fulltext/allocation-threads.lisp" :GIT-BLOB
   "870a308baeed93e1aabb6dc9a88db443592439c0")
  (:PATH "tests/fulltext/analysis-conformance.lisp" :GIT-BLOB
   "ad704e6457ad7873b3eb2feea241da5129962c8f")
  (:PATH "tests/fulltext/analysis-support.lisp" :GIT-BLOB
   "805f7e60fd3f6aa25b4c53680e5251188e57868e")
  (:PATH "tests/fulltext/analysis.lisp" :GIT-BLOB
   "4d529aef551bd365f0c12eb3dffbb7b2960fae56")
  (:PATH "tests/fulltext/codec-corruption.lisp" :GIT-BLOB
   "c62dd05be34d1f653eed8565cc0b40b950bdb97f")
  (:PATH "tests/fulltext/codec-differential.lisp" :GIT-BLOB
   "91b651930dd7f9da36fd317453686d272e0d2c40")
  (:PATH "tests/fulltext/codec-guards.lisp" :GIT-BLOB
   "9f6b8e823ae25c43b767141e0193b908ca0e763a")
  (:PATH "tests/fulltext/codec-support.lisp" :GIT-BLOB
   "890e176db757eed9e2680f5b247a12922709d4b9")
  (:PATH "tests/fulltext/codec.lisp" :GIT-BLOB
   "50b924b1c0e9127da33413f1100bf04ef2ee500d")
  (:PATH "tests/fulltext/document-differential.lisp" :GIT-BLOB
   "78466a8bc1213d0794155535eb28a990a45a38aa")
  (:PATH "tests/fulltext/document-guards.lisp" :GIT-BLOB
   "608f322bd4ac149abb9ffbb352595b5c94d3d217")
  (:PATH "tests/fulltext/document-support.lisp" :GIT-BLOB
   "57d59f345c6cbe8dba253acce7993409b5bbed94")
  (:PATH "tests/fulltext/document.lisp" :GIT-BLOB
   "ab305e31ece6bf7fd20ac5b7ea119b01c57e7c92")
  (:PATH "tests/fulltext/format-guards.lisp" :GIT-BLOB
   "9a23048572dfa5eee314221ced3425a1ea46c28a")
  (:PATH "tests/fulltext/format-support.lisp" :GIT-BLOB
   "d03bd892800d593a3550bdc709d43c357041bfab")
  (:PATH "tests/fulltext/format-threads.lisp" :GIT-BLOB
   "b8e8eb4491b59c721071396ce656eb09186f988d")
  (:PATH "tests/fulltext/format.lisp" :GIT-BLOB
   "b7cb19b82d4e50d457c603b8708693adf27785f0")
  (:PATH "tests/fulltext/index.lisp" :GIT-BLOB
   "0673c32fe456a9cb77cf4aa5cc4e071a888cccf2")
  (:PATH "tests/fulltext/minimum-v2.hex" :GIT-BLOB
   "c4db496b0e5b920665d1c80bea204f6227da1f0e")
  (:PATH "tests/fulltext/put-concurrency.lisp" :GIT-BLOB
   "613b2e5a89d505701583aa9c68e6273f4163d2e7")
  (:PATH "tests/fulltext/put-guards.lisp" :GIT-BLOB
   "6b531c1b143860a46e84d5c77da982f54fbd413b")
  (:PATH "tests/fulltext/put-lifecycle.lisp" :GIT-BLOB
   "8cba90b629299c8494194a73ef8b819f554ca557")
  (:PATH "tests/fulltext/put-physical-guards.lisp" :GIT-BLOB
   "bd293d0ef1d5596e85859cb85e41639b3a0fd70e")
  (:PATH "tests/fulltext/put-physical-native.lisp" :GIT-BLOB
   "635118c4287ab13b4b98e34d04dc307b97497827")
  (:PATH "tests/fulltext/put-physical-support.lisp" :GIT-BLOB
   "1e81cc2af12f24515debc953d4f7884b07a2e197")
  (:PATH "tests/fulltext/put-physical.lisp" :GIT-BLOB
   "f8d1fa41090aaa40c2146ec9280bff08d968fdce")
  (:PATH "tests/fulltext/put-rows.lisp" :GIT-BLOB
   "0ee39c61cdbb6742eb36d65677030d44c96ad98e")
  (:PATH "tests/fulltext/put-support.lisp" :GIT-BLOB
   "2a3c9b543587b1a9c5402a16f82cfc1c671a6160")
  (:PATH "tests/fulltext/put.lisp" :GIT-BLOB
   "83f9503ec4bd1a6610443bb8eea991e6069c6565")
  (:PATH "tests/get-active/construction.lisp" :GIT-BLOB
   "ec2831edef2e452597ce867b026eb73c84fc5214")
  (:PATH "tests/get-active/directory.lisp" :GIT-BLOB
   "48c9a60e58536170a610844e853eae6f91beeff1")
  (:PATH "tests/get-active/preflight.lisp" :GIT-BLOB
   "7f41c04257e0bab10a2ffbc091b02d660029c4df")
  (:PATH "tests/get-active/read.lisp" :GIT-BLOB
   "0ab8c2b2b639a51b0217876a896d9468f41e22de")
  (:PATH "tests/get-active/support.lisp" :GIT-BLOB
   "0eb0864894f8f8cb32221ff98c75dde5aff80c26")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "ced6f8b39836c1c2ff264822ddaf05d0653bfff6")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/lifetime-support.lisp" :GIT-BLOB
   "cd514970e84f8654318dcc23a6b1ef24323be8a9")
  (:PATH "tests/get-directory/lifetime.lisp" :GIT-BLOB
   "c57261d2de469318402d5bf79f5ab5d27108bb46")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/series-read.lisp" :GIT-BLOB
   "b500bb83170622b6d96edbd363ebc85240064c18")
  (:PATH "tests/get-directory/series-support.lisp" :GIT-BLOB
   "ead990e110b588bb4df35ea17d3816db3b79cee5")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "a5b09ee5120bedc4e946366239dd5e6c978b27d2")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "9e03608bef23c0aa5a69dce8c7dfd09ed818a377")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get-resolver/construction.lisp" :GIT-BLOB
   "322c63ee6576304ca1ab19e28b902b680bc2acae")
  (:PATH "tests/get-resolver/read.lisp" :GIT-BLOB
   "a1788d1aab3f76b9dc29095676ec42f3a1f936a8")
  (:PATH "tests/get-resolver/sort.lisp" :GIT-BLOB
   "442ce9eef4fac8f593a9d94ed08a76b830773563")
  (:PATH "tests/get-resolver/support.lisp" :GIT-BLOB
   "11d5cf0efe8ee4f5606707cc7eca175442a50190")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/image-processes.lisp" :GIT-BLOB
   "11c9ba829c73bb71f54be52710ac699b40b47f60")
  (:PATH "tests/index/image-tests.lisp" :GIT-BLOB
   "3ea1eb66179db5125b2b5137372c70c9d953e95f")
  (:PATH "tests/index/mode-policy.lisp" :GIT-BLOB
   "4513fb320a9f1ced973820d8a9c58ee9a0d73ea6")
  (:PATH "tests/index/mode-support.lisp" :GIT-BLOB
   "14d4c82bd54795844d14ac1d7f1b7ced320c4233")
  (:PATH "tests/index/page-build.lisp" :GIT-BLOB
   "bd600c74e28d32328559e9b9f268b4afa3481a55")
  (:PATH "tests/index/page-cache.lisp" :GIT-BLOB
   "aaace9b80ff3c6ce2ab52a3644be8c56eef4ebfd")
  (:PATH "tests/index/page-chains.lisp" :GIT-BLOB
   "265a85cd6aff51dd8a5ceae50f60ff7b8d63660e")
  (:PATH "tests/index/page-corruption.lisp" :GIT-BLOB
   "880775f39ed5c6352c0ae448b7a830ea63b03a85")
  (:PATH "tests/index/page-fixtures.lisp" :GIT-BLOB
   "0ed84fd77dc21375773651e4bb42e56a2c0a5e43")
  (:PATH "tests/index/page-lookup-support.lisp" :GIT-BLOB
   "8800a152c6f0eefa572fda9e17ee9e5e1ff77023")
  (:PATH "tests/index/page-lookup.lisp" :GIT-BLOB
   "290b471927fc1647a000099d8f3f8b57b878c843")
  (:PATH "tests/index/page-support.lisp" :GIT-BLOB
   "920c631d2763260aec7bcb02d3172d8be1d4b21f")
  (:PATH "tests/index/page-tests.lisp" :GIT-BLOB
   "a18f0315e5480a356504f1f541bffc1ad3484fc6")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "d21142f34f3687c35f39c86d962f2c8ffd52c330")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/create-relative-native.lisp" :GIT-BLOB
   "fd5e819e2197869a93259857aacfa68bfe9e9a44")
  (:PATH "tests/io/create-relative-support.lisp" :GIT-BLOB
   "8382ffb8f04b6d2fc3e4adb89f995c9c37b0e445")
  (:PATH "tests/io/create-relative.lisp" :GIT-BLOB
   "7fb4c3665ca1b8f6de2dedd2827cfc150dcddf02")
  (:PATH "tests/io/directory-lock.lisp" :GIT-BLOB
   "4cefd15616f4ac2312a669b1242929d2706eb540")
  (:PATH "tests/io/flush-failure.lisp" :GIT-BLOB
   "76a80588d99b441e8c57a97f9a10d4d9d6c7b59b")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/open-relative-native.lisp" :GIT-BLOB
   "cdb197bf2760de70e7ec49af76e2954a18006997")
  (:PATH "tests/io/open-relative-support.lisp" :GIT-BLOB
   "4256567b2a10423a41540298317c8ef80e6b5af0")
  (:PATH "tests/io/open-relative.lisp" :GIT-BLOB
   "4bec9451a13db1437e081bda2858d4cb8b1e5de1")
  (:PATH "tests/io/readiness.lisp" :GIT-BLOB
   "1a7ce2205d7278a080395a3f4287540e11d3bea4")
  (:PATH "tests/io/rename-native.lisp" :GIT-BLOB
   "99f79041529d20d0ea774b01e3ed82fc5a274cdd")
  (:PATH "tests/io/rename.lisp" :GIT-BLOB
   "e83443eec6187d53118795c4f6ee797112f27ea2")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer-failure.lisp" :GIT-BLOB
   "c87c80fb9c82062bf4d4179d67f710ff10b4f051")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/local/native.lisp" :GIT-BLOB
   "b8891b57aa6229995b7c6ee5581d9cde650e3c93")
  (:PATH "tests/local/processes.lisp" :GIT-BLOB
   "9d716c57c2dd44219555c50bb00d0385e1a4a946")
  (:PATH "tests/local/server.lisp" :GIT-BLOB
   "18d38754fed2d888ab8d6b7d29b2352a20122bcb")
  (:PATH "tests/local/wire.lisp" :GIT-BLOB
   "349d7df061b5871658ad3fa6a14601bd58f1fa2c")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery-active-checkpoint/guards.lisp" :GIT-BLOB
   "cae7d70c2a5598bb5c3e1256ef4bb8b391656f6f")
  (:PATH "tests/recovery-active-checkpoint/publication.lisp" :GIT-BLOB
   "a996bc5f82f16fe12a74d9bee5962f8d8629f53a")
  (:PATH "tests/recovery-active-checkpoint/semantics.lisp" :GIT-BLOB
   "a4b80a1a678cdc4537ee9d989f178124829e70cb")
  (:PATH "tests/recovery-active-checkpoint/support.lisp" :GIT-BLOB
   "998ab160b939c93797fc90206a9b50f2cf55e452")
  (:PATH "tests/recovery-active/publication.lisp" :GIT-BLOB
   "8a3c4ba88dd7010c65a464d231ebdab2c8c27e67")
  (:PATH "tests/recovery-active/read.lisp" :GIT-BLOB
   "63f52ee0e0ab244ed278562a5d7fbc752b7617e7")
  (:PATH "tests/recovery-active/semantics.lisp" :GIT-BLOB
   "1d3c935a1169904c900461b67adb96f4dfd96b94")
  (:PATH "tests/recovery-active/support.lisp" :GIT-BLOB
   "5ebf9d06ae855b07875aadc10e2a8ac01ba56036")
  (:PATH "tests/recovery-archive-csn/guards.lisp" :GIT-BLOB
   "a6d91274479da64fa689ca370ff495cc96ae0e51")
  (:PATH "tests/recovery-archive-csn/native.lisp" :GIT-BLOB
   "d66af858c855e39c984f1ff8534e6de3c7c7fc88")
  (:PATH "tests/recovery-archive-csn/plan.lisp" :GIT-BLOB
   "b740c77023c500208ff742e02c4d5aebcd44db70")
  (:PATH "tests/recovery-archive-csn/set.lisp" :GIT-BLOB
   "d163bf160241d2225ac3282c1d925aa65e249ab3")
  (:PATH "tests/recovery-archive-csn/support.lisp" :GIT-BLOB
   "0c458a3f6f8aa062c2cc8831834c29159e09762d")
  (:PATH "tests/recovery-archive/active.lisp" :GIT-BLOB
   "ccbaaa3294880905584ad42c0601201fa3a3dc36")
  (:PATH "tests/recovery-archive/guards.lisp" :GIT-BLOB
   "8afea2a3df30099c07badd7d9c0bcf627a5f9a9d")
  (:PATH "tests/recovery-archive/native.lisp" :GIT-BLOB
   "ae8df9ced72f9142ade184ec78bdc576e05593e1")
  (:PATH "tests/recovery-archive/query.lisp" :GIT-BLOB
   "b0a56949ec13ec7c80466ac8b3cecc79c0fc6d63")
  (:PATH "tests/recovery-archive/read.lisp" :GIT-BLOB
   "22d1042700435e2c15e3f610f9ada9c4a8d8d4ed")
  (:PATH "tests/recovery-archive/support.lisp" :GIT-BLOB
   "0cbefaed0f74c8e34e4cea9a359c58f9196f22ad")
  (:PATH "tests/recovery-closed/csn.lisp" :GIT-BLOB
   "754611c3818a0aac26b189392d4024a251439d0c")
  (:PATH "tests/recovery-closed/guards.lisp" :GIT-BLOB
   "344857641ef2206d4d5a800fbb93b834a9f13c4d")
  (:PATH "tests/recovery-closed/publication.lisp" :GIT-BLOB
   "72f179d28936100b91d1847eeb8a24c696552619")
  (:PATH "tests/recovery-closed/read.lisp" :GIT-BLOB
   "0e401337f36768cd63206cbb7b6adf91eeeeb1ef")
  (:PATH "tests/recovery-closed/semantics.lisp" :GIT-BLOB
   "a931be1523c72d49e955aa7708bec6bd3b273be0")
  (:PATH "tests/recovery-closed/support.lisp" :GIT-BLOB
   "15bafc01c04fe1763d9a6580f6ad0bbb1917f40c")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "e6f289d77025dce439787287abc6a4dde0ac69f5")
  (:PATH "tests/recovery/inventory-directory-native.lisp" :GIT-BLOB
   "8f89629becea88fdc74c920a59676412c3a7b976")
  (:PATH "tests/recovery/inventory-directory-support.lisp" :GIT-BLOB
   "c316b3647e7ea5391d687917fe802907f2273bb4")
  (:PATH "tests/recovery/inventory-directory.lisp" :GIT-BLOB
   "ead38feadd94f49276596d0abf989f29d13af497")
  (:PATH "tests/recovery/inventory-id.lisp" :GIT-BLOB
   "1f05c46bfc887984c476bd7673d2b2dde998c44d")
  (:PATH "tests/recovery/inventory-sources-native.lisp" :GIT-BLOB
   "86144ee3fe19ef0f2a54c9760ed193860881ced4")
  (:PATH "tests/recovery/inventory-sources-support.lisp" :GIT-BLOB
   "36b79c4091825c32ffc3aa32a146ee5121881ebc")
  (:PATH "tests/recovery/inventory-sources.lisp" :GIT-BLOB
   "3ffd5a9fb098ab4aeb091a6823fcec68d22c19aa")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest-transition.lisp" :GIT-BLOB
   "cdde7b60edddd974153ee670d859a94993afa367")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/runtime/adoption.lisp" :GIT-BLOB
   "8fbee7f08a25445b66895ae2e329a217070f67f4")
  (:PATH "tests/runtime/bootstrap.lisp" :GIT-BLOB
   "1398120574f95ebaec3c7431a74a35e0ced01652")
  (:PATH "tests/runtime/guards.lisp" :GIT-BLOB
   "a097cc38e13a1ef7369a2ed996d042718cf7312c")
  (:PATH "tests/runtime/native.lisp" :GIT-BLOB
   "e92ba03fb8184a6c95c44269a26a831b714974a1")
  (:PATH "tests/runtime/support.lisp" :GIT-BLOB
   "7d4dc59eab68672512aed0f4ae578436e669fe2e")
  (:PATH "tests/runtime/threads.lisp" :GIT-BLOB
   "2454593a231d5d6bb9ef4318eb06567ce3192d24")
  (:PATH "tests/scheduler/controller.lisp" :GIT-BLOB
   "8e14282e1f42f3b247a5c578d8a683ddc6147381")
  (:PATH "tests/scheduler/dispatch.lisp" :GIT-BLOB
   "6a493f0022ac8c9b6117c2a62df49fa596194c7b")
  (:PATH "tests/scheduler/lifecycle.lisp" :GIT-BLOB
   "874391809401f42a4db81fe544306165f99ceb5d")
  (:PATH "tests/scheduler/pool-begin.lisp" :GIT-BLOB
   "13a239cf97403806a73242abbd5b545440a17645")
  (:PATH "tests/scheduler/pool-chain-support.lisp" :GIT-BLOB
   "a1ea8258495b9a717e1e0ef164133f6b7140f8a5")
  (:PATH "tests/scheduler/pool-chain.lisp" :GIT-BLOB
   "86675c17ea47eff262cb03cdb41e50bcdb82b78e")
  (:PATH "tests/scheduler/pool-claim.lisp" :GIT-BLOB
   "f636ee873deb2cd5347a50c9aec4a6afa16d13c5")
  (:PATH "tests/scheduler/pool-recycle.lisp" :GIT-BLOB
   "3c779589cd7df6ae1146c2ca50b70320093bbf4a")
  (:PATH "tests/scheduler/pool-start.lisp" :GIT-BLOB
   "ec19bb409799e7956e40c34cc9264d02033cfb22")
  (:PATH "tests/scheduler/pool-step.lisp" :GIT-BLOB
   "d0ff803608990744408749722210e812f6268782")
  (:PATH "tests/scheduler/support.lisp" :GIT-BLOB
   "f2301a1adf44c33284aaa1171acd90c5828b0396")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "ef3d4671b3df48b932c1666f8b58fdca4eecbc77")
  (:PATH "tests/series/log-binding.lisp" :GIT-BLOB
   "c116a9169058ddd9e384fda5f52bb5787977e20e")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "257c6f8cf28bdd8408a3363041d621497f4a5f67")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "c3eb1ce7870b81944c23efac9b8cb7f8f4888ba9")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/vertical/method.md" :GIT-BLOB
   "3e60572557391e2c772d3b44491ae18eecb352bf")
  (:PATH "tests/vertical/processes.lisp" :GIT-BLOB
   "059fbd2bb702e76e986b97edfbe4d3784599d583")
  (:PATH "tests/vertical/resume.lisp" :GIT-BLOB
   "6f80a0d0fec9f725beca54d06d961932bd815043")
  (:PATH "tests/vertical/scenarios.lisp" :GIT-BLOB
   "fcbc7878d56720604f0e86a916d2e42c0f28cffd")
  (:PATH "tests/vertical/support.lisp" :GIT-BLOB
   "37c2e8d1da68eb425cdd11548f8699c888afd7bf")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-float-write-audit.lisp" :GIT-BLOB
   "485544868eeadff247968b86c2d5da9b3b610295")
  (:PATH "tools/cbor-float-write-bench.lisp" :GIT-BLOB
   "d992c9f8cf6ff0d748fcb77f871fb77969480bca")
  (:PATH "tools/cbor-float-write-mutation.lisp" :GIT-BLOB
   "5d0d6bd46b0286f153ee9c482734c659959396e2")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-read-driver.lisp" :GIT-BLOB
   "a6b65bd233dba2a2eec941d96a75b9db948d19f8")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-parallel-tests.lisp" :GIT-BLOB
   "a49a03a64a137e66c07c98f981327fc42d9cb508")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "e3df9f52590ce2de86ad75b872c859b81bbcc518")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "1f63d49150e6b7b23c1df2a9c25c3d2288861b8a")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "253fea1c65c6aacb77fa56f2ab05cce086a1856d")
  (:PATH "tools/ci.lisp" :GIT-BLOB "c0b6255982f4299b883992f5829baaebcd2aaa36")
  (:PATH "tools/ci/archive.lisp" :GIT-BLOB
   "03712985b7cf1493a7009a35965cadf6c9902292")
  (:PATH "tools/ci/conditions-self-test.lisp" :GIT-BLOB
   "99f857163fa38683871790731b6f72448cf92ffb")
  (:PATH "tools/ci/coverage.lisp" :GIT-BLOB
   "233ae46d6ab9fab6a74046140323eecc64243174")
  (:PATH "tools/ci/data-self-test.lisp" :GIT-BLOB
   "b5d6a8f505604e3c45d228582933af38713cc01a")
  (:PATH "tools/ci/data.lisp" :GIT-BLOB
   "8cec68fa2e6e5d7e4484a53cde13964b875f9222")
  (:PATH "tools/ci/github.lisp" :GIT-BLOB
   "a2ca20ed9c586b104f59091d174028b3454d6a10")
  (:PATH "tools/ci/identity.lisp" :GIT-BLOB
   "abf3cc722957379e1408d629b81a2d1916a0788b")
  (:PATH "tools/ci/measure-self-test.lisp" :GIT-BLOB
   "18959f2608b1be4ef1b77b0a7d3b1a67735c16d4")
  (:PATH "tools/ci/measure.lisp" :GIT-BLOB
   "7e16fd5b80a7bbce27a0c856a6abd001ff4814ed")
  (:PATH "tools/ci/producer.lisp" :GIT-BLOB
   "a7fab0bcc8dc6a33ed37acb0d391ec1a73674493")
  (:PATH "tools/ci/publish-self-test.lisp" :GIT-BLOB
   "400b9ba4c1c3fd0e6bd158f3f89bcc58e802c595")
  (:PATH "tools/ci/publish.lisp" :GIT-BLOB
   "d8a212faaa5bba7df102377a70e6cd9d75d7810c")
  (:PATH "tools/ci/self-test.lisp" :GIT-BLOB
   "8b2cfa7eab4f728c70a4f0f6e4a81da3259a9e38")
  (:PATH "tools/ci/support.lisp" :GIT-BLOB
   "b5fe7c565ed0f885b666d8dba836bec4a7ba4c65")
  (:PATH "tools/ci/test-self-test.lisp" :GIT-BLOB
   "2cd7248feeb0ff089429cee6f29ab12283665ec4")
  (:PATH "tools/ci/tests.lisp" :GIT-BLOB
   "9c81cf6aec5f89896d9e4ccdcd59ccf1d3c65c6f")
  (:PATH "tools/ci/workflow-self-test.lisp" :GIT-BLOB
   "f0278d9bc21245d6890e52011414627376bca5de")
  (:PATH "tools/collect-command-archive-tests.lisp" :GIT-BLOB
   "49da390b7e170acc9ffdafa78285f215aec75f44")
  (:PATH "tools/collect-command-archive.lisp" :GIT-BLOB
   "d2eb1bd8a62b0fd98ec023243b2a768c19988dc7")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/control-checkpoint-bench.lisp" :GIT-BLOB
   "f631bbb7096359592fde0ae2b4462c2d2067d5a1")
  (:PATH "tools/control-transition-bench.lisp" :GIT-BLOB
   "40fd5a04dc62cced8e688ed30f59e0d810716a43")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/engine-crash.lisp" :GIT-BLOB
   "04c4796c05bdcecf6d8fc83d3ee1eafcf969fed9")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "abd8e62e937c60e9ac68c3ccce904111388bff09")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "f520ecdb46cc94e07d774d39cb73beed380aa867")
  (:PATH "tools/fulltext-codec-fixture.lisp" :GIT-BLOB
   "f6756e030cdde7beaab41a6b38516950f1663c9e")
  (:PATH "tools/fulltext-persistence.lisp" :GIT-BLOB
   "ab0dbf4ec2e5335721818cc03711b92d7d62111d")
  (:PATH "tools/fulltext-qualification.lisp" :GIT-BLOB
   "d649e9cafa96bcb4351bbced5de04bb10352ab85")
  (:PATH "tools/fulltext-unicode-tables.lisp" :GIT-BLOB
   "ba86b196441a40e662f6052e189074eef08b75d5")
  (:PATH "tools/get-active-init-bench.lisp" :GIT-BLOB
   "c62f2bf8ba96c3e80cdd50ba067e4c4df3e5e957")
  (:PATH "tools/get-active-init-mutation.lisp" :GIT-BLOB
   "b2cd809d99d049757156ddf0141997e3b67903b4")
  (:PATH "tools/get-cost-bench.lisp" :GIT-BLOB
   "696d56846ce992f186da2b468f8de55063532b02")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "45897c0afa972a437bbb595493b87dd0c8ed9710")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/get-resolver-coverage.lisp" :GIT-BLOB
   "5ab21d923b68e35adbc177ecd352bb33340f0c07")
  (:PATH "tools/get-series-bench.lisp" :GIT-BLOB
   "2950d4fcb7fc93fbfc7d78c860f0ac43ed984f35")
  (:PATH "tools/get-series-capture.lisp" :GIT-BLOB
   "9c42e23d381751e8140f186f969c6c2ef8d606cf")
  (:PATH "tools/get-series-mutation.lisp" :GIT-BLOB
   "3d3e887ba8e1d90612e561dfffb3d71c486e813b")
  (:PATH "tools/get-throughput-bench.lisp" :GIT-BLOB
   "6554b119583602b9d06b3ff7b2bb9c8104130d79")
  (:PATH "tools/index-image-crash.lisp" :GIT-BLOB
   "01f7cec3a08a55fcf51b4c743e588ad53a0023ae")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/io-completion-mutation.lisp" :GIT-BLOB
   "7fd59fd86e2d477a6b6ee0f7a2142f8ea6b073c6")
  (:PATH "tools/io-rename-bench.lisp" :GIT-BLOB
   "988d259af126212adc2be8fb9ca9acd8755fdce0")
  (:PATH "tools/io-rename-mutation.lisp" :GIT-BLOB
   "dfc691c88e9ab940a065703a223a1c414454b0f2")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/legal-notices.lisp" :GIT-BLOB
   "f120b9660591fd3eda904c9cf0722bddae3f05a0")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "adf3ca235874a2b950e57ea61a719c4c90e9dda8")
  (:PATH "tools/local-client.lisp" :GIT-BLOB
   "1ab2f474ad7db04a3fc8cc6dd7e84a2441498d20")
  (:PATH "tools/local-fault-server.lisp" :GIT-BLOB
   "92cd3d6164c6000c181374e3b917bbf1bb83aaa6")
  (:PATH "tools/local-server.lisp" :GIT-BLOB
   "517652d80ad2d4fbbe85be42fa110d4c902d8cf8")
  (:PATH "tools/local-tests.lisp" :GIT-BLOB
   "02aace929b7f5e2fd790c02d1557628ea17d7afc")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/measure-pool-begin.lisp" :GIT-BLOB
   "e3094d9f35efdaa647751f19a7acda00c36d515a")
  (:PATH "tools/measure-pool-claim.lisp" :GIT-BLOB
   "712a4a5393b69539f02cd625223918e404b331d3")
  (:PATH "tools/measure-pool-dispatch.lisp" :GIT-BLOB
   "bddb449176d3b7b6ae946e841a0ca3202e6c28ef")
  (:PATH "tools/measure-pool-lifecycle.lisp" :GIT-BLOB
   "3a229eecc3c158cec9af8fad6abd5fc2d980e2dd")
  (:PATH "tools/measure-pool-recycle.lisp" :GIT-BLOB
   "cb20f6d271889a9801106daf230ee934aaa7bf81")
  (:PATH "tools/measure-pool-start.lisp" :GIT-BLOB
   "e6be453833925b89cdc49303b99a23374f3b2689")
  (:PATH "tools/measure-pool-step.lisp" :GIT-BLOB
   "cdcb410e27475282d157b0d64a4656ea6ad069a1")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/pages/bootstrap.lisp" :GIT-BLOB
   "a9cf9ea45672b576b76acf1e4773c2c2949bc2ca")
  (:PATH "tools/pages/build.lisp" :GIT-BLOB
   "e319acad4fe5bf1f9cd14b65772775c95ab632fe")
  (:PATH "tools/pages/check.lisp" :GIT-BLOB
   "b0524f02c494e61f4edf08aa2802ba1a3d16cd66")
  (:PATH "tools/pages/code-reference.lisp" :GIT-BLOB
   "16bf45ca14cc936283e32700698e696f4a36a09c")
  (:PATH "tools/pages/code-source.lisp" :GIT-BLOB
   "8ba99903d3afdae918fd8966410fbbaf7438066f")
  (:PATH "tools/pages/code-tests.lisp" :GIT-BLOB
   "1f1349e749863b14d9690a33dda48537d96434e3")
  (:PATH "tools/pages/dependencies.lock.lisp" :GIT-BLOB
   "f0f339aabf9998e7f910f8904744549766426ec6")
  (:PATH "tools/pages/editorial.lisp" :GIT-BLOB
   "f5a43b2ba1a876c3643ad4b3b64b43096c193b49")
  (:PATH "tools/pages/generate.lisp" :GIT-BLOB
   "56ee4dcf36cc76e82b3997357630eca1083dadff")
  (:PATH "tools/pages/markdown.lisp" :GIT-BLOB
   "a6ce370b0cbbeb2869c88112b69ee7aa38e7effa")
  (:PATH "tools/pages/model.lisp" :GIT-BLOB
   "bed6a6fb53b8efb13020bcf5cc5d1ec27aa31436")
  (:PATH "tools/pages/publication.lisp" :GIT-BLOB
   "8154535b76733cbdd33b3217744481635860a5a0")
  (:PATH "tools/pages/runtime-check.lisp" :GIT-BLOB
   "f9ab88e954f1b07f9c59594f55e67e909ee5f2e3")
  (:PATH "tools/pages/site.css" :GIT-BLOB
   "8069a0942d7ce79b272d8011c4f6c6002aae07e1")
  (:PATH "tools/pages/site.js" :GIT-BLOB
   "06770c92736cc6bd2b3e0c9638ec09f5c0dcc1c3")
  (:PATH "tools/pages/tests.lisp" :GIT-BLOB
   "d05b62748b36cefed5977d1a445c18e1d70b8e62")
  (:PATH "tools/pages/theme.lisp" :GIT-BLOB
   "547ef0acc0e6070c7fcd53385b0efed1aec5f82d")
  (:PATH "tools/pages/third-party-notices.lisp" :GIT-BLOB
   "907abf85677565bb547a4b7f0e7c6311b3bfa3ce")
  (:PATH "tools/pages/third-party-notices.txt" :GIT-BLOB
   "68ebcf8172dcbbf0865767f5194abb97911a83ef")
  (:PATH "tools/pool-controller-bench.lisp" :GIT-BLOB
   "cf6f31dd9c7a8d7f4e7cc1f19c4b9c5a48af6d55")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "068090ec38864b2b55877918aec57375312ee8db")
  (:PATH "tools/recovery-active-bench.lisp" :GIT-BLOB
   "9c11d5654a6168c27c64abcc8f852673c5974515")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/vertical-crash.lisp" :GIT-BLOB
   "8f920374d5b1049f5bac1e8dfb441099575de6cd")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :WALL-SECONDS 36.791105d0 :FINISHED-AT-UNIVERSAL-TIME 4002461914
 :SCHEMA-VERSION 1 :KIND :COMMAND-VERIFICATION :ENVIRONMENT
 (:LISP #A((4) BASE-CHAR . "SBCL") :VERSION #A((6) BASE-CHAR . "2.6.10") :OS
  #A((6) BASE-CHAR . "Darwin") :OS-VERSION #A((6) BASE-CHAR . "27.2.0")
  :MACHINE #A((5) BASE-CHAR . "ARM64") :CPU "Apple M4" :MEMORY-BYTES
  17179869184 :LOGICAL-CPUS 10 :EXTERNAL-LOAD-STATUS :UNCONTROLLED
  :LOAD-AVERAGE "{ 2.44 3.58 3.84 }" :COMMIT
  "f3c8350acef6c2ac3c5a94f74a5f1a04f486b5d0" :WORKING-TREE "M CHANGELOG.md
 M arcdocdb.asd
 M docs/adr/README.md
 M docs/implementazione/README.md
 M docs/implementazione/cache-record.md
 M docs/implementazione/production-unix-m1.md
 M docs/tracciabilita/matrice.md
 M docs/valutazione/registro-rischi.md
 M docs/valutazione/stime-ordine-di-grandezza.md
 M src/engine/adopt.lisp
 M src/engine/lifecycle.lisp
 M src/engine/package.lisp
 M src/engine/read.lisp
 M src/engine/startup.lisp
 M src/engine/types.lisp
 M src/local/cli.lisp
 M src/local/server.lisp
 M tests/local/processes.lisp
 M tests/local/server.lisp
?? docs/adr/0079-cache-record-m1.md
?? spikes/results/2026-10-31-engine-record-cache/
?? src/engine/record-cache.lisp
?? tests/engine/record-cache.lisp"
  :CWD
  #A((74) BASE-CHAR
     . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/")
  :DATE-UNIVERSAL-TIME 4002461878)
 :COMMAND
 (#A((48) BASE-CHAR . "/Users/gpicchiarelli/.local/sbcl/2.6.10/bin/sbcl")
  #A((8) BASE-CHAR . "--script")
  #A((62) BASE-CHAR
     . "spikes/results/2026-10-31-engine-record-cache/local-bench.lisp")
  #A((5) BASE-CHAR . "--run"))
 :STATUS :OK :STARTED-AT-UNIVERSAL-TIME 4002461878 :SOURCE-BLOBS-BEFORE
 ((:PATH ".gitattributes" :GIT-BLOB "d22cbb201cb1d3384baa7e8422aa9d6ee8aea1f9")
  (:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "4ed9445eb02f439a3c781878622809125ed924e6")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "711b96fd6fb677d15473213023c40c35affb47c0")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "ea5cf67447809b2e413026d50e2f61609cb9e438")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "80da41aac60230141d5d2d0819c9b6c2c3b3ce91")
  (:PATH ".github/ci-toolchain.lock.lisp" :GIT-BLOB
   "c01b06c5b208014ab30bb000dc10acfc9e72cc89")
  (:PATH ".github/workflows/ci-results.yml" :GIT-BLOB
   "d5029660830b7dbef56d6648bbf0a9bbaa400c56")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "49fc8ba897e94dc36c31d973e6e12efeab51b715")
  (:PATH ".github/workflows/docs.yml" :GIT-BLOB
   "6eef2de086d133233892870f80f5771f90ab1676")
  (:PATH ".gitignore" :GIT-BLOB "a3a191b534821cfe86f062a09dbc2cb19ba153bf")
  (:PATH "CHANGELOG.md" :GIT-BLOB "87840f1089d9c2ec1ba7b282874276890a28d254")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bc7dba35611947cb7c1e9fb898e294b00f9f2de1")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "20743e1dd5a32d14e0af066e27987eaa16c94964")
  (:PATH "README.md" :GIT-BLOB "9e6430d753813af59152d82a3959a45d70abfa94")
  (:PATH "SECURITY.md" :GIT-BLOB "331a1316c300159882e3a30f9f2c8575a8e586a9")
  (:PATH "THIRD-PARTY-NOTICES.txt" :GIT-BLOB
   "0c5bc85db048fb8970c3cc42fb128337eff77e39")
  (:PATH "arcdocdb.asd" :GIT-BLOB "b3226747355fcac8bc4d2a210b8f54848eb689ea")
  (:PATH "assets/README.md" :GIT-BLOB
   "c30d58ba88d9dd9f146df6f03aeedbdea3df5c72")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "a024e50336c5d93b7619048432219020d84eb688")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "0bb1c4dcc1aef96287b5edf18db288467e37f9c1")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "data/unicode/18.0.0/CaseFolding.txt" :GIT-BLOB
   "9ee0a2dd654f6fa520cd932be19ac5c00ffacded")
  (:PATH "data/unicode/18.0.0/DerivedNormalizationProps.txt" :GIT-BLOB
   "32227e8f297e96f98954281d99c38839a7834d7c")
  (:PATH "data/unicode/18.0.0/LICENSE.txt" :GIT-BLOB
   "56da58912807030b451a4700687d5bd02c72d6ed")
  (:PATH "data/unicode/18.0.0/NormalizationTest.txt" :GIT-BLOB
   "730c1a013ac78f6a63118e670c72556d4f112eab")
  (:PATH "data/unicode/18.0.0/README.md" :GIT-BLOB
   "06ab2a1368779a5535c48e90a7e2fb77e44080c9")
  (:PATH "data/unicode/18.0.0/ReadMe.txt" :GIT-BLOB
   "aa18f7175c4a46df644c7c6435ad95a8ad3cd724")
  (:PATH "data/unicode/18.0.0/UnicodeData.txt" :GIT-BLOB
   "ebccf021c4fcf31c2ecbb9bd7da3f5eb7ed44851")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakProperty.txt" :GIT-BLOB
   "313ae91aad579445a1e06556a1d7a2edd0c782a2")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakTest.txt" :GIT-BLOB
   "8d734a2690b9f06018e02b0b4f165acc4d0d2853")
  (:PATH "data/unicode/18.0.0/emoji/emoji-data.txt" :GIT-BLOB
   "7a383f0dcfd6ad65a2b7b5e90f701e38485f151f")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "a677288d5fd65a8de671c8cb513fef7c9cb013d5")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "0f68efcd275602bc60b1ee3a2a104f8a49bc6b80")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "1445703c53c2f1b82ced7dd78f34ad4ab8aae7d1")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "3c1c28fb8949660be6391180be187f55d14d5bb6")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "4c0ad12a7532b5d518b0581301f28a3601228d94")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "fce97d7d8c70a6c8f5425cd47ade5a2db5892a11")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "d3973b8d3cca6c9df25ab1c2e76c305bdc28c51b")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "85c9f51f242e4e5c3239edb58eea0a3ae0013011")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "5e10ff0c486bc5e08163bcd5df5bd5736de102f0")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "8720f145cca1d03da5446c5398ad4417a6243a18")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "30462b46bdd4dffdc7a8217adb6ec89571bf8b89")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "c05d0f0f5f69c9ddd9a85769c4bb11cc5a921c75")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "4ccdd9d66495ccff8d47d70ab80b04fa3bc601ca")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "b6a6a520f82271f96513a10457ad400c3f86f2bd")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "b75830dd78d106f8db76e65c08d4e8f3b2a488e4")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "d102ba1c248c77c71c437e46675cd5fc913fcdc5")
  (:PATH "docs/README.md" :GIT-BLOB "db925522d2e683e87137b5f3bca8d234cfe435bc")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "641a7c9e540ff2ec1136bcaa53c6558691578577")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "85d24f91157ac79e6af8c3ac908ca03921913922")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "9baef4c50046aca7c2d9740896af96a9dc5974f3")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "c949015de0fa3a2c25e597b523cb9a00409549b7")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "dd5d59a612a804976a08a475b0cce0de5daba1e3")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "49c294e438f29b383bc825210ba12f070f24a7a1")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "b56195d0f7f43e7bdb91a3af0d1a33f161b8d36e")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "26cb290c6bed61bf397cf4f9dbad7ca81d97e8b0")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "289e40fc2198e9295b90cddd5444d061cccdacfc")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "570458150a9f118174d72cbf90b0b13400237997")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "86c3d28f5a8ecdcf0dbbff34e5eeddf69bea5c48")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "3a490fbb3a23a5de59e08a86b5d656e559ec3696")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "c6b0803782b4595bce94f73f37bfb3de06ef58e3")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "811067eb4311ef4ed3c3b5450325345c04d444e4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "c863c2471e2f6e2b6bb0cb79f9c303dda902f572")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "5117c423e298e8aee4e02b2daea95cdfa6747784")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "813ecfb7741a73bbe4065c0914eab22495bbca3e")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "c5fc54a10372cec9bbf1fd3cbb436a6e835cd079")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "08a71d783f74d8dc0c02db312902f4256668d49d")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "085506a53a59d44f70b63f9f550df428a1f7c564")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "6399188b2711a8860f5895fb92dfabb34fa2dafa")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "13e62eb82f21f3b5490511d47823439541edba33")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "7785da60ce293bc328817518fbf2be3f9ab9a7b8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "57f594b6143b04e40bc3fea9394ebe938ca799ee")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "6b41728bd67274b11b1fde42cfb6ac2b71b0340b")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "0ec3e4cb8daeb741d6be9428099f1da284b0f895")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "50cded21f18bd019fc190b08edb348945d05829f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "e0e408989c0d8b1a8594a31a9f4cda888232b8c7")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "51ecdb8e1af48f87cd2e53d8c3c334b4a4dd7062")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "8589ad553a5b18f96e5dbab682a024f90b671c2e")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "138cf9abbe606df8f544a669069ed94844c9960f")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "c6ee53cf623ad6294ab2ab7e46ee16a3304dfdda")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "0af09ca66b38c35361d30ddbd028a0cb7fcac4e8")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "98cad23c9c529f3f83ccf02dc9bd1a4cb1e6f318")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "2d7ba68f4a56fa80700825d44f2b4335b4d342f4")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "5150eca7a1e85c342e20519179c0560e19c816c4")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "3aa06135165157067c6eaf64d8317a43d32086f6")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "b352146cf5138b099155a819a2c0c19780a31af7")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "05cc183bb8bd0b7b468a7225065c4dc75dd6cd33")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "452553489ad4b466a118e5ec3f08a79223ba7f69")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "7323f9c4e7d6a41ee0e8edbc7c21f6c40fae7258")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c12ccb4a82f5e97c40c2e2df05f085c28f9356af")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "c5ccb103deb265db77ca14be9e4fb60ebb7395f3")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "d0ce5bcc0bbfbf2fa92187bbd09d0ff320d54e69")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "a52656154964c4588477288a15fb10284ac888a4")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "d23b7ee9ef2e3e178a663dbfb004ccc8fed2c542")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2c0669b7a0226ff342e15158899a06d75a30abbc")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "5ba95841ff8f467ed496f51101ddd832dca4fab1")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "2787435e8647b4c1702b7fb4f35f40cd64197fa0")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "18cf324a65ccb0d7684d357bbb8eeb6aeed6a11a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "6754d79f26141153b55bbe1bcaa4a82825f95700")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "fd7e70d402194978a3ffdad705318afb0431f04e")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "2c3d966a83d6f5c1ba122e38ee510b5277a1e89e")
  (:PATH "docs/adr/0053-ricerca-full-text-indici-invertiti.md" :GIT-BLOB
   "ed37b13d26276ccec88bc4eb7e9259bc8ea270a0")
  (:PATH "docs/adr/0054-contratto-e-formato-full-text.md" :GIT-BLOB
   "239a1b5bbb0be77e0a60cb3f0360d8f4906d0b46")
  (:PATH "docs/adr/0055-interfaccia-locale-unix-socket.md" :GIT-BLOB
   "3a1a8acc98918b9eff3f9c319da1d089bd55bf1b")
  (:PATH "docs/adr/0056-sessione-locale-m16.md" :GIT-BLOB
   "09aa317be40281eb6dfeedfb16c27bf4ee227782")
  (:PATH "docs/adr/0057-selezione-automatica-indice.md" :GIT-BLOB
   "dd056fe207e34cc13582ef67686f5cef50da0d52")
  (:PATH "docs/adr/0058-pagine-indice-primario.md" :GIT-BLOB
   "aace2fae9377ecc39befa24f30a71fa3544aa82f")
  (:PATH "docs/adr/0059-crc32c-arm64-sbcl.md" :GIT-BLOB
   "8abf118f525ac8e4bfb3657e7b9c2389825e3734")
  (:PATH "docs/adr/0060-crc32c-caricamento-portabile.md" :GIT-BLOB
   "e525cdb37bc853b13c077a139869132a6c8a3296")
  (:PATH "docs/adr/0061-conservazione-esterna-delle-prove.md" :GIT-BLOB
   "f72ff61077518b492f247dde021f8ae8d5749777")
  (:PATH "docs/adr/0062-cronologia-git-due-commit.md" :GIT-BLOB
   "d17a19b8086aeb412bb8622fe8dc5301fd3265d0")
  (:PATH "docs/adr/0063-immagini-sigillate-indice-primario.md" :GIT-BLOB
   "6bf24e2c250857907d5d36e6ea7f2d93cf2dcf63")
  (:PATH "docs/adr/0064-adozione-indice-paginato-m1.md" :GIT-BLOB
   "8b4f945e8e06c194b517c1563c2a78fe1ddbd609")
  (:PATH "docs/adr/0065-costruzione-immagini-dal-motore.md" :GIT-BLOB
   "09314a89fa7875d648062095cfd24081055e34f5")
  (:PATH "docs/adr/0066-attivazione-seriale-immagini-m1.md" :GIT-BLOB
   "ca6fd5d38685053ceb12922973a932f72fce5fd8")
  (:PATH "docs/adr/0067-delta-seriale-indice-m1.md" :GIT-BLOB
   "03ea9916428820920370aaeef7c422b0478d3b4e")
  (:PATH "docs/adr/0068-rinnovo-seriale-immagini-m1.md" :GIT-BLOB
   "2240c84c7e57c86d33df08772b173cc9d0d11aba")
  (:PATH "docs/adr/0069-manutenzione-a-soglie-delta-m1.md" :GIT-BLOB
   "7433e9b73ae1548f198181002505a8aabec65ceb")
  (:PATH "docs/adr/0070-scoperta-readonly-immagini-m1.md" :GIT-BLOB
   "f4a496e4556b220282b4a962a57a723ad2ccbf50")
  (:PATH "docs/adr/0071-delta-location-indice-m1.md" :GIT-BLOB
   "5f06b390d2223e5e5e85f38f5de73cf1ad668f5f")
  (:PATH "docs/adr/0072-rinnovo-automatico-delta-m1.md" :GIT-BLOB
   "99ae69d3d9fa5d6d69f9cb5efede395fe33ae408")
  (:PATH "docs/adr/0073-indice-automatico-operativo-m1.md" :GIT-BLOB
   "8f7677e90411d564c161e07d5f46fe774e32384e")
  (:PATH "docs/adr/0074-crc32c-sbcl-2.6.10.md" :GIT-BLOB
   "0d32b3a9bfe16d3755cc163e1ec2ec09394ca598")
  (:PATH "docs/adr/0075-codex-documentation-toolchain.md" :GIT-BLOB
   "60f2fca9be7d793cffd1f13dc43a80365df700a5")
  (:PATH "docs/adr/0076-rotazione-live-m1.md" :GIT-BLOB
   "1da6f99e64dbce919e88440c8a4662d9abc9ba82")
  (:PATH "docs/adr/0077-source-derived-code-reference.md" :GIT-BLOB
   "100230816ee9e513dfc78ba3c57c992bef61eec5")
  (:PATH "docs/adr/0078-compattazione-prefix-m1.md" :GIT-BLOB
   "89e9e72b6eb4aaf2a0fd494de6a72a33810a52b0")
  (:PATH "docs/adr/0079-cache-record-m1.md" :GIT-BLOB
   "114135347b465d247f7e05b091858c9791f88382")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "b885270db66dd618a2984415182e1bc6eb8c9edc")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "da6af58f171fe105407b444a400905f554110ec9")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "09805b5022bf9b338522c4078feae7334825c50a")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "2b878e6c0b9ea5576635f16b1d9e7433c956458f")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "0b92053bbe5abc8b74a59472a0ddaad7be9ba399")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "35ce8a542e4e77ba28c497e4a33358f308708bd0")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "5729dba5379c1eaf1366302e6243fa5219f60cd0")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "2325e50c80180c368d7e13c9181bb6e6fd8ff831")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "5f74a1692a934ddc9425d91ff0cadbf842c95bb2")
  (:PATH "docs/code-reference.md" :GIT-BLOB
   "ce9a8a5a9a8ef8d58833bb239199bbd2e1f6019a")
  (:PATH "docs/editorial-policy.md" :GIT-BLOB
   "23c70f794c8640f050be6eda8d1f75fbeeb13540")
  (:PATH "docs/editorial-review.md" :GIT-BLOB
   "9264d1e4e9b0189d3b3f5a5f3c8cebe5f5d728ec")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "d83cff978b0e2c61bfbf1308e4fdcdbd38fb4ebf")
  (:PATH "docs/formato-indice-full-text.md" :GIT-BLOB
   "be3b1b6661023f58d985a26c07c15216cb099a66")
  (:PATH "docs/full-text.md" :GIT-BLOB
   "29a9ee662cd39c103edaaf046bc8b68731bd8df4")
  (:PATH "docs/github-pages.md" :GIT-BLOB
   "1d624b0c03aa60ee582ce4c98c83b38272c0dc75")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "8c460a969441f5be9d94766fff808f15d6d33f36")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "0c946fd449c68453ea89231234ec67431189414d")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "af4e816a0da1be43b48fc88866c6e07d68447d2a")
  (:PATH "docs/implementazione/active-recovery-metodo.md" :GIT-BLOB
   "5724560732e14d6d374483aa71ca0f7802541df5")
  (:PATH "docs/implementazione/active-recuperato-metodo.md" :GIT-BLOB
   "32524af882ad0a043f6d939994c9a6a11769fef9")
  (:PATH "docs/implementazione/active-recuperato-verifica.md" :GIT-BLOB
   "23af8d8e23577a92d5c0e74884061cb56639d55d")
  (:PATH "docs/implementazione/active-recuperato.md" :GIT-BLOB
   "0b685aa69fd7c078994b5d1feaa4b5b93c1cafc8")
  (:PATH "docs/implementazione/adozione-closed-runtime.md" :GIT-BLOB
   "21630d85433210b2f061c422c931ef0f14ad0b61")
  (:PATH "docs/implementazione/adozione-controller-runtime.md" :GIT-BLOB
   "f2f7826b7eb58b681d334e29834ddd1cf09fed06")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "797a1998753834a3204075954c9cfe81a0f064d4")
  (:PATH "docs/implementazione/archivio-csn-revisione.md" :GIT-BLOB
   "c886079a0ad9f47ae864fbb63084960f897e55fa")
  (:PATH "docs/implementazione/archivio-csn-verifica.md" :GIT-BLOB
   "873f06c415107bac58d781df316e5b484222316a")
  (:PATH "docs/implementazione/associazione-file.md" :GIT-BLOB
   "02e39a32261a5a901ca45e15dcc7505819a969e0")
  (:PATH "docs/implementazione/attivazione-indice-m1.md" :GIT-BLOB
   "cd609a5e9645be680b23798e0bda841d8507d772")
  (:PATH "docs/implementazione/cache-pagine.md" :GIT-BLOB
   "1eaeb517c655d918d307d46423e4aee54f39290b")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "3dbae0d9e595f509621e6bf6dd3380a5ed844f1d")
  (:PATH "docs/implementazione/cbor-array-decisioni.md" :GIT-BLOB
   "948258bd302c1820210e439862d432d8c5554e9e")
  (:PATH "docs/implementazione/cbor-array-lettura.md" :GIT-BLOB
   "c419ecc31f9e905f4d053fd4473c8b605415dc4d")
  (:PATH "docs/implementazione/cbor-array-metodo.md" :GIT-BLOB
   "a5e53c22e391f72573f89c01f58ae28fa1c40376")
  (:PATH "docs/implementazione/cbor-array-revisione.md" :GIT-BLOB
   "f992654650b2fb08a59058b337fef63f901bf75c")
  (:PATH "docs/implementazione/cbor-array-risultati.md" :GIT-BLOB
   "e4c253fcfbe86fd2dfce2bd3354614a67f4b97f5")
  (:PATH "docs/implementazione/cbor-array.md" :GIT-BLOB
   "0f8fa2876a7366cd62bd1b8669251e2107b19b7d")
  (:PATH "docs/implementazione/cbor-float-scrittura-copertura.md" :GIT-BLOB
   "c1f596a69e83504ff3fd2c7cf569f234e1c6554b")
  (:PATH "docs/implementazione/cbor-float-scrittura-dati.md" :GIT-BLOB
   "618a4fdc1d5fbb230414931295ff0f7ef9367c84")
  (:PATH "docs/implementazione/cbor-float-scrittura-decisioni.md" :GIT-BLOB
   "cd76b3d2b02c6c021849b2b85d1a403d76e38f78")
  (:PATH "docs/implementazione/cbor-float-scrittura-lettura.md" :GIT-BLOB
   "11a065b51085a23f42df7ca75e315cbee0328e70")
  (:PATH "docs/implementazione/cbor-float-scrittura-metodo.md" :GIT-BLOB
   "6c046bb92cc291fb00914da89e0eefb705b4ae65")
  (:PATH "docs/implementazione/cbor-float-scrittura-revisione.md" :GIT-BLOB
   "870474964d88a8b4099bf00cc31c0b2bc542f94a")
  (:PATH "docs/implementazione/cbor-float-scrittura-risultati.md" :GIT-BLOB
   "84faa8d4bbf5150c4b9df17879b5dd0b39a286d4")
  (:PATH "docs/implementazione/cbor-float-scrittura.md" :GIT-BLOB
   "c14c7bbaebcd803c24f62adcda19259b16f00e52")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c7fe2a7bad385932a72141de4ae46f04bbd8ce18")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "dd7621ec9feea82adec89e00ed232b22d8aead35")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "4984c8c845da1437c212f47a7a345979df1c5acc")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "ba09a11d806999c55e0cb75f5b638d1fe2cb0476")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "29f9c13299d7b2fbcea64db535c0ec3fd4456f73")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "fb04b79a27ae65e2097c21ace50ee70f26bb0e8a")
  (:PATH "docs/implementazione/cbor-item-decisioni.md" :GIT-BLOB
   "800cefe6cf8f8a8000dad71d3807df7e7efdd210")
  (:PATH "docs/implementazione/cbor-item-lettura.md" :GIT-BLOB
   "57bcf4f8d1c40334c68d53ad2b4a2092e769d8d1")
  (:PATH "docs/implementazione/cbor-item-metodo.md" :GIT-BLOB
   "05b4a0d45c993c6bfebb0555098334f40db82f33")
  (:PATH "docs/implementazione/cbor-item-revisione.md" :GIT-BLOB
   "de0ef7bc19fe539d4aef7cdc1c1f5345b8002a94")
  (:PATH "docs/implementazione/cbor-item-risultati.md" :GIT-BLOB
   "8b02e00a9d43febf09b846d1bf6a01ebee2b3005")
  (:PATH "docs/implementazione/cbor-item.md" :GIT-BLOB
   "8548c091f11308380d4ac4e01ff884644b470281")
  (:PATH "docs/implementazione/cbor-map-decisioni.md" :GIT-BLOB
   "f44e789f6d2bf153580332fb136e46cb9e57194a")
  (:PATH "docs/implementazione/cbor-map-lettura.md" :GIT-BLOB
   "23a1f7f9653522ebf02619977dc2d74ed275f891")
  (:PATH "docs/implementazione/cbor-map-metodo.md" :GIT-BLOB
   "50ad5d1f64b5dbd37f4285306c5430789e0c581e")
  (:PATH "docs/implementazione/cbor-map-revisione.md" :GIT-BLOB
   "4f9c6c7a2e2eed16e73bbb314f5936182d371420")
  (:PATH "docs/implementazione/cbor-map-risultati.md" :GIT-BLOB
   "5322d5cdd93ea61e00830138091c72eadd5effe9")
  (:PATH "docs/implementazione/cbor-map.md" :GIT-BLOB
   "3f4f8e64c19f21958bcc913a1ee701cc55a18f06")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "998d3f4d69a4915bd3d5ac13381d89b15a22afaf")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "1c7b8bc426f5054aa88e7b2cf8ce1d0c339e112b")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "d34c7e0e8b9347228e9c3121358824f106d1e663")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "8beb9758140566348297f59d8a85a1c6816c70ae")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "464af7d4e2264a4c7e0336b2219a0e886cd04c2b")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "a0a4beb749f27b8fdd721492a338ff29acd18420")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "3ac17f24029e9c242146cd994a7b2b907ef8177d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "1a2a1bc130b5e3f343f110bd9ccca2de3486a19b")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "ef1defbeb7d0f2f52a289e03fa52b7922bd8fff2")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "980896a21ef91e13e4c3a4d414d72115eb27fee1")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "a0533ae26074d23c19b098bcf11d7f3959c3b609")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "c3bd5167d49e4e2bc59bff90b6e62e3435ed43b6")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "556fddff139cb8660db889b3b1cb39046972c01f")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "d0bb1a35f08dc97dcb4e03e70e521707c8a8d29c")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "05a927871e8257d31d40c727f88858cc10f3f5b3")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "7b606f5d5c44abd25a7cea635c2e3086f7b08d7a")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "0c3f81227199b06df304e9e3bcbc6c98660bacc8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "54852d32fb4a642db32067148adbf6d9fb22a066")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "ab773c5d9261846c39c09f6cf06566344acd4ff9")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "a3e52d83ef8dab364c1e290a003fbcac3e4703b5")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "943ce8b93716e53b1048dbb672ecb01ecf2ecf2c")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "3bc420d5c29b2005395fdbf72ba1fe12fa0feb20")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "12ed41add43b64cf9a0cf317dab6a09a0f6a8f5e")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "7299368dd4c077d8e620e6a3f6b91dde5cde96c3")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "ee75788591cf776a011eddef4384ce6c9b0c1cf8")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "b5e504a3508da8c72295f9fa7a18ba44a482b547")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e5b9990f00978da272fac6353b4706e9cdb3e80e")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "46f011d10fbd376c7387ffe48a9730a3a2620b05")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "d33e32c7e570f1958c8af75a789ea3a6583e4289")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "032c6c20aa5e116d2c1fa4214a0701e40620b966")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "77e0e458eb0cfbeb0796d176ff54805fcec9fc13")
  (:PATH "docs/implementazione/cbor-stringa-lettura-decisioni.md" :GIT-BLOB
   "a307a12444fd16df6ad92dcdf8717f02e76ac7a8")
  (:PATH "docs/implementazione/cbor-stringa-lettura-metodo.md" :GIT-BLOB
   "3378a194f4eded0fc1316be064956d77b3132fb3")
  (:PATH "docs/implementazione/cbor-stringa-lettura-prima-revisione.md"
   :GIT-BLOB "6fb1e3c3cd8a7512958b54095940826c30980eed")
  (:PATH "docs/implementazione/cbor-stringa-lettura-risultati.md" :GIT-BLOB
   "b50555a7cf2b592b5c36b2d094d7500225581f06")
  (:PATH "docs/implementazione/cbor-stringa-lettura-seconda-revisione.md"
   :GIT-BLOB "ebfc3d0bbdd1a19a295c55770a6d505ddbd4aa84")
  (:PATH "docs/implementazione/cbor-stringa-lettura.md" :GIT-BLOB
   "9eecb30c6b1887b9a0a5f5aabe3516916c3ba025")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "82f1683ba3774d33e82fd23e118790e401c11085")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "ff78a1940b29beef1c4e685e2084767c948f9da0")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "280b19d5e97d5487ba6be4f59da8b015063074bf")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "7ac03f1075bd778be47916ef9eef72e5bcdc90ff")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "08f016eb4a073cf59dbb3c5c9b23791d4a1285ef")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "c17e8ed2fb902df4c971d0300c1c7842dd46a764")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "16b04b9a5451b880ea2449104f65e261ba7f6c7d")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "66c94d76bdb2c46714ea86774489f31580ac63c9")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "d64b31030580f02466562e86efae7cc27451d0a2")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "16ffa1f24020338735660b5b008fb3e00c498ea4")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "39fa55a82334440ea17d53dbefe050d53db6a716")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "5e801a7632e7ce46f56e79cad2073b3e155eae99")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "c77993b00f09e89d21d2ab2eb319964e9e2fa819")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "2221900158acbbd5cdaa39d3301b08501c071e97")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "e29635a7ce3cd150ea0801c4610ddd03af941c8c")
  (:PATH "docs/implementazione/cbor-tag-decisioni.md" :GIT-BLOB
   "f0329ac5196815f633bf7abc82c97730cee832a5")
  (:PATH "docs/implementazione/cbor-tag-lettura.md" :GIT-BLOB
   "49146a982d1297edaf0c31daca7c5eb6150a6ea7")
  (:PATH "docs/implementazione/cbor-tag-metodo.md" :GIT-BLOB
   "ffa487840cb2e0964e7fa7a7cd55d57fbeed3de4")
  (:PATH "docs/implementazione/cbor-tag-revisione.md" :GIT-BLOB
   "b61c84f5f4a70f3009748536709d37c2609d89cd")
  (:PATH "docs/implementazione/cbor-tag-risultati.md" :GIT-BLOB
   "a78c3f04408c306f2cddcc617274f2335b17fc81")
  (:PATH "docs/implementazione/cbor-tag.md" :GIT-BLOB
   "a67789164c1ca9ab5be6435322ae77606314831f")
  (:PATH "docs/implementazione/checkpoint-control.md" :GIT-BLOB
   "2e2d90188ad3b3bec79f9a2c90e9f2cff58f3c42")
  (:PATH "docs/implementazione/checkpoint-recovery.md" :GIT-BLOB
   "fd1444d3e09f58457eb3babe639bc93634e32aa3")
  (:PATH "docs/implementazione/ci-provenienza-pr.md" :GIT-BLOB
   "cfe42a5fe0ebb52b0c1217926a15078d8baf4cea")
  (:PATH "docs/implementazione/ci-statistiche.md" :GIT-BLOB
   "6d6d3ad1d0381ab4bf946a6c1e7561f5266ad494")
  (:PATH "docs/implementazione/ci-wire-processi.md" :GIT-BLOB
   "537159570d4bdc8e7dbcddb5be3dd9e2d57c26eb")
  (:PATH "docs/implementazione/closed-recuperato-revisione.md" :GIT-BLOB
   "38373f1de3d42b5e9056e60d30f215083a80c845")
  (:PATH "docs/implementazione/closed-recuperato-verifica.md" :GIT-BLOB
   "1c4b3e4f0e6c3d3c4519dcdd56c7a2ca8ca2d47d")
  (:PATH "docs/implementazione/closed-recuperato.md" :GIT-BLOB
   "3675c4a21cd14e15f136f1bdcd6e0c64f28564bc")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "07c702f3b926311b7af6950382459286f20c9d05")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "7c9473c0d5149a7cefab4ef33076c7f44bfe9f30")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "2dd9f8ab7dbdc2df6a41874a63aa62f45fa11ba8")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "714da56672b38ed721a71f7d81986f66ca3915e6")
  (:PATH "docs/implementazione/control-recuperato.md" :GIT-BLOB
   "050723cbdec05ccf343e6cf651023dbba053fa60")
  (:PATH "docs/implementazione/control-transizione-metodo.md" :GIT-BLOB
   "4af36a8e4c9c409cccb82beacd9a7243057c2b76")
  (:PATH "docs/implementazione/control-verifica-metodo.md" :GIT-BLOB
   "8ffecd3625f0d1c3b4cf5786e17354cd170a127f")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4e75306fe31c84d552c342f4294894121d647097")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "4c8e017a2fc5e52b4a26d3f90c50d2e89f90e5f1")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "a294f643c70035056ce585a186fe4fb0ad1f01f3")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "6a48c794b8d8619e762c0c33108175d26dab2235")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "e3bc4006b2c53306af00f16d8967e002be5be7f2")
  (:PATH "docs/implementazione/controllore-pool-decisioni.md" :GIT-BLOB
   "e45a4a1609e6ad2c4a8c507a3b6474b34329fc7e")
  (:PATH "docs/implementazione/controllore-pool-metodo.md" :GIT-BLOB
   "9452ebefc6280a045c051c394e3ab55a9b5b7b90")
  (:PATH "docs/implementazione/controllore-pool-revisione-2.md" :GIT-BLOB
   "f4b54f7f20f0dbc620c95098dfe8f7d11e00eb84")
  (:PATH "docs/implementazione/controllore-pool-revisione.md" :GIT-BLOB
   "8331ccdab4e1957b7eaa4ff7404ab2ed263fa924")
  (:PATH "docs/implementazione/controllore-pool-risultati.md" :GIT-BLOB
   "e0738c5de4ceb793d70419ac8fece82e1de2359d")
  (:PATH "docs/implementazione/controllore-pool.md" :GIT-BLOB
   "32a0876c84705abfb03a324d93c0e09997e8caaf")
  (:PATH "docs/implementazione/costruzione-indice-m1.md" :GIT-BLOB
   "954e5c11aac01cdcdbbe1300ab7ad5904a31186f")
  (:PATH "docs/implementazione/costruzione-indice-paginato.md" :GIT-BLOB
   "6f4a25f0f4a8c5c5ef123b587f34313cf18493ae")
  (:PATH "docs/implementazione/crc32c-arm64-metodo.md" :GIT-BLOB
   "fd0a6f8b0203eb527434d5c85b5a21bffaa83842")
  (:PATH "docs/implementazione/crc32c-arm64.md" :GIT-BLOB
   "9d44dfe4836c393debf1e2fedd781ba8d64ac854")
  (:PATH "docs/implementazione/crc32c-piattaforme.md" :GIT-BLOB
   "c48393540f18a1982fa9523d82684488f2d0e9ed")
  (:PATH "docs/implementazione/crc32c-unroll32.md" :GIT-BLOB
   "f9b81bfbbfe41d6f0433df1275b14e0ddb277521")
  (:PATH "docs/implementazione/csn-archivio-recovery.md" :GIT-BLOB
   "0501c6e7d687db9aa0196637ea4ceb5032d398b9")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "f3c71d7a014741290c658cd958ca5d5b6e5076a7")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "6809b9ff79f77032c94c726a67913fd86ed590f4")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "87df34a5915fead7f06bff837dfa0b904f9eb664")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "ac014f8282cf46645dd18f92f16bff17ac1da0b4")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "3d69beb591d794d62111bb695cf87fc6c4726e2c")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "7979e6edd61ac9300d6560b493a61948a4fd0d92")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "62df2e33eb3daa289da2fd2d544db1e367495b76")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "2ab09dc900d919686bd211a1fc0c9e233d6d8bbe")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "26b8a34a0c455ffa1244cd8930718ad68067983d")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "475fcdde02949a8500168f29ab43891d70fe7fa9")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "7e01085ba74008ba3f3715415c7196de10efe61f")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "a2f17134ae38a241a5610af3f00051f0e1c6bca5")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "04724b6857c83e623ba245bef65c657f416bbced")
  (:PATH "docs/implementazione/decisioni-recuperate-revisione.md" :GIT-BLOB
   "e8ec567a22d4a0b7f365d7649622e9a3405e69e4")
  (:PATH "docs/implementazione/decisioni-recuperate-verifica.md" :GIT-BLOB
   "efae51de3ab17894525f9803c2caa2dab2caa737")
  (:PATH "docs/implementazione/decisioni-recuperate.md" :GIT-BLOB
   "877dab2bc85bec554965e906163a950fa7f42dbb")
  (:PATH "docs/implementazione/delta-indice-m1.md" :GIT-BLOB
   "74b4d0337972db90f897380d1acf29cf56b5387d")
  (:PATH "docs/implementazione/delta-location-m1-metodo.md" :GIT-BLOB
   "546cbb2eb9169663e412972c9ffa3dfdd7a44eb7")
  (:PATH "docs/implementazione/delta-location-m1.md" :GIT-BLOB
   "dd39d0fa56ef87edaac933052523fb1092af9891")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "23c6bd3464be1c5de0e85dd1ceef49cb072e2610")
  (:PATH "docs/implementazione/evidenze-parallele.md" :GIT-BLOB
   "c1cf798f1d7aa870e6fc08666fb089bd0078f1b2")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "9ce191f9a921d27dd12773f67b2ea9dc2b724c11")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "5988fea2f0c49b45d4da2152cd2f213f7d4a3bbe")
  (:PATH "docs/implementazione/fonti-recovery-metodo.md" :GIT-BLOB
   "71889d31dc82e1ce9cb80228debcd2aaae265ca3")
  (:PATH "docs/implementazione/fonti-recovery.md" :GIT-BLOB
   "b613cfd01ebf4f093fd8d5b4f6ea14c2c43b1156")
  (:PATH "docs/implementazione/full-text-codec-decisioni.md" :GIT-BLOB
   "d84b4a8ea730f7eb6a08f7578322a9cbab97cc27")
  (:PATH "docs/implementazione/full-text-codec.md" :GIT-BLOB
   "dd648030eb25834fe6d66bf6fb61fad777ef7906")
  (:PATH "docs/implementazione/full-text-decisioni.md" :GIT-BLOB
   "891a19e59ded15ce976428e647431e6087fcda8b")
  (:PATH "docs/implementazione/full-text-documenti-decisioni.md" :GIT-BLOB
   "6df6ad62e11ea8977a258a6e11e774488c131e97")
  (:PATH "docs/implementazione/full-text-documenti.md" :GIT-BLOB
   "813e65fa97477a4d4451c483e137540af95cd667")
  (:PATH "docs/implementazione/full-text-put-metodo.md" :GIT-BLOB
   "2526a07b957970e7abc7f6baae970c2162d9b68e")
  (:PATH "docs/implementazione/full-text-put.md" :GIT-BLOB
   "a480bcb65e37731737a70f16554ca9e5e8cf8ee0")
  (:PATH "docs/implementazione/full-text-riferimenti-metodo.md" :GIT-BLOB
   "0cb603ba80950501cb439b61b4645274188ec75d")
  (:PATH "docs/implementazione/full-text-riferimenti.md" :GIT-BLOB
   "d363ee6d5e8e55f35668fbb129c2cf1f626a6d16")
  (:PATH "docs/implementazione/full-text-righe-metodo.md" :GIT-BLOB
   "2f576876ff695c0b662b91f8deea5b3793c3bc5b")
  (:PATH "docs/implementazione/full-text-righe.md" :GIT-BLOB
   "c6b643c4cf20d6b4378f7bfe7f05132cd4ba1d10")
  (:PATH "docs/implementazione/full-text-riserve-metodo.md" :GIT-BLOB
   "17663cca4a20e28e53be920eaa83792b520354a4")
  (:PATH "docs/implementazione/full-text-riserve.md" :GIT-BLOB
   "154f11b6ffc05e72273d3ab4a0b7a5d3867ad3a7")
  (:PATH "docs/implementazione/full-text.md" :GIT-BLOB
   "10317557bc507e5b786a0564626bc3109e851c46")
  (:PATH "docs/implementazione/get-active-metodo.md" :GIT-BLOB
   "de07ae6a11977904595cd321e2fdfb229cb0bbc0")
  (:PATH "docs/implementazione/get-active-preflight-metodo.md" :GIT-BLOB
   "2557776ad0c8c99e3c479ebfd557b6c912dd503d")
  (:PATH "docs/implementazione/get-active-preflight-verifica.md" :GIT-BLOB
   "2616f8e780fbc697519bc3517591c54197bd37f5")
  (:PATH "docs/implementazione/get-active-verifica.md" :GIT-BLOB
   "f46fdd16bd2ff24d0caa1426706db284b6e9f583")
  (:PATH "docs/implementazione/get-active-vuoto.md" :GIT-BLOB
   "4a9988d8277e40527ee761df7b55a44897c827db")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "3f09685689be3207d6d3689b3e2383060092c9e4")
  (:PATH "docs/implementazione/get-costi-metodo.md" :GIT-BLOB
   "fb1926959f835883b7d88a5dda7bdea7f30998b8")
  (:PATH "docs/implementazione/get-costi-risultati.md" :GIT-BLOB
   "655b8a35ae16b285e8c5da3ee0249d47a7629c57")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "56133e69f5a305d3d7ed173361a60d11dc8083a1")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "242e710cf037c17f94ce2c6213210b87e1cd5108")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "017acf3977bd60a59c7cc3c093c084dc5742d8d6")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "d25a0d6bb499867c8e74865f76064205c70a904a")
  (:PATH "docs/implementazione/get-fonti-serie-metodo.md" :GIT-BLOB
   "0b3f2db806973acd21c7b0cb4fe203656db06baf")
  (:PATH "docs/implementazione/get-fonti-serie-revisione.md" :GIT-BLOB
   "91c14197cca8cfa11f46b4f5e2ef5cc03e269507")
  (:PATH "docs/implementazione/get-fonti-serie.md" :GIT-BLOB
   "ef7f5f3ae5748673a74ca960d3c5bb1c6e1dd44d")
  (:PATH "docs/implementazione/get-lifetime.md" :GIT-BLOB
   "3c83a87b6b59b2432c54145ff6d8e5144c7864be")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "953b28082bc52d2925a43c6e78ef19e9cd7710b6")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "adad30953d4d419ccd39475545619fb9e32b1392")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "a85bb276b698a7c20da89fb2fb23e19aef2bf5e0")
  (:PATH "docs/implementazione/get-resolver-metodo.md" :GIT-BLOB
   "fe7942c088ae3aa68d0e15e04c9f46faf05622ac")
  (:PATH "docs/implementazione/get-resolver-verifica.md" :GIT-BLOB
   "67b906cd6e8b8569f97a766b66deebd57f4be501")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "753deeb7ec87fcfdc7c8c1275368fa947827ac37")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "5d14690cdad3e3517bcd32522fd9b26f10475eac")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "4515dcc663abeaa09a60ea4c8b3bd6df1baad2d9")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "9a6c1470083bbd595277d9a9f3b430ff0c5f85d6")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "b8204499bb41f33cea556a86eab9551f8709de40")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "695650c8c40cd1cbe9ad38eed29698b7b71ba97f")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "78a7da074a3daca5f05793f03b88fc4ce45321aa")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "c1a36112a2dbf6afef54a654c262389ba9037ba2")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "83b6d477b9d16697c2002989891657ba95ee4e6a")
  (:PATH "docs/implementazione/id-directory-recovery.md" :GIT-BLOB
   "6ea173a4f8c1210432f00d11e6ce6aae4ad1174b")
  (:PATH "docs/implementazione/id-segmento-recovery.md" :GIT-BLOB
   "f2fa99ae8a932406bb74666fa401e0aa9b2655a0")
  (:PATH "docs/implementazione/immagini-indice-paginato.md" :GIT-BLOB
   "8e88cc05ab5ee90c1a1c98d9b20859b652a97bf3")
  (:PATH "docs/implementazione/indice-automatico-completamento-metodo.md"
   :GIT-BLOB "c354d887b3102978bf827b1959e323b7d9b18b27")
  (:PATH "docs/implementazione/indice-automatico-operativo.md" :GIT-BLOB
   "e70a739bfd63091d2ba9cec5c6fd6aa821e4d669")
  (:PATH "docs/implementazione/indice-automatico-risultati.md" :GIT-BLOB
   "d8823f505faa11809cea64f9f3c90675b0198fb0")
  (:PATH "docs/implementazione/indice-automatico.md" :GIT-BLOB
   "614b528773e7b34f955143e0afea744d431e2e1e")
  (:PATH "docs/implementazione/indice-da-recovery.md" :GIT-BLOB
   "486481170704785730c471af7dfd1a5816243a04")
  (:PATH "docs/implementazione/indice-paginato-m1.md" :GIT-BLOB
   "fe476e799ce3ec29caebbecb1a112a2e04bbe2f7")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "4e34fc8e0ffc4413a921b5538edd63693281b70e")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "439aa57177f9323735aaf1e8c4677cdf17e29ad7")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "3935af00f6b06ca6fbca8ab7a8c977eab164322c")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "32dd19680071319c88e9a91a0132260e921573d2")
  (:PATH "docs/implementazione/inizializzazione-active.md" :GIT-BLOB
   "d4c99e5ce4fb98ef862944a7cc41c08205cf60f7")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "56795353bfac9ce5c3ebc0b69f704890d306c194")
  (:PATH "docs/implementazione/inventario-directory-metodo.md" :GIT-BLOB
   "1c6d345a7b2d02c2687f08474a7805e79160b615")
  (:PATH "docs/implementazione/inventario-directory-revisione.md" :GIT-BLOB
   "42511becdd73740fd1ea37f271dc7d4482ddeb74")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "caab01e598ef66377c6da22dbcec17db820b8b91")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "7fcabec950c4e85735ab5bd7960cba65d0b1b494")
  (:PATH "docs/implementazione/io-apertura-relativa-metodo.md" :GIT-BLOB
   "fa44089871f66bddf1309fa5d75b4678eef58902")
  (:PATH "docs/implementazione/io-apertura-relativa-revisione.md" :GIT-BLOB
   "8b13ab5dd4831710adfa606e5edf659e31c8a714")
  (:PATH "docs/implementazione/io-apertura-relativa.md" :GIT-BLOB
   "975eed05b2318ed9b85f4d6f860c2431248f1db7")
  (:PATH "docs/implementazione/io-completamento.md" :GIT-BLOB
   "b5982e35ea000c4c9dcc91021374849d6670638b")
  (:PATH "docs/implementazione/io-creazione-relativa-metodo.md" :GIT-BLOB
   "84b9f6ac1bf934fb7c34e178542cce9dae62fdc6")
  (:PATH "docs/implementazione/io-creazione-relativa-revisione.md" :GIT-BLOB
   "6ad24b936952f03d7a70827f10314ac7f0ad1dfb")
  (:PATH "docs/implementazione/io-creazione-relativa.md" :GIT-BLOB
   "0a0d30b8c6cf826cb906b7d7d26bc8c4c68b3b8d")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "d6eb46b50c73b0150eddbc34cc93f127e82163dc")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "92c01fe2ab85af78f2f3cbf68cdaababa61f5ed9")
  (:PATH "docs/implementazione/io-pubblicazione-metodo.md" :GIT-BLOB
   "bdf72add9058e53ae707719af4ead4d18f462946")
  (:PATH "docs/implementazione/io-pubblicazione.md" :GIT-BLOB
   "f56f5f2f22e43b665a472d8560143b9430ea9ded")
  (:PATH "docs/implementazione/io-rinomina.md" :GIT-BLOB
   "d699c8433a309044b041ec1e2a0713ddb7d6f120")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "3db1a3257313b7040dd2b1222f4de77166de75da")
  (:PATH "docs/implementazione/lettura-indice-paginato.md" :GIT-BLOB
   "ce43161a04c6068b3ddce5b8eee94f35e46c5872")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "1fa26d055d5ee76d3a9bc6f6e6e31a3af3c0e0f1")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "91b0ee252ceff9071c62a573b7b499b8e36e1964")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "4b69dba2809dc40a4d039a6106dd02e560c8e26c")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "20b9246ebddba96db237e5ebcbf2529afbd26a91")
  (:PATH "docs/implementazione/manutenzione-indice-m1.md" :GIT-BLOB
   "bcf08f6c98961ee5660483cd627244c1243f2a99")
  (:PATH "docs/implementazione/merge-main-2026-10-23.md" :GIT-BLOB
   "cb672d06673d639a152ef3bea52b73f258513473")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "332563a00301c759a56fa56efeb0c733f5d8acb5")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "daca7cad14916fbc0b10743a6898bfba4f6c47ad")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "2789dc59d0173d4e0af289cfac129ab12d1bec00")
  (:PATH "docs/implementazione/moduli.md" :GIT-BLOB
   "04085bb65a97af3cf46e9a0ad4a3b491c3009648")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "48ffbd9f476751940bbae8713788bd1d812a6002")
  (:PATH "docs/implementazione/pagine-indice-risultati.md" :GIT-BLOB
   "e8889ba9c0d836e73050037bd49faa9ae016a5a6")
  (:PATH "docs/implementazione/pagine-indice.md" :GIT-BLOB
   "34c6c7dec3f852d8dc6245a6c05a7f26ef2d09a5")
  (:PATH "docs/implementazione/pool-begin-metodo.md" :GIT-BLOB
   "8d10cde6f53e6e75cd936fa109121d0caab09d5f")
  (:PATH "docs/implementazione/pool-begin-revisione.md" :GIT-BLOB
   "95657e20c25dd27baddab5c04a2053170af45b96")
  (:PATH "docs/implementazione/pool-begin-risultati.md" :GIT-BLOB
   "c4049dcf13b516abf81bbea4d32aff64cb425c7f")
  (:PATH "docs/implementazione/pool-begin.md" :GIT-BLOB
   "06bd817d57eb415225973e0981778132621cf230")
  (:PATH "docs/implementazione/pool-catena-metodo.md" :GIT-BLOB
   "758327137a15f0f1ef344d51370add33a3a2c6cd")
  (:PATH "docs/implementazione/pool-catena-risultati.md" :GIT-BLOB
   "8bf6c0fe47438107778c68195e6f98ccb42b0b9c")
  (:PATH "docs/implementazione/pool-dispatch-metodo.md" :GIT-BLOB
   "eb6709befc9bdb0d67b04fd5c4c4f98a01ab94de")
  (:PATH "docs/implementazione/pool-dispatch-revisione.md" :GIT-BLOB
   "abda6bf2dbaa1fc5fdc6e55cc22bb0ee931513f2")
  (:PATH "docs/implementazione/pool-dispatch-risultati.md" :GIT-BLOB
   "ab68af4bc1ab1552d74c694ce96c1e1c4222920f")
  (:PATH "docs/implementazione/pool-dispatch.md" :GIT-BLOB
   "a540afacd7952495cc3300e0bced676639c55337")
  (:PATH "docs/implementazione/pool-prepara-metodo.md" :GIT-BLOB
   "4da00d6f92b7f949ec8acafbd3a97dd56bbbb367")
  (:PATH "docs/implementazione/pool-prepara-revisione.md" :GIT-BLOB
   "2c5e9f14f01fedcb7e3dc7a3b4ade9b8bfdcc9b6")
  (:PATH "docs/implementazione/pool-prepara-risultati.md" :GIT-BLOB
   "8c5a986a075da0555e225369bb08b72e4994558b")
  (:PATH "docs/implementazione/pool-prepara.md" :GIT-BLOB
   "84dcb4f1603e43af42c335d58a1d67ebe6347ae0")
  (:PATH "docs/implementazione/pool-recycle-metodo.md" :GIT-BLOB
   "2c811c8f11f65e5142e23c6d8e306b44e412d1e0")
  (:PATH "docs/implementazione/pool-recycle-revisione.md" :GIT-BLOB
   "100e57b2835ce7bc6b5dc68912cf99ae1e637c30")
  (:PATH "docs/implementazione/pool-recycle-risultati.md" :GIT-BLOB
   "4a192b8293368b041956bf12a8e266bd08d86cb5")
  (:PATH "docs/implementazione/pool-recycle.md" :GIT-BLOB
   "40dcde9abd1d21cf1d0d56cecc3b66c641b607b8")
  (:PATH "docs/implementazione/pool-step-metodo.md" :GIT-BLOB
   "e44a4958a4c0a67213243b112bc7362f0573e914")
  (:PATH "docs/implementazione/pool-step-revisione.md" :GIT-BLOB
   "66ab0543f271b9a5c96cb6aa2247be4d6925fd59")
  (:PATH "docs/implementazione/pool-step-risultati.md" :GIT-BLOB
   "470c7dc02213e5d01719829413da36ec08cc5d4c")
  (:PATH "docs/implementazione/pool-step.md" :GIT-BLOB
   "09a4edba6f17bed9682708707ecbe188b2b8e101")
  (:PATH "docs/implementazione/pool-worker-claim-metodo.md" :GIT-BLOB
   "b1b933f896ebb4b2c54a2a714a4c4291c431662d")
  (:PATH "docs/implementazione/pool-worker-claim-revisione.md" :GIT-BLOB
   "18aef79552d243af35866c3d2955e2d11761935d")
  (:PATH "docs/implementazione/pool-worker-claim-risultati.md" :GIT-BLOB
   "f0ce19f06da992cf25de5b3dd396258b7197105c")
  (:PATH "docs/implementazione/pool-worker-claim.md" :GIT-BLOB
   "5a69ddd2dad8066ee9d03792f8548abb9225222f")
  (:PATH "docs/implementazione/pool-worker-lifecycle-metodo.md" :GIT-BLOB
   "d32a1e07253c9138b176912091366712ff3037a4")
  (:PATH "docs/implementazione/pool-worker-lifecycle-revisione.md" :GIT-BLOB
   "9638731f43392e0a33b7f4ed84b19d6c46d1b0fa")
  (:PATH "docs/implementazione/pool-worker-lifecycle-risultati.md" :GIT-BLOB
   "d26d034ded38c3feb056a5a272e5147d790b36f6")
  (:PATH "docs/implementazione/pool-worker-lifecycle.md" :GIT-BLOB
   "5a1af3956ec7cb503cfe7b561acc66e3b32029ad")
  (:PATH "docs/implementazione/prestazioni-local-m1.md" :GIT-BLOB
   "d09055552b7b9fa8d15cd552465dc1025defa2d6")
  (:PATH "docs/implementazione/production-engine-bootstrap-metodo.md" :GIT-BLOB
   "92ea9255903acb119f72d1a61affda35f94a9358")
  (:PATH "docs/implementazione/production-engine-bootstrap.md" :GIT-BLOB
   "110fc6b64792152c41674c8a9e51ca47f45d653a")
  (:PATH "docs/implementazione/production-unix-m1.md" :GIT-BLOB
   "d96cdb1e30cf8112586f6707267a0533e1b1fa30")
  (:PATH "docs/implementazione/prova-verticale.md" :GIT-BLOB
   "3b9642adce018f1bba63fca6cfaad10924f0351f")
  (:PATH "docs/implementazione/pubblicazione-control.md" :GIT-BLOB
   "8dee23aebeb7bd74de78153bff357b6810162ca0")
  (:PATH "docs/implementazione/raccolta-comandi-risultati.md" :GIT-BLOB
   "0e8a853a5618a1906dd4adbb7c9b18840959d03e")
  (:PATH "docs/implementazione/raccolta-comandi.md" :GIT-BLOB
   "69a9ac538805c31b2857a55f2d5b5c32c0a71b38")
  (:PATH "docs/implementazione/recovery-archivio.md" :GIT-BLOB
   "728fcfa388c5032d170b4f1924b6d614857baee7")
  (:PATH "docs/implementazione/recovery-csn.md" :GIT-BLOB
   "0a3b62e567853df795b710c8e080e3e4319d5153")
  (:PATH "docs/implementazione/recovery-serie.md" :GIT-BLOB
   "fb61bc33d840d815c72dcb3eb4c74c909708d42c")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "09620fc2b2248bec312b075e411f6864a5ebf16f")
  (:PATH "docs/implementazione/replay-closed.md" :GIT-BLOB
   "bb4499a07188b2887c5960e3eba59c951d80a159")
  (:PATH "docs/implementazione/rinnovo-automatico-m1-metodo.md" :GIT-BLOB
   "061f7030b0c9486754cea7333ee3838cf5f00e59")
  (:PATH "docs/implementazione/rinnovo-automatico-m1.md" :GIT-BLOB
   "29fbd690f61f74593e280c1be93b64d74b2609cd")
  (:PATH "docs/implementazione/rinnovo-indice-m1.md" :GIT-BLOB
   "048fb5e263d00771553c8de699ebe0e585c9c780")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "d7b9c49b07bae6f01a5562d15a2cdabcbb979878")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "2709d9ad98b8dd8028b36f0163ba09bf2f49ae14")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "fa341fd666506b060c4d1253773dd87859014238")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "569fb428d702f4a60440c10cb0d9a1a360670fd1")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "ac6b5e1ea180807849dc24481de16eb79e4999af")
  (:PATH "docs/implementazione/runtime-archivio-revisione.md" :GIT-BLOB
   "bba7a3fa2b7e2139ea24ec86cc97fb4b02909aff")
  (:PATH "docs/implementazione/runtime-archivio.md" :GIT-BLOB
   "f8efbf185c6e21920a72d7982f396f5f6e4360d8")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "54739f1b4f681ee51b684fd5f1706028a8922b11")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "24f4832f44e05b4958ee59a8b9b899228f5afa6d")
  (:PATH "docs/implementazione/scoperta-indice-local-m1.md" :GIT-BLOB
   "c6a2000090f8bf5b356b49804799739acccd1344")
  (:PATH "docs/implementazione/scoperta-indice-m1.md" :GIT-BLOB
   "4f05d679dfd56ea2922507433e26c876de136b00")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "40197f19d765e646a0e3ce558386997294130ab1")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "16a6ec600581f9c958650a8578117ad7d7d79584")
  (:PATH "docs/implementazione/selezione-versioni-recovery.md" :GIT-BLOB
   "47d2caa2887778182456420705e0228179305769")
  (:PATH "docs/implementazione/sessione-locale.md" :GIT-BLOB
   "2ecf722d1f5009738a021d2b451e71bfcf0a6c2a")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "3badf8773cc33d0a772b9bde5741af120be1db29")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "52ce3f078d06cad8ffac89ea2baa6ad830c0df34")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "d0ce2c9951518f30ccec2391bc8d9e3e508eaa19")
  (:PATH "docs/implementazione/stabilizzazione-archivio-metodo.md" :GIT-BLOB
   "e29923b3ea68b49f0d100baa7b41f221663d26f9")
  (:PATH "docs/implementazione/stabilizzazione-archivio.md" :GIT-BLOB
   "51adacc370255a8a7d7bb9cb32d5efd9d98cc21f")
  (:PATH "docs/implementazione/stabilizzazione-esclusiva-metodo.md" :GIT-BLOB
   "862b15afa8262596760a2b84e08ba266369e101a")
  (:PATH "docs/implementazione/stabilizzazione-nomi-recovery.md" :GIT-BLOB
   "19c7b3f57ea810a35ebe212071e06e27f61c3a21")
  (:PATH "docs/implementazione/stabilizzazione-serie-metodo.md" :GIT-BLOB
   "89673b60a8a5690b772ef365b2194470238efd14")
  (:PATH "docs/implementazione/stabilizzazione-serie.md" :GIT-BLOB
   "960b956f4841ce0d3a6e38612feee69f2666ab37")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "ec3c6b8f92c54a84bc98d5ac21e58758152de542")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "a60c8e7ee23f78e8a53a516e2c161fc0827ff699")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "e7cf6d0c9962ed26216d07d63d052d45bb9f03e7")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "1a94e0e95ab7446193da420d97bedc24a721d387")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "8ab0ba990681d1b185ab87aad114593c0abb305a")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "f08e66f8b7925a5bcec55f2edf1380fc66d6c0a2")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "353a2d053b16ec57b6572aed1f17d1b49d8a232f")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "15c437c7c71674f8fc1cd5a72b3162f4f1715eba")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "e20c5c59567d8ce4800dc19e8dc5fdc2f7f0606f")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "f4edff819e12b287df3cf5f00ecd3550e930f9e0")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "82bd2785271ce7480c4c8d137349c8d41dfee729")
  (:PATH "docs/implementazione/worker-cbor-interleaving.md" :GIT-BLOB
   "02c902149e07d4ac4dfc6f6170799eb34574f09a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "ab3e69cc7051d3ce33f9b4d94cd0e2b20b49807c")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "2c5bcfdaa1783a21adba6911300d0baf7d12f339")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "8fcb335ad6bc807d58ab2ec9033f948421737de5")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "8fa6801e99ffb1abca08a0861883ace20672bd2c")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "63c27916925bec8cfbc39c0c9d558eb444e6dad2")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "f35b46574ff72f1ddac7498c601be30c990d859e")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "ebea51d87dc4f0c750be5834f48d66aac19c7e2d")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "9cd61461e8bfad2d757011db0307229f1517a0d2")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "865c639e5d48a0a77133b6fbe033d78113f703ac")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "1dd65b133120e4f660ed14e674caa8d9af55cfc9")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "4812ec2f65bf772695877b5760a2528fb69a70ef")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "debe8bfd28a95306a16004ca1ccb20ff2bf85fd6")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "7a1ffa13a41b58db26e43bb4090a5d7b6732e512")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "f0ab347bf7c6974b7968e96b9615238b2b14713d")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "b3d19a3668170d14b2ee8a1cec101a27334a8d41")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "14bca7f6cd2c9976cbfdbe3a24a146bc46a34d79")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "f0fd5c63f1adaf9e08e3a7f03dd3fa62bc10aea5")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "c96e7d84ba793911aca73e1deafe6da49509b879")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "8543024839bb87730a16489183b141a010d48cfc")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "234ef34a0065f902f68cdc9432513444a303731c")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ae34240b8fcb8fecbda5492828281de203dc5327")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "07bc53c1a476b0f93bf860fa18c97573d96c656f")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "e120e67c134bd2b9ddbbf55259f5195a3ef4989c")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "85cdbcee3cc2985f6935c6508b71ae9eccf58c99")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "a7329d98d65dd7a94773a87d27f7e3d3871469bf")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "370e2848280af70fbee9085f4c5f1fb44b110889")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "3a9260af22a77d11d636a787613bd50668ffc1cd")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "1600a7f92e73a45f44214bfb2074d0c5cf6decec")
  (:PATH "docs/legal/README.md" :GIT-BLOB
   "149c30dbb116c197f5046d245f765803ed6112f4")
  (:PATH "docs/legal/accessibility.md" :GIT-BLOB
   "f0075a299d3f10c36f250343da01908f39bfc447")
  (:PATH "docs/legal/distribution.md" :GIT-BLOB
   "60ae06a99a28b346e28a28dba81925e38b762192")
  (:PATH "docs/legal/privacy.md" :GIT-BLOB
   "668c2ffde82f4149697d070851e5fdbf281937b0")
  (:PATH "docs/legal/review-2026-10-31.md" :GIT-BLOB
   "8e4053b788081e583340d3531e8c618eba2ef312")
  (:PATH "docs/legal/third-party.md" :GIT-BLOB
   "308d64af3e3901e8c8ea6209ec772f65bd55796e")
  (:PATH "docs/limiti.md" :GIT-BLOB "18a03d0c1262b4ddaddf5ff1cb3dd1777f216c3c")
  (:PATH "docs/lisp-api.md" :GIT-BLOB
   "a53a254f4225afdd5d59dffc7aebeb158b40bec3")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "f639c868ec4145ce4d712345973822ada77abb6a")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "6c2425c43abbc961ab2845fca2e3ea069b39eb81")
  (:PATH "docs/riferimenti.md" :GIT-BLOB
   "9addadca061376e75319617301e590e010ab8467")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "6d219aec5deaa4e99116741b6ba788d699868456")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "113bbeaa93a2032b3a642d626836c1d5f5d16c4f")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "df1e19c126d44b07fecbf153fcafa2c9af44e861")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "935cef690625235efeb2d36dbacb38fb83685047")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "1ae3fc90e1a01aa296c51d3f25c6d65c1bcdb5da")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "b7ef23de41612f981d34a97641e52902a1840a50")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "33f78a2faae61cd73459658d3ba2a88e2ecafe81")
  (:PATH "docs/valutazione/caso-duso-nntp.md" :GIT-BLOB
   "b6a035e1d66b869f40a42e07f2021a42d7de2859")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "972ca495cf51f54d16f3c33ca31fe890b6db7806")
  (:PATH "docs/valutazione/cronologia.md" :GIT-BLOB
   "be43f507343a1c75d71d9e4ada287a9c2fc0de12")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "32026027782790da44884b029c4bae89d5f4e1fd")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "32e72f3b579ee02d5a5e0e897a7618434b02e60d")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "2eeb123c80d9f061d21d2f1a31c57613d7707506")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "a01e78e3fd9dbfe2705fa6fda631d9c387b3bc91")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "c3173768fe23a50691d7106bddbc8c46bb8cd040")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "ed0b8c472645dd6e31178034268a7e60a34e09be")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "603665f1033eb1a62f8b9a4115250a16cf39b429")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "dca0a8b0aa20c8d038dcbc11023182fd552de10f")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "45bf66ebba21b28f569e6f12344277dce7245cd9")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "11d712a7a3432a89299a2f5d7f23736d596d7e40")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "f3eecb3e77252633aac4a62f1100a77b64ca91e0")
  (:PATH "examples/local-roundtrip.lisp" :GIT-BLOB
   "f814d10935f22272e5a440e92e7c8109dda16be8")
  (:PATH "legal/algorithms/xxHash-v0.8.3-NOTICES.txt" :GIT-BLOB
   "1ac346f5f0bff517073cca31f1509f39a5818d55")
  (:PATH "legal/notice-files.lisp" :GIT-BLOB
   "30a68c858f462c6ef601c270ac48603374b149d9")
  (:PATH "legal/runtime/SBCL-2.6.9-COPYING.txt" :GIT-BLOB
   "4220b33974e7fc04036b2b5600cb3ca88ce2c4c3")
  (:PATH "spikes/README.md" :GIT-BLOB
   "f835fdd46c43312889de749d525290e541e891f3")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "c2c2487c33cadbec5444b81073eb9e417a16c42f")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "03a90c690b4673695f0380f81f0cf68e4da8eda4")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "049ff2032103d3d6a6a8049fa9d803d6f82beeaf")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "cd79005b8100b79cbbca35a5677125af54f5e854")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "b388bbb2a067537c8b03b046d63ed6fd5201fa58")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "be57e2f216618fb65d5dde48e8d29938d377a009")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "6452906fa525035cf6abe7967f05778aeaf17f76")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "014f488b7b50a9439b36f49afd6b6f0f11295d84")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "badf96cfb95709afc9174e40b521ac75c6adac8c")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "1a46426b6521ca207a747cd0d2a7fed0ad4ecfd1")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "0061c53057783cc076b2dcb9596e91017e473c47")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "7edbb7459ca78fb41cb812d82ce1dc1c68176ea6")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "18246e75e94db5f4517e96e827469d6a006b30d2")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "0597672e814ccc60c541439e838b7e4eb491788a")
  (:PATH "spikes/SPK-07-protocols/metodo-page-lifetime.md" :GIT-BLOB
   "fba367b24467642a6e544ff86e099b143a73a925")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "6c0034a70670b4249cd2b525c9fca3e140dbd94e")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "517286df830984ba4a6ff39b03175e445afd65d7")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "163e4c3222c4e5771660e6463367ec6b1bc914af")
  (:PATH "spikes/SPK-07-protocols/page-lifetime.lisp" :GIT-BLOB
   "c032387167188be066737f75583738843b12c883")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "1ec5a1db56a76daacbc7488d8b7940aa0e16eca0")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "95ab6095de30d013dbf5c426f7b6c0a99d5663e6")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "9daf0b57d92db583544653384217105121c8627d")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "4712fb08742000724dbbf5c1f7fac4505ca6ad4c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/comparison.lisp" :GIT-BLOB
   "b8b8ebfa609d6bfe9b710833f22cdff693ef46bd")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/crc32c-unroll32.lisp" :GIT-BLOB
   "6dbbe7218c7b5185329f099a8c1407e0f48d8648")
  (:PATH "spikes/SPK-08-generated-code/crc32c.lisp" :GIT-BLOB
   "72bccfafe9c5cb0fd5dc6392534c5be404774a64")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "680b5d9c4e112747e903e124e07cab8adbf97da9")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c-unroll32.md" :GIT-BLOB
   "d722f4f0145cca93b8cb46aa0572538df99a12e0")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c.md" :GIT-BLOB
   "fbbb491611d807c1022c50236fe29c8d7accb2c0")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "4a57493b511201112c533418f1846acdf96f35c8")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "1bbf37c97bcc7d527c3d5aa90cbb9217b807f3ee")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c-unroll32.lisp" :GIT-BLOB
   "79033530456f565b3b14e25b56146039b5356860")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c.lisp" :GIT-BLOB
   "a45f0c3e862c2174b64ac63d4ca97ae3ddf21569")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "7c797afe4a6060782ce58f0cfc06f539006d117a")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "2ed0e101d31cef0967820fc70155ddd4561140fa")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "740e01ad7ddd2dc170e50454befe9a63b9eff276")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "1e54780546d2bcdd623f7fa6c2faaf127bf15dae")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69ac8ef15f356257dae151e035689d8124e9a9eb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "95928362ab8fbde280a5f74be905ae2ca58729ab")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "df0869dea4916cdb5b671a79ffa812369d043773")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "spikes/SPK-11-unix-socket/README.md" :GIT-BLOB
   "47d0cf7d3d5b5541e38cb47814dbb1f0197ffbdc")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "spikes/SPK-11-unix-socket/core.lisp" :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/native-io-method.md" :GIT-BLOB
   "a90da59a3ecad08654d619a56c2ced177db88a40")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-method.md" :GIT-BLOB
   "ebd5dce74e96860ace17a05cf7e14f940adb126f")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/evidence/README.md" :GIT-BLOB
   "d0dd48506d19490ae1c864f86f4606845241a15d")
  (:PATH "spikes/evidence/history.lisp" :GIT-BLOB
   "f210350eb462c1f3d45f24217f004775496b0eaa")
  (:PATH "spikes/evidence/snapshot.lisp" :GIT-BLOB
   "9ea68544e9490d6598d6361ae0bac6e27a69ce4e")
  (:PATH "src/active/package.lisp" :GIT-BLOB
   "fbd3a32b30808508424c007ece26c9f3ea9ad0a9")
  (:PATH "src/active/preflight.lisp" :GIT-BLOB
   "9a7da536a7286f5996bf1720db7f9b9dbf20abff")
  (:PATH "src/active/prepare.lisp" :GIT-BLOB
   "e6739a357bdce50ca6bfda7dcd147ce8ffb790fd")
  (:PATH "src/active/source.lisp" :GIT-BLOB
   "cc25d0713721585fa74d4c1a89a994ef3f753c69")
  (:PATH "src/active/types.lisp" :GIT-BLOB
   "fc4c2d3ac0839aab37b91d4e017cdaf18bc5041e")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "b0230656edbe3dea63568e74a97e5193cab7c54a")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "a1db79505e00f465b0f0debacbcbd8aad60c5b75")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9725836f0c142b5e292fea4d073f5fbc52b99825")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "84b090e318216a832ab684fc5a936c68e465c169")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "93ecc29914d02b4b6066896de8c2590906ca91bc")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "03bdfeeef2e2639030d3509bd6905364c55f345a")
  (:PATH "src/codec/cbor-array-input.lisp" :GIT-BLOB
   "1b028f9e5f945266f1144b664bf206e89f603863")
  (:PATH "src/codec/cbor-array-write.lisp" :GIT-BLOB
   "625b61e204f7485e1015d109426810ef9d92827c")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-float-narrow.lisp" :GIT-BLOB
   "a2424c60204a55c7ec315de4446e41e243a1afca")
  (:PATH "src/codec/cbor-float-write.lisp" :GIT-BLOB
   "5a44cea28eb51016ce5155ebdf5750b93d15a1b3")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-item-read.lisp" :GIT-BLOB
   "e95db7d9f407e9e0039dc8892e4af8065490d99d")
  (:PATH "src/codec/cbor-map-input.lisp" :GIT-BLOB
   "87c9fd9dd6eb1f3ee1b79bdf2957801762601d97")
  (:PATH "src/codec/cbor-map-write.lisp" :GIT-BLOB
   "84887090a1fa543da817bd096528b576f3d58d9e")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "d9c686fef43c16c5cbf85672b2480a3d0340edfc")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-string-read.lisp" :GIT-BLOB
   "446498b0f3b0f014471312eeb01b3d9a254b6535")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a9028c0b30a22367baad2711346a5517089b1940")
  (:PATH "src/codec/cbor-tag-input.lisp" :GIT-BLOB
   "760e81952f8eb3210465a6cea5c0b89c3f15c5a4")
  (:PATH "src/codec/cbor-tag-write.lisp" :GIT-BLOB
   "4680d759cf12aaa61df5823cb86e71ed7379914c")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "159033291735d23258b340f8da17ad6bd001ccbf")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/control/build.lisp" :GIT-BLOB
   "d5aca4f9ade3c126e88709f1ada1a9e39132b6a1")
  (:PATH "src/control/dependency.lisp" :GIT-BLOB
   "144f908c5cafddc397dd8a1cab04cd641d93a32c")
  (:PATH "src/control/package.lisp" :GIT-BLOB
   "e56a6bb83abe9441350baa46573d74c6d55edf4e")
  (:PATH "src/control/preflight.lisp" :GIT-BLOB
   "850a8f3bedb592dad251e36d7e95ad9fa993979d")
  (:PATH "src/control/prepare.lisp" :GIT-BLOB
   "51cdc2f60ef3da074e98f5bbabd1bb1b4ffbd6ed")
  (:PATH "src/control/publication-read.lisp" :GIT-BLOB
   "a5ebb2f8fafe283f3816d48e633ef8471bfbf4ba")
  (:PATH "src/control/publication.lisp" :GIT-BLOB
   "c8c482c65af3a94bea9acc38b3b93f04933c93b1")
  (:PATH "src/control/recovery-publication.lisp" :GIT-BLOB
   "b01545b6647f5dbac8097dcab394260fb7f9d3cd")
  (:PATH "src/control/recovery-read.lisp" :GIT-BLOB
   "430665c20905e5f7d67245e2d7503bb0f9e0c11f")
  (:PATH "src/control/recovery-types.lisp" :GIT-BLOB
   "2ac4f985eec224f17cea5658cd9d42f4aed99cce")
  (:PATH "src/control/transfer.lisp" :GIT-BLOB
   "69bb7c2e27817201c5533fa4d6099a26750a38b7")
  (:PATH "src/control/types.lisp" :GIT-BLOB
   "7eaa6e2298ac264b7d64c1f7a78de8d1fab8ce09")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "9eb660cca8f097e25ca3c1535cace8c20bc1e238")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "f3788232dd7828d3271688399f1d382393301cbd")
  (:PATH "src/dispatch/begin.lisp" :GIT-BLOB
   "bb45bcad39e438aa082e92d01358d1059cc5fd20")
  (:PATH "src/dispatch/build.lisp" :GIT-BLOB
   "9d1c974830e92918b572af978e8a2b4acae257b6")
  (:PATH "src/dispatch/claim.lisp" :GIT-BLOB
   "a9d55f610fbd14b5bff7f9d6c2a6c8abb7ba405c")
  (:PATH "src/dispatch/package.lisp" :GIT-BLOB
   "db21c798588ff4a88be5b69b5fbe72bc84811a46")
  (:PATH "src/dispatch/recycle.lisp" :GIT-BLOB
   "57955f63a0cfc4efc3f7f742fd479c032dcec5b2")
  (:PATH "src/dispatch/start.lisp" :GIT-BLOB
   "4d519c9fba0c085d5789c2883c8d04079e3933ea")
  (:PATH "src/dispatch/step.lisp" :GIT-BLOB
   "36c8c1e84c7329f4a0b24186e09a40b2ce2d2b61")
  (:PATH "src/dispatch/types.lisp" :GIT-BLOB
   "6f3b3841a3158cac6daf70cc8a1ae3984f52566c")
  (:PATH "src/engine/adopt.lisp" :GIT-BLOB
   "f2cc0f5a3263a605de7f50175e362c55158cb763")
  (:PATH "src/engine/compaction-control.lisp" :GIT-BLOB
   "02cbb0127a3e9519ed0dc90730f077ade17fb5dd")
  (:PATH "src/engine/compaction-install.lisp" :GIT-BLOB
   "167777a12cf87a02b36a73c5609d098d9d8d1b46")
  (:PATH "src/engine/compaction-plan.lisp" :GIT-BLOB
   "d255c8440ee3abb0c190801e7c5b2e1a4872b47e")
  (:PATH "src/engine/compaction-reclaim.lisp" :GIT-BLOB
   "00076045f47b9b8a5a4a0aeee449a3a0cc5e2047")
  (:PATH "src/engine/compaction-relocate.lisp" :GIT-BLOB
   "3f316d79bf63b30bb5fa0cbac38927cf2a6e540d")
  (:PATH "src/engine/compaction-scan.lisp" :GIT-BLOB
   "942e0b2ba2be30a2e94efa1c80564dd7159e322a")
  (:PATH "src/engine/compaction-types.lisp" :GIT-BLOB
   "ee6f36958a147af9cdabdfee2ebe77752476da74")
  (:PATH "src/engine/compaction-verify.lisp" :GIT-BLOB
   "57628bb40f5be4c42b4366e81a0662f7f98c0137")
  (:PATH "src/engine/compaction-write.lisp" :GIT-BLOB
   "41cc966628e64d765c8a8f9d132321451025a3bd")
  (:PATH "src/engine/compaction.lisp" :GIT-BLOB
   "1eac672cf412fc36ae6fbfe5d8b4e7b93dcf480e")
  (:PATH "src/engine/config.lisp" :GIT-BLOB
   "354198f7b04489a46d0a67018d181a4c8668a42e")
  (:PATH "src/engine/delta-location.lisp" :GIT-BLOB
   "367601a853f8d2dd155b1dc0002b86d1b4bcdd5b")
  (:PATH "src/engine/delta-types.lisp" :GIT-BLOB
   "539f08cdb3736546b2b1556f81050d6c5d09ece9")
  (:PATH "src/engine/delta.lisp" :GIT-BLOB
   "b865dc6c8be351c3e89fcddbce61a4e0d7a2dd5d")
  (:PATH "src/engine/files.lisp" :GIT-BLOB
   "eda0f6adb8eb34225b6775b8ef666224e753deda")
  (:PATH "src/engine/image-activation.lisp" :GIT-BLOB
   "51ef93215340364bc2c881f3e7efa6a47aac6aa8")
  (:PATH "src/engine/image-auto-types.lisp" :GIT-BLOB
   "8879e3aa9b00d18cb138da9ca6d04028816502af")
  (:PATH "src/engine/image-auto-write.lisp" :GIT-BLOB
   "ac1ad97829a4b076b6f223e9e010c55752bf3066")
  (:PATH "src/engine/image-auto.lisp" :GIT-BLOB
   "0449392da3326308f5697fc231d24d329a691db8")
  (:PATH "src/engine/image-build-io.lisp" :GIT-BLOB
   "fbd185cd56d4d980575c4d0fec5597b715074f61")
  (:PATH "src/engine/image-build-plan.lisp" :GIT-BLOB
   "ccd01ee41d0d7a103680785731c5271a54f6f2df")
  (:PATH "src/engine/image-build-read.lisp" :GIT-BLOB
   "b11e63f292b93ddaee8b0c645d525a175a1906b0")
  (:PATH "src/engine/image-build-tree.lisp" :GIT-BLOB
   "d9a657c2fbdbb294e34fe8ba40c4fe8c8df11f03")
  (:PATH "src/engine/image-build-types.lisp" :GIT-BLOB
   "d2aacfe57703a7a99354657e4823a641d6eabb43")
  (:PATH "src/engine/image-build.lisp" :GIT-BLOB
   "a4c8ad027a796610299f457399f566ac0ca4284d")
  (:PATH "src/engine/image-config.lisp" :GIT-BLOB
   "47becee77666bb573500cc1d23735e627e65411b")
  (:PATH "src/engine/image-discovery-config.lisp" :GIT-BLOB
   "66c7f2c7f7eb87e0147d858c11787ffdd06b14bb")
  (:PATH "src/engine/image-discovery.lisp" :GIT-BLOB
   "aa41ecbc41a335a25fd3f62761147be516ebce6c")
  (:PATH "src/engine/image-maintenance-config.lisp" :GIT-BLOB
   "cbd5f1cdde00a60ee8cd952898c06e205c8edf1c")
  (:PATH "src/engine/image-maintenance.lisp" :GIT-BLOB
   "44bdff3e98ff1176b51b1bbc20bb8f54b94f5f3d")
  (:PATH "src/engine/image-recovery.lisp" :GIT-BLOB
   "f42286cf6d43cd486d9c4a79f764c99c35e2aa37")
  (:PATH "src/engine/image-renewal.lisp" :GIT-BLOB
   "0e6c21fcdec1d316551417b024e1ba5bda472abc")
  (:PATH "src/engine/image-source.lisp" :GIT-BLOB
   "8b7c7ecdebbf07ada9b68037976be5af53a6a106")
  (:PATH "src/engine/index-auto-api.lisp" :GIT-BLOB
   "1241871a3195c1c42b890e08373803a816809817")
  (:PATH "src/engine/index-auto-apply.lisp" :GIT-BLOB
   "7062c70c0f6322cda8de3f089bab2a216dae3d44")
  (:PATH "src/engine/index-auto-files.lisp" :GIT-BLOB
   "2c79ded6eb822d4f238f31cd7756bcdc79d5be7d")
  (:PATH "src/engine/index-auto-memory.lisp" :GIT-BLOB
   "8199f78030cc2d21af63d223c7d9cb99cb22b4fb")
  (:PATH "src/engine/index-auto-migrate.lisp" :GIT-BLOB
   "52e44cd130f7dc77bf6fa0be130dfc4827b4ec59")
  (:PATH "src/engine/index-auto-resolver.lisp" :GIT-BLOB
   "82554d4e3b9382c60bbdb0cf2986a4e75af1dafa")
  (:PATH "src/engine/index-auto-types.lisp" :GIT-BLOB
   "7d848c894841cdcf2abf615cd8140568a264351c")
  (:PATH "src/engine/index.lisp" :GIT-BLOB
   "650e3e008a6e489ebc3972366724edab5a3189c0")
  (:PATH "src/engine/initialize.lisp" :GIT-BLOB
   "8c39b866a402a30b1aa1ef7409e675f367e4ec97")
  (:PATH "src/engine/lifecycle.lisp" :GIT-BLOB
   "eb8dc8c0fa0c8f510502ed95b6d001229f1dcb4d")
  (:PATH "src/engine/package.lisp" :GIT-BLOB
   "2fa6abaec0ae44e0cae76e414df34afdc5eb5699")
  (:PATH "src/engine/preflight.lisp" :GIT-BLOB
   "272b6ffeb63fa9536bade7a0fd48764340128e4c")
  (:PATH "src/engine/read.lisp" :GIT-BLOB
   "658f1224eabea55171889037f09cbd030c9836c9")
  (:PATH "src/engine/record-cache.lisp" :GIT-BLOB
   "6d00296bffb12094dafd46a4ac898c9a20f81dfa")
  (:PATH "src/engine/recovery.lisp" :GIT-BLOB
   "05b64c0a49c59c209af8bac92f6823c193a92122")
  (:PATH "src/engine/rotation.lisp" :GIT-BLOB
   "bc4d8783b4cc930f424cc7312579bcfe3b73d772")
  (:PATH "src/engine/startup.lisp" :GIT-BLOB
   "5245c459ca92fa0f69ff1810befc748fbb303f7f")
  (:PATH "src/engine/types.lisp" :GIT-BLOB
   "a6332ea2bdbfa4e7c87c3c3e3e8390d949b27238")
  (:PATH "src/engine/write.lisp" :GIT-BLOB
   "3b83c17a8bf510c110648b4257fe9b8df43b6bf5")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "93dbc244d3e8a86e64254b31e2954102f65ab149")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "0fc4c81f23e27dabfe52485a3976ec3eb390eb4c")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "e0d503d2ad85689ac6162636857f4e44f2b5c7f9")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "474ddacfc871629aad94b6d59b87de7cd4349475")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "838611d288696767dc539b155fcfefe3feec79e2")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "bbed8c36a799b57baebe6350dd96c3a968dd05e7")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "b27df62179c9f43132c445c82f0c2bf4ee78f366")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "5d4e27472170bfffa85a6e8aac0760236e7fefb6")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "f79bbd85269d50eb929816276353b2fbb85f92c9")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "a36b9bc921e8d58f9cf3a10a8426eb388e710226")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "c066712083a07bc574481ae3a3cdcc996c9303a8")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "3c970d0cbd3866d837c07bd03d7e4e0fae24f21f")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "c048d0e7321d26e5ec3ec4eb7d3bd79b4714aef5")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "7170e6de30721bcb89cb94b56e9d3c579a1269be")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8be80a716738875d5e6fe056c5f3c81d2ffad2e5")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "5560532f4cae67478c11adc65e632cfe3da10ad7")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/crc32c-native.lisp" :GIT-BLOB
   "2e80dc72cce0064a460b8ee78970acae71a9da35")
  (:PATH "src/foundation/crc32c-vops.lisp" :GIT-BLOB
   "0677d1d29c7fc16dbd8bda529cffa5f1076327a8")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "3dee5a43950d683f83deffaa6f329d6dcbc6cfc2")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "6fca7bd583990cf07093243c95f399d294b74d45")
  (:PATH "src/fulltext-admission/build.lisp" :GIT-BLOB
   "ba813f4178d646f412363e8b3f86f7309878a4a1")
  (:PATH "src/fulltext-admission/copy.lisp" :GIT-BLOB
   "43488c42525991544b355bfc061c2c753e866c88")
  (:PATH "src/fulltext-admission/guards.lisp" :GIT-BLOB
   "c4734194dc53a5f98397bd0b35079c5739f95a41")
  (:PATH "src/fulltext-admission/lifecycle.lisp" :GIT-BLOB
   "088b775f74cf633ecb3b84a0c0b9445209cc4b93")
  (:PATH "src/fulltext-admission/package.lisp" :GIT-BLOB
   "74d06aa6d0d0b263b806f678b23cec40b5db3ef1")
  (:PATH "src/fulltext-admission/preflight.lisp" :GIT-BLOB
   "eeff3e04503f0dac81da9816112f2da68e384dc2")
  (:PATH "src/fulltext-admission/query.lisp" :GIT-BLOB
   "a8aac3c938ada73cb2b18abfaf44d7bc1ff4cfa5")
  (:PATH "src/fulltext-admission/reserve.lisp" :GIT-BLOB
   "374c03ecf29417aad8e760dd432ff3e5a6383e4c")
  (:PATH "src/fulltext-admission/row-update.lisp" :GIT-BLOB
   "1d77f5d5c6e1ddb8ab08136d7d7afaf1f79a7f79")
  (:PATH "src/fulltext-admission/rows.lisp" :GIT-BLOB
   "f1c6dc8236477b5de6b2f0e5db4bab8a02fcbe95")
  (:PATH "src/fulltext-admission/types.lisp" :GIT-BLOB
   "b4766a5b561c1a1f3e53bfc9485f72b128dfb1d1")
  (:PATH "src/fulltext-put/append.lisp" :GIT-BLOB
   "df244937278aebfabba27f14555b36476e6d9858")
  (:PATH "src/fulltext-put/binding.lisp" :GIT-BLOB
   "c47d939287b3be63ec090d24bd64903556b2b86a")
  (:PATH "src/fulltext-put/build.lisp" :GIT-BLOB
   "1f4113fb6ce043099672cf72c995b976c9543cea")
  (:PATH "src/fulltext-put/package.lisp" :GIT-BLOB
   "0ffd3fb459d14ef6da0ab6789930b8ee54b78fe5")
  (:PATH "src/fulltext-put/physical-header.lisp" :GIT-BLOB
   "8fbb48b2ceb0ccb9c73b9344e14fbb025174b7e4")
  (:PATH "src/fulltext-put/physical.lisp" :GIT-BLOB
   "f7a1a29690b384cdd8bf791e62ac2d98deb7495b")
  (:PATH "src/fulltext-put/prepare.lisp" :GIT-BLOB
   "5a6929f64ba29f63efa2717a79fb79c93206b74c")
  (:PATH "src/fulltext-put/reserve.lisp" :GIT-BLOB
   "81642e379bb158bed9bec2f0fa9c70190a637567")
  (:PATH "src/fulltext-put/row-reference.lisp" :GIT-BLOB
   "b24f1dc1bd7ea08b7efe05e954cd30190f8a1aa1")
  (:PATH "src/fulltext-put/start.lisp" :GIT-BLOB
   "8c6677841d374a7bfc1834a83ccf610eecce0890")
  (:PATH "src/fulltext-put/types.lisp" :GIT-BLOB
   "c0bb31863f4f17894f85f69df42d5476d988f9da")
  (:PATH "src/fulltext/analysis-emit.lisp" :GIT-BLOB
   "17bcef98c46d7a035d2945be0c7407ed178e3da7")
  (:PATH "src/fulltext/analysis-nfc.lisp" :GIT-BLOB
   "e3e34d111a4cbab7a860d995e0658e154f1a4031")
  (:PATH "src/fulltext/analysis-package.lisp" :GIT-BLOB
   "5729cfba660c391cf9dee6fc3d5e6ccbddcd2552")
  (:PATH "src/fulltext/analysis-properties.lisp" :GIT-BLOB
   "320a03b22e01f755184d3d8b6aa1a61b009ce538")
  (:PATH "src/fulltext/analysis-space.lisp" :GIT-BLOB
   "7ab493596664f1488b369fc0b14b083e9eee31af")
  (:PATH "src/fulltext/analysis-word-context.lisp" :GIT-BLOB
   "023c1d7676f5f1325e7b112ba38a132a010f36e8")
  (:PATH "src/fulltext/analysis-word-rules.lisp" :GIT-BLOB
   "0278fccb36c8320d8b0b11b26e067773b8435e1a")
  (:PATH "src/fulltext/analysis.lisp" :GIT-BLOB
   "496c3196aa6efc23695486f15253f9275b58c1c6")
  (:PATH "src/fulltext/codec-input.lisp" :GIT-BLOB
   "ff8ede224c154fa075b7f1eb53cacecbcc7d73c3")
  (:PATH "src/fulltext/codec-package.lisp" :GIT-BLOB
   "fcd63be08134216e7a0d79c68ba6fc1120415689")
  (:PATH "src/fulltext/codec-plan.lisp" :GIT-BLOB
   "b614382a5beec3c0ccc3134f0e2abffc0fb44e87")
  (:PATH "src/fulltext/codec-query.lisp" :GIT-BLOB
   "1047b265bf2140ea5d14ea55987f1bdfae2f6e0c")
  (:PATH "src/fulltext/codec-read-base.lisp" :GIT-BLOB
   "5a24b81342a564255563e9309efcc9f043aa33a4")
  (:PATH "src/fulltext/codec-read-dict.lisp" :GIT-BLOB
   "5958a63148c0942343fa93fce59a59d614850bb2")
  (:PATH "src/fulltext/codec-read-lengths.lisp" :GIT-BLOB
   "91b77b0ef9cc16fb29c437130453ca97c19de60f")
  (:PATH "src/fulltext/codec-read-postings.lisp" :GIT-BLOB
   "46fc1a96ed8bd3e616392ac6c891a678b4e8f33a")
  (:PATH "src/fulltext/codec-read-term.lisp" :GIT-BLOB
   "bf77c4c7d7f7faeaa68077cc1dfbb8349ff6eeb7")
  (:PATH "src/fulltext/codec-run.lisp" :GIT-BLOB
   "fbe693aa1579466dc55fc03fe88a1bb04d7c097f")
  (:PATH "src/fulltext/codec-space.lisp" :GIT-BLOB
   "48e907be585f73c58fd7fa4e89a0b5cdfbfef309")
  (:PATH "src/fulltext/codec-view.lisp" :GIT-BLOB
   "49a4547d0153a45281e2bd2188891f2c5517523d")
  (:PATH "src/fulltext/codec-write-entries.lisp" :GIT-BLOB
   "035e0c6d0826d7be8e5308c3dbabf9f4b6b94b50")
  (:PATH "src/fulltext/codec-write.lisp" :GIT-BLOB
   "64731ed8f9fc9f1246a62c659b18fa85ae2a0f3e")
  (:PATH "src/fulltext/descriptor.lisp" :GIT-BLOB
   "d53475000e9a1f3f3ab97f29780b526b39c43e58")
  (:PATH "src/fulltext/document-analysis.lisp" :GIT-BLOB
   "5f4635b04bf39a7673c4071ac423f3c23b595c57")
  (:PATH "src/fulltext/document-bound.lisp" :GIT-BLOB
   "6eb42da6fa77f01a38b92559b1eccc32f1313d43")
  (:PATH "src/fulltext/document-config-input.lisp" :GIT-BLOB
   "f9522d52f03c808c9e31903ac6393ba113c487f0")
  (:PATH "src/fulltext/document-config.lisp" :GIT-BLOB
   "4d28290bec4b6bca2f8a79338323fa1e4b2ed617")
  (:PATH "src/fulltext/document-package.lisp" :GIT-BLOB
   "c699e405a2ce6c5a18cc27842352f8ad43647e4b")
  (:PATH "src/fulltext/document-paths.lisp" :GIT-BLOB
   "dc31d23d3316043885526af964aab860fe4a6f45")
  (:PATH "src/fulltext/document-scan.lisp" :GIT-BLOB
   "62df7660d399fe08ccb948a21fe6ceb0bbca507b")
  (:PATH "src/fulltext/document-space.lisp" :GIT-BLOB
   "ab484dddcbd81d464e8739e4aa28a1be667accc1")
  (:PATH "src/fulltext/document-start.lisp" :GIT-BLOB
   "d59279a55290ed8b35e722dd9ee47cef68502a1a")
  (:PATH "src/fulltext/document.lisp" :GIT-BLOB
   "447a0f0d27d1e197483f839e7a03d75bce92585d")
  (:PATH "src/fulltext/format-constants.lisp" :GIT-BLOB
   "cc040653f809c725a063eee35fff6e2f9570b675")
  (:PATH "src/fulltext/format-input.lisp" :GIT-BLOB
   "891ad11bf97386317a7a56d6e81c7d425745dfdb")
  (:PATH "src/fulltext/format-package.lisp" :GIT-BLOB
   "1f72e2d40467a20422c5bfaa2564bb5b84fedf29")
  (:PATH "src/fulltext/format-read.lisp" :GIT-BLOB
   "323807f0a973049dd290dd7dad4d2266301e6e57")
  (:PATH "src/fulltext/format-write.lisp" :GIT-BLOB
   "2b89b266d96de0264d92b164b4d59e4e27079f82")
  (:PATH "src/fulltext/index-build.lisp" :GIT-BLOB
   "54ae060c29f1345430a44b2b378c8cb43039dcdc")
  (:PATH "src/fulltext/index-lookup.lisp" :GIT-BLOB
   "9ef394661c96beef9e4cbf3f2e8e5812ec6828c6")
  (:PATH "src/fulltext/index-package.lisp" :GIT-BLOB
   "20bfb93adc06f0782e20fe842f4805b2249d440a")
  (:PATH "src/fulltext/index-sort.lisp" :GIT-BLOB
   "369d3de6ee0ecee94aadfe6ebbce619b84e8147b")
  (:PATH "src/fulltext/index-step.lisp" :GIT-BLOB
   "9206fd68138b97057494978f7713618063510654")
  (:PATH "src/fulltext/meta-fields.lisp" :GIT-BLOB
   "afaeeadd5831bac5804c57a9b67428a3e3c2eaa0")
  (:PATH "src/fulltext/meta-read.lisp" :GIT-BLOB
   "9a4f5a543e68b9c585126096feadaa754f10c6d7")
  (:PATH "src/fulltext/unicode-tables.lisp" :GIT-BLOB
   "a0b079ee4bfba2d1a6ca83b4bb9c555462b75b3c")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "4ebfa97211671287aa2c972a8923654c2390d0f9")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "8dcddeb0536c1104af92c722ffbfab2059601c74")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "a957b1f91e495637b700756736a96baafd233abe")
  (:PATH "src/get-directory/sources-read.lisp" :GIT-BLOB
   "fbb8b26fcfd9de939bf4f3c61d5fd0c5c335754c")
  (:PATH "src/get-directory/sources-types.lisp" :GIT-BLOB
   "ce426ea6409d588e0ca6add8e6c95a1c594e0c89")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "564cdaea8cb9aae672cbbd4328ea7e76b4430f4a")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "4a4b68bd8da051f2673def534aadec8febb11caa")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "3a3dae662d06b1e2b6bc936b227894d2f0396b6d")
  (:PATH "src/get-resolver/active-init.lisp" :GIT-BLOB
   "df5a754f6cf7b5c61ea4c9dc1df1c94b33e3f106")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "93a32b00aef08a29b4ae7d638eaf16cc68a284ff")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "a71e3a410808705bb3393b4839a71fb7f54b9d48")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "0ca652d2dc2a7a2a4474e4c32adc90e9b2ac13d4")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "75a6c0dae936931d0d13623291a17ee1596c084f")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "d6854c7ec8b7125b33391a27760be11cd01c89db")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "33d7b898b5f5a7b20c8112484191c14df44b770e")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "c46dd43cba38117155ee217a08c02448a0a0d3ee")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "b747d3a4b6517d7574225dc26cab8703747f0e05")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "c0f1a6b32a1725b6e9ae05e00e130a3e0097be78")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "7f2f8b496d65b70d83eee58c19b5b679b5d632ba")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "77b07c57b7e57505ff35724dc36a90cb554679ee")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "76ac8e35c01b887cec70ccd78d29d87690557eae")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "2a393aae53a7b13b567dc5a44b5d0d1da83714f3")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "01233e1565f301c96ce6ee3bb33a50f10cb2e937")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "7a3600dfe26168cc956e1ef62d07221a6d51a61f")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "fe1475f001e9b5719980f7e7507f735edc7e208a")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "4dd3840c525e54acc7d1577b45aadff217a77c4b")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "f1a5060bb6071bec929476a9151fba0ec68e1604")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "db2d060ad9f747deaa7f5016d09eb8ff0299d36e")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "9827cb4af0343e4241d2fed6e3c62830455f8749")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index-disk/api.lisp" :GIT-BLOB
   "daeaeeaef31f8cd903ad02f6cd60193611714643")
  (:PATH "src/index-disk/balance.lisp" :GIT-BLOB
   "c1189c5fcb2a3389004a0b2d19357c4f93e9e026")
  (:PATH "src/index-disk/build.lisp" :GIT-BLOB
   "85d0f397ea8062235c537806caa21fe03d790589")
  (:PATH "src/index-disk/cache.lisp" :GIT-BLOB
   "e61013c7d4d60aa0711024615dcdf42476c69ecb")
  (:PATH "src/index-disk/copy.lisp" :GIT-BLOB
   "b26cdc656f9112ab344983c5a7f473e97442c8e3")
  (:PATH "src/index-disk/mutate.lisp" :GIT-BLOB
   "ac7a72b3d506de92ec80bbb9653904188b98d8f8")
  (:PATH "src/index-disk/package.lisp" :GIT-BLOB
   "23536e507f5fee4b20554184835addebab23ba3e")
  (:PATH "src/index-disk/read.lisp" :GIT-BLOB
   "20599afde6adbb9cd9decdc852f0de469a5d72e5")
  (:PATH "src/index-disk/relocate.lisp" :GIT-BLOB
   "34399623c2c31e68c16d069f57d1b7e6b9bd4ab2")
  (:PATH "src/index-disk/types.lisp" :GIT-BLOB
   "df13ba528aa6bba71981c44b8fbf14c69fa4551e")
  (:PATH "src/index-disk/visit.lisp" :GIT-BLOB
   "ec8ae71e8f2d27b7e2a49cefbeb2c86e7367bbe2")
  (:PATH "src/index-disk/write.lisp" :GIT-BLOB
   "7b6e37218626e782f22cc2903328c40f23d52fac")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "64be10d7b2dc85c6dd6c31becefbb6ee3ae74d21")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "ec86f5be5b5d465d5e32dc3c492cbc0c90daaba5")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "6dc9775423900dd855c71c06079cdc5e69411c5b")
  (:PATH "src/index/image-codec.lisp" :GIT-BLOB
   "e3b96642767e7e0d116481f41e279274646c2b12")
  (:PATH "src/index/image-constants.lisp" :GIT-BLOB
   "6c123802b75884937c2e9bcd7cfe4e214173ab9e")
  (:PATH "src/index/image-publication.lisp" :GIT-BLOB
   "7733d528d07acc24ec9f8c00c6767c2e3b09975e")
  (:PATH "src/index/image-recovery.lisp" :GIT-BLOB
   "ea1a681932b0fa2a1a7a3f44238816657505e55c")
  (:PATH "src/index/image-seal.lisp" :GIT-BLOB
   "f788cc87a9f2f963210d5bb54310f359df78adba")
  (:PATH "src/index/image-types.lisp" :GIT-BLOB
   "69315a89f5b007ebfbb838bc87dde37221fa69c8")
  (:PATH "src/index/image-verify-edges.lisp" :GIT-BLOB
   "2bdfd22b88408ff57efe6dc6e8c61fb5bb4f2fa1")
  (:PATH "src/index/image-verify-entry.lisp" :GIT-BLOB
   "6d240011e6b3f2c8795537bdead86763cd5a0dd5")
  (:PATH "src/index/image-verify-key.lisp" :GIT-BLOB
   "c7bde57d3d327f32321c29d358cb84eb90f1eadc")
  (:PATH "src/index/image-verify-types.lisp" :GIT-BLOB
   "a7f39bfa563402bb113c3430c5229926c0354ff9")
  (:PATH "src/index/mode-package.lisp" :GIT-BLOB
   "53da3230da115c0d702cc762d3f2ab69e6af253e")
  (:PATH "src/index/mode-policy.lisp" :GIT-BLOB
   "2acdfd94b5a0e5bfc04135cf9f39b4a72ef93482")
  (:PATH "src/index/mode-types.lisp" :GIT-BLOB
   "9e42e46cfa22a400da7635e45ab7c8192e25204c")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/page-body.lisp" :GIT-BLOB
   "c4143fd0c6350883ff10db74c2f8b9c7320b7600")
  (:PATH "src/index/page-bucket.lisp" :GIT-BLOB
   "f6f9c5b2076c8f3c1ae9dd1c23bdab00cbd69005")
  (:PATH "src/index/page-build-config.lisp" :GIT-BLOB
   "8d34342f4e34d3edacf6edb07a3059b8cd199d62")
  (:PATH "src/index/page-build-emit.lisp" :GIT-BLOB
   "479818ed5d901eee9ecfee456e39b66d4f02c620")
  (:PATH "src/index/page-build-plan.lisp" :GIT-BLOB
   "86bf82eb3913ca8dad0f7e1dbe1e9016da5b18a9")
  (:PATH "src/index/page-build-proof.lisp" :GIT-BLOB
   "f86fd7f850a9f1559e9af7fdf445971e07020eff")
  (:PATH "src/index/page-build-types.lisp" :GIT-BLOB
   "4fb20f67faa960088aadf112246f84a98f58117a")
  (:PATH "src/index/page-build.lisp" :GIT-BLOB
   "b632710d7d32cac680b10a9312bd9c4878024fd0")
  (:PATH "src/index/page-cache-types.lisp" :GIT-BLOB
   "bbea574ced62361daf59b1d03fb6f06cdb840991")
  (:PATH "src/index/page-cache.lisp" :GIT-BLOB
   "e66d3fa17f78dde39eff02eb8993a7c68f9ba9f5")
  (:PATH "src/index/page-constants.lisp" :GIT-BLOB
   "de904d211f301a087b3d1d53fa47a8054ccf2eb7")
  (:PATH "src/index/page-lookup-key.lisp" :GIT-BLOB
   "9e2e8f43e9a787b7a9223d57dcbab979dbbc233e")
  (:PATH "src/index/page-lookup-types.lisp" :GIT-BLOB
   "9abfe5a3024425124a8e9cc3b0a7087ad5cad1ff")
  (:PATH "src/index/page-lookup.lisp" :GIT-BLOB
   "9dde416acf27111c21e3f439dd2c948d27517eb7")
  (:PATH "src/index/page-package.lisp" :GIT-BLOB
   "d3f1ff0b939b5a4a1e2df7f22fb04077886220ea")
  (:PATH "src/index/page-read.lisp" :GIT-BLOB
   "0386ec4059fbb6a01d34a137e5bf5a6f44a6f589")
  (:PATH "src/index/page-types.lisp" :GIT-BLOB
   "74a9db44b348db25a046c9250f092a0e03f82ca0")
  (:PATH "src/index/page-validation.lisp" :GIT-BLOB
   "a45eb2aa3d449c9500a95950709cb6019fb8f76b")
  (:PATH "src/index/page-write.lisp" :GIT-BLOB
   "6206be6610c55d48389763a3205ff80ebd79a6d8")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "27c03d2d3e8bfb6b93088bb55bd6e615350261d0")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "83fe7ca83cad1b84f41a579d56bb02ee0bac881e")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "86debb0798063a5e05be0a96f125dece7edd0f0a")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "5afb91ab551d915d29f6630573a17328839cc616")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "099d59bb9acc155380a3baaa3a10816e0902d8ca")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "d054587f29d5108d65704fe8b5b6794178923902")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "7cc651a3e3de17decfe71f3ee9b826dfa7b3ca2f")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "fde846254989ef432159c1ffcfc25fb3f950dbcc")
  (:PATH "src/index/primary-restore.lisp" :GIT-BLOB
   "252bd2cb57700c33fd4ec94749ea6f0b80ae6817")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "179de5b6f466cfcb72c719c49a0e885b5bcf6a12")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "621a82743aceafa1653340330e413bc902c58ebb")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "0187f4d9603d23a6ddb0a76d282af9c811080534")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "589e1557b2906a15c6c874f126968669206ceed9")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "bebb4f103854e0b3dbfc248cae5b82cdeafb0b57")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "ad43248f2f9ec4978a07df5bb696c49a1c055ea7")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "6a55454412edc8466e9c7972f9c81d9a3c945697")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "d42c883908d8a8c9c467342b8977498f38dcf33b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "83bec7e5e8d66f78d9b127c5310b2058b3c3fed6")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "ab3fd8e8abe4fd803038cf11e13c3fef75a8144b")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "0e8ca5847c6683a89cdd47e3476665b1bd46e6da")
  (:PATH "src/io/cpu-build.lisp" :GIT-BLOB
   "0dd046093289729dbc7817a3eeb7dff004f0e9fa")
  (:PATH "src/io/cpu-features.lisp" :GIT-BLOB
   "80653c6c8871127b3d76cc631d47ba0e711b6e5d")
  (:PATH "src/io/cpu-package.lisp" :GIT-BLOB
   "baf8aa6f2ef5231eb6462bca65d83ac1886d09e5")
  (:PATH "src/io/create-relative.lisp" :GIT-BLOB
   "eb4a8c292b30a3083cd256eda697b05737553022")
  (:PATH "src/io/derived-remove.lisp" :GIT-BLOB
   "a0631348bc17fc4e5c1638522be73ae87fa53a97")
  (:PATH "src/io/directory-lock.lisp" :GIT-BLOB
   "f0135b3b43625d9535db6196507b55154d36f852")
  (:PATH "src/io/directory.lisp" :GIT-BLOB
   "8b3fb30b5fa092a5f88ce55cbcf5ebfa6bddf993")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "9b04b83cf53f493aaf75d1c19a6d5f9f4ee0971f")
  (:PATH "src/io/identity-types.lisp" :GIT-BLOB
   "d53f8c4793af7e98dcab62ee5c94571dd8d520a2")
  (:PATH "src/io/identity.lisp" :GIT-BLOB
   "0cb49ca63800c1fc25bee5bf94c2811969511a07")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "9ea7d77f1bccbb7051123ac2e5793d38b770ffbf")
  (:PATH "src/io/namespace.lisp" :GIT-BLOB
   "1f73f6bf5c4b8f12064b515008d6c8f9076518ce")
  (:PATH "src/io/native-create-relative.lisp" :GIT-BLOB
   "9d715484a72332fb056b8102d2277140128b2f59")
  (:PATH "src/io/native-directory.lisp" :GIT-BLOB
   "95ea1018b8693a89e0967f9a7a6dea95542d6005")
  (:PATH "src/io/native-namespace.lisp" :GIT-BLOB
   "599c21713f3d82b6bc9faac71e42a45da0e6cd90")
  (:PATH "src/io/native-open-relative.lisp" :GIT-BLOB
   "d924a8a202ab02406cdae147cfa0cb742a0917e6")
  (:PATH "src/io/native-publish.lisp" :GIT-BLOB
   "d62f716c3965b838e0cdb7a629c78bdf845bbdc2")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "37f1e1782e0e3580447aa0ef56cb0942cfbd0e66")
  (:PATH "src/io/open-relative.lisp" :GIT-BLOB
   "e712b098ddbd883b77382c60b1b511427e8c4db7")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "c0be7a664e6642b7dcc6362d6194090fa9a8290e")
  (:PATH "src/io/publish.lisp" :GIT-BLOB
   "cb759a6c4c6d4b9300c1bb9e1e7b7d781f629f65")
  (:PATH "src/io/readiness.lisp" :GIT-BLOB
   "8ae8de38729e3866227360cc1cf6022c9220490b")
  (:PATH "src/io/rename.lisp" :GIT-BLOB
   "38a7d50880a012266e59eb915edafe64f2047e4e")
  (:PATH "src/io/segment-remove.lisp" :GIT-BLOB
   "8530ef67554d751b20d1004a9af49f20b8fc1861")
  (:PATH "src/io/stabilize-preflight.lisp" :GIT-BLOB
   "290915923be47b7739c3f44560a62f9819c7a26e")
  (:PATH "src/io/stabilize.lisp" :GIT-BLOB
   "504c9dca2fece31bc79f8788f7524d7397a1fee2")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "b66a02dbc2eda6d43388a0946ae46b795efb2a76")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "8e7b3506c6f1da4493bba4817d8b1f6c57585aaf")
  (:PATH "src/local/cli.lisp" :GIT-BLOB
   "801ea182eab95273f82e3b5687605dfbf31aef75")
  (:PATH "src/local/client.lisp" :GIT-BLOB
   "e7f09f4789f50fb79aeef0722c9461f0915cb084")
  (:PATH "src/local/dispatch.lisp" :GIT-BLOB
   "143123455d4733f499a652b174f120da18eec3ea")
  (:PATH "src/local/native.lisp" :GIT-BLOB
   "380f655e5da39eaff4daeef4c6eaf63217762a48")
  (:PATH "src/local/package.lisp" :GIT-BLOB
   "74489fef066b33ac706cb0dd8c757d440e0bfebf")
  (:PATH "src/local/readiness.lisp" :GIT-BLOB
   "bbc9fce59ab612aa4dd003d90a854506c7b047f1")
  (:PATH "src/local/server.lisp" :GIT-BLOB
   "4b9672242fb9e0a0f0d46e47ff6489ff9870e469")
  (:PATH "src/local/state.lisp" :GIT-BLOB
   "de28dd14714908a96f1355a8aa3f9d8953900134")
  (:PATH "src/local/wire.lisp" :GIT-BLOB
   "60a5c872e2da0baa0fee22fd4909b66342c2c387")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "fdeac572e64c3591208a87872b8aa9d520c3bde7")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "74ebd63accc8216dfe5a1794c0e430bb9bccd29e")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "a05a5732511ffca3591110f617e3a19be819b47b")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "158b5a6d1eb171d07bd4f67addc2f4be5495d54b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "06a0af0e813b9c22ce98d523d42c031c79ca3734")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "95f5a8c59ff1fef05bcd3fd220d6a14d9c332d61")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "e5130ba55ee942238a5a98ecc51e07725e1c9655")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "2de7b390c89ab19f8be03767ecb07af8fe1e4fb1")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "172a43f86726ec68af730700c99098d66500ad66")
  (:PATH "src/recovery-active/build.lisp" :GIT-BLOB
   "0fa0e554f7e3aa6990d861dec7cbf8408db28068")
  (:PATH "src/recovery-active/closure.lisp" :GIT-BLOB
   "326b2070076e6e9a8d8ee66567d05b5c19329467")
  (:PATH "src/recovery-active/csn.lisp" :GIT-BLOB
   "42b1279ccd9910816bd8d0887b60bcfe9b6e252a")
  (:PATH "src/recovery-active/frames.lisp" :GIT-BLOB
   "3d01c07ff8118b92e5de7b31ca72b19db5ec72ff")
  (:PATH "src/recovery-active/package.lisp" :GIT-BLOB
   "474cd54f2a31f4ded95fd723b4170bee8addece4")
  (:PATH "src/recovery-active/publication.lisp" :GIT-BLOB
   "38542ec938fd3409d73d7531e90fc6474ef42fad")
  (:PATH "src/recovery-active/query.lisp" :GIT-BLOB
   "e2a5aea0f5a97670cc20a583ed312c89df1c7187")
  (:PATH "src/recovery-active/read.lisp" :GIT-BLOB
   "f801950d67755cd15804ef43f1461d435eda54a6")
  (:PATH "src/recovery-active/resolve.lisp" :GIT-BLOB
   "66f4ada585e085a8403d4cdbc9a3dfee31754bce")
  (:PATH "src/recovery-active/types.lisp" :GIT-BLOB
   "069ca4b815c98d82695dd7eb9337a83c5f35b98b")
  (:PATH "src/recovery-archive-csn/build.lisp" :GIT-BLOB
   "ea5a6abf3d6b0817cfa99db490e9e5df57cb200a")
  (:PATH "src/recovery-archive-csn/package.lisp" :GIT-BLOB
   "bacf4fc95e38a8d0416110c6b87b506d561a7e59")
  (:PATH "src/recovery-archive-csn/preflight.lisp" :GIT-BLOB
   "a7a20c65ba54da28dd88c941736fb374065d580f")
  (:PATH "src/recovery-archive-csn/query.lisp" :GIT-BLOB
   "28f8acd47abad20efb95ec0ea8bd765bfa10baff")
  (:PATH "src/recovery-archive-csn/series.lisp" :GIT-BLOB
   "f8eb49763d533cd34cdf05593d2416a63c5f1d0c")
  (:PATH "src/recovery-archive-csn/types.lisp" :GIT-BLOB
   "d30bb8cb36fd1c64a720073fd3f4b4921e507cad")
  (:PATH "src/recovery-archive/active.lisp" :GIT-BLOB
   "5eb16b6f93d24ac3c6f06af8ed3c005328b457a5")
  (:PATH "src/recovery-archive/build.lisp" :GIT-BLOB
   "81a581f63c21154b8a55f2f429ec28ee32a659b3")
  (:PATH "src/recovery-archive/package.lisp" :GIT-BLOB
   "82c707853b1a5b2b6d657e120c7e0ecb82404134")
  (:PATH "src/recovery-archive/query.lisp" :GIT-BLOB
   "8ae65f7a41d2b4a395d6e6a1829d334dfbe88878")
  (:PATH "src/recovery-archive/read.lisp" :GIT-BLOB
   "07ee8571028ca0ec5f754ec9f8478077650ee48d")
  (:PATH "src/recovery-archive/types.lisp" :GIT-BLOB
   "80d29b79c185d0007d0b0e4baa913ed18ec0524c")
  (:PATH "src/recovery-bootstrap/build.lisp" :GIT-BLOB
   "60d549030aa9d16b823fcb98398f14cd3786f73b")
  (:PATH "src/recovery-bootstrap/package.lisp" :GIT-BLOB
   "29ce39efa53a72cd766810b81a08c9a2f86afc91")
  (:PATH "src/recovery-bootstrap/preflight.lisp" :GIT-BLOB
   "601685cad9fd3829ea36672e86b94952f3fe4493")
  (:PATH "src/recovery-bootstrap/shape.lisp" :GIT-BLOB
   "56e6694b910c05854961e920deeb0da390d4a428")
  (:PATH "src/recovery-bootstrap/stabilize-preflight.lisp" :GIT-BLOB
   "5c05f4f7b52c72cce8f3a086a64c4d190e7de36e")
  (:PATH "src/recovery-bootstrap/stabilize-shape.lisp" :GIT-BLOB
   "649080985356be430b25c841c7d345e9d24cb543")
  (:PATH "src/recovery-bootstrap/stabilize.lisp" :GIT-BLOB
   "2ef2dda4858003135215d7d36f816f4929d214a3")
  (:PATH "src/recovery-checkpoint/build.lisp" :GIT-BLOB
   "c274d47f45d845a6e16049e2a573e8d9d76fbc3a")
  (:PATH "src/recovery-checkpoint/order.lisp" :GIT-BLOB
   "a265f08779f2abc94be058454cf75643c33272ca")
  (:PATH "src/recovery-checkpoint/package.lisp" :GIT-BLOB
   "7b191ecff3dbac6b5f690ad221c68b4762a9f0aa")
  (:PATH "src/recovery-checkpoint/preflight.lisp" :GIT-BLOB
   "61e245a5495de984a94fef573f88d11245e86b71")
  (:PATH "src/recovery-checkpoint/sections.lisp" :GIT-BLOB
   "eb05b6c58fe3131fbd597dff5655e4a476b55092")
  (:PATH "src/recovery-closed/build.lisp" :GIT-BLOB
   "bab6c80812e70ffb31a59f29ffaaa6f90678cea1")
  (:PATH "src/recovery-closed/csn-serie.lisp" :GIT-BLOB
   "078d9bbd66289b667c4273053f706a3a2af120e6")
  (:PATH "src/recovery-closed/csn.lisp" :GIT-BLOB
   "41144f854694ff9338e0067d2f59b3312119c5b2")
  (:PATH "src/recovery-closed/package.lisp" :GIT-BLOB
   "49ac245e2430e719b1d417b91b0ffcd53555e47d")
  (:PATH "src/recovery-closed/publication.lisp" :GIT-BLOB
   "fc512bece4fead39a0c75c943cc5d10bbfb810b4")
  (:PATH "src/recovery-closed/read.lisp" :GIT-BLOB
   "08bcf5a490ceba1ae7a94258f1c0bd9ca148cdaa")
  (:PATH "src/recovery-closed/resolve.lisp" :GIT-BLOB
   "2f107b18e7060dc54e902dbe0363d836285ace5f")
  (:PATH "src/recovery-closed/types.lisp" :GIT-BLOB
   "a403121cd1459db7eb753981a402152615541caa")
  (:PATH "src/recovery-closed/verify.lisp" :GIT-BLOB
   "bac75f2ed61947826ca194cf57f8d2feb003f7fc")
  (:PATH "src/recovery-replay/package.lisp" :GIT-BLOB
   "8639d959e29e9f36270a94831eace49f6535a863")
  (:PATH "src/recovery-replay/read.lisp" :GIT-BLOB
   "05eade0aed1e83cf2df5f5e2bab563d31c95081a")
  (:PATH "src/recovery-replay/resolve.lisp" :GIT-BLOB
   "85eb7133fe1463016604e6a6c9ca26dea7bb5633")
  (:PATH "src/recovery-replay/visit.lisp" :GIT-BLOB
   "0c94187caae5986c8481cf1a8e8bc060db2a7b53")
  (:PATH "src/recovery-selection/frame.lisp" :GIT-BLOB
   "101813cb3536365ac914f10e926f424dec18647e")
  (:PATH "src/recovery-selection/index-preflight.lisp" :GIT-BLOB
   "c3d336e63fbb2b5d972a314a86edd123f050aa7b")
  (:PATH "src/recovery-selection/index.lisp" :GIT-BLOB
   "b4b3488404b09fd1df4f351910043b333c1f355e")
  (:PATH "src/recovery-selection/key.lisp" :GIT-BLOB
   "f751a1ed921903353ab48e52e9fa24d374202ed1")
  (:PATH "src/recovery-selection/package.lisp" :GIT-BLOB
   "9dd583b4bf868183f7555b1e4f7c29f2a13c244c")
  (:PATH "src/recovery-selection/read.lisp" :GIT-BLOB
   "04903a7aa14fe3c332bad4255ff62f87d2e69b77")
  (:PATH "src/recovery-selection/select.lisp" :GIT-BLOB
   "dc4345cbad0fd4223eb50ed2d0ed6bcccb8ec709")
  (:PATH "src/recovery-selection/types.lisp" :GIT-BLOB
   "85930de29d2bc071ea7bbb8677d9aa0ac4e1310e")
  (:PATH "src/recovery-series/build.lisp" :GIT-BLOB
   "998f3c94e5ec1fd83f6146adc88f16350e1a941d")
  (:PATH "src/recovery-series/entry.lisp" :GIT-BLOB
   "a37b7c87eff82670540beb78aa78cb40fab88455")
  (:PATH "src/recovery-series/package.lisp" :GIT-BLOB
   "51f3d64796df1a2180cb977adb8a094e7c7fd94b")
  (:PATH "src/recovery-series/preflight.lisp" :GIT-BLOB
   "0daff10989f88386221d11ff4123384a67092075")
  (:PATH "src/recovery-series/read.lisp" :GIT-BLOB
   "d7ec011280d40883408a816425210f60f4ae4561")
  (:PATH "src/recovery-series/stabilize-preflight.lisp" :GIT-BLOB
   "4e6d9e8047e76ce2fa5324ebca9456d29bd69c2f")
  (:PATH "src/recovery-series/stabilize-set-preflight.lisp" :GIT-BLOB
   "81cc2dcf0e684ccc710e51b221b84c10f057db8f")
  (:PATH "src/recovery-series/stabilize-set.lisp" :GIT-BLOB
   "7fe9646c0721b02d48f8ee99cf3f2e5fa020d4c5")
  (:PATH "src/recovery-series/stabilize.lisp" :GIT-BLOB
   "1fe16c3863409635d882ebce5a9f5abc03ad5ecc")
  (:PATH "src/recovery-series/types.lisp" :GIT-BLOB
   "eb8d4a347b96aca4e5277435fe1361ed794f39b6")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "d7ac44761869f57e333497212510416fd1e794c9")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "58a3e620a8def39d2b24cd210d9283184c247ed2")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "b30dd16f31dcb00316d6983c7cfc5cb2948ce0ee")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "54b5092b76b1c609ee195c44bd9206c1800542c4")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "c7bd0b41e7a84ef73829aeaef3a113f12e7a6031")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "c2fab3b7b2cec568adfe88f0037fc216f83765c9")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "2059363677925a732eb1c70fc1ed1be94d715ea9")
  (:PATH "src/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "7b7f3c4c1bbcd252583249b650f82ab968409e24")
  (:PATH "src/recovery/inventory-directory.lisp" :GIT-BLOB
   "4f253cf7dbe6dad5814749ff53d40759ab882d73")
  (:PATH "src/recovery/inventory-id.lisp" :GIT-BLOB
   "c6dabcd733010fe6966aa1d27656b0760744e55d")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47bc32082a709eb46a5fdb5a5b3011d2c4377f80")
  (:PATH "src/recovery/inventory-sources-build.lisp" :GIT-BLOB
   "149e9ca5fc1bf3ed1f473beb075d5c35b6099886")
  (:PATH "src/recovery/inventory-sources-query.lisp" :GIT-BLOB
   "9742c023b3347d38f678c7a1752a9cc37b665996")
  (:PATH "src/recovery/inventory-sources-types.lisp" :GIT-BLOB
   "b52908d02b1cda451190be58333ef9c9508fddf9")
  (:PATH "src/recovery/inventory-sources.lisp" :GIT-BLOB
   "3619190b49dcbaa32ef4dd2111995df5beace5c5")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "1cbb826a8999579a98e51b9c0ecd1cd6a6ff9661")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "1a98289ea132f2b68309efb3a7552f99a514796e")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "801976598bd390814c4ddfaf00377ee38369405c")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "2ddd4fb6d4c1717a25c369c6a7252f9f80769221")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "9754b563a1d0fbfcda0f306e94b1b6d0257dfb0e")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "43af5d7e8cf2c8465492531133ea9647f614e613")
  (:PATH "src/recovery/manifest-transition.lisp" :GIT-BLOB
   "c871c345eb51367427adbb9bda778a6857a97510")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "40c49f4692e11b4c7f9f55b93bae69210adbdcbb")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "eb0e60664ad7abeefde7a4fc81fa7b3fa38ac57f")
  (:PATH "src/runtime/active.lisp" :GIT-BLOB
   "d7889b0103e18eb47878a88c760cae38de48b3fa")
  (:PATH "src/runtime/build.lisp" :GIT-BLOB
   "4fbf71ebd764f7d90977d027372437e113fdeed3")
  (:PATH "src/runtime/closed-preflight.lisp" :GIT-BLOB
   "5e10ae83ae0e4cd3adbbdae389629a0a854182a2")
  (:PATH "src/runtime/closed-transfer.lisp" :GIT-BLOB
   "3db2e73c10bf24d3931cbf993f240aac45e88e0f")
  (:PATH "src/runtime/closed.lisp" :GIT-BLOB
   "b06f0ae33a9c084c5101cfa5170e358bd4f7fe55")
  (:PATH "src/runtime/package.lisp" :GIT-BLOB
   "5eb61dac53e09bdaf493680967ab65938b6b8f63")
  (:PATH "src/runtime/preflight.lisp" :GIT-BLOB
   "7babef89ceacca9a7c8fac7068b54f653a4a3c58")
  (:PATH "src/runtime/query.lisp" :GIT-BLOB
   "34a7a4ebe5d0baeb93acca991f02a38b0cad2204")
  (:PATH "src/runtime/types.lisp" :GIT-BLOB
   "19fe3cc6004382550ea7939c5bf100d1fcc92607")
  (:PATH "src/scheduler/build.lisp" :GIT-BLOB
   "a55b8e7089ba3880ffa69cee4adb13dc0543069c")
  (:PATH "src/scheduler/lifecycle-build.lisp" :GIT-BLOB
   "7dfa330d606ef9c4dbceeb83845a32e75eb62fe6")
  (:PATH "src/scheduler/lifecycle-read.lisp" :GIT-BLOB
   "3b7ece551dae47957d9350c49285617d60b6ee3f")
  (:PATH "src/scheduler/lifecycle-types.lisp" :GIT-BLOB
   "5a03c1176d6bc019bcd230b0fd665cc48d555395")
  (:PATH "src/scheduler/lifecycle-update.lisp" :GIT-BLOB
   "47d323541ba45f5fb507ebcdb2eae9dd701533a2")
  (:PATH "src/scheduler/lifecycle-worker.lisp" :GIT-BLOB
   "8ae274af549a3464fd5f03d64e3c10ac73145630")
  (:PATH "src/scheduler/package.lisp" :GIT-BLOB
   "cadff5f2e29e7c5b625b95f9387faf29aad02178")
  (:PATH "src/scheduler/policy.lisp" :GIT-BLOB
   "37ed8717cf05ca8f03c06204641f47af18858a7b")
  (:PATH "src/scheduler/pool-claim.lisp" :GIT-BLOB
   "9ba00e2b77cbca2189e947e00b435fb81145668e")
  (:PATH "src/scheduler/read.lisp" :GIT-BLOB
   "ea882e41d231cc0dbafc9eac66bdd1f935433f00")
  (:PATH "src/scheduler/types.lisp" :GIT-BLOB
   "6fcd3d494dc339f8061a64fcce4133b9c86708b3")
  (:PATH "src/scheduler/update.lisp" :GIT-BLOB
   "eb0ad7a3abf119d733ae571d98695980ca4fe694")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "b1aeaa0032d7418cd3c9a7dcbc35add751fb17ce")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "5b189fb0ff0e54abaf72adcb05e5da58ebecb741")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "f81c0946f3e173fa6bf87c24e7c51999afc46363")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "6fd26253982dba01e9eef2702c5f4ede6ba70659")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "95cf61b5df1cdd57975f64a05f890528568046b1")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "79cc08666f83630adba9cab148bb71c2f6d46253")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "f21cae5c4f5cfd94d5d4b6a437ac2ede15750b5d")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "4d09a75d977a0eed0819e7c7d61737d245514b00")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "dee5f67f723edb5ba47b78e68baeee49eb56015c")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "18a29843546af6fc28fa36742a175fc3e6f19e1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "3b6335d3c665f5fe66771242c4d43db3de10b333")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "16700994fa5959633b21d4c7eb21483cd489f0c4")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "2a15783bbd1f5fdd1adb0ae4a045449970f46650")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "d7c667389bf8ad8ec4a04ce2b1bc9ec90e64a54d")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "fd552f6657ade1482eeada765c0880b6afe8a73f")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "6643873870526ee603a5c5b554a91650e5be0e6f")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "028c7b1111e43c0749479067451894b38479a7ec")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "10af1f2b835f387f7c5c69011b712c37bce142f9")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0548df3e81bff3332c67897fc70d7aece4c822ea")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "0e6f1849a77fd2de1109e3576f174f13e2eca665")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "05cb8e127c9384da1c40d21c7566f5d57b705ecf")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "65b17519d6d6e5d9e104bc37b2c4eb4d3b93f132")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "51110c6784e99fc94ddf5a2344e0d85262c297d5")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "cad0373b4932d1b28a19b940936a817774de9eae")
  (:PATH "src/wal/frame.lisp" :GIT-BLOB
   "2f2f1af60a399d9263f15ce4565502da1c70f173")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "17858cffba82609484a6f4a32d082d14ceec1c4b")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "e0ea179069a7b297c7c26f6c294c7d4aea3db671")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "d9f682a05cf5adb22850728a839228f02744c5f2")
  (:PATH "tests/cache/README.md" :GIT-BLOB
   "3836e59b86c5a731e772fbf0a6cca376b14806af")
  (:PATH "tests/cache/guards.lisp" :GIT-BLOB
   "af881fd91c3820ab19d1daa2d56f1fe57257d08f")
  (:PATH "tests/cache/support.lisp" :GIT-BLOB
   "fd829e7352ba878e73df30d979e9558ff6ccba14")
  (:PATH "tests/cache/threads.lisp" :GIT-BLOB
   "ca03c59f0fada09cae8c452fed6490de32d4a3a6")
  (:PATH "tests/ci-catalog.lisp" :GIT-BLOB
   "15b3b3126a8dc57fe98d4dccd5c85d1fcb88204b")
  (:PATH "tests/codec/cbor-array-write-support.lisp" :GIT-BLOB
   "2a47078354c45a5775f48f6dd8f5d784da7de202")
  (:PATH "tests/codec/cbor-array-write-threads.lisp" :GIT-BLOB
   "43bac6c9604140af2594d85b76c14c3101b6925b")
  (:PATH "tests/codec/cbor-array-write.lisp" :GIT-BLOB
   "b13f58264f3cd97e1947ee52936732a7fcebe672")
  (:PATH "tests/codec/cbor-float-write-support.lisp" :GIT-BLOB
   "5416b62340ae8f3332915f8891529d95549a5fba")
  (:PATH "tests/codec/cbor-float-write-threads.lisp" :GIT-BLOB
   "3b0840150945cd4f118516b1d6d61524fa6856fa")
  (:PATH "tests/codec/cbor-float-write.lisp" :GIT-BLOB
   "747cd8a72445a3ea638cd1910bc9faa63f4cdc33")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-item-read-support.lisp" :GIT-BLOB
   "0326100362a1c4b24d2c7e511e45357f09a56d33")
  (:PATH "tests/codec/cbor-item-read-threads.lisp" :GIT-BLOB
   "a0da65545ed80ede0a967cadbb337731f6fe1ce9")
  (:PATH "tests/codec/cbor-item-read.lisp" :GIT-BLOB
   "b2cbdcb4255c51d9da4fe73b28939c1cb923fefe")
  (:PATH "tests/codec/cbor-map-write-support.lisp" :GIT-BLOB
   "113bfc4529199f69dea1862baec0aa7403c6fa97")
  (:PATH "tests/codec/cbor-map-write-threads.lisp" :GIT-BLOB
   "892d30fd1c7a8f12430c6caa6f43ee872574eb09")
  (:PATH "tests/codec/cbor-map-write.lisp" :GIT-BLOB
   "6ad0e9b5a48ba9c32c46d720f2f7f1821368d6c8")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "532c3f1d5898083364f17f9fc9cbf0da7b798bda")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "d88b573a98689b5e1c0cbade8f8a7ac69470554f")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "0989d7f8e43ec7213df856b842b1e9149df96d9f")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "186f1772335ce33e4e3d1d933bf4d4e91fe0763f")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-read-support.lisp" :GIT-BLOB
   "cfd55cd47d782673113e67af625c1360195a345c")
  (:PATH "tests/codec/cbor-string-read-threads.lisp" :GIT-BLOB
   "c3686d6e47ad56e53db556747ee2d49cea527df5")
  (:PATH "tests/codec/cbor-string-read.lisp" :GIT-BLOB
   "8437bdcaa4cf308dbf4614e748cdab4be2ae6d62")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "66b5d03695f522cca8013ccdad3ede690cc63412")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "16cc32f2c51d28f75a64b93ead642340f88e9c05")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "595d51a96ee3767c13797910ea324061a4788617")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-tag-write-support.lisp" :GIT-BLOB
   "e6e1e91e5ed95019e20b11d2dc0e408911acb46e")
  (:PATH "tests/codec/cbor-tag-write-threads.lisp" :GIT-BLOB
   "1c731f7ed83f703e3d2a8a4c57e6c702ef127887")
  (:PATH "tests/codec/cbor-tag-write.lisp" :GIT-BLOB
   "df97950ec8d24157bb6566c7995262f7beea7742")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "0f66cc1f8b493598d436b1d62d7211f4196fb430")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "7717054be474eba254f3f645fc62ec4ef65a511c")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "0c1a6d9fbe44a95b951a7e1a9aad90f65cef961b")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/control/native.lisp" :GIT-BLOB
   "2107cb66de45ded987c7fb1392155ff6afebbed6")
  (:PATH "tests/control/publication.lisp" :GIT-BLOB
   "f987c9317990ce977ecadb747268b39d2612eba1")
  (:PATH "tests/control/recovery-guards.lisp" :GIT-BLOB
   "b2e877dfcc35468cfafd95f398f33d1415692c1f")
  (:PATH "tests/control/recovery-publication.lisp" :GIT-BLOB
   "cd99169af8aecf204ce9cd2e6e1f2a9fbb081f68")
  (:PATH "tests/control/recovery-read.lisp" :GIT-BLOB
   "21f33af3220a237d7a8dc2ff3a98bfd4c41fa201")
  (:PATH "tests/control/support.lisp" :GIT-BLOB
   "053d81269526d2e7c78181fbe2f8e58ac3f878f3")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/engine/compaction.lisp" :GIT-BLOB
   "4e46ba4400a7af10db08d35e191be80204237234")
  (:PATH "tests/engine/delta-location.lisp" :GIT-BLOB
   "3ab2c0e5c6d45ed746de955c72192327c525c71c")
  (:PATH "tests/engine/delta.lisp" :GIT-BLOB
   "5160313851bdfa637e80b76095679b9e965f22a7")
  (:PATH "tests/engine/image-activation.lisp" :GIT-BLOB
   "bb8b9470cae4854efd1336bc5a289d7305faed54")
  (:PATH "tests/engine/image-auto.lisp" :GIT-BLOB
   "19215e89154e8f65ba0e83e21b04d3d069c93a69")
  (:PATH "tests/engine/image-build.lisp" :GIT-BLOB
   "8543c508064d8198957a25f93e6da3c343d6c26a")
  (:PATH "tests/engine/image-discovery.lisp" :GIT-BLOB
   "50891fbd9ded0ece20969b466f24f1f591bd1439")
  (:PATH "tests/engine/image-maintenance.lisp" :GIT-BLOB
   "3b28dcea4388823fe8999b1fd67edb7a0da5343d")
  (:PATH "tests/engine/image-renewal.lisp" :GIT-BLOB
   "01e55612ec38f31fe281c0f1707bf1aa50aa1345")
  (:PATH "tests/engine/images.lisp" :GIT-BLOB
   "7ea979d2249807380c4532acc52e2ad299dcc0ad")
  (:PATH "tests/engine/index-auto-disk.lisp" :GIT-BLOB
   "57efb3be2095d695461717b131b95f2b6c1131f7")
  (:PATH "tests/engine/index-automatic.lisp" :GIT-BLOB
   "d2f9514760932005ab95e12f037606cf0dd94fde")
  (:PATH "tests/engine/lifecycle.lisp" :GIT-BLOB
   "55f8a525a7fb68846724b869d15eee8238924fe3")
  (:PATH "tests/engine/processes.lisp" :GIT-BLOB
   "f88f26beb525183b9a7840b72ae5f8fae727be7f")
  (:PATH "tests/engine/record-cache.lisp" :GIT-BLOB
   "7dc3029e1048aedb7aab3bfb2649a69731e01734")
  (:PATH "tests/engine/rotation.lisp" :GIT-BLOB
   "f0de9a0e81ab82a161ba5e19a0706aae803e63e5")
  (:PATH "tests/engine/support.lisp" :GIT-BLOB
   "4f050bd297add4aff17a15bb24b3f499785018fd")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "b1e71783b65b85e6253f733098c3153d41c4971c")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ca77be5b92c1cec98860dd5f59b278e9dcaf8ae4")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/fulltext/admission-concurrency.lisp" :GIT-BLOB
   "fbc2b0294a9369c4812bf206f001399be2af0ff3")
  (:PATH "tests/fulltext/admission-guards.lisp" :GIT-BLOB
   "b3475774a8a7f31269ea0e1b33bb659e230f67c7")
  (:PATH "tests/fulltext/admission-lifecycle.lisp" :GIT-BLOB
   "175c3e3bd33b163bc7593066ade68eb426e8e757")
  (:PATH "tests/fulltext/admission-resources.lisp" :GIT-BLOB
   "29ac6bf4b0b392579997b79c10142b2f491a5eb7")
  (:PATH "tests/fulltext/admission-rows-support.lisp" :GIT-BLOB
   "1713cd556e5e37525af25a15b4f5b36474967d88")
  (:PATH "tests/fulltext/admission-rows.lisp" :GIT-BLOB
   "6e2d6c65c8046ad7dee030a4e95330f3ce3993dd")
  (:PATH "tests/fulltext/admission-support.lisp" :GIT-BLOB
   "1eaef196dc555b086cd53584731041bfb97cda59")
  (:PATH "tests/fulltext/admission.lisp" :GIT-BLOB
   "74ed0e49ce0c839cb5e74d854704d21cb8dbbf68")
  (:PATH "tests/fulltext/allocation-threads.lisp" :GIT-BLOB
   "870a308baeed93e1aabb6dc9a88db443592439c0")
  (:PATH "tests/fulltext/analysis-conformance.lisp" :GIT-BLOB
   "ad704e6457ad7873b3eb2feea241da5129962c8f")
  (:PATH "tests/fulltext/analysis-support.lisp" :GIT-BLOB
   "805f7e60fd3f6aa25b4c53680e5251188e57868e")
  (:PATH "tests/fulltext/analysis.lisp" :GIT-BLOB
   "4d529aef551bd365f0c12eb3dffbb7b2960fae56")
  (:PATH "tests/fulltext/codec-corruption.lisp" :GIT-BLOB
   "c62dd05be34d1f653eed8565cc0b40b950bdb97f")
  (:PATH "tests/fulltext/codec-differential.lisp" :GIT-BLOB
   "91b651930dd7f9da36fd317453686d272e0d2c40")
  (:PATH "tests/fulltext/codec-guards.lisp" :GIT-BLOB
   "9f6b8e823ae25c43b767141e0193b908ca0e763a")
  (:PATH "tests/fulltext/codec-support.lisp" :GIT-BLOB
   "890e176db757eed9e2680f5b247a12922709d4b9")
  (:PATH "tests/fulltext/codec.lisp" :GIT-BLOB
   "50b924b1c0e9127da33413f1100bf04ef2ee500d")
  (:PATH "tests/fulltext/document-differential.lisp" :GIT-BLOB
   "78466a8bc1213d0794155535eb28a990a45a38aa")
  (:PATH "tests/fulltext/document-guards.lisp" :GIT-BLOB
   "608f322bd4ac149abb9ffbb352595b5c94d3d217")
  (:PATH "tests/fulltext/document-support.lisp" :GIT-BLOB
   "57d59f345c6cbe8dba253acce7993409b5bbed94")
  (:PATH "tests/fulltext/document.lisp" :GIT-BLOB
   "ab305e31ece6bf7fd20ac5b7ea119b01c57e7c92")
  (:PATH "tests/fulltext/format-guards.lisp" :GIT-BLOB
   "9a23048572dfa5eee314221ced3425a1ea46c28a")
  (:PATH "tests/fulltext/format-support.lisp" :GIT-BLOB
   "d03bd892800d593a3550bdc709d43c357041bfab")
  (:PATH "tests/fulltext/format-threads.lisp" :GIT-BLOB
   "b8e8eb4491b59c721071396ce656eb09186f988d")
  (:PATH "tests/fulltext/format.lisp" :GIT-BLOB
   "b7cb19b82d4e50d457c603b8708693adf27785f0")
  (:PATH "tests/fulltext/index.lisp" :GIT-BLOB
   "0673c32fe456a9cb77cf4aa5cc4e071a888cccf2")
  (:PATH "tests/fulltext/minimum-v2.hex" :GIT-BLOB
   "c4db496b0e5b920665d1c80bea204f6227da1f0e")
  (:PATH "tests/fulltext/put-concurrency.lisp" :GIT-BLOB
   "613b2e5a89d505701583aa9c68e6273f4163d2e7")
  (:PATH "tests/fulltext/put-guards.lisp" :GIT-BLOB
   "6b531c1b143860a46e84d5c77da982f54fbd413b")
  (:PATH "tests/fulltext/put-lifecycle.lisp" :GIT-BLOB
   "8cba90b629299c8494194a73ef8b819f554ca557")
  (:PATH "tests/fulltext/put-physical-guards.lisp" :GIT-BLOB
   "bd293d0ef1d5596e85859cb85e41639b3a0fd70e")
  (:PATH "tests/fulltext/put-physical-native.lisp" :GIT-BLOB
   "635118c4287ab13b4b98e34d04dc307b97497827")
  (:PATH "tests/fulltext/put-physical-support.lisp" :GIT-BLOB
   "1e81cc2af12f24515debc953d4f7884b07a2e197")
  (:PATH "tests/fulltext/put-physical.lisp" :GIT-BLOB
   "f8d1fa41090aaa40c2146ec9280bff08d968fdce")
  (:PATH "tests/fulltext/put-rows.lisp" :GIT-BLOB
   "0ee39c61cdbb6742eb36d65677030d44c96ad98e")
  (:PATH "tests/fulltext/put-support.lisp" :GIT-BLOB
   "2a3c9b543587b1a9c5402a16f82cfc1c671a6160")
  (:PATH "tests/fulltext/put.lisp" :GIT-BLOB
   "83f9503ec4bd1a6610443bb8eea991e6069c6565")
  (:PATH "tests/get-active/construction.lisp" :GIT-BLOB
   "ec2831edef2e452597ce867b026eb73c84fc5214")
  (:PATH "tests/get-active/directory.lisp" :GIT-BLOB
   "48c9a60e58536170a610844e853eae6f91beeff1")
  (:PATH "tests/get-active/preflight.lisp" :GIT-BLOB
   "7f41c04257e0bab10a2ffbc091b02d660029c4df")
  (:PATH "tests/get-active/read.lisp" :GIT-BLOB
   "0ab8c2b2b639a51b0217876a896d9468f41e22de")
  (:PATH "tests/get-active/support.lisp" :GIT-BLOB
   "0eb0864894f8f8cb32221ff98c75dde5aff80c26")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "ced6f8b39836c1c2ff264822ddaf05d0653bfff6")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/lifetime-support.lisp" :GIT-BLOB
   "cd514970e84f8654318dcc23a6b1ef24323be8a9")
  (:PATH "tests/get-directory/lifetime.lisp" :GIT-BLOB
   "c57261d2de469318402d5bf79f5ab5d27108bb46")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/series-read.lisp" :GIT-BLOB
   "b500bb83170622b6d96edbd363ebc85240064c18")
  (:PATH "tests/get-directory/series-support.lisp" :GIT-BLOB
   "ead990e110b588bb4df35ea17d3816db3b79cee5")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "a5b09ee5120bedc4e946366239dd5e6c978b27d2")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "9e03608bef23c0aa5a69dce8c7dfd09ed818a377")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get-resolver/construction.lisp" :GIT-BLOB
   "322c63ee6576304ca1ab19e28b902b680bc2acae")
  (:PATH "tests/get-resolver/read.lisp" :GIT-BLOB
   "a1788d1aab3f76b9dc29095676ec42f3a1f936a8")
  (:PATH "tests/get-resolver/sort.lisp" :GIT-BLOB
   "442ce9eef4fac8f593a9d94ed08a76b830773563")
  (:PATH "tests/get-resolver/support.lisp" :GIT-BLOB
   "11d5cf0efe8ee4f5606707cc7eca175442a50190")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/image-processes.lisp" :GIT-BLOB
   "11c9ba829c73bb71f54be52710ac699b40b47f60")
  (:PATH "tests/index/image-tests.lisp" :GIT-BLOB
   "3ea1eb66179db5125b2b5137372c70c9d953e95f")
  (:PATH "tests/index/mode-policy.lisp" :GIT-BLOB
   "4513fb320a9f1ced973820d8a9c58ee9a0d73ea6")
  (:PATH "tests/index/mode-support.lisp" :GIT-BLOB
   "14d4c82bd54795844d14ac1d7f1b7ced320c4233")
  (:PATH "tests/index/page-build.lisp" :GIT-BLOB
   "bd600c74e28d32328559e9b9f268b4afa3481a55")
  (:PATH "tests/index/page-cache.lisp" :GIT-BLOB
   "aaace9b80ff3c6ce2ab52a3644be8c56eef4ebfd")
  (:PATH "tests/index/page-chains.lisp" :GIT-BLOB
   "265a85cd6aff51dd8a5ceae50f60ff7b8d63660e")
  (:PATH "tests/index/page-corruption.lisp" :GIT-BLOB
   "880775f39ed5c6352c0ae448b7a830ea63b03a85")
  (:PATH "tests/index/page-fixtures.lisp" :GIT-BLOB
   "0ed84fd77dc21375773651e4bb42e56a2c0a5e43")
  (:PATH "tests/index/page-lookup-support.lisp" :GIT-BLOB
   "8800a152c6f0eefa572fda9e17ee9e5e1ff77023")
  (:PATH "tests/index/page-lookup.lisp" :GIT-BLOB
   "290b471927fc1647a000099d8f3f8b57b878c843")
  (:PATH "tests/index/page-support.lisp" :GIT-BLOB
   "920c631d2763260aec7bcb02d3172d8be1d4b21f")
  (:PATH "tests/index/page-tests.lisp" :GIT-BLOB
   "a18f0315e5480a356504f1f541bffc1ad3484fc6")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "d21142f34f3687c35f39c86d962f2c8ffd52c330")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/create-relative-native.lisp" :GIT-BLOB
   "fd5e819e2197869a93259857aacfa68bfe9e9a44")
  (:PATH "tests/io/create-relative-support.lisp" :GIT-BLOB
   "8382ffb8f04b6d2fc3e4adb89f995c9c37b0e445")
  (:PATH "tests/io/create-relative.lisp" :GIT-BLOB
   "7fb4c3665ca1b8f6de2dedd2827cfc150dcddf02")
  (:PATH "tests/io/directory-lock.lisp" :GIT-BLOB
   "4cefd15616f4ac2312a669b1242929d2706eb540")
  (:PATH "tests/io/flush-failure.lisp" :GIT-BLOB
   "76a80588d99b441e8c57a97f9a10d4d9d6c7b59b")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/open-relative-native.lisp" :GIT-BLOB
   "cdb197bf2760de70e7ec49af76e2954a18006997")
  (:PATH "tests/io/open-relative-support.lisp" :GIT-BLOB
   "4256567b2a10423a41540298317c8ef80e6b5af0")
  (:PATH "tests/io/open-relative.lisp" :GIT-BLOB
   "4bec9451a13db1437e081bda2858d4cb8b1e5de1")
  (:PATH "tests/io/readiness.lisp" :GIT-BLOB
   "1a7ce2205d7278a080395a3f4287540e11d3bea4")
  (:PATH "tests/io/rename-native.lisp" :GIT-BLOB
   "99f79041529d20d0ea774b01e3ed82fc5a274cdd")
  (:PATH "tests/io/rename.lisp" :GIT-BLOB
   "e83443eec6187d53118795c4f6ee797112f27ea2")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer-failure.lisp" :GIT-BLOB
   "c87c80fb9c82062bf4d4179d67f710ff10b4f051")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/local/native.lisp" :GIT-BLOB
   "b8891b57aa6229995b7c6ee5581d9cde650e3c93")
  (:PATH "tests/local/processes.lisp" :GIT-BLOB
   "9d716c57c2dd44219555c50bb00d0385e1a4a946")
  (:PATH "tests/local/server.lisp" :GIT-BLOB
   "18d38754fed2d888ab8d6b7d29b2352a20122bcb")
  (:PATH "tests/local/wire.lisp" :GIT-BLOB
   "349d7df061b5871658ad3fa6a14601bd58f1fa2c")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery-active-checkpoint/guards.lisp" :GIT-BLOB
   "cae7d70c2a5598bb5c3e1256ef4bb8b391656f6f")
  (:PATH "tests/recovery-active-checkpoint/publication.lisp" :GIT-BLOB
   "a996bc5f82f16fe12a74d9bee5962f8d8629f53a")
  (:PATH "tests/recovery-active-checkpoint/semantics.lisp" :GIT-BLOB
   "a4b80a1a678cdc4537ee9d989f178124829e70cb")
  (:PATH "tests/recovery-active-checkpoint/support.lisp" :GIT-BLOB
   "998ab160b939c93797fc90206a9b50f2cf55e452")
  (:PATH "tests/recovery-active/publication.lisp" :GIT-BLOB
   "8a3c4ba88dd7010c65a464d231ebdab2c8c27e67")
  (:PATH "tests/recovery-active/read.lisp" :GIT-BLOB
   "63f52ee0e0ab244ed278562a5d7fbc752b7617e7")
  (:PATH "tests/recovery-active/semantics.lisp" :GIT-BLOB
   "1d3c935a1169904c900461b67adb96f4dfd96b94")
  (:PATH "tests/recovery-active/support.lisp" :GIT-BLOB
   "5ebf9d06ae855b07875aadc10e2a8ac01ba56036")
  (:PATH "tests/recovery-archive-csn/guards.lisp" :GIT-BLOB
   "a6d91274479da64fa689ca370ff495cc96ae0e51")
  (:PATH "tests/recovery-archive-csn/native.lisp" :GIT-BLOB
   "d66af858c855e39c984f1ff8534e6de3c7c7fc88")
  (:PATH "tests/recovery-archive-csn/plan.lisp" :GIT-BLOB
   "b740c77023c500208ff742e02c4d5aebcd44db70")
  (:PATH "tests/recovery-archive-csn/set.lisp" :GIT-BLOB
   "d163bf160241d2225ac3282c1d925aa65e249ab3")
  (:PATH "tests/recovery-archive-csn/support.lisp" :GIT-BLOB
   "0c458a3f6f8aa062c2cc8831834c29159e09762d")
  (:PATH "tests/recovery-archive/active.lisp" :GIT-BLOB
   "ccbaaa3294880905584ad42c0601201fa3a3dc36")
  (:PATH "tests/recovery-archive/guards.lisp" :GIT-BLOB
   "8afea2a3df30099c07badd7d9c0bcf627a5f9a9d")
  (:PATH "tests/recovery-archive/native.lisp" :GIT-BLOB
   "ae8df9ced72f9142ade184ec78bdc576e05593e1")
  (:PATH "tests/recovery-archive/query.lisp" :GIT-BLOB
   "b0a56949ec13ec7c80466ac8b3cecc79c0fc6d63")
  (:PATH "tests/recovery-archive/read.lisp" :GIT-BLOB
   "22d1042700435e2c15e3f610f9ada9c4a8d8d4ed")
  (:PATH "tests/recovery-archive/support.lisp" :GIT-BLOB
   "0cbefaed0f74c8e34e4cea9a359c58f9196f22ad")
  (:PATH "tests/recovery-closed/csn.lisp" :GIT-BLOB
   "754611c3818a0aac26b189392d4024a251439d0c")
  (:PATH "tests/recovery-closed/guards.lisp" :GIT-BLOB
   "344857641ef2206d4d5a800fbb93b834a9f13c4d")
  (:PATH "tests/recovery-closed/publication.lisp" :GIT-BLOB
   "72f179d28936100b91d1847eeb8a24c696552619")
  (:PATH "tests/recovery-closed/read.lisp" :GIT-BLOB
   "0e401337f36768cd63206cbb7b6adf91eeeeb1ef")
  (:PATH "tests/recovery-closed/semantics.lisp" :GIT-BLOB
   "a931be1523c72d49e955aa7708bec6bd3b273be0")
  (:PATH "tests/recovery-closed/support.lisp" :GIT-BLOB
   "15bafc01c04fe1763d9a6580f6ad0bbb1917f40c")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "e6f289d77025dce439787287abc6a4dde0ac69f5")
  (:PATH "tests/recovery/inventory-directory-native.lisp" :GIT-BLOB
   "8f89629becea88fdc74c920a59676412c3a7b976")
  (:PATH "tests/recovery/inventory-directory-support.lisp" :GIT-BLOB
   "c316b3647e7ea5391d687917fe802907f2273bb4")
  (:PATH "tests/recovery/inventory-directory.lisp" :GIT-BLOB
   "ead38feadd94f49276596d0abf989f29d13af497")
  (:PATH "tests/recovery/inventory-id.lisp" :GIT-BLOB
   "1f05c46bfc887984c476bd7673d2b2dde998c44d")
  (:PATH "tests/recovery/inventory-sources-native.lisp" :GIT-BLOB
   "86144ee3fe19ef0f2a54c9760ed193860881ced4")
  (:PATH "tests/recovery/inventory-sources-support.lisp" :GIT-BLOB
   "36b79c4091825c32ffc3aa32a146ee5121881ebc")
  (:PATH "tests/recovery/inventory-sources.lisp" :GIT-BLOB
   "3ffd5a9fb098ab4aeb091a6823fcec68d22c19aa")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest-transition.lisp" :GIT-BLOB
   "cdde7b60edddd974153ee670d859a94993afa367")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/runtime/adoption.lisp" :GIT-BLOB
   "8fbee7f08a25445b66895ae2e329a217070f67f4")
  (:PATH "tests/runtime/bootstrap.lisp" :GIT-BLOB
   "1398120574f95ebaec3c7431a74a35e0ced01652")
  (:PATH "tests/runtime/guards.lisp" :GIT-BLOB
   "a097cc38e13a1ef7369a2ed996d042718cf7312c")
  (:PATH "tests/runtime/native.lisp" :GIT-BLOB
   "e92ba03fb8184a6c95c44269a26a831b714974a1")
  (:PATH "tests/runtime/support.lisp" :GIT-BLOB
   "7d4dc59eab68672512aed0f4ae578436e669fe2e")
  (:PATH "tests/runtime/threads.lisp" :GIT-BLOB
   "2454593a231d5d6bb9ef4318eb06567ce3192d24")
  (:PATH "tests/scheduler/controller.lisp" :GIT-BLOB
   "8e14282e1f42f3b247a5c578d8a683ddc6147381")
  (:PATH "tests/scheduler/dispatch.lisp" :GIT-BLOB
   "6a493f0022ac8c9b6117c2a62df49fa596194c7b")
  (:PATH "tests/scheduler/lifecycle.lisp" :GIT-BLOB
   "874391809401f42a4db81fe544306165f99ceb5d")
  (:PATH "tests/scheduler/pool-begin.lisp" :GIT-BLOB
   "13a239cf97403806a73242abbd5b545440a17645")
  (:PATH "tests/scheduler/pool-chain-support.lisp" :GIT-BLOB
   "a1ea8258495b9a717e1e0ef164133f6b7140f8a5")
  (:PATH "tests/scheduler/pool-chain.lisp" :GIT-BLOB
   "86675c17ea47eff262cb03cdb41e50bcdb82b78e")
  (:PATH "tests/scheduler/pool-claim.lisp" :GIT-BLOB
   "f636ee873deb2cd5347a50c9aec4a6afa16d13c5")
  (:PATH "tests/scheduler/pool-recycle.lisp" :GIT-BLOB
   "3c779589cd7df6ae1146c2ca50b70320093bbf4a")
  (:PATH "tests/scheduler/pool-start.lisp" :GIT-BLOB
   "ec19bb409799e7956e40c34cc9264d02033cfb22")
  (:PATH "tests/scheduler/pool-step.lisp" :GIT-BLOB
   "d0ff803608990744408749722210e812f6268782")
  (:PATH "tests/scheduler/support.lisp" :GIT-BLOB
   "f2301a1adf44c33284aaa1171acd90c5828b0396")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "ef3d4671b3df48b932c1666f8b58fdca4eecbc77")
  (:PATH "tests/series/log-binding.lisp" :GIT-BLOB
   "c116a9169058ddd9e384fda5f52bb5787977e20e")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "257c6f8cf28bdd8408a3363041d621497f4a5f67")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "c3eb1ce7870b81944c23efac9b8cb7f8f4888ba9")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/vertical/method.md" :GIT-BLOB
   "3e60572557391e2c772d3b44491ae18eecb352bf")
  (:PATH "tests/vertical/processes.lisp" :GIT-BLOB
   "059fbd2bb702e76e986b97edfbe4d3784599d583")
  (:PATH "tests/vertical/resume.lisp" :GIT-BLOB
   "6f80a0d0fec9f725beca54d06d961932bd815043")
  (:PATH "tests/vertical/scenarios.lisp" :GIT-BLOB
   "fcbc7878d56720604f0e86a916d2e42c0f28cffd")
  (:PATH "tests/vertical/support.lisp" :GIT-BLOB
   "37c2e8d1da68eb425cdd11548f8699c888afd7bf")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-float-write-audit.lisp" :GIT-BLOB
   "485544868eeadff247968b86c2d5da9b3b610295")
  (:PATH "tools/cbor-float-write-bench.lisp" :GIT-BLOB
   "d992c9f8cf6ff0d748fcb77f871fb77969480bca")
  (:PATH "tools/cbor-float-write-mutation.lisp" :GIT-BLOB
   "5d0d6bd46b0286f153ee9c482734c659959396e2")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-read-driver.lisp" :GIT-BLOB
   "a6b65bd233dba2a2eec941d96a75b9db948d19f8")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-parallel-tests.lisp" :GIT-BLOB
   "a49a03a64a137e66c07c98f981327fc42d9cb508")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "e3df9f52590ce2de86ad75b872c859b81bbcc518")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "1f63d49150e6b7b23c1df2a9c25c3d2288861b8a")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "253fea1c65c6aacb77fa56f2ab05cce086a1856d")
  (:PATH "tools/ci.lisp" :GIT-BLOB "c0b6255982f4299b883992f5829baaebcd2aaa36")
  (:PATH "tools/ci/archive.lisp" :GIT-BLOB
   "03712985b7cf1493a7009a35965cadf6c9902292")
  (:PATH "tools/ci/conditions-self-test.lisp" :GIT-BLOB
   "99f857163fa38683871790731b6f72448cf92ffb")
  (:PATH "tools/ci/coverage.lisp" :GIT-BLOB
   "233ae46d6ab9fab6a74046140323eecc64243174")
  (:PATH "tools/ci/data-self-test.lisp" :GIT-BLOB
   "b5d6a8f505604e3c45d228582933af38713cc01a")
  (:PATH "tools/ci/data.lisp" :GIT-BLOB
   "8cec68fa2e6e5d7e4484a53cde13964b875f9222")
  (:PATH "tools/ci/github.lisp" :GIT-BLOB
   "a2ca20ed9c586b104f59091d174028b3454d6a10")
  (:PATH "tools/ci/identity.lisp" :GIT-BLOB
   "abf3cc722957379e1408d629b81a2d1916a0788b")
  (:PATH "tools/ci/measure-self-test.lisp" :GIT-BLOB
   "18959f2608b1be4ef1b77b0a7d3b1a67735c16d4")
  (:PATH "tools/ci/measure.lisp" :GIT-BLOB
   "7e16fd5b80a7bbce27a0c856a6abd001ff4814ed")
  (:PATH "tools/ci/producer.lisp" :GIT-BLOB
   "a7fab0bcc8dc6a33ed37acb0d391ec1a73674493")
  (:PATH "tools/ci/publish-self-test.lisp" :GIT-BLOB
   "400b9ba4c1c3fd0e6bd158f3f89bcc58e802c595")
  (:PATH "tools/ci/publish.lisp" :GIT-BLOB
   "d8a212faaa5bba7df102377a70e6cd9d75d7810c")
  (:PATH "tools/ci/self-test.lisp" :GIT-BLOB
   "8b2cfa7eab4f728c70a4f0f6e4a81da3259a9e38")
  (:PATH "tools/ci/support.lisp" :GIT-BLOB
   "b5fe7c565ed0f885b666d8dba836bec4a7ba4c65")
  (:PATH "tools/ci/test-self-test.lisp" :GIT-BLOB
   "2cd7248feeb0ff089429cee6f29ab12283665ec4")
  (:PATH "tools/ci/tests.lisp" :GIT-BLOB
   "9c81cf6aec5f89896d9e4ccdcd59ccf1d3c65c6f")
  (:PATH "tools/ci/workflow-self-test.lisp" :GIT-BLOB
   "f0278d9bc21245d6890e52011414627376bca5de")
  (:PATH "tools/collect-command-archive-tests.lisp" :GIT-BLOB
   "49da390b7e170acc9ffdafa78285f215aec75f44")
  (:PATH "tools/collect-command-archive.lisp" :GIT-BLOB
   "d2eb1bd8a62b0fd98ec023243b2a768c19988dc7")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/control-checkpoint-bench.lisp" :GIT-BLOB
   "f631bbb7096359592fde0ae2b4462c2d2067d5a1")
  (:PATH "tools/control-transition-bench.lisp" :GIT-BLOB
   "40fd5a04dc62cced8e688ed30f59e0d810716a43")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/engine-crash.lisp" :GIT-BLOB
   "04c4796c05bdcecf6d8fc83d3ee1eafcf969fed9")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "abd8e62e937c60e9ac68c3ccce904111388bff09")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "f520ecdb46cc94e07d774d39cb73beed380aa867")
  (:PATH "tools/fulltext-codec-fixture.lisp" :GIT-BLOB
   "f6756e030cdde7beaab41a6b38516950f1663c9e")
  (:PATH "tools/fulltext-persistence.lisp" :GIT-BLOB
   "ab0dbf4ec2e5335721818cc03711b92d7d62111d")
  (:PATH "tools/fulltext-qualification.lisp" :GIT-BLOB
   "d649e9cafa96bcb4351bbced5de04bb10352ab85")
  (:PATH "tools/fulltext-unicode-tables.lisp" :GIT-BLOB
   "ba86b196441a40e662f6052e189074eef08b75d5")
  (:PATH "tools/get-active-init-bench.lisp" :GIT-BLOB
   "c62f2bf8ba96c3e80cdd50ba067e4c4df3e5e957")
  (:PATH "tools/get-active-init-mutation.lisp" :GIT-BLOB
   "b2cd809d99d049757156ddf0141997e3b67903b4")
  (:PATH "tools/get-cost-bench.lisp" :GIT-BLOB
   "696d56846ce992f186da2b468f8de55063532b02")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "45897c0afa972a437bbb595493b87dd0c8ed9710")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/get-resolver-coverage.lisp" :GIT-BLOB
   "5ab21d923b68e35adbc177ecd352bb33340f0c07")
  (:PATH "tools/get-series-bench.lisp" :GIT-BLOB
   "2950d4fcb7fc93fbfc7d78c860f0ac43ed984f35")
  (:PATH "tools/get-series-capture.lisp" :GIT-BLOB
   "9c42e23d381751e8140f186f969c6c2ef8d606cf")
  (:PATH "tools/get-series-mutation.lisp" :GIT-BLOB
   "3d3e887ba8e1d90612e561dfffb3d71c486e813b")
  (:PATH "tools/get-throughput-bench.lisp" :GIT-BLOB
   "6554b119583602b9d06b3ff7b2bb9c8104130d79")
  (:PATH "tools/index-image-crash.lisp" :GIT-BLOB
   "01f7cec3a08a55fcf51b4c743e588ad53a0023ae")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/io-completion-mutation.lisp" :GIT-BLOB
   "7fd59fd86e2d477a6b6ee0f7a2142f8ea6b073c6")
  (:PATH "tools/io-rename-bench.lisp" :GIT-BLOB
   "988d259af126212adc2be8fb9ca9acd8755fdce0")
  (:PATH "tools/io-rename-mutation.lisp" :GIT-BLOB
   "dfc691c88e9ab940a065703a223a1c414454b0f2")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/legal-notices.lisp" :GIT-BLOB
   "f120b9660591fd3eda904c9cf0722bddae3f05a0")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "adf3ca235874a2b950e57ea61a719c4c90e9dda8")
  (:PATH "tools/local-client.lisp" :GIT-BLOB
   "1ab2f474ad7db04a3fc8cc6dd7e84a2441498d20")
  (:PATH "tools/local-fault-server.lisp" :GIT-BLOB
   "92cd3d6164c6000c181374e3b917bbf1bb83aaa6")
  (:PATH "tools/local-server.lisp" :GIT-BLOB
   "517652d80ad2d4fbbe85be42fa110d4c902d8cf8")
  (:PATH "tools/local-tests.lisp" :GIT-BLOB
   "02aace929b7f5e2fd790c02d1557628ea17d7afc")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/measure-pool-begin.lisp" :GIT-BLOB
   "e3094d9f35efdaa647751f19a7acda00c36d515a")
  (:PATH "tools/measure-pool-claim.lisp" :GIT-BLOB
   "712a4a5393b69539f02cd625223918e404b331d3")
  (:PATH "tools/measure-pool-dispatch.lisp" :GIT-BLOB
   "bddb449176d3b7b6ae946e841a0ca3202e6c28ef")
  (:PATH "tools/measure-pool-lifecycle.lisp" :GIT-BLOB
   "3a229eecc3c158cec9af8fad6abd5fc2d980e2dd")
  (:PATH "tools/measure-pool-recycle.lisp" :GIT-BLOB
   "cb20f6d271889a9801106daf230ee934aaa7bf81")
  (:PATH "tools/measure-pool-start.lisp" :GIT-BLOB
   "e6be453833925b89cdc49303b99a23374f3b2689")
  (:PATH "tools/measure-pool-step.lisp" :GIT-BLOB
   "cdcb410e27475282d157b0d64a4656ea6ad069a1")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/pages/bootstrap.lisp" :GIT-BLOB
   "a9cf9ea45672b576b76acf1e4773c2c2949bc2ca")
  (:PATH "tools/pages/build.lisp" :GIT-BLOB
   "e319acad4fe5bf1f9cd14b65772775c95ab632fe")
  (:PATH "tools/pages/check.lisp" :GIT-BLOB
   "b0524f02c494e61f4edf08aa2802ba1a3d16cd66")
  (:PATH "tools/pages/code-reference.lisp" :GIT-BLOB
   "16bf45ca14cc936283e32700698e696f4a36a09c")
  (:PATH "tools/pages/code-source.lisp" :GIT-BLOB
   "8ba99903d3afdae918fd8966410fbbaf7438066f")
  (:PATH "tools/pages/code-tests.lisp" :GIT-BLOB
   "1f1349e749863b14d9690a33dda48537d96434e3")
  (:PATH "tools/pages/dependencies.lock.lisp" :GIT-BLOB
   "f0f339aabf9998e7f910f8904744549766426ec6")
  (:PATH "tools/pages/editorial.lisp" :GIT-BLOB
   "f5a43b2ba1a876c3643ad4b3b64b43096c193b49")
  (:PATH "tools/pages/generate.lisp" :GIT-BLOB
   "56ee4dcf36cc76e82b3997357630eca1083dadff")
  (:PATH "tools/pages/markdown.lisp" :GIT-BLOB
   "a6ce370b0cbbeb2869c88112b69ee7aa38e7effa")
  (:PATH "tools/pages/model.lisp" :GIT-BLOB
   "bed6a6fb53b8efb13020bcf5cc5d1ec27aa31436")
  (:PATH "tools/pages/publication.lisp" :GIT-BLOB
   "8154535b76733cbdd33b3217744481635860a5a0")
  (:PATH "tools/pages/runtime-check.lisp" :GIT-BLOB
   "f9ab88e954f1b07f9c59594f55e67e909ee5f2e3")
  (:PATH "tools/pages/site.css" :GIT-BLOB
   "8069a0942d7ce79b272d8011c4f6c6002aae07e1")
  (:PATH "tools/pages/site.js" :GIT-BLOB
   "06770c92736cc6bd2b3e0c9638ec09f5c0dcc1c3")
  (:PATH "tools/pages/tests.lisp" :GIT-BLOB
   "d05b62748b36cefed5977d1a445c18e1d70b8e62")
  (:PATH "tools/pages/theme.lisp" :GIT-BLOB
   "547ef0acc0e6070c7fcd53385b0efed1aec5f82d")
  (:PATH "tools/pages/third-party-notices.lisp" :GIT-BLOB
   "907abf85677565bb547a4b7f0e7c6311b3bfa3ce")
  (:PATH "tools/pages/third-party-notices.txt" :GIT-BLOB
   "68ebcf8172dcbbf0865767f5194abb97911a83ef")
  (:PATH "tools/pool-controller-bench.lisp" :GIT-BLOB
   "cf6f31dd9c7a8d7f4e7cc1f19c4b9c5a48af6d55")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "068090ec38864b2b55877918aec57375312ee8db")
  (:PATH "tools/recovery-active-bench.lisp" :GIT-BLOB
   "9c11d5654a6168c27c64abcc8f852673c5974515")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/vertical-crash.lisp" :GIT-BLOB
   "8f920374d5b1049f5bac1e8dfb441099575de6cd")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :STDOUT "(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 261618
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61573824 :P50-TICKS 217
 :P99-TICKS 257 :LATENCY-TICKS
 #(132 139 130 132 133 160 135 136 134 135 139 135 138 147 136 132 138 115 136
   134 133 146 137 142 142 141 141 133 129 135 153 141 135 131 133 131 135 138
   225 223 222 222 222 226 218 217 219 224 218 227 228 215 219 224 216 220 222
   226 221 216 220 234 219 221 220 222 217 227 237 221 218 220 222 216 217 220
   219 223 218 216 220 219 218 217 219 218 230 220 216 218 143 223 218 228 221
   217 223 223 225 219 215 217 210 220 218 225 220 228 217 220 236 217 220 221
   217 219 222 224 218 222 218 214 215 218 216 213 218 224 229 231 219 223 217
   218 234 224 210 226 218 219 225 225 220 220 221 220 218 223 219 220 215 234
   218 221 219 217 220 224 222 216 219 219 222 220 218 219 218 224 215 226 220
   218 223 224 236 218 221 226 221 217 223 218 221 217 221 217 220 225 223 219
   218 218 224 218 233 218 217 216 220 217 223 221 218 224 205 221 219 223 222
   223 201 220 222 217 218 223 225 225 219 222 223 219 235 218 222 221 217 221
   221 218 218 221 203 250 221 219 221 221 214 220 219 221 219 217 219 218 217
   230 221 214 224 228 217 231 228 219 220 231 219 218 221 217 223 219 219 222
   221 224 216 215 228 220 226 224 220 220 211 248 217 217 214 220 218 221 219
   220 236 217 218 217 216 217 216 217 217 222 221 222 218 217 215 216 216 215
   215 214 213 216 216 214 216 218 214 216 213 218 215 219 215 216 227 215 214
   215 215 217 216 220 215 214 215 215 217 222 220 216 215 218 216 215 216 214
   214 214 227 209 211 214 211 208 208 214 211 216 225 216 219 218 201 264 219
   236 231 222 196 251 285 262 324 256 216 220 233 220 217 308 297 235 225 223
   215 253 226 240 233 225 220 223 225 223 222 221 222 222 227 223 245 223 222
   220 220 221 222 223 223 238 228 218 220 214 224 220 218 215 217 215 215 214
   214 234 222 217 215 215 220 215 220 220 216 222 215 216 215 233 223 217 216
   208 228 209 220 219 223 220 226 236 221 221 221 221 220 219 233 223 205 208
   218 223 261 245 227 225 221 243 236 225 231 221 224 221 219 219 218 221 229
   217 223 218 217 219 215 218 217 223 224 222 218 210 217 217 221 217 218 226
   220 228 220 217 216 216 218 239 219 221 214 228 223 219 219 222 227 221 218
   226 232 215 215 276 224 219 218 222 217 228 228 41190 386 252 257 225 213
   175 207 216 227 218 218 211 211 210 231 217 214 204 210 213 216 246 217 237
   212 186 210 218 211 217 247 212 211 210 213 212 210 219 211 236 218 219 210
   221 213 232 212 217 214 205 217 202 212 209 213 213 215 229 210 211 217 218
   219 225 216 227 232 219 215 211 217 210 201 215 229 211 210 223 213 209 212
   210 208 210 208 209 229 213 210 210 211 232 222 229 228 241 210 218 224 219
   220 224 218 223 215 218 244 219 206 217 225 232 215 216 231 217 220 218 222
   210 239 216 216 211 210 211 212 211 237 213 214 218 211 212 211 217 214 211
   232 216 211 215 212 213 210 211 210 236 212 212 210 213 210 211 232 210 212
   213 234 214 211 219 210 215 210 225 211 208 210 211 227 221 213 211 207 217
   213 213 235 203 214 228 213 209 211 210 212 214 212 210 211 210 216 238 211
   214 209 231 207 213 210 210 215 213 235 217 210 210 210 211 212 213 215 227
   214 210 210 211 220 212 209 210 210 215 234 213 213 212 211 213 212 213 213
   221 212 211 211 211 235 215 216 210 227 214 214 210 218 209 210 188 242 209
   213 217 195 205 213 210 213 158 203 230 211 208 214 212 209 214 211 210 233
   210 212 210 216 212 213 209 211 209 237 202 213 214 213 209 224 208 213 219
   213 210 234 213 214 217 212 208 225 217 214 175 232 209 211 212 211 209 210
   214 235 220 215 237 220 216 240 210 218 210 211 210 210 206 210 224 231 211
   209 209 212 213 214 201 214 216 219 217 233 217 224 213 211 238 212 211 218
   213 210 210 213 225 211 209 213 209 218 209 233 212 211 217 208 233 209 210
   218 209 210 235 212 210 208 230 212 210 214 210 234 211 212 212 211 210 232
   221 215 148 206 211 209 233 211 213 209 211 227 209 209 209 212 232 207 216
   248 213 215 216 208 215 213 206 211 214 234 218 215 202 208 210 207 232 212
   212 210 228 212 219 214 210 210 220 198 232 217 210 215 220 231 212 209 213
   210 230 211 212 213 214 210 206 213 232 211 211 212 229 210 201 209 217 208
   212 196 233 208 208 215 209 213 216 236 211 213 218 220 208 226 213 212 215
   209 213 221 218 204 210 211 233 216 211 214 212 219 212 230 210 213 210))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 218479
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61633888 :P50-TICKS 212
 :P99-TICKS 237 :LATENCY-TICKS
 #(218 211 212 208 211 217 211 213 210 232 212 210 211 209 210 239 212 210 210
   211 211 230 210 210 212 217 207 236 212 209 128 231 204 217 220 214 225 217
   218 214 233 201 210 217 212 213 241 213 215 228 209 209 205 209 217 234 216
   210 240 175 210 216 221 229 213 200 216 210 207 210 237 204 217 212 226 211
   218 215 209 209 209 224 215 211 213 216 213 225 215 181 201 189 196 215 168
   174 219 182 215 214 221 232 212 215 214 218 209 213 213 212 210 234 162 210
   204 211 222 209 215 214 211 209 183 211 213 230 210 217 210 208 210 211 212
   228 170 219 209 212 216 215 212 210 211 233 212 210 220 209 237 214 210 211
   210 210 210 229 209 209 214 211 204 235 212 210 211 207 214 210 212 208 212
   233 210 207 209 215 214 208 212 216 212 213 293 211 210 210 211 211 207 224
   219 211 213 212 211 231 218 185 211 219 211 210 207 237 211 203 209 210 209
   208 238 211 208 211 210 220 243 210 212 216 215 211 210 212 219 202 237 213
   211 212 219 210 235 209 209 230 211 212 211 226 214 209 210 212 231 215 210
   233 210 213 217 213 214 209 209 209 214 209 232 214 211 217 213 213 231 211
   204 213 212 210 229 208 208 212 211 211 209 209 211 210 209 209 210 209 226
   210 211 210 214 231 218 216 218 209 214 212 214 269 219 220 209 211 241 214
   213 211 211 209 229 213 210 212 212 211 233 211 225 212 212 213 215 211 219
   210 205 209 235 213 217 212 210 215 212 211 206 210 209 213 213 214 210 211
   241 210 210 210 215 211 209 226 214 209 214 212 236 212 209 212 211 212 206
   228 215 212 216 218 219 209 213 210 213 214 225 223 215 218 210 205 236 221
   218 216 213 220 207 234 216 208 207 210 206 231 212 216 210 209 211 216 234
   209 212 219 210 214 236 214 212 217 213 213 226 213 211 217 221 230 213 211
   228 211 208 210 212 228 220 209 215 233 209 207 214 212 227 212 218 234 214
   214 214 213 218 210 208 232 213 219 218 216 217 211 229 214 211 211 217 223
   219 211 233 216 211 215 218 213 215 215 229 218 213 214 217 216 210 187 216
   217 211 214 220 216 212 211 220 219 216 205 218 206 212 215 217 215 219 209
   219 214 216 222 209 210 219 223 216 215 221 220 219 210 208 217 218 213 224
   221 223 176 208 209 220 216 223 220 215 221 214 220 221 195 214 218 226 216
   218 229 217 224 217 217 209 216 213 219 212 213 218 221 214 224 226 214 217
   215 220 224 215 220 224 218 219 182 218 219 221 217 218 218 228 221 221 220
   219 216 221 218 220 218 222 205 202 216 215 211 210 212 213 213 211 212 212
   218 220 210 216 211 212 210 225 203 216 223 223 219 218 212 218 214 218 223
   213 215 219 213 210 211 213 211 214 214 209 208 210 215 218 211 211 213 216
   207 211 215 209 208 208 212 210 208 212 214 212 209 210 213 220 209 212 212
   213 214 214 210 209 209 212 212 207 209 210 215 214 211 209 210 210 210 210
   208 216 174 222 210 214 209 209 213 210 209 210 178 207 214 212 210 210 209
   213 216 219 215 209 217 215 204 207 206 212 195 217 215 210 212 217 212 204
   212 198 221 211 212 213 211 216 212 209 211 210 210 212 211 213 209 217 212
   217 210 214 203 217 210 177 221 215 216 216 212 206 150 219 214 210 210 211
   218 220 216 216 209 196 217 217 210 218 211 211 212 209 213 196 210 217 218
   218 209 210 204 216 178 210 207 209 209 209 212 211 218 216 208 212 210 222
   212 211 211 210 211 214 214 208 208 211 213 208 209 211 214 210 214 210 209
   209 209 210 213 217 213 211 215 205 208 210 210 212 210 208 214 216 202 206
   212 209 210 209 211 209 211 220 215 214 211 215 215 208 209 210 219 198 214
   212 216 212 211 214 208 209 220 213 216 216 213 206 207 209 211 213 209 202
   214 211 211 207 212 212 211 212 212 209 210 222 212 211 208 205 218 214 214
   216 226 221 221 224 222 228 218 217 215 216 216 221 220 213 208 218 208 212
   217 215 213 219 207 214 214 213 215 211 212 211 217 211 215 211 213 212 220
   218 212 218 219 180 214 212 212 213 216 214 181 212 218 210 215 212 213 211
   211 201 175 217 211 212 213 214 215 210 210 211 210 214 223 211 212 218 220
   213 211 214 216 205 211 223 217 216 191 185 214 214 212 212 167 216 214 211
   216 215 213 215 204 210 210 212 213 219 213 222 209 214 207 212 209 222 210
   211 211 220 208 212 213 219 210 212 213 211 209 222 217 210 211 221 211 212
   211 212 210 212 213 221 210 212 210 214 212 213 211 213 215 209 212))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 220225
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61573920 :P50-TICKS 212
 :P99-TICKS 241 :LATENCY-TICKS
 #(213 211 210 217 210 213 211 210 208 217 226 212 204 216 213 211 213 210 211
   211 220 213 212 212 219 211 211 211 212 214 210 212 209 211 218 211 214 210
   212 210 219 213 213 210 214 217 214 218 210 212 218 215 211 212 216 217 207
   210 213 215 212 211 213 210 209 206 210 211 212 214 213 211 210 210 215 215
   206 206 214 211 210 216 217 212 217 210 222 220 203 210 212 211 212 213 212
   210 207 208 210 213 211 211 212 212 211 210 206 216 213 164 217 219 216 215
   212 213 209 212 218 209 209 193 182 221 224 204 208 216 222 217 222 209 213
   218 210 213 218 213 201 210 215 209 209 209 211 213 211 210 214 208 219 207
   238 223 220 209 212 211 215 211 213 211 217 212 213 216 211 213 212 215 212
   210 172 207 210 211 210 213 213 222 208 216 206 212 208 212 212 232 211 217
   183 211 209 203 212 226 230 229 241 227 219 223 211 210 209 211 211 216 208
   209 212 221 218 213 231 210 210 212 209 209 203 210 209 209 209 213 211 231
   233 216 237 240 232 212 236 211 210 213 211 210 220 214 198 208 217 210 209
   211 210 212 211 223 207 211 209 209 210 211 212 211 1746 220 213 203 222 209
   209 215 215 217 211 214 226 210 221 218 214 213 213 215 212 214 219 215 221
   215 211 211 213 211 214 214 210 213 213 214 206 215 210 213 221 213 209 212
   209 227 213 213 210 215 211 211 202 215 216 212 210 214 218 214 214 212 220
   212 213 214 215 213 215 209 211 213 215 210 212 226 205 213 209 210 211 210
   182 210 213 214 217 230 210 212 218 215 212 211 209 214 213 212 212 210 211
   215 212 211 212 212 214 214 204 212 210 211 211 209 211 214 213 203 213 215
   209 216 215 209 209 212 213 217 208 218 209 211 212 215 209 209 215 216 211
   220 211 211 211 228 215 209 214 218 218 219 215 210 215 210 211 217 214 215
   215 221 158 211 209 212 215 219 221 217 215 212 204 218 211 212 213 213 215
   213 203 214 212 211 216 209 211 214 213 208 217 219 206 209 209 200 215 209
   211 213 214 217 216 181 215 210 202 222 215 209 210 216 214 166 137 223 220
   211 208 207 210 210 208 210 197 213 217 217 214 213 210 209 211 215 207 209
   209 207 210 209 210 213 218 212 208 216 212 210 217 215 212 211 214 216 210
   208 210 212 209 209 210 208 213 209 212 207 211 208 208 207 207 209 210 213
   208 208 208 207 208 208 208 208 208 216 208 212 209 208 209 208 209 210 209
   209 210 208 208 207 207 212 208 207 209 207 218 214 214 213 218 213 212 214
   214 212 212 223 217 215 212 224 214 214 216 213 214 213 212 211 212 213 204
   214 218 215 213 217 220 214 213 213 217 215 213 212 195 220 234 223 217 218
   214 217 212 218 223 222 219 216 212 215 216 222 215 214 214 223 224 215 213
   219 204 215 212 215 215 222 213 216 214 214 230 227 225 216 215 219 214 214
   216 213 216 213 214 206 213 215 216 213 219 223 216 214 218 216 226 215 219
   229 213 209 213 213 216 212 218 214 219 222 214 211 213 216 215 214 215 214
   222 220 234 195 211 214 226 207 216 213 214 213 216 216 213 223 216 214 222
   180 224 180 153 218 222 216 216 214 220 214 219 191 212 214 213 213 213 213
   215 214 217 214 215 213 215 214 213 214 213 211 217 218 216 215 218 214 219
   215 218 224 226 224 226 220 228 219 223 223 219 232 222 228 218 218 219 226
   220 200 212 214 214 214 211 212 220 221 245 223 214 219 231 216 215 223 214
   212 218 207 211 227 163 655 380 332 290 283 261 309 279 228 224 217 219 223
   206 214 220 219 219 212 213 210 201 207 214 209 217 221 200 212 211 212 216
   208 210 213 215 215 212 212 211 216 209 209 209 210 209 200 224 211 209 209
   214 209 208 210 210 209 215 217 209 208 208 210 209 209 208 209 214 212 220
   212 209 209 209 211 209 209 208 221 211 211 194 223 215 209 210 214 208 211
   216 210 209 218 213 209 208 206 202 209 217 211 207 216 210 213 213 208 209
   208 210 217 208 211 215 155 213 209 208 209 209 227 209 210 209 208 213 210
   209 208 209 215 210 211 205 209 211 209 208 212 207 208 225 210 208 209 208
   207 206 214 226 215 202 216 218 221 205 212 207 212 216 203 215 147 213 213
   210 214 211 210 211 213 212 223 218 207 211 209 211 210 214 215 211 213 222
   211 208 207 197 216 201 213 211 211 220 213 217 210 213 217 205 209 210 208
   219 215 210 209 209 207 212 216 203 212 192 212 212 212 219 209 209 149 212
   212 209 214 206 210 211 211 208 208 209 209 210 209 214 212 209 208))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 223031
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61573440 :P50-TICKS 209
 :P99-TICKS 269 :LATENCY-TICKS
 #(212 210 221 218 213 209 216 209 209 208 211 209 215 203 209 217 212 210 209
   215 216 186 213 216 213 208 214 208 207 211 214 208 206 215 210 213 209 208
   209 208 208 208 210 215 210 210 211 209 209 209 212 209 209 208 213 213 212
   208 209 207 209 218 214 208 212 211 208 211 212 209 210 207 208 214 201 218
   216 208 214 206 212 213 210 200 207 217 211 211 210 207 211 210 208 209 203
   219 209 212 211 212 213 211 217 214 210 215 215 211 215 220 228 219 209 209
   209 214 206 211 211 208 209 211 209 209 209 211 213 214 211 210 209 208 208
   214 210 210 221 214 209 212 208 213 213 205 206 212 185 214 213 210 217 212
   210 208 210 209 214 220 210 216 209 209 210 209 209 209 205 210 216 209 210
   206 208 217 216 208 211 217 210 220 211 217 204 208 210 209 209 205 214 214
   215 211 217 209 210 210 206 211 219 215 208 214 212 208 211 210 207 209 212
   213 217 214 208 209 210 208 209 208 209 216 210 214 211 199 209 210 209 209
   209 215 209 210 216 208 210 205 208 207 210 209 219 215 214 198 211 214 219
   209 214 209 214 212 198 212 213 210 209 217 215 205 212 201 141 211 209 210
   209 209 216 203 201 205 202 216 212 219 190 209 208 209 209 210 206 217 216
   209 217 204 210 210 209 209 213 221 214 208 211 210 209 209 211 209 210 214
   157 216 181 211 210 209 211 207 210 212 209 211 211 211 208 212 211 210 208
   214 215 211 215 214 213 211 213 212 215 194 214 216 217 221 218 212 212 206
   213 217 213 212 218 214 215 248 201 228 236 209 224 217 193 199 200 207 198
   208 219 186 130 129 129 129 129 128 129 129 139 131 130 129 130 135 128 163
   137 176 158 130 127 129 136 129 128 127 128 128 128 130 128 127 217 215 218
   213 215 213 213 213 214 213 217 213 213 213 211 222 221 187 226 222 228 212
   221 208 221 214 219 213 213 217 217 227 220 229 234 221 215 216 214 213 219
   215 213 214 218 216 217 215 212 212 214 213 214 212 214 213 214 213 217 212
   216 142 131 142 136 131 130 454 334 265 306 278 267 300 269 279 301 267 288
   251 288 219 214 214 220 216 213 213 220 210 212 211 204 214 245 221 209 210
   222 212 219 209 222 212 215 207 227 213 212 214 216 213 213 209 213 218 213
   209 222 142 137 130 130 130 150 129 129 128 127 128 246 236 153 128 129 128
   144 132 269 127 142 145 134 130 129 127 128 148 132 142 138 126 129 127 127
   127 127 126 131 127 125 126 128 128 126 127 132 128 126 127 126 125 127 126
   155 148 130 128 124 127 125 136 142 147 128 135 127 140 128 128 130 130 134
   126 126 126 125 129 132 127 128 126 127 127 126 126 126 127 126 128 126 127
   127 142 142 128 133 128 127 127 131 129 126 151 129 126 125 127 128 137 131
   126 130 124 126 126 142 129 126 136 133 149 132 148 152 132 132 151 153 131
   211 216 209 210 213 210 207 210 208 208 211 206 209 207 209 207 217 213 217
   211 211 208 211 208 210 209 209 206 208 209 213 211 207 209 208 207 207 208
   208 208 211 212 153 221 197 210 206 222 199 207 207 216 213 202 206 212 198
   207 207 206 199 212 215 217 210 208 211 214 210 208 198 209 220 219 210 210
   205 210 210 211 200 211 209 209 141 133 128 127 129 128 103 127 105 127 123
   127 135 140 129 126 127 158 131 136 129 133 128 127 124 129 133 131 129 130
   129 129 131 128 146 128 126 128 127 129 126 127 126 127 126 127 113 127 128
   127 126 139 128 127 126 128 127 136 114 113 126 126 128 127 128 126 130 129
   128 128 126 126 127 122 124 128 127 137 128 129 129 127 128 126 131 136 128
   126 128 126 125 141 128 139 126 127 129 122 128 153 130 127 132 227 214 242
   214 209 214 207 212 211 211 214 210 211 215 207 215 211 211 210 210 215 211
   214 212 211 216 210 216 211 211 215 206 199 212 211 236 211 212 215 212 209
   208 210 208 223 211 209 218 214 214 223 212 214 215 222 191 216 219 216 218
   215 217 210 201 214 218 212 215 214 211 214 213 218 211 191 164 237 220 217
   224 218 219 185 135 112 129 129 128 135 130 129 128 126 129 128 130 128 128
   131 137 139 143 135 128 130 123 131 129 135 127 127 124 128 124 124 133 132
   127 140 140 137 179 135 206 174 135 129 116 129 128 132 133 128 128 129 128
   130 130 130 127 126 128 130 129 136 105 105 105 127 134 132 133 127 126 128
   130 131 126 134 132 133 129 141 158 132 145 138 134 129 160 159 133 132 132
   131 130 137 126 128 129 127 129 218 218 172 230 229 35119 249 147 140))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 213749
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61633776 :P50-TICKS 220
 :P99-TICKS 314 :LATENCY-TICKS
 #(185 146 151 153 143 135 136 137 154 139 133 139 198 253 231 222 230 227 226
   225 225 272 195 221 229 231 222 226 221 222 224 225 226 220 220 199 262 235
   235 227 236 239 229 225 225 221 229 228 226 221 225 167 148 137 153 154 143
   137 139 139 135 155 150 140 136 144 139 136 137 147 137 136 138 134 135 135
   133 139 198 159 147 146 140 133 137 142 150 142 136 136 138 138 235 137 142
   141 145 141 139 180 136 134 145 137 137 137 129 139 150 132 137 142 139 131
   145 143 141 140 145 136 147 136 151 134 140 142 136 150 136 141 138 138 168
   150 152 138 139 140 138 138 141 145 159 141 135 142 148 138 143 144 142 158
   147 137 140 135 151 140 141 140 134 137 134 137 139 135 130 136 139 151 131
   137 136 141 140 133 137 135 143 158 145 160 134 136 159 133 136 138 136 148
   141 138 137 149 135 145 135 136 135 136 135 134 136 137 134 143 139 138 139
   139 142 139 141 134 140 139 136 138 134 142 136 137 135 136 142 142 134 137
   136 147 144 147 143 137 184 207 209 221 223 219 228 220 223 220 228 222 220
   221 228 219 219 227 221 219 236 222 221 229 229 238 167 226 221 224 223 220
   226 223 221 221 224 219 222 227 224 229 227 220 269 223 224 223 215 225 222
   234 222 221 228 226 226 219 222 223 223 221 221 221 219 220 219 223 241 232
   225 226 229 221 220 222 234 182 271 194 219 221 227 221 223 221 228 229 216
   165 222 175 217 163 226 220 225 222 219 223 224 218 223 219 219 222 221 219
   218 227 222 219 220 221 218 220 233 224 224 234 229 229 222 225 219 220 222
   232 220 223 221 245 224 231 225 226 233 221 222 228 221 219 220 217 219 218
   262 217 220 217 221 244 211 220 220 217 210 217 219 227 220 218 220 220 217
   222 222 224 219 215 229 236 218 231 224 221 221 223 225 216 228 222 219 219
   194 225 222 222 218 227 222 223 225 223 221 222 221 220 229 223 221 214 226
   233 224 232 226 225 220 230 222 226 224 226 222 221 229 203 236 223 193 235
   231 233 229 226 222 223 227 223 223 221 223 293 223 223 224 226 222 220 221
   218 220 228 225 220 225 233 242 236 229 221 247 192 142 231 216 217 226 228
   159 221 228 219 225 224 224 229 228 219 220 221 225 219 219 223 219 222 220
   218 225 225 223 217 224 225 228 225 218 218 226 220 219 219 221 221 216 234
   222 229 229 200 222 227 219 221 219 226 220 221 219 220 219 220 223 220 222
   226 216 216 220 221 220 219 220 219 220 224 219 220 217 221 227 225 226 211
   226 225 212 216 230 221 379 229 200 224 227 228 224 235 236 226 231 219 220
   225 223 218 218 225 221 215 216 218 225 230 202 204 222 222 222 211 224 208
   222 231 227 221 226 224 227 228 231 220 219 226 223 223 225 221 224 219 219
   221 220 222 217 224 222 221 222 220 220 223 223 225 220 211 226 221 271 214
   225 235 229 191 226 192 207 216 228 224 226 221 225 227 220 226 222 225 227
   225 223 222 222 226 223 221 210 221 221 220 236 220 227 217 228 223 223 245
   220 222 228 219 229 206 230 222 228 207 224 218 215 217 226 212 217 220 217
   222 215 224 223 203 205 218 215 226 215 217 214 218 216 216 222 208 218 214
   214 216 207 218 228 230 220 223 215 225 212 212 226 207 207 229 221 226 219
   217 216 215 222 215 217 216 216 224 208 217 215 219 217 215 215 213 222 195
   218 203 218 229 237 226 220 211 220 225 279 229 226 226 208 217 224 219 208
   222 221 219 217 237 218 216 215 222 221 225 226 223 216 215 222 223 215 214
   221 227 215 214 215 221 217 215 222 199 188 220 211 224 216 188 228 222 189
   224 220 224 304 225 205 219 218 222 220 219 220 222 219 220 218 218 218 218
   227 237 214 225 212 228 220 219 229 212 221 223 219 227 219 221 223 230 231
   222 228 217 229 221 224 217 220 218 217 218 220 217 221 219 219 219 217 221
   222 219 223 223 227 217 218 223 220 224 228 223 220 199 214 223 222 218 227
   228 214 203 233 221 225 218 223 218 219 219 217 220 217 221 228 221 218 219
   218 218 218 179 224 208 227 228 218 220 216 224 220 219 220 219 223 242 217
   222 209 220 226 218 221 210 224 222 216 216 216 217 240 212 217 219 220 222
   222 215 227 216 219 216 216 217 202 218 208 220 229 231 222 215 213 224 230
   220 214 227 194 417 647 263 229 218 234 217 218 218 233 219 277 220 219 215
   212 188 227 188 215 464 409 222 222 242 225 238 256 259 261 297 268 368 273
   277 349 327 312 314 273 355 270 329 276 252 210 216 219 200 224 225))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 236044 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61573840 :P50-TICKS 224 :P99-TICKS 352
 :LATENCY-TICKS
 #(145 153 141 142 143 162 223 143 139 153 148 224 153 141 139 139 139 138 138
   139 138 138 138 137 137 131 154 156 148 142 148 151 284 243 225 226 223 229
   232 219 222 233 228 235 224 220 231 226 224 234 220 234 244 227 227 225 220
   221 225 222 227 223 233 227 222 221 217 223 222 215 221 223 217 224 219 219
   219 220 231 239 224 227 225 221 221 221 231 225 237 228 215 249 215 242 215
   243 231 201 231 224 229 224 222 221 221 223 223 222 227 226 228 225 223 220
   226 223 223 227 224 224 222 231 220 224 226 209 227 220 227 202 225 221 229
   228 225 222 219 227 216 220 220 230 222 218 221 221 220 232 223 219 221 221
   219 223 219 225 218 223 215 224 221 310 217 213 223 213 218 221 260 272 224
   236 237 232 223 163 231 216 227 219 219 219 216 218 216 218 223 217 217 217
   218 223 226 227 236 279 228 199 232 242 227 222 231 235 225 223 228 222 222
   237 197 224 218 218 217 225 228 217 220 224 226 219 218 219 226 224 222 219
   220 218 219 219 232 224 215 222 221 211 217 274 252 284 249 206 230 260 215
   248 209 273 239 235 196 236 224 214 226 207 201 222 227 215 221 222 201 209
   201 211 224 223 224 225 223 223 226 238 227 228 223 225 232 229 228 229 229
   205 221 224 231 225 224 238 240 230 247 230 227 221 219 231 223 224 220 223
   223 212 222 220 221 219 219 218 218 227 222 218 219 235 219 201 224 220 223
   226 226 229 219 220 233 226 205 231 284 250 165 246 222 259 239 251 379 288
   331 297 284 253 264 227 326 306 436 262 260 237 244 237 229 230 231 226 231
   234 226 233 231 243 230 215 234 231 229 226 224 233 293 225 228 219 224 236
   208 234 244 226 238 225 232 221 221 220 214 230 217 220 219 231 220 219 218
   221 220 217 219 222 217 223 223 224 217 217 225 227 221 226 221 225 225 223
   241 231 213 217 228 232 232 228 223 221 204 239 226 222 228 223 287 229 224
   221 226 224 221 224 221 222 229 238 223 229 224 225 223 224 226 223 225 290
   209 243 230 229 232 236 222 223 229 233 226 231 228 234 230 232 227 221 220
   221 222 221 221 221 224 222 223 224 222 222 222 220 220 221 222 224 225 227
   219 214 225 224 232 226 223 191 233 217 204 231 227 223 251 203 224 228 224
   230 216 223 223 231 227 236 231 229 231 229 224 230 226 225 225 224 230 228
   228 220 230 223 229 239 221 227 224 232 230 245 218 225 215 219 229 222 223
   215 237 227 217 214 225 218 218 220 220 223 219 219 217 221 219 220 217 224
   220 231 223 222 208 223 207 223 200 221 198 206 242 246 220 233 231 233 226
   234 226 230 228 228 224 233 228 232 231 229 224 231 233 233 273 223 228 218
   233 227 230 233 195 227 222 231 226 221 228 226 225 240 220 230 219 221 274
   313 229 269 391 362 286 327 287 309 319 300 296 276 319 327 336 336 602 334
   332 292 308 303 284 272 278 313 360 354 368 264 320 268 295 313 309 283 352
   266 264 265 500 320 346 277 246 239 237 228 229 224 228 223 255 244 227 242
   229 228 2512 247 238 237 212 228 227 205 227 200 218 227 222 222 223 221 222
   224 201 226 224 222 225 224 231 237 223 223 222 223 202 221 225 200 229 170
   238 243 245 215 232 236 206 224 217 191 221 218 216 216 222 221 218 219 219
   218 222 218 216 216 220 217 241 239 229 229 228 218 205 219 205 217 216 218
   217 195 237 235 264 243 230 228 226 201 230 228 226 227 226 230 206 204 200
   225 225 215 201 226 192 226 231 159 228 223 219 204 227 235 221 228 228 201
   246 229 228 270 215 243 247 229 219 226 224 225 223 224 222 221 225 227 221
   222 222 227 225 222 222 223 232 240 234 229 231 225 225 227 221 220 226 211
   225 226 235 227 222 234 231 225 223 230 229 216 285 347 244 219 215 236 233
   221 234 225 228 222 224 231 212 231 228 206 232 219 233 238 197 251 239 245
   241 220 230 220 222 221 219 220 220 221 221 220 223 220 219 219 219 219 221
   211 177 232 189 239 230 235 233 235 220 225 223 224 224 230 231 223 226 220
   231 224 219 219 221 216 220 218 218 222 227 220 218 217 219 217 217 217 218
   219 221 218 226 224 219 220 222 221 236 223 228 236 220 233 227 218 221 218
   218 225 222 245 227 219 227 220 219 221 219 225 219 216 223 225 224 229 232
   224 217 223 221 201 221 219 220 222 235 226 244 241 228 230 195 232 219 229
   231 210 226 230 228 227 263 260 298 236 251 308 308 283 243 230 220 236 227
   234 230 224 231 225 226 219 218 230 226 222 228 226 230 229 224 223))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 198684 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61633488 :P50-TICKS 215 :P99-TICKS 265
 :LATENCY-TICKS
 #(230 226 224 225 221 231 233 212 229 221 227 225 220 222 227 222 222 224 233
   246 242 224 229 223 221 227 235 222 219 219 225 217 221 218 220 223 219 169
   214 219 218 218 219 218 218 219 217 227 219 223 234 205 168 227 218 222 223
   229 236 230 225 233 222 207 226 223 224 230 226 224 221 223 222 224 216 221
   227 233 186 216 225 222 191 224 217 218 221 222 213 225 237 213 222 238 222
   220 221 222 219 219 220 203 209 248 221 221 223 263 232 214 234 229 221 222
   227 228 232 227 220 219 221 218 218 229 226 227 185 222 232 227 219 222 221
   222 219 219 230 234 219 219 219 220 218 218 217 217 224 224 214 229 227 218
   219 221 223 218 224 218 218 242 232 229 219 182 255 264 276 236 230 231 232
   228 224 223 227 227 226 228 224 226 226 224 222 200 220 221 227 229 231 231
   231 239 187 208 234 210 227 148 145 144 137 148 116 141 141 137 139 138 138
   152 163 142 138 139 139 157 139 139 137 139 142 137 138 175 188 161 183 158
   144 158 159 166 177 146 172 145 145 140 134 201 145 184 137 146 189 168 190
   157 159 141 137 137 199 198 208 212 212 196 244 167 258 221 218 203 190 201
   198 197 199 190 193 192 216 188 187 190 210 200 209 206 212 227 209 220 222
   163 208 185 203 202 198 225 219 215 215 126 135 143 137 137 135 135 154 165
   176 164 140 138 138 141 140 137 147 139 136 136 136 152 158 199 148 252 141
   139 137 149 138 136 137 136 137 136 137 159 142 155 138 137 140 143 139 150
   139 137 141 138 136 137 138 136 140 217 138 166 260 229 279 237 215 205 196
   214 206 220 229 204 222 219 220 232 216 221 235 225 173 179 187 182 164 144
   138 142 144 139 137 139 139 137 140 138 140 180 139 156 141 138 138 146 133
   141 139 137 139 168 228 221 194 216 225 235 219 223 199 226 221 199 222 203
   219 203 231 241 264 270 222 200 219 200 207 201 210 208 193 183 203 198 220
   210 191 206 198 217 236 223 219 222 217 219 209 213 221 224 228 235 220 233
   218 222 201 195 199 215 219 198 205 141 139 140 141 138 138 142 138 138 138
   137 139 138 138 138 145 137 135 153 142 146 155 145 216 142 139 137 136 136
   254 221 193 265 237 234 220 206 202 239 267 368 332 285 239 227 227 225 223
   219 226 220 220 222 236 228 223 221 222 214 230 216 239 228 228 223 225 182
   167 140 140 140 143 140 144 141 146 140 145 140 137 138 138 137 144 138 138
   138 138 139 138 139 139 140 139 138 137 138 138 145 141 137 141 137 137 139
   137 129 138 139 143 143 177 165 139 137 137 137 150 138 136 135 135 138 135
   134 137 157 144 157 180 232 225 231 225 223 223 211 192 211 221 235 217 198
   221 194 221 224 223 225 194 223 222 223 223 222 222 223 236 232 228 222 222
   234 223 228 222 224 219 215 171 141 139 136 143 132 136 134 139 136 136 135
   135 135 136 137 136 139 137 135 136 139 136 139 135 139 140 136 137 143 134
   148 154 148 148 147 140 140 138 149 139 136 137 138 137 138 137 151 145 140
   144 139 137 135 136 141 136 134 138 137 110 133 135 137 228 224 222 220 219
   238 232 230 223 226 222 220 220 221 223 223 220 219 220 234 221 226 197 201
   227 216 224 227 226 219 216 224 219 226 219 218 219 218 220 225 222 217 215
   220 207 220 218 223 216 214 225 218 218 218 217 216 195 220 215 214 219 223
   222 222 219 219 219 218 219 220 219 219 222 221 217 212 221 219 217 219 222
   220 210 221 221 225 220 220 221 225 227 214 218 225 213 206 221 225 190 220
   224 218 221 219 218 217 225 221 219 200 222 218 215 219 220 222 227 228 227
   230 165 222 219 217 220 214 215 217 215 216 220 228 218 220 223 218 217 220
   223 222 221 220 220 220 214 217 217 218 225 254 242 288 385 1206 263 230 230
   219 207 225 231 225 225 205 224 214 222 224 222 210 231 218 185 134 133 143
   137 135 133 133 133 136 132 132 133 120 132 133 135 134 132 134 133 133 118
   132 133 139 145 134 133 134 142 146 151 137 139 133 133 140 134 136 129 133
   132 133 132 178 149 153 141 139 134 144 142 132 133 134 133 134 136 134 138
   159 145 224 220 218 218 220 201 220 221 217 218 223 218 217 218 217 218 220
   216 218 247 224 210 190 223 218 207 220 218 214 222 218 227 220 226 217 218
   219 220 217 222 221 211 219 207 213 221 220 229 234 235 226 222 219 226 221
   213 219 219 217 222 210 213 220 211 219 212 209 205 211 214 215 198 212 209
   211 210 211 210 216 215 216 210 210 210 216 210 209 214 174 213 228))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 207000 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61573792 :P50-TICKS 213 :P99-TICKS 324
 :LATENCY-TICKS
 #(192 221 230 223 220 224 228 224 219 226 219 194 220 225 223 222 222 219 220
   219 220 220 219 218 220 226 194 224 342 237 258 332 229 226 197 215 217 226
   220 219 219 220 215 200 219 229 219 194 217 166 238 237 221 219 216 207 188
   214 213 218 220 237 221 203 195 213 257 210 211 216 248 324 255 252 214 217
   220 223 210 199 221 217 215 194 144 140 134 138 134 159 314 259 249 247 247
   244 235 250 254 273 262 281 297 320 320 265 141 137 135 134 146 138 134 178
   136 135 194 135 134 158 231 133 137 132 255 145 137 137 135 135 236 217 227
   226 221 188 196 191 218 190 196 219 216 204 199 217 215 229 215 173 224 191
   209 200 257 241 216 240 212 215 224 216 218 218 217 193 214 183 219 214 217
   215 188 215 216 216 218 195 243 221 221 216 221 210 275 212 221 247 224 220
   185 218 221 188 193 210 184 207 201 183 205 194 230 201 189 215 199 205 221
   213 189 202 214 199 193 190 204 196 234 213 237 236 192 207 243 252 225 224
   202 220 194 258 197 193 206 205 195 193 197 186 184 206 203 184 216 184 222
   217 211 207 211 224 213 217 223 211 198 259 233 228 224 217 216 217 219 218
   216 215 215 215 214 214 216 210 196 221 247 215 215 208 219 196 214 198 214
   192 215 218 222 216 212 190 200 218 228 234 219 216 215 208 213 220 214 212
   215 212 212 191 213 206 215 230 274 259 209 220 217 351 217 220 214 221 223
   221 215 215 213 228 218 207 219 218 220 219 223 228 225 209 217 244 229 226
   222 217 205 221 218 211 224 219 219 208 178 219 142 135 135 167 136 135 161
   136 195 138 152 166 170 187 138 131 133 147 137 131 131 133 131 131 132 132
   134 138 159 135 168 289 360 338 200 189 268 229 218 227 221 221 223 245 192
   206 215 198 229 226 224 207 209 193 222 203 227 220 222 217 213 215 208 201
   212 215 223 1571 215 178 210 210 208 200 211 210 236 215 216 198 180 234 243
   198 214 217 248 221 243 219 256 225 207 212 186 214 214 206 211 216 208 214
   207 192 154 129 143 130 139 137 137 163 147 133 128 129 132 221 171 134 128
   129 151 155 237 226 250 147 129 128 127 128 129 133 126 128 130 129 128 127
   127 127 127 127 128 127 128 128 127 128 138 128 129 128 127 138 141 139 192
   134 163 130 200 132 131 130 195 193 213 223 216 228 199 231 215 163 192 187
   201 208 217 213 210 211 180 199 201 164 139 131 132 126 130 131 129 130 130
   113 145 164 133 130 129 129 107 128 138 139 140 154 147 157 131 130 219 138
   129 157 207 212 234 345 394 183 218 207 219 188 233 211 204 206 198 264 187
   189 235 217 216 215 215 215 215 213 214 213 213 213 216 213 214 214 213 214
   212 220 233 225 222 224 205 187 181 205 223 218 214 214 185 226 220 218 215
   214 214 214 215 212 215 220 218 214 213 213 213 214 211 228 235 211 223 213
   216 218 212 221 214 214 213 217 218 171 222 214 209 207 225 218 219 223 227
   230 225 221 208 224 220 211 217 212 223 214 212 212 212 213 212 213 211 211
   225 201 220 213 215 183 201 187 210 193 216 133 130 130 131 128 129 128 127
   133 127 128 127 127 127 127 123 138 129 127 128 128 128 128 129 130 128 128
   128 128 127 128 129 128 151 208 179 225 219 216 214 220 219 215 213 218 214
   206 222 217 218 220 191 188 212 224 213 187 212 212 213 212 215 214 214 215
   223 211 213 219 214 213 212 213 212 213 216 208 213 233 217 195 187 222 219
   167 219 212 207 211 213 217 216 203 212 213 213 221 219 217 218 216 223 217
   220 216 217 222 235 213 220 220 217 189 223 217 218 224 217 220 230 221 220
   216 189 222 205 218 216 194 213 214 213 214 213 213 213 220 214 191 213 210
   212 214 215 213 213 214 217 214 196 218 215 219 178 205 213 208 197 137 132
   129 146 139 139 129 130 136 149 130 127 128 128 128 128 129 130 124 128 128
   128 128 128 129 127 128 127 128 128 146 134 132 226 232 227 220 216 171 214
   215 214 212 214 195 221 218 228 212 209 213 220 210 216 202 214 217 213 213
   212 212 212 212 214 216 215 211 212 212 212 213 230 181 215 214 217 222 216
   216 218 212 207 186 216 220 216 210 221 214 215 218 212 216 213 216 213 212
   213 213 213 213 215 213 214 214 214 210 225 224 225 218 225 218 223 220 208
   207 213 216 224 218 211 215 210 215 215 196 213 182 214 212 211 213 211 212
   215 216 184 212 235 218 212 212 216 211 213 205 209 212 219 216 227 257 335
   249 219 210 223 209 196 280 239 255 288 262 296 360 301 268 276 272))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 221414 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61633936 :P50-TICKS 215 :P99-TICKS 277
 :LATENCY-TICKS
 #(291 298 238 251 268 267 268 244 286 235 220 284 293 264 263 236 255 266 256
   270 240 224 259 256 252 247 243 245 264 217 276 229 266 273 275 254 263 256
   277 254 313 295 288 220 258 260 282 277 246 243 269 248 246 263 224 222 216
   193 210 224 188 219 206 191 208 199 199 215 207 170 218 222 219 217 214 200
   181 208 184 218 218 184 189 225 201 219 215 212 213 208 212 212 190 212 210
   199 211 212 204 213 210 211 199 214 213 213 214 214 217 214 216 213 243 247
   215 219 212 224 218 217 215 212 210 215 220 213 211 211 212 209 216 221 137
   211 209 222 218 211 194 223 214 217 215 217 214 214 212 212 223 216 213 220
   188 214 213 214 196 212 211 221 219 201 217 200 216 216 212 206 216 214 214
   215 229 223 214 216 223 220 220 213 195 213 215 217 213 213 212 213 220 216
   225 217 212 212 210 212 213 210 212 215 212 215 213 218 216 219 225 196 211
   207 221 218 205 209 215 214 223 216 213 213 215 217 213 213 212 213 216 212
   213 213 212 217 220 220 221 203 234 226 216 214 217 216 214 214 215 213 213
   221 199 215 213 215 219 213 214 216 214 214 213 214 214 213 215 212 212 213
   213 213 213 214 213 213 219 225 214 209 217 219 213 213 215 213 217 202 219
   218 207 213 201 209 213 209 210 213 209 208 209 212 209 209 209 209 210 215
   218 210 218 222 228 215 212 209 209 192 209 195 209 209 210 218 214 223 215
   213 220 216 194 214 217 215 217 217 205 212 216 213 218 215 214 214 214 215
   215 214 216 218 213 216 209 202 225 230 168 206 225 207 208 217 214 210 211
   208 176 218 212 213 211 203 209 210 208 209 209 211 210 209 213 189 209 210
   228 216 226 215 216 215 220 214 212 212 213 212 219 221 214 212 213 215 210
   209 210 207 208 210 210 215 204 204 207 207 208 208 209 208 209 209 208 219
   202 218 212 214 210 158 213 206 215 226 221 213 210 221 208 221 218 217 224
   207 217 214 247 222 211 221 221 213 216 214 219 212 213 207 207 222 219 166
   215 218 217 218 214 216 215 223 199 210 209 214 214 211 197 209 209 211 209
   210 210 209 210 212 216 221 218 215 215 213 213 214 214 214 226 214 213 213
   216 227 224 213 215 215 222 211 212 217 276 225 216 214 213 216 219 200 217
   213 213 214 214 217 215 213 213 215 215 220 220 222 223 214 220 218 219 215
   214 209 204 227 178 224 215 215 219 220 213 215 213 214 188 213 215 213 218
   217 216 217 214 215 215 215 214 214 213 221 213 213 220 220 217 225 222 157
   222 214 214 215 213 219 214 216 215 220 218 222 217 214 213 209 212 213 214
   213 225 217 215 214 213 218 222 218 207 210 208 212 213 210 209 212 209 215
   213 221 216 213 218 191 215 215 214 214 212 202 213 213 218 220 209 217 214
   213 211 208 214 215 214 223 218 218 218 219 221 216 223 208 215 219 218 216
   220 223 214 223 193 222 220 223 218 214 221 217 193 217 218 217 219 208 187
   217 217 223 225 226 225 219 218 212 218 219 217 223 219 232 222 218 219 219
   218 216 215 216 214 218 214 214 215 219 216 215 215 214 214 215 214 214 214
   216 222 214 214 213 216 172 218 216 217 208 199 214 204 192 208 216 215 206
   212 210 213 212 207 216 214 216 216 216 214 215 215 219 216 217 215 215 214
   227 208 230 235 236 215 218 221 218 225 220 217 231 232 227 219 208 217 214
   215 213 218 215 214 223 215 192 213 214 216 215 216 214 214 219 213 213 215
   214 214 214 226 216 226 246 185 230 221 216 222 220 218 221 200 220 216 225
   215 217 218 217 217 217 216 224 209 213 215 216 214 220 212 224 225 223 211
   210 217 210 209 211 206 202 219 219 218 218 218 224 225 214 216 217 220 218
   215 218 219 215 214 216 214 216 219 214 214 214 215 215 215 214 226 222 191
   199 223 215 219 223 222 221 225 229 206 148 225 202 218 220 209 221 218 215
   155 216 211 214 207 210 214 210 212 214 197 221 212 211 214 219 211 210 212
   210 221 217 215 212 196 216 226 216 214 217 218 211 216 217 216 214 230 223
   229 214 219 218 214 215 220 215 215 222 216 215 217 210 215 215 216 217 218
   214 216 214 205 184 219 213 215 215 214 207 219 219 222 206 207 223 213 218
   222 212 216 208 217 215 218 206 211 202 211 213 211 211 212 215 223 214 211
   212 211 209 209 211 211 232 203 208 237 231 219 215 225 210 219 217 208 216
   216 229 216 223 210 213 207 212 217 206 211 214 211 208 211 211 210 211 211
   217 212 207 217 197 212 209 211 212 211 207 213 211 213 212 216 217))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 215534 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61573872 :P50-TICKS 215 :P99-TICKS 235
 :LATENCY-TICKS
 #(227 217 196 224 220 223 190 215 214 209 220 215 144 164 193 213 211 218 170
   216 219 213 211 211 210 212 211 211 212 222 211 200 222 232 216 213 222 219
   214 214 204 193 216 234 216 222 216 221 225 219 225 210 217 215 219 219 221
   225 220 213 218 189 215 215 214 216 216 213 213 216 218 224 217 215 220 221
   217 223 214 167 180 229 219 181 188 218 220 203 195 216 218 221 218 221 190
   223 215 216 223 217 216 218 222 215 215 216 214 216 212 214 219 223 222 214
   206 212 217 207 216 212 210 214 213 216 214 221 215 215 222 218 214 221 222
   214 215 221 225 214 215 214 219 218 224 225 215 222 216 218 216 217 214 218
   220 216 221 213 1665 227 222 214 224 220 216 220 223 215 221 216 213 216 216
   214 214 224 219 215 220 219 214 214 216 199 225 183 221 220 220 217 218 224
   224 225 213 220 220 228 213 230 224 215 215 210 215 210 216 198 220 213 216
   216 214 215 215 214 215 217 216 221 215 216 209 219 217 216 216 220 218 220
   232 189 216 220 204 217 181 217 215 217 215 211 213 229 206 215 167 185 215
   214 215 212 223 206 186 216 217 213 215 211 225 194 213 211 215 212 215 214
   206 208 219 228 243 214 211 212 221 212 212 226 219 210 211 212 220 211 211
   215 211 209 224 218 203 224 219 217 179 213 210 211 217 219 210 213 211 213
   212 217 210 212 207 220 221 211 215 216 217 204 221 211 220 208 169 221 214
   212 209 213 223 215 187 215 222 216 206 225 221 219 210 211 219 213 212 221
   210 200 210 209 212 211 211 207 211 216 211 211 209 212 213 212 212 211 211
   213 217 214 218 211 216 219 219 204 218 180 229 220 208 187 221 233 208 216
   206 199 215 217 227 215 211 219 212 189 203 214 219 214 216 211 206 217 210
   211 204 227 203 208 217 222 215 214 221 205 225 204 173 202 239 224 228 221
   223 229 217 231 164 236 210 217 219 218 215 216 216 215 216 220 217 199 214
   214 216 215 215 215 215 215 219 215 221 220 231 245 220 200 268 212 206 218
   222 206 218 217 217 225 218 222 202 215 216 215 215 215 211 215 214 217 218
   221 220 217 222 226 212 224 225 203 219 207 221 209 214 217 214 215 234 216
   224 218 216 212 217 219 214 216 219 215 220 216 215 215 214 214 217 215 216
   214 217 209 215 216 218 215 216 217 215 215 216 219 221 222 218 216 178 199
   214 215 207 225 222 209 218 210 210 215 212 211 213 221 208 225 226 212 182
   216 211 203 214 215 216 215 215 211 210 221 220 219 220 217 219 217 216 215
   193 214 217 227 221 211 210 212 221 201 136 213 213 211 211 211 212 218 212
   211 211 210 211 210 212 212 212 210 211 211 211 211 211 210 215 212 218 221
   217 222 165 192 210 215 203 181 224 223 214 220 195 208 224 217 214 217 216
   215 222 224 206 217 214 215 216 215 215 215 219 213 226 179 218 205 216 216
   223 216 215 216 214 214 226 221 219 215 227 216 217 211 216 225 209 213 215
   218 215 212 214 216 212 214 213 216 214 214 214 215 214 220 214 214 206 218
   211 224 219 219 221 189 211 171 225 218 215 167 220 210 217 216 215 211 211
   212 209 211 215 210 210 208 211 219 208 225 181 217 222 225 220 174 220 221
   207 214 221 217 206 215 217 216 214 226 220 209 216 211 218 212 212 202 214
   212 210 210 212 215 217 213 210 212 211 210 216 218 201 207 222 219 212 216
   210 210 220 212 211 214 223 225 215 223 209 214 206 223 219 218 216 214 221
   217 214 216 226 240 214 214 221 218 215 215 213 213 219 219 215 213 208 167
   220 223 217 210 213 215 219 210 211 202 215 213 211 230 217 224 217 198 220
   218 219 217 213 216 215 220 213 208 215 208 212 215 214 215 213 213 221 219
   214 217 187 194 236 188 152 243 231 235 231 240 222 172 226 231 227 226 230
   215 217 217 206 218 201 204 235 212 213 191 223 217 218 215 215 214 214 216
   218 141 134 133 132 143 132 138 132 140 141 163 145 132 129 129 136 131 146
   132 130 129 130 131 131 127 129 146 181 135 128 145 139 131 130 132 131 138
   135 135 137 131 131 133 135 132 131 131 132 133 132 130 131 131 132 130 133
   130 147 134 131 131 130 135 133 137 221 218 214 219 215 217 215 215 202 219
   219 222 222 208 203 215 204 222 217 217 221 227 217 216 218 214 216 203 214
   215 215 223 207 214 214 219 215 215 214 207 219 218 217 198 227 226 205 208
   211 203 216 221 198 213 212 212 224 218 205 216 215 215 218 212 215 217 219
   214 213 216 215 208 214 214 213 214 214 214 213 215 214 219 221 214))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 233088 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61573920 :P50-TICKS 226 :P99-TICKS 278
 :LATENCY-TICKS
 #(167 171 195 203 224 217 220 219 234 202 212 192 192 188 190 195 190 197 194
   286 282 285 282 280 278 283 257 251 254 254 252 255 256 253 253 276 354 302
   260 249 245 259 245 263 250 245 233 229 230 234 239 229 180 231 227 225 225
   227 229 227 228 230 237 237 233 233 235 160 227 230 236 227 272 236 236 238
   233 240 229 181 226 230 231 227 236 230 235 229 225 226 227 226 229 234 229
   228 226 215 228 228 226 232 226 223 224 229 232 226 256 229 230 241 221 226
   225 240 229 233 225 227 224 224 227 225 228 225 225 223 224 226 219 224 230
   225 226 223 221 224 225 226 218 224 227 231 182 207 235 233 219 235 219 224
   228 229 231 232 236 226 228 187 222 232 225 224 226 224 220 224 221 227 221
   224 220 225 228 213 208 225 226 222 221 225 220 219 216 224 223 189 229 211
   225 233 275 261 236 222 254 237 244 237 226 226 228 225 250 213 224 229 233
   227 213 227 226 226 226 232 223 233 239 236 225 221 235 226 229 233 234 233
   229 230 226 228 215 237 228 231 238 233 227 227 239 231 229 202 244 228 228
   223 223 227 225 221 226 226 224 225 230 227 225 223 225 227 227 228 229 244
   236 227 193 240 231 225 231 228 227 228 226 221 226 224 222 221 222 220 222
   227 223 220 224 222 221 220 226 225 219 230 216 230 230 225 229 236 228 228
   225 234 234 229 224 241 231 231 201 225 228 224 222 224 224 224 219 222 222
   218 224 221 219 221 212 210 234 230 144 224 223 224 222 225 223 220 221 228
   228 225 241 226 224 230 226 199 224 234 234 227 225 221 222 228 225 220 221
   220 222 223 230 217 224 219 228 222 220 219 223 231 226 234 190 234 232 231
   225 228 225 230 227 227 230 215 231 235 226 223 227 234 228 226 228 227 227
   224 223 223 232 224 226 226 223 225 224 226 225 223 227 224 224 223 224 220
   233 230 243 230 196 227 204 218 232 230 244 233 225 227 229 227 227 226 235
   228 224 226 225 229 229 224 222 223 226 226 224 227 245 225 202 229 235 224
   222 210 225 224 215 211 215 216 227 216 240 224 224 232 231 228 231 228 224
   221 226 227 220 221 186 224 222 220 223 227 219 223 218 224 226 220 220 221
   217 222 223 229 226 188 229 236 235 226 230 234 228 226 230 227 231 227 225
   226 229 225 226 226 225 234 226 227 225 218 223 226 228 225 179 238 234 225
   214 238 231 225 227 227 227 245 234 228 225 223 243 226 230 226 231 224 196
   226 227 232 225 226 228 219 232 223 222 225 226 221 217 225 226 224 214 221
   229 229 235 230 216 218 211 216 200 233 227 228 228 225 225 226 226 225 229
   223 223 224 222 226 224 224 224 226 224 225 225 222 202 229 227 225 221 225
   214 222 221 221 220 224 232 229 234 226 225 204 225 224 227 225 223 227 227
   233 233 228 226 233 231 225 226 221 225 238 224 223 231 229 225 222 233 228
   222 230 227 320 220 209 222 237 236 218 227 221 227 213 223 221 219 221 220
   227 245 218 202 223 227 221 220 225 198 164 242 222 215 232 229 225 225 226
   224 231 207 222 233 234 243 229 226 232 226 227 220 227 226 223 223 225 223
   228 222 229 226 222 225 229 217 223 222 224 222 220 222 199 228 224 199 231
   229 185 177 181 223 212 226 218 225 225 225 225 229 231 223 228 225 224 225
   227 227 226 224 231 225 224 229 229 226 229 227 232 232 224 220 222 228 223
   220 222 220 225 233 236 224 227 231 229 223 224 225 224 228 223 223 226 233
   229 225 225 225 229 227 227 229 224 235 228 227 225 216 223 230 228 232 233
   223 233 229 232 232 223 226 172 220 226 226 236 228 225 230 238 229 231 223
   227 232 232 223 228 231 226 227 239 2136 228 236 235 232 236 227 231 237 224
   226 227 224 224 223 230 224 227 225 226 224 223 226 230 232 223 232 232 226
   222 224 232 216 224 244 223 212 236 228 221 201 189 234 232 238 231 219 224
   213 221 222 216 225 220 220 220 228 221 224 224 225 220 236 219 221 222 224
   226 227 205 219 233 225 219 211 224 219 221 220 222 225 223 239 228 199 228
   224 225 225 223 224 226 224 224 228 216 224 224 227 228 225 226 224 224 226
   226 225 226 223 224 225 233 229 230 237 232 229 235 215 230 231 226 231 217
   217 232 226 227 225 222 225 225 225 222 226 229 229 223 223 224 224 223 212
   208 228 228 238 223 221 229 218 221 223 223 215 232 191 242 221 223 211 228
   224 216 226 225 218 227 225 223 224 227 229 229 227 225 225 225 224 225 222
   223 226 229 223 231 228 235 233 165 196 240 220 193 235 233 223 210))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 221797 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61633888 :P50-TICKS 221 :P99-TICKS 240
 :LATENCY-TICKS
 #(228 225 221 222 225 223 223 226 224 228 230 221 215 225 225 232 218 217 232
   225 230 234 226 226 223 226 224 235 214 231 222 225 230 225 226 224 224 227
   224 178 224 225 231 226 224 229 225 224 223 234 225 222 223 229 218 226 213
   240 231 222 232 228 230 222 148 178 235 227 223 234 228 227 225 230 229 231
   230 229 227 225 227 227 224 224 225 225 226 229 223 227 225 229 233 175 233
   228 222 222 233 220 218 220 226 224 234 224 238 218 224 226 227 224 222 225
   228 223 224 228 225 227 222 225 225 225 223 226 232 226 220 229 227 224 223
   227 226 232 226 235 206 228 230 229 186 227 224 296 234 228 228 338 213 266
   232 234 221 231 219 230 227 225 222 225 226 225 151 148 146 153 155 148 156
   142 140 142 141 142 141 143 145 143 144 140 145 136 141 193 147 172 141 144
   143 142 139 148 228 222 216 227 222 222 223 224 219 225 221 220 218 218 218
   221 220 220 221 235 227 212 212 222 222 226 177 216 223 230 221 182 196 235
   219 214 227 226 228 204 228 221 228 207 215 221 217 221 215 221 229 223 220
   222 219 221 220 219 225 229 234 226 225 220 223 222 224 232 223 213 226 224
   227 238 233 224 227 217 227 231 225 226 225 227 228 223 225 227 225 228 229
   226 227 236 203 196 233 222 224 230 224 215 226 227 232 212 237 177 201 218
   233 227 225 227 223 230 224 222 226 225 224 221 225 224 223 227 225 227 228
   223 223 213 225 225 221 232 212 223 235 214 222 217 232 223 225 225 225 225
   240 208 225 224 222 224 223 222 211 224 197 213 216 219 219 201 220 221 220
   221 226 219 219 221 221 222 218 222 220 220 225 212 224 214 234 234 162 210
   236 225 213 230 225 212 235 220 227 231 196 225 163 142 141 138 146 147 142
   141 139 140 142 142 164 147 143 148 139 140 147 139 146 146 148 149 143 159
   155 140 139 140 173 220 225 219 225 220 226 237 229 224 227 223 226 225 224
   212 222 224 221 226 224 216 222 224 223 224 222 223 224 223 223 226 227 222
   224 223 226 226 227 230 238 203 232 230 223 223 225 209 213 226 229 229 235
   234 226 224 201 225 223 229 224 221 223 214 224 223 222 226 234 231 231 233
   223 226 227 225 228 223 225 230 240 226 222 188 225 204 221 222 220 228 221
   222 195 219 219 221 219 218 220 225 221 233 226 206 209 215 217 229 230 218
   226 232 231 252 205 246 218 192 245 217 225 231 225 204 226 214 225 225 225
   219 218 222 220 218 221 223 219 219 225 222 222 218 222 221 219 229 217 201
   225 232 230 231 225 230 194 219 224 222 233 239 230 220 223 220 227 221 221
   224 228 224 226 222 212 225 196 217 220 221 223 220 221 217 220 222 220 219
   218 222 233 219 224 216 223 230 238 230 243 226 233 226 227 232 225 225 235
   231 225 231 235 227 220 226 226 222 241 219 232 231 217 234 239 228 250 237
   210 230 228 224 233 227 226 230 229 232 235 235 230 222 215 218 222 224 224
   225 225 230 226 219 223 219 222 217 217 216 218 188 193 215 215 217 217 206
   217 217 218 221 207 220 224 187 226 214 215 222 219 219 226 222 220 225 216
   219 218 220 211 217 225 219 217 220 217 219 220 217 220 220 227 204 224 226
   223 214 213 221 219 214 217 214 215 210 222 225 219 218 218 219 225 204 218
   219 218 219 216 220 220 217 227 213 216 227 217 196 217 209 217 220 219 225
   217 220 224 221 219 229 176 211 203 231 210 215 216 215 210 217 215 221 219
   221 203 204 216 216 216 206 231 217 189 218 218 221 217 217 222 218 201 200
   224 228 209 216 225 215 216 218 216 216 214 220 226 215 217 219 215 213 213
   218 213 211 218 215 222 216 214 216 215 213 215 215 216 212 209 213 215 212
   214 215 214 216 200 220 218 199 225 210 196 192 220 219 219 213 215 223 219
   216 218 220 223 209 216 227 217 169 235 244 219 218 225 213 219 225 215 210
   214 216 221 217 214 215 218 216 210 212 214 220 210 220 223 219 206 220 218
   221 216 216 219 217 218 216 219 216 215 216 215 218 213 214 217 219 217 220
   214 215 219 215 219 222 218 226 222 177 214 222 197 223 214 218 217 225 219
   215 223 215 215 214 211 215 226 215 224 204 222 214 218 219 215 213 214 222
   220 222 225 209 227 219 218 225 218 219 216 220 225 225 224 224 218 212 222
   217 218 216 214 218 230 221 198 223 217 216 218 206 228 224 221 227 215 188
   222 218 217 216 223 222 221 223 215 215 185 202 218 222 226 219 217 226 216
   219 216 224 219 216 224 198 218 215 216 218 219 216 218 217 221 223))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 219557 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61573872 :P50-TICKS 217 :P99-TICKS 233
 :LATENCY-TICKS
 #(217 207 224 215 221 218 220 212 212 208 215 205 212 222 220 227 209 217 211
   215 217 218 217 215 199 224 213 197 219 219 217 217 218 215 216 222 217 217
   223 224 206 217 225 221 221 227 226 235 151 223 220 206 220 219 219 215 217
   215 214 220 214 214 213 213 213 219 215 211 213 215 213 213 212 214 214 212
   215 214 225 219 226 215 213 212 220 214 216 214 217 208 230 217 214 216 217
   213 215 213 214 215 214 209 211 214 215 217 211 213 215 204 214 214 212 214
   214 213 216 180 222 207 214 215 224 214 197 222 202 210 214 223 224 205 222
   222 218 225 221 224 220 218 218 218 218 219 215 219 218 220 219 218 218 199
   216 218 218 150 216 221 207 222 217 211 216 224 204 217 218 217 219 223 214
   214 214 215 219 217 213 215 217 213 215 217 213 204 186 226 216 214 220 213
   213 214 213 214 214 212 214 216 215 219 208 217 216 228 219 222 219 216 208
   185 228 219 220 223 217 216 224 218 218 218 217 217 217 218 214 218 219 215
   217 208 217 216 216 209 210 216 223 212 220 208 213 225 220 209 216 223 216
   225 220 224 141 212 220 215 211 213 214 214 213 212 221 210 213 215 213 214
   216 215 213 217 221 213 213 214 213 212 212 214 214 215 222 233 225 210 214
   220 210 167 201 223 219 217 216 214 217 213 214 214 215 212 214 219 214 220
   214 215 214 212 215 214 213 217 203 211 221 214 215 205 212 221 212 218 214
   211 215 219 221 223 218 219 220 219 223 217 211 217 216 219 218 215 217 217
   220 216 217 218 218 216 216 217 219 217 218 216 217 203 221 220 225 221 211
   197 213 219 238 218 220 225 217 216 221 216 221 187 211 217 215 218 217 209
   217 219 221 217 217 216 219 225 205 219 223 216 218 212 220 215 217 215 221
   223 220 213 220 216 222 213 212 213 210 215 223 211 217 220 217 204 210 227
   229 182 198 220 217 215 212 219 209 212 214 213 212 218 219 238 230 180 191
   160 195 215 222 225 224 216 220 199 222 218 212 213 214 211 209 215 216 208
   213 216 214 212 213 214 213 212 224 217 190 221 224 214 218 226 216 188 223
   214 222 228 196 176 211 218 221 211 213 216 214 209 211 214 215 212 212 216
   213 216 211 213 213 212 213 214 216 212 217 218 217 216 210 218 217 224 203
   290 246 222 222 229 233 218 212 219 218 223 218 223 215 192 214 215 219 216
   220 219 218 225 214 219 218 215 224 208 195 220 154 216 217 220 197 212 213
   210 211 215 220 213 231 219 217 221 223 1625 225 216 219 218 219 217 216 223
   221 216 217 217 223 206 217 218 217 221 224 210 226 207 186 226 230 207 154
   232 224 219 217 215 216 214 220 219 213 215 217 212 214 211 214 214 213 213
   213 214 218 216 214 224 174 209 218 221 217 221 219 220 218 217 216 216 227
   207 223 219 217 221 214 212 217 216 218 220 217 217 212 227 220 218 217 218
   216 217 215 218 231 237 220 217 215 221 221 219 225 224 187 182 211 214 219
   219 211 212 222 217 216 222 218 218 216 217 220 215 219 217 217 221 224 218
   220 217 217 224 218 224 217 178 225 224 217 224 216 217 217 211 219 224 203
   223 212 219 227 216 212 218 215 217 218 217 217 216 223 183 220 217 218 222
   213 215 217 218 216 219 217 219 225 216 214 220 225 229 224 238 198 211 225
   230 225 220 219 218 219 216 218 218 217 222 221 212 216 206 221 219 216 216
   225 217 222 210 220 221 178 214 227 215 214 212 218 219 217 215 214 226 225
   221 218 213 218 220 217 216 217 215 217 219 216 219 215 218 218 217 223 222
   217 229 219 219 210 225 217 218 217 221 242 218 219 213 220 231 210 223 218
   218 213 222 214 221 219 142 137 134 133 137 134 136 129 116 170 136 136 128
   129 134 136 136 129 130 130 132 129 135 134 133 130 133 130 132 148 134 128
   157 220 231 212 216 215 221 196 218 216 219 222 200 216 218 216 224 217 218
   215 214 219 213 208 215 214 214 222 215 214 220 205 187 211 214 218 212 214
   213 208 212 214 213 215 215 212 215 214 202 211 217 218 218 220 210 170 226
   217 205 213 216 214 222 210 222 217 226 219 216 218 217 216 195 216 217 221
   214 217 216 215 216 215 224 217 223 214 226 220 199 179 213 216 211 215 208
   213 213 216 229 213 226 223 219 221 226 217 218 226 218 217 217 217 216 221
   219 217 215 217 218 216 216 214 220 221 215 200 219 217 220 219 228 226 218
   176 224 219 205 218 220 219 221 223 217 222 217 217 214 218 214 218 220 217
   216 219 205 218 215 217 217 216 219 219 186 208 214 220 219 213 221))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 212659 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61633840 :P50-TICKS 216 :P99-TICKS 253
 :LATENCY-TICKS
 #(196 219 225 215 216 224 220 217 215 217 223 213 217 217 215 215 213 218 221
   218 221 223 215 215 215 218 216 216 215 218 219 224 211 203 311 253 233 220
   223 215 223 215 218 217 226 218 210 211 219 217 224 224 190 219 217 220 216
   217 218 216 220 212 224 177 221 221 218 203 221 222 218 212 216 227 243 216
   218 211 215 213 212 217 213 211 213 212 213 208 215 213 213 218 214 214 213
   212 213 213 213 211 211 217 213 215 210 214 195 216 195 221 226 228 144 137
   150 147 143 136 140 134 134 137 136 135 134 152 140 143 133 134 134 146 134
   134 131 133 128 132 133 132 134 136 133 133 218 219 211 207 217 222 216 215
   217 221 181 211 225 229 215 218 225 218 210 214 224 201 200 223 226 214 219
   219 221 218 220 217 217 218 217 216 219 217 216 217 220 215 215 216 216 218
   216 218 216 217 219 239 216 186 217 223 220 223 143 197 221 209 159 212 222
   222 222 215 217 224 217 220 216 219 217 216 216 218 218 220 211 210 222 216
   217 219 216 218 168 223 223 215 217 225 216 217 215 219 214 221 222 208 223
   219 215 215 226 217 218 220 217 216 228 226 225 217 208 224 219 201 215 217
   222 191 218 220 217 217 204 220 224 217 219 204 225 221 225 224 221 184 215
   210 216 218 212 211 213 213 213 213 213 214 212 217 214 212 213 213 213 213
   210 213 194 221 170 222 218 216 215 221 216 214 216 225 215 228 194 215 214
   213 215 213 212 171 214 218 215 211 212 213 212 213 212 213 218 205 214 213
   212 212 212 212 212 208 213 216 211 185 215 216 222 223 225 232 197 270 217
   221 220 189 220 218 220 221 215 222 217 218 213 217 217 215 215 219 218 219
   216 218 217 217 203 230 218 222 226 222 216 223 215 218 212 215 217 225 220
   221 216 217 222 215 217 217 217 215 214 227 220 214 216 221 216 209 214 215
   218 213 217 222 212 282 217 217 223 156 222 223 227 217 190 235 238 213 231
   257 194 224 223 219 219 216 217 219 216 217 215 232 214 216 220 204 216 217
   215 218 202 220 232 228 232 187 221 223 218 208 218 220 194 216 231 220 222
   224 224 214 215 214 218 217 214 211 214 213 213 213 212 213 218 212 213 215
   215 205 214 213 213 211 221 192 211 213 221 220 214 217 216 234 231 150 183
   316 244 182 221 217 222 225 214 218 225 221 218 218 214 212 220 224 224 217
   228 206 218 217 222 220 217 220 229 226 225 225 218 217 212 223 217 217 220
   221 221 222 225 215 215 227 222 217 220 217 219 204 216 222 185 196 206 216
   218 220 217 212 217 217 215 218 218 216 215 218 208 230 218 221 307 241 248
   224 211 156 158 151 139 133 131 134 145 143 135 136 136 132 138 136 138 133
   127 134 134 132 134 136 137 134 133 136 135 133 136 135 163 142 132 135 134
   132 134 137 132 143 138 141 146 151 154 156 139 133 132 136 134 144 134 139
   135 133 133 136 133 145 150 134 226 215 217 223 204 214 217 216 216 216 203
   219 217 227 217 226 223 222 214 217 220 221 217 190 217 218 222 218 217 214
   224 220 225 220 216 189 222 207 210 198 219 219 191 222 221 217 217 218 202
   218 216 202 223 218 217 217 217 215 215 215 219 218 216 227 218 221 210 214
   217 216 214 214 218 207 203 213 217 212 215 223 216 228 221 218 216 223 220
   217 228 217 216 219 224 210 216 217 216 217 209 215 218 217 220 216 216 217
   215 217 222 217 220 223 225 210 189 183 222 224 199 223 222 216 217 214 218
   219 215 211 208 212 212 214 221 212 213 214 213 214 211 214 214 212 218 214
   219 206 224 216 221 216 226 219 226 214 216 222 234 220 214 219 216 218 212
   223 205 215 224 222 224 216 215 217 222 215 220 217 217 217 214 219 217 215
   217 222 208 208 223 215 219 221 226 223 218 220 141 217 204 183 217 216 200
   223 216 219 200 223 217 216 216 223 219 220 220 220 228 230 217 217 216 220
   217 221 216 217 223 224 214 214 212 222 213 213 207 213 221 228 222 223 217
   217 225 218 215 221 224 217 217 218 215 217 215 216 216 216 225 217 216 216
   215 218 216 215 217 217 218 214 218 221 224 206 272 231 230 216 201 222 208
   224 217 217 219 216 204 215 220 214 216 217 216 216 214 218 217 218 222 217
   220 212 193 215 221 162 217 218 222 209 197 218 218 215 224 221 225 221 208
   222 218 216 218 216 218 216 216 217 217 221 219 201 221 239 179 261 198 214
   228 223 216 223 224 219 224 196 210 221 168 170 210 180 266 291 139 144 139
   130 178 141 148 134 136 138 135 136 134 135 136 129 130 135 134 135))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 223097 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61573872 :P50-TICKS 217 :P99-TICKS 237
 :LATENCY-TICKS
 #(218 221 217 210 217 201 216 224 198 201 221 223 224 216 213 213 223 210 210
   218 215 218 199 223 219 234 215 214 214 212 220 214 213 216 215 213 214 217
   216 213 206 208 214 213 214 220 212 213 233 202 212 211 214 214 212 213 215
   220 220 214 191 189 221 211 210 211 223 198 225 210 213 213 220 213 214 212
   212 214 213 218 207 215 215 212 214 213 213 214 211 214 223 210 222 218 219
   221 217 219 216 222 217 215 220 230 223 223 218 213 218 221 216 217 217 217
   214 216 217 216 217 221 216 217 220 212 216 217 219 216 214 222 215 214 217
   226 217 213 213 204 215 221 227 220 220 218 211 215 217 213 215 214 215 215
   212 213 213 212 214 213 214 218 221 200 215 212 212 215 226 225 219 211 221
   214 217 220 216 215 216 216 220 218 234 225 218 217 194 219 218 216 217 217
   225 217 214 217 217 216 219 217 211 216 220 215 219 216 218 213 217 217 217
   221 224 231 214 194 218 208 214 223 203 219 220 217 217 209 213 217 216 217
   218 217 216 220 216 216 217 216 215 214 216 216 215 221 219 221 221 233 222
   209 211 221 215 217 210 214 212 226 251 222 207 215 220 221 215 215 214 217
   216 214 217 216 214 224 215 217 216 214 217 217 215 216 211 225 220 215 216
   178 221 217 221 223 233 218 218 212 220 214 1605 226 218 216 215 217 216 216
   218 220 216 214 217 217 215 206 218 225 225 205 224 181 216 224 215 217 216
   215 208 225 188 210 213 215 220 210 220 215 214 213 218 215 214 211 213 214
   214 213 212 213 216 211 212 206 212 212 210 214 214 211 212 219 221 255 225
   219 224 217 194 221 206 282 224 219 217 219 216 219 217 215 216 226 212 217
   216 217 218 216 216 212 213 203 224 220 212 223 225 218 214 212 216 215 213
   212 212 221 222 223 218 220 216 227 224 220 215 219 228 218 219 217 214 224
   217 216 216 215 216 215 215 217 216 218 216 217 216 215 210 219 208 220 231
   217 221 226 212 225 224 229 229 211 221 225 220 221 221 218 221 219 221 219
   219 226 219 218 224 221 220 216 222 226 219 227 224 218 215 215 218 217 215
   212 214 221 229 225 220 218 243 208 218 217 219 221 213 219 217 215 217 160
   230 225 213 221 212 216 217 217 215 217 217 217 218 221 202 223 210 210 207
   217 160 226 186 228 230 221 221 217 217 220 216 217 215 215 218 216 217 217
   219 215 215 215 213 214 221 213 215 221 222 203 223 226 197 211 218 222 220
   217 216 224 223 223 224 217 225 215 213 214 215 216 218 215 216 214 216 216
   214 214 215 214 214 215 208 215 215 216 214 215 215 212 212 214 217 214 215
   225 214 152 193 220 216 216 209 205 219 217 219 213 221 213 209 218 211 213
   212 217 218 213 217 215 212 214 214 215 215 225 224 232 223 224 192 218 221
   212 218 218 218 217 231 222 226 217 218 226 211 220 225 218 214 216 218 218
   218 218 216 218 226 217 218 219 217 218 216 218 218 217 223 218 216 222 223
   225 230 208 224 213 212 211 199 216 223 211 217 227 222 212 223 218 218 217
   217 218 218 220 215 216 222 218 218 217 223 216 223 227 237 216 220 222 216
   212 215 218 207 220 221 244 203 228 220 204 194 214 216 209 216 215 213 219
   214 213 221 215 215 213 203 219 216 221 214 215 217 226 212 215 215 212 213
   223 215 167 217 226 231 203 212 204 220 221 223 227 195 216 218 219 217 218
   220 219 214 216 217 225 220 209 220 218 206 197 224 218 222 223 195 220 222
   216 218 217 219 216 214 216 220 222 232 222 220 218 217 217 220 213 220 206
   217 219 202 200 207 240 233 255 248 189 219 223 226 214 218 216 214 214 212
   217 215 213 218 216 216 201 216 226 220 232 225 211 216 221 214 216 219 220
   217 225 369 229 221 218 223 219 216 222 219 218 216 218 221 217 217 218 217
   217 223 230 224 226 226 223 206 216 214 222 213 215 214 216 218 218 224 217
   202 193 220 223 217 191 223 213 218 216 204 217 219 216 219 224 222 211 219
   219 217 217 186 216 218 215 217 212 202 211 160 226 220 224 204 230 220 204
   218 216 226 215 204 217 229 195 219 222 219 207 212 214 213 214 212 214 218
   211 213 215 213 213 212 218 212 218 205 214 217 222 220 218 224 210 217 216
   222 214 226 210 220 213 214 223 212 198 219 202 220 212 214 219 218 208 210
   214 215 214 213 215 214 213 216 214 214 213 215 213 213 213 223 216 210 218
   219 229 220 218 214 222 220 220 210 205 214 213 213 220 214 212 216 213 214
   221 206 216 217 210 216 215 214 214 212 221 215 208 211 224 228 223))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 236022 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61573856 :P50-TICKS 228 :P99-TICKS 278 :LATENCY-TICKS
 #(216 217 219 216 230 247 267 230 203 175 174 164 201 195 199 196 187 302 300
   291 284 282 286 282 208 255 253 252 251 252 252 253 253 352 330 250 248 246
   232 258 245 236 237 234 262 251 201 230 259 217 259 241 224 238 234 232 233
   233 234 224 234 230 230 228 226 230 231 228 229 235 226 230 236 234 244 232
   238 232 229 231 240 228 228 224 225 228 238 224 236 232 231 229 227 236 226
   227 230 230 236 227 226 234 231 227 225 227 229 242 243 203 229 229 228 227
   230 235 232 234 233 247 224 242 239 188 232 226 259 228 223 225 235 216 228
   229 227 227 206 228 227 228 227 226 229 226 225 228 236 240 233 234 235 225
   221 231 227 225 226 217 225 234 203 235 223 222 225 229 226 225 221 226 224
   223 224 227 222 224 222 226 223 223 224 223 219 223 234 196 209 270 234 226
   238 241 235 234 230 225 228 230 230 222 235 235 232 238 235 221 244 234 226
   227 233 204 235 233 207 228 226 227 226 223 229 228 225 225 225 219 232 235
   237 231 228 236 230 237 228 229 240 247 239 230 225 230 245 233 234 229 228
   231 228 228 229 227 245 234 235 229 231 230 233 225 229 238 233 228 229 230
   232 230 240 235 225 243 245 233 232 210 237 239 226 234 230 225 233 225 219
   224 224 223 224 225 234 223 222 224 223 225 222 224 227 246 230 236 230 235
   223 228 234 228 227 231 226 236 234 244 236 226 234 229 234 230 224 228 227
   225 225 226 226 226 231 228 228 225 228 228 229 226 228 233 230 225 231 226
   234 244 225 220 225 235 220 211 231 230 213 220 224 221 223 227 224 221 220
   223 222 224 227 227 225 227 219 225 221 220 227 229 231 229 217 236 232 229
   235 227 229 226 227 246 240 227 191 223 229 226 219 225 229 224 226 223 225
   233 201 210 222 217 243 258 278 232 215 238 233 224 226 226 224 228 230 224
   234 228 242 251 212 251 248 239 236 248 237 223 223 233 220 229 224 223 224
   226 223 224 223 226 224 227 224 219 223 224 221 224 222 223 224 248 238 226
   232 233 226 223 220 222 226 227 218 223 222 213 241 232 232 230 230 230 229
   226 224 226 225 226 227 228 228 226 226 225 225 226 221 230 226 228 226 225
   223 223 225 231 226 223 223 237 221 268 222 231 236 237 241 241 233 230 229
   229 226 223 225 225 223 223 229 228 224 217 225 226 219 223 235 225 225 239
   239 230 225 236 225 225 222 224 229 226 223 148 208 231 241 227 227 233 240
   240 232 229 231 231 228 228 229 235 226 229 227 226 229 227 227 227 224 233
   228 225 225 227 226 229 233 233 237 220 246 239 230 231 226 227 233 226 222
   232 215 225 220 225 222 222 226 224 226 225 224 232 223 223 223 224 230 236
   225 232 232 227 226 235 228 228 228 229 252 224 237 208 228 238 238 238 235
   237 221 226 224 224 223 227 225 226 190 227 225 223 226 228 227 225 223 225
   225 224 220 226 225 224 239 238 217 227 237 217 205 228 230 229 240 224 220
   232 228 223 225 225 228 227 223 229 230 233 231 229 228 227 223 224 238 234
   223 237 227 225 225 233 228 224 226 225 248 211 229 228 224 229 229 226 223
   225 228 227 220 222 221 226 223 222 221 224 228 218 224 222 222 221 223 222
   222 221 227 229 226 232 229 160 246 209 238 225 233 240 237 213 228 227 230
   230 225 230 228 229 227 227 229 229 226 226 223 231 231 226 232 235 234 229
   232 230 231 235 231 227 224 226 224 238 229 229 230 228 230 225 225 227 230
   224 227 227 234 231 226 229 228 226 227 228 226 232 227 223 226 225 227 220
   200 233 232 246 191 217 221 273 276 152 230 231 236 239 228 232 226 225 227
   225 226 224 232 227 227 226 223 227 233 222 223 236 209 231 237 236 229 228
   234 213 221 233 252 236 238 233 236 219 248 226 220 227 231 224 224 226 227
   223 219 224 224 226 227 229 209 265 233 212 213 221 212 229 223 221 224 223
   224 227 224 224 250 245 240 230 235 233 203 236 235 213 233 188 230 230 226
   228 228 233 228 226 229 222 224 227 226 225 225 228 225 229 226 226 226 228
   223 224 225 235 231 225 227 216 225 223 225 231 223 224 223 230 225 222 229
   230 229 228 234 228 241 238 230 226 229 232 226 217 224 230 231 226 229 224
   227 228 226 227 231 227 241 231 228 227 233 237 241 226 218 252 2057 235 229
   231 230 230 241 230 253 235 230 229 235 228 228 227 226 235 229 229 168 238
   235 228 227 232 225 229 228 229 242 236 236 229 228 235 227 226 227 225 230
   226 224 229 224 228 230 227 230 220 223 229 224 226 228 227 225 225))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 228354 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61633952 :P50-TICKS 225 :P99-TICKS 257 :LATENCY-TICKS
 #(232 240 238 241 235 231 204 232 237 236 233 224 227 235 224 233 230 225 232
   226 245 242 295 260 237 233 235 234 226 223 231 231 174 235 234 223 224 229
   225 228 229 230 223 215 234 220 234 228 225 235 228 224 228 224 226 227 223
   226 228 226 228 227 225 234 234 224 229 229 232 227 227 227 230 236 232 232
   230 226 234 239 185 240 262 235 237 257 235 228 232 227 228 219 151 146 143
   145 142 144 146 145 146 145 141 146 148 145 150 149 144 145 146 144 145 145
   144 168 151 162 156 154 149 233 227 225 234 227 232 231 225 214 243 236 231
   229 230 238 229 230 226 230 230 228 228 229 225 226 226 226 227 231 232 227
   223 201 226 224 227 225 226 211 231 226 239 221 187 216 245 247 230 239 231
   218 239 237 230 240 227 233 229 236 227 229 226 229 226 227 227 228 233 227
   209 232 223 235 235 226 225 227 227 215 201 187 230 233 233 240 228 227 222
   229 231 239 233 230 227 226 225 231 228 227 228 218 234 227 225 229 227 222
   230 207 224 228 228 229 233 228 232 234 233 237 228 230 230 230 234 239 209
   222 252 226 226 231 207 245 230 223 228 229 230 181 220 225 228 224 222 224
   236 234 229 237 235 234 226 242 231 233 233 223 229 232 229 230 231 223 222
   230 224 239 231 219 220 230 223 224 246 228 221 226 222 221 222 224 222 223
   225 222 225 225 222 225 225 224 224 226 241 229 215 177 223 233 234 232 241
   227 222 234 225 234 222 206 229 227 226 232 236 226 226 228 230 224 226 224
   225 231 236 233 231 235 223 225 222 228 233 227 232 222 219 239 224 233 226
   229 224 223 228 231 228 229 225 213 228 229 225 227 228 232 225 229 232 232
   227 231 229 229 223 233 226 227 230 248 226 176 210 231 225 224 187 236 229
   233 226 227 231 223 223 225 223 221 220 224 226 226 227 225 223 226 220 224
   224 223 232 228 232 229 225 228 236 225 229 227 230 227 228 237 232 222 223
   226 229 228 238 223 225 222 225 223 221 224 224 229 223 222 222 223 223 226
   223 223 220 225 227 223 223 218 178 264 246 245 228 232 227 231 233 253 232
   235 227 227 233 225 225 232 223 222 226 223 223 226 224 226 224 220 223 222
   222 222 226 230 237 233 234 208 228 219 237 227 227 228 232 240 232 230 226
   226 236 229 228 230 227 224 226 228 228 226 225 226 225 232 221 227 223 225
   228 229 227 225 226 229 226 225 234 231 228 241 227 222 236 202 230 230 229
   222 230 232 227 225 231 226 229 228 226 228 230 226 225 232 225 228 224 226
   229 226 229 235 231 204 224 229 237 223 228 230 225 226 240 233 235 225 226
   236 232 227 232 224 235 231 227 226 226 226 230 232 228 227 231 226 228 224
   227 225 225 226 226 231 232 228 225 231 215 225 232 195 235 240 240 241 221
   289 229 231 232 211 226 229 226 227 227 226 228 227 222 227 236 225 228 234
   229 228 239 229 224 221 226 226 222 221 224 225 228 195 240 229 230 235 232
   225 229 223 210 229 224 226 219 220 220 218 220 220 221 219 218 224 214 217
   218 223 228 226 218 227 216 221 226 205 194 289 268 323 220 241 396 268 224
   217 216 224 219 220 220 201 226 225 211 219 224 219 226 236 221 227 219 228
   228 227 224 224 224 222 225 220 220 223 220 230 227 219 216 215 238 227 209
   219 222 226 221 219 221 219 225 220 218 221 217 220 220 219 221 220 226 220
   216 231 230 218 219 220 218 209 223 220 219 164 227 231 226 219 197 230 224
   194 227 222 226 224 225 222 219 220 224 222 219 220 218 221 222 218 221 218
   225 219 219 221 220 219 227 227 219 173 219 226 180 218 227 221 220 221 215
   220 241 224 222 220 216 219 215 217 217 216 222 218 216 215 214 217 216 214
   214 217 215 220 213 217 216 212 216 216 215 215 212 221 224 218 218 220 223
   223 205 224 238 219 221 220 230 223 202 218 216 216 217 214 216 215 214 217
   218 214 215 220 217 223 214 218 216 213 216 209 226 206 222 227 221 219 225
   224 220 218 210 220 225 236 227 222 220 220 219 220 220 228 218 226 220 218
   217 220 219 220 220 219 228 224 212 220 221 221 220 219 218 218 219 221 221
   228 229 222 186 219 223 216 221 226 216 219 210 223 218 226 221 219 221 223
   218 219 218 220 222 224 216 221 222 211 218 222 209 221 217 165 224 221 215
   218 225 204 216 217 216 218 219 225 219 233 218 221 229 222 218 226 229 221
   211 217 243 221 198 221 226 218 218 221 219 224 217 221 216 219 219 220 218
   219 218 229 221 218 223 225 192 197 219 228 222 228 221 221 220 215))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 226362 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61573904 :P50-TICKS 220 :P99-TICKS 241 :LATENCY-TICKS
 #(215 223 221 214 216 215 217 215 214 215 217 219 215 218 223 181 233 227 221
   215 215 220 216 214 218 217 217 226 221 227 219 224 225 219 220 219 217 221
   219 220 217 224 218 217 219 219 217 218 216 219 218 222 221 219 217 222 217
   221 225 232 217 233 253 169 206 221 219 220 223 218 223 223 216 223 221 223
   219 219 219 219 220 227 220 215 218 220 219 218 217 218 222 216 192 221 207
   222 219 222 228 217 221 224 219 233 211 222 224 220 219 223 223 224 219 227
   227 220 218 208 222 200 197 231 222 225 217 220 219 220 219 221 219 223 220
   218 220 176 227 221 238 229 188 189 145 241 215 264 230 231 230 218 219 219
   220 219 218 215 220 218 221 216 215 220 223 180 215 213 215 222 218 216 215
   222 216 222 219 223 217 216 215 221 216 217 210 216 212 233 213 225 223 220
   221 220 219 226 215 217 220 220 219 218 216 220 222 217 220 219 218 219 217
   220 220 224 230 219 219 218 220 220 221 220 214 227 233 203 222 225 209 226
   218 217 203 222 228 228 226 219 219 226 219 218 218 220 215 223 219 219 219
   220 217 221 224 220 224 226 222 224 218 230 221 218 220 221 224 220 227 227
   229 220 219 223 219 223 226 219 220 218 220 219 219 218 217 220 230 216 219
   220 220 231 219 221 220 219 224 220 217 225 218 230 225 177 198 171 220 212
   223 226 223 220 220 219 222 218 221 219 218 217 218 224 223 220 218 219 221
   217 221 219 220 227 195 227 221 225 224 220 227 219 218 221 221 217 234 195
   226 219 218 226 223 232 222 193 222 219 221 221 219 217 218 218 220 221 219
   219 222 220 222 221 218 217 217 219 220 219 218 229 246 192 256 231 227 155
   201 222 220 231 219 220 231 221 221 219 219 219 204 222 223 220 217 220 220
   219 218 220 226 212 224 230 217 223 221 223 217 215 221 215 216 217 214 223
   239 219 233 223 221 230 219 220 227 220 220 221 220 219 227 222 218 219 228
   218 219 218 217 219 226 218 220 218 220 218 216 221 221 225 203 228 219 205
   217 213 221 225 221 216 225 215 214 223 218 215 219 218 218 220 221 215 215
   212 218 215 214 216 213 211 229 227 229 226 224 223 214 228 219 220 221 222
   212 211 223 229 225 220 228 221 228 219 219 219 219 217 219 219 219 220 220
   220 220 217 202 214 221 220 219 220 224 218 221 219 220 224 221 231 226 247
   218 225 224 231 221 226 224 219 216 227 216 217 221 218 217 222 221 218 226
   223 212 224 181 214 217 216 217 218 222 176 220 225 226 223 231 220 218 224
   211 216 231 227 224 217 214 222 219 223 211 221 219 220 216 212 228 213 215
   216 216 223 213 216 216 216 222 215 216 222 215 222 216 213 220 221 218 222
   223 204 192 211 213 220 223 221 210 217 217 214 218 223 209 189 240 226 218
   215 216 222 214 216 220 217 226 220 213 222 232 232 205 225 205 220 220 226
   219 219 217 220 221 221 228 231 222 220 218 224 213 218 218 225 212 219 221
   215 229 222 226 220 223 221 224 217 218 218 218 220 220 219 220 220 224 215
   219 222 221 226 217 215 229 178 223 185 239 223 220 218 224 216 220 1763 233
   220 220 228 220 217 219 219 217 219 222 232 220 223 230 218 217 210 219 219
   212 216 218 227 226 226 229 229 222 221 225 219 224 222 217 220 214 218 221
   222 219 219 220 216 220 217 222 220 220 219 218 220 224 215 218 220 218 221
   213 225 237 176 221 222 215 196 215 221 201 226 217 215 218 228 216 218 216
   214 216 217 214 219 213 218 213 215 216 237 259 233 235 223 203 225 220 232
   217 220 225 226 220 241 200 225 215 218 214 216 207 234 221 219 213 217 197
   220 218 226 218 217 216 218 209 220 219 216 216 216 217 219 224 238 220 221
   222 219 224 222 228 225 220 203 233 223 203 222 220 222 208 231 226 223 221
   220 218 222 220 217 226 222 219 222 225 220 219 218 219 219 219 218 217 228
   226 153 225 233 230 224 221 223 232 222 223 224 222 221 227 229 229 220 220
   220 226 234 225 220 219 218 219 218 217 218 221 218 217 215 218 219 219 216
   216 218 228 217 217 218 218 224 215 222 227 213 223 239 215 225 219 228 230
   218 224 215 223 223 220 225 229 223 218 222 223 224 220 219 224 218 220 220
   225 221 218 225 223 232 226 220 223 220 222 233 215 226 212 221 218 223 228
   219 225 214 222 219 222 224 217 220 221 217 220 220 221 224 222 221 220 220
   220 198 218 218 218 223 224 218 193 220 230 225 233 229 180 200 226 227 225
   218 222 219 220 223 220 226 220 219 241 232 211 219 212 200 244 225))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 219360 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61633840 :P50-TICKS 220 :P99-TICKS 241 :LATENCY-TICKS
 #(241 229 253 226 206 157 181 223 223 226 243 223 183 225 259 196 265 227 228
   227 208 217 226 216 224 231 221 223 223 221 219 205 166 226 223 219 217 225
   222 214 217 222 221 221 216 227 222 219 220 222 222 220 227 221 206 162 154
   150 158 146 149 140 142 143 140 161 147 140 148 151 143 138 138 142 139 146
   140 139 139 142 137 140 139 137 140 144 141 134 137 138 139 138 138 137 136
   138 136 141 140 136 147 146 139 162 150 142 144 137 134 140 134 149 138 134
   134 132 155 233 224 227 222 228 225 219 227 221 205 229 212 220 221 218 219
   220 222 219 224 219 221 217 224 220 219 219 218 223 224 218 220 219 212 220
   221 230 219 223 175 227 224 210 220 222 227 245 225 225 226 217 215 223 219
   211 220 220 221 218 245 226 220 213 228 218 220 223 160 229 224 222 221 221
   228 220 219 219 221 220 231 185 218 219 212 230 218 217 217 221 223 219 215
   219 217 214 216 218 216 217 217 223 215 218 218 218 216 218 215 219 221 220
   224 222 233 223 214 237 224 218 225 226 217 222 218 217 224 215 226 217 227
   217 212 218 221 221 216 217 215 217 223 211 221 213 225 195 226 190 200 226
   222 219 222 220 221 222 229 227 221 215 237 198 251 220 225 218 223 216 218
   217 225 226 222 218 218 224 220 212 215 215 222 222 211 216 216 174 216 218
   216 220 216 222 202 223 231 218 222 223 218 215 228 234 219 225 223 223 224
   219 220 220 223 224 216 221 220 219 215 221 221 219 229 224 218 227 207 218
   216 218 221 216 220 225 215 222 233 224 226 223 222 220 224 219 222 221 216
   220 219 220 219 219 222 222 218 222 218 217 217 219 219 218 223 223 221 220
   218 219 222 222 235 228 190 151 203 226 212 237 229 225 227 221 220 225 219
   220 218 221 220 218 222 220 225 226 218 219 218 219 221 218 228 167 169 229
   231 217 221 238 227 217 218 219 222 234 219 224 219 219 225 222 207 216 222
   228 220 220 216 219 220 217 219 216 219 228 217 219 222 203 221 222 220 219
   218 226 223 226 228 226 228 170 217 219 215 228 219 229 246 227 223 220 218
   222 219 225 219 218 218 216 219 224 225 226 221 223 219 244 235 229 222 164
   217 226 258 222 214 191 224 220 219 233 222 228 203 224 230 224 222 221 220
   222 221 225 223 222 223 222 225 219 213 221 223 226 224 220 219 221 210 225
   222 221 219 228 232 209 226 217 225 229 225 216 217 220 229 222 224 222 225
   219 218 220 220 218 224 223 219 220 220 218 220 219 220 222 226 222 220 200
   226 217 219 218 219 217 225 210 221 217 217 228 221 226 220 220 211 220 218
   221 222 220 217 219 222 218 225 228 219 220 218 220 220 226 226 219 224 221
   219 221 220 218 224 219 229 232 207 206 213 223 226 226 219 217 210 222 226
   220 225 220 219 219 217 221 218 224 218 213 218 220 218 220 219 217 224 229
   224 224 187 238 176 218 217 227 216 217 221 205 228 226 223 214 219 212 218
   221 229 205 222 221 221 220 218 220 220 218 227 226 227 219 216 206 219 221
   219 220 218 217 217 224 222 223 225 214 232 219 210 221 158 218 226 225 227
   221 159 225 230 224 223 221 185 194 221 221 227 220 223 232 219 218 218 221
   222 224 206 226 230 156 215 220 226 217 220 218 223 232 226 226 218 219 230
   211 217 219 218 218 219 222 219 219 218 194 217 219 231 226 198 220 217 224
   224 222 220 217 221 219 206 224 227 227 221 215 227 219 217 216 220 225 228
   201 206 218 212 190 221 218 220 232 222 215 222 216 215 218 217 214 216 223
   217 217 219 221 216 214 217 216 219 220 212 220 231 224 226 223 219 222 219
   224 209 219 223 227 222 224 219 219 222 221 222 218 223 219 218 229 221 217
   220 224 223 219 217 220 219 215 220 218 218 222 216 219 217 225 223 212 229
   229 218 213 193 234 200 215 224 225 196 224 221 225 220 217 220 221 216 219
   224 218 219 225 220 221 217 221 219 218 220 222 216 230 223 171 218 216 223
   217 215 215 216 223 219 216 225 223 220 218 217 221 219 223 220 220 219 219
   217 220 220 217 221 222 223 218 219 222 224 220 221 225 229 210 226 232 170
   223 223 224 221 220 220 183 233 168 239 210 227 227 221 221 219 219 232 240
   225 220 216 227 219 218 218 221 223 218 218 214 220 218 220 224 220 180 224
   225 222 218 226 219 226 215 218 223 225 223 225 220 220 221 209 218 212 217
   223 218 217 216 215 213 216 214 216 217 218 214 213 217 217 217 218 217 216
   215 212 219 221 227 206 217 177 219 217 219 193 137 134 136 139 146))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 222033 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61573856 :P50-TICKS 219 :P99-TICKS 247 :LATENCY-TICKS
 #(143 135 139 152 142 132 137 135 134 138 132 131 139 138 133 140 155 161 142
   212 247 179 211 222 217 225 236 224 222 226 220 221 220 222 225 221 221 220
   218 223 217 220 222 219 220 219 220 221 212 223 222 227 222 219 206 227 217
   221 222 223 229 233 221 222 205 220 222 217 216 224 211 216 215 216 217 216
   215 218 216 219 216 216 222 217 214 215 216 213 214 223 218 213 217 187 220
   216 223 220 215 196 228 225 211 212 215 223 222 225 219 226 220 213 219 221
   219 216 221 219 222 208 224 219 218 222 220 218 232 221 196 230 229 220 220
   227 221 210 218 220 220 240 227 224 223 309 241 229 221 218 220 221 217 214
   195 216 257 250 325 238 222 220 220 218 218 214 218 220 239 226 217 225 172
   231 225 221 193 221 213 224 186 152 149 151 146 150 138 139 135 131 153 145
   141 141 141 152 144 138 135 143 138 136 137 140 135 137 135 138 138 134 132
   171 225 218 217 220 217 218 220 224 219 222 219 220 182 220 219 222 224 217
   222 221 222 218 221 219 237 219 231 223 219 225 223 221 227 220 221 220 221
   217 219 225 226 205 222 220 219 221 217 220 222 222 224 220 219 219 218 224
   230 159 209 173 203 228 225 223 229 224 217 222 209 216 220 215 219 215 215
   217 216 215 212 216 221 206 213 217 218 214 215 216 218 221 171 224 220 196
   214 218 221 218 217 215 221 215 214 215 217 215 223 221 228 221 221 224 224
   217 219 214 221 218 220 222 225 213 223 219 221 212 198 165 219 218 221 226
   221 216 223 223 221 216 224 173 226 226 193 199 224 219 213 223 223 216 220
   225 218 215 222 214 220 220 219 220 222 225 216 218 227 218 207 230 248 228
   227 198 221 220 226 218 219 220 218 220 236 232 227 225 221 224 222 220 228
   227 220 220 226 222 219 221 218 274 228 219 225 218 217 221 220 223 218 219
   219 217 224 235 222 231 228 222 226 254 224 224 228 228 222 173 231 221 1566
   224 219 217 217 217 217 214 221 220 216 217 214 216 229 213 226 215 224 217
   215 219 225 214 214 215 214 214 229 223 229 223 222 220 227 219 224 219 228
   220 221 222 219 219 220 220 221 218 230 219 218 219 216 219 220 223 219 219
   223 224 216 232 223 220 226 223 222 218 209 201 223 217 221 220 219 229 219
   220 223 219 221 219 217 219 217 220 219 197 224 219 220 223 219 225 225 221
   225 222 226 223 214 216 216 215 214 228 224 221 221 221 227 218 220 216 220
   220 217 220 213 218 218 220 219 219 216 222 220 218 225 219 220 218 217 219
   220 221 221 228 232 220 209 223 230 221 223 221 178 225 225 220 224 218 220
   219 218 218 217 223 227 221 219 227 228 257 352 231 221 221 231 228 218 215
   217 219 216 213 218 215 217 219 219 162 231 220 217 225 219 218 219 219 220
   218 223 218 217 224 223 223 219 218 220 226 218 218 220 224 215 217 219 221
   225 221 217 226 220 217 170 192 219 186 221 225 219 224 223 228 223 223 222
   227 225 217 217 220 219 225 239 229 220 219 226 223 204 216 226 210 225 227
   221 221 221 219 216 221 219 219 217 223 227 221 219 230 226 218 215 224 219
   218 218 221 218 219 221 223 220 224 217 219 219 217 220 219 218 220 217 230
   224 210 225 217 179 214 221 211 209 231 223 226 216 220 230 234 225 218 235
   226 220 219 221 223 222 231 221 220 211 224 216 225 223 227 228 210 218 209
   221 221 220 217 219 227 226 223 215 207 216 218 219 216 215 219 212 183 217
   214 216 221 214 214 216 218 216 214 215 215 216 219 215 217 218 214 214 215
   218 220 218 231 235 197 204 226 210 215 220 221 223 231 226 221 219 225 219
   221 219 217 216 224 222 228 198 223 221 218 225 219 178 227 223 223 219 219
   218 185 221 218 213 216 214 214 167 211 216 221 216 219 228 220 228 223 222
   218 228 221 220 217 219 218 220 212 215 219 219 223 222 175 219 219 221 218
   219 222 220 206 226 217 206 202 201 223 185 225 215 218 213 221 221 219 220
   241 213 220 193 215 222 218 221 220 219 222 217 219 222 218 220 223 220 179
   221 225 220 217 228 219 217 154 216 222 232 226 222 219 214 221 219 216 218
   215 215 222 215 216 214 216 215 212 215 217 216 224 224 216 216 213 215 216
   215 214 214 208 224 218 222 227 215 231 223 218 221 222 225 222 219 219 222
   222 217 220 220 222 227 221 218 220 221 217 221 221 218 230 168 230 214 221
   224 221 218 219 220 222 227 218 221 222 222 213 227 225 222 223 227 220 220
   224 220 219 220 218 219 224 225 217 217 222 220 217 220 219 218 221))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 215814 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61633840 :P50-TICKS 216 :P99-TICKS 327
 :LATENCY-TICKS
 #(146 140 135 141 144 155 143 143 141 140 140 142 141 145 140 139 139 142 148
   154 146 154 202 141 160 144 154 144 154 267 144 142 146 173 145 147 156 142
   150 138 143 143 218 233 227 231 234 232 232 233 222 236 226 223 240 220 230
   225 179 221 170 224 226 225 190 218 217 220 225 197 227 222 217 232 220 221
   220 227 229 224 219 239 224 227 225 225 229 202 185 239 223 199 237 233 228
   229 225 228 228 234 232 201 228 228 232 229 226 230 225 228 227 243 225 231
   227 227 219 217 260 251 217 226 202 327 472 327 315 313 307 274 344 295 319
   269 272 238 226 206 216 245 309 263 247 194 198 209 233 228 211 225 226 209
   193 327 143 137 139 135 138 216 140 137 135 135 146 135 135 148 140 138 160
   248 179 176 141 139 137 151 134 136 134 133 134 163 134 134 132 133 152 139
   144 148 147 148 168 146 135 135 143 136 134 136 133 136 165 138 158 156 152
   138 143 135 135 135 209 223 211 222 218 215 226 223 209 222 193 225 220 220
   222 222 189 207 197 200 224 198 292 336 274 285 265 236 291 293 256 241 279
   273 287 204 207 207 228 224 145 256 185 184 232 224 223 221 219 184 216 264
   232 203 225 259 238 248 222 220 223 222 220 217 257 225 224 204 207 158 223
   220 224 247 140 262 234 220 253 148 181 222 242 262 229 194 206 222 219 221
   219 217 215 215 216 215 217 220 209 208 218 217 217 216 217 205 216 217 174
   217 221 219 227 208 158 231 226 226 184 194 222 189 170 212 223 222 207 193
   219 219 224 220 219 207 222 219 223 243 235 159 230 205 235 228 261 219 220
   213 228 217 214 225 215 203 204 213 223 218 217 201 217 213 184 215 217 208
   214 219 217 220 190 217 203 216 206 205 217 203 184 218 209 195 197 250 173
   197 194 209 156 248 238 223 195 220 206 207 217 185 217 218 215 210 216 208
   195 184 217 204 215 217 214 218 212 230 200 218 219 190 212 214 187 211 215
   200 216 224 183 222 221 218 219 209 212 201 214 215 189 216 214 215 216 219
   218 219 218 192 213 215 214 215 214 204 204 223 204 183 222 195 194 184 231
   251 237 220 211 207 203 190 218 205 201 215 195 215 188 185 206 194 193 215
   254 273 190 221 227 207 222 256 203 211 213 219 212 210 214 214 228 220 219
   203 210 206 215 216 192 210 208 196 217 220 203 194 215 218 188 219 187 200
   219 213 276 213 219 218 218 222 215 223 254 204 216 267 232 218 192 218 206
   206 216 247 230 195 189 229 220 224 241 246 203 227 218 199 216 229 224 224
   190 219 215 215 220 205 217 216 202 216 202 223 227 215 217 191 203 218 214
   151 202 203 206 213 193 214 219 219 293 151 245 153 139 138 154 137 137 134
   132 135 137 134 134 175 144 138 146 134 135 123 136 148 168 156 201 143 136
   143 180 146 152 224 200 198 217 196 219 207 220 213 186 205 209 217 221 217
   222 211 203 226 175 196 209 222 216 231 182 187 217 202 229 225 214 193 209
   229 195 201 180 210 221 198 221 157 138 193 138 134 146 135 135 138 135 134
   135 134 134 134 144 134 133 134 143 133 135 133 134 135 133 145 147 136 136
   150 142 140 150 155 145 181 204 134 133 135 139 147 133 134 132 134 136 132
   132 134 260 136 132 137 132 136 136 133 132 134 141 220 191 253 195 223 215
   255 220 214 206 205 217 192 236 212 217 208 251 202 212 145 176 137 190 162
   151 173 138 187 136 137 141 174 211 197 203 195 190 201 225 221 182 175 192
   150 179 136 136 133 134 140 235 138 137 134 154 138 135 167 154 171 142 182
   153 182 141 138 140 156 142 138 135 136 135 263 223 217 223 231 218 227 235
   212 217 188 193 223 191 214 214 215 227 213 228 221 211 219 210 213 224 208
   225 227 205 207 225 212 216 215 203 202 188 202 189 217 221 358 304 257 285
   263 269 270 263 284 267 279 258 263 210 219 221 213 221 240 179 247 220 241
   239 232 193 213 224 223 217 218 222 218 222 217 220 219 306 288 291 236 226
   214 217 207 172 280 295 281 291 282 256 327 284 288 247 249 275 282 230 314
   260 250 283 271 278 266 279 298 246 257 276 299 279 234 269 235 239 283 263
   271 273 242 240 262 280 240 250 252 286 334 224 219 290 244 279 273 294 292
   265 267 253 312 301 293 299 279 277 294 296 306 325 296 344 327 322 284 287
   332 313 285 320 309 251 310 296 300 312 284 276 276 275 272 276 284 284 280
   325 292 294 301 283 278 277 294 326 285 305 276 275 274 293 292 300 287 258
   256 273 268 290 305 301 290 284 283 281 301 288 285 274 274 281 281))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 221890 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61573888 :P50-TICKS 217 :P99-TICKS 325
 :LATENCY-TICKS
 #(335 271 285 281 282 285 284 271 331 292 286 282 283 282 283 274 283 285 283
   281 286 276 285 282 280 282 279 277 291 286 270 277 296 299 322 286 194 258
   288 280 274 263 253 281 248 279 244 211 271 279 257 271 224 296 255 274 276
   274 288 277 223 296 252 242 232 272 281 262 302 289 263 289 245 277 272 254
   260 271 279 321 248 263 257 258 262 259 276 238 256 253 248 248 244 243 238
   243 239 248 266 316 325 344 1854 296 274 622 354 325 297 287 277 284 283 270
   287 297 351 368 281 233 237 233 344 186 240 233 247 222 223 229 220 195 187
   203 219 200 214 226 227 146 140 138 141 146 137 136 135 135 135 136 135 136
   134 136 136 137 135 135 135 133 136 134 139 133 134 135 256 252 153 235 214
   199 225 230 188 222 220 211 223 210 225 227 179 215 230 209 229 222 222 223
   221 226 222 219 210 215 217 215 217 217 222 243 227 208 230 225 221 218 218
   222 239 221 172 236 224 218 213 222 217 219 216 215 214 228 220 226 218 226
   219 224 219 216 218 218 220 218 217 217 218 221 220 219 219 219 246 215 193
   232 307 267 233 221 223 222 223 238 226 216 178 182 217 261 228 233 201 220
   220 281 256 255 144 217 140 135 137 140 139 135 141 134 132 135 132 133 164
   144 140 135 138 139 152 138 147 152 138 141 132 141 132 133 139 132 165 136
   136 134 133 134 158 137 133 145 137 137 134 144 136 132 135 134 146 137 136
   153 142 187 194 140 137 314 260 141 136 136 135 136 140 135 136 133 134 135
   136 139 137 135 134 135 145 136 135 150 142 137 161 138 139 154 201 188 163
   192 137 135 135 165 134 135 133 143 133 133 135 134 142 150 131 150 138 141
   134 133 136 156 150 134 131 133 215 227 210 206 217 222 226 240 211 210 189
   205 215 186 219 218 214 202 261 220 213 192 222 215 213 207 267 228 222 205
   214 214 226 255 220 343 274 246 229 225 229 230 226 227 205 228 222 220 211
   178 227 224 218 229 225 191 234 221 223 214 220 228 220 219 219 221 219 224
   214 220 219 199 221 219 220 219 219 228 228 215 216 221 219 215 219 217 216
   206 226 234 221 220 218 222 216 218 218 218 221 217 218 219 220 219 221 220
   218 218 221 223 221 217 223 226 221 219 221 218 218 230 245 230 237 230 228
   229 226 233 179 219 223 218 217 217 217 212 217 218 221 218 218 218 221 218
   218 186 215 221 230 226 223 222 228 221 219 220 222 210 211 230 218 224 225
   229 223 226 227 227 227 225 222 221 224 223 224 222 223 224 224 222 223 224
   226 225 213 223 222 235 230 183 219 232 225 226 222 222 230 228 228 223 219
   218 218 219 219 219 213 222 207 217 218 216 218 202 216 200 226 226 219 218
   216 223 217 215 221 221 235 221 221 182 218 222 208 217 214 217 214 217 220
   215 215 214 218 217 219 218 196 216 223 213 238 222 219 226 222 218 218 213
   218 221 183 209 226 215 213 223 223 225 224 167 220 217 195 229 240 221 221
   222 220 222 215 218 217 219 214 232 227 186 222 219 223 222 222 224 223 222
   221 222 238 229 227 219 219 230 216 218 216 215 222 213 217 213 213 214 214
   213 213 213 218 214 213 210 213 214 213 213 213 194 218 216 228 221 219 168
   220 197 207 215 216 217 207 204 210 217 210 209 211 211 211 216 214 211 211
   211 212 210 210 210 217 216 213 203 212 211 211 216 210 211 211 211 212 219
   218 179 213 213 219 213 212 210 225 216 216 208 211 203 214 207 212 213 212
   222 213 212 210 213 212 212 213 212 212 221 221 221 193 219 188 187 219 220
   217 223 210 214 221 213 212 215 213 214 213 217 225 213 213 214 215 213 210
   220 225 214 224 219 218 218 221 218 212 218 214 224 226 220 215 214 222 221
   219 214 214 216 216 212 202 227 211 210 210 210 213 210 216 217 211 221 211
   212 214 211 217 215 207 221 186 211 215 216 212 193 216 214 215 214 164 212
   216 210 209 210 211 210 209 211 206 212 212 215 213 211 213 201 205 214 219
   175 211 211 210 229 198 211 210 213 210 224 216 211 209 215 210 202 208 210
   210 213 210 210 211 210 209 210 210 209 210 213 192 209 209 210 211 210 214
   219 251 219 294 322 299 237 262 308 324 233 223 194 154 194 215 212 200 211
   189 196 192 193 207 183 238 227 216 205 199 216 206 215 182 208 183 213 198
   204 183 196 209 204 197 218 186 196 218 210 210 198 213 200 247 210 209 214
   208 213 194 210 211 209 210 212 210 311 284 247 243 241 240 254 304 262 303
   311 297 283 245 298 278 219 212 212 194 211 211 189 210 306 194 275))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 219343 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61573824 :P50-TICKS 213 :P99-TICKS 299
 :LATENCY-TICKS
 #(228 196 219 220 238 210 202 223 214 210 207 208 213 215 211 213 227 231 194
   196 213 212 214 186 215 208 199 210 230 210 184 214 195 210 212 184 180 211
   198 211 211 188 183 211 194 213 209 180 195 212 181 229 227 286 299 271 228
   217 228 206 188 217 188 214 190 188 188 207 185 186 210 194 183 184 198 211
   218 173 218 227 239 219 195 198 217 180 211 196 198 207 198 217 215 193 206
   193 213 212 226 220 203 211 213 179 210 184 208 211 214 228 209 211 188 185
   198 184 197 210 200 189 207 225 201 205 221 204 211 225 219 215 287 200 204
   221 192 203 221 214 215 220 221 196 214 214 214 214 207 215 181 237 218 238
   218 207 218 196 212 205 198 192 181 200 231 225 194 213 199 184 205 203 193
   197 194 192 203 201 188 209 184 209 170 210 215 202 210 197 201 209 207 233
   212 214 198 199 212 201 320 223 182 179 177 242 206 207 198 182 210 185 206
   215 206 214 215 214 204 214 187 190 214 191 204 182 201 213 186 225 222 258
   219 229 271 343 326 229 302 344 163 228 221 213 212 209 207 220 211 208 208
   210 208 208 209 208 207 211 206 220 219 221 238 192 210 188 203 202 198 239
   211 210 213 197 196 209 209 189 208 199 176 184 212 212 207 206 207 206 208
   212 181 190 208 207 208 206 207 362 249 216 256 237 269 228 210 219 214 203
   202 193 206 223 222 224 187 186 211 179 182 199 192 186 206 206 212 211 213
   211 236 241 217 212 198 212 201 179 193 215 271 215 205 209 208 199 214 217
   209 237 210 183 226 205 220 207 216 214 204 190 202 210 202 180 212 183 217
   197 219 184 192 209 206 212 213 215 248 221 219 196 211 207 201 166 210 215
   216 202 218 209 204 207 212 196 206 210 208 207 206 206 205 206 214 212 226
   232 215 216 278 314 347 264 212 201 187 198 193 182 250 239 250 236 222 215
   220 221 215 210 216 216 213 189 218 211 201 213 210 209 212 209 210 209 209
   210 215 215 209 211 209 210 215 226 213 219 219 214 215 218 216 216 214 214
   224 214 224 202 221 215 214 222 213 212 213 216 214 214 215 213 213 215 213
   214 213 213 213 213 215 220 215 215 214 213 214 215 217 216 222 224 217 214
   200 224 223 217 213 211 213 216 211 210 210 210 210 209 210 211 210 212 213
   210 211 211 210 211 221 228 196 211 218 218 216 222 214 221 213 216 225 217
   224 224 218 222 220 217 217 210 215 226 223 207 217 218 217 217 219 216 217
   220 217 205 216 217 218 217 217 217 215 225 200 224 221 222 221 210 218 212
   226 274 316 217 219 213 218 251 213 223 209 214 182 203 263 227 238 224 227
   226 224 216 212 214 219 213 211 214 212 214 227 220 221 221 215 214 220 207
   217 218 214 219 212 215 214 214 219 214 216 212 215 214 222 218 213 217 214
   191 214 213 213 262 231 225 217 211 184 150 216 213 214 214 220 214 213 216
   205 218 211 215 215 229 214 213 215 214 214 213 218 212 208 213 216 222 218
   221 223 214 218 217 219 217 218 222 218 216 203 231 219 212 214 212 214 219
   220 214 220 212 213 212 213 212 211 216 211 212 212 211 213 212 214 213 212
   215 211 212 213 221 216 213 208 177 143 219 203 215 217 212 204 215 216 213
   220 215 214 221 212 212 212 212 210 219 212 212 214 209 197 211 217 186 202
   207 217 209 203 212 209 210 210 210 210 212 203 222 214 212 216 213 215 213
   212 216 212 213 215 218 216 212 212 212 213 212 212 212 212 213 216 211 213
   213 212 213 216 216 218 215 161 212 214 222 222 218 222 219 208 217 219 220
   216 214 218 217 224 216 222 219 218 220 218 218 217 219 151 223 209 213 221
   215 213 220 212 214 213 213 213 213 217 223 217 213 222 215 214 213 213 214
   213 215 221 213 208 214 214 213 213 215 212 214 217 212 213 214 213 214 215
   217 216 213 219 212 213 219 1420 226 209 215 217 219 137 214 221 213 213 219
   212 212 218 213 212 213 212 213 213 215 222 215 211 222 225 205 215 213 217
   210 212 213 212 210 168 214 221 215 203 214 217 214 212 213 216 215 202 213
   211 212 219 215 212 212 220 213 212 213 218 211 203 216 213 212 168 223 213
   217 211 203 141 214 218 217 222 215 221 220 218 221 217 217 221 217 217 215
   218 216 217 217 219 217 220 218 218 214 225 208 216 216 218 218 220 218 216
   217 206 223 221 214 213 217 210 212 214 213 213 217 213 214 213 213 215 163
   213 213 213 214 212 214 214 214 215 218 214 213 213 218 215 217 216 230 217
   220 199 220 216 207 203 200 210 218 214 202 226 214 216 219 214 213))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 213918 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61633840 :P50-TICKS 214 :P99-TICKS 239
 :LATENCY-TICKS
 #(217 228 225 214 214 214 217 215 214 220 224 218 210 212 211 217 209 210 210
   211 217 223 221 209 217 188 222 216 204 213 214 214 213 212 212 213 214 213
   214 214 220 216 213 214 214 213 215 216 214 210 213 223 216 224 221 217 204
   197 219 211 217 223 217 222 218 219 217 223 211 219 218 219 216 220 216 216
   220 216 217 223 219 222 218 162 199 226 220 218 216 220 216 221 216 218 224
   222 221 218 216 290 208 192 209 220 216 205 212 216 214 215 216 219 210 216
   214 215 214 216 205 216 214 214 218 216 214 215 215 217 200 207 221 205 203
   223 213 227 221 208 218 222 221 218 222 221 217 220 218 218 218 219 218 222
   215 231 223 218 226 220 220 226 223 210 231 223 218 217 214 223 215 214 216
   216 227 221 220 214 208 213 209 212 214 212 223 218 211 159 192 207 193 211
   211 215 216 215 214 223 211 214 209 210 210 213 212 218 211 212 212 217 212
   217 214 214 188 220 219 224 226 219 220 223 191 215 214 213 215 213 212 211
   213 211 213 213 214 212 218 204 206 211 221 216 211 212 213 221 160 216 222
   223 211 212 222 239 196 207 219 211 225 227 215 217 179 212 212 216 219 201
   214 210 213 212 210 187 210 212 214 215 211 210 211 212 211 211 206 212 195
   213 213 214 211 211 215 217 207 227 200 212 217 187 208 227 219 214 213 210
   218 231 217 221 218 216 215 215 215 218 219 219 214 217 215 214 214 215 214
   212 215 222 224 186 221 207 217 211 213 215 210 214 223 211 211 217 219 226
   220 220 214 218 187 213 216 217 217 214 214 212 213 213 218 218 216 216 215
   216 215 219 218 203 218 222 214 214 215 227 218 222 218 221 191 189 223 216
   175 220 219 213 217 203 214 217 212 214 215 212 216 211 212 211 212 220 171
   211 219 216 211 211 219 219 224 220 212 217 221 215 214 220 215 213 215 215
   217 232 213 217 214 211 222 212 209 211 215 208 213 210 214 211 211 211 214
   213 216 211 210 210 210 204 211 146 211 209 211 212 211 219 211 175 224 214
   156 194 214 220 220 209 212 221 214 215 214 209 217 216 219 212 213 203 213
   214 214 214 214 214 220 214 213 217 218 219 214 225 215 212 217 204 217 214
   214 222 201 220 218 214 218 219 210 214 214 215 216 198 183 197 210 219 221
   220 215 213 214 216 215 215 213 219 214 216 218 215 213 213 215 217 218 237
   225 212 207 204 231 223 212 220 219 217 215 212 220 202 218 217 213 214 215
   214 216 218 217 211 219 215 215 215 217 217 218 216 224 215 214 222 211 212
   212 216 216 212 211 195 197 213 227 217 225 217 201 215 215 215 215 206 214
   213 214 215 214 219 199 212 216 213 213 215 217 218 216 218 215 215 213 215
   215 216 217 208 201 226 202 170 192 225 221 224 218 216 208 216 222 214 221
   211 216 213 214 214 213 213 220 211 217 214 203 212 213 213 213 211 207 214
   214 206 216 211 218 213 212 211 213 218 213 215 225 194 220 221 218 212 218
   218 213 204 214 216 215 215 214 215 215 219 216 214 213 214 214 214 215 216
   215 218 215 215 215 222 214 215 219 196 134 214 214 204 219 218 214 216 116
   214 215 212 216 204 215 211 211 211 212 211 213 211 211 220 201 211 211 210
   204 223 217 217 217 226 214 215 222 214 215 214 214 219 217 227 217 217 222
   206 210 218 216 212 211 211 219 219 218 210 210 218 213 211 210 212 215 212
   202 212 210 213 211 211 211 211 213 219 214 222 217 221 206 356 224 317 234
   290 303 240 214 247 236 199 247 250 205 239 196 218 214 230 171 176 156 161
   134 227 132 132 132 133 133 139 131 131 131 131 129 132 130 126 132 131 130
   130 130 132 132 131 129 130 131 198 157 220 225 211 181 137 228 208 220 210
   209 184 220 210 214 217 205 226 214 213 220 213 215 213 214 213 213 214 213
   213 211 213 219 213 213 213 213 212 212 215 210 212 215 215 212 212 211 203
   216 212 213 160 213 199 223 214 209 202 219 213 213 216 213 195 135 130 129
   130 129 129 129 130 129 129 129 131 129 130 129 129 140 133 130 137 136 132
   128 134 131 130 129 128 129 128 134 129 128 219 212 206 218 227 219 215 210
   208 212 212 212 203 208 209 211 208 206 209 209 210 210 209 205 209 209 208
   208 209 209 212 214 197 208 214 216 212 219 217 213 213 216 209 212 192 201
   202 205 213 219 213 213 222 212 213 212 212 213 213 211 213 213 220 224 204
   215 207 222 215 213 220 204 217 213 213 215 217 217 228 204 216 212 212 219
   211 214 206 211 210 209 210 211 210 213 210 210 210 202 208 210 210))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 219821 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61573904 :P50-TICKS 214 :P99-TICKS 229
 :LATENCY-TICKS
 #(219 213 208 221 149 219 220 214 218 217 215 197 211 215 213 210 213 214 214
   216 213 176 214 212 213 212 215 210 211 223 210 221 222 216 214 213 216 218
   214 216 206 209 221 220 203 216 192 212 216 214 217 207 213 219 214 214 213
   214 213 214 219 214 215 214 213 212 214 214 214 213 217 197 217 222 223 211
   215 208 182 222 220 218 211 217 228 216 215 217 214 213 214 209 206 213 213
   210 213 212 213 212 214 218 219 221 218 220 221 215 213 221 213 212 214 212
   211 226 213 256 217 213 215 217 200 210 213 214 213 212 215 216 213 211 220
   213 213 212 211 211 211 211 211 212 198 214 212 213 217 215 222 213 198 180
   226 211 213 220 217 216 212 207 214 216 214 218 215 214 223 218 222 195 227
   216 215 224 217 214 214 215 213 198 212 214 222 220 215 217 214 215 215 213
   214 226 221 231 220 207 219 214 209 218 212 212 210 214 223 211 210 205 209
   212 177 212 210 211 216 207 210 210 211 210 210 214 211 209 211 205 170 185
   150 224 218 208 214 213 219 224 196 213 218 215 216 215 214 215 215 206 221
   219 220 224 208 212 222 215 216 213 226 215 215 220 214 214 214 214 212 226
   223 212 212 210 219 213 210 209 211 211 214 210 212 211 210 211 211 212 210
   211 209 215 209 210 210 211 210 210 212 212 213 228 216 205 213 178 192 222
   220 224 220 221 215 220 218 214 215 213 213 214 216 216 221 215 214 219 213
   214 220 214 220 222 229 214 211 214 212 211 211 209 211 221 214 221 213 218
   213 210 212 214 213 214 218 217 214 212 216 215 213 215 215 215 218 212 214
   214 212 215 215 213 213 215 219 225 221 217 193 176 215 216 218 217 211 214
   209 218 211 210 212 217 212 209 212 214 218 211 213 210 211 215 215 210 211
   219 251 221 219 225 222 213 220 215 214 215 222 215 219 214 221 205 212 217
   207 213 215 212 212 214 212 206 216 219 206 211 217 210 210 211 202 211 211
   211 212 210 210 218 211 213 204 223 212 205 219 183 214 187 216 222 195 217
   211 211 210 214 213 211 221 210 211 211 210 211 209 213 209 211 216 210 210
   214 222 185 219 222 214 215 217 210 206 213 215 214 227 223 220 214 215 225
   212 210 210 211 211 212 211 211 213 213 211 211 212 206 212 211 211 202 210
   217 212 202 210 211 208 214 231 225 216 168 222 228 206 224 221 215 206 211
   210 214 216 210 205 210 211 210 212 211 210 211 217 210 210 209 211 213 218
   211 215 223 208 217 216 212 212 205 211 239 218 214 220 219 216 216 214 213
   217 215 217 214 215 222 215 214 215 214 216 216 214 215 214 216 215 213 215
   213 218 214 213 212 218 215 222 1666 225 220 217 216 222 217 214 215 215 214
   212 218 214 216 219 189 215 213 187 213 214 217 209 213 222 215 184 200 220
   223 226 219 229 219 210 215 215 207 218 233 223 214 218 213 213 214 216 197
   213 211 213 212 217 202 216 213 214 212 211 216 212 216 217 199 212 203 211
   211 221 206 227 218 223 228 216 186 203 191 207 187 211 221 203 227 220 218
   214 221 216 215 214 214 203 218 214 213 215 213 213 215 212 212 214 213 223
   214 165 226 229 220 208 219 205 217 217 213 214 198 214 213 228 223 222 212
   215 211 212 203 214 215 209 211 212 212 211 211 207 215 208 166 210 210 210
   210 211 217 211 211 212 213 211 214 213 194 213 207 196 168 217 206 184 223
   221 218 216 159 214 220 220 211 201 211 210 210 213 211 212 217 210 209 212
   209 212 211 212 213 159 213 172 194 218 221 215 224 214 216 210 214 210 169
   223 222 215 218 222 218 216 213 222 221 220 215 214 214 214 214 213 213 219
   221 217 216 215 207 214 214 214 216 214 212 217 218 228 219 209 190 161 208
   215 222 215 222 219 218 218 219 214 220 224 229 213 207 219 213 214 217 211
   209 214 222 220 214 216 214 199 255 246 223 215 217 218 227 208 214 213 214
   216 226 220 223 219 211 207 215 213 213 214 215 214 214 222 216 215 213 225
   214 214 215 215 215 215 215 222 213 169 224 210 214 215 216 221 228 223 173
   208 220 225 211 220 206 217 219 214 214 220 218 215 215 214 213 214 223 215
   214 216 215 212 213 204 213 219 219 216 224 223 220 199 213 213 221 208 215
   212 210 210 213 221 216 219 217 214 217 221 213 216 215 215 214 213 215 213
   215 211 215 214 213 213 214 213 215 215 216 220 217 214 221 211 218 212 217
   212 218 203 178 216 229 217 229 216 221 217 215 219 217 185 213 213 214 213
   214 214 194 209 222 214 214 214 215 226 214 171 190 215 224 211 216))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 221875
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61633952 :P50-TICKS 220
 :P99-TICKS 235 :LATENCY-TICKS
 #(143 141 136 140 137 152 138 137 136 137 148 139 136 136 157 157 164 139 136
   138 136 137 147 137 135 138 134 136 137 136 136 137 138 136 134 136 141 138
   142 136 144 145 187 143 137 140 135 146 229 235 228 229 231 240 226 229 223
   229 228 224 225 225 217 222 222 221 221 224 221 221 220 223 220 219 220 219
   225 223 221 225 221 222 223 224 224 226 227 225 222 225 228 212 226 225 226
   225 231 222 221 231 222 223 222 219 222 221 225 221 221 221 208 220 220 223
   218 217 225 229 228 231 224 216 219 231 222 224 224 222 231 228 228 225 221
   226 222 222 234 229 223 224 218 223 218 222 219 222 221 219 215 220 222 219
   222 221 218 222 226 220 218 223 227 222 220 159 227 233 217 222 227 221 215
   217 216 223 215 216 221 219 216 218 216 224 226 219 217 216 224 230 219 215
   219 227 218 207 226 218 224 211 224 222 219 215 218 160 235 219 231 216 216
   228 221 220 222 231 224 206 219 226 209 218 217 220 219 218 219 221 224 217
   219 219 218 218 222 217 222 225 238 218 217 218 228 197 224 227 219 222 226
   226 222 219 219 224 233 230 204 201 224 220 226 220 194 217 217 223 231 224
   221 230 211 230 219 220 221 217 223 216 221 220 217 209 223 221 218 224 225
   228 225 221 233 228 212 219 223 223 225 220 218 220 218 218 221 223 220 219
   222 214 223 216 221 219 222 224 222 225 229 210 269 212 221 230 221 221 227
   221 221 221 223 222 217 218 219 222 218 228 220 220 216 219 231 224 217 217
   219 216 218 224 228 219 216 220 227 219 219 223 217 218 222 221 225 215 220
   229 219 229 223 227 222 220 218 218 219 213 221 223 218 220 218 217 225 226
   218 221 219 222 225 223 220 224 216 222 240 231 225 222 225 218 227 216 224
   216 220 226 217 222 219 225 223 219 222 221 219 222 219 224 219 221 222 224
   228 226 225 223 229 232 221 224 225 222 228 223 224 231 231 225 221 227 216
   222 220 214 223 221 224 226 221 221 222 220 221 221 221 219 224 208 220 222
   219 223 215 222 233 223 226 226 196 207 232 224 219 226 222 224 225 224 221
   224 219 222 220 219 220 221 230 212 218 224 209 209 195 221 218 223 228 226
   227 226 220 221 227 215 221 225 226 218 229 226 225 218 218 225 220 220 225
   223 216 217 218 218 218 214 217 222 222 217 214 220 218 214 214 217 216 215
   220 209 219 214 216 223 220 219 217 225 219 227 220 218 223 212 219 214 219
   215 220 216 216 214 216 216 217 216 225 221 236 222 217 215 216 214 215 215
   226 218 222 224 214 215 217 225 215 220 210 217 216 226 229 223 220 220 229
   222 222 219 226 213 223 222 219 219 218 220 218 220 223 229 218 217 221 218
   225 221 223 221 224 223 219 227 219 225 216 176 222 189 219 226 221 218 223
   219 218 227 222 220 221 222 219 218 221 221 220 218 219 220 221 220 217 218
   232 214 224 227 218 216 220 218 219 217 218 216 221 222 225 228 224 211 230
   220 221 218 223 222 218 217 224 211 218 227 219 223 221 218 219 218 225 223
   218 189 217 193 224 227 220 226 220 217 252 222 214 178 219 221 216 224 202
   227 221 227 204 226 211 220 224 207 225 221 223 229 222 219 219 218 222 217
   224 227 213 220 218 221 232 222 221 223 231 233 221 232 222 219 227 210 222
   222 229 226 225 219 218 220 219 219 218 217 224 231 237 229 218 225 225 222
   219 218 223 224 224 225 217 219 151 225 233 222 206 222 219 193 231 218 227
   219 219 219 225 212 218 219 216 220 225 223 218 220 229 225 221 225 220 220
   224 220 220 221 226 221 217 221 225 218 228 229 226 221 222 220 226 226 222
   221 220 218 220 219 230 214 222 221 218 220 219 220 219 221 210 220 223 217
   220 219 191 224 224 223 223 220 206 230 190 232 218 222 186 220 226 219 222
   220 220 222 218 220 220 222 222 222 220 210 219 220 219 217 194 219 226 223
   226 221 224 226 230 219 222 222 227 233 221 221 223 217 225 218 208 217 226
   217 219 216 218 220 216 208 218 216 221 212 216 215 213 214 216 218 216 215
   220 217 215 220 221 201 222 227 228 165 221 215 226 229 221 182 230 224 221
   223 223 235 159 230 205 221 229 222 218 220 198 223 217 219 217 222 213 235
   216 224 222 220 219 230 222 220 219 220 220 232 223 231 219 217 225 228 232
   220 222 221 219 222 219 217 218 215 217 218 218 218 218 214 218 220 211 217
   219 217 219 221 222 230 225 215 224 186 216 222 236 224 233 224 221 222 215
   223 218 216 219 214 216 220 218 216 217 219 216 215 216 216 216 220))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 223061
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61573872 :P50-TICKS 216
 :P99-TICKS 303 :LATENCY-TICKS
 #(236 229 226 227 223 227 222 218 221 223 226 229 225 220 229 220 221 221 222
   221 217 222 213 219 226 222 219 218 219 220 218 220 219 218 227 218 222 217
   217 222 218 223 220 217 215 181 225 208 160 222 221 160 219 222 219 219 218
   218 216 215 218 219 217 215 215 218 214 214 219 238 212 218 231 225 222 233
   221 225 222 227 217 218 222 221 219 228 227 223 220 219 223 223 225 221 227
   216 220 219 218 219 219 219 221 218 225 224 222 219 221 214 220 218 219 219
   220 213 221 241 229 227 225 225 188 213 223 223 165 226 225 223 218 218 243
   227 188 225 220 228 218 219 228 226 221 219 219 221 226 225 203 228 198 221
   225 215 216 225 217 216 219 216 230 225 221 221 224 224 219 225 222 223 219
   219 229 222 220 219 226 218 218 219 220 151 275 221 222 203 223 277 359 234
   228 233 230 279 179 257 210 224 232 217 222 227 233 297 218 220 218 234 253
   220 229 231 236 224 217 220 196 217 218 220 228 222 223 210 218 224 215 215
   218 184 208 200 217 227 215 206 216 212 189 210 209 210 212 214 193 213 252
   251 225 295 240 217 220 216 203 220 215 214 213 216 214 218 239 1686 229 214
   220 220 220 218 216 227 224 222 217 219 210 201 215 213 195 195 221 217 214
   211 217 207 216 214 209 194 213 195 215 217 215 182 214 269 225 220 223 217
   218 217 256 278 230 218 243 219 221 242 242 416 338 236 228 234 245 210 223
   232 207 189 219 216 217 219 217 222 223 237 227 218 220 217 219 215 218 218
   218 216 220 217 216 202 219 219 232 230 222 220 221 217 218 207 217 224 233
   231 216 214 220 218 213 215 219 212 216 198 212 212 215 215 212 214 213 212
   215 211 212 211 211 216 211 212 212 212 215 221 218 216 230 208 222 204 216
   217 224 217 219 223 218 221 219 219 216 221 217 220 216 216 215 212 220 217
   207 227 225 225 203 221 219 221 219 221 222 219 216 227 224 192 217 217 209
   207 215 215 214 215 217 215 213 204 218 216 183 223 218 218 215 218 218 216
   199 222 209 216 198 219 216 209 163 176 226 202 223 221 213 221 216 216 222
   216 214 208 213 220 217 215 215 215 215 217 221 222 217 217 220 201 224 220
   216 216 211 217 203 217 219 219 230 217 220 215 213 217 217 213 214 216 216
   213 213 213 213 213 218 215 214 213 211 212 212 213 212 215 217 211 214 212
   201 218 219 216 215 221 193 224 213 148 221 218 219 215 216 218 216 218 216
   215 216 216 216 215 216 215 219 217 215 217 218 216 208 160 231 228 228 223
   215 217 217 214 216 225 193 219 216 217 212 213 222 188 194 213 214 212 218
   212 217 216 213 212 213 213 215 213 212 212 218 212 215 207 212 218 215 218
   218 178 216 220 206 213 213 216 218 211 222 216 216 227 222 214 216 215 215
   215 215 215 218 217 214 198 232 243 228 287 222 214 219 214 212 216 215 212
   228 222 226 224 220 216 217 215 214 220 216 216 216 215 219 216 216 216 220
   217 218 216 215 219 220 219 203 215 216 217 220 217 223 202 217 202 192 212
   220 216 218 209 217 215 217 215 216 213 216 216 212 193 207 211 211 214 214
   212 212 215 158 196 189 208 208 208 212 208 208 208 211 210 217 218 211 210
   211 212 210 210 211 211 210 214 210 198 213 217 210 200 199 211 208 210 211
   210 211 211 214 211 211 215 213 225 215 161 192 202 205 195 213 210 193 213
   212 212 219 212 213 213 212 214 203 210 211 211 210 211 211 218 212 215 223
   180 220 209 204 208 210 207 210 206 207 207 216 217 212 213 190 212 219 216
   214 225 201 211 213 212 218 209 211 216 210 211 211 211 211 211 210 212 212
   221 211 204 211 215 214 217 218 220 249 250 261 303 184 211 195 211 191 215
   200 193 219 200 195 218 207 213 216 214 201 215 195 213 223 226 231 209 182
   183 215 209 210 205 204 210 193 224 176 182 209 181 195 208 198 199 208 185
   215 209 185 177 176 209 179 188 175 185 202 209 210 199 180 208 190 210 342
   296 249 320 245 274 336 313 241 230 250 277 263 285 275 273 217 210 211 218
   211 209 206 287 218 210 238 219 216 312 319 230 217 200 200 193 207 204 201
   199 269 191 182 206 205 210 207 181 221 208 214 219 205 185 205 206 208 205
   204 204 203 209 219 213 212 212 181 209 181 206 208 207 207 210 124 191 210
   206 212 183 169 197 215 208 212 228 218 250 216 211 255 216 213 185 220 213
   213 213 214 199 213 215 183 213 188 212 188 219 232 178 248 206 205 206 211
   204 174 205 205 217 221 196 212 206 212 202 182 181 208 194 187 197))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 215839
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61633904 :P50-TICKS 211
 :P99-TICKS 270 :LATENCY-TICKS
 #(204 177 209 204 207 211 200 209 208 207 207 208 209 208 212 212 241 224 212
   220 228 211 231 270 277 166 188 216 194 211 216 215 199 213 179 219 214 211
   198 212 212 208 199 215 212 228 210 212 211 177 209 207 195 208 211 215 220
   187 216 180 178 208 209 208 209 208 209 210 200 204 189 191 208 185 208 195
   207 210 209 203 191 208 205 176 204 195 188 223 362 203 217 204 216 182 211
   203 212 214 208 199 180 197 207 199 208 200 210 195 210 214 177 211 212 205
   187 213 215 227 178 182 203 233 235 327 358 220 213 268 194 213 187 211 194
   202 243 206 199 213 193 207 209 166 208 204 203 168 207 218 154 199 206 216
   208 184 190 210 207 176 207 213 217 195 201 186 190 254 215 210 209 183 185
   189 198 178 184 182 185 180 200 196 198 199 185 192 195 185 183 291 250 196
   232 237 211 232 202 215 185 191 213 207 191 220 217 217 212 193 207 206 205
   208 209 206 175 210 187 208 196 187 204 190 237 238 216 275 223 186 188 196
   187 206 182 199 208 212 210 206 214 204 226 217 214 204 216 195 203 220 186
   199 215 209 188 180 197 187 186 180 218 212 212 239 195 230 227 200 208 205
   212 242 212 212 218 188 176 204 212 203 192 202 207 211 198 212 214 188 213
   196 209 180 200 200 200 211 212 211 202 180 233 245 212 302 324 380 205 232
   156 196 197 159 187 217 189 200 187 228 224 219 216 218 205 193 211 199 218
   223 211 213 184 204 213 216 193 190 214 239 220 220 210 211 216 187 230 212
   208 207 215 218 216 212 211 209 217 212 210 201 209 212 191 209 211 214 210
   215 210 209 213 210 210 210 213 212 209 216 179 210 209 216 209 211 214 219
   212 152 204 215 210 155 199 210 216 198 181 211 210 215 211 211 196 203 212
   211 211 211 211 207 183 211 211 211 210 216 210 218 224 216 212 209 218 212
   211 210 214 221 216 216 215 207 217 209 212 212 210 212 211 211 215 191 217
   214 211 211 214 211 211 211 211 219 211 210 210 211 220 214 214 207 202 217
   213 214 162 217 222 214 216 219 211 206 213 211 210 208 210 210 209 210 214
   210 205 211 211 211 211 210 210 211 210 210 211 208 220 216 215 220 214 214
   213 214 232 207 215 222 211 210 193 178 216 196 198 218 214 202 209 215 212
   199 209 211 213 209 214 211 210 212 216 210 209 209 210 209 206 227 220 219
   211 212 218 215 212 201 190 202 214 218 219 222 215 152 211 214 210 214 212
   209 215 210 209 210 210 212 210 214 208 207 207 208 214 209 229 220 211 211
   215 217 210 202 212 211 211 223 222 216 218 199 190 210 218 210 214 211 211
   210 214 210 211 212 211 213 211 204 212 210 211 213 209 211 210 211 211 207
   215 199 218 177 170 216 190 183 216 213 214 212 211 212 215 202 212 211 210
   211 210 210 210 211 213 216 214 211 211 221 220 217 217 211 188 207 215 207
   198 207 207 209 216 217 212 214 211 219 213 210 210 210 214 213 204 210 215
   212 215 182 216 214 217 214 216 214 217 205 214 213 211 220 218 208 200 206
   220 201 201 215 220 216 201 202 209 213 203 213 210 210 209 210 205 208 210
   210 210 211 212 209 211 212 219 227 226 216 214 216 220 215 214 215 214 223
   213 222 218 213 214 212 209 205 213 211 213 212 211 210 213 201 211 211 211
   211 211 210 211 211 211 212 211 198 191 223 219 222 192 143 168 216 199 211
   214 212 216 216 212 211 221 213 218 203 199 208 209 209 208 209 207 208 211
   212 210 207 213 215 239 229 214 208 212 214 211 213 211 218 214 194 214 221
   210 220 217 203 208 210 206 208 209 210 202 214 212 207 207 208 210 208 207
   209 205 209 171 214 214 212 212 211 211 212 207 219 215 217 209 208 214 208
   211 194 164 216 183 209 213 216 150 217 138 215 211 208 211 209 218 214 193
   208 208 204 211 208 205 212 210 215 210 217 214 205 230 217 215 211 212 214
   213 212 212 214 224 199 210 205 205 217 213 210 208 207 208 214 208 208 208
   208 212 207 208 207 211 209 208 207 208 208 208 213 208 202 207 202 211 222
   219 214 158 195 203 212 199 202 213 213 191 212 207 209 216 195 206 212 212
   211 211 212 212 214 218 216 212 214 213 214 220 217 219 216 215 216 211 217
   209 202 210 210 211 220 215 212 207 210 208 208 209 209 210 211 207 210 206
   207 205 199 210 208 210 208 210 207 218 218 212 208 216 214 220 209 211 214
   219 232 235 228 201 174 222 223 211 214 221 219 210 214 213 219 213 212 212
   216 218 217 215 210 211 210 211 212 211 210 210 216 186 209 220 1579))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 211610
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61633888 :P50-TICKS 212
 :P99-TICKS 228 :LATENCY-TICKS
 #(227 216 217 212 211 215 212 211 212 211 212 210 213 212 212 208 212 212 211
   212 212 212 213 212 210 210 216 210 214 217 228 217 210 186 205 221 224 208
   216 215 195 178 209 209 214 207 211 223 212 211 213 211 212 212 215 212 213
   214 213 212 212 217 219 199 214 221 219 221 225 224 217 219 219 217 231 223
   218 216 203 218 213 218 212 215 215 212 212 219 211 212 212 211 212 212 210
   211 211 212 221 215 213 213 212 213 212 213 214 217 222 224 203 209 185 200
   230 208 173 207 218 219 220 212 213 212 215 198 210 212 213 214 212 211 212
   218 212 212 212 210 213 202 213 221 214 200 220 219 215 217 210 215 218 216
   214 215 213 231 221 219 216 218 218 182 212 219 217 212 215 217 213 213 217
   213 214 211 212 214 212 205 211 213 219 204 219 193 184 207 219 194 221 213
   211 218 212 214 217 211 211 211 220 219 196 215 214 213 221 213 211 212 212
   211 212 212 186 212 213 202 213 211 212 215 212 221 218 173 203 219 215 217
   209 209 214 208 214 216 209 209 225 208 216 213 214 214 213 193 212 218 186
   188 211 217 208 212 212 217 213 213 211 212 189 210 214 216 210 211 203 213
   212 212 218 234 222 217 209 216 220 217 207 213 214 204 198 215 211 214 223
   215 211 220 213 212 212 212 213 210 213 225 216 211 211 212 206 212 210 208
   216 214 209 201 209 209 209 215 212 208 210 213 214 214 221 218 219 214 212
   222 211 213 218 199 214 213 207 187 190 213 213 214 218 213 216 203 210 211
   212 213 211 212 210 219 212 212 214 222 216 211 205 211 217 158 133 129 130
   128 130 143 130 119 129 129 131 128 131 129 129 130 133 129 130 131 129 129
   129 129 130 128 130 128 129 133 132 140 143 129 141 155 139 133 132 133 132
   141 131 129 129 129 130 135 128 132 129 130 123 129 125 130 131 121 131 126
   130 129 129 129 149 131 203 213 210 208 209 209 209 210 215 170 201 217 195
   213 210 208 218 217 239 210 208 215 227 218 213 201 209 212 212 211 209 209
   208 208 209 208 208 209 210 208 207 209 210 206 209 208 213 208 217 216 205
   206 213 208 209 209 209 209 218 215 213 208 228 220 204 222 212 210 214 215
   215 211 214 217 213 217 221 212 215 211 214 185 211 197 212 205 216 215 212
   210 154 215 214 212 217 213 212 213 213 213 214 213 216 214 218 212 211 213
   212 212 212 212 217 218 217 191 203 222 211 209 209 241 212 210 210 218 214
   218 194 221 214 215 222 214 214 214 207 214 211 214 213 212 215 212 212 220
   212 220 218 212 212 211 213 212 215 165 221 213 212 220 216 214 226 205 216
   219 192 171 211 207 213 212 210 215 214 217 218 213 213 211 212 213 211 213
   212 212 216 220 224 214 212 212 215 215 213 218 205 221 215 213 211 212 214
   210 213 212 212 214 230 213 218 211 209 215 208 210 212 214 215 208 207 209
   207 206 212 209 209 207 214 208 209 210 208 208 207 207 208 209 206 211 208
   200 211 210 224 219 220 194 214 222 205 220 200 210 213 188 194 215 213 216
   218 214 212 212 212 217 213 213 212 211 217 212 216 213 192 220 218 200 211
   220 209 197 211 212 220 212 216 212 212 213 227 218 222 216 212 211 214 213
   211 205 206 205 213 212 212 211 213 211 212 212 211 217 193 213 212 212 210
   212 211 211 213 211 191 217 211 216 213 221 206 203 216 194 218 215 216 215
   204 213 212 217 212 212 223 216 212 212 213 211 214 203 212 213 214 215 214
   212 220 216 168 218 225 213 210 211 209 209 208 211 210 209 200 209 220 212
   219 221 212 212 209 218 213 215 212 184 220 191 212 212 212 212 212 212 209
   217 219 219 211 214 211 211 212 212 210 219 213 216 212 212 210 191 214 214
   215 183 200 154 208 216 278 208 213 215 218 215 212 214 215 213 213 212 212
   212 213 213 213 211 221 213 211 214 214 212 216 212 193 215 221 216 214 213
   220 212 205 217 212 212 208 215 221 216 214 221 213 215 213 215 217 217 213
   213 213 214 214 211 219 220 213 217 213 213 216 217 213 213 212 214 213 220
   216 215 191 211 223 218 203 212 210 214 221 208 214 218 215 215 214 212 214
   212 218 212 213 211 218 214 211 212 213 230 192 218 213 220 208 213 216 213
   215 202 208 216 211 207 212 217 207 208 208 207 208 214 210 210 210 213 207
   209 208 210 209 214 220 200 158 219 180 206 178 209 212 209 210 212 192 208
   227 213 219 213 214 215 214 215 213 215 212 211 213 206 211 211 213 217 212
   212 212 207 212 212 215 211 213 217 219 214 214 212 216 218 213 213))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 207340
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61573904 :P50-TICKS 211
 :P99-TICKS 229 :LATENCY-TICKS
 #(138 138 129 129 149 133 134 131 128 130 134 131 133 131 132 129 123 129 132
   132 129 126 132 131 128 135 137 129 131 139 133 130 129 202 132 131 140 142
   149 136 129 130 133 130 132 145 132 127 132 134 131 129 128 129 137 128 129
   128 130 128 127 129 160 219 201 212 207 214 213 214 211 212 214 214 211 211
   208 215 221 196 219 216 213 205 219 213 215 223 212 231 213 221 214 219 212
   214 224 213 217 214 212 213 213 212 214 213 214 213 213 213 214 213 213 214
   223 216 214 216 214 213 212 215 217 213 216 214 231 212 210 194 214 204 215
   213 214 210 219 211 211 211 208 209 209 199 193 145 130 132 130 128 129 152
   134 130 129 129 132 135 136 146 137 132 132 135 132 129 132 132 127 137 137
   134 129 129 128 129 132 130 131 128 122 130 128 141 131 129 130 130 128 128
   128 129 130 129 136 130 131 127 127 127 129 129 128 128 129 128 128 138 131
   129 128 129 229 221 213 210 208 216 210 209 209 210 229 233 219 218 212 212
   224 213 212 218 213 181 211 211 213 212 212 211 214 212 215 213 201 211 214
   212 211 212 210 212 207 213 212 211 211 212 210 214 184 217 213 192 218 210
   212 219 213 231 215 212 211 215 213 210 211 211 209 211 212 212 212 218 197
   203 218 215 219 193 214 213 202 196 214 207 214 208 210 213 208 208 204 207
   212 214 209 208 212 211 208 210 209 208 215 223 217 198 217 211 197 212 218
   214 215 216 203 212 209 219 222 213 211 220 215 213 219 217 212 210 211 213
   214 213 211 212 225 211 211 212 217 212 212 211 212 210 213 210 211 212 212
   215 206 223 216 223 218 195 214 212 195 213 210 211 212 210 213 217 211 211
   210 214 212 211 213 199 176 200 207 215 223 218 214 213 210 216 213 209 219
   214 212 218 216 197 212 212 238 193 222 212 209 233 194 213 218 211 217 218
   206 204 218 218 213 213 218 217 212 215 215 213 218 223 209 222 213 211 208
   197 214 208 209 216 207 206 211 214 207 206 213 208 210 209 209 208 206 208
   206 208 208 210 207 200 208 207 211 208 208 207 207 213 214 195 213 214 207
   201 207 208 209 210 211 203 205 207 216 207 211 207 209 208 212 208 209 208
   210 213 200 217 203 203 212 222 215 217 212 212 220 213 212 211 212 207 208
   193 211 211 212 211 212 224 202 215 213 213 218 218 185 204 211 212 213 212
   213 214 213 212 211 213 226 214 215 196 217 212 212 213 211 213 212 214 212
   211 215 219 211 211 211 210 212 215 211 212 213 212 211 223 217 211 210 211
   216 185 208 230 216 214 221 214 214 215 199 156 198 216 218 219 216 214 210
   197 214 208 212 208 206 203 208 199 217 208 209 208 209 208 206 212 208 208
   265 217 221 214 224 216 207 222 217 219 224 206 221 218 226 214 219 220 216
   213 210 200 210 211 211 214 211 220 211 210 209 211 211 211 215 179 210 208
   206 220 210 212 196 210 210 209 211 211 219 211 216 212 217 207 224 200 220
   206 217 218 212 144 214 213 207 214 217 206 204 211 208 201 208 209 211 208
   207 207 207 208 208 211 213 220 218 215 214 215 215 216 216 211 211 214 211
   222 213 218 198 208 210 211 207 208 210 208 208 207 206 208 207 210 207 208
   207 207 207 207 208 207 207 208 216 206 207 199 206 205 210 210 184 209 216
   209 215 214 209 208 215 217 217 212 210 213 210 219 208 210 208 227 1570 213
   209 209 207 211 211 216 217 217 217 210 208 208 209 208 208 209 208 208 205
   216 200 215 214 212 221 213 217 217 212 214 212 212 212 211 212 211 219 212
   193 211 213 213 212 215 211 212 216 225 220 210 216 213 217 219 209 190 193
   227 206 224 218 202 211 181 212 213 210 216 209 212 215 212 211 212 211 211
   211 214 214 211 211 212 211 212 212 218 195 217 222 198 208 207 216 203 207
   209 207 209 224 216 216 211 211 220 211 211 210 212 213 216 207 212 216 217
   210 211 211 211 211 215 213 211 225 208 195 207 211 216 211 219 212 206 215
   212 221 216 220 215 213 162 179 212 218 222 217 214 213 214 198 204 213 208
   208 209 206 204 208 209 208 209 203 211 206 207 208 208 208 206 215 170 197
   199 208 181 212 213 213 219 215 212 213 212 217 226 219 211 204 208 215 209
   209 208 213 213 208 207 208 212 208 207 211 213 203 211 207 207 207 208 207
   207 203 206 209 208 213 209 213 210 212 209 217 197 170 219 221 217 210 213
   209 206 213 212 220 213 216 208 213 212 211 213 213 214 213 212 211 203 222
   216 213 212 195 216 210 146 214 214 216 214 220 201 214 214 213 215))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 235171 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61633936 :P50-TICKS 229 :P99-TICKS 286 :LATENCY-TICKS
 #(219 216 227 224 246 212 201 177 170 183 281 286 286 288 293 295 282 276 283
   286 278 287 284 282 277 293 256 253 253 251 254 253 254 312 364 262 252 271
   244 258 248 260 258 250 249 250 326 249 235 230 216 237 235 230 226 231 231
   225 229 227 230 224 224 229 223 226 225 222 232 225 236 231 225 223 242 225
   224 222 224 228 225 223 223 226 244 231 244 237 233 239 230 231 232 248 227
   227 229 229 204 227 232 230 229 226 230 232 230 238 231 230 230 225 231 228
   230 231 233 233 235 219 198 246 229 230 237 233 221 227 225 228 227 228 225
   223 230 240 233 232 244 226 225 229 228 227 224 229 224 213 220 235 188 230
   225 227 238 225 236 226 224 223 238 225 244 239 230 232 236 233 236 237 232
   230 231 230 233 235 231 239 234 202 230 225 237 232 231 232 228 226 230 233
   233 236 231 211 186 187 237 221 223 232 224 239 236 228 238 230 234 220 227
   231 232 230 233 235 231 231 227 229 229 227 203 228 235 233 232 228 229 234
   229 231 229 230 231 237 226 232 228 225 192 226 224 230 235 223 226 224 223
   222 222 224 231 223 232 217 240 222 223 224 223 222 225 228 195 213 243 287
   232 235 243 231 218 207 227 221 233 246 242 241 234 228 229 231 229 234 232
   233 235 230 229 230 236 230 228 228 228 227 227 224 229 209 239 237 231 228
   225 239 234 230 228 229 238 230 238 232 230 236 230 230 229 230 225 229 227
   225 227 227 226 223 230 232 234 241 232 230 231 229 228 234 230 227 231 232
   237 209 231 219 179 236 230 190 226 227 221 247 236 231 234 239 233 231 236
   231 231 227 230 231 235 229 228 231 231 231 228 232 228 236 224 225 236 222
   224 226 231 222 225 234 241 232 226 234 224 227 227 232 229 231 228 230 230
   230 227 232 236 229 233 204 236 229 232 228 231 224 226 228 230 235 228 242
   237 225 234 234 223 239 238 190 234 226 224 229 223 223 221 228 223 218 219
   207 223 223 224 224 224 228 228 223 213 224 231 218 238 231 227 231 228 227
   225 213 227 243 232 234 219 225 229 225 222 222 225 225 223 223 223 224 223
   223 227 223 223 224 220 234 237 229 225 229 239 231 227 232 233 236 233 226
   233 238 217 242 190 228 226 231 222 240 234 229 236 229 227 230 226 231 225
   231 228 226 228 231 227 229 232 239 227 240 239 234 226 232 233 233 235 230
   230 230 239 250 237 241 231 232 173 226 224 224 223 227 226 224 225 227 226
   223 221 211 224 223 225 230 223 229 222 224 227 221 223 222 227 228 240 233
   227 234 249 221 216 235 230 234 236 230 236 230 224 232 227 225 230 223 235
   223 226 223 220 225 228 223 224 226 233 237 231 208 237 233 237 235 233 236
   231 231 230 235 235 214 228 197 225 231 223 223 223 224 223 224 222 223 229
   222 222 225 225 222 221 224 226 221 230 225 222 224 223 224 229 225 235 233
   233 231 227 197 238 234 235 234 235 226 235 235 239 231 230 229 230 230 229
   236 234 227 230 230 230 229 226 236 231 192 232 227 227 228 236 231 230 228
   234 236 235 236 227 223 229 229 224 233 230 222 221 231 220 224 223 224 232
   259 225 190 230 277 226 232 239 226 224 298 238 208 228 263 241 222 251 197
   251 225 216 262 231 231 198 220 232 229 231 227 229 228 228 228 227 231 227
   234 229 230 227 228 228 225 232 232 229 229 233 245 239 227 233 238 217 229
   224 226 225 222 227 227 230 231 230 241 235 226 215 227 229 226 225 228 231
   227 237 227 226 228 226 230 227 228 236 239 220 228 229 227 228 233 231 219
   234 229 241 233 211 222 193 167 235 232 228 236 227 234 234 210 233 230 227
   232 233 225 227 230 224 225 230 238 230 227 230 232 236 231 223 236 223 226
   231 229 232 228 222 238 224 239 238 235 231 242 235 229 233 238 225 229 226
   227 229 223 232 227 227 212 226 202 224 227 233 226 227 228 226 226 229 232
   234 234 233 223 188 227 214 222 239 227 208 238 239 231 226 223 227 222 223
   223 222 228 225 222 224 225 229 225 224 224 221 231 234 232 232 202 228 226
   210 235 226 232 228 233 242 233 228 229 223 229 251 245 266 234 224 239 233
   222 225 228 224 230 225 225 220 224 186 225 226 229 224 247 220 222 222 233
   227 225 224 229 202 218 199 216 208 242 233 232 205 242 237 239 233 229 226
   231 230 226 236 238 229 229 226 227 229 232 229 229 241 235 235 228 230 179
   229 220 227 227 226 228 228 228 243 231 222 224 225 234 231 222 225 224 224
   223 226 227 224 231 228 227 223 222 223 224 221 222 223 228 223 222))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 233383 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61573936 :P50-TICKS 226 :P99-TICKS 251 :LATENCY-TICKS
 #(245 237 274 217 247 233 222 243 235 234 232 192 240 230 236 227 226 227 226
   226 228 236 213 226 225 226 228 223 227 226 225 235 222 237 226 239 230 225
   234 223 227 227 225 226 231 229 229 234 228 235 225 226 228 232 227 227 220
   228 228 226 235 229 228 230 227 228 231 222 228 234 230 228 222 231 225 241
   234 244 225 241 201 213 229 233 235 243 228 228 236 240 227 228 226 230 228
   229 225 233 231 228 230 227 228 225 196 232 239 236 230 227 234 216 221 225
   225 224 239 246 221 232 216 237 235 241 234 232 228 243 230 227 235 227 224
   227 226 227 229 228 226 224 227 225 224 226 224 224 231 223 232 227 237 230
   242 227 236 213 215 233 235 234 237 233 231 237 233 238 224 236 229 232 231
   227 232 230 233 242 223 231 228 238 228 233 235 203 235 232 241 218 228 232
   228 231 241 230 240 220 224 233 226 231 224 226 226 231 229 218 224 224 222
   225 224 223 231 228 219 220 232 224 224 223 226 227 218 233 232 243 240 225
   198 219 229 229 235 241 232 223 228 229 237 232 227 228 242 230 229 231 227
   229 227 230 229 229 232 227 228 235 237 231 242 229 228 231 230 229 227 229
   230 242 227 242 234 223 235 230 229 225 233 228 229 228 231 229 227 226 230
   230 225 227 226 231 234 224 229 226 226 226 213 229 227 242 236 252 269 231
   245 238 232 222 237 234 230 230 229 229 227 211 240 232 237 230 229 232 228
   231 229 229 231 239 242 233 239 229 225 235 234 230 258 201 242 236 229 235
   225 225 230 225 227 232 227 224 226 223 223 223 226 226 237 231 225 224 221
   224 224 222 224 225 228 225 220 224 231 232 225 241 232 217 218 232 235 233
   228 227 230 240 229 236 223 233 231 232 230 233 232 231 232 236 228 230 235
   228 227 221 2116 229 230 237 236 242 231 225 236 229 225 225 227 231 223 226
   221 228 224 226 225 228 221 229 220 223 217 226 225 224 225 223 225 228 224
   230 225 226 235 235 242 227 235 236 222 227 222 231 244 235 230 233 235 228
   229 230 232 228 230 230 228 236 226 229 231 224 231 236 174 204 236 181 228
   227 233 229 224 223 219 227 236 235 233 220 227 233 225 224 223 216 223 231
   226 223 222 224 226 223 226 223 231 220 222 224 224 223 222 224 224 225 226
   232 241 242 229 161 240 224 240 230 231 229 198 228 226 237 222 227 226 224
   209 222 231 227 230 229 229 226 227 232 236 235 190 208 238 188 227 226 221
   231 180 224 225 222 242 231 235 230 227 232 229 227 226 233 228 226 207 202
   287 251 241 239 236 231 229 228 229 228 238 227 229 229 227 232 223 232 225
   236 235 228 241 232 235 227 224 226 190 238 232 231 229 224 226 233 236 228
   227 227 241 229 221 229 228 228 225 238 227 246 233 234 232 226 228 232 233
   226 223 212 229 240 233 241 241 239 231 241 230 241 232 243 241 229 226 233
   228 228 224 227 238 227 227 228 226 231 228 223 235 228 227 235 234 232 226
   232 225 226 234 230 235 229 224 223 217 216 222 217 217 210 215 216 217 215
   217 219 218 215 215 217 216 214 217 224 224 174 167 219 215 219 219 217 223
   217 214 217 222 210 227 226 226 224 221 225 221 219 228 227 220 220 218 220
   222 219 219 221 225 221 219 220 220 218 220 220 219 218 225 214 225 230 227
   223 182 219 208 233 230 238 219 215 233 224 211 222 230 219 226 230 229 219
   220 219 222 228 221 221 215 221 226 224 196 222 212 224 207 224 222 231 222
   223 220 221 218 224 225 229 223 215 218 217 216 219 218 217 222 215 219 217
   217 216 216 218 218 215 217 216 219 222 219 216 217 214 216 218 222 210 222
   227 222 219 226 172 169 221 224 220 231 222 231 229 222 226 220 222 221 220
   226 222 223 220 222 221 220 219 222 223 225 220 227 221 226 216 225 225 222
   223 222 221 223 218 224 234 219 228 222 222 228 219 221 221 223 219 220 220
   222 220 224 221 219 220 220 219 221 221 221 223 224 221 219 219 221 213 224
   220 226 232 216 168 221 225 223 226 221 217 219 217 221 216 216 218 217 216
   215 216 218 216 225 218 218 216 214 218 217 193 217 228 224 228 217 224 222
   226 221 224 220 220 210 228 225 219 219 225 220 217 210 216 221 218 216 226
   216 216 213 217 216 215 223 220 216 215 216 216 219 214 215 216 208 221 217
   226 218 222 181 226 220 191 223 219 217 223 224 220 226 214 218 220 225 218
   222 223 220 221 221 222 221 220 225 221 430 327 310 279 237 220 218 229 224
   224 223 217 218 221 228 226 211 221 217 224 226 222 180 251 223 220))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 224819 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61633936 :P50-TICKS 220 :P99-TICKS 242 :LATENCY-TICKS
 #(227 221 218 216 216 217 220 218 216 216 216 216 216 216 214 214 217 224 222
   218 220 219 223 217 217 206 149 223 204 212 231 224 225 222 228 223 224 230
   222 220 218 214 235 218 221 223 219 220 217 227 228 218 220 219 219 220 209
   215 237 230 225 233 230 222 222 226 226 222 223 226 232 242 221 234 219 218
   228 216 219 221 215 218 217 216 216 222 224 215 217 218 217 215 230 229 240
   242 211 218 229 215 216 217 224 220 215 232 225 222 227 192 167 219 181 195
   223 225 221 228 224 221 224 224 221 219 220 231 226 221 210 221 223 218 221
   220 225 223 217 227 228 227 219 226 222 217 221 229 221 218 220 221 221 186
   226 231 226 220 229 225 221 227 228 222 226 221 224 222 221 222 219 221 222
   221 221 225 223 227 226 222 224 220 208 236 229 226 229 217 221 225 232 207
   193 221 198 224 229 229 224 223 196 198 217 252 243 221 218 221 223 217 214
   217 217 215 218 220 221 217 216 215 231 225 219 219 219 228 201 191 231 218
   222 220 221 220 224 233 224 220 229 205 221 218 222 222 221 225 222 220 221
   220 219 220 221 217 221 226 211 218 218 221 215 221 219 221 156 226 229 215
   222 208 180 220 223 183 176 223 231 220 223 219 219 222 219 218 219 216 225
   220 176 217 224 216 221 219 218 227 223 218 225 231 215 222 235 223 226 219
   219 217 217 216 217 206 224 225 222 220 229 219 222 218 220 222 217 220 220
   218 224 220 218 219 217 224 235 218 221 222 226 219 226 221 218 225 221 232
   226 220 215 228 222 218 226 221 220 224 221 222 230 219 221 220 223 222 221
   222 222 222 230 222 222 220 220 221 229 219 225 231 227 224 220 223 228 219
   222 222 221 240 224 235 224 219 226 221 215 222 221 224 221 218 220 221 219
   220 217 221 219 223 219 219 219 220 217 223 220 217 220 227 223 228 216 206
   187 215 262 226 189 228 231 227 268 212 208 232 230 225 215 228 224 222 157
   227 224 222 219 222 221 232 223 221 219 227 164 208 226 224 223 219 219 210
   219 218 217 215 223 219 228 227 225 223 231 219 219 223 221 220 217 223 224
   219 221 220 219 215 217 219 220 223 220 231 216 219 217 220 220 218 225 229
   220 221 201 233 218 214 169 224 224 230 191 213 218 215 221 217 216 215 204
   230 220 217 221 213 217 215 213 218 218 218 217 164 190 224 234 226 214 225
   217 220 225 219 218 236 231 227 221 221 222 226 221 218 226 219 220 220 220
   218 219 224 226 215 219 220 221 218 217 221 221 223 223 220 218 220 221 223
   225 222 225 195 231 216 207 225 224 221 191 225 221 222 226 222 220 216 221
   220 220 219 217 220 227 218 220 219 204 220 237 239 227 213 226 226 221 201
   219 241 244 224 220 230 228 221 215 217 223 216 216 218 221 224 210 218 218
   215 216 217 217 217 213 222 216 216 216 201 216 216 214 216 217 218 221 219
   193 208 220 240 242 228 225 235 216 170 221 227 223 208 213 191 223 262 221
   219 225 187 227 223 221 219 218 225 223 219 220 220 220 220 218 232 226 227
   195 225 226 221 220 223 217 217 216 221 219 210 226 220 234 229 223 229 223
   229 220 221 221 219 220 221 219 221 218 226 221 220 219 221 220 215 220 222
   222 222 215 220 216 224 222 240 220 224 196 229 192 220 188 219 218 216 197
   224 219 224 221 220 220 218 219 222 221 219 216 221 223 218 219 221 222 223
   162 225 228 216 230 216 216 225 218 220 217 217 221 242 228 220 215 224 225
   223 208 217 218 219 242 230 211 219 225 217 218 224 215 221 221 214 218 216
   217 215 214 216 217 217 233 219 223 225 210 222 148 220 222 214 193 227 221
   220 182 222 222 224 211 220 224 219 220 218 220 220 222 226 219 224 224 218
   220 215 227 229 224 230 218 218 220 218 217 215 214 218 231 224 221 220 215
   223 216 215 216 206 221 216 224 238 219 218 224 223 217 205 215 216 214 218
   221 215 216 217 216 215 215 220 219 229 226 217 227 173 236 195 257 186 272
   230 200 175 215 222 217 218 219 224 219 216 211 218 222 215 216 217 215 215
   216 217 222 217 228 224 225 225 224 217 216 218 220 217 185 215 213 227 223
   225 223 220 227 219 221 224 214 225 219 219 226 221 223 222 219 217 219 220
   218 218 216 218 228 217 215 218 219 217 216 227 221 227 260 235 194 216 221
   168 219 228 224 227 228 220 216 225 217 216 216 218 215 215 220 217 218 215
   205 219 216 216 214 216 217 223 222 209 224 224 216 216 222 214 216 220 222
   216 230 219 229 222 220 225 222 218 192 221 222 230 223 207 224 220))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 225971 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61573936 :P50-TICKS 220 :P99-TICKS 243 :LATENCY-TICKS
 #(223 226 223 220 224 227 225 223 214 220 236 220 226 223 209 224 231 222 226
   227 227 226 223 220 221 224 226 218 220 219 219 219 217 221 221 217 223 205
   220 243 210 224 223 208 224 229 226 220 218 227 220 211 219 220 225 227 228
   218 218 222 223 217 216 214 217 216 225 215 216 214 217 215 215 221 215 231
   221 215 226 227 211 216 218 214 216 216 212 217 200 224 221 219 216 139 218
   220 205 223 242 223 219 214 219 218 213 216 183 261 297 369 284 230 220 218
   216 218 216 219 220 216 215 216 216 230 220 221 219 229 235 225 224 227 220
   222 221 225 218 1632 234 221 222 220 224 220 218 222 221 219 223 221 224 215
   226 223 221 218 220 227 228 225 219 220 220 219 220 219 220 222 225 236 221
   218 209 220 225 227 216 220 231 225 226 229 217 222 219 217 218 216 223 219
   216 217 216 216 219 216 205 219 224 224 220 222 234 212 225 187 219 219 216
   226 223 226 229 221 220 223 217 227 231 222 218 216 221 216 212 198 222 216
   223 219 216 162 210 230 204 230 216 219 221 215 214 219 220 217 222 211 215
   215 217 222 222 219 231 228 216 184 212 225 227 178 216 218 219 219 215 217
   216 219 219 214 216 214 213 223 218 214 211 222 218 219 213 218 216 214 220
   218 225 222 224 228 222 216 169 221 218 215 214 216 221 222 229 225 219 225
   215 230 245 226 231 214 208 223 218 220 223 218 212 226 225 216 226 222 221
   215 218 220 219 223 218 223 224 222 222 155 231 181 220 223 203 214 218 225
   226 223 218 225 222 223 227 220 220 192 219 224 221 218 221 223 222 220 218
   227 217 218 220 227 230 220 227 225 163 221 224 229 220 218 220 224 225 229
   232 226 225 214 214 217 219 159 221 217 213 217 214 216 219 217 217 222 219
   216 222 216 215 214 216 220 219 215 217 218 211 221 218 223 219 230 185 229
   230 220 215 224 219 216 226 221 220 220 226 223 208 219 219 216 221 218 223
   221 221 221 219 220 221 221 219 227 226 233 223 220 218 227 219 219 219 220
   203 226 225 222 217 224 218 216 215 218 217 214 219 220 216 214 216 221 217
   214 219 216 171 217 216 215 216 214 217 216 215 216 223 241 233 221 215 226
   218 230 222 225 224 220 217 216 222 215 214 216 220 214 223 216 216 215 214
   216 216 215 216 216 219 181 219 227 223 223 225 222 225 222 222 225 205 218
   236 228 230 221 244 223 209 217 219 233 202 231 217 171 226 223 229 223 223
   220 178 221 222 218 219 220 222 226 220 220 203 217 225 214 225 225 216 213
   224 190 225 176 223 219 177 228 220 219 223 220 222 191 216 219 217 218 219
   225 176 217 217 219 220 217 219 212 227 170 212 225 221 217 217 225 216 210
   214 216 223 206 228 225 220 217 217 207 218 216 224 221 218 218 217 219 219
   217 220 219 223 219 217 219 218 219 221 219 218 218 220 220 224 220 195 226
   220 223 223 229 214 209 224 212 214 223 220 222 225 218 223 211 220 224 223
   221 217 227 215 219 223 222 217 221 220 224 223 224 228 220 219 217 227 215
   215 216 214 216 231 216 227 210 223 228 223 214 219 219 219 218 225 220 219
   219 217 220 221 219 220 220 225 218 218 220 219 218 220 196 223 221 220 253
   215 207 231 219 228 216 219 217 210 224 225 218 222 222 221 220 220 217 227
   218 214 222 218 220 220 220 226 221 218 228 228 224 220 215 220 227 220 224
   218 217 224 225 224 236 230 225 216 229 237 218 225 218 222 215 215 217 217
   214 218 216 215 223 215 216 216 213 218 221 217 215 213 217 209 218 218 223
   218 223 213 223 213 212 228 230 210 221 218 218 221 214 215 221 217 214 213
   214 214 214 223 216 215 214 212 216 217 214 220 230 217 166 225 226 219 218
   228 219 218 217 206 190 211 219 227 220 216 223 216 226 221 220 218 217 217
   215 214 216 215 215 220 218 220 220 214 218 216 214 215 216 223 220 204 225
   227 220 235 225 213 156 211 188 214 224 226 223 225 226 200 221 221 226 219
   195 219 218 218 223 219 217 218 222 219 219 217 220 219 221 191 228 220 230
   215 220 221 226 221 221 220 220 226 227 227 222 220 226 228 221 217 223 221
   222 221 220 219 218 217 220 221 219 221 226 220 219 218 221 219 219 220 220
   213 227 225 229 222 198 232 208 220 228 228 226 221 214 221 226 226 215 219
   231 227 220 229 224 218 219 220 220 221 219 226 221 219 223 225 230 223 221
   219 220 222 220 230 243 223 219 229 246 219 228 222 225 235 219 220 222 220
   220 219 223 226 218 220 220 220 221 217 221 226 219 220 219 218 219))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 226102 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61573936 :P50-TICKS 220 :P99-TICKS 236 :LATENCY-TICKS
 #(223 219 182 228 230 218 229 223 221 230 214 222 227 230 220 219 218 219 219
   219 220 227 222 199 223 220 221 222 219 224 188 227 210 228 220 219 220 227
   220 220 219 225 232 220 226 219 189 225 223 221 221 222 220 221 218 219 217
   217 233 224 219 226 218 219 218 219 219 220 219 220 218 223 221 226 226 226
   220 220 222 223 196 230 230 220 230 225 219 227 221 223 220 223 220 221 220
   221 219 220 220 217 220 221 220 225 215 221 226 221 220 220 221 226 224 220
   213 219 234 204 229 221 218 223 222 219 214 223 218 219 216 219 222 213 219
   220 219 219 217 220 222 219 219 223 220 213 218 221 227 219 235 218 198 220
   220 188 198 222 220 235 226 216 223 226 218 218 220 220 220 221 217 219 221
   223 216 220 220 220 218 219 214 221 185 213 218 219 217 231 220 220 220 222
   241 235 236 223 221 221 203 221 220 220 223 224 223 224 211 219 220 220 219
   222 220 222 219 221 221 220 221 220 220 218 222 211 223 227 225 221 264 211
   173 228 196 261 223 224 226 211 217 218 217 216 218 209 204 215 211 223 221
   246 241 223 219 219 225 222 218 217 212 218 217 215 221 225 228 224 208 185
   223 220 236 226 218 223 223 218 222 240 235 225 222 220 220 223 221 218 224
   222 220 220 218 220 223 227 218 224 219 218 228 202 219 220 225 224 219 218
   217 219 219 218 221 227 226 227 222 225 172 193 227 223 214 221 220 225 232
   220 219 213 220 222 213 222 217 224 217 217 217 216 216 218 217 215 217 222
   216 229 218 218 222 367 230 220 222 221 218 225 221 222 231 229 228 225 223
   226 223 213 221 221 219 218 218 220 226 218 220 219 219 219 217 219 222 220
   223 215 223 219 218 219 220 218 221 225 231 224 221 233 245 230 229 235 224
   228 217 224 222 217 219 221 220 217 218 223 217 217 216 219 192 233 220 218
   219 221 184 229 235 231 170 212 209 224 216 216 218 216 215 219 219 213 230
   224 230 221 224 228 200 217 220 221 218 221 219 221 214 226 221 220 219 220
   218 220 220 219 226 219 220 218 221 220 221 217 225 228 225 222 219 234 194
   221 225 219 216 215 227 221 218 224 220 222 218 218 217 224 227 222 223 220
   223 219 216 220 220 223 231 203 194 228 229 222 220 232 219 224 221 219 221
   204 228 219 227 220 217 225 216 217 215 214 216 216 214 215 213 219 223 213
   216 218 215 214 210 216 216 213 224 216 213 215 209 226 219 216 224 218 224
   224 224 219 200 226 230 212 221 216 217 224 219 213 214 215 215 215 214 216
   210 219 214 218 214 215 214 215 223 219 182 223 214 223 218 230 220 217 219
   219 228 231 221 224 222 218 226 223 218 219 227 219 220 219 217 220 195 217
   218 219 225 210 220 220 220 218 218 222 220 218 224 216 223 204 228 207 228
   227 227 184 223 204 223 216 232 218 221 226 220 218 228 219 238 205 186 220
   221 225 213 225 222 220 216 217 216 222 172 213 222 220 221 223 221 218 215
   216 216 213 221 235 215 226 220 222 226 222 227 220 219 221 219 227 217 218
   216 220 220 218 218 220 221 222 222 220 219 222 218 212 224 218 221 229 222
   228 216 222 224 213 218 202 171 225 222 184 223 218 219 224 223 218 218 223
   220 217 220 220 223 219 235 226 221 221 218 220 142 226 223 232 229 222 221
   227 219 219 221 222 222 234 224 223 218 226 220 221 215 154 218 215 216 216
   213 221 215 160 215 216 215 214 213 218 216 215 225 216 216 215 212 215 216
   219 217 231 225 218 221 208 205 223 223 214 223 221 226 225 219 220 219 220
   220 220 226 225 228 219 225 220 219 219 217 215 225 215 220 210 220 217 188
   228 219 218 219 220 219 228 230 225 221 229 220 220 218 224 227 220 220 218
   219 219 218 218 217 219 231 222 219 219 220 220 218 211 220 217 228 225 189
   231 228 206 212 212 230 224 230 223 222 217 217 222 220 216 216 219 220 216
   217 214 216 217 222 213 214 216 223 213 224 216 213 217 207 224 220 219 222
   221 218 221 217 1658 182 219 216 229 198 225 221 219 216 214 215 219 220 217
   213 223 198 216 220 217 215 215 214 216 215 217 219 218 236 212 225 203 225
   221 224 215 218 219 216 197 226 221 228 220 220 220 219 221 223 218 213 220
   219 219 217 220 220 218 223 226 210 206 224 234 214 211 221 217 224 217 215
   218 214 159 215 230 226 221 225 221 222 220 223 209 222 220 219 221 225 220
   221 221 220 220 219 219 219 219 226 220 219 217 211 229 226 227 222 222 233
   231 221 217 221 224 223 227 195 223 215 222 218 219 219 220 219 219))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 232200 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61633920 :P50-TICKS 226 :P99-TICKS 279
 :LATENCY-TICKS
 #(237 251 224 218 222 217 215 214 213 216 211 207 287 281 279 280 276 277 279
   276 277 291 300 296 245 244 265 276 252 250 273 263 251 251 248 247 244 331
   247 234 236 229 232 229 226 230 222 226 230 227 229 250 232 230 228 230 205
   262 251 228 220 169 233 243 230 229 230 248 226 225 229 226 225 224 229 222
   226 219 223 223 223 225 227 223 232 235 269 204 237 225 221 228 224 234 224
   222 227 231 231 221 224 222 221 223 220 222 222 223 233 226 221 219 220 224
   225 220 220 221 220 221 218 221 221 222 220 226 222 222 219 228 197 215 207
   231 234 222 197 226 224 215 227 221 221 216 219 232 176 229 258 216 225 224
   220 225 222 218 221 221 220 220 220 236 231 245 231 227 226 230 233 221 227
   222 226 230 228 227 222 238 229 222 225 228 231 223 222 225 225 224 223 224
   228 226 226 229 223 223 223 227 225 223 222 241 232 220 244 232 242 235 215
   242 237 238 229 228 224 236 198 230 225 224 245 228 226 225 224 226 226 224
   226 234 240 234 235 227 224 221 229 222 221 222 232 233 234 234 228 227 231
   223 224 230 226 213 224 225 227 224 221 230 223 228 226 226 207 229 227 216
   234 225 232 228 237 203 232 228 231 171 235 237 218 237 229 210 222 221 224
   229 226 211 220 219 229 222 227 226 223 223 218 224 232 224 202 233 230 181
   229 234 223 220 226 223 222 212 219 222 209 228 228 222 235 233 227 230 230
   230 228 230 229 228 231 234 228 224 227 228 227 225 225 229 239 211 225 228
   225 234 230 245 229 216 218 188 225 235 238 239 240 166 232 234 234 226 228
   228 228 227 228 217 225 237 233 221 254 230 229 240 234 187 233 234 223 220
   226 222 216 220 223 215 220 227 232 232 227 224 234 230 226 227 230 230 227
   227 224 244 234 227 226 232 225 225 225 225 227 224 225 225 227 239 228 235
   228 235 202 320 228 237 228 233 230 227 223 222 228 224 221 224 225 219 223
   221 223 224 220 222 222 221 226 222 223 220 225 231 227 228 234 218 221 219
   224 224 223 224 222 214 229 240 225 230 228 231 229 230 229 229 225 232 227
   221 227 229 230 226 226 226 227 233 224 228 223 222 223 229 232 227 247 241
   200 198 213 242 215 219 225 211 233 229 224 232 226 222 226 226 224 236 233
   228 233 226 221 227 225 226 228 224 244 227 233 230 203 225 229 228 226 232
   228 245 236 230 215 225 219 229 222 219 222 220 226 223 221 218 221 221 222
   226 223 220 221 226 225 221 221 219 222 229 222 221 216 224 221 224 223 234
   252 224 220 233 230 223 208 225 225 222 225 223 220 221 219 223 225 225 240
   244 236 216 229 221 225 224 230 206 226 234 223 225 237 225 223 225 225 224
   224 229 227 212 219 232 220 222 217 227 233 220 221 194 222 222 219 224 222
   225 227 220 220 220 217 219 222 219 219 225 225 237 229 239 242 225 212 160
   236 226 227 231 234 222 224 222 219 226 218 226 223 212 220 222 223 219 221
   225 220 226 223 222 221 226 225 225 230 239 230 231 233 220 222 226 225 229
   230 235 241 229 237 218 226 226 228 228 228 229 234 228 229 229 218 225 227
   231 227 234 236 229 229 229 227 227 229 230 250 240 227 225 167 227 227 211
   231 228 216 223 227 226 234 230 230 226 227 223 229 234 226 225 234 227 230
   226 227 231 231 202 232 227 226 229 233 226 224 226 231 234 230 236 221 223
   225 228 227 222 230 227 217 221 220 222 222 219 221 221 227 219 219 220 222
   220 221 222 221 224 225 224 227 221 223 240 232 234 233 238 229 223 225 221
   226 229 220 223 221 223 220 222 220 219 238 220 207 255 233 238 232 222 222
   245 250 227 234 230 230 227 266 233 219 231 241 228 223 226 219 228 220 279
   248 227 225 213 206 281 220 239 222 223 223 225 221 232 236 220 225 222 221
   220 221 221 225 220 226 228 227 223 235 234 228 236 185 222 239 233 216 228
   225 229 196 228 226 225 220 224 226 222 224 228 227 226 224 226 230 225 221
   215 224 227 223 227 235 187 231 237 236 224 220 232 214 220 221 230 219 226
   235 231 225 214 223 228 219 223 218 224 220 218 222 220 221 220 221 217 219
   219 227 222 224 193 223 199 224 224 215 222 221 229 225 240 232 233 209 171
   223 229 213 234 236 230 235 226 224 233 223 224 231 224 225 227 225 226 228
   228 228 223 226 225 226 232 230 220 232 215 219 221 230 219 220 221 222 218
   235 224 230 227 223 231 209 222 225 229 223 226 223 227 227 222 225 227 225
   226 228 226 225 222 225 224 224 225 222 230 234 230 237 222 223 243))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 221279 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61573888 :P50-TICKS 222 :P99-TICKS 247
 :LATENCY-TICKS
 #(227 233 222 229 223 232 224 233 230 228 225 234 224 231 225 225 226 226 230
   223 230 230 224 189 241 230 228 224 230 228 225 224 223 226 241 235 232 237
   220 220 225 221 224 219 218 225 220 229 218 221 221 220 222 221 222 220 222
   224 222 219 222 222 220 221 220 213 225 223 226 224 228 232 191 234 199 223
   230 231 223 226 220 225 226 223 221 222 221 229 221 224 222 219 222 223 219
   222 220 228 215 225 229 222 230 223 222 213 229 224 230 222 223 238 223 237
   228 221 230 224 222 222 225 225 227 222 225 225 228 226 231 232 228 223 224
   225 229 232 217 224 224 223 227 231 234 233 231 215 215 220 234 236 253 240
   224 226 224 225 224 226 232 222 224 225 224 224 229 234 226 225 232 224 234
   232 234 234 232 228 239 235 215 218 221 228 227 234 231 224 222 220 227 221
   221 227 224 226 221 219 222 220 222 220 218 222 219 225 224 222 220 223 220
   220 221 217 221 227 224 230 230 225 197 240 210 239 227 228 199 227 232 227
   217 232 225 227 221 227 232 232 228 228 230 229 224 228 225 196 226 226 222
   230 224 226 229 226 228 207 232 224 222 224 223 227 236 234 233 214 226 232
   225 224 223 225 225 224 207 224 228 227 228 229 222 225 226 226 234 193 227
   234 222 202 226 234 230 229 232 233 236 190 150 166 238 204 231 230 211 228
   224 235 233 217 226 225 226 228 276 226 229 232 226 223 224 223 224 205 228
   222 234 236 224 226 231 226 224 223 227 233 232 225 225 222 221 220 223 226
   223 221 221 223 222 219 219 222 223 223 222 223 223 218 221 222 221 218 238
   223 221 220 227 218 228 224 221 232 214 223 223 229 225 226 217 237 231 226
   231 228 224 223 225 224 226 217 223 232 230 221 229 224 226 224 221 229 226
   233 218 224 224 231 225 224 224 225 226 236 237 170 228 234 225 223 223 221
   228 228 235 224 215 221 225 225 225 222 226 231 227 223 227 223 225 226 225
   224 233 233 243 240 227 214 223 236 224 235 298 234 302 219 226 230 221 222
   213 228 221 187 228 224 222 229 220 224 222 226 226 227 239 225 209 218 229
   235 221 150 140 147 138 142 147 139 142 145 139 136 136 167 156 170 168 180
   146 142 140 141 141 146 143 139 144 143 138 138 139 146 139 141 138 138 138
   141 141 139 141 143 167 146 177 167 160 141 140 149 140 149 144 144 140 144
   141 144 140 139 137 159 143 142 156 1924 170 184 152 148 145 145 166 144 142
   139 142 140 140 148 140 141 142 141 141 144 143 139 143 140 143 142 139 141
   152 143 141 141 141 141 152 153 146 155 147 145 144 158 140 144 236 231 233
   198 225 222 225 226 227 238 227 226 225 225 223 225 226 223 225 228 225 223
   225 224 227 224 227 224 224 224 227 229 231 223 224 230 232 241 238 247 237
   226 225 221 222 214 223 235 232 229 228 230 226 224 234 226 226 229 224 217
   225 227 224 226 226 224 228 230 224 222 223 226 249 233 232 230 238 220 224
   224 232 220 224 220 223 211 232 231 225 221 220 227 219 216 218 220 225 222
   219 221 218 220 216 220 220 217 222 222 226 219 221 219 219 219 219 233 344
   251 251 212 227 228 231 226 249 227 227 231 221 228 219 221 223 220 219 217
   220 217 218 219 223 217 215 218 200 221 216 219 218 217 224 221 220 224 233
   225 217 215 221 216 211 216 217 215 221 220 225 217 218 222 216 222 218 218
   216 224 219 216 219 217 216 217 216 218 218 222 219 208 217 217 215 218 220
   216 217 222 227 222 223 218 224 195 213 200 214 222 220 215 215 213 219 218
   223 217 216 219 225 215 218 219 217 220 216 218 218 213 228 220 218 204 215
   221 229 216 219 219 224 216 217 218 219 217 210 227 222 220 221 225 202 219
   212 218 218 218 216 219 222 215 218 219 217 219 218 217 219 216 223 217 217
   216 216 200 218 213 222 219 228 217 216 241 173 221 208 226 177 223 225 220
   148 217 216 219 215 213 212 213 214 216 214 214 209 215 213 214 214 213 215
   218 223 225 206 222 228 213 216 237 217 217 202 215 215 225 224 222 215 214
   214 213 214 213 213 217 214 213 212 214 214 213 217 215 213 213 215 214 214
   231 212 204 186 221 228 218 215 207 225 217 224 224 233 212 191 203 221 227
   220 222 219 155 227 213 213 223 212 213 215 216 221 215 218 222 221 214 213
   214 215 212 215 215 228 230 213 216 223 217 219 219 224 219 217 226 217 216
   223 221 219 214 211 224 219 219 207 219 217 213 212 214 215 212 213 219 214
   214 211 213 212 211 214 212 212 221 219 223 214 214 219 224 222 214))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 222232 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61633936 :P50-TICKS 218 :P99-TICKS 238
 :LATENCY-TICKS
 #(226 232 219 217 213 216 214 220 213 215 214 212 214 215 213 213 216 220 215
   212 209 213 213 213 217 221 200 213 224 215 215 217 212 200 214 213 215 214
   223 225 219 221 218 216 225 219 217 217 224 218 217 215 221 218 219 217 215
   218 221 220 217 218 218 217 217 218 218 216 220 213 219 229 223 216 183 216
   157 240 196 233 228 221 214 219 192 214 218 213 216 218 208 213 213 218 217
   214 212 217 215 221 214 216 213 218 177 177 224 216 221 204 222 221 219 217
   218 218 236 225 224 223 218 225 218 215 218 219 219 216 216 223 219 224 201
   193 258 227 252 225 223 218 217 216 218 214 216 214 238 218 222 218 219 266
   155 201 205 196 212 233 223 225 229 208 215 216 216 217 215 216 212 219 214
   213 214 215 213 212 211 214 215 212 220 217 217 213 213 218 217 223 223 152
   220 200 212 215 222 211 210 213 215 214 219 218 218 218 219 208 224 215 216
   218 216 218 216 216 218 217 216 219 218 222 226 223 219 218 219 218 218 216
   217 218 217 224 205 221 220 232 222 229 206 217 198 224 235 210 213 218 216
   224 215 217 219 222 216 217 217 216 216 221 217 221 218 224 217 216 218 220
   223 218 209 218 216 219 220 218 219 214 196 238 217 219 217 218 225 213 215
   215 213 216 212 215 214 219 215 215 212 214 213 213 215 212 213 220 212 215
   212 213 213 216 217 215 220 220 219 214 215 220 216 227 216 224 205 208 219
   219 220 214 213 212 215 215 215 213 216 216 211 214 212 216 220 214 213 218
   220 213 209 223 220 223 226 207 213 217 214 215 214 213 213 218 193 194 210
   220 223 207 245 213 232 233 221 227 224 223 226 221 216 219 218 220 224 215
   220 220 223 223 216 220 218 217 220 224 224 237 234 224 213 207 236 193 206
   222 220 223 225 220 213 222 215 213 209 216 222 213 222 216 218 209 214 214
   215 213 214 216 215 230 223 219 230 221 214 215 222 214 217 229 215 217 234
   218 222 216 212 213 216 212 214 219 213 214 214 216 214 212 215 222 215 214
   213 215 216 214 217 215 214 218 213 211 215 219 221 229 221 173 212 224 221
   203 216 209 219 220 218 219 219 222 221 214 224 218 218 219 220 219 218 226
   218 218 215 216 218 214 228 219 225 224 213 224 228 211 219 219 218 206 227
   213 220 216 215 223 216 215 213 216 215 214 217 215 212 214 214 215 216 214
   216 211 218 214 222 218 214 212 216 214 221 217 241 223 221 196 217 219 217
   215 219 225 224 221 220 219 222 218 217 220 218 222 228 227 224 212 217 227
   221 217 218 219 223 223 226 228 224 189 217 218 220 218 162 222 220 218 231
   222 226 231 192 204 227 212 228 221 222 219 221 227 224 225 219 218 218 219
   230 223 221 218 222 222 218 218 218 219 218 221 224 223 222 221 196 155 221
   216 216 211 214 215 214 223 215 220 215 217 207 214 213 218 213 222 220 215
   214 220 212 217 216 212 218 221 153 210 221 226 214 221 218 225 219 220 225
   223 193 228 224 217 214 218 214 215 216 206 216 214 215 215 213 214 216 215
   223 215 211 215 213 215 214 214 214 215 216 215 213 202 217 215 226 225 225
   203 201 221 200 218 222 223 219 218 216 222 224 218 219 220 218 218 217 219
   219 217 221 222 217 220 218 219 221 165 218 223 225 224 220 225 220 216 219
   221 220 231 210 218 220 215 226 220 214 216 216 220 220 221 218 220 218 219
   217 219 219 218 219 227 221 219 220 219 220 218 151 237 221 223 219 205 217
   186 220 218 217 227 226 231 220 218 222 222 218 222 217 219 220 224 215 226
   213 219 218 221 221 218 223 231 229 205 197 217 215 222 217 216 215 221 213
   214 224 223 235 204 225 219 247 239 229 226 230 184 219 219 221 223 220 223
   219 158 220 219 218 219 219 216 218 228 218 217 217 223 223 195 240 167 188
   212 225 223 208 221 223 228 220 215 214 214 223 193 213 214 213 214 213 226
   220 214 217 215 218 217 212 215 216 220 207 218 233 219 223 227 227 219 222
   218 218 223 235 225 222 208 215 222 209 223 222 217 220 213 221 217 214 214
   214 217 216 211 219 212 214 217 213 214 215 213 215 216 220 201 226 228 217
   216 194 202 216 217 184 222 218 222 227 221 219 226 218 222 220 223 220 219
   193 216 219 220 220 217 219 222 218 220 224 201 219 214 223 216 213 216 212
   216 217 216 217 184 221 212 221 224 227 221 220 209 217 223 217 215 217 223
   213 219 218 217 217 219 217 216 218 222 222 217 220 220 217 218 225 223 237
   226 229 226 210 220 187 204 217 217 218 223 221 218 226 223 218 218))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 227525 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61573760 :P50-TICKS 219 :P99-TICKS 294
 :LATENCY-TICKS
 #(212 220 219 216 218 219 218 219 210 225 195 221 234 222 199 236 212 213 215
   208 194 231 220 223 231 229 225 167 220 224 217 215 217 218 219 216 217 219
   216 217 218 219 219 221 217 218 218 219 219 218 224 214 218 217 222 222 218
   222 219 220 211 200 225 249 222 229 223 221 212 215 219 219 215 214 216 212
   214 213 214 213 216 214 213 212 212 220 221 213 213 231 220 220 228 218 224
   161 214 226 218 216 209 218 217 198 220 223 216 211 225 209 212 220 218 219
   210 215 220 219 210 216 213 220 214 211 215 214 213 220 207 215 214 222 218
   216 213 211 222 217 217 218 223 213 237 223 214 214 220 215 220 226 222 223
   216 218 217 216 216 218 216 220 219 220 213 218 217 218 217 217 216 221 218
   210 218 228 219 216 225 218 219 217 217 226 219 227 222 221 218 222 219 224
   218 222 217 219 237 217 217 218 217 216 218 219 217 215 217 218 216 217 216
   212 218 210 223 221 227 222 219 218 225 222 212 220 218 221 225 223 218 220
   223 219 218 221 216 215 219 216 217 221 218 218 222 224 219 219 222 229 219
   221 219 218 219 220 217 218 218 209 269 225 215 215 218 219 214 213 212 214
   213 219 222 224 242 217 216 216 208 222 1717 219 216 214 217 216 225 214 223
   230 209 213 221 225 220 214 218 222 218 220 230 218 224 229 225 220 218 218
   222 222 212 216 208 218 221 216 217 213 221 218 220 222 216 221 207 227 214
   216 218 222 217 218 218 218 219 232 222 222 174 220 222 217 210 212 215 215
   214 213 215 218 214 212 216 214 214 212 212 215 215 218 213 216 214 219 216
   213 204 219 217 233 229 191 215 215 216 185 206 228 215 185 213 191 216 220
   214 215 213 213 213 215 215 217 214 213 214 216 217 228 217 213 222 226 207
   218 221 220 222 224 219 219 222 218 219 235 212 221 218 220 223 218 220 219
   211 218 217 217 217 217 215 218 222 220 218 216 217 215 215 219 218 217 220
   224 218 222 218 224 217 191 211 217 222 219 208 223 221 223 220 208 224 221
   211 225 222 216 218 219 217 218 217 220 218 219 220 219 221 236 216 223 213
   210 142 186 224 221 219 218 216 238 219 220 222 230 220 218 168 217 217 223
   218 216 216 221 218 222 216 217 217 215 213 240 230 224 220 219 218 220 221
   219 220 217 218 223 224 223 218 221 223 212 225 225 221 221 205 218 231 182
   224 221 225 288 223 222 219 218 219 219 219 217 218 218 218 226 221 225 220
   220 217 222 220 220 221 211 259 235 236 177 214 219 221 249 216 207 199 246
   224 221 197 220 242 228 211 227 219 216 213 210 220 188 226 224 216 271 222
   222 234 221 215 225 225 222 224 252 227 223 222 222 220 217 219 189 223 220
   196 227 228 203 200 224 225 211 261 248 253 234 275 233 193 213 228 185 223
   215 234 222 216 224 216 220 237 219 219 223 232 226 222 213 174 217 212 212
   216 212 191 218 243 219 238 204 226 210 202 208 222 226 259 241 199 219 185
   204 231 221 219 215 221 243 234 223 225 213 230 235 240 256 222 219 215 184
   222 219 202 201 180 231 203 181 195 218 190 220 191 223 242 222 240 282 224
   221 242 239 380 286 262 294 259 257 193 228 241 232 225 236 249 223 216 221
   217 212 207 217 188 224 216 216 233 234 300 276 263 220 191 230 229 245 246
   230 226 226 232 221 219 210 223 225 256 199 206 175 223 225 233 227 228 216
   215 234 209 222 220 223 219 197 198 220 218 215 219 222 243 221 148 218 246
   222 216 214 183 227 213 191 206 225 243 220 224 227 237 198 183 297 284 261
   232 229 244 229 227 239 191 221 218 229 218 219 222 218 227 219 219 218 216
   219 216 214 216 216 220 215 214 217 220 227 229 224 226 216 230 226 223 220
   229 223 220 220 219 225 227 224 219 221 217 215 227 226 237 221 195 219 218
   222 202 226 220 222 223 218 193 221 217 221 219 290 225 220 215 268 215 216
   223 217 229 215 230 184 162 221 237 195 202 241 295 237 222 230 223 237 226
   231 246 274 323 259 308 244 247 249 241 199 231 192 225 212 233 232 226 218
   210 229 232 223 272 225 207 212 219 227 224 234 218 224 239 393 312 348 260
   254 235 287 205 221 205 221 187 218 217 193 220 223 204 206 222 223 221 221
   220 217 215 245 224 196 195 242 214 220 214 198 210 209 213 223 236 205 232
   226 210 134 272 248 226 242 234 210 241 222 220 215 246 247 226 188 217 222
   161 206 210 221 233 229 224 268 231 219 214 214 211 218 213 224 224 217 229
   234 229 207 219 218 216 210 216 214 222 219 207 195 228 220 219 235))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 226120 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61633760 :P50-TICKS 219 :P99-TICKS 284
 :LATENCY-TICKS
 #(235 222 220 238 234 222 219 223 218 176 225 237 260 230 223 220 220 224 230
   226 180 262 233 228 219 251 253 218 204 253 256 260 225 255 231 223 233 250
   160 161 194 233 273 223 223 230 216 202 219 237 187 216 216 199 218 217 229
   234 208 253 217 215 224 212 200 236 234 201 198 324 218 232 198 236 228 222
   223 214 223 187 225 223 218 216 200 217 230 224 221 263 228 220 218 227 219
   235 213 221 197 204 219 234 214 215 211 189 219 214 211 184 188 217 217 229
   224 250 217 157 240 230 149 217 196 213 195 245 180 221 179 241 269 168 294
   314 227 222 222 219 229 220 249 223 218 215 228 222 239 226 195 226 277 217
   217 218 218 221 226 225 204 245 237 222 236 284 323 222 220 217 226 227 212
   225 231 220 223 208 221 232 281 228 219 219 197 221 243 218 222 199 231 224
   224 218 237 223 221 219 209 215 218 219 216 219 205 214 218 222 204 245 258
   220 279 206 235 267 229 187 214 221 214 224 226 222 292 373 902 311 228 222
   223 223 220 218 217 219 219 215 186 217 195 223 219 218 243 232 215 241 225
   223 224 239 230 220 222 226 224 222 221 222 222 220 220 233 221 225 214 217
   220 217 222 223 218 221 215 209 216 213 216 215 215 220 213 214 216 213 215
   215 214 214 212 222 215 213 211 217 214 214 216 217 216 220 220 222 232 224
   218 226 199 184 209 216 221 225 226 218 224 175 228 220 215 216 215 214 210
   213 214 214 213 217 214 214 209 212 216 210 214 215 213 215 222 223 194 223
   225 221 214 223 220 246 233 229 230 221 235 217 236 225 221 225 219 221 227
   204 218 218 225 200 219 219 216 220 220 218 220 219 219 220 217 227 222 217
   203 216 221 221 216 219 221 223 209 221 225 194 205 222 225 218 212 220 221
   216 216 214 217 225 206 178 216 215 221 216 218 218 216 210 214 215 214 215
   216 215 214 216 205 209 220 190 216 222 219 227 217 220 218 219 218 229 221
   231 208 214 218 226 218 221 220 217 219 218 219 219 218 226 218 219 219 217
   216 218 219 216 217 223 217 218 217 218 221 216 222 222 224 221 228 220 184
   214 219 207 222 212 218 227 214 217 226 220 212 211 217 221 218 226 223 226
   218 218 224 219 219 217 219 222 224 224 222 227 217 208 216 220 216 222 215
   216 214 232 220 226 219 218 219 219 219 219 219 216 227 221 217 217 218 221
   218 212 217 217 218 218 218 224 219 225 218 218 217 185 224 213 221 222 220
   233 202 196 223 219 229 221 220 224 221 225 219 215 215 219 221 219 214 224
   221 221 194 212 186 197 227 239 194 227 200 227 224 216 213 224 215 217 215
   216 221 210 228 230 221 218 226 221 218 222 220 219 215 218 223 223 219 219
   220 220 219 219 201 218 218 217 219 222 219 216 219 220 222 220 221 225 221
   227 197 237 227 225 214 223 222 223 224 220 215 222 215 216 213 214 213 216
   216 220 214 219 216 214 218 215 215 214 213 226 212 228 210 217 222 221 227
   221 217 220 222 220 235 221 222 218 215 219 214 215 214 219 212 215 220 215
   215 216 215 213 214 214 215 214 222 219 213 218 214 216 235 214 214 170 219
   222 219 217 238 343 234 216 221 219 217 221 222 216 228 221 218 219 216 225
   223 218 219 220 220 218 220 206 219 216 219 228 171 217 223 230 216 215 216
   221 222 210 226 216 233 223 229 226 223 219 221 217 219 217 219 222 220 221
   206 217 218 218 218 221 217 218 217 218 218 216 229 228 224 217 223 240 227
   227 226 204 216 192 222 212 216 221 218 225 223 221 221 230 220 217 218 219
   219 216 219 220 225 208 215 220 225 215 217 217 237 212 299 234 240 245 231
   273 196 223 211 281 217 231 193 228 226 214 218 221 216 225 218 236 219 218
   217 217 216 215 215 220 211 216 216 219 214 215 213 214 215 222 213 217 215
   215 219 211 213 213 216 222 209 216 217 215 215 221 164 220 215 211 212 230
   235 211 225 224 221 225 217 222 222 216 221 220 231 224 168 220 219 218 223
   153 220 219 218 225 229 220 199 223 230 221 213 219 227 214 213 216 220 214
   218 230 215 225 219 219 226 194 217 219 223 218 219 219 219 219 218 219 219
   218 223 225 222 223 220 222 221 218 223 218 224 220 223 222 214 220 221 262
   224 218 222 220 221 217 220 216 215 226 216 216 222 211 215 218 216 216 214
   217 215 213 223 207 214 217 213 222 223 226 209 226 231 220 219 231 221 219
   222 223 223 236 221 224 219 217 229 221 220 218 221 223 225 220 220 221 219
   219 217 222 220 217 224 220 217 222 217 219 219 216 224 222 226 223))
(:KIND :PRODUCTION-LOCAL-TESTS :STATUS :PASSED :TESTS 6 :ROOT #A((55) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/\") :RETAINED NIL :PROCESSES ((:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-101\") :ROLE :SERVER :PID 75111 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-101/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v1-101.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--record-cache-budget\" #A((7) BASE-CHAR . \"4194304\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v1-101.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 1.964057d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/001-v1-server-101.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/001-v1-server-101.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 75111) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-102\") :ROLE :SERVER :PID 75137 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-102/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v1-102.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--record-cache-budget\" #A((1) BASE-CHAR . \"0\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v1-102.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 1.872875d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/002-v1-server-102.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/002-v1-server-102.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 75137) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-103\") :ROLE :SERVER :PID 75266 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-103/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v1-103.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((7) BASE-CHAR . \"4194304\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v1-103.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 6.869982d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/003-v1-server-103.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/003-v1-server-103.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 75266) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-104\") :ROLE :SERVER :PID 75735 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-104/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v1-104.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((1) BASE-CHAR . \"0\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v1-104.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 6.874651d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/004-v1-server-104.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/004-v1-server-104.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 75735) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-105\") :ROLE :SERVER :PID 76179 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-105/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v2-105.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--record-cache-budget\" #A((1) BASE-CHAR . \"0\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v2-105.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 1.890069d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/005-v2-server-105.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/005-v2-server-105.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 76179) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-106\") :ROLE :SERVER :PID 76321 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-106/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v2-106.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--record-cache-budget\" #A((7) BASE-CHAR . \"4194304\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v2-106.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 1.895741d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/006-v2-server-106.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/006-v2-server-106.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 76321) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-107\") :ROLE :SERVER :PID 76441 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-107/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v2-107.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((1) BASE-CHAR . \"0\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v2-107.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 6.83902d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/007-v2-server-107.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/007-v2-server-107.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 76441) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-108\") :ROLE :SERVER :PID 76882 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-108/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v2-108.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((7) BASE-CHAR . \"4194304\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/cache-runtime/v2-108.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 6.918217d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/008-v2-server-108.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6YNCN-1LYE-0/008-v2-server-108.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 76882) :RESPONSE NIL)) :SCENARIOS NIL :SIGKILLS 0 :CONDITION NIL :CLEANUP-ERRORS NIL :BENCHMARK NIL :POWER-LOSS-QUALIFICATION NIL)
(:KIND :CACHE-UNIX-BENCHMARK :STATUS :PASSED :SELF-TEST NIL :LIMITS
 (:LOCAL-C4 :SINGLE-SYNCHRONOUS-CLIENT :WARM-READS :CLIENT-ALLOCATION-ONLY
  :NO-LOAD-TAIL-QUALIFICATION))
"
 :STDERR "" :EXIT-CODE 0 :LIMITS
 (:COMMAND-OUTPUT-IS-RAW :WALL-TIME-INCLUDES-ENTIRE-COMMAND
  :NO-AUTOMATIC-REQUIREMENT-PROMOTION))
