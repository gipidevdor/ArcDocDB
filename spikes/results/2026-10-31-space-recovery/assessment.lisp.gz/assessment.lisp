;;;; Static review only; no Lisp/project code, tests, compaction, restore, or unlink executed.
(:schema-version 1 :kind :space-recovery-static-assessment
 :observed-at-utc "2026-10-31T16:07:18+00:00"
 :status :static-review-complete :apply-performed nil
 :candidate-file "candidates.lisp" :candidate-shape "(:schema-version 1 :files (repository-relative strings ...))"
 :candidate-file-sha256 "6d85ea169f09aa115b4c9d3e7f3c5624cb24ecb6643a55496471e0a059c5cf1c"
 :reviewed-reports 71 :selected 32 :deferred 39 :selected-original-bytes 9917305
 :selected-campaigns (("2026-10-31-local-index-bench" 14) ("2026-10-31-local-performance-fix" 18))
 :selected-byte-snapshot-sha256 "b80bdb468282fcab3e17f765f5555dc4832a436b7e62d548abcdc6e2f53bb306"
 :snapshot-method "SHA256 of ordered path NUL SHA256(plain bytes) LF; caller produces authoritative pre/post file baselines."
 :selection-proof
 ("Ancestor inventory screen covered all 71 reports through repository root. No applicable archive-index/CI manifest/closed stored-byte catalogue governs the selected 32."
  "Both driver-manifest.json files attest drivers/method/helpers, not selected report bytes. Component inventories and validation/cleanup records retain metrics/outcomes. Existing compaction records attest result.lisp payloads, not these report.lisp files."
  "Ordinary-text checkout scan found no literal SHA256/Git-blob references to the 71 candidate streams. Known closed archives are separate scopes; CI is excluded."
  "local-index-bench: validate-archive.lisp:4-15 reads ten selected command reports through read-evidence; component-summary.lisp:4-8 reads four component reports the same way."
  "local-performance-fix: validate.lisp:5-23 reads sixteen selected command reports; :36-44 and component-summary.lisp:4-8 read two component reports, all through read-evidence."
  "Generic direct readers in mutation drivers operate on their own produced reports; no binding to selected paths was found. The other 39 were screened but their reader contracts were not qualified; they remain excluded.")
 :estimate (:method :in-memory-gzip9-plus-350-byte-descriptor :saved-bytes 7190865)
 :reviewed-drivers
 (
  (:file "reclaim.lisp" :bytes 11958 :sha256 "719a3f4202e683d9b1b839d7fce884e05120f1c171c115c6627eb4c3c783b88d")
  (:file "compact-results.lisp" :bytes 4625 :sha256 "ffff9c74c6d7a0d4cb2ee3e6f67a996f116f8ae2b6b74b11f51ed680b8e40fef")
  (:file "method.lisp" :bytes 1539 :sha256 "bf8eb24852d32c04c54d3a1adc15d713b3d6c3b19579016cbd03b25b5c2158ec"))
 :reclaim-review
 (:parenthesis-fix :confirmed-at-lines-67-72
  :delimiter-screen :balanced
  :restore "Explicit allowlist, TAR/zstd roundtrip, independent extraction and all restored path/size/SHA comparisons precede source metadata/SHA and owner-PID recheck, then unlink."
  :pruning "walk-empty is called only beneath *prune-roots* populated by successfully selected completed directories; no global prune walk. STAT-BLOCKS is absent."
  :scope-caveat "SAFE-STAT at :19-22 checks the leaf only; no complete no-symlink ancestor/confinement guard. Execution in the intended physical primary roots with unchanged ancestry remains an operational prerequisite."
  :concurrency "Tracked status is checked before archiving, not again at unlink; the bulk source/PID gate still has a pathname TOCTOU window. Caller must quiesce writers/index changes. Loose old logs/FASL have age guards, not standard-run owner/terminal guards.")
 :compact-results-review
 (:delimiter-screen :balanced
  :standard-compactor t :workers 4 :source-fork-or-eval nil
  :bootstrap "Ordinary LOAD uses bound uiop:*command-line-arguments* and empty-compactor/. Keep this directory genuinely empty; ensure-directories-exist does not itself prove emptiness."
  :sealed-guard "Runtime ancestor archive-index.lisp rejection added at :21-25. Exact static selection remains these two campaigns only."
  :verification "Every selected original is compared after decompression to reclaim's published-before bytes/SHA; shasum --check verifies every preexisting nonselected file."
  :protected-baseline-scope "As agreed: attests preexisting files only. New additions from other chats are outside this check; any all-archives-unchanged wording must be read with this scope."
  :other-lisp-errors-found nil)
 :method-review "Consistent with original compact-many/4 workers and declared SOURCE-ID change. Terminal/PID clauses describe standard runs; loose logs/FASL retain their narrower age-only selection semantics. Existing reader/checker controls are future verification, not executed evidence."
 :residual-risks
 ("Static scope is the observed primary checkout; unknown external readers are not covered. Caller owns immutable input assurance, recoverable archive, and before/after SHA collection."
  "No selected result, product code, versioned tool, or reviewed driver was changed by this agent. Only candidates.lisp and assessment.lisp were written."
  "Non-CI result representation changes tracked blobs and future CI SOURCE-ID. Preserve historical attribution; concurrent primary documentation changes may independently change it."
  "Compactor guarantees verified bytes and exclusive sidecar creation, not power-loss durability; compact-many itself bypasses automatic age/PID candidate filtering.")
 :runtime-execution nil :tests-run nil :results-mutated nil :deletions nil)
