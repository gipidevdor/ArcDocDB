(:KIND :PUBLISHED-FILES-BEFORE :FILES
 ((:PATH "spikes/results/2026-10-23-attuali/README.md" :BYTES 2871 :DEVICE
   16777232 :INODE 1557816984 :MTIME 1793395837 :SHA256
   "af72c2f1bdcd46e1295d3ce1d259e90af4b79137eb91c98ff85d35bd239d51ad")
  (:PATH "spikes/results/2026-10-23-attuali/catalogo.lisp" :BYTES 460 :DEVICE
   16777232 :INODE 1557815916 :MTIME 1792787562 :SHA256
   "912b5b63b42f49e5cd08e03a1fb82e7e62fff687f8b4a88eb89556eb97fcaefe")
  (:PATH "spikes/results/2026-10-23-attuali/ci-repack-source.txt" :BYTES 2155
   :DEVICE 16777232 :INODE 1557826286 :MTIME 1792787562 :SHA256
   "b12b7675d28b771b0bab8d7fd605fd591e7b935cde946daba6a08887ed12eb6f")
  (:PATH "spikes/results/2026-10-23-attuali/ci-repack.lisp" :BYTES 627 :DEVICE
   16777232 :INODE 1557826285 :MTIME 1792787562 :SHA256
   "681274a14640a241168cb347da22b3e355accfb41bf872934839240cd1ae9b5a")
  (:PATH "spikes/results/2026-10-23-attuali/ci-selftest.lisp" :BYTES 632
   :DEVICE 16777232 :INODE 1557825763 :MTIME 1792787498 :SHA256
   "3bf53e3748c34568e0fb83b9f6f7ed394be5c711a74ca8b7bdde88a45f49bc23")
  (:PATH "spikes/results/2026-10-23-attuali/report.lisp" :BYTES 317 :DEVICE
   16777232 :INODE 1557825764 :MTIME 1792787498 :SHA256
   "f169873ab02b033ccbb65d194689ee5c9e24815a32ecab424097bedbeb457c69")
  (:PATH "spikes/results/2026-10-23-attuali/report.lisp.gz" :BYTES 379261
   :DEVICE 16777232 :INODE 1557825765 :MTIME 1792787498 :SHA256
   "a7ca1427b21529d9413a2deb5f864ea2fc20e315b54808cb507ccae6d6baee08")
  (:PATH "spikes/results/2026-10-23-attuali/risultati.lisp" :BYTES 3085 :DEVICE
   16777232 :INODE 1557815915 :MTIME 1792788156 :SHA256
   "a1923cc9fb74510e0e56e31b7153dba010b9d88acfa983873b5cf6412c4d5f49")
  (:PATH
   "spikes/results/2026-10-24-page-cache/allocation-run/conservazione.lisp"
   :BYTES 1068 :DEVICE 16777232 :INODE 1560114489 :MTIME 1793207956 :SHA256
   "759361594683648000ff522c9ffaad502d8273758abefbc98cf5dd2071579ca9")
  (:PATH "spikes/results/2026-10-24-page-cache/allocation-run/report.lisp"
   :BYTES 296822 :DEVICE 16777232 :INODE 1560114490 :MTIME 1793207956 :SHA256
   "cfe1e2afc281159118a60b05b23253f85678b5282cba42488de805bf3b673ba4")
  (:PATH "spikes/results/2026-10-24-page-cache/allocation.lisp" :BYTES 975
   :DEVICE 16777232 :INODE 1560114491 :MTIME 1793207956 :SHA256
   "bdecefb59cf79e98f246f2f1b00b5380c6b737a22a51327e266edd95e20b6166")
  (:PATH "spikes/results/2026-10-24-page-cache/check-run/conservazione.lisp"
   :BYTES 1628 :DEVICE 16777232 :INODE 1560114493 :MTIME 1793207956 :SHA256
   "ffbb964ad9eafd85aaea54f1df1a3489d38a563423439967dc743d82c7641fcd")
  (:PATH "spikes/results/2026-10-24-page-cache/check-run/report.lisp" :BYTES
   317 :DEVICE 16777232 :INODE 1560114494 :MTIME 1793207956 :SHA256
   "c039fe5b7782ce3e6ef1c9f13325d360d49cbaf602ac9953aa11dbfb6899c215")
  (:PATH "spikes/results/2026-10-24-page-cache/check-run/report.lisp.gz" :BYTES
   298666 :DEVICE 16777232 :INODE 1560114495 :MTIME 1793207956 :SHA256
   "23a2f1766e7fc9940453394a706ce541bd81b288b984d14dd83c5aef70d31c53")
  (:PATH "spikes/results/2026-10-24-page-cache/recording-path-rejected.log"
   :BYTES 3583 :DEVICE 16777232 :INODE 1560114496 :MTIME 1793207956 :SHA256
   "6fdc75a0be8d53747e0391195e29a36ac759cd8bf89dbf448f8b3db6810bd4b2")
  (:PATH "spikes/results/2026-10-24-page-cache/report.md" :BYTES 1973 :DEVICE
   16777232 :INODE 1560114497 :MTIME 1793207956 :SHA256
   "da850fecf5f92cc3ce94d468b8f4b57cea27e10257ad786ca7909825cf598681")
  (:PATH "spikes/results/2026-10-24-page-cache/targeted-run/conservazione.lisp"
   :BYTES 1063 :DEVICE 16777232 :INODE 1560114499 :MTIME 1793207956 :SHA256
   "1844bcc53de6c24c228cbcee942b7120e86043c67d3565684ec831e3e048a167")
  (:PATH "spikes/results/2026-10-24-page-cache/targeted-run/report.lisp" :BYTES
   298335 :DEVICE 16777232 :INODE 1560114500 :MTIME 1793207956 :SHA256
   "3d1db40357adb2b31dd0722dcd1af8bad0e6f95e77d75fd3d49f893b02ae8e8c")
  (:PATH
   "spikes/results/2026-10-24-page-lookup/allocation-run/conservazione.lisp"
   :BYTES 1071 :DEVICE 16777232 :INODE 1560114503 :MTIME 1793207956 :SHA256
   "4b8bdd7853ffbddeb0ed500c2196d3efc35c004608339bcfbe1d845d78b07017")
  (:PATH "spikes/results/2026-10-24-page-lookup/allocation-run/report.lisp"
   :BYTES 298526 :DEVICE 16777232 :INODE 1560114504 :MTIME 1793207956 :SHA256
   "f227beaaf93e2ffc63956590df3b218856a42d877cbb20657d48a3faa0eec49c")
  (:PATH "spikes/results/2026-10-24-page-lookup/allocation.lisp" :BYTES 1629
   :DEVICE 16777232 :INODE 1560114505 :MTIME 1793207956 :SHA256
   "e442364a974a9f8c66f0dbe262b8506a8cd3228c5664db2c960794eb042c2ee1")
  (:PATH "spikes/results/2026-10-24-page-lookup/attempt-1-read-error.log.gz"
   :BYTES 22649 :DEVICE 16777232 :INODE 1560114506 :MTIME 1793207956 :SHA256
   "6cac754697b9254f75ee7dbfb91ee707981a41866728bb4cac974ce472a1a6d8")
  (:PATH "spikes/results/2026-10-24-page-lookup/attempt-2-key-fixture.log.gz"
   :BYTES 138787 :DEVICE 16777232 :INODE 1560114507 :MTIME 1793207956 :SHA256
   "57399cee40fb5c00f7dc9d884081b4f4121ffd78e7ddeeedd11ef05d05342c2b")
  (:PATH
   "spikes/results/2026-10-24-page-lookup/attempt-3-resident-budget.log.gz"
   :BYTES 6199 :DEVICE 16777232 :INODE 1560114508 :MTIME 1793207956 :SHA256
   "a5980fdb621caf591d22f97791f3922a3fd89d9b47bcbedf5231dd783386f604")
  (:PATH "spikes/results/2026-10-24-page-lookup/check-run/conservazione.lisp"
   :BYTES 1636 :DEVICE 16777232 :INODE 1560114510 :MTIME 1793207956 :SHA256
   "ce6ea3b101482fd9211fcdef8a853719b2c3920383fe30e50d475d1fad47b8ea")
  (:PATH "spikes/results/2026-10-24-page-lookup/check-run/report.lisp" :BYTES
   317 :DEVICE 16777232 :INODE 1560114511 :MTIME 1793207956 :SHA256
   "a155271fc3b1a67df039b84d42a7ab2de802c9314b9acb881e249001d014265a")
  (:PATH "spikes/results/2026-10-24-page-lookup/check-run/report.lisp.gz"
   :BYTES 302115 :DEVICE 16777232 :INODE 1560114512 :MTIME 1793207956 :SHA256
   "d327f1d5278b7bd53e550253e1c6f86fe57d8aa009c77a3c00c6b85847607a4b")
  (:PATH "spikes/results/2026-10-24-page-lookup/report.md" :BYTES 3408 :DEVICE
   16777232 :INODE 1560114513 :MTIME 1793207956 :SHA256
   "d8d8e416e1d160785c79331c9d9fa84f3037027d39792f96c2c94c13dfc0e2f7")
  (:PATH
   "spikes/results/2026-10-24-page-lookup/targeted-run/conservazione.lisp"
   :BYTES 1067 :DEVICE 16777232 :INODE 1560114515 :MTIME 1793207956 :SHA256
   "f8b1e4cc171462eeab1f4c6a4253b7d59c6dba2a0e3684c00b8f3b46e2e0cc65")
  (:PATH "spikes/results/2026-10-24-page-lookup/targeted-run/report.lisp"
   :BYTES 905308 :DEVICE 16777232 :INODE 1560114516 :MTIME 1793207956 :SHA256
   "9a9d8240ec007d2241df51c7e60f7f0e89c9161dd6260d5257df9652e7186377")
  (:PATH
   "spikes/results/2026-10-28-index-images/allocation-run/conservazione.lisp"
   :BYTES 1073 :DEVICE 16777232 :INODE 1560159346 :MTIME 1793213452 :SHA256
   "ec3cd36b3ab89b1adb5366bc103a8576188ffd91c834a64f2d67b012a4bcd5c2")
  (:PATH "spikes/results/2026-10-28-index-images/allocation-run/report.lisp"
   :BYTES 303703 :DEVICE 16777232 :INODE 1560159347 :MTIME 1793213452 :SHA256
   "a66523877c6d5880261b55d4c12367d06a485ece5088f38e0c1fe7a1d5dc28b9")
  (:PATH "spikes/results/2026-10-28-index-images/allocation.lisp" :BYTES 1271
   :DEVICE 16777232 :INODE 1560153337 :MTIME 1793213192 :SHA256
   "a04439e0b5a7b506b56ba05f5034bb093c8489d4672af9c3885afe3e7282c8b5")
  (:PATH "spikes/results/2026-10-28-index-images/attempt-1-lookup-block.log.gz"
   :BYTES 23167 :DEVICE 16777232 :INODE 1560158632 :MTIME 1793213385 :SHA256
   "7d9ca82ca6d16352fc67f46e1cfe3a21b0566df6d18eaa66eb9f43094fd9b4a5")
  (:PATH "spikes/results/2026-10-28-index-images/attempt-3-test-parens.log.gz"
   :BYTES 3653 :DEVICE 16777232 :INODE 1560158633 :MTIME 1793213385 :SHA256
   "0832f9ed58fc614e14bf34f880ae2923b65b2972c21a32820913e851ef5031c3")
  (:PATH "spikes/results/2026-10-28-index-images/check-run/conservazione.lisp"
   :BYTES 1634 :DEVICE 16777232 :INODE 1560177766 :MTIME 1793213913 :SHA256
   "1b590e51b92dd1ce6097043e757d6631398b9afa305f1d5f6169579cc668acc5")
  (:PATH "spikes/results/2026-10-28-index-images/check-run/report.lisp" :BYTES
   317 :DEVICE 16777232 :INODE 1560177768 :MTIME 1793213913 :SHA256
   "dacca14a836a32a2b96251006124f9251da7366fbebed2cce2da2c048dec7df9")
  (:PATH "spikes/results/2026-10-28-index-images/check-run/report.lisp.gz"
   :BYTES 311029 :DEVICE 16777232 :INODE 1560177767 :MTIME 1793213913 :SHA256
   "3584505011ddd8a8a483fd17cff784a23f4a621366a8859ea04c044e04140664")
  (:PATH
   "spikes/results/2026-10-28-index-images/lookup-allocation-run/conservazione.lisp"
   :BYTES 1087 :DEVICE 16777232 :INODE 1560159349 :MTIME 1793213452 :SHA256
   "0aa50a9bd6a5613face225334c509088cd6dbb4dbc67c0817812cc0116681bcb")
  (:PATH
   "spikes/results/2026-10-28-index-images/lookup-allocation-run/report.lisp"
   :BYTES 303833 :DEVICE 16777232 :INODE 1560159350 :MTIME 1793213452 :SHA256
   "92f224f3fd2000f82b8fb8e9d5e3a8947722f9e9e80cd6d3034f1b82e4fcf4cd")
  (:PATH "spikes/results/2026-10-28-index-images/report.md" :BYTES 4759 :DEVICE
   16777232 :INODE 1560159351 :MTIME 1793213914 :SHA256
   "3536e499592fd79332c7b69840c1b6fad28abe7fc39f046f0ec1959c9c34931c")
  (:PATH
   "spikes/results/2026-10-28-index-images/targeted-run/conservazione.lisp"
   :BYTES 1069 :DEVICE 16777232 :INODE 1560159343 :MTIME 1793213452 :SHA256
   "2b1532a63c66705259f7045a16b8c9e9cb59978f6f8623c403b64426fdf77a54")
  (:PATH "spikes/results/2026-10-28-index-images/targeted-run/report.lisp"
   :BYTES 308410 :DEVICE 16777232 :INODE 1560159344 :MTIME 1793213452 :SHA256
   "c12e2608a568db76e59528f3ea976fdba6e5dba9c767a298626374a42da8e1b3")
  (:PATH "spikes/results/2026-10-28-page-build/check-run/conservazione.lisp"
   :BYTES 1636 :DEVICE 16777232 :INODE 1560145234 :MTIME 1793209169 :SHA256
   "cba58782b7c04348cd7d0f80bcdee5622ee0f8fd94872840f569996b046da93f")
  (:PATH "spikes/results/2026-10-28-page-build/check-run/report.lisp" :BYTES
   317 :DEVICE 16777232 :INODE 1560145236 :MTIME 1793209169 :SHA256
   "4a39c589fe65a4108d0fe28b17dc4cff13cb45f1f7a01c059a9ea7b2461b7381")
  (:PATH "spikes/results/2026-10-28-page-build/check-run/report.lisp.gz" :BYTES
   306417 :DEVICE 16777232 :INODE 1560145235 :MTIME 1793209169 :SHA256
   "0554168564af1b7d589053d436fed80dae6fb1bd7c7ad6a4b58c29121068c742")
  (:PATH "spikes/results/2026-10-28-page-build/report.md" :BYTES 2737 :DEVICE
   16777232 :INODE 1560126474 :MTIME 1793209170 :SHA256
   "0758d0d4eac7d30a9c09d98974432ced95c494fb42d6e653c0296c0213b96523")
  (:PATH "spikes/results/2026-10-28-page-build/targeted-run/conservazione.lisp"
   :BYTES 1615 :DEVICE 16777232 :INODE 1560126471 :MTIME 1793208712 :SHA256
   "7c4c36143725d5c986f28804f6c8db71e0a1453220f49b62616dc07154a919ad")
  (:PATH "spikes/results/2026-10-28-page-build/targeted-run/report.lisp" :BYTES
   317 :DEVICE 16777232 :INODE 1560126473 :MTIME 1793208712 :SHA256
   "b702c07ec44f40f86befe6204267ce7f5012078fcee9d3ce62c8c0fefa01b71c")
  (:PATH "spikes/results/2026-10-28-page-build/targeted-run/report.lisp.gz"
   :BYTES 138022 :DEVICE 16777232 :INODE 1560126472 :MTIME 1793208712 :SHA256
   "b65c55e64f92f7e98bdcbec31f1fbb8c7e5d58026cb34756f990699d77ceef42")
  (:PATH
   "spikes/results/2026-10-29-engine-image-activation/allocation-run/conservazione.lisp"
   :BYTES 1095 :DEVICE 16777232 :INODE 1560362371 :MTIME 1793292314 :SHA256
   "a0b31b25888952c5e6d41c6386428fa35b7b2eb7675d4035216dedb2be365645")
  (:PATH
   "spikes/results/2026-10-29-engine-image-activation/allocation-run/report.lisp"
   :BYTES 307333 :DEVICE 16777232 :INODE 1560362372 :MTIME 1793292313 :SHA256
   "31b5afedae188cacc995022f2c0871b7b79c3b73442eb84750f61a68903f3962")
  (:PATH "spikes/results/2026-10-29-engine-image-activation/allocation.lisp"
   :BYTES 2007 :DEVICE 16777232 :INODE 1560360448 :MTIME 1793292219 :SHA256
   "73dec583d98a151ffb6745706cfe8f158d7890e4e4eff748c6f2481469a5c48c")
  (:PATH
   "spikes/results/2026-10-29-engine-image-activation/attempt-2-test-parentheses.log.gz"
   :BYTES 2526 :DEVICE 16777232 :INODE 1560361574 :MTIME 1793292311 :SHA256
   "d44e14a8947e83d7df768520192fdca3414c242412eef3c7b13102a72acb43c7")
  (:PATH
   "spikes/results/2026-10-29-engine-image-activation/check-run/conservazione.lisp"
   :BYTES 1636 :DEVICE 16777232 :INODE 1560404449 :MTIME 1793293055 :SHA256
   "a386c31e6210f5b0e4e204ce94c7ce8bc6196e9f260bb3cc59e9fb800ebc76d5")
  (:PATH
   "spikes/results/2026-10-29-engine-image-activation/check-run/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1560404451 :MTIME 1793293055 :SHA256
   "a4f675d9a30b873457bcf90a92c38b16aff28d83c660d30928506174e68be42d")
  (:PATH
   "spikes/results/2026-10-29-engine-image-activation/check-run/report.lisp.gz"
   :BYTES 318787 :DEVICE 16777232 :INODE 1560404450 :MTIME 1793293055 :SHA256
   "25980d73ae952a69c1bcb7a5141722676be17886069a8f224a17978ddae3a52c")
  (:PATH "spikes/results/2026-10-29-engine-image-activation/report.md" :BYTES
   5423 :DEVICE 16777232 :INODE 1560362373 :MTIME 1793293110 :SHA256
   "6dffee8b3058496d19b528b4400859e98359981938fbb31b068eb87a0e8100a6")
  (:PATH
   "spikes/results/2026-10-29-engine-image-activation/targeted-run/conservazione.lisp"
   :BYTES 1091 :DEVICE 16777232 :INODE 1560361572 :MTIME 1793292266 :SHA256
   "56d23d9576c94c5c0ac1f7f410988c186dd3543de5c98ff2079f96076e050c5b")
  (:PATH
   "spikes/results/2026-10-29-engine-image-activation/targeted-run/report.lisp"
   :BYTES 309652 :DEVICE 16777232 :INODE 1560361573 :MTIME 1793292266 :SHA256
   "e4633c64607c032b0f30cbab41a42dcf25f43316448d832a1b3f7e1f5c259b26")
  (:PATH "spikes/results/2026-10-29-engine-image-activation/targeted.lisp"
   :BYTES 810 :DEVICE 16777232 :INODE 1560360447 :MTIME 1793292219 :SHA256
   "9c6a65c02121b28e1a9d7a02468f6bc30149fb070b15f9cebd952f8a5da45713")
  (:PATH
   "spikes/results/2026-10-29-engine-image-build/allocation-run/conservazione.lisp"
   :BYTES 1085 :DEVICE 16777232 :INODE 1560268807 :MTIME 1793260286 :SHA256
   "2bdc9a2b83568fb679cc32d0537ce9d6ffdb0e4dae79d5a0e82f94bec84e3f1c")
  (:PATH
   "spikes/results/2026-10-29-engine-image-build/allocation-run/report.lisp"
   :BYTES 306384 :DEVICE 16777232 :INODE 1560268808 :MTIME 1793260286 :SHA256
   "6aadf20570fbe483daa7d197f990a34314f312502c8effe8fc3353443afcad06")
  (:PATH "spikes/results/2026-10-29-engine-image-build/allocation.lisp" :BYTES
   1216 :DEVICE 16777232 :INODE 1560267684 :MTIME 1793260209 :SHA256
   "f84ae7c2144a0909f4b3e9ab65c9e536ff0d363eb73b180a02a60ed5db69c160")
  (:PATH "spikes/results/2026-10-29-engine-image-build/attempt-1-lint.log.gz"
   :BYTES 215 :DEVICE 16777232 :INODE 1560268617 :MTIME 1793260284 :SHA256
   "dff8dd503d8d01e0bc2f7b8588f2154525200a8b1aa18c521fc6ee9e10c9ad63")
  (:PATH
   "spikes/results/2026-10-29-engine-image-build/attempt-1-test-parentheses.log.gz"
   :BYTES 149735 :DEVICE 16777232 :INODE 1560268612 :MTIME 1793260284 :SHA256
   "80f77104a0174d0b6606a8b8d713904007b60ec3753008223d28cfe155e0890c")
  (:PATH
   "spikes/results/2026-10-29-engine-image-build/attempt-3-span-sentinel.log.gz"
   :BYTES 121776 :DEVICE 16777232 :INODE 1560268613 :MTIME 1793260284 :SHA256
   "98328ceee9c4981a2eba43d336161565751d6b687bdaf6208dffe8aa3c7fd275")
  (:PATH
   "spikes/results/2026-10-29-engine-image-build/check-run/conservazione.lisp"
   :BYTES 1635 :DEVICE 16777232 :INODE 1560293089 :MTIME 1793260964 :SHA256
   "85a9ea7726307518cbf1e61c80f5d8b9b561e3ee81abe23bf691b4083c353a1a")
  (:PATH "spikes/results/2026-10-29-engine-image-build/check-run/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1560293091 :MTIME 1793260963 :SHA256
   "fa5865c3af15c7b30d1101201934b5957d2359307351d5530ab3573ac17b615c")
  (:PATH
   "spikes/results/2026-10-29-engine-image-build/check-run/report.lisp.gz"
   :BYTES 317175 :DEVICE 16777232 :INODE 1560293090 :MTIME 1793260963 :SHA256
   "d23b8aa780bd53889b720f54f44a8a887e79797111f2ff537723ec21070b98c3")
  (:PATH "spikes/results/2026-10-29-engine-image-build/report.md" :BYTES 5540
   :DEVICE 16777232 :INODE 1560268809 :MTIME 1793261037 :SHA256
   "26b41ecd0e1b54c30498e4e336678f557bcd599bc13ff24093d796cc83812ceb")
  (:PATH
   "spikes/results/2026-10-29-engine-image-build/targeted-run/conservazione.lisp"
   :BYTES 1081 :DEVICE 16777232 :INODE 1560268610 :MTIME 1793260262 :SHA256
   "d59be947f454671ffb8b5d306454415f27dcf6ff7e0a7ef2c1cb289bd80dc0a7")
  (:PATH
   "spikes/results/2026-10-29-engine-image-build/targeted-run/report.lisp"
   :BYTES 313539 :DEVICE 16777232 :INODE 1560268611 :MTIME 1793260262 :SHA256
   "4b7fd7dcbd92d5e32f3f408dfbac8fd054c314745824e9ce2a859e32e3d1cd53")
  (:PATH "spikes/results/2026-10-29-engine-image-build/targeted.lisp" :BYTES
   788 :DEVICE 16777232 :INODE 1560267682 :MTIME 1793260209 :SHA256
   "99dd7642f286d034f9e810f706c0523da05452d991c1f2dbe46d04f5eacb666f")
  (:PATH
   "spikes/results/2026-10-29-engine-image-delta/allocation-run/conservazione.lisp"
   :BYTES 1085 :DEVICE 16777232 :INODE 1560941760 :MTIME 1793305186 :SHA256
   "a195dba947a49f17c6c90200ee3d32e25de74c0779ba2b23d21d66dd2c8cf367")
  (:PATH
   "spikes/results/2026-10-29-engine-image-delta/allocation-run/report.lisp"
   :BYTES 308589 :DEVICE 16777232 :INODE 1560941761 :MTIME 1793305185 :SHA256
   "4ad0faae35c031f7e014abab41c6a2e56accd484c0c2f9ef3249fd7551f76938")
  (:PATH "spikes/results/2026-10-29-engine-image-delta/allocation.lisp" :BYTES
   2321 :DEVICE 16777232 :INODE 1560932186 :MTIME 1793305098 :SHA256
   "b5043a1cbc9aa13138a2672accdac17f1e7ec470bd181c8c14bb7d9c5920fe74")
  (:PATH
   "spikes/results/2026-10-29-engine-image-delta/attempt-2-test-parentheses.log.gz"
   :BYTES 1805 :DEVICE 16777232 :INODE 1560935326 :MTIME 1793305159 :SHA256
   "3d79aabed63f13d3736b9cf8d6a4cf83bc8858797e93095f2308345c5a03795d")
  (:PATH
   "spikes/results/2026-10-29-engine-image-delta/check-run/conservazione.lisp"
   :BYTES 1636 :DEVICE 16777232 :INODE 1561211781 :MTIME 1793305881 :SHA256
   "46ff997c39282be26af7017957650e147f48c5b6905e3fb446f720edbbab2d46")
  (:PATH "spikes/results/2026-10-29-engine-image-delta/check-run/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1561211783 :MTIME 1793305880 :SHA256
   "2a2db56eab66f54eb33008844af93b0e1475e9729609acd337bdab875afac545")
  (:PATH
   "spikes/results/2026-10-29-engine-image-delta/check-run/report.lisp.gz"
   :BYTES 319656 :DEVICE 16777232 :INODE 1561211782 :MTIME 1793305880 :SHA256
   "5014d3d7b55c864a47943b895f6705c74dd5b46e06201f72f11c7e58dc1ea715")
  (:PATH "spikes/results/2026-10-29-engine-image-delta/report.md" :BYTES 3678
   :DEVICE 16777232 :INODE 1560929061 :MTIME 1793305918 :SHA256
   "9a4a12764339d93277212cf212935e52d799e81718fcdff017e36110090ed240")
  (:PATH
   "spikes/results/2026-10-29-engine-image-delta/targeted-run/conservazione.lisp"
   :BYTES 1081 :DEVICE 16777232 :INODE 1560941757 :MTIME 1793305231 :SHA256
   "6204121b5e1a13d04cb53d4be4ee75f40932f2dd03889bb1022eef95d4510707")
  (:PATH
   "spikes/results/2026-10-29-engine-image-delta/targeted-run/report.lisp"
   :BYTES 310464 :DEVICE 16777232 :INODE 1560941758 :MTIME 1793305231 :SHA256
   "75f26ef3316967bc981adbfe4356b7509a2563719a7cbc3670e7ee8d967ad86b")
  (:PATH "spikes/results/2026-10-29-engine-image-delta/targeted.lisp" :BYTES
   801 :DEVICE 16777232 :INODE 1560932185 :MTIME 1793305098 :SHA256
   "0c7c97c2b319a1bb415e5b2884e1d5426a236868dd8640ff1475737cdfc21ed7")
  (:PATH
   "spikes/results/2026-10-29-engine-index-images/allocation-run/conservazione.lisp"
   :BYTES 1087 :DEVICE 16777232 :INODE 1560235085 :MTIME 1793257823 :SHA256
   "ecf817f79cc079ba18793c7eb1881801004d38ba04c3fcc8d8a11bd3ee4f5782")
  (:PATH
   "spikes/results/2026-10-29-engine-index-images/allocation-run/report.lisp"
   :BYTES 304622 :DEVICE 16777232 :INODE 1560235086 :MTIME 1793257822 :SHA256
   "14eb872c39ad192d66a9cba36ce1205297b64a982a33975ee70cfbbc194db3bd")
  (:PATH "spikes/results/2026-10-29-engine-index-images/allocation.lisp" :BYTES
   1171 :DEVICE 16777232 :INODE 1560233510 :MTIME 1793257660 :SHA256
   "0f4c7618ef574a4407a2184b9671189b3585f1e62170e8625d8266cd777eb8df")
  (:PATH
   "spikes/results/2026-10-29-engine-index-images/attempt-1-test-parenthesis.log.gz"
   :BYTES 120255 :DEVICE 16777232 :INODE 1560235087 :MTIME 1793257843 :SHA256
   "07f9107728483cc8514c7e0d91fadd1bb9980c8045443cd6cbd5328ce31cea72")
  (:PATH
   "spikes/results/2026-10-29-engine-index-images/attempt-3-test-constructor.log.gz"
   :BYTES 2645 :DEVICE 16777232 :INODE 1560235088 :MTIME 1793257843 :SHA256
   "73997dba4c39b666993a34d31bb444740db0141c7c518688889a676cd5734a6a")
  (:PATH
   "spikes/results/2026-10-29-engine-index-images/check-run/conservazione.lisp"
   :BYTES 1636 :DEVICE 16777232 :INODE 1560258085 :MTIME 1793258421 :SHA256
   "c0eb310acbdee60f6d66ec2bec2f73651ceb2386d137be32915eb9981b3cff94")
  (:PATH "spikes/results/2026-10-29-engine-index-images/check-run/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1560258087 :MTIME 1793258420 :SHA256
   "7a457cddb36ecc66ed81aa81ed8297b4d00c0a0f2ecf82614842d23158963368")
  (:PATH
   "spikes/results/2026-10-29-engine-index-images/check-run/report.lisp.gz"
   :BYTES 313418 :DEVICE 16777232 :INODE 1560258086 :MTIME 1793258420 :SHA256
   "44b825b634cd79a10174511e586b9fd1ee723653dfc94bda7e2ee40011664b8d")
  (:PATH "spikes/results/2026-10-29-engine-index-images/report.md" :BYTES 5288
   :DEVICE 16777232 :INODE 1560239910 :MTIME 1793258479 :SHA256
   "6da3037b297dae979d0cc82bb90dc1f6b29cfcd3cc4d727b9961b17ce4821494")
  (:PATH
   "spikes/results/2026-10-29-engine-index-images/targeted-run/conservazione.lisp"
   :BYTES 1083 :DEVICE 16777232 :INODE 1560235082 :MTIME 1793257796 :SHA256
   "cfcb8264bbac79e540e6c1cf1165d8024c28fa7a7189cc160f5b066ed981496e")
  (:PATH
   "spikes/results/2026-10-29-engine-index-images/targeted-run/report.lisp"
   :BYTES 307133 :DEVICE 16777232 :INODE 1560235083 :MTIME 1793257795 :SHA256
   "a29a1f1588336b48d7184be133ade7d2dd379bcdd06ce15c6d0d693d2eaf9417")
  (:PATH "spikes/results/2026-10-29-engine-index-images/targeted.lisp" :BYTES
   930 :DEVICE 16777232 :INODE 1560234022 :MTIME 1793257745 :SHA256
   "c1f0b02a2f59f79155a08d2f8ef153662e8b58d2f123a6f19d6a77e9d0954af8")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/allocation-final/conservazione.lisp"
   :BYTES 1093 :DEVICE 16777232 :INODE 1562884306 :MTIME 1793391387 :SHA256
   "f9f0c8e66bc0ed4fd228540e5b8810700ffbaaea0a9f1f2e9b3679e700379119")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/allocation-final/report.lisp"
   :BYTES 311489 :DEVICE 16777232 :INODE 1562884307 :MTIME 1793391387 :SHA256
   "ead0cead27d66bab4a7610fa1746907f84d7d65af6b139f5df70e295e97e9a63")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/allocation-run/conservazione.lisp"
   :BYTES 1081 :DEVICE 16777232 :INODE 1562863285 :MTIME 1793390502 :SHA256
   "08b5c530f896a432c97e5f23b6aabecd7e930a050a7da5e546c3020867b9b939")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/allocation-run/report.lisp"
   :BYTES 311814 :DEVICE 16777232 :INODE 1562863286 :MTIME 1793390501 :SHA256
   "ab1afaf67804fe09b898138f0b998892a2add43647480a08868febdfc95ac243")
  (:PATH "spikes/results/2026-10-30-engine-image-discovery/allocation.lisp"
   :BYTES 1387 :DEVICE 16777232 :INODE 1562844656 :MTIME 1793389805 :SHA256
   "3c67ce8248fa04637955a3031102890d42c7ecda02d6259e78aa3a42b79fec39")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/attempt-1-sources-changed/conservazione.lisp"
   :BYTES 1624 :DEVICE 16777232 :INODE 1562875650 :MTIME 1793391235 :SHA256
   "b296372ffac00995a9f96631a043e96caeb6caae0bf1381e3fe12a8b78c26117")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/attempt-1-sources-changed/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1562875652 :MTIME 1793391234 :SHA256
   "35d71564d36104055240bf587e79f608c6cee756c15c67721791770e402ea5f7")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/attempt-1-sources-changed/report.lisp.gz"
   :BYTES 317442 :DEVICE 16777232 :INODE 1562875651 :MTIME 1793391234 :SHA256
   "38fe54236800a37d18479397cda00fbe87b2265aa6f664d9fe362fce840df4b1")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/attempt-2-concurrent-git-state/ci-selftest/conservazione.lisp"
   :BYTES 1067 :DEVICE 16777232 :INODE 1562903017 :MTIME 1793392165 :SHA256
   "4949160f5a1838ef618f9ad9322e98f4138790c5565b907f6d92b40780456e8c")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/attempt-2-concurrent-git-state/ci-selftest/report.lisp"
   :BYTES 312231 :DEVICE 16777232 :INODE 1562903018 :MTIME 1793392165 :SHA256
   "e27b3e00ca678ad912c93341ebf5b14a78d79f651d137bf9597100234b0aeada")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/attempt-2-concurrent-git-state/conservazione.lisp"
   :BYTES 1624 :DEVICE 16777232 :INODE 1562902771 :MTIME 1793392167 :SHA256
   "488e938906e16885f8dbb29032227fc9080db8ae13fcd42f5c08b4e811d47c3d")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/attempt-2-concurrent-git-state/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1562902773 :MTIME 1793392167 :SHA256
   "701cfde3f9bd6f59b42217370b5bebcf878c2d6ff400f5232b48db6f3dadf3fe")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/attempt-2-concurrent-git-state/report.lisp.gz"
   :BYTES 317384 :DEVICE 16777232 :INODE 1562902772 :MTIME 1793392166 :SHA256
   "a36d8dcd1df9a4ee32bb0ec771a49c0603c1279c3eee218d064a27101f3fb73e")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/current-trace.log.gz"
   :BYTES 77 :DEVICE 16777232 :INODE 1562931193 :MTIME 1793393675 :SHA256
   "50252028968c2d7c281d1d5041516555122206acb14117e650af7f978049970e")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/ci-selftest/conservazione.lisp"
   :BYTES 1250 :DEVICE 16777232 :INODE 1562930220 :MTIME 1793393614 :SHA256
   "ff7a12a7a6db72867fa45d88179268d2ab703858aff5b4268823f50db50608b1")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/ci-selftest/report.lisp"
   :BYTES 313415 :DEVICE 16777232 :INODE 1562930221 :MTIME 1793393614 :SHA256
   "0ceb007aea31ebfc2e297e79ecc1e2b37d77cec9ba2c7f12f6bee788aafea85d")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/conservazione.lisp"
   :BYTES 1863 :DEVICE 16777232 :INODE 1562923148 :MTIME 1793393239 :SHA256
   "6743d46364934324a78dacecb380a7b179e1977959fec7b668ce04f341ccda7e")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/remaining-checks.lisp"
   :BYTES 502 :DEVICE 16777232 :INODE 1562930250 :MTIME 1793393643 :SHA256
   "70ca925779d9c88201d6e72dfc68b0a60147289cbf005f62fa4aeb3271cdf82f")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/remaining-checks.log.gz"
   :BYTES 7333 :DEVICE 16777232 :INODE 1562930248 :MTIME 1793393643 :SHA256
   "de169df25c32b9b16602bf126d56b5e15da9dae336bdbba55ebfc599874519ca")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1562923150 :MTIME 1793393238 :SHA256
   "e2eebf9633985b88a630ace2c1dc0d883c3d2e8784d460d1770585eadf2cd3e1")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/report.lisp.gz"
   :BYTES 317165 :DEVICE 16777232 :INODE 1562923149 :MTIME 1793393238 :SHA256
   "993d4bce917f1859b5dcbe34c86e70d0b9fa4a7fff74a5ce8b24138df3b9a974")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/SPK-01.lisp"
   :BYTES 27228 :DEVICE 16777232 :INODE 1562930231 :MTIME 1793393538 :SHA256
   "87683d47f2f15d29a436ac04d45950cb4f0f8868439988a508fbceca0615c44b")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/SPK-02.lisp"
   :BYTES 1607 :DEVICE 16777232 :INODE 1562930235 :MTIME 1793393539 :SHA256
   "5b870e3539970600891949c09422b6d374ee46ef6cfa7f02e1ea37a98936e5fd")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/SPK-03.lisp"
   :BYTES 3708 :DEVICE 16777232 :INODE 1562930234 :MTIME 1793393540 :SHA256
   "1d59bd6daaaebd98b10a6d01c4d006c2f9fe467611384679edb9399a9fcd6603")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/SPK-04.lisp"
   :BYTES 6752 :DEVICE 16777232 :INODE 1562930245 :MTIME 1793393541 :SHA256
   "a5ae0f46300a1d4c4e33143296a6887f1322e54effe6e581d522c369867f484a")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/SPK-05.lisp"
   :BYTES 10143 :DEVICE 16777232 :INODE 1562930237 :MTIME 1793393542 :SHA256
   "f0a7b623c51136785dbcdda3e8cbc2d5569030161300ec0cce547bcfebf898e7")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/SPK-06.lisp"
   :BYTES 24070 :DEVICE 16777232 :INODE 1562930229 :MTIME 1793393544 :SHA256
   "3b86341dea08a5889decc6296fdf7660a8dd9959579cf338b530a3a40e4c0f43")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/SPK-07.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1562930225 :MTIME 1793393578 :SHA256
   "41099e48645cc99fc83cbf2c9b91fd165d4eb067295ff41a7fd8c5763b8a9a3f")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/SPK-07.lisp.gz"
   :BYTES 411790 :DEVICE 16777232 :INODE 1562930227 :MTIME 1793393578 :SHA256
   "06ec358a43a8ceb9b851e7552365bbaabb99601e7d3fb9305290d295962b7821")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/SPK-08.lisp"
   :BYTES 332128 :DEVICE 16777232 :INODE 1562930242 :MTIME 1793393559 :SHA256
   "2aa1bac44b739f1a25fd53a2c61267b7b80d540d407fc1961baec0d82c05dfd1")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/SPK-09.lisp"
   :BYTES 2472 :DEVICE 16777232 :INODE 1562930241 :MTIME 1793393560 :SHA256
   "5134c9f13d38912f4e1ae0beeb0a7c434eadcaa3c0340b86cc8451d8d234d4ab")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/SPK-10.lisp"
   :BYTES 22977 :DEVICE 16777232 :INODE 1562930228 :MTIME 1793393564 :SHA256
   "130a0e285e67fdbd4317c2c10240bafae3848f211f8eefcf4ed891ad23382387")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/SPK-11.lisp"
   :BYTES 75834 :DEVICE 16777232 :INODE 1562930226 :MTIME 1793393576 :SHA256
   "ddfecede3bd0298efa0887005397fe855f1bdf4ebe4a572a0532400a4d6b0f27")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/conservazione.lisp"
   :BYTES 2462 :DEVICE 16777232 :INODE 1562930230 :MTIME 1793393580 :SHA256
   "2b32b2356718349f5b894c223ed504f513039d40e95b4dc4e0e7ccc36bf81a35")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/report.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1562930233 :MTIME 1793393579 :SHA256
   "d19d4a5cc26e5b3b496ff2e629f417fc36e11b3f46b606e4a1e9d4d0469c65ee")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/isolated-check-run/spikes/report.lisp.gz"
   :BYTES 484943 :DEVICE 16777232 :INODE 1562930232 :MTIME 1793393579 :SHA256
   "f7f1e00b79e581b5ea5c0d6001362ba1c814f7ac4979c640b9dc52ad9e9c5ab0")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/live-document-links.log.gz"
   :BYTES 1098 :DEVICE 16777232 :INODE 1562930251 :MTIME 1793393643 :SHA256
   "95a65f346df374d93ea908adf1e270e2a377b9dcebeb17806ab207bd955eab0d")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/recorder-before-fix-failure.log.gz"
   :BYTES 1121 :DEVICE 16777232 :INODE 1562903799 :MTIME 1793392373 :SHA256
   "04c59633db68eb1ba8b0134ca29bc32a1c247389fd821e329e1189227ca906c8")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/recorder-before-order-fix.lisp.gz"
   :BYTES 3167 :DEVICE 16777232 :INODE 1562903644 :MTIME 1793392350 :SHA256
   "899d0dba102ace6eaa25355f064e7c154b3741e9e71afa63ba2f28b7e0030e6f")
  (:PATH "spikes/results/2026-10-30-engine-image-discovery/report.md" :BYTES
   9507 :DEVICE 16777232 :INODE 1562846032 :MTIME 1793393661 :SHA256
   "3d49252f4877cf834486d9efde70d53b0a830502420af04bdf42c7ea8b2151e5")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/sbcl-2.6.9-allocation/conservazione.lisp"
   :BYTES 1115 :DEVICE 16777232 :INODE 1562884312 :MTIME 1793391436 :SHA256
   "442afa5d9d3b9f7c416164cb4bd5be95b549221f536cd0afaf9bd361d0f4d808")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/sbcl-2.6.9-allocation/report.lisp"
   :BYTES 311509 :DEVICE 16777232 :INODE 1562884313 :MTIME 1793391436 :SHA256
   "35e72b81933799faa6763e74e80698646f31bedbaf42d61ab9bd0d3ca2eb6e3c")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/sbcl-2.6.9-targeted/conservazione.lisp"
   :BYTES 1093 :DEVICE 16777232 :INODE 1562884309 :MTIME 1793391434 :SHA256
   "40f57a64e57362c41ab89c662343af514d16a417c2ed185e1acfb8ad5652d929")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/sbcl-2.6.9-targeted/report.lisp"
   :BYTES 314206 :DEVICE 16777232 :INODE 1562884310 :MTIME 1793391433 :SHA256
   "4a4bc55db03aa0f082ae3b0bf586c2d025855065f578cd1e2b35cf3e21c4c530")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/snapshot-equivalence.lisp"
   :BYTES 7703 :DEVICE 16777232 :INODE 1562930249 :MTIME 1793393643 :SHA256
   "d4758fc954edb1e1bba423f32420d463c40cdc23795bc9f2f9e1fcf8c890cc11")
  (:PATH "spikes/results/2026-10-30-engine-image-discovery/source-delta.log"
   :BYTES 125 :DEVICE 16777232 :INODE 1562875980 :MTIME 1793391353 :SHA256
   "15609e9f288861df4dad3011ea21609d739f02690c10e7aa3604486e46fdac87")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/targeted-final/conservazione.lisp"
   :BYTES 1089 :DEVICE 16777232 :INODE 1562884303 :MTIME 1793391385 :SHA256
   "4c60cbc743b8187214d12e2bd4926620e3bab54e8f312bd08fb2df24a36ea7ff")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/targeted-final/report.lisp"
   :BYTES 314188 :DEVICE 16777232 :INODE 1562884304 :MTIME 1793391384 :SHA256
   "3f4ff3a2e17c94aafc8983f3d4181842bd180cc2ffe4efdea6e6d30618679e7d")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/targeted-run/conservazione.lisp"
   :BYTES 1077 :DEVICE 16777232 :INODE 1562863282 :MTIME 1793390499 :SHA256
   "3409e7f37fde79935ff1f88ada54473676be02cf5c225dd6d09ae039b8a10687")
  (:PATH
   "spikes/results/2026-10-30-engine-image-discovery/targeted-run/report.lisp"
   :BYTES 314511 :DEVICE 16777232 :INODE 1562863283 :MTIME 1793390498 :SHA256
   "07c9f23161c5a16c771b35fa392d23afbf5dcbb89d9eb8149203882fd2382560")
  (:PATH "spikes/results/2026-10-30-engine-image-discovery/targeted.lisp"
   :BYTES 809 :DEVICE 16777232 :INODE 1562842105 :MTIME 1793390305 :SHA256
   "ea201768f1cc7b4a0d25d8dbfe04511a1a2bf7738e50f42adde056b6c8764d82")
  (:PATH
   "spikes/results/2026-10-30-engine-image-maintenance/allocation-run/conservazione.lisp"
   :BYTES 1085 :DEVICE 16777232 :INODE 1562820436 :MTIME 1793387716 :SHA256
   "6cb7935f14e0691618dd43e3d0ef889b4c539cda7b97925fc7a0951ec050b5fb")
  (:PATH
   "spikes/results/2026-10-30-engine-image-maintenance/allocation-run/report.lisp"
   :BYTES 309698 :DEVICE 16777232 :INODE 1562820437 :MTIME 1793387716 :SHA256
   "d421df4e6970a60c32b471f3e244a7c653e57327d9b18b44f6415528603b59fb")
  (:PATH "spikes/results/2026-10-30-engine-image-maintenance/allocation.lisp"
   :BYTES 2245 :DEVICE 16777232 :INODE 1562811869 :MTIME 1793387598 :SHA256
   "e704af2db4264ab0db464d74d2bbd3d24c6cef42adcd78880192894916f92bbb")
  (:PATH
   "spikes/results/2026-10-30-engine-image-maintenance/check-run/conservazione.lisp"
   :BYTES 1624 :DEVICE 16777232 :INODE 1562837576 :MTIME 1793388388 :SHA256
   "5d47af6057236d044b46beafe05497551e3192c412ccff2b3f7268f0bdf697d5")
  (:PATH
   "spikes/results/2026-10-30-engine-image-maintenance/check-run/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1562837578 :MTIME 1793388387 :SHA256
   "bdd7b7a085d08dd397a293d81a30e5f77fdb490d4b44bdd369fb6caa569dd6ac")
  (:PATH
   "spikes/results/2026-10-30-engine-image-maintenance/check-run/report.lisp.gz"
   :BYTES 316309 :DEVICE 16777232 :INODE 1562837577 :MTIME 1793388387 :SHA256
   "e36fe724b840bb9ce2bcff6c920c3f65640db332774f5776ff81711a3a3d674c")
  (:PATH "spikes/results/2026-10-30-engine-image-maintenance/report.md" :BYTES
   3963 :DEVICE 16777232 :INODE 1562812701 :MTIME 1793388497 :SHA256
   "69a3c15f2abc2d780722d005a05a752e305b3f98dd398de6264bd944af93b8ba")
  (:PATH
   "spikes/results/2026-10-30-engine-image-maintenance/sbcl-2.6.9-allocation/conservazione.lisp"
   :BYTES 1119 :DEVICE 16777232 :INODE 1562838758 :MTIME 1793388448 :SHA256
   "acc39ce45bac6c92dc2ca9b4ca8c7b141f2037804a2c9f8044139cf829ab89d1")
  (:PATH
   "spikes/results/2026-10-30-engine-image-maintenance/sbcl-2.6.9-allocation/report.lisp"
   :BYTES 309716 :DEVICE 16777232 :INODE 1562838759 :MTIME 1793388448 :SHA256
   "de2960d18c506af05fc2ecd139f10ff01d7ad6e15316339fcd9b7122e502d32c")
  (:PATH
   "spikes/results/2026-10-30-engine-image-maintenance/sbcl-2.6.9-targeted/conservazione.lisp"
   :BYTES 1097 :DEVICE 16777232 :INODE 1562838755 :MTIME 1793388446 :SHA256
   "efb58098d4480df745171f3ea0ad696cc55ad67951862e687eaa1760204eb57b")
  (:PATH
   "spikes/results/2026-10-30-engine-image-maintenance/sbcl-2.6.9-targeted/report.lisp"
   :BYTES 310043 :DEVICE 16777232 :INODE 1562838756 :MTIME 1793388445 :SHA256
   "c71f75f28983abaecb28309dc63d12f35584a187082e20aa31a36da4ea306c04")
  (:PATH
   "spikes/results/2026-10-30-engine-image-maintenance/targeted-run/conservazione.lisp"
   :BYTES 1081 :DEVICE 16777232 :INODE 1562820433 :MTIME 1793387713 :SHA256
   "efdf22cf4d49ae95237703084671b7a19bda66aa5a8bd9a9ff43e5ce8b6efb29")
  (:PATH
   "spikes/results/2026-10-30-engine-image-maintenance/targeted-run/report.lisp"
   :BYTES 310023 :DEVICE 16777232 :INODE 1562820434 :MTIME 1793387713 :SHA256
   "786c70f6687bde197343b36a2dbfc6f38a0a6cb86c0ce408af6ba3cbfa2008e3")
  (:PATH "spikes/results/2026-10-30-engine-image-maintenance/targeted.lisp"
   :BYTES 814 :DEVICE 16777232 :INODE 1562810630 :MTIME 1793387525 :SHA256
   "5ec9577c4076dcae4492009e36ca2e1c1070b22d187db6f9aa3ca3fdc8a8ce73")
  (:PATH
   "spikes/results/2026-10-30-engine-image-renewal/allocation-run/conservazione.lisp"
   :BYTES 1089 :DEVICE 16777232 :INODE 1562348766 :MTIME 1793330316 :SHA256
   "1eae7122b6bc911cf2c09436e9d3c226b3bb13aae75f2c3ab1bfc94c6de7cbec")
  (:PATH
   "spikes/results/2026-10-30-engine-image-renewal/allocation-run/report.lisp"
   :BYTES 309029 :DEVICE 16777232 :INODE 1562348767 :MTIME 1793330315 :SHA256
   "e253ab5cebe0739df9461c84ca050d800e872ad90c74866161ab4dce2c7d66ce")
  (:PATH "spikes/results/2026-10-30-engine-image-renewal/allocation.lisp"
   :BYTES 1594 :DEVICE 16777232 :INODE 1562341719 :MTIME 1793330183 :SHA256
   "17f6a690d86d7d6f9d82d5bf4e0edf34d363b0cc5ba191dcec5363fe50f057b9")
  (:PATH
   "spikes/results/2026-10-30-engine-image-renewal/attempt-2-v1-long-key-fixture.log.gz"
   :BYTES 2073 :DEVICE 16777232 :INODE 1562342447 :MTIME 1793330268 :SHA256
   "f2177bf168f56dc766a0a16494f9a20a57168509cf5a2eb5667128c79a993ddc")
  (:PATH
   "spikes/results/2026-10-30-engine-image-renewal/attempt-3-v1-long-key-fixture.log.gz"
   :BYTES 2071 :DEVICE 16777232 :INODE 1562342475 :MTIME 1793330281 :SHA256
   "cbef1dd55ee5149b4e8a9c087d8c447e4bad78e3c6085f2d87a1e5eb268a0297")
  (:PATH
   "spikes/results/2026-10-30-engine-image-renewal/check-run/conservazione.lisp"
   :BYTES 1636 :DEVICE 16777232 :INODE 1562360327 :MTIME 1793330948 :SHA256
   "8ba9ffa361e3af25e8ab6e3cdcae402e2483be2e5a539aed490532472b99bff8")
  (:PATH "spikes/results/2026-10-30-engine-image-renewal/check-run/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1562360329 :MTIME 1793330947 :SHA256
   "7a2726728d05852b56edfd9bc2dc73e17ea94ed6e26f43bada0d6798e838b44a")
  (:PATH
   "spikes/results/2026-10-30-engine-image-renewal/check-run/report.lisp.gz"
   :BYTES 320147 :DEVICE 16777232 :INODE 1562360328 :MTIME 1793330947 :SHA256
   "cbe58ab396c25953f4c686ce597b457de083aa97b7b49b49bd8c8bba44b56de0")
  (:PATH "spikes/results/2026-10-30-engine-image-renewal/report.md" :BYTES 4827
   :DEVICE 16777232 :INODE 1562341622 :MTIME 1793387500 :SHA256
   "acf448e497844029564299172a94f06f2bf948155f60890622abcf45c58c11e2")
  (:PATH
   "spikes/results/2026-10-30-engine-image-renewal/targeted-run/conservazione.lisp"
   :BYTES 1085 :DEVICE 16777232 :INODE 1562348763 :MTIME 1793330355 :SHA256
   "7290564f68e6013dc39a72c7baddea25e880f788cd9ea739b075551bd41d0712")
  (:PATH
   "spikes/results/2026-10-30-engine-image-renewal/targeted-run/report.lisp"
   :BYTES 311216 :DEVICE 16777232 :INODE 1562348764 :MTIME 1793330354 :SHA256
   "0920b9bab98b236eb8fe47304454aa66e0da5ce00787cbaffb23ca5632fb89de")
  (:PATH "spikes/results/2026-10-30-engine-image-renewal/targeted.lisp" :BYTES
   804 :DEVICE 16777232 :INODE 1562340505 :MTIME 1793330183 :SHA256
   "865eb5a7278a5716a827395276c47841f017cbd3e33c0569dd38fbc69f586d97")
  (:PATH
   "spikes/results/2026-10-30-sbcl-2.6.10/allocation-run/conservazione.lisp"
   :BYTES 1075 :DEVICE 16777232 :INODE 1562789718 :MTIME 1793386688 :SHA256
   "9a54c87a6a33987cd7c38fc8581ad45da62d02aae3b09fc4341287aa02126854")
  (:PATH "spikes/results/2026-10-30-sbcl-2.6.10/allocation-run/report.lisp"
   :BYTES 309073 :DEVICE 16777232 :INODE 1562789719 :MTIME 1793386688 :SHA256
   "7e2948011f16b8e30932e38e5a5abb44fb4cacc402ee8bc87d4920a60e4d2df2")
  (:PATH
   "spikes/results/2026-10-30-sbcl-2.6.10/attempt-1-check/conservazione.lisp"
   :BYTES 1067 :DEVICE 16777232 :INODE 1562789715 :MTIME 1793386674 :SHA256
   "570825880098c5a22a8a7c1c5a2dc9d5eb0fd25954c2ae156b6e7da7c18cd507")
  (:PATH "spikes/results/2026-10-30-sbcl-2.6.10/attempt-1-check/report.lisp"
   :BYTES 836390 :DEVICE 16777232 :INODE 1562789716 :MTIME 1793386673 :SHA256
   "b62662fa4b4afa15bcf61f77ffe56742e961c4e467af15edaddf423eab0b52a2")
  (:PATH "spikes/results/2026-10-30-sbcl-2.6.10/build.log.gz" :BYTES 18276
   :DEVICE 16777232 :INODE 1562788713 :MTIME 1793386666 :SHA256
   "a792fb65b0ae3d2e09cf5117943d4633dac5f74c82746d655fc936f4adf9f89e")
  (:PATH "spikes/results/2026-10-30-sbcl-2.6.10/check-run/conservazione.lisp"
   :BYTES 1624 :DEVICE 16777232 :INODE 1562810096 :MTIME 1793387472 :SHA256
   "019e6ef3f19bef0e9be401ebfb4dab24adef3bc1096ecfdcac729b866c7773ef")
  (:PATH "spikes/results/2026-10-30-sbcl-2.6.10/check-run/report.lisp" :BYTES
   317 :DEVICE 16777232 :INODE 1562810098 :MTIME 1793387471 :SHA256
   "ddca5529c18e214c99cf79570dce3bba009ea31eb48206314bf13ab40634e995")
  (:PATH "spikes/results/2026-10-30-sbcl-2.6.10/check-run/report.lisp.gz"
   :BYTES 315757 :DEVICE 16777232 :INODE 1562810097 :MTIME 1793387471 :SHA256
   "1b793eaa6dbdfe586e27881cdd19277c9f0d67403ee8aad19e93ffcf186bc319")
  (:PATH "spikes/results/2026-10-30-sbcl-2.6.10/compiler.txt" :BYTES 201
   :DEVICE 16777232 :INODE 1562788715 :MTIME 1793386666 :SHA256
   "f29205d7c2a38b4751821f13b4ce058720c5bb2cba76dfb3c9be3ee585a21d04")
  (:PATH "spikes/results/2026-10-30-sbcl-2.6.10/install.log.gz" :BYTES 164
   :DEVICE 16777232 :INODE 1562788714 :MTIME 1793386666 :SHA256
   "bd2b4bb4ee366d0a4e3e3fc760bfa2ab46262f6937e37cc95f88287b5eb975e2")
  (:PATH "spikes/results/2026-10-30-sbcl-2.6.10/installation.lisp" :BYTES 1083
   :DEVICE 16777232 :INODE 1562788711 :MTIME 1793386666 :SHA256
   "59b57f40cd811cf663b1813c14ef4c9ea56245a3a516d519ce4f68f77de62b0c")
  (:PATH "spikes/results/2026-10-30-sbcl-2.6.10/report.md" :BYTES 1684 :DEVICE
   16777232 :INODE 1562788716 :MTIME 1793387500 :SHA256
   "1f3a03b82c1ce04b7ee141b647573d3c9bb6239c234268bd72cef21b6017f40e")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/allocation-final-2.6.10.lisp"
   :BYTES 334 :DEVICE 16777232 :INODE 1563154751 :MTIME 1793435334 :SHA256
   "7c23fe083a28ee5be88d5102962482e2eba3f8d1e0f7c672dad15656e3280ee7")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/allocation-final-2.6.10.lisp.gz"
   :BYTES 100070 :DEVICE 16777232 :INODE 1563154752 :MTIME 1793435334 :SHA256
   "af5ba84419e481ba407dbca1c60ffd93b3d2213b07a234e146ad72ea73fa9690")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/allocation-final-2.6.9.lisp"
   :BYTES 333 :DEVICE 16777232 :INODE 1563154719 :MTIME 1793435333 :SHA256
   "cb455ae1940dbba203fe5d22782977250afc28129be5d6a9719dd61ca2cbf70f")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/allocation-final-2.6.9.lisp.gz"
   :BYTES 100097 :DEVICE 16777232 :INODE 1563154734 :MTIME 1793435334 :SHA256
   "c669cb9ed1a9cdd20fdaf362899a7926367ce7aaaa18c70c58cf73a56180873c")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/allocation-pre-review-2.6.9.lisp"
   :BYTES 338 :DEVICE 16777232 :INODE 1563154716 :MTIME 1793435333 :SHA256
   "887ccce4da481ddd6a8e8ce131c569e22e8fc36f00ed053d64ac6e226f6d61fa")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/allocation-pre-review-2.6.9.lisp.gz"
   :BYTES 100109 :DEVICE 16777232 :INODE 1563154718 :MTIME 1793435333 :SHA256
   "9583f8ad537438313b8947c44b6fc49d8229ac06a91ae160c4266c3cc6b2b360")
  (:PATH "spikes/results/2026-10-31-engine-auto-renewal/allocation.lisp" :BYTES
   2280 :DEVICE 16777232 :INODE 1563154788 :MTIME 1793435335 :SHA256
   "fac834b09260d857c19866320cc2cbc139100f9b6ddc9cfc64a9c28bdc1a40e8")
  (:PATH "spikes/results/2026-10-31-engine-auto-renewal/archive-index.lisp"
   :BYTES 16656 :DEVICE 16777232 :INODE 1563154943 :MTIME 1793435342 :SHA256
   "646ff5d9aba72920159b4f5df837281d3d389c711cec23c178c831be03c772f4")
  (:PATH "spikes/results/2026-10-31-engine-auto-renewal/catalogo.lisp" :BYTES
   365 :DEVICE 16777232 :INODE 1563154944 :MTIME 1793435342 :SHA256
   "5633a4107f735a15e2c6bec4479895f501eb21ef4178b4f2b0e6bd246f8f2214")
  (:PATH "spikes/results/2026-10-31-engine-auto-renewal/ci-final-2.6.9.lisp"
   :BYTES 324 :DEVICE 16777232 :INODE 1563154765 :MTIME 1793435335 :SHA256
   "7f00ac3cfae2d5245d3002053d611040ef384ad8cc7326d07d14c35430b88a0f")
  (:PATH "spikes/results/2026-10-31-engine-auto-renewal/ci-final-2.6.9.lisp.gz"
   :BYTES 100063 :DEVICE 16777232 :INODE 1563154775 :MTIME 1793435335 :SHA256
   "96a278cf62fd3470a2329e6769706fc01c28fcd20a9df713275cc3e1b6073248")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/collection-manifest.lisp"
   :BYTES 8322 :DEVICE 16777232 :INODE 1563154874 :MTIME 1793435337 :SHA256
   "bf98a0e22d0a2903938eb7fcf8e4bf9650bb229a538690781a99d2d3c6437638")
  (:PATH "spikes/results/2026-10-31-engine-auto-renewal/collection-source.lisp"
   :BYTES 31268 :DEVICE 16777232 :INODE 1563154875 :MTIME 1793435337 :SHA256
   "4edf03e7257d5d4b19c37cb7c51cec772660f79d9f9268b2db4ad6cb66e55c1e")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/diagnostics/balance.lisp.txt"
   :BYTES 879 :DEVICE 16777232 :INODE 1563154790 :MTIME 1793435335 :SHA256
   "16a6dfaa9e3e2baa5bc713d9f28d245281e32e7f8f70aa6505acb8eedc3d38da")
  (:PATH "spikes/results/2026-10-31-engine-auto-renewal/full-final-2.6.9.lisp"
   :BYTES 327 :DEVICE 16777232 :INODE 1563154753 :MTIME 1793435334 :SHA256
   "72c55016f14dc901a5627f749feb206ebf12b9e0abbd1ceccc2c2a3aa5a0a6be")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/full-final-2.6.9.lisp.gz"
   :BYTES 324621 :DEVICE 16777232 :INODE 1563154764 :MTIME 1793435335 :SHA256
   "8e04dff73a00005fdd54c6d3ca2a4e9068341c9bd3dfa71c54aefec91fbdc9d1")
  (:PATH "spikes/results/2026-10-31-engine-auto-renewal/report.md" :BYTES 7320
   :DEVICE 16777232 :INODE 1563154806 :MTIME 1793435335 :SHA256
   "0037473da337971ae86337adba283446b2f20b1634cc7ae67352d40ded82752a")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/snapshots/activation-pre-review.lisp.txt"
   :BYTES 6962 :DEVICE 16777232 :INODE 1563154834 :MTIME 1793435336 :SHA256
   "5872e5ec6851f5c4314699657fb946d5e6d2a2488757ca82fe32918c79342648")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/snapshots/asd-before-new-tests.lisp.txt"
   :BYTES 29163 :DEVICE 16777232 :INODE 1563154853 :MTIME 1793435337 :SHA256
   "f490b6b31bf79198040fe7d3e5bf4e1e99c89a8652dd6fa4e01b81b6d2dbd238")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/snapshots/auto-write-pre-review.lisp.txt"
   :BYTES 4513 :DEVICE 16777232 :INODE 1563154822 :MTIME 1793435336 :SHA256
   "f0e3dab3c6baff3d3c9dd0fb23cf53bacfd98ebe6fb474c884ce044e2f310882")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/snapshots/lifecycle-pre-review.lisp.txt"
   :BYTES 6177 :DEVICE 16777232 :INODE 1563154841 :MTIME 1793435336 :SHA256
   "eb9985bf51f3c88aa80461b5748d7ccc4434593aa341a3209d7dab6db7f42982")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/snapshots/package-pre-review.lisp.txt"
   :BYTES 1949 :DEVICE 16777232 :INODE 1563154832 :MTIME 1793435336 :SHA256
   "11a01722bfab0e33d06a556d2505dfc8b3a0241317cbb4fc635ef9cf5d47cd61")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/snapshots/processes-before-new-tests.lisp.txt"
   :BYTES 6237 :DEVICE 16777232 :INODE 1563154856 :MTIME 1793435337 :SHA256
   "ba9f72a0b97acb71774e6b35b7384b4797336c6feac4157812b2ae5dee2b154b")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/snapshots/source-identities.lisp"
   :BYTES 1976 :DEVICE 16777232 :INODE 1563154869 :MTIME 1793435337 :SHA256
   "2c3f7dd1da929a2d8221d0eddc004357efe9e09ee49b8aaebcf31e3b6dda78fc")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/snapshots/tests-attempt-01.lisp.txt"
   :BYTES 18063 :DEVICE 16777232 :INODE 1563154807 :MTIME 1793435335 :SHA256
   "fcd5a3c25345d4706444de2cb58b71f6dc32b570023ab52fff8ef2bd6ccfa595")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/snapshots/tests-attempt-02.lisp.txt"
   :BYTES 18061 :DEVICE 16777232 :INODE 1563154808 :MTIME 1793435335 :SHA256
   "bc33e25b35639330ac705e00008fe8bf1ff6551c8c4d3750025112ffb3c9720c")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/snapshots/tests-attempt-03.lisp.txt"
   :BYTES 22563 :DEVICE 16777232 :INODE 1563154818 :MTIME 1793435336 :SHA256
   "71531bf22c3e14abf9e77b56fa076724f782b30fbfe8e27608a415c4b4206f00")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/snapshots/types-pre-review.lisp.txt"
   :BYTES 3673 :DEVICE 16777232 :INODE 1563154826 :MTIME 1793435336 :SHA256
   "ee3f08d747eac5cb0fa50bd81c6b76e306d3bbfbc45e5440a8f7259d16cadb28")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/snapshots/write-pre-review.lisp.txt"
   :BYTES 8559 :DEVICE 16777232 :INODE 1563154852 :MTIME 1793435337 :SHA256
   "af0fbfd30b2469298269808c1ebc5b2e6ef72d64b8e687a24d6062f1fba3a060")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/strict-existing-cases.lisp"
   :BYTES 332 :DEVICE 16777232 :INODE 1563154660 :MTIME 1793435332 :SHA256
   "11970dcdc5aae86e3ccf80141a0455cc437ae5bcc778ea0b9d2a18225bfc3ce5")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/strict-existing-cases.lisp.gz"
   :BYTES 100849 :DEVICE 16777232 :INODE 1563154663 :MTIME 1793435332 :SHA256
   "1afef1a14dbfa36cdd2c599413a81c7b8f3fa8226340520f615fdc805089af0c")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/syntax-balance-diagnostic.lisp"
   :BYTES 336 :DEVICE 16777232 :INODE 1563154673 :MTIME 1793435332 :SHA256
   "76d278ce3630efce94d6856cb3ceb57a1f768958cec4889c9f8a2c8e18d05c2a")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/syntax-balance-diagnostic.lisp.gz"
   :BYTES 100688 :DEVICE 16777232 :INODE 1563154675 :MTIME 1793435332 :SHA256
   "3a8971b5cdb47c455b7484afc07d587a17d2c48f58b1049a80f092f09008b8c8")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/targeted-attempt-01-syntax.lisp"
   :BYTES 337 :DEVICE 16777232 :INODE 1563154664 :MTIME 1793435332 :SHA256
   "8df8df0cafabfb7725d50b6e46850e73a7ce2113476a33952091eb0aad51196c")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/targeted-attempt-01-syntax.lisp.gz"
   :BYTES 102024 :DEVICE 16777232 :INODE 1563154878 :MTIME 1793435337 :SHA256
   "c84549bb770733ef72f84213f59ecfd23df58d28a11d8de426c6235936127a8e")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/targeted-attempt-02-oracle.lisp"
   :BYTES 337 :DEVICE 16777232 :INODE 1563154676 :MTIME 1793435332 :SHA256
   "1085eb0407c66c01300aae5e5cd2430f2c1c364ed00d08570adb13fcdd870438")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/targeted-attempt-02-oracle.lisp.gz"
   :BYTES 102757 :DEVICE 16777232 :INODE 1563154692 :MTIME 1793435333 :SHA256
   "d0c84f32e0739dff4c825a8934b486185fdfbb69d20b2366e18f0d5d30096242")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/targeted-final-2.6.10.lisp"
   :BYTES 332 :DEVICE 16777232 :INODE 1563154735 :MTIME 1793435334 :SHA256
   "ad6590497bc09e9f4eeef49bd7df0f4370ad440f256442c0ada6b1fd3e32c833")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/targeted-final-2.6.10.lisp.gz"
   :BYTES 101426 :DEVICE 16777232 :INODE 1563154736 :MTIME 1793435334 :SHA256
   "6d1b8b8cd59115b3f120b585760031225da3256a962b2e8dd03a49e74354c989")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/targeted-pre-review-2.6.9.lisp"
   :BYTES 336 :DEVICE 16777232 :INODE 1563154695 :MTIME 1793435333 :SHA256
   "19876238e58d9267f29f5ae725ad1bcdcf71eb208a4cf43da38cec70b53b38d4")
  (:PATH
   "spikes/results/2026-10-31-engine-auto-renewal/targeted-pre-review-2.6.9.lisp.gz"
   :BYTES 101453 :DEVICE 16777232 :INODE 1563154697 :MTIME 1793435333 :SHA256
   "78e2d024b04e9e85dda69c68edc8b543af51e1215e98138de51b0e4a74fadf3a")
  (:PATH "spikes/results/2026-10-31-engine-auto-renewal/targeted.lisp" :BYTES
   944 :DEVICE 16777232 :INODE 1563154787 :MTIME 1793435335 :SHA256
   "12cecf4298991003cea66433b1507e3ab4b51765de6c8858a32f4e701a6fb7e2")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/allocation-before-quota-2.6.10.lisp"
   :BYTES 341 :DEVICE 16777232 :INODE 1563273909 :MTIME 1793443081 :SHA256
   "9d814102e7e15159cc1c7f03e63e0751473d15594658f4931cb3666914bac754")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/allocation-before-quota-2.6.10.lisp.gz"
   :BYTES 101682 :DEVICE 16777232 :INODE 1563273924 :MTIME 1793443081 :SHA256
   "ec8c25a85399a32e4e79538bb4e7eadb1af16a68c9ca27ffbe1367fb1989abfc")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/allocation-before-quota-2.6.9.lisp"
   :BYTES 340 :DEVICE 16777232 :INODE 1563276403 :MTIME 1793443127 :SHA256
   "71f9bd302d9798bd6eaec1f8de194799661f002ffabfbaab62877bea36442a22")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/allocation-before-quota-2.6.9.lisp.gz"
   :BYTES 101708 :DEVICE 16777232 :INODE 1563273891 :MTIME 1793443081 :SHA256
   "b96da478e55e449d375bb8dddb628610bbae834a77aa767d8be90ca428dfb908")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/allocation-final-2.6.10.lisp"
   :BYTES 334 :DEVICE 16777232 :INODE 1563274033 :MTIME 1793443082 :SHA256
   "ba5c905cd46823761568d5f529515b7b0438ca39c1bc543b9d976cf5f6c9d028")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/allocation-final-2.6.10.lisp.gz"
   :BYTES 101678 :DEVICE 16777232 :INODE 1563274035 :MTIME 1793443082 :SHA256
   "941ef9928a85644620478a8342c9d8ce37ae916183f5ba29531efb564b245fb4")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/allocation-final-2.6.9.lisp"
   :BYTES 333 :DEVICE 16777232 :INODE 1563274039 :MTIME 1793443082 :SHA256
   "dd535ca455441c74705bb6bc79bd9b3a78e4b27b3f3a82a42908968431a6d16a")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/allocation-final-2.6.9.lisp.gz"
   :BYTES 101709 :DEVICE 16777232 :INODE 1563274058 :MTIME 1793443082 :SHA256
   "fdaf1278927dbc1b3416d5718a1babf908af5ea215db99fdb27ec974d259b299")
  (:PATH "spikes/results/2026-10-31-engine-automatic-index/archive-index.lisp"
   :BYTES 58769 :DEVICE 16777232 :INODE 1563277290 :MTIME 1793443144 :SHA256
   "9c1f39f6a5b39dd10baf0d02091605e03baf0443573be1c59908d5583180c711")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/argument-guards-before-quota.lisp"
   :BYTES 339 :DEVICE 16777232 :INODE 1563274061 :MTIME 1793443083 :SHA256
   "214a12a049efcdb59e6aff4fb725c40141370cc647f63e70e16be274bfe43996")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/argument-guards-before-quota.lisp.gz"
   :BYTES 101567 :DEVICE 16777232 :INODE 1563274062 :MTIME 1793443083 :SHA256
   "36a5c845785a5f00b1c95e39970ba761b73405bd31584a533d91f539cde0f873")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/attempt-01-test-syntax.lisp"
   :BYTES 333 :DEVICE 16777232 :INODE 1563274078 :MTIME 1793443083 :SHA256
   "6b92bd4bf71e15657d0ed14dd32b506dc6398bf04a28e858372289215b6375f9")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/attempt-01-test-syntax.lisp.gz"
   :BYTES 103515 :DEVICE 16777232 :INODE 1563274086 :MTIME 1793443083 :SHA256
   "ec0fd3c8e74e5967bf2ea3307c3db999a3cd7f0b452f4933be5149645788af2c")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/attempt-02-test-syntax.lisp"
   :BYTES 333 :DEVICE 16777232 :INODE 1563274090 :MTIME 1793443083 :SHA256
   "7000538556c51ce6ee978a888d9f39d249d7ef64eba38e44cc1c226c378457c3")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/attempt-02-test-syntax.lisp.gz"
   :BYTES 103625 :DEVICE 16777232 :INODE 1563274123 :MTIME 1793443084 :SHA256
   "2da932d132fe5539c996afa21868ecba86972f0fa5a6899ffacace6d211effc4")
  (:PATH "spikes/results/2026-10-31-engine-automatic-index/catalogo.lisp"
   :BYTES 368 :DEVICE 16777232 :INODE 1563277291 :MTIME 1793443144 :SHA256
   "f2c7a0d9917f053157c1c0f88404cabf2497fa02da9eaa5cceaa41dfcc3d307b")
  (:PATH "spikes/results/2026-10-31-engine-automatic-index/ci-final-2.6.9.lisp"
   :BYTES 324 :DEVICE 16777232 :INODE 1563274130 :MTIME 1793443084 :SHA256
   "838f9f685ff78797d17df6a3d268d947f7bf2708343b54d408566548de7d3c32")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/ci-final-2.6.9.lisp.gz"
   :BYTES 101805 :DEVICE 16777232 :INODE 1563274132 :MTIME 1793443084 :SHA256
   "2e7dece074bb808c6bc869bf175dc64d370f0357bcbd8a83cd486ad42d991ed7")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/collection-manifest.lisp"
   :BYTES 36729 :DEVICE 16777232 :INODE 1563276305 :MTIME 1793443126 :SHA256
   "68d9dd3bab8d1c9485bf56f173233b314b3922eb8471b18801418c1996fa9a3b")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/collection-source.lisp"
   :BYTES 31268 :DEVICE 16777232 :INODE 1563276402 :MTIME 1793443127 :SHA256
   "4edf03e7257d5d4b19c37cb7c51cec772660f79d9f9268b2db4ad6cb66e55c1e")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/diagnostics/collection-attempt-01.lisp.txt"
   :BYTES 178 :DEVICE 16777232 :INODE 1563276036 :MTIME 1793443125 :SHA256
   "c519983fa9effa281ad3663aa074f49bbd074372a1f806b8849d853ef817185e")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/diagnostics/compile.log.gz"
   :BYTES 52573 :DEVICE 16777232 :INODE 1563276125 :MTIME 1793443125 :SHA256
   "7c53d8d5e8e8d0c97536521b3686754d6f466be4ee749370bb0feec9abfe7285")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/diagnostics/layout-compile.log.gz"
   :BYTES 1977 :DEVICE 16777232 :INODE 1563276136 :MTIME 1793443125 :SHA256
   "5bc02117959bfa9051bae1759bb1877d9fb736fe3c59fe87323f2a86b59bcfe9")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/disk-core-smoke.lisp"
   :BYTES 325 :DEVICE 16777232 :INODE 1563274162 :MTIME 1793443085 :SHA256
   "91c853e19fad39591d2c81dcb04453d81b6b3c8027ed7ebd96f2e8f75661c8c3")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/disk-core-smoke.lisp.gz"
   :BYTES 100818 :DEVICE 16777232 :INODE 1563274167 :MTIME 1793443085 :SHA256
   "90ebf64c04d8b2d347d7c452ceac849d44b29a8ee239e3d8da87d2cf0acc4309")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/drivers/allocation.lisp"
   :BYTES 3160 :DEVICE 16777232 :INODE 1563274479 :MTIME 1793443100 :SHA256
   "570b67236537fc2765f1545d59a09369b7629dfd7a8f50983d073f6185c820b7")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/drivers/argument-guards.lisp"
   :BYTES 1238 :DEVICE 16777232 :INODE 1563274500 :MTIME 1793443101 :SHA256
   "e5412b0d7462dfc39f6eb5744dd12b30996317bdaff3d0a85c2ef72067a85b52")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/drivers/heap-driver.lisp"
   :BYTES 885 :DEVICE 16777232 :INODE 1563274483 :MTIME 1793443100 :SHA256
   "bf10ae16cbab442cd5b617931d089efa80287930bbd93b3fca4a669b4610fcb2")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/drivers/heap-worker.lisp"
   :BYTES 2543 :DEVICE 16777232 :INODE 1563274484 :MTIME 1793443100 :SHA256
   "4e180533ba0a7620f94ab320440de1eca8a7d7c1d22ea4522d98ef4f70a6574a")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/drivers/local-targeted.lisp"
   :BYTES 329 :DEVICE 16777232 :INODE 1563274520 :MTIME 1793443102 :SHA256
   "0e74fe9ae53615fa6c925de6120cc06f05922e2a809d105fd72709eb4d92bf20")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/drivers/quota-regression.lisp"
   :BYTES 510 :DEVICE 16777232 :INODE 1563274519 :MTIME 1793443102 :SHA256
   "77174ffeebd3246a52309d472292724757c7774e24e1398a1f03786506ccff49")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/drivers/retirement-diagnostic.lisp"
   :BYTES 1563 :DEVICE 16777232 :INODE 1563274502 :MTIME 1793443101 :SHA256
   "04bc12f84de185d2b170fb4ca6752e3d762217368adb563e57d9385338309684")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/drivers/retirement-regression.lisp"
   :BYTES 515 :DEVICE 16777232 :INODE 1563274515 :MTIME 1793443102 :SHA256
   "567d845096b2d43f1b348d800fb362d1f49a2cc0e17d1dc4822cd4709dd29e1a")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/drivers/supplemental.lisp"
   :BYTES 2524 :DEVICE 16777232 :INODE 1563274490 :MTIME 1793443101 :SHA256
   "ec445bbacea2c388114d5d1a085b2df33943390ffb43a18d22cc463b3fa31c63")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/drivers/targeted.lisp"
   :BYTES 756 :DEVICE 16777232 :INODE 1563274466 :MTIME 1793443099 :SHA256
   "509ab72b23fda347c124655ba6340566133216a74fe646688969249886d9274a")
  (:PATH "spikes/results/2026-10-31-engine-automatic-index/engine-smoke.lisp"
   :BYTES 322 :DEVICE 16777232 :INODE 1563274173 :MTIME 1793443085 :SHA256
   "34bcf266541012d9787564894bd7a9eea0d5356dc89cc5c306aeb59c986f4661")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/engine-smoke.lisp.gz"
   :BYTES 101465 :DEVICE 16777232 :INODE 1563274205 :MTIME 1793443086 :SHA256
   "120e23c38d04b5f982268b36ea384869013bed7b492313b0e3927883b145e09c")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/final-working-tree.patch"
   :BYTES 97941 :DEVICE 16777232 :INODE 1563274565 :MTIME 1793443104 :SHA256
   "6f03cfb270ce45103fd527d4698d436d6e4ac8afeadd3675f2f3787abe29e9ef")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/full-before-local-fixture-adaptation.lisp"
   :BYTES 348 :DEVICE 16777232 :INODE 1563274214 :MTIME 1793443086 :SHA256
   "b2ef1fc145901001f1b2affdb44efdd132ff7567eccad02f8f559e9c122896ac")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/full-before-local-fixture-adaptation.lisp.gz"
   :BYTES 321544 :DEVICE 16777232 :INODE 1563274217 :MTIME 1793443086 :SHA256
   "c1e1357b5240a9bbbbaed95aa814057f76e301d693b4c5751095a6ed21718437")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/full-final-2.6.9.lisp"
   :BYTES 327 :DEVICE 16777232 :INODE 1563274226 :MTIME 1793443087 :SHA256
   "1f5b5c2cbf17c413ef0a98ffb1ba8390a078aca04e62efe9607e03247ec6afe3")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/full-final-2.6.9.lisp.gz"
   :BYTES 334920 :DEVICE 16777232 :INODE 1563274227 :MTIME 1793443087 :SHA256
   "91c362b3c137e2477e86da91d563581db85cbd0d70d33f7aad00c7f768fcbeb5")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/full-pre-review-stopped.lisp"
   :BYTES 335 :DEVICE 16777232 :INODE 1563274229 :MTIME 1793443087 :SHA256
   "565771412e5bb8008df20e294d347d57e98505737a6441c7a7fb87a795e35e03")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/full-pre-review-stopped.lisp.gz"
   :BYTES 318208 :DEVICE 16777232 :INODE 1563274258 :MTIME 1793443088 :SHA256
   "9dbfe4fed47142c30f565537c3066705013010e569143c6d587fe07b96bde8d7")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/heap-before-retirement-review.lisp"
   :BYTES 340 :DEVICE 16777232 :INODE 1563274260 :MTIME 1793443088 :SHA256
   "351bdbafd0a602f5cee091846edd3cd0db455483689657683ef6d6fdcb3acf18")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/heap-before-retirement-review.lisp.gz"
   :BYTES 102255 :DEVICE 16777232 :INODE 1563274261 :MTIME 1793443088 :SHA256
   "8c3aeee565e4003c56cd46cb3b1d571e54f79404f35c9115c7011ce5ee1ec02c")
  (:PATH "spikes/results/2026-10-31-engine-automatic-index/heap-final.lisp"
   :BYTES 320 :DEVICE 16777232 :INODE 1563274266 :MTIME 1793443089 :SHA256
   "68f8c1f2b13fda16376f1921904afdebca073a20257b4cac49069a53015b72ea")
  (:PATH "spikes/results/2026-10-31-engine-automatic-index/heap-final.lisp.gz"
   :BYTES 102262 :DEVICE 16777232 :INODE 1563274267 :MTIME 1793443089 :SHA256
   "b5318ff791a3382c55ad390173fcf4d253e544bf12c7228a003015ba5fd136d0")
  (:PATH "spikes/results/2026-10-31-engine-automatic-index/heap-initial.lisp"
   :BYTES 322 :DEVICE 16777232 :INODE 1563274269 :MTIME 1793443089 :SHA256
   "dcd4f4e3e2f191c1f0d4315f706359172989e4c2af75d30b0dda11e54cddeda1")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/heap-initial.lisp.gz"
   :BYTES 101891 :DEVICE 16777232 :INODE 1563274281 :MTIME 1793443090 :SHA256
   "10801e8b3656364590751a165717f54f352803d047b42123719b19257c0f6418")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/initial-mode-tests.lisp"
   :BYTES 328 :DEVICE 16777232 :INODE 1563274284 :MTIME 1793443090 :SHA256
   "4ce337ba9ac82344acade853ebe526edc8b41315f916ad4c809a0e2cc4332083")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/initial-mode-tests.lisp.gz"
   :BYTES 102488 :DEVICE 16777232 :INODE 1563274285 :MTIME 1793443090 :SHA256
   "bf59425d7823c332f00cb8a1fb7634df44fcae781e606febb97be8d0aaa62820")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/local-fixture-adapted.lisp"
   :BYTES 332 :DEVICE 16777232 :INODE 1563274296 :MTIME 1793443091 :SHA256
   "58d8f7de35ad8d7c71d7daf3ffd7eb2183f3a6b1a3fbf28d715fe5b462104687")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/local-fixture-adapted.lisp.gz"
   :BYTES 101823 :DEVICE 16777232 :INODE 1563274298 :MTIME 1793443091 :SHA256
   "c62e7b2ccae5f5814bb55b1a5c2f94bf1cddb73788e780391829f95644023420")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/local-fixture-syntax-attempt-01.lisp"
   :BYTES 342 :DEVICE 16777232 :INODE 1563274299 :MTIME 1793443091 :SHA256
   "1334f9aa8e3b3308b0d8a1d48db89c596bae43ae220070df6232475242d46c50")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/local-fixture-syntax-attempt-01.lisp.gz"
   :BYTES 103518 :DEVICE 16777232 :INODE 1563274320 :MTIME 1793443092 :SHA256
   "55226dd3c99f8a074a2741dc6f4224ac88b57f0bcf93685a8fcfc614aaac4597")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/local-fixture-syntax-attempt-02.lisp"
   :BYTES 342 :DEVICE 16777232 :INODE 1563274323 :MTIME 1793443092 :SHA256
   "4fc5ef5422764a2268ac03b5a172fc31216f18fba1b52fc936dab6ecd4ba41f6")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/local-fixture-syntax-attempt-02.lisp.gz"
   :BYTES 103518 :DEVICE 16777232 :INODE 1563274324 :MTIME 1793443092 :SHA256
   "d06de9240568408a1aac56d1337947213d53040a6d09c0025ab5017442c54570")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/mode-and-disk-tests.lisp"
   :BYTES 329 :DEVICE 16777232 :INODE 1563274334 :MTIME 1793443093 :SHA256
   "0a750787938802cf7bef57e08e9f6e79a4ccd000300b2e9a2da7f5d973454e23")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/mode-and-disk-tests.lisp.gz"
   :BYTES 102798 :DEVICE 16777232 :INODE 1563274336 :MTIME 1793443093 :SHA256
   "aa42e3536dd74ff449b10049180e61d2b1b463d2364afa58843944ae738a9cec")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/mode-tests-before-native-review.lisp"
   :BYTES 342 :DEVICE 16777232 :INODE 1563274338 :MTIME 1793443093 :SHA256
   "de0d448764bc9c272e180b7d7baa015f00808d9bbd53d1d579adb8e279ee604e")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/mode-tests-before-native-review.lisp.gz"
   :BYTES 103055 :DEVICE 16777232 :INODE 1563274356 :MTIME 1793443094 :SHA256
   "feeaf5da3e0a3d3276fa827a4d3cd90cf36151e03ad46a0a1235cb5ecc5ec7ca")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/qualified-targeted-2.6.10.lisp"
   :BYTES 336 :DEVICE 16777232 :INODE 1563274359 :MTIME 1793443094 :SHA256
   "198c0874496f0342d4be8b9b6a98fa983619ee4295082842a343af1f63b782e7")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/qualified-targeted-2.6.10.lisp.gz"
   :BYTES 103154 :DEVICE 16777232 :INODE 1563274361 :MTIME 1793443094 :SHA256
   "8b4b7251a7039ec87baf2af5a6f665672c9068120a36f3d7f462d2ebed4d100f")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/quota-defect-reproduction.lisp"
   :BYTES 336 :DEVICE 16777232 :INODE 1563274383 :MTIME 1793443095 :SHA256
   "8cfd7081d9c6e5e14b5d0ee777c24f66825bd0fc6bbc0cc2bcc7b0bb2fe0f9cd")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/quota-defect-reproduction.lisp.gz"
   :BYTES 102786 :DEVICE 16777232 :INODE 1563274384 :MTIME 1793443095 :SHA256
   "80835e632fb041c9a1577b19ccc65bcfc88c9090ded712e3c39c74f3839abbbc")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/quota-regression.lisp"
   :BYTES 326 :DEVICE 16777232 :INODE 1563274389 :MTIME 1793443095 :SHA256
   "2c546305d08fd080bed15497a76c3c22cfe8ff26f3bfa035facce8d54eb415fb")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/quota-regression.lisp.gz"
   :BYTES 101573 :DEVICE 16777232 :INODE 1563274400 :MTIME 1793443096 :SHA256
   "ad4399c89499fae46e3b96bb80fbe66b6b679bb32d8d08d8b48449ca5821e0e7")
  (:PATH "spikes/results/2026-10-31-engine-automatic-index/report.md" :BYTES
   7679 :DEVICE 16777232 :INODE 1563274547 :MTIME 1793443103 :SHA256
   "7ba36b24f4332b99a3d3f4dd237759f917c3e6151b37b66aec0410f8e32e36bb")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/retirement-defect-reproduction.lisp"
   :BYTES 341 :DEVICE 16777232 :INODE 1563274402 :MTIME 1793443096 :SHA256
   "b48f4a380e2210037975997d0b96e16f8a1faec33a7694a261157ab6bdfd1919")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/retirement-defect-reproduction.lisp.gz"
   :BYTES 101579 :DEVICE 16777232 :INODE 1563274403 :MTIME 1793443096 :SHA256
   "a7d524709b03612aa995d34f61636c5c7a82636229132d8d59e50021c75da4d7")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/retirement-pre-review/src/engine/index-auto-files.lisp.txt"
   :BYTES 6352 :DEVICE 16777232 :INODE 1563275941 :MTIME 1793443124 :SHA256
   "752c66a6e24df7e8375f86a97008a0265b517388092d2d4cc8eb71aa6a4916ac")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/retirement-pre-review/src/engine/index-auto-migrate.lisp.txt"
   :BYTES 8522 :DEVICE 16777232 :INODE 1563276018 :MTIME 1793443124 :SHA256
   "eb0addf3b275e7545ca220f57aecfefb8136e0eae7a10184a8caf16b75b09a47")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/retirement-pre-review/tests/engine/index-automatic.lisp.txt"
   :BYTES 13831 :DEVICE 16777232 :INODE 1563276029 :MTIME 1793443125 :SHA256
   "5e15b4c370243888f49e64c17d846c220731fe93e4a7f397cae0f289b1fac231")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/retirement-regression.lisp"
   :BYTES 332 :DEVICE 16777232 :INODE 1563274423 :MTIME 1793443097 :SHA256
   "ac45a8e9ccf8b65abcb4f2ab38407b396e4874a8f0b783e067a1c8e8543b6c4e")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/retirement-regression.lisp.gz"
   :BYTES 101573 :DEVICE 16777232 :INODE 1563274426 :MTIME 1793443097 :SHA256
   "301c82e3b6657e7613fe4df99d7f0e94d986c450a25a0147331fc8197a1892c9")
  (:PATH "spikes/results/2026-10-31-engine-automatic-index/review.md" :BYTES
   21038 :DEVICE 16777232 :INODE 1563274549 :MTIME 1793443103 :SHA256
   "8c9e36cb8c28f798de9cdf105a44b497ca758ff73c6b95cde2e21ec9cfac45b6")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/snapshots/local-server-before-auto-fixture.lisp.txt"
   :BYTES 8662 :DEVICE 16777232 :INODE 1563276154 :MTIME 1793443126 :SHA256
   "6b96c904b40f8032036274200c1d20dfc790ee17722900743b9b34972cc64ffb")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/snapshots/memory-before-quota-fix.lisp.txt"
   :BYTES 9841 :DEVICE 16777232 :INODE 1563276266 :MTIME 1793443126 :SHA256
   "151993ee150cfe34198db0c64c9b9e969bedbae08074e51e11503206e55c4566")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/snapshots/pre-review-identities.txt"
   :BYTES 225 :DEVICE 16777232 :INODE 1563276285 :MTIME 1793443126 :SHA256
   "5adffa839ce01bb9dc0440cae990db522809cdc2085f79ab09332503c497821b")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-before-final-qa/docs/implementazione/indice-automatico-operativo.md.txt"
   :BYTES 7200 :DEVICE 16777232 :INODE 1563275809 :MTIME 1793443123 :SHA256
   "1a2058ccb98cdaa3091b247114c4ac04553ac802344039202851eed4c78e13cc")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-before-final-qa/src/engine/index-auto-memory.lisp.txt"
   :BYTES 9841 :DEVICE 16777232 :INODE 1563275909 :MTIME 1793443124 :SHA256
   "151993ee150cfe34198db0c64c9b9e969bedbae08074e51e11503206e55c4566")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-before-final-qa/tests/engine/index-automatic.lisp.txt"
   :BYTES 15722 :DEVICE 16777232 :INODE 1563275926 :MTIME 1793443124 :SHA256
   "7682d9c11e0a46d6c3e7d2d94a6a8af603fa098721085d3e05c9f95a575b87b1")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final-identities.txt"
   :BYTES 10352 :DEVICE 16777232 :INODE 1563274550 :MTIME 1793443103 :SHA256
   "a0ecb965740f0de9bf12ea5840b9c0934c8a6f379bbb8e6a3417f019c4b7edf1")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/CHANGELOG.md.txt"
   :BYTES 45868 :DEVICE 16777232 :INODE 1563274571 :MTIME 1793443104 :SHA256
   "10b6ab84ca24d4e2f9caee8e37663fd93b7e4e689462223e39526384d77f90fc")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/README.md.txt"
   :BYTES 1573 :DEVICE 16777232 :INODE 1563274574 :MTIME 1793443104 :SHA256
   "c4eb73ea2734088fe4d26b14d8a2bb26f4b887e4725d7f170ab3ba829841fc8c")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/arcdocdb.asd.txt"
   :BYTES 29825 :DEVICE 16777232 :INODE 1563274600 :MTIME 1793443105 :SHA256
   "d2e918d40d75726c7f0651e39b25ca97dd1c1b1a93f2de57f2cfba85e6b4542c")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/adr/0067-delta-seriale-indice-m1.md.txt"
   :BYTES 2757 :DEVICE 16777232 :INODE 1563274616 :MTIME 1793443105 :SHA256
   "5e3ad4243110aac5f287b96347cc23d5f087f5b2dfb4f7de0e14baf50e26e15a")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/adr/0071-delta-location-indice-m1.md.txt"
   :BYTES 3078 :DEVICE 16777232 :INODE 1563274654 :MTIME 1793443105 :SHA256
   "7aea34147645dc4a898861102b750720396437e2c22f6a40afc1ea2a8e01850a")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/adr/0072-rinnovo-automatico-delta-m1.md.txt"
   :BYTES 2714 :DEVICE 16777232 :INODE 1563274656 :MTIME 1793443106 :SHA256
   "1af8e13b38efa61b04d83d6c255b1e7d1c189bcfc07b5d68d9797c98c3001652")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/adr/0073-indice-automatico-operativo-m1.md.txt"
   :BYTES 3763 :DEVICE 16777232 :INODE 1563274658 :MTIME 1793443106 :SHA256
   "00a57939d1bbd71d950a6d30835af47747e3cfdcafc4358c7b28502b3bbdf394")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/adr/README.md.txt"
   :BYTES 15273 :DEVICE 16777232 :INODE 1563274708 :MTIME 1793443106 :SHA256
   "313fda23b62bdb252978f29a7c398c5309117a81cd72399cb63016c77fc930a1")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/implementazione/README.md.txt"
   :BYTES 3081 :DEVICE 16777232 :INODE 1563274722 :MTIME 1793443106 :SHA256
   "5202c40a697712243eb792a7239604bb6d2bcd921c237faad9b96cc685544711")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/implementazione/delta-indice-m1.md.txt"
   :BYTES 4519 :DEVICE 16777232 :INODE 1563274730 :MTIME 1793443107 :SHA256
   "160d6a8e1e035161c82e242d0419e55ee20ade254deebeb14eb3bb58c478bbe5")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/implementazione/delta-location-m1-metodo.md.txt"
   :BYTES 4265 :DEVICE 16777232 :INODE 1563274806 :MTIME 1793443107 :SHA256
   "664ce35f5746a860a87becc473c7b33e4322ba0cdc988f6c6318d573b633edbc")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/implementazione/delta-location-m1.md.txt"
   :BYTES 4408 :DEVICE 16777232 :INODE 1563274823 :MTIME 1793443107 :SHA256
   "a540ff9d7a9c18241cd9ef192cceb5ad32e8f578ff9036f285e1f197f746770a")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/implementazione/indice-automatico-completamento-metodo.md.txt"
   :BYTES 2451 :DEVICE 16777232 :INODE 1563274830 :MTIME 1793443107 :SHA256
   "80aa0090aef4b31baf2c2c7e2becce4bef5d4ddbeb48480340df6e8c823c01f2")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/implementazione/indice-automatico-operativo.md.txt"
   :BYTES 7318 :DEVICE 16777232 :INODE 1563274871 :MTIME 1793443108 :SHA256
   "092152d9073cc8b7e59a74e816051d85fc534ac3a55bc47c716f4c829a89442d")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/implementazione/indice-automatico.md.txt"
   :BYTES 10273 :DEVICE 16777232 :INODE 1563274884 :MTIME 1793443108 :SHA256
   "40fce425f2246e603e8e4cc820ab647acfeffde8810620e6689f309ef4e8df73")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/implementazione/manutenzione-indice-m1.md.txt"
   :BYTES 4020 :DEVICE 16777232 :INODE 1563274890 :MTIME 1793443108 :SHA256
   "7970276db1edf689a8010ab44650b959d54d35f20b577d73cc30fd3003dd2530")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/implementazione/rinnovo-automatico-m1-metodo.md.txt"
   :BYTES 2476 :DEVICE 16777232 :INODE 1563274968 :MTIME 1793443109 :SHA256
   "2dbe6abd35413a1b804c3eea33075c30cf9775cf3adb78d50094ce5a262e752f")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/implementazione/rinnovo-automatico-m1.md.txt"
   :BYTES 5449 :DEVICE 16777232 :INODE 1563274985 :MTIME 1793443109 :SHA256
   "050dae4d6326124cd23b4aa06c2c3dd46cf248c05c7b8f6fed853d30d342853a")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/invarianti.md.txt"
   :BYTES 21971 :DEVICE 16777232 :INODE 1563274614 :MTIME 1793443105 :SHA256
   "7bd4fb90feda603c2642b42966f7297a4a2f803a05e31a6a90e6d5731984b116")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/tracciabilita/matrice.md.txt"
   :BYTES 65840 :DEVICE 16777232 :INODE 1563274986 :MTIME 1793443109 :SHA256
   "f5ca19f462250f2675223f8f284398db50f3b47bd48195bcc9c2d26d4980eaaa")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/docs/tracciabilita/requisiti.lisp.txt"
   :BYTES 50489 :DEVICE 16777232 :INODE 1563275061 :MTIME 1793443110 :SHA256
   "b126ee9a31d94f96ea324083a05fa20972a1dd5088709b2efd1ea504e240bac3")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/adopt.lisp.txt"
   :BYTES 6676 :DEVICE 16777232 :INODE 1563275072 :MTIME 1793443110 :SHA256
   "5bfed7e43533f89432d765b7749b2fd5cbba654a818d7e0e735957cd0de7e869")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/config.lisp.txt"
   :BYTES 3166 :DEVICE 16777232 :INODE 1563275097 :MTIME 1793443110 :SHA256
   "8fd7a099377e578ef2db6dce93f6f258718b4e6f3696916fd0e1c7c07768cfd9")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/delta-location.lisp.txt"
   :BYTES 6991 :DEVICE 16777232 :INODE 1563275134 :MTIME 1793443110 :SHA256
   "8322209ceb11669521d8adb0eb73e0eae71822cf851b95c84fe6601a7bcc54a6")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/delta-types.lisp.txt"
   :BYTES 3873 :DEVICE 16777232 :INODE 1563275136 :MTIME 1793443110 :SHA256
   "465288cbf0af8f99f6b0d064794c2488983034eaf42a06da8050d96a3e3e87e1")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/delta.lisp.txt"
   :BYTES 4987 :DEVICE 16777232 :INODE 1563275141 :MTIME 1793443111 :SHA256
   "3ea372db67d4d88f49dfa0ac0d64fd5f8bfd186800619ab322f8dcfd88d20c91")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/image-activation.lisp.txt"
   :BYTES 7081 :DEVICE 16777232 :INODE 1563275173 :MTIME 1793443111 :SHA256
   "92fdc69a19bc1d72539bff7c47a3c91e219f96dcd5ddcbd3c0d67ff6e68fe6f7")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/image-auto-types.lisp.txt"
   :BYTES 877 :DEVICE 16777232 :INODE 1563275180 :MTIME 1793443111 :SHA256
   "0bdfadda6bcd86feb046f0c612cd31dd96f8a005ce0eb5a547083f437701005c")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/image-auto-write.lisp.txt"
   :BYTES 5381 :DEVICE 16777232 :INODE 1563275186 :MTIME 1793443111 :SHA256
   "f52a7ec8cc2d2af6c394ab3344f383cea0c824e0b18d3c7339e7b26cf58d1367")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/image-auto.lisp.txt"
   :BYTES 3569 :DEVICE 16777232 :INODE 1563275195 :MTIME 1793443112 :SHA256
   "1f5e31c62ef2ef13b355af03025bd995b7bac0003996a0474e5597d465f57885")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/image-build.lisp.txt"
   :BYTES 3533 :DEVICE 16777232 :INODE 1563275208 :MTIME 1793443112 :SHA256
   "a8f0f64b40c6484689d9f8d335c610a2b0874ac40d029da17066c176a5e95ad4")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/image-maintenance-config.lisp.txt"
   :BYTES 1118 :DEVICE 16777232 :INODE 1563275209 :MTIME 1793443112 :SHA256
   "e4b4bee611abb17d4d54e0029c2133fad2d8293887004f6117cd03a342ee4f40")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/image-maintenance.lisp.txt"
   :BYTES 3926 :DEVICE 16777232 :INODE 1563275231 :MTIME 1793443113 :SHA256
   "1f841df1d698649b1a4142030da36756aa1df6a0bdb71358986be8bb6791f6a9")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/image-renewal.lisp.txt"
   :BYTES 5059 :DEVICE 16777232 :INODE 1563275232 :MTIME 1793443113 :SHA256
   "f80a0359d03e7fba9c5b441f031602e6864f89ddfb4ec27fe20b0d607c88512a")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/image-source.lisp.txt"
   :BYTES 5113 :DEVICE 16777232 :INODE 1563275235 :MTIME 1793443113 :SHA256
   "e4d8405d299f3b800f831be185ae23de9f0cbe90c20188801a467b4efa1bf914")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/index-auto-api.lisp.txt"
   :BYTES 4011 :DEVICE 16777232 :INODE 1563275279 :MTIME 1793443113 :SHA256
   "dfb71e800b49f951faaea7681f5969ac4b9df5deb9b70ebeaf62d0e2306feedc")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/index-auto-apply.lisp.txt"
   :BYTES 4856 :DEVICE 16777232 :INODE 1563275280 :MTIME 1793443113 :SHA256
   "b7ca5661dba389d8ac8f82a4ac37423e97a26b0e13ef5cfab1a2c02c8b2303cb")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/index-auto-files.lisp.txt"
   :BYTES 7567 :DEVICE 16777232 :INODE 1563275283 :MTIME 1793443114 :SHA256
   "65463b713fc0ed79946e9b7ff52cecbe7c548d6c36eb0279c18fbdf256ff99e5")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/index-auto-memory.lisp.txt"
   :BYTES 9863 :DEVICE 16777232 :INODE 1563275302 :MTIME 1793443114 :SHA256
   "0c9c73ed246b4f3dfa6984ae13a932746fc5ec0bdd186f360ac073811edbeefe")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/index-auto-migrate.lisp.txt"
   :BYTES 8616 :DEVICE 16777232 :INODE 1563275309 :MTIME 1793443114 :SHA256
   "4dfd60213946814310d01c69b7092aab380cef70a6be64d7b790b7f6a0a268c3")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/index-auto-resolver.lisp.txt"
   :BYTES 4568 :DEVICE 16777232 :INODE 1563275319 :MTIME 1793443114 :SHA256
   "a04860b7954b3a558ca6eb9e8c04e0eebd713948a44b4579fc1733d2b5585aac")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/index-auto-types.lisp.txt"
   :BYTES 2782 :DEVICE 16777232 :INODE 1563275329 :MTIME 1793443115 :SHA256
   "2e8060f405a375e436d7d5e5f5d774f85143712dddb637b6b7bbaf64c4a22173")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/index.lisp.txt"
   :BYTES 5450 :DEVICE 16777232 :INODE 1563275334 :MTIME 1793443115 :SHA256
   "125758e677cc051abe3f59059f17dd7b5119fe5ab9d0475337bbc0cf5ba518b9")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/lifecycle.lisp.txt"
   :BYTES 6580 :DEVICE 16777232 :INODE 1563275337 :MTIME 1793443115 :SHA256
   "bbc8dd306cd205a191464322ec64fa0ee2819ab4f6bde8208c715878a7fb5d8a")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/package.lisp.txt"
   :BYTES 2124 :DEVICE 16777232 :INODE 1563275375 :MTIME 1793443116 :SHA256
   "8aaa64d7de025aba76322c4033877193690cd9b5d5bd2af7a0cb9c20f1ef8692")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/read.lisp.txt"
   :BYTES 5848 :DEVICE 16777232 :INODE 1563275377 :MTIME 1793443116 :SHA256
   "8dd0cf525725f3356f86fff8e041c564747a2eca49086a76af414a786b917f27")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/startup.lisp.txt"
   :BYTES 7150 :DEVICE 16777232 :INODE 1563275378 :MTIME 1793443116 :SHA256
   "d1943d04db968aec0322e9501a9611b938ca82a3a49a12a2638c6be3b7b6c9a7")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/types.lisp.txt"
   :BYTES 3752 :DEVICE 16777232 :INODE 1563275409 :MTIME 1793443116 :SHA256
   "819d72d301f66c5491cc43407b9656567f7e0d4e1c72a4937659d70bf961abc6")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/engine/write.lisp.txt"
   :BYTES 8693 :DEVICE 16777232 :INODE 1563275412 :MTIME 1793443116 :SHA256
   "7e98968e399b60cb5b10c154318e9fc2c2697497dea3110e6edacf931ac547c8")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/get-resolver/read.lisp.txt"
   :BYTES 7437 :DEVICE 16777232 :INODE 1563275418 :MTIME 1793443116 :SHA256
   "b0591550b864ea4ed51c405afa48483dd35a620f95ba563851cf44bc83addaa1")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/get-resolver/types.lisp.txt"
   :BYTES 1849 :DEVICE 16777232 :INODE 1563275427 :MTIME 1793443117 :SHA256
   "42f3aac7096d111a5bf985ad7a379e5cc9bea5302a7d122d52258ab01e493996")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/get/build.lisp.txt"
   :BYTES 4244 :DEVICE 16777232 :INODE 1563275448 :MTIME 1793443117 :SHA256
   "8865ed17835aef9c4113e329e844063a73c3f8d65702476723ceceefff02c9b7")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/get/types.lisp.txt"
   :BYTES 4598 :DEVICE 16777232 :INODE 1563275455 :MTIME 1793443117 :SHA256
   "8dfb787b8f45453e824d218190f714b91e7d9dd139147ed9ef353e5524c45837")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/index-disk/api.lisp.txt"
   :BYTES 5263 :DEVICE 16777232 :INODE 1563275471 :MTIME 1793443118 :SHA256
   "c7a14be3b1d2d5b604a2caa902907fa392f0fc834e4fdfc89bb8e56b9a1ac552")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/index-disk/balance.lisp.txt"
   :BYTES 3524 :DEVICE 16777232 :INODE 1563275472 :MTIME 1793443118 :SHA256
   "62d9e3139392275d7d12cae40c79368f1ac8561fd772ba8b8db65b9ec7cb945e")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/index-disk/build.lisp.txt"
   :BYTES 5224 :DEVICE 16777232 :INODE 1563275474 :MTIME 1793443118 :SHA256
   "17281a326a94547d836073c6f09e456916d312fda92b5f09b05a98ac7fd6c333")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/index-disk/cache.lisp.txt"
   :BYTES 4240 :DEVICE 16777232 :INODE 1563275514 :MTIME 1793443118 :SHA256
   "ca9a22eb16996cc4773c232cfa8cd8364d4161171f209a2aa6a966b66e213ddd")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/index-disk/copy.lisp.txt"
   :BYTES 4189 :DEVICE 16777232 :INODE 1563275517 :MTIME 1793443119 :SHA256
   "e207be2ea3e610032a3841e1145b35d8d42b93c2a3002f4872e3a7951fea7b6d")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/index-disk/mutate.lisp.txt"
   :BYTES 3703 :DEVICE 16777232 :INODE 1563275518 :MTIME 1793443119 :SHA256
   "7cd7206d4a00801048131d71b27abdcd5dbf8a08229e7f5755cc1602bcdac2d0")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/index-disk/package.lisp.txt"
   :BYTES 961 :DEVICE 16777232 :INODE 1563275558 :MTIME 1793443119 :SHA256
   "6253db262030dda083a52ba7091b78abf538ed1f32b585f6f6feaa6bf8edca29")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/index-disk/read.lisp.txt"
   :BYTES 7844 :DEVICE 16777232 :INODE 1563275560 :MTIME 1793443119 :SHA256
   "524e7d7acd6cd05992c3754d855f1f35a608f3d115229eed1696153a78e1a4f8")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/index-disk/types.lisp.txt"
   :BYTES 6599 :DEVICE 16777232 :INODE 1563275561 :MTIME 1793443119 :SHA256
   "edd640e5cc9ef718a44d85011965384b771499df13540ddd86cea5089d0d1ac1")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/index-disk/visit.lisp.txt"
   :BYTES 6211 :DEVICE 16777232 :INODE 1563275574 :MTIME 1793443120 :SHA256
   "e1ed5c8dbe00c48c0e01e29670795a50a862d26d6fc27d7e0c898d816d43ebb0")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/index-disk/write.lisp.txt"
   :BYTES 5959 :DEVICE 16777232 :INODE 1563275577 :MTIME 1793443120 :SHA256
   "2646c0b630113c6a73c25006e3e1191c0e3ef0b1c2e95411b1aa13662e321dc4")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/io/derived-remove.lisp.txt"
   :BYTES 4175 :DEVICE 16777232 :INODE 1563275578 :MTIME 1793443120 :SHA256
   "d0d3ac184aeac9a5c875b1549c68fd7c6a83d1688126980210f744838fc21f79")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/io/package.lisp.txt"
   :BYTES 1153 :DEVICE 16777232 :INODE 1563275611 :MTIME 1793443121 :SHA256
   "272955b74f9d206dbc9b9457715873d195a4b2d9828858480dd222c3816cac96")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/src/io/types.lisp.txt"
   :BYTES 6411 :DEVICE 16777232 :INODE 1563275612 :MTIME 1793443121 :SHA256
   "2f17414beaf7df39132299ff603558e03c53e766eb4f992fb71871a669192cc2")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/tests/engine/delta-location.lisp.txt"
   :BYTES 16212 :DEVICE 16777232 :INODE 1563275613 :MTIME 1793443121 :SHA256
   "727831dd43127157c228d80cc227217ba6bc29dee795dedad447ff7f07d204cc")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/tests/engine/delta.lisp.txt"
   :BYTES 11892 :DEVICE 16777232 :INODE 1563275657 :MTIME 1793443121 :SHA256
   "0de534e3db1d15c6b3364056b598ed5d98ac041553a5dea56f74e3b94cc1cf10")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/tests/engine/image-auto.lisp.txt"
   :BYTES 23129 :DEVICE 16777232 :INODE 1563275671 :MTIME 1793443121 :SHA256
   "99cdcbb8817c2b09a0b758ab9cc6779b9f606fdf5b18c1c574c43a156e03b9d6")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/tests/engine/image-build.lisp.txt"
   :BYTES 18184 :DEVICE 16777232 :INODE 1563275687 :MTIME 1793443122 :SHA256
   "4aaced115a44cd0b3af38385c49fe4069ccca13eb2b5013807c7e8a54fd6717a")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/tests/engine/index-auto-disk.lisp.txt"
   :BYTES 13619 :DEVICE 16777232 :INODE 1563275774 :MTIME 1793443122 :SHA256
   "11be95609c3bf675d57618a957a811b549aedd760c4e979ea10482cbeaf4f5c9")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/tests/engine/index-automatic.lisp.txt"
   :BYTES 16382 :DEVICE 16777232 :INODE 1563275782 :MTIME 1793443122 :SHA256
   "299e25572ca363ca88002f841034660aaf7a97eeb3c1a417b7a372781b9a1dbd")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/tests/engine/processes.lisp.txt"
   :BYTES 6516 :DEVICE 16777232 :INODE 1563275783 :MTIME 1793443122 :SHA256
   "a94e21153975e6710690cae6ab37b31ed59f7e1b93dbc27ae43f91ce740ab66d")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/tests/engine/support.lisp.txt"
   :BYTES 5494 :DEVICE 16777232 :INODE 1563275801 :MTIME 1793443123 :SHA256
   "8c9468d741b75fa8ade496831d760888bee3483fc2023f65b91a730164889aa9")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/source-final/tests/local/server.lisp.txt"
   :BYTES 9667 :DEVICE 16777232 :INODE 1563275806 :MTIME 1793443123 :SHA256
   "2611ef7e52eb874f91cd2620f6efc78b2253dab4abb009232430b2d5224ee2a4")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/supplemental-before-retirement-review.lisp"
   :BYTES 348 :DEVICE 16777232 :INODE 1563274429 :MTIME 1793443097 :SHA256
   "f8cef75b4491fc78501cba787374a2cc33764ada74c8f617505c785b97ed5035")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/supplemental-before-retirement-review.lisp.gz"
   :BYTES 101577 :DEVICE 16777232 :INODE 1563274442 :MTIME 1793443098 :SHA256
   "9f1fc95f7965260f79cbc3a13b099b5ea88d22891c95c3ad46c9f97ceaec28d7")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/targeted-before-retirement-review.lisp"
   :BYTES 344 :DEVICE 16777232 :INODE 1563274447 :MTIME 1793443098 :SHA256
   "67f6f76437a45d10864edfd35d074e0bb2c04b8ded4cb163909596c0af3ed197")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/targeted-before-retirement-review.lisp.gz"
   :BYTES 103072 :DEVICE 16777232 :INODE 1563274448 :MTIME 1793443098 :SHA256
   "b6e0624d78dedd4c8a5a877d6a40c92f710844fa4dbb78aae6f7e1cbf3f639be")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/targeted-final-2.6.10.lisp"
   :BYTES 332 :DEVICE 16777232 :INODE 1563274456 :MTIME 1793443099 :SHA256
   "51e39b27eee544d27cd494582bd37bf0199406cbe172eedad866d2f4d7e00a83")
  (:PATH
   "spikes/results/2026-10-31-engine-automatic-index/targeted-final-2.6.10.lisp.gz"
   :BYTES 103112 :DEVICE 16777232 :INODE 1563274462 :MTIME 1793443099 :SHA256
   "93eae83d0e28409016ca7abb57fa366032831ff2563bdb3ae4b89a91eb4832b0")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-full-unused-binding/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564077991 :MTIME 1793462037 :SHA256
   "9363224b0b3a643908ddfb92146cd7ac49620be0a745e727bc04c45f5a8edf9b")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-full-unused-binding/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1564077992 :MTIME 1793462037 :SHA256
   "6e43a83f5f6060a05a27c21419e5cc5f1be9f17a3b98efc07075fb36c37c4ad2")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-full-unused-binding/report.lisp.gz"
   :BYTES 158401 :DEVICE 16777232 :INODE 1564077993 :MTIME 1793462037 :SHA256
   "73bdc5ff8615a325e6373411b9ea91a07d367df161243736cd58ef393a9f5bdf")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-integration-counter/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564077995 :MTIME 1793462037 :SHA256
   "4b9117671102fec3caaeaf9162313b7f8bc72bbaf7d0038a41172c49b0cdeb61")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-integration-counter/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564077996 :MTIME 1793462037 :SHA256
   "f8aba27f0692b540ba1192b254dfb8201e940f2d1520f1e78edeeb196348bfdd")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-integration-counter/report.lisp.gz"
   :BYTES 106511 :DEVICE 16777232 :INODE 1564077997 :MTIME 1793462037 :SHA256
   "2239db4094333bdeb9e1ad1d0216516e1e25b6e7df703e38fb1d031de6e6afe3")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-integration-reader/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564077999 :MTIME 1793462037 :SHA256
   "9a4176ebaec23ed2c1b2853e0fc43db28639bac14f21a8014bd47d2e8a7f9568")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-integration-reader/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078000 :MTIME 1793462037 :SHA256
   "0bb51a305ff0e90c564ce35563a712895cb4080c8a17f63447dd0be093db47fe")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-integration-reader/report.lisp.gz"
   :BYTES 106177 :DEVICE 16777232 :INODE 1564078001 :MTIME 1793462037 :SHA256
   "f39709a78620871429a350bac9d4fdf2bc348b93152a417f29e841cb7ef7bced")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-smoke-asdf/conservazione.lisp"
   :BYTES 1178 :DEVICE 16777232 :INODE 1564078003 :MTIME 1793462037 :SHA256
   "9bfd87bc762e7977f3bb3adc64c1865c55d6050165c275f643dfba6b7061b278")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-smoke-asdf/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078004 :MTIME 1793462037 :SHA256
   "9ebbaf06f7b7ce4ab5a65b6832cf25d390419ac78512d94b273a6c9ac718e571")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-smoke-asdf/report.lisp.gz"
   :BYTES 104416 :DEVICE 16777232 :INODE 1564078005 :MTIME 1793462037 :SHA256
   "8c8f159a800c17f39b6dca130dfcbeaee9d91fe970e786fba8df8a11df28cb43")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-smoke-csn/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078007 :MTIME 1793462037 :SHA256
   "56208397b4d3bc8bf46e6f0f4106c7f0eb79a8cfa82c6b2d1a55673f94bf39d8")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-smoke-csn/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078008 :MTIME 1793462037 :SHA256
   "59b48f173009f07d58252d2807060950293a6cb51ebfa73baee3c286cc96c6fa")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-smoke-csn/report.lisp.gz"
   :BYTES 104238 :DEVICE 16777232 :INODE 1564078009 :MTIME 1793462037 :SHA256
   "28ea073be1984f6c4f8a1eeda045bca5dd8039c11d24b94c25ff89306d248ac4")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-smoke-driver/conservazione.lisp"
   :BYTES 1181 :DEVICE 16777232 :INODE 1564078011 :MTIME 1793462037 :SHA256
   "3ba84f90268f2dd627768c79c9551f94db3d9e69c4b7c8ca85b0d5ca85ced1f7")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-smoke-driver/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078012 :MTIME 1793462037 :SHA256
   "dbe788b6f99212112da3256d2991ff50131365772eefb7e4f8bb85911e8180c6")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-smoke-driver/report.lisp.gz"
   :BYTES 103844 :DEVICE 16777232 :INODE 1564078013 :MTIME 1793462037 :SHA256
   "4f0beed90dc35e24530f6a2e3e7c8193e34ada9966f688c36b7d82bc1a93fd61")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-targeted-key-size/conservazione.lisp"
   :BYTES 1181 :DEVICE 16777232 :INODE 1564078015 :MTIME 1793462037 :SHA256
   "e008e29a14f26a7574462258324d48229b10b471a444a6fa2f86ee33fdb52d45")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-targeted-key-size/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078016 :MTIME 1793462037 :SHA256
   "6f424931055b2c1544bec937a1a2ceb2373663fed1ef88d25a83a1bee3398fdf")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-targeted-key-size/report.lisp.gz"
   :BYTES 104932 :DEVICE 16777232 :INODE 1564078017 :MTIME 1793462037 :SHA256
   "f02a4370fb774d51eba579d5790077a5ea1caf66d08d4d7133bf98a0b9ae2ae5")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-targeted-reader/conservazione.lisp"
   :BYTES 1181 :DEVICE 16777232 :INODE 1564078019 :MTIME 1793462037 :SHA256
   "8450b0e5a310b801348f9526f78453287f378f6087bb8968f34bfea888d417f4")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-targeted-reader/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078020 :MTIME 1793462037 :SHA256
   "8b416303871193da3308af495343122c6950d07a09673de3eed8f39702924ad0")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-targeted-reader/report.lisp.gz"
   :BYTES 104971 :DEVICE 16777232 :INODE 1564078021 :MTIME 1793462037 :SHA256
   "5204e6d55295dc81cd9bf55d4f1bce935b7e5e57b97760bf247663f1257e5acf")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-targeted-snapshot/conservazione.lisp"
   :BYTES 1181 :DEVICE 16777232 :INODE 1564078023 :MTIME 1793462037 :SHA256
   "84cdec78817c13f185375b82ce0f4e0ea33301331bbf47ac86173bbf53afd12d")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-targeted-snapshot/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078024 :MTIME 1793462037 :SHA256
   "4a6293b003bc8db1302e900f537fea0e03d4ab95bc21990ea0bded3706667437")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/attempt-targeted-snapshot/report.lisp.gz"
   :BYTES 104622 :DEVICE 16777232 :INODE 1564078025 :MTIME 1793462037 :SHA256
   "d8278838b78389f6ef3b54f18fbe2efbbc7a2703e08d05ee52245d267d6b9788")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.10-v1-paged/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078027 :MTIME 1793462037 :SHA256
   "8ab6f825f6df198044786403fd7eb1e28c3e1e47dba4a1c79f269f03fd0d31cb")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.10-v1-paged/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078028 :MTIME 1793462037 :SHA256
   "26fee9ea1036f6b0f3ee5e4322c4c897ba08a9d0f2190db5000c4dfcda23155c")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.10-v1-paged/report.lisp.gz"
   :BYTES 113542 :DEVICE 16777232 :INODE 1564078029 :MTIME 1793462037 :SHA256
   "a19282d4bada79c72ccedc73f0db293665fff0c5ad78bd31b489107be5b9b092")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.10-v1-resident/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078031 :MTIME 1793462037 :SHA256
   "ca4850e13b0aa7a7fc43e2fc5c77fac128cd550f7b902a255e2250d0940f92e3")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.10-v1-resident/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078032 :MTIME 1793462037 :SHA256
   "ab26347d5986f3d6176fb269fc7fa1145ae803d55b431c35a6228b5218f4907b")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.10-v1-resident/report.lisp.gz"
   :BYTES 109074 :DEVICE 16777232 :INODE 1564078033 :MTIME 1793462037 :SHA256
   "186cd8c2db117b50b1dab8faa0b46ddfc4c49963f5fcbd7129c26dd5ad1744a2")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.10-v2-paged/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078035 :MTIME 1793462037 :SHA256
   "5aaaa5eb3497509fbe0f69d3626e98a01a60dfaa3ac3f4236ea0a5971fc2f0c3")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.10-v2-paged/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078036 :MTIME 1793462037 :SHA256
   "95d38730be63df3d70ec50dba9ef4b8747a863abcff1f768b6c87f5c8dd3555a")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.10-v2-paged/report.lisp.gz"
   :BYTES 113746 :DEVICE 16777232 :INODE 1564078037 :MTIME 1793462037 :SHA256
   "f7e7008bd589b2e95df837ee8beb2ba577a9061a4a3de7d81a88b2a260ac061b")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.10-v2-resident/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078039 :MTIME 1793462037 :SHA256
   "14784932ee5c71601e91c8df39a224f0e69809746c8eb1e9b44197174dc721b0")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.10-v2-resident/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078040 :MTIME 1793462037 :SHA256
   "91109b2c22c36418d23664dc91be25fc8f967bdb1a72a28ae9ac3574e8b8ba09")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.10-v2-resident/report.lisp.gz"
   :BYTES 109014 :DEVICE 16777232 :INODE 1564078041 :MTIME 1793462037 :SHA256
   "a569910edb3de4e6227a5a7808045686e50ac440958adcf3e42b9a68fb89336c")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.9-v1-paged/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078043 :MTIME 1793462037 :SHA256
   "e8101531c5f4f74aca2860f0428731731f2be0885d179bad8e1ea13af9e2228e")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.9-v1-paged/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078044 :MTIME 1793462037 :SHA256
   "ee9b5425d192d216b3efc516d8c098d223da46660dedc4ff456980e53b02c998")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.9-v1-paged/report.lisp.gz"
   :BYTES 113789 :DEVICE 16777232 :INODE 1564078045 :MTIME 1793462037 :SHA256
   "69188f366e6ba0e1a1d5de6f6ffa4a23fb4e90d6599ab12038d89a2cb751935b")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.9-v1-resident/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078047 :MTIME 1793462037 :SHA256
   "0d0e763958fab6a06d75e49fb48f887f891a608c45d400d90cdc1cca2e3528c8")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.9-v1-resident/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078048 :MTIME 1793462037 :SHA256
   "5aeded44c3fda15263bbdc7b5a69e4d7c6a7fea526dbcf2d34ad89f4808b164f")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.9-v1-resident/report.lisp.gz"
   :BYTES 108978 :DEVICE 16777232 :INODE 1564078049 :MTIME 1793462037 :SHA256
   "e922213f798f65efb0487bae05d9d763d20578951425f89cc288201087f883c2")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.9-v2-paged/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078051 :MTIME 1793462037 :SHA256
   "15efeae9cdb2673b645cf3b42c8cb602e570a6b74aabccc227669cdd9cf74257")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.9-v2-paged/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078052 :MTIME 1793462037 :SHA256
   "69a2cc060e6cc4143decf38f1830b775ff8478e1bed85136c8d229ae89723bbd")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.9-v2-paged/report.lisp.gz"
   :BYTES 113821 :DEVICE 16777232 :INODE 1564078053 :MTIME 1793462037 :SHA256
   "baab073e744019344dcc385e53e1f2f8e59d2c8e48c8636d1562811866d9ad67")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.9-v2-resident/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078055 :MTIME 1793462037 :SHA256
   "d8602adbb18eb438e2f1bfc897aad44318dcb5584ff0d0de547aa453c222623b")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.9-v2-resident/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078056 :MTIME 1793462037 :SHA256
   "c1c37abcc209f06984d19318793d3d4563c247ebf76193d19c6826dd0704506a")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-2.6.9-v2-resident/report.lisp.gz"
   :BYTES 108992 :DEVICE 16777232 :INODE 1564078057 :MTIME 1793462037 :SHA256
   "c60d5486caa3e170869438309136162274a13000f0f22524a2f42f59660affd2")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-initial-resident-v2/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078059 :MTIME 1793462037 :SHA256
   "ee63004cf1a5334193d2e4319abff447822726604515373e344d4db5dc543d10")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-initial-resident-v2/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078060 :MTIME 1793462037 :SHA256
   "dddb66dfa49b9007d83c176ba9ed424564871417381285d8445dc2ee725c62f8")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-initial-resident-v2/report.lisp.gz"
   :BYTES 107257 :DEVICE 16777232 :INODE 1564078061 :MTIME 1793462037 :SHA256
   "6ff5730fa88b7dfb20881b2c5e84c83d775fa8f6cb9cc7dd5f82986ffded5f1e")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-selftest-2.6.9/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078063 :MTIME 1793462037 :SHA256
   "94e5ec0aeef2914550d13cf18101f15dc33f32a0b33414bfd40ef3c539b683ea")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-selftest-2.6.9/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078064 :MTIME 1793462037 :SHA256
   "e6e87915fae6f4f9afd27fa040038a934f9d2589d8a2ae5af28ff7dd6440d28b")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/bench-selftest-2.6.9/report.lisp.gz"
   :BYTES 103393 :DEVICE 16777232 :INODE 1564078065 :MTIME 1793462037 :SHA256
   "67d3226e9a85a5c4ef28fc95725a043d6eed031f0145b6dfe2e69d7de5a32457")
  (:PATH "spikes/results/2026-10-31-engine-compaction/bench.lisp" :BYTES 8206
   :DEVICE 16777232 :INODE 1564078066 :MTIME 1793462037 :SHA256
   "001cda04705d526417cc6c9dc70f86d03b5e31bdcdd89b4e6fa603fd4eb12d78")
  (:PATH "spikes/results/2026-10-31-engine-compaction/cleanup.lisp" :BYTES 261
   :DEVICE 16777232 :INODE 1564078067 :MTIME 1793462037 :SHA256
   "3cf965b55db3b5cd1ba510771a385d66b7fe24eed377569a9d3c9200f05dc827")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/compact-final-records.lisp"
   :BYTES 7082 :DEVICE 16777232 :INODE 1564078068 :MTIME 1793462037 :SHA256
   "8810f384c3228ca37eff63d22c0d4ffa929eadb94d88cf8465f12e25dd261309")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/compact-small-records.lisp"
   :BYTES 8234 :DEVICE 16777232 :INODE 1564078069 :MTIME 1793462037 :SHA256
   "e36d8b35dc4d417606ac69b9f8d5224504d20d92da0d9640f7cbd1ce785b634d")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/compact-supporting-records.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078070 :MTIME 1793462037 :SHA256
   "95aa74f39be33f89331840f98d211894c9e127270003ec4ae98542197d05168a")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/docs-2.6.9/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078072 :MTIME 1793462037 :SHA256
   "d81691da720c1bee78ee97b31a5d544e3c97e5bddc659d35c78839238e8cc1dc")
  (:PATH "spikes/results/2026-10-31-engine-compaction/docs-2.6.9/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078073 :MTIME 1793462037 :SHA256
   "a25e8291b21d9dc0128cb759ad68683277ee238a88554c1cb6dd846bd5e8ffef")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/docs-2.6.9/report.lisp.gz"
   :BYTES 105805 :DEVICE 16777232 :INODE 1564078074 :MTIME 1793462037 :SHA256
   "e9fbc052b1cf094661d24b52d79df41f6d06686b8d96d3a7f6e1690c4e1c5a69")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/final-checks/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078076 :MTIME 1793462037 :SHA256
   "cb64a04849f9fce91e2695cee84b12bbf13932711a3333f5784d7b8f40a184de")
  (:PATH "spikes/results/2026-10-31-engine-compaction/final-checks/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078077 :MTIME 1793462037 :SHA256
   "24b05e9805e9892c1338952c6344277d9b438608d96ad669b81371604373a917")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/final-checks/report.lisp.gz"
   :BYTES 105275 :DEVICE 16777232 :INODE 1564078078 :MTIME 1793462037 :SHA256
   "8559ea1bb80e824593075bfe9bf272c265b8a780b37d0cc49008dde5d08f63b4")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/full-2.6.9/conservazione.lisp"
   :BYTES 1776 :DEVICE 16777232 :INODE 1564078080 :MTIME 1793462037 :SHA256
   "d00cadbfcd1c6725cb22d262ee03d4ff335f7eabac7c4b219b5ccabe8f53f509")
  (:PATH "spikes/results/2026-10-31-engine-compaction/full-2.6.9/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1564078081 :MTIME 1793462037 :SHA256
   "466d0b793684b455b7ce56a0cd4756d12bf14ab72870af42e742509cc9975dd1")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/full-2.6.9/report.lisp.gz"
   :BYTES 345462 :DEVICE 16777232 :INODE 1564078082 :MTIME 1793462037 :SHA256
   "7f1abb93e919416173c3a78d4c157ec59c20bac98ab697f589a220e281dbd1d9")
  (:PATH "spikes/results/2026-10-31-engine-compaction/initial-metrics.lisp"
   :BYTES 882 :DEVICE 16777232 :INODE 1564078083 :MTIME 1793462037 :SHA256
   "7b2a8f87777f399de51b611c829d4c9f7dcd0fc73b0a17e14a3304e42018a9ed")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/integration-2.6.9/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078085 :MTIME 1793462037 :SHA256
   "527f3077ce2d0444dab7935acdfa937c5e2b058362cb3dd09fa386517588fd9e")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/integration-2.6.9/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078086 :MTIME 1793462037 :SHA256
   "d2915a77f3002279e24d03147186c80b3d5eadb93dfd1e41819a69e755b6b038")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/integration-2.6.9/report.lisp.gz"
   :BYTES 106075 :DEVICE 16777232 :INODE 1564078087 :MTIME 1793462037 :SHA256
   "2facec69591ceb6d431e708eb34994f09c8dcfa1f3368c5605ad3270cd7b6093")
  (:PATH "spikes/results/2026-10-31-engine-compaction/integration.lisp" :BYTES
   451 :DEVICE 16777232 :INODE 1564078088 :MTIME 1793462037 :SHA256
   "14a7622fd697fc47947f1e5275aa00398ea62b2b9164036414f4f793c01d5fd4")
  (:PATH "spikes/results/2026-10-31-engine-compaction/metrics.lisp" :BYTES 6612
   :DEVICE 16777232 :INODE 1564078089 :MTIME 1793462037 :SHA256
   "ef45b35f19a36bc7f21f0e3932f385c4b22d0e4f2543b0dc5fa2bf000c496c35")
  (:PATH "spikes/results/2026-10-31-engine-compaction/report.md" :BYTES 9070
   :DEVICE 16777232 :INODE 1564078090 :MTIME 1793462037 :SHA256
   "24d49835c45ad9c0c84ca105f9a5d76b513aee9b93b94ef1c4806e8a0b8dc3de")
  (:PATH "spikes/results/2026-10-31-engine-compaction/review.md" :BYTES 2544
   :DEVICE 16777232 :INODE 1564078091 :MTIME 1793462037 :SHA256
   "755c8cf4234a4b9ad09b2a159a6d27abf08ba7b06df42009c66f8058a5b19489")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/smoke-2.6.9/conservazione.lisp"
   :BYTES 1181 :DEVICE 16777232 :INODE 1564078093 :MTIME 1793462037 :SHA256
   "43df0322f33e71c3f66dc661825e7306f24eade00d8eb116a8bb5bf53ec48d6e")
  (:PATH "spikes/results/2026-10-31-engine-compaction/smoke-2.6.9/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078094 :MTIME 1793462037 :SHA256
   "2e14c8f7297f04e059a3dcc95c20432eb4958d9b61d6589ae541f3ae403ec1cc")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/smoke-2.6.9/report.lisp.gz"
   :BYTES 102817 :DEVICE 16777232 :INODE 1564078095 :MTIME 1793462037 :SHA256
   "7b1fc2131c603b7196e72a06b79308ba931be1f215f1a798c4f1b838e02db967")
  (:PATH "spikes/results/2026-10-31-engine-compaction/smoke.lisp" :BYTES 1262
   :DEVICE 16777232 :INODE 1564078096 :MTIME 1793462037 :SHA256
   "ea02f909d6a8ddcce5aeb50287a9d7b01d1ba8b2505e5055758508f8c24ef4c5")
  (:PATH "spikes/results/2026-10-31-engine-compaction/source-identity.lisp"
   :BYTES 1686 :DEVICE 16777232 :INODE 1564078097 :MTIME 1793462037 :SHA256
   "17b23b5f071f39737e6052863cdd27d111c732d35cb9e1bf48d8d511da51fc46")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/strict-2.6.10/conservazione.lisp"
   :BYTES 1776 :DEVICE 16777232 :INODE 1564078099 :MTIME 1793462037 :SHA256
   "8c70acd8a3d9e5d1136b3cfa7cd7a35ae608ad486e27ca47cacecf18a6d4142b")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/strict-2.6.10/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1564078100 :MTIME 1793462037 :SHA256
   "6168609abe37a273de42090d213459b2cfe5f9d2ed2256b9d67ea65eb54e4bbc")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/strict-2.6.10/report.lisp.gz"
   :BYTES 327969 :DEVICE 16777232 :INODE 1564078101 :MTIME 1793462037 :SHA256
   "35317d1b0795b2bdcd59cb022d83158ed9847ecffdd7577def60b65e53118043")
  (:PATH "spikes/results/2026-10-31-engine-compaction/summarize.lisp" :BYTES
   2456 :DEVICE 16777232 :INODE 1564078103 :MTIME 1793462037 :SHA256
   "2fc84d47983b0aeb394a6ea78e94c7cb871562e24d1bf665491670200ccd4d53")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448536-snapshot-self-test-38509-0/report.lisp"
   :BYTES 2021 :DEVICE 16777232 :INODE 1564078106 :MTIME 1793462037 :SHA256
   "17a841d84b13f38ee66393451e809c75129a89249f2e1cdde0ceeb1fcc8e318b")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448537-reader-self-test-38512-0/report.lisp"
   :BYTES 2003 :DEVICE 16777232 :INODE 1564078108 :MTIME 1793462037 :SHA256
   "a7db3963f557ec15d1e9b02d2a514e3cafc346c1148aa8385783a82d7316c1e7")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-01.lisp"
   :BYTES 27228 :DEVICE 16777232 :INODE 1564078110 :MTIME 1793462037 :SHA256
   "cfcaef87dd02b58c162b0d32114466850a8806831041ce845f237885ac1a2617")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-02.lisp"
   :BYTES 1607 :DEVICE 16777232 :INODE 1564078111 :MTIME 1793462037 :SHA256
   "3e3da6552c78cc0faa797db205af71cab0d901e3c24f2d59edb2d37dd5fdb4f4")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-03.lisp"
   :BYTES 3664 :DEVICE 16777232 :INODE 1564078112 :MTIME 1793462037 :SHA256
   "c39f7403291065024ce8d07f973f192cbf1601a9ba4121a942c8c99dce913219")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-04.lisp"
   :BYTES 6752 :DEVICE 16777232 :INODE 1564078113 :MTIME 1793462037 :SHA256
   "ddc2b4a553ea224a0b927d12a3c0585703a0b608d5ca929ec8e23bc9eda157da")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-05.lisp"
   :BYTES 10170 :DEVICE 16777232 :INODE 1564078114 :MTIME 1793462037 :SHA256
   "4cd79b579654ad78b9e7c462f785a715234142ae7cea1ce9c3e1480b5f6b9b25")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-06.lisp"
   :BYTES 24072 :DEVICE 16777232 :INODE 1564078115 :MTIME 1793462037 :SHA256
   "28c626935084ca61e10422a69d5613f0b5fef4c6cdd72973744a78e420d9c79e")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-07.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1564078116 :MTIME 1793462037 :SHA256
   "5464ca8888277566fa2d961c60a5d012b10135462fa0db9d8cdec688a1c7ddef")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-07.lisp.gz"
   :BYTES 411741 :DEVICE 16777232 :INODE 1564078117 :MTIME 1793462037 :SHA256
   "de7442ca5b165bd57197baa226bb40e1183cb781e6f899ad96d6b1fdfeafcc29")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-08.lisp"
   :BYTES 315 :DEVICE 16777232 :INODE 1564078120 :MTIME 1793462037 :SHA256
   "0ab0e3789b7f632f77fe757d3f3bae00b0ad4fae5e4304bacba2d30082046f1d")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-08.lisp.gz"
   :BYTES 45451 :DEVICE 16777232 :INODE 1564078121 :MTIME 1793462037 :SHA256
   "a25b4a1a655d74f0e827f4438574c34873be310f33b52a95746d1c57c0e443f8")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-09.lisp"
   :BYTES 2472 :DEVICE 16777232 :INODE 1564078122 :MTIME 1793462037 :SHA256
   "0c46285c24c5a59d4ec378cf324d4179fd1218d64a3abad732574d75dd18b860")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-10.lisp"
   :BYTES 22975 :DEVICE 16777232 :INODE 1564078123 :MTIME 1793462037 :SHA256
   "6f9fd18681069a0c14055ae43051b9c330147fdb26af4c4d16215fc94840fbe1")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-11.lisp"
   :BYTES 313 :DEVICE 16777232 :INODE 1564078124 :MTIME 1793462037 :SHA256
   "3e6b597056cad9602b997d97fc4df1dd4cb4b487e2a0afd2be68c8f611332128")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/SPK-11.lisp.gz"
   :BYTES 7994 :DEVICE 16777232 :INODE 1564078125 :MTIME 1793462037 :SHA256
   "e9f6f7db5a4ac8251f15fefd8e960f98196cc52ebd3882f1592607f9aa8e1bc1")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/conservazione.lisp"
   :BYTES 2352 :DEVICE 16777232 :INODE 1564078126 :MTIME 1793462037 :SHA256
   "6cfa78da99da3b281bb6d3c857efd0bc2eae3fd37555b69b24bf724927d71a25")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/report.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1564078127 :MTIME 1793462037 :SHA256
   "d54259c6ded90ce8c1598b67f9ccd7ef2b1f3c4dfcfc0220933ad109aa1c8448")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448789-check-44839-0/report.lisp.gz"
   :BYTES 483884 :DEVICE 16777232 :INODE 1564078128 :MTIME 1793462037 :SHA256
   "1b80aa6196e498b6f6d3e309f0e0279700a6a196af3b47b6cc6bf1a7abc57b99")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448836-command-45815-0/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078130 :MTIME 1793462037 :SHA256
   "ced9aaad3969d42e6f59120bd8c31fd717e44525be5b1ace108b07a913e7684f")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448836-command-45815-0/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078131 :MTIME 1793462037 :SHA256
   "b0cca24a15687ce39aa85a4bdd883363550a446164d1697e6b99f42442c43d1c")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/4002448836-command-45815-0/report.lisp.gz"
   :BYTES 104793 :DEVICE 16777232 :INODE 1564078132 :MTIME 1793462037 :SHA256
   "4648eafcde7400e954d507d969980d974bf537348ea72551cbcae944743adf66")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/command-archive-collector-self-test-NOcXJO.lisp"
   :BYTES 28790 :DEVICE 16777232 :INODE 1564078133 :MTIME 1793462037 :SHA256
   "180fa057f130830294a59909ef4fca11b121c9f63bcb3c44f0acf6d112a31b83")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/evidence-parallel-self-test-LLIDXc.lisp"
   :BYTES 3381 :DEVICE 16777232 :INODE 1564078134 :MTIME 1793462037 :SHA256
   "e86a21439afdd8f3e08f124d928a82e1efd965e41b0a39cc3e5602b068a8cb8e")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/record-command-self-test.lisp"
   :BYTES 157 :DEVICE 16777232 :INODE 1564078135 :MTIME 1793462037 :SHA256
   "7e47f646dc8ee821fcd8e3536a898b414e928bb78b4cbfd416d95f7b431a963b")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/selftest-1793460036-45814/boundaries.lisp"
   :BYTES 976 :DEVICE 16777232 :INODE 1564078137 :MTIME 1793462037 :SHA256
   "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/selftest-1793460036-45814/conditions.lisp"
   :BYTES 663 :DEVICE 16777232 :INODE 1564078138 :MTIME 1793462037 :SHA256
   "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/selftest-1793460036-45814/data.lisp"
   :BYTES 3214 :DEVICE 16777232 :INODE 1564078139 :MTIME 1793462037 :SHA256
   "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/selftest-1793460036-45814/measure.lisp"
   :BYTES 2041 :DEVICE 16777232 :INODE 1564078140 :MTIME 1793462037 :SHA256
   "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/selftest-1793460036-45814/publication.lisp"
   :BYTES 1181 :DEVICE 16777232 :INODE 1564078141 :MTIME 1793462037 :SHA256
   "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/selftest-1793460036-45814/report.lisp"
   :BYTES 632 :DEVICE 16777232 :INODE 1564078142 :MTIME 1793462037 :SHA256
   "3bf53e3748c34568e0fb83b9f6f7ed394be5c711a74ca8b7bdde88a45f49bc23")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/selftest-1793460036-45814/tests.lisp"
   :BYTES 2409 :DEVICE 16777232 :INODE 1564078143 :MTIME 1793462037 :SHA256
   "49acae481faadf756a5650f1c389386f54afc7b6e86fca34b8cb0d65726f76e4")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/supporting/selftest-1793460036-45814/workflow.lisp"
   :BYTES 27784 :DEVICE 16777232 :INODE 1564078144 :MTIME 1793462037 :SHA256
   "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/targeted-seven-2.6.9/conservazione.lisp"
   :BYTES 1180 :DEVICE 16777232 :INODE 1564078146 :MTIME 1793462037 :SHA256
   "b10f1db2b9890577e634c02355d38222eb4ed43f40b16c6624b5c7923b510d12")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/targeted-seven-2.6.9/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078147 :MTIME 1793462037 :SHA256
   "18491daea64b2c71b32684084a03c507f47fd4cc223f0b032fe352a1013bb4f5")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/targeted-seven-2.6.9/report.lisp.gz"
   :BYTES 103083 :DEVICE 16777232 :INODE 1564078148 :MTIME 1793462037 :SHA256
   "1c1b58a3d3f52eab1260d9f7ec91da48833329d4b5db173900741d2f07df4698")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/targeted-twelve-2.6.9/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1564078150 :MTIME 1793462037 :SHA256
   "04f3c30a868e97a9081eb5b8c219b31902ea643f30049e83bb96a4059d2c0e1f")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/targeted-twelve-2.6.9/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1564078151 :MTIME 1793462037 :SHA256
   "e4c03a7705aae324534f7f00918dd96ea07a0975b9cb2d49f069e64d7d3dae81")
  (:PATH
   "spikes/results/2026-10-31-engine-compaction/targeted-twelve-2.6.9/report.lisp.gz"
   :BYTES 104378 :DEVICE 16777232 :INODE 1564078152 :MTIME 1793462037 :SHA256
   "b4ee139345a9dbd19cee08097d5e07f9bc81dc32c2776dbd36311565ca0cd2a9")
  (:PATH "spikes/results/2026-10-31-engine-compaction/targeted.lisp" :BYTES 413
   :DEVICE 16777232 :INODE 1564078153 :MTIME 1793462037 :SHA256
   "02c3034df3a25bf265022f2e36f136b25edbd925ad7685f9de5b192ae52ff352")
  (:PATH "spikes/results/2026-10-31-engine-compaction/verify-sources.lisp"
   :BYTES 1298 :DEVICE 16777232 :INODE 1564078154 :MTIME 1793462037 :SHA256
   "a75b0d63faa86e3509ac1458cbc6a6deea058028f7fae5e1b5c25d7aece8226f")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/allocation-final-2.6.10.lisp"
   :BYTES 333 :DEVICE 16777232 :INODE 1563070185 :MTIME 1793426289 :SHA256
   "985535a813a1686d3da27e76ebc77c46a5b5bf15ad1a50b3035a805518b56a76")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/allocation-final-2.6.10.lisp.gz"
   :BYTES 99539 :DEVICE 16777232 :INODE 1563070211 :MTIME 1793426290 :SHA256
   "bc048e9db59ac1b5ca88c361d5404dbde2d8d4be8fd7cf10fd284b8f81d4d6ca")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/allocation-final-2.6.9.lisp"
   :BYTES 332 :DEVICE 16777232 :INODE 1563070254 :MTIME 1793426291 :SHA256
   "85afd3fd93583b99946c0012f4aab5e6e291eea082c12ca844bff2a20c8ac6ea")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/allocation-final-2.6.9.lisp.gz"
   :BYTES 99564 :DEVICE 16777232 :INODE 1563070255 :MTIME 1793426291 :SHA256
   "6f007150172710b2a0cce5615031a8f0ca31ec4240a74bc93d2b7bc257959593")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/allocation-pre-review-2.6.10.lisp"
   :BYTES 338 :DEVICE 16777232 :INODE 1563070090 :MTIME 1793426285 :SHA256
   "c21b74af0f31ae4c4f19e46618b2d3932b6843626532a482bddbe0ca6c17665a")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/allocation-pre-review-2.6.10.lisp.gz"
   :BYTES 99547 :DEVICE 16777232 :INODE 1563070093 :MTIME 1793426285 :SHA256
   "814fe1552215f18287ddd7352f5ba9fcd171c66f8f2377a19ea109c753af5554")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/allocation-pre-review-2.6.9.lisp"
   :BYTES 337 :DEVICE 16777232 :INODE 1563070127 :MTIME 1793426286 :SHA256
   "b18f8c7285da2496f04dcd194616a9e09e784dd818eaf28f690c3efc1bca9eb1")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/allocation-pre-review-2.6.9.lisp.gz"
   :BYTES 99575 :DEVICE 16777232 :INODE 1563070128 :MTIME 1793426286 :SHA256
   "80583d69d0b7f856d87f98c7f3e988dce0a34c0872eba646053b35f9f017f062")
  (:PATH "spikes/results/2026-10-31-engine-location-delta/allocation.lisp"
   :BYTES 4285 :DEVICE 16777232 :INODE 1563070293 :MTIME 1793426293 :SHA256
   "9d5a84e48646074ff9d86e672a5ef92b23d85f9296ca6a59cb69a02f985b8705")
  (:PATH "spikes/results/2026-10-31-engine-location-delta/archive-index.lisp"
   :BYTES 23993 :DEVICE 16777232 :INODE 1563070459 :MTIME 1793426311 :SHA256
   "a414c92d8f9d41b98f81cda44c6d62594f419243140ac7352c6fc80c922c9dda")
  (:PATH "spikes/results/2026-10-31-engine-location-delta/catalogo.lisp" :BYTES
   367 :DEVICE 16777232 :INODE 1563070460 :MTIME 1793426311 :SHA256
   "9c9fdfa55a6ef062f7064bfeaa341a139d872ab4dece8936c0967d2e811e947f")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/ci-attempt-01-failed.lisp"
   :BYTES 329 :DEVICE 16777232 :INODE 1563070146 :MTIME 1793426287 :SHA256
   "2c3b3b99d57d92c34a780077af2250bb51b83a0751fbe2f485b324d5ba509301")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/ci-attempt-01-failed.lisp.gz"
   :BYTES 99410 :DEVICE 16777232 :INODE 1563070147 :MTIME 1793426287 :SHA256
   "41df298f4d71bea45ecb6acfd1cc12080ee98693b2782c8e3124488d5f087759")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/ci-attempt-02-failed.lisp"
   :BYTES 329 :DEVICE 16777232 :INODE 1563070182 :MTIME 1793426289 :SHA256
   "4d3e86620882d0ac89735d51822349808626c2cfc709a6ce42de62db704d52f4")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/ci-attempt-02-failed.lisp.gz"
   :BYTES 99403 :DEVICE 16777232 :INODE 1563070183 :MTIME 1793426289 :SHA256
   "6dcf46ffac146aa98a5edc43f5002888462d768f7c977b0bf02673e90d2a0425")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/ci-data-diagnostic.lisp"
   :BYTES 327 :DEVICE 16777232 :INODE 1563070217 :MTIME 1793426290 :SHA256
   "365c3931933f6a4b050fbf4750763cbd7c81a589e395da8e994cfaf21d59aaf9")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/ci-data-diagnostic.lisp.gz"
   :BYTES 99376 :DEVICE 16777232 :INODE 1563070218 :MTIME 1793426290 :SHA256
   "12632c2045f0a81f0e0efedb1f79195b6bf4d328632d06fcde7bf2758137a90a")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/ci-data-no-status-diagnostic.lisp"
   :BYTES 338 :DEVICE 16777232 :INODE 1563070228 :MTIME 1793426290 :SHA256
   "10e9260ab6159a86faea3ed42bb09d32d8581363fd4d523bc72dba4cb18b2e07")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/ci-data-no-status-diagnostic.lisp.gz"
   :BYTES 99319 :DEVICE 16777232 :INODE 1563070229 :MTIME 1793426290 :SHA256
   "cc973f203fcf6ae39da9d5047394136695601e256acfc253edcef3a8561b25aa")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/ci-exact-diagnostic.lisp"
   :BYTES 328 :DEVICE 16777232 :INODE 1563070231 :MTIME 1793426291 :SHA256
   "495e5bf0003a5aa5e9342cbdc0a07d21600b4d4304512bbe13d397a8aec73209")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/ci-exact-diagnostic.lisp.gz"
   :BYTES 99377 :DEVICE 16777232 :INODE 1563070248 :MTIME 1793426291 :SHA256
   "20880a69747d4fb212c8f3d3bb5dabc02f46e6a0929ecd456d118ece6a980f2b")
  (:PATH "spikes/results/2026-10-31-engine-location-delta/ci-final-2.6.9.lisp"
   :BYTES 323 :DEVICE 16777232 :INODE 1563070272 :MTIME 1793426292 :SHA256
   "43003f01eb2e5f8d96f22e9375aa52a9b1012f01a905b16096f4e8781e96338f")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/ci-final-2.6.9.lisp.gz"
   :BYTES 99426 :DEVICE 16777232 :INODE 1563070291 :MTIME 1793426293 :SHA256
   "7426fd6ed46129dae80e83cb7d5d8ee6b5ea429eb4f993570841cfa43188de0e")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/collection-manifest.lisp"
   :BYTES 11705 :DEVICE 16777232 :INODE 1563070364 :MTIME 1793426297 :SHA256
   "eeec492a0d112ca45352130ff067f7317c0eb9f0d7ffd6c14f023afdf4dfa597")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/collection-source.lisp"
   :BYTES 31268 :DEVICE 16777232 :INODE 1563070378 :MTIME 1793426297 :SHA256
   "4edf03e7257d5d4b19c37cb7c51cec772660f79d9f9268b2db4ad6cb66e55c1e")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/diagnostics/ci-context-debug.lisp.txt"
   :BYTES 1419 :DEVICE 16777232 :INODE 1563070346 :MTIME 1793426296 :SHA256
   "756a68fae40c570903be5a79f2126486933d68d7bf7e4e5d5ccfef557801b358")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/diagnostics/ci-data-debug.lisp.txt"
   :BYTES 1550 :DEVICE 16777232 :INODE 1563070344 :MTIME 1793426296 :SHA256
   "365f2b9c19ba4422f082605cc702725c231bcc7cf8318d5acfd72ab5dd86718a")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/diagnostics/ci-data-diagnostic-source.lisp.txt"
   :BYTES 28924 :DEVICE 16777232 :INODE 1563070361 :MTIME 1793426296 :SHA256
   "4522509375fc34425106464dec071f37e60189e48acce81f4a77fbc36090ae62")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/diagnostics/ci-exact-debug.lisp.txt"
   :BYTES 985 :DEVICE 16777232 :INODE 1563070347 :MTIME 1793426296 :SHA256
   "41661723a844b59e66bab6d26e1a64eecde592010416bb7be5295451fff9df6b")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/diagnostics/prepare-ci-debug.lisp.txt"
   :BYTES 844 :DEVICE 16777232 :INODE 1563070362 :MTIME 1793426297 :SHA256
   "07e3dcfaac133673f55021d0a5b9324acac3a36f884d9b360bd951ab548d5a4d")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/full-attempt-01-changed.lisp"
   :BYTES 335 :DEVICE 16777232 :INODE 1563070106 :MTIME 1793426285 :SHA256
   "ddcec4536380ab1a48dedbdb75db2df680a382e1e09697c000c1bb41d5d296aa")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/full-attempt-01-changed.lisp.gz"
   :BYTES 319023 :DEVICE 16777232 :INODE 1563070107 :MTIME 1793426286 :SHA256
   "0cf12a175ba5cf5d0d94782b2874d0d80c9e0338c171af111f1b0cc2278168ef")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/full-attempt-02-toolchain-mismatch.lisp"
   :BYTES 346 :DEVICE 16777232 :INODE 1563070167 :MTIME 1793426288 :SHA256
   "135597bed348394345c3fce2482db47d2d592b348cf4d9d45004a38520a57e32")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/full-attempt-02-toolchain-mismatch.lisp.gz"
   :BYTES 314497 :DEVICE 16777232 :INODE 1563070170 :MTIME 1793426288 :SHA256
   "5e1a22c4c4aebf4fb3f2f4e688ae3d9fc8ad834235a4202a766e1dd5aeb7fce0")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/full-final-2.6.9.lisp"
   :BYTES 327 :DEVICE 16777232 :INODE 1563070267 :MTIME 1793426292 :SHA256
   "de6c3d25a5567633c612ce8907831063c99725b85c64fa95c11d60be0b0c4407")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/full-final-2.6.9.lisp.gz"
   :BYTES 323466 :DEVICE 16777232 :INODE 1563070270 :MTIME 1793426292 :SHA256
   "5484162a94559607dc3ff6e59f7235c6cfadfe1f76ff7cc3d54d1397b88260dc")
  (:PATH "spikes/results/2026-10-31-engine-location-delta/report.md" :BYTES
   7609 :DEVICE 16777232 :INODE 1563070312 :MTIME 1793426294 :SHA256
   "f18ca0bd39d361cc6771dc735500e220ef3226b081dc16a49f928e514b8040c0")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/snapshots/product-pre-review.lisp.txt"
   :BYTES 6337 :DEVICE 16777232 :INODE 1563070335 :MTIME 1793426295 :SHA256
   "b353704b0ac352bd8f48d9243852d1a3ec461499044d45a7f3462518e5062e64")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/snapshots/tests-attempt-01.lisp.txt"
   :BYTES 8860 :DEVICE 16777232 :INODE 1563070316 :MTIME 1793426294 :SHA256
   "95afcffdcc98bdcdde7fdf50fe133b3a4ef1cca666dd9046c1c09878bfedba4c")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/snapshots/tests-attempt-02.lisp.txt"
   :BYTES 16001 :DEVICE 16777232 :INODE 1563070317 :MTIME 1793426294 :SHA256
   "297e6333dc705af196e820210bc155cb37e9c60bd8aa3424036dd413ab0a1906")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/snapshots/tests-attempt-03.lisp.txt"
   :BYTES 16000 :DEVICE 16777232 :INODE 1563070330 :MTIME 1793426295 :SHA256
   "933e1c56c50d5b1cd0bc1cb089f823ee2ea95c857581bc5f2e0a450eb4b4c4d5")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/snapshots/tests-pre-review.lisp.txt"
   :BYTES 16049 :DEVICE 16777232 :INODE 1563070332 :MTIME 1793426295 :SHA256
   "bb0166b8272de7d18270d534a63ccd38297cdf84c58d3b1b7d76dd048f664cb1")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/targeted-attempt-01-failed.lisp"
   :BYTES 337 :DEVICE 16777232 :INODE 1563070060 :MTIME 1793426283 :SHA256
   "b5d521c65f597cde80d6bdcc25c443694dd875472b938de82ce65f55cb9fcd01")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/targeted-attempt-01-failed.lisp.gz"
   :BYTES 101534 :DEVICE 16777232 :INODE 1563070054 :MTIME 1793426283 :SHA256
   "581bedf97ac65c6cfd325de358a059972c32a0858cf8cadeb554a6dd4bdd9d6b")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/targeted-attempt-02-failed.lisp"
   :BYTES 337 :DEVICE 16777232 :INODE 1563070379 :MTIME 1793426297 :SHA256
   "9d814d02f7f447a6c6743bb76f415facc9e1641f9e57fa919c7fc3ad819b27c5")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/targeted-attempt-02-failed.lisp.gz"
   :BYTES 101321 :DEVICE 16777232 :INODE 1563070055 :MTIME 1793426283 :SHA256
   "10e862821b0a5923036fbefa6252770d174590b8b5d8515e3d03b61f34f95819")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/targeted-attempt-03-failed.lisp"
   :BYTES 337 :DEVICE 16777232 :INODE 1563070066 :MTIME 1793426284 :SHA256
   "4052347fac4b19ec1585100be67b502688ff9e558efbb1f6d37a16812b8ca5a9")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/targeted-attempt-03-failed.lisp.gz"
   :BYTES 101537 :DEVICE 16777232 :INODE 1563070074 :MTIME 1793426284 :SHA256
   "7e0dd81c8473f9e627441b4ba9dedf727550c7c5a03841e29e52649c8293c39e")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/targeted-final-2.6.10.lisp"
   :BYTES 332 :DEVICE 16777232 :INODE 1563070148 :MTIME 1793426287 :SHA256
   "25b315f1dcf7ff196921de5577928ff233340bbcae63129e14440743b6fc5bfc")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/targeted-final-2.6.10.lisp.gz"
   :BYTES 100604 :DEVICE 16777232 :INODE 1563070164 :MTIME 1793426288 :SHA256
   "78170ba97b09b44df889bb63458e6c84db62bd954e44118c0fa4ec5bc2b33403")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/targeted-pre-review-2.6.10.lisp"
   :BYTES 337 :DEVICE 16777232 :INODE 1563070075 :MTIME 1793426284 :SHA256
   "1530be980707c277d90b97bce7cac2d705f230b024be4176e2911c207cff284a")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/targeted-pre-review-2.6.10.lisp.gz"
   :BYTES 100557 :DEVICE 16777232 :INODE 1563070089 :MTIME 1793426285 :SHA256
   "c0abc7d4e14dee22ef0799e80f034b5e4e2cedbb0aa5747bcb274a531bed58c5")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/targeted-pre-review-2.6.9.lisp"
   :BYTES 336 :DEVICE 16777232 :INODE 1563070112 :MTIME 1793426286 :SHA256
   "01f03f644f3002144541ef57eb8ca139a7b5d93f2482812370cebb3f7e4ab22d")
  (:PATH
   "spikes/results/2026-10-31-engine-location-delta/targeted-pre-review-2.6.9.lisp.gz"
   :BYTES 100638 :DEVICE 16777232 :INODE 1563070125 :MTIME 1793426286 :SHA256
   "af67ca03bcfcbb333e26d915f57a470568ff6fe29e0375966d1739798397b590")
  (:PATH "spikes/results/2026-10-31-engine-location-delta/targeted.lisp" :BYTES
   894 :DEVICE 16777232 :INODE 1563070292 :MTIME 1793426293 :SHA256
   "6015873d91f8d6b40df858a7e8dfba0ca89c9f3b97eee04c4109d3f0657b045e")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/attempt-cbor-fixture/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563762526 :MTIME 1793455796 :SHA256
   "cf0ece5fea577ce92c392c137a8c4d6e7a0034bddc801ccf41b3dbdcd4f1c4a3")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/attempt-cbor-fixture/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563762527 :MTIME 1793455796 :SHA256
   "1d33a51d3afde38f7a840a58eaa14b68218e06fbdf50c828bef6f3c48e0902ba")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/attempt-cbor-fixture/report.lisp.gz"
   :BYTES 104337 :DEVICE 16777232 :INODE 1563762528 :MTIME 1793455796 :SHA256
   "e8c5d5bbb61476327f307ba4f96f1595c8104a58940acb192df55f8f542cfe84")
  (:PATH "spikes/results/2026-10-31-live-rotation/cleanup.lisp" :BYTES 191
   :DEVICE 16777232 :INODE 1563762529 :MTIME 1793455796 :SHA256
   "031a0f17be2e0e45f765b44143527adc691dcecac415edd562773e3f6da7bd4b")
  (:PATH "spikes/results/2026-10-31-live-rotation/compact-final-records.lisp"
   :BYTES 2895 :DEVICE 16777232 :INODE 1563762530 :MTIME 1793455796 :SHA256
   "68a212d4560346c729f6767fb8141e705f6924c22a345b455e4704266ee8febe")
  (:PATH "spikes/results/2026-10-31-live-rotation/compact-small-records.lisp"
   :BYTES 2900 :DEVICE 16777232 :INODE 1563762531 :MTIME 1793455796 :SHA256
   "ade3efc7029f6b98713a926bc435f41b751903cabacea3228871b474f2364adb")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/core-2.6.9/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563762533 :MTIME 1793455796 :SHA256
   "b7fe59ae2090f2284850b7fec90117793fc35be80ad2ae2e02422833c9476741")
  (:PATH "spikes/results/2026-10-31-live-rotation/core-2.6.9/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563762534 :MTIME 1793455796 :SHA256
   "f33672d5dc751c0baf0f567a2d05ab34cc47af8d2d275448959b1e8f9b9b47f5")
  (:PATH "spikes/results/2026-10-31-live-rotation/core-2.6.9/report.lisp.gz"
   :BYTES 101949 :DEVICE 16777232 :INODE 1563762535 :MTIME 1793455796 :SHA256
   "29bb7e1074ef72499cb71c09e2a6996df057ba298ad3cef0ef42ca3c8818cd58")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/corruption-2.6.9/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563762537 :MTIME 1793455796 :SHA256
   "4102a23f677a01fa50d820a79be5afbc573127212089bdc0c4e575fd55eba42a")
  (:PATH "spikes/results/2026-10-31-live-rotation/corruption-2.6.9/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563762538 :MTIME 1793455796 :SHA256
   "c44837b6357c860dec01d0d55cd74391fe1a0a2ca1fbbc603f436452a9fd011c")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/corruption-2.6.9/report.lisp.gz"
   :BYTES 101867 :DEVICE 16777232 :INODE 1563762539 :MTIME 1793455796 :SHA256
   "b394258f619a1954d510c8b7f4991ff8a19a7027e04549be7c14500eedc44419")
  (:PATH "spikes/results/2026-10-31-live-rotation/corruption.lisp" :BYTES 281
   :DEVICE 16777232 :INODE 1563762540 :MTIME 1793455796 :SHA256
   "b3fc2d3cff860915a4c1311aa23d90786c947ce1c96e55eda270aaebb2277dad")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/doc-link-attempt/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563762542 :MTIME 1793455796 :SHA256
   "a01bab578f83b8c851d3ed13f2a0a788b8cec92ebbb9cea8426cf6a3d4c5a549")
  (:PATH "spikes/results/2026-10-31-live-rotation/doc-link-attempt/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563762543 :MTIME 1793455796 :SHA256
   "9ff2d9c3cd2c8beabfc59ee608b937fae01ba0d6a0dabb2fc304da917cc161ce")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/doc-link-attempt/report.lisp.gz"
   :BYTES 102219 :DEVICE 16777232 :INODE 1563762544 :MTIME 1793455796 :SHA256
   "771027b69c814cefec8c7568b7f1c27207afcc5903b6cb8f4bc11b60e33a9659")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/final-doc-checks/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563762546 :MTIME 1793455796 :SHA256
   "242a8bdb382e5248996006cd47a114a755498ac59bfa5800ecf5d5c67838843c")
  (:PATH "spikes/results/2026-10-31-live-rotation/final-doc-checks/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563762547 :MTIME 1793455796 :SHA256
   "8cc711b67803dc0e2eff793da854c1744e150d9eebf95491fe40c2ae0e0add78")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/final-doc-checks/report.lisp.gz"
   :BYTES 102124 :DEVICE 16777232 :INODE 1563762548 :MTIME 1793455796 :SHA256
   "be17be09919112b8bd0cb5c8fa812aedb8b105db522cf471f7c33862e15c4663")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/fixture-diagnostics/1U6Y4Y1-PCQ-0/001-v1-server-90.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1563762551 :MTIME 1793455796 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/fixture-diagnostics/1U6Y4Y1-PCQ-0/001-v1-server-90.stdout"
   :BYTES 47 :DEVICE 16777232 :INODE 1563762552 :MTIME 1793455796 :SHA256
   "9c5f04ef2668487808bf32d3d2fdec6c7f11af87f2d931bdea1db64c1fdbaf95")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/full-2.6.9/conservazione.lisp"
   :BYTES 1776 :DEVICE 16777232 :INODE 1563762554 :MTIME 1793455796 :SHA256
   "193167a2cf6e731feb4eb6e543747ecf26099aa3742d757a065ad3141bc67dac")
  (:PATH "spikes/results/2026-10-31-live-rotation/full-2.6.9/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563762555 :MTIME 1793455796 :SHA256
   "b17540e729a08f74ee5872c1600c6c8d61b7ee794a8c73b61f7c690a4f923f10")
  (:PATH "spikes/results/2026-10-31-live-rotation/full-2.6.9/report.lisp.gz"
   :BYTES 337648 :DEVICE 16777232 :INODE 1563762556 :MTIME 1793455796 :SHA256
   "36682756682168737e3794622a4156091324e7b16748fb0973e78b634a36ee3c")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/post-qualification-code-identity.lisp"
   :BYTES 242 :DEVICE 16777232 :INODE 1563762557 :MTIME 1793455796 :SHA256
   "9d1216f3a8482313faa61f979e3d462dcddfe2f8f305ddfc6345e7b6e3ece61f")
  (:PATH "spikes/results/2026-10-31-live-rotation/qualified-documentation.lisp"
   :BYTES 1226 :DEVICE 16777232 :INODE 1563762558 :MTIME 1793455796 :SHA256
   "c3e65e18704a2499ad1215d5b69ad9ff0f83d6b9ec8ea2a265efcae5bcf6ba7c")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/qualified-documentation/CHANGELOG.md.txt"
   :BYTES 46273 :DEVICE 16777232 :INODE 1563762560 :MTIME 1793455796 :SHA256
   "6bccde63392c26cbb60027e2894b2da8bc372486606dd115e2a0333e3d3a7220")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/qualified-documentation/docs/adr/0075-rotazione-live-m1.md.txt"
   :BYTES 3277 :DEVICE 16777232 :INODE 1563762563 :MTIME 1793455796 :SHA256
   "e21d33d63294e8e5c2ad1375e92c6dfaff640722b45aa848544dcf54332abf0a")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/qualified-documentation/docs/adr/README.md.txt"
   :BYTES 15639 :DEVICE 16777232 :INODE 1563762564 :MTIME 1793455796 :SHA256
   "e1dc8b2e7fffdb0a7f1438e32a8fbdc1756e48f52582d3c2df44baf1590f321a")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/qualified-documentation/docs/implementazione/README.md.txt"
   :BYTES 3178 :DEVICE 16777232 :INODE 1563762566 :MTIME 1793455796 :SHA256
   "4b49e44ea0008ec965767d9ac601400751b4831bf8e918566bddd7a4a3fb6085")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/qualified-documentation/docs/implementazione/production-engine-bootstrap.md.txt"
   :BYTES 8929 :DEVICE 16777232 :INODE 1563762567 :MTIME 1793455796 :SHA256
   "a974833f02edf661baeb4424daac099eadb30b781fe085393d9fc9c9e72627d0")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/qualified-documentation/docs/tracciabilita/matrice.md.txt"
   :BYTES 66044 :DEVICE 16777232 :INODE 1563762569 :MTIME 1793455796 :SHA256
   "3cc7ad9cee512710959ea705b54d44780c49204e8734f4416e9f3a77d8f0eff3")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/qualified-documentation/docs/tracciabilita/requisiti.lisp.txt"
   :BYTES 50511 :DEVICE 16777232 :INODE 1563762570 :MTIME 1793455796 :SHA256
   "62f15f714235a23185d523a3b3da1c16f0107eb1ac0bae7a6c7fa812d10970b8")
  (:PATH "spikes/results/2026-10-31-live-rotation/report.md" :BYTES 3515
   :DEVICE 16777232 :INODE 1563762571 :MTIME 1793455796 :SHA256
   "8832343b41992dcd60671002eb8ef8d327c84b1aaece1f8b05c7bae8b9a48ff1")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/strict-2.6.10/conservazione.lisp"
   :BYTES 1776 :DEVICE 16777232 :INODE 1563762573 :MTIME 1793455796 :SHA256
   "f2b33868b527e8c1b12a57b115b368a87279f1af9f7d3fb27e31d4c76bc08396")
  (:PATH "spikes/results/2026-10-31-live-rotation/strict-2.6.10/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563762574 :MTIME 1793455796 :SHA256
   "b968ddb42b4509a94e41ead432b18cca8abc5b4aa491ea0dc7dbd933c786dcba")
  (:PATH "spikes/results/2026-10-31-live-rotation/strict-2.6.10/report.lisp.gz"
   :BYTES 320637 :DEVICE 16777232 :INODE 1563762575 :MTIME 1793455796 :SHA256
   "f0be4cc5277ee7a20e8702899140cebd7ca2fec40417d2693843ddc8c6aa9fcf")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/ci-command/conservazione.lisp"
   :BYTES 1183 :DEVICE 16777232 :INODE 1563762579 :MTIME 1793455796 :SHA256
   "492bba742b078ec8b1c5bfba9b1e126dfe1ec70f029b748a7ff3c2004a6091d6")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/ci-command/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563762580 :MTIME 1793455796 :SHA256
   "6e76e434316cba3841d0290d90182d74345ad101f8b0463733a0a5cc288c343e")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/ci-command/report.lisp.gz"
   :BYTES 102240 :DEVICE 16777232 :INODE 1563762581 :MTIME 1793455796 :SHA256
   "d48d6dda9b8e0ba7f15c45d9ae42858c899bba88ae3fa9f2a500330e4f98c00e")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/ci-self-test/boundaries.lisp"
   :BYTES 976 :DEVICE 16777232 :INODE 1563762583 :MTIME 1793455796 :SHA256
   "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/ci-self-test/conditions.lisp"
   :BYTES 663 :DEVICE 16777232 :INODE 1563762584 :MTIME 1793455796 :SHA256
   "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/ci-self-test/data.lisp"
   :BYTES 3214 :DEVICE 16777232 :INODE 1563762585 :MTIME 1793455796 :SHA256
   "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/ci-self-test/measure.lisp"
   :BYTES 2041 :DEVICE 16777232 :INODE 1563762586 :MTIME 1793455796 :SHA256
   "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/ci-self-test/publication.lisp"
   :BYTES 1181 :DEVICE 16777232 :INODE 1563762587 :MTIME 1793455796 :SHA256
   "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/ci-self-test/report.lisp"
   :BYTES 632 :DEVICE 16777232 :INODE 1563762588 :MTIME 1793455796 :SHA256
   "3bf53e3748c34568e0fb83b9f6f7ed394be5c711a74ca8b7bdde88a45f49bc23")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/ci-self-test/tests.lisp"
   :BYTES 2409 :DEVICE 16777232 :INODE 1563762589 :MTIME 1793455796 :SHA256
   "49acae481faadf756a5650f1c389386f54afc7b6e86fca34b8cb0d65726f76e4")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/ci-self-test/workflow.lisp"
   :BYTES 27784 :DEVICE 16777232 :INODE 1563762590 :MTIME 1793455796 :SHA256
   "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/reader-self-test/completion-exit/isolated-build.lisp"
   :BYTES 197 :DEVICE 16777232 :INODE 1563762593 :MTIME 1793455796 :SHA256
   "1a45dcf8a6d03f1e8866e49280c6f0edb894320c90624d5620fad1e3d546cea9")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/reader-self-test/completion-exit/stderr.log"
   :BYTES 0 :DEVICE 16777232 :INODE 1563762594 :MTIME 1793455796 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/reader-self-test/completion-exit/stdout.log"
   :BYTES 105 :DEVICE 16777232 :INODE 1563762595 :MTIME 1793455796 :SHA256
   "5e630c1b44d68ce71b27d151e76bf367e3cbd941200adc36cdd30e0fe7390531")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/reader-self-test/report.lisp"
   :BYTES 2003 :DEVICE 16777232 :INODE 1563762596 :MTIME 1793455796 :SHA256
   "ac9dcb0c84ce79dde88aebd614620c15176678452ba24361d1236ea21952e1ef")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/reader-self-test/signal/isolated-build.lisp"
   :BYTES 247 :DEVICE 16777232 :INODE 1563762598 :MTIME 1793455796 :SHA256
   "ff5cf55dda241d32ea1b4308172c7dc526436cbf1d546e7471148cee95a873d1")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/reader-self-test/signal/stderr.log"
   :BYTES 0 :DEVICE 16777232 :INODE 1563762599 :MTIME 1793455796 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/reader-self-test/signal/stdout.log"
   :BYTES 126 :DEVICE 16777232 :INODE 1563762600 :MTIME 1793455796 :SHA256
   "3697c68fa71f124c8d05d8cc5d649a744586a10989eb2e67c5bdce6bfc760142")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/snapshot-self-test/completion-exit/isolated-build.lisp"
   :BYTES 199 :DEVICE 16777232 :INODE 1563762603 :MTIME 1793455796 :SHA256
   "b8bb4416a818775bae5c77341eeec2c356a2733f633ac2bc8b6ac3ff955d05e0")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/snapshot-self-test/completion-exit/stderr.log"
   :BYTES 0 :DEVICE 16777232 :INODE 1563762605 :MTIME 1793455796 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/snapshot-self-test/completion-exit/stdout.log"
   :BYTES 107 :DEVICE 16777232 :INODE 1563762606 :MTIME 1793455796 :SHA256
   "4f22544421d9012fe132a36bf15950cd327ca959b8f9c5ef3d386e0c8b62a25c")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/snapshot-self-test/report.lisp"
   :BYTES 2021 :DEVICE 16777232 :INODE 1563762607 :MTIME 1793455796 :SHA256
   "2e5d9ad238b36e84aa1b109846fc5a50d7c7e09fd4acb8c50116f066b7167964")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/snapshot-self-test/signal/isolated-build.lisp"
   :BYTES 249 :DEVICE 16777232 :INODE 1563762609 :MTIME 1793455796 :SHA256
   "a345276e3dfe377c0bbd359793165915b1527938a65250d367ce5ac079feecc1")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/snapshot-self-test/signal/stderr.log"
   :BYTES 0 :DEVICE 16777232 :INODE 1563762610 :MTIME 1793455796 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/snapshot-self-test/signal/stdout.log"
   :BYTES 128 :DEVICE 16777232 :INODE 1563762611 :MTIME 1793455796 :SHA256
   "e3502e714a0530acb1f0130c4ced4a016607bcb067e3686f6f29704db8423ea5")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-01.lisp"
   :BYTES 27228 :DEVICE 16777232 :INODE 1563762613 :MTIME 1793455796 :SHA256
   "5ec660f165bb0e925194ed7adf03ad05ad9241fdd3aa3bcb6d7fdfefccdcc25c")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-02.lisp"
   :BYTES 1607 :DEVICE 16777232 :INODE 1563762614 :MTIME 1793455796 :SHA256
   "bc157221f5912f56a2461d67551eb63190cf50e6c31ae7269f216f22fdced26c")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-03.lisp"
   :BYTES 3664 :DEVICE 16777232 :INODE 1563762615 :MTIME 1793455796 :SHA256
   "4445f11acf23d2af41d7c67fac8f851ea3ff4ee84d6b73c89222cefce2e99e24")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-04.lisp"
   :BYTES 6752 :DEVICE 16777232 :INODE 1563762616 :MTIME 1793455796 :SHA256
   "6d8b654a68ded4acf58dec266c274a902d2fbe9b02e5fa034bda6ea79f8ac62b")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-05.lisp"
   :BYTES 10168 :DEVICE 16777232 :INODE 1563762617 :MTIME 1793455796 :SHA256
   "ce1173ca59c23ea63f652ee67079ef18042d3039dbd7c6e227fdf7bfcbd75aad")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-06.lisp"
   :BYTES 24088 :DEVICE 16777232 :INODE 1563762618 :MTIME 1793455796 :SHA256
   "4285b474d39b91149893ae7f7cf281b8d53ec2987bc1209960b46eb60e7791d6")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-07.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1563762619 :MTIME 1793455796 :SHA256
   "a1e97cc1652e99e2b07e72e690215564c84fc1e6706102ce848600cfad483dd8")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-07.lisp.gz"
   :BYTES 411739 :DEVICE 16777232 :INODE 1563762620 :MTIME 1793455796 :SHA256
   "c482276e24c6ed86db6e459a79eb42f3b5bd8a64cbf75f03a7ff1af50e7263c6")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-08.lisp"
   :BYTES 315 :DEVICE 16777232 :INODE 1563762621 :MTIME 1793455796 :SHA256
   "26c932348e6934eda80b141d125d604dd7fd5f942164d512d0b9525eb6ceb48d")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-08.lisp.gz"
   :BYTES 45452 :DEVICE 16777232 :INODE 1563762622 :MTIME 1793455796 :SHA256
   "09a94a7fd6efb80dff8414ff11469350cc8d5b6298c00ba9835f8c9720b0dbb6")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-09.lisp"
   :BYTES 2472 :DEVICE 16777232 :INODE 1563762623 :MTIME 1793455796 :SHA256
   "c6163348c9faf554c2b5ec52cb367bf506159b19fb1283ecb38549d1e3d6b0e4")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-10.lisp"
   :BYTES 22977 :DEVICE 16777232 :INODE 1563762624 :MTIME 1793455796 :SHA256
   "a0e32a6cb291895c1838c7a474f0fecbed30d3325f70e49bc3f3234834b439ce")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-11.lisp"
   :BYTES 313 :DEVICE 16777232 :INODE 1563762625 :MTIME 1793455796 :SHA256
   "166924fa49b14dbc3aa150838cae9353f30a9a0d1b73a166ff0b557d34bd31f5")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/SPK-11.lisp.gz"
   :BYTES 7995 :DEVICE 16777232 :INODE 1563762626 :MTIME 1793455796 :SHA256
   "1dfbc8b2ea684eaaed69be1b919fa9c667426fcdd5601da8f56a2bf06dd7657d")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/conservazione.lisp"
   :BYTES 2352 :DEVICE 16777232 :INODE 1563762627 :MTIME 1793455796 :SHA256
   "3196631c1814fcd02c64115ea24a7769cf21e1b56bb5b6bb0373eacf7292b974")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/report.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1563762628 :MTIME 1793455796 :SHA256
   "6c989d6b898e172faf2f06f8062882f9ae7e826a52fc94293fa8f33cb2ec8e4d")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/supporting/spikes/report.lisp.gz"
   :BYTES 484020 :DEVICE 16777232 :INODE 1563762629 :MTIME 1793455796 :SHA256
   "403c4b0bb075322f5b5662588ad4dcbe0b9164503a18f1351fd660c4ae9f3194")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/targeted-eight-2.6.9/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563762631 :MTIME 1793455796 :SHA256
   "56fde96baa56bb406f7a6f1d7338e953eaf4854cfb4ecbd45eeaf456699edef6")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/targeted-eight-2.6.9/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563762632 :MTIME 1793455796 :SHA256
   "3896e75e57e409e3fdb11223a05bcdd8d1fd43661a22e04f2e74f49caf84f09c")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/targeted-eight-2.6.9/report.lisp.gz"
   :BYTES 103309 :DEVICE 16777232 :INODE 1563762633 :MTIME 1793455796 :SHA256
   "9619ecf418a32cea7a01dea2d45cf46990e710e2729a1c5df61223cf66626f5a")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/targeted-six-2.6.9/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563762635 :MTIME 1793455796 :SHA256
   "3af08758f7ff292ff665242fe77ac5732bb26811f03b7ef5de215e328cc10d8b")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/targeted-six-2.6.9/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563762636 :MTIME 1793455796 :SHA256
   "02e725ea66b078b91da2a7fce656bb7c3e338115d1742830b2e68b3c8f397eff")
  (:PATH
   "spikes/results/2026-10-31-live-rotation/targeted-six-2.6.9/report.lisp.gz"
   :BYTES 103256 :DEVICE 16777232 :INODE 1563762637 :MTIME 1793455796 :SHA256
   "b0351ec33786d33ed20a1ec27174f1cd5762c61341674636bb48ac5ad786de26")
  (:PATH "spikes/results/2026-10-31-live-rotation/targeted.lisp" :BYTES 490
   :DEVICE 16777232 :INODE 1563762638 :MTIME 1793455796 :SHA256
   "88a1886ec7a312f4a7bdf1d6da072cac6ca50d2ebc0e1fc478902e11d66a3fcc")
  (:PATH "spikes/results/2026-10-31-local-index-bench/archive-validation.lisp"
   :BYTES 293 :DEVICE 16777232 :INODE 1563356057 :MTIME 1793446790 :SHA256
   "24d55c58399f9301d1355b328009342aca061e7c50300011c73aefc2f02d501c")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/attempt-format-driver-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356059 :MTIME 1793446790 :SHA256
   "05d63ca6ac946fe2995445b72fa7e9f21e855aa8a25233d92e851e5d1ef24af9")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/attempt-format-driver-command/report.lisp"
   :BYTES 314724 :DEVICE 16777232 :INODE 1563356060 :MTIME 1793446790 :SHA256
   "8aab996cc064e60c7b4d01a9514be4a1a1b97c4fc2163d1ffc22b0547c9eccc4")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/attempt-format-driver/result.lisp"
   :BYTES 382 :DEVICE 16777232 :INODE 1563356062 :MTIME 1793446790 :SHA256
   "fd701614bf5396879e80ae83e031faf1aba24e3d4968fe5393aed334b0e6f507")
  (:PATH "spikes/results/2026-10-31-local-index-bench/bench.lisp" :BYTES 12293
   :DEVICE 16777232 :INODE 1563356063 :MTIME 1793446790 :SHA256
   "3324099ebccc6a7a7e7ded910d660f7b645119c6455da1312aa0314efb72e82b")
  (:PATH "spikes/results/2026-10-31-local-index-bench/cleanup.lisp" :BYTES 239
   :DEVICE 16777232 :INODE 1563356064 :MTIME 1793446790 :SHA256
   "5c3331f76ce2b4cb490ccf9f77c33e7b67fae439f148a4ffa53e0e7b6be4cd31")
  (:PATH "spikes/results/2026-10-31-local-index-bench/compaction.lisp" :BYTES
   1683 :DEVICE 16777232 :INODE 1563356065 :MTIME 1793446790 :SHA256
   "96cf78f76786793ff8774b701f74e2911211809b12be8d09c88584efdd712209")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/comparison-2.6.9/metrics.csv"
   :BYTES 21390 :DEVICE 16777232 :INODE 1563356067 :MTIME 1793446790 :SHA256
   "4abd2159620e2f485a829d878316ace6552f0e0dc74ed4f43a7022015d44aa8d")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/comparison-2.6.9/resources.csv"
   :BYTES 6009 :DEVICE 16777232 :INODE 1563356068 :MTIME 1793446790 :SHA256
   "cd80f7f61f27fd1210e7a9cbab6f762d997fc901ebf67d3abcbe1bee9c92cff2")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/comparison-2.6.9/startup.csv"
   :BYTES 2124 :DEVICE 16777232 :INODE 1563356069 :MTIME 1793446790 :SHA256
   "fda5c1f5cb54a12e742c43390470a12b6e7398b8996af6a0f09ec6a856d7b794")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/comparison-2.6.9/summary.lisp"
   :BYTES 67401 :DEVICE 16777232 :INODE 1563356070 :MTIME 1793446790 :SHA256
   "4a609d1e082ff8bd127637904e94304044f0fd77ce3bf94ebe0e760c80ba8bdb")
  (:PATH "spikes/results/2026-10-31-local-index-bench/component-inventory.lisp"
   :BYTES 541 :DEVICE 16777232 :INODE 1563356071 :MTIME 1793446790 :SHA256
   "a73e08d816cb692fdd200fb63583e82cb39c72c2dfca363d47d46342437800c7")
  (:PATH "spikes/results/2026-10-31-local-index-bench/component-method.md"
   :BYTES 1337 :DEVICE 16777232 :INODE 1563356072 :MTIME 1793446790 :SHA256
   "4f04a16088537fd0e46ff49d9a67fd50a503f32237a972ba6380b0523e0a2f85")
  (:PATH "spikes/results/2026-10-31-local-index-bench/component-metrics.csv"
   :BYTES 24765 :DEVICE 16777232 :INODE 1563356073 :MTIME 1793446790 :SHA256
   "ca7ddbe8ce63c49df6404efb31e54f2ea9e0b3a10cc1ab229018a4ad92380df0")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-performance-2.6.9-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356075 :MTIME 1793446790 :SHA256
   "27c5a9b180ee67473c641f1e08d755b1b4d08a6305848dc18bb39103fadece12")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-performance-2.6.9-command/report.lisp"
   :BYTES 311440 :DEVICE 16777232 :INODE 1563356076 :MTIME 1793446790 :SHA256
   "382fade8d1d61cf2946bf806764d4da2f86c138f7856522325d400798171c956")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-performance-2.6.9-run/report.lisp"
   :BYTES 272807 :DEVICE 16777232 :INODE 1563356078 :MTIME 1793446790 :SHA256
   "167fbbf56ef99a350ccfe26de320aef1d4aaf3de78d59d820416782dea79f4cb")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-performance-2.6.9-run/self-test-metrics.lisp"
   :BYTES 50868 :DEVICE 16777232 :INODE 1563356079 :MTIME 1793446790 :SHA256
   "a253b14e8a8fdabdac2ad25be2487db77eda107e6cc7f82d600ef0b987111018")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-performance-2.6.9-run/self-test-sensor.lisp"
   :BYTES 347 :DEVICE 16777232 :INODE 1563356080 :MTIME 1793446790 :SHA256
   "0e2a0c705421db3263a7461fecba3aec332c4c0d689b52874b1e669114efd4b3")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-performance-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356082 :MTIME 1793446790 :SHA256
   "6933565fd74ae805810e59f3a1e1c5dc47ae4e4659207c3900cbac632e396902")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-performance-command/report.lisp"
   :BYTES 311491 :DEVICE 16777232 :INODE 1563356083 :MTIME 1793446790 :SHA256
   "3aa814e0a780f7ba5f04a331e1cd5ab63e5a20d1154b95b2d634285f42c5b5ba")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-performance-run/report.lisp"
   :BYTES 272744 :DEVICE 16777232 :INODE 1563356085 :MTIME 1793446790 :SHA256
   "9729735123a63e68319d725d5304f5cab9a824e3c89907c224d3a0c4ccc0b193")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-performance-run/self-test-metrics.lisp"
   :BYTES 50845 :DEVICE 16777232 :INODE 1563356086 :MTIME 1793446790 :SHA256
   "610dbe3088c29526ea2c7f41f7efa268641ffb2f98c96a7ff9ac913da1442b4b")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-performance-run/self-test-sensor.lisp"
   :BYTES 347 :DEVICE 16777232 :INODE 1563356087 :MTIME 1793446790 :SHA256
   "ba4c783ccd5555a2fb826431e4dcc2ee187f23769a20e1464d4b8493402530e3")
  (:PATH "spikes/results/2026-10-31-local-index-bench/component-summary.lisp"
   :BYTES 3333 :DEVICE 16777232 :INODE 1563356088 :MTIME 1793446790 :SHA256
   "e7fb4c6e54ff088937e991816c3ecfca9406dfb69f7456523982d2d0c651c1f1")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-throughput-2.6.9-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356090 :MTIME 1793446790 :SHA256
   "7b0ac9c76effcb69f48f79b0c2cbb22d2c8dc4afbbfc00dd5b0f41df52dd6f4b")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-throughput-2.6.9-command/report.lisp"
   :BYTES 311354 :DEVICE 16777232 :INODE 1563356091 :MTIME 1793446790 :SHA256
   "fac6e31e079453351cd073aac61e853c36570236d883ea1dd63768246268fd56")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-throughput-2.6.9-run/report.lisp"
   :BYTES 133970 :DEVICE 16777232 :INODE 1563356093 :MTIME 1793446790 :SHA256
   "28f8060e3686ff69e5d21c30483693ae3e7bc17783ccbbc880f21ae08d292beb")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-throughput-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356095 :MTIME 1793446790 :SHA256
   "517ac1e9a77701259bb71c4a47570f8d96c9fb15f89e1a6b1b466d3b2b4b936a")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-throughput-command/report.lisp"
   :BYTES 311393 :DEVICE 16777232 :INODE 1563356096 :MTIME 1793446790 :SHA256
   "bb35a805a5ef82c6db8e4e9fbd27d8065b31ee1dce8abfbb215b4cd4142d5103")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/component-throughput-run/report.lisp"
   :BYTES 134040 :DEVICE 16777232 :INODE 1563356098 :MTIME 1793446790 :SHA256
   "9a8f515960b4d4f46497e21a733e4bfc6ecd7b46c9e33faf36f82d68b6ae654a")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/driver-initial-syntax-failure.log.gz"
   :BYTES 974 :DEVICE 16777232 :INODE 1563356099 :MTIME 1793446790 :SHA256
   "25a8701ddffd70e4f583c40a09474e4ffad029f39e98b523b1c32fc56616a021")
  (:PATH "spikes/results/2026-10-31-local-index-bench/driver-manifest.json"
   :BYTES 1130 :DEVICE 16777232 :INODE 1563356100 :MTIME 1793446790 :SHA256
   "ac8cdf5bd11049d215c33ed8ea7432f50d256af0ac11b4dd335eb068a2c09593")
  (:PATH "spikes/results/2026-10-31-local-index-bench/extra-summary.lisp"
   :BYTES 1727 :DEVICE 16777232 :INODE 1563356101 :MTIME 1793446790 :SHA256
   "6b76b4aabcd660a8ac7432040af0541d041288ad2cb5a8ee4d88e58b885a2176")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/focused-2.6.9-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356103 :MTIME 1793446790 :SHA256
   "09dc124b37c15f3b9185c437bfb39fc6da78e6240ac1d0fee1b5faeaeda9e076")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/focused-2.6.9-command/report.lisp"
   :BYTES 321018 :DEVICE 16777232 :INODE 1563356104 :MTIME 1793446790 :SHA256
   "41eaf67269de2da68ef96c5fc0fb8bd949e1c2e85582f33bd5b66f37d2d0368e")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/focused-2.6.9-run/result.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563356106 :MTIME 1793446790 :SHA256
   "d102d50ac84e1525b0c367512a20e72df614ef2f23180893ee10a4ce126cf76a")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/focused-2.6.9-run/result.lisp.gz"
   :BYTES 686237 :DEVICE 16777232 :INODE 1563356107 :MTIME 1793446790 :SHA256
   "6bd23588fb46d68b4200c7679537628976586fdcf632e543ba7bf24fa776d949")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/focused-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356109 :MTIME 1793446790 :SHA256
   "7778154b87b7b2338db7978c99ae949b54d4658308f06df235c1cb6196a2dbb4")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/focused-command/report.lisp"
   :BYTES 321050 :DEVICE 16777232 :INODE 1563356110 :MTIME 1793446790 :SHA256
   "25f7adda650d05c19d1fd6704e268cce700bcfea4fa7ef5cf889431e09c39679")
  (:PATH "spikes/results/2026-10-31-local-index-bench/focused-run/result.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563356112 :MTIME 1793446790 :SHA256
   "6fd56c55224da6560a0dbc4120bb4cdeef028e663161df094d39dccb4c64e01b")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/focused-run/result.lisp.gz"
   :BYTES 714390 :DEVICE 16777232 :INODE 1563356113 :MTIME 1793446790 :SHA256
   "11dc15bacb78fae47ebce789c5fcb866593d00ef500d5b896a3f5a4cc58bae15")
  (:PATH "spikes/results/2026-10-31-local-index-bench/method.md" :BYTES 3238
   :DEVICE 16777232 :INODE 1563356114 :MTIME 1793446790 :SHA256
   "a69e98465ac0f1914e63de8339b493831810971ac95dd29e75f2a4b9517e4a23")
  (:PATH "spikes/results/2026-10-31-local-index-bench/metrics.csv" :BYTES 21403
   :DEVICE 16777232 :INODE 1563356115 :MTIME 1793446790 :SHA256
   "ad51a8a47cdd73a0e8875d6392aa943e34ec85a9b3ce3b270e31d80b63688999")
  (:PATH "spikes/results/2026-10-31-local-index-bench/report.md" :BYTES 10980
   :DEVICE 16777232 :INODE 1563356116 :MTIME 1793446790 :SHA256
   "19312eb3acc774a2d6ad272148745f0042c9ab5f688fbb51f4c271aeda7d2b6a")
  (:PATH "spikes/results/2026-10-31-local-index-bench/resources.csv" :BYTES
   6050 :DEVICE 16777232 :INODE 1563356117 :MTIME 1793446790 :SHA256
   "df3e114e48463e5aab896d66dfbe95eb77c7025730e3367c7891512d99f67433")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/self-test-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356119 :MTIME 1793446790 :SHA256
   "55590e75b49e48c97e2f19f4f73528a01998a2423154e39684ee8b4e072ac994")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/self-test-command/report.lisp"
   :BYTES 312202 :DEVICE 16777232 :INODE 1563356120 :MTIME 1793446790 :SHA256
   "e9814d29874d3b6c8315698f364dc21dc915182bf0f78efa53e4357ad78b7ac3")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/self-test-final-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356122 :MTIME 1793446790 :SHA256
   "fbd495d0d04ae95947c5f633090304edf26e595e64ed4a5c91dc3b7f3d363802")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/self-test-final-command/report.lisp"
   :BYTES 313011 :DEVICE 16777232 :INODE 1563356123 :MTIME 1793446790 :SHA256
   "fabfa252646a6ab5252c572e1d0719c7f08da448d72a0b0e475560fabaaca851")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/self-test-final/result.lisp"
   :BYTES 34530 :DEVICE 16777232 :INODE 1563356125 :MTIME 1793446790 :SHA256
   "49a17eba40c72664ce42afb301ffce0a7ef75469b0c130e224bec0c4a109c92e")
  (:PATH "spikes/results/2026-10-31-local-index-bench/self-test/result.lisp"
   :BYTES 17409 :DEVICE 16777232 :INODE 1563356127 :MTIME 1793446790 :SHA256
   "4222b4f85a968f32b7d682e96b134314da301eb14145b0c735ea501bf5e7b4d1")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356129 :MTIME 1793446790 :SHA256
   "a8ff9c8702cba9283162b1e71bdf6a39a36ad4dc58ea7663a0b9acbcdbb35b86")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-command/report.lisp"
   :BYTES 311549 :DEVICE 16777232 :INODE 1563356130 :MTIME 1793446790 :SHA256
   "f15f902087b550f13d5a21a71f64d610047cfdf8c7917bb8600f903065953b02")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-01.lisp"
   :BYTES 35633 :DEVICE 16777232 :INODE 1563356132 :MTIME 1793446790 :SHA256
   "80034e0186032046dc1f17e41ca24d20e3971ae862aa7fb13e04d60a5446ab59")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-02.lisp"
   :BYTES 325022 :DEVICE 16777232 :INODE 1563356133 :MTIME 1793446790 :SHA256
   "55cae51bef20619b599374fffa3d6a5287ff6049b4b447d79a802520293c7946")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-03.lisp"
   :BYTES 56289 :DEVICE 16777232 :INODE 1563356134 :MTIME 1793446790 :SHA256
   "d143ebc14344357be1ea5f254fc13df0ff04f28807300de06064f263e4e6fbab")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-04.lisp"
   :BYTES 227238 :DEVICE 16777232 :INODE 1563356135 :MTIME 1793446790 :SHA256
   "b1542b87bdda6ba46ecaace3262f3d403fbe60324dbcce671e7746a4ef29dd18")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-05.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563356136 :MTIME 1793446790 :SHA256
   "2bc729a4ce553a4ea385319310eaa1fc48f1fc4f03f377fc36601e183c34cdb0")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-05.lisp.gz"
   :BYTES 159721 :DEVICE 16777232 :INODE 1563356137 :MTIME 1793446790 :SHA256
   "4f41a43b0a98e8f77bba2a2756ff0a4f53ce6407f9a010a880826039afea89b4")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-06.lisp"
   :BYTES 319 :DEVICE 16777232 :INODE 1563356138 :MTIME 1793446790 :SHA256
   "56e884df15795ef54e96667ed7d0029e1c6b6459901e96d152acf4ab266dbbe6")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-06.lisp.gz"
   :BYTES 5081318 :DEVICE 16777232 :INODE 1563356139 :MTIME 1793446791 :SHA256
   "92ce3d3d8ab4b7a2775bb17edb4fb704f580e6ae0324da87ee671a9cf90bd48e")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-07.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1563356140 :MTIME 1793446791 :SHA256
   "804960558b489577810cc90578508dd415fd3e3a359e4acf980beb6a281da475")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-07.lisp.gz"
   :BYTES 411762 :DEVICE 16777232 :INODE 1563356141 :MTIME 1793446791 :SHA256
   "25cb6bff0866e59c81ffe1dcf60491b85f9906f0946efcaa83e571cb55dd61c2")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-08.lisp"
   :BYTES 226461 :DEVICE 16777232 :INODE 1563356142 :MTIME 1793446791 :SHA256
   "bf5a3473326d74ca297fd1a4f8154ab9df39b0b147b0f6c94ad50b3512288992")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-09.lisp"
   :BYTES 49851 :DEVICE 16777232 :INODE 1563356143 :MTIME 1793446791 :SHA256
   "3d9eb22eac1d3088da015d4ea59f8dfff1da1d59280c296bb6d47f6b15c7c900")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-10.lisp"
   :BYTES 36629 :DEVICE 16777232 :INODE 1563356144 :MTIME 1793446791 :SHA256
   "358b25f3d1cddd064d82b51f24ad38c726eb9d462ce00ff178e1def0c49dd336")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/SPK-11.lisp"
   :BYTES 6765 :DEVICE 16777232 :INODE 1563356145 :MTIME 1793446791 :SHA256
   "db7f683ebdf5e7b432ab5a9f442a4473fc771847eadedffedeb15287665e5579")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/conservazione.lisp"
   :BYTES 3516 :DEVICE 16777232 :INODE 1563356146 :MTIME 1793446791 :SHA256
   "8ae165f52e58540acfa654cf9ff7afe637ece49999727ee4aa4e09c7f676f51f")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/report.lisp"
   :BYTES 319 :DEVICE 16777232 :INODE 1563356147 :MTIME 1793446791 :SHA256
   "2a5a434b80e920fd17b756d523095ef020faa0fb4bace28901f549d12a554936")
  (:PATH
   "spikes/results/2026-10-31-local-index-bench/standard-runs/report.lisp.gz"
   :BYTES 5760561 :DEVICE 16777232 :INODE 1563356148 :MTIME 1793446791 :SHA256
   "b11381a71f0683f6515ee29d9dc1d4f29b89bbbdb250965e26f941bff6106f95")
  (:PATH "spikes/results/2026-10-31-local-index-bench/startup.csv" :BYTES 2124
   :DEVICE 16777232 :INODE 1563356149 :MTIME 1793446791 :SHA256
   "b26291d299473a594ccf88d98189f5b4d02be395bf0e6505d4e5f7eaaa96ebe5")
  (:PATH "spikes/results/2026-10-31-local-index-bench/summarize.lisp" :BYTES
   4586 :DEVICE 16777232 :INODE 1563356150 :MTIME 1793446791 :SHA256
   "82cdd0166e11ad98200257efe39d33ac1c20d486177d24d365c7b1adb26060db")
  (:PATH "spikes/results/2026-10-31-local-index-bench/summary.lisp" :BYTES
   67393 :DEVICE 16777232 :INODE 1563356151 :MTIME 1793446791 :SHA256
   "04d488d42b24f2665623aa69ce7ec94b65a643e55b9defb3a9951f888cddcfb1")
  (:PATH "spikes/results/2026-10-31-local-index-bench/validate-archive.lisp"
   :BYTES 2915 :DEVICE 16777232 :INODE 1563356152 :MTIME 1793446791 :SHA256
   "a443c2c1e6ba0734a5e7766e0684b05b0711b0dcda7e1b25f3d248eab8808b6c")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/attempt-1-syntax/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563406353 :MTIME 1793448702 :SHA256
   "330a33409421c126fbb317530e0fa84f763416674471762ec8f8194e5e45f0d8")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/attempt-1-syntax/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563406354 :MTIME 1793448702 :SHA256
   "b70fab2048c10896887350309683b152e01196373f9660d14ba7c2408d41dc99")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/attempt-1-syntax/report.lisp.gz"
   :BYTES 103340 :DEVICE 16777232 :INODE 1563406355 :MTIME 1793448702 :SHA256
   "eb2be4eec560f24208a93938ff7030e1b9ce64e6556c983f9245b1c7a89cfbd8")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/attempt-2-initial-quota/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563406357 :MTIME 1793448702 :SHA256
   "b55fa5ddc5ae884f9b44340ccd78c52fa3d1dc81924b6a16a492ee496cd3b166")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/attempt-2-initial-quota/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563406358 :MTIME 1793448702 :SHA256
   "b99533ee619e6549c57d8f695672e2474e46ead197e2ad66784686b9ab964691")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/attempt-2-initial-quota/report.lisp.gz"
   :BYTES 104813 :DEVICE 16777232 :INODE 1563406359 :MTIME 1793448702 :SHA256
   "9f9bc6445b542ad16bf04e33388c2872ec90b1220cf4acc21638c58d6b6a0881")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/attempt-3-path-type/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563406361 :MTIME 1793448702 :SHA256
   "d638484044017ad674fb28183a59d7191a655bbc65beeae5faa466348571cc4f")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/attempt-3-path-type/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563406362 :MTIME 1793448702 :SHA256
   "1e45e43958877532841269bfe151e047d5491839f2b1c087676777c8632fa0f9")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/attempt-3-path-type/report.lisp.gz"
   :BYTES 104838 :DEVICE 16777232 :INODE 1563406363 :MTIME 1793448702 :SHA256
   "2def4a2a60bae26cf9274affb42a7dc82d646c1f6f1d0f7bd1c635d137edb5ad")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/attempt-4-v1-key-bound/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563406365 :MTIME 1793448702 :SHA256
   "34502eb7c0092850a3dc76be22049d8605e8e66945499e211a7852f2bd5d8c96")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/attempt-4-v1-key-bound/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563406366 :MTIME 1793448702 :SHA256
   "0a2460598df0002bdd7091d2e13152658d6fbc233893e32e069b3a22bcd8bf78")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/attempt-4-v1-key-bound/report.lisp.gz"
   :BYTES 104840 :DEVICE 16777232 :INODE 1563406367 :MTIME 1793448702 :SHA256
   "01187e91530efabc46d866829e0e67d91bc5968d68d646e33da787ceaf7c5de5")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/compact-small-records.lisp"
   :BYTES 2351 :DEVICE 16777232 :INODE 1563406368 :MTIME 1793448702 :SHA256
   "8ae8f9e93505b0a90a03bec743f7eff9d9bb2d3705b52f8fc8900b96dfc46dfb")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/fixture-diagnostics/1U6Y39F-8W4-0/001-v1-server-80.stderr"
   :BYTES 75 :DEVICE 16777232 :INODE 1563406371 :MTIME 1793448702 :SHA256
   "2e69fe741d875f6099be6fcfe2a6e02e3045cdd9be94efccd2a82a7224c95057")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/fixture-diagnostics/1U6Y39F-8W4-0/001-v1-server-80.stdout"
   :BYTES 0 :DEVICE 16777232 :INODE 1563406372 :MTIME 1793448702 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/fixture-diagnostics/1U6Y3BJ-93B-0/001-v1-server-80.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1563406374 :MTIME 1793448702 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/fixture-diagnostics/1U6Y3BJ-93B-0/001-v1-server-80.stdout"
   :BYTES 47 :DEVICE 16777232 :INODE 1563406375 :MTIME 1793448702 :SHA256
   "b751c84b34021de6a368d1106f9170704ff7a080ce6040246df8a48fd9e3cb41")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/fixture-diagnostics/1U6Y3CR-9JL-0/001-v1-server-80.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1563406377 :MTIME 1793448702 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/fixture-diagnostics/1U6Y3CR-9JL-0/001-v1-server-80.stdout"
   :BYTES 47 :DEVICE 16777232 :INODE 1563406378 :MTIME 1793448702 :SHA256
   "446d833f65d946ad2b600d3ae5bfa224bb550510219c0df5cba96cecefaa4d7f")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/full-2.6.9/conservazione.lisp"
   :BYTES 1776 :DEVICE 16777232 :INODE 1563406380 :MTIME 1793448702 :SHA256
   "c2554b356eb7d995e077e5dc7de973d4c4aaa403f76046a2b05034c9a6e5e84c")
  (:PATH "spikes/results/2026-10-31-local-index-budget/full-2.6.9/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563406381 :MTIME 1793448702 :SHA256
   "e6064d48df2fbb7a33791111783ed67b2b2cc665a525b015a3b3a25d827b2a83")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/full-2.6.9/report.lisp.gz"
   :BYTES 336477 :DEVICE 16777232 :INODE 1563406382 :MTIME 1793448702 :SHA256
   "c07777baf906fd9f346ebe9550d360d2c4357df506d0a76894d58770ba8aa2fd")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/full-attempt-runtime-path/conservazione.lisp"
   :BYTES 1775 :DEVICE 16777232 :INODE 1563406384 :MTIME 1793448702 :SHA256
   "1eff1f7a9493aff89296801bb320e5da61a33f42341e41e6d4f602fd397c8144")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/full-attempt-runtime-path/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563406385 :MTIME 1793448702 :SHA256
   "01c76d6417e8e17fe882a972bbb742ae5a0086853a5bb178ae51318b217c9791")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/full-attempt-runtime-path/report.lisp.gz"
   :BYTES 327534 :DEVICE 16777232 :INODE 1563406386 :MTIME 1793448702 :SHA256
   "32103f2afa4e0607eebd08b2233df9c8621cb90b474af191ec82eee6def44458")
  (:PATH "spikes/results/2026-10-31-local-index-budget/report.md" :BYTES 3138
   :DEVICE 16777232 :INODE 1563406387 :MTIME 1793448702 :SHA256
   "d1f0dc8b74af12d89f62d2cee0e48016c6960a8240e1b8957c6c7702482ec970")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/runtime-path-diagnostic/report.lisp"
   :BYTES 1018 :DEVICE 16777232 :INODE 1563406389 :MTIME 1793448702 :SHA256
   "0c53eefedbb11fe281ca363039303fe6634937e18c1a80a365fc3eebe0d42ba0")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/runtime-path-diagnostic/signal/isolated-build.lisp"
   :BYTES 249 :DEVICE 16777232 :INODE 1563406391 :MTIME 1793448702 :SHA256
   "a345276e3dfe377c0bbd359793165915b1527938a65250d367ce5ac079feecc1")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/runtime-path-diagnostic/signal/stderr.log"
   :BYTES 309 :DEVICE 16777232 :INODE 1563406392 :MTIME 1793448702 :SHA256
   "7d1c0c870e861046829f590ed70ef2aeb256142ae4b903a8debe9c42af40620c")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/runtime-path-diagnostic/signal/stderr.log.gz"
   :BYTES 171 :DEVICE 16777232 :INODE 1563406393 :MTIME 1793448702 :SHA256
   "fdfdf5ce89deb5b55039b7d9dd3137bbe6ea0fb557799a90853cd25638a58ffe")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/runtime-path-diagnostic/signal/stdout.log"
   :BYTES 0 :DEVICE 16777232 :INODE 1563406394 :MTIME 1793448702 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH "spikes/results/2026-10-31-local-index-budget/small-compaction.lisp"
   :BYTES 1019 :DEVICE 16777232 :INODE 1563406395 :MTIME 1793448702 :SHA256
   "5316405bc9bd787e5da6fa640524e2ab5c02890e20e40b56847e76ddf18fca81")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/strict-2.6.10/conservazione.lisp"
   :BYTES 1776 :DEVICE 16777232 :INODE 1563406397 :MTIME 1793448702 :SHA256
   "895e163a3d71329b10d30bfd3511bf6eedab9691b4c9726774c119311584a9be")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/strict-2.6.10/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563406398 :MTIME 1793448702 :SHA256
   "9d1799a99f4cad78dd23f3a6dc293f984425cd1fa675a343e1559a02eaa081c8")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/strict-2.6.10/report.lisp.gz"
   :BYTES 319506 :DEVICE 16777232 :INODE 1563406399 :MTIME 1793448702 :SHA256
   "40033dacaffce62f3f20d4db75d484e645e4a147b85f6072fea0949cdb49f2a3")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/ci-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563406402 :MTIME 1793448702 :SHA256
   "d3f90fe6f54c86967168bb57a991cb57765570fd84342faebebde2a7b287d4ec")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/ci-command/report.lisp"
   :BYTES 323549 :DEVICE 16777232 :INODE 1563406403 :MTIME 1793448702 :SHA256
   "360cf0888b3acbffecc625cf64a02c8addfc8ee2c0653079f80af33ff4969420")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/ci-self-test/boundaries.lisp"
   :BYTES 976 :DEVICE 16777232 :INODE 1563406405 :MTIME 1793448702 :SHA256
   "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/ci-self-test/conditions.lisp"
   :BYTES 663 :DEVICE 16777232 :INODE 1563406406 :MTIME 1793448702 :SHA256
   "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/ci-self-test/data.lisp"
   :BYTES 3214 :DEVICE 16777232 :INODE 1563406407 :MTIME 1793448702 :SHA256
   "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/ci-self-test/measure.lisp"
   :BYTES 2041 :DEVICE 16777232 :INODE 1563406408 :MTIME 1793448702 :SHA256
   "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/ci-self-test/publication.lisp"
   :BYTES 1181 :DEVICE 16777232 :INODE 1563406409 :MTIME 1793448702 :SHA256
   "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/ci-self-test/report.lisp"
   :BYTES 632 :DEVICE 16777232 :INODE 1563406410 :MTIME 1793448702 :SHA256
   "3bf53e3748c34568e0fb83b9f6f7ed394be5c711a74ca8b7bdde88a45f49bc23")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/ci-self-test/tests.lisp"
   :BYTES 2409 :DEVICE 16777232 :INODE 1563406411 :MTIME 1793448702 :SHA256
   "49acae481faadf756a5650f1c389386f54afc7b6e86fca34b8cb0d65726f76e4")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/ci-self-test/workflow.lisp"
   :BYTES 27784 :DEVICE 16777232 :INODE 1563406412 :MTIME 1793448702 :SHA256
   "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/reader-self-test/completion-exit/isolated-build.lisp"
   :BYTES 197 :DEVICE 16777232 :INODE 1563406415 :MTIME 1793448702 :SHA256
   "1a45dcf8a6d03f1e8866e49280c6f0edb894320c90624d5620fad1e3d546cea9")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/reader-self-test/completion-exit/stderr.log"
   :BYTES 0 :DEVICE 16777232 :INODE 1563406416 :MTIME 1793448702 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/reader-self-test/completion-exit/stdout.log"
   :BYTES 105 :DEVICE 16777232 :INODE 1563406417 :MTIME 1793448702 :SHA256
   "5e630c1b44d68ce71b27d151e76bf367e3cbd941200adc36cdd30e0fe7390531")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/reader-self-test/report.lisp"
   :BYTES 2003 :DEVICE 16777232 :INODE 1563406418 :MTIME 1793448702 :SHA256
   "fbc1233efa14db02b96ea0c548edb7145223a214a01387da116d5024aad19902")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/reader-self-test/signal/isolated-build.lisp"
   :BYTES 247 :DEVICE 16777232 :INODE 1563406420 :MTIME 1793448702 :SHA256
   "ff5cf55dda241d32ea1b4308172c7dc526436cbf1d546e7471148cee95a873d1")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/reader-self-test/signal/stderr.log"
   :BYTES 0 :DEVICE 16777232 :INODE 1563406421 :MTIME 1793448702 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/reader-self-test/signal/stdout.log"
   :BYTES 126 :DEVICE 16777232 :INODE 1563406422 :MTIME 1793448702 :SHA256
   "3697c68fa71f124c8d05d8cc5d649a744586a10989eb2e67c5bdce6bfc760142")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/snapshot-self-test/completion-exit/isolated-build.lisp"
   :BYTES 199 :DEVICE 16777232 :INODE 1563406425 :MTIME 1793448702 :SHA256
   "b8bb4416a818775bae5c77341eeec2c356a2733f633ac2bc8b6ac3ff955d05e0")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/snapshot-self-test/completion-exit/stderr.log"
   :BYTES 0 :DEVICE 16777232 :INODE 1563406426 :MTIME 1793448702 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/snapshot-self-test/completion-exit/stdout.log"
   :BYTES 107 :DEVICE 16777232 :INODE 1563406427 :MTIME 1793448702 :SHA256
   "4f22544421d9012fe132a36bf15950cd327ca959b8f9c5ef3d386e0c8b62a25c")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/snapshot-self-test/report.lisp"
   :BYTES 2021 :DEVICE 16777232 :INODE 1563406428 :MTIME 1793448702 :SHA256
   "f7c1efcdbffccf2ce8013e0e6b56e02176e61b970b06fa34a4941dfa49106d18")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/snapshot-self-test/signal/isolated-build.lisp"
   :BYTES 249 :DEVICE 16777232 :INODE 1563406430 :MTIME 1793448702 :SHA256
   "a345276e3dfe377c0bbd359793165915b1527938a65250d367ce5ac079feecc1")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/snapshot-self-test/signal/stderr.log"
   :BYTES 0 :DEVICE 16777232 :INODE 1563406431 :MTIME 1793448702 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/snapshot-self-test/signal/stdout.log"
   :BYTES 128 :DEVICE 16777232 :INODE 1563406432 :MTIME 1793448702 :SHA256
   "e3502e714a0530acb1f0130c4ced4a016607bcb067e3686f6f29704db8423ea5")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/SPK-01.lisp"
   :BYTES 27228 :DEVICE 16777232 :INODE 1563406434 :MTIME 1793448702 :SHA256
   "13c5a7bc88c5947143888c8ea260a380569134ebb12feedfd067a245f845f8f1")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/SPK-02.lisp"
   :BYTES 1607 :DEVICE 16777232 :INODE 1563406435 :MTIME 1793448702 :SHA256
   "d1dadef7dbbcf6ef6d2996b0ca5a82567b2763e9d34cce41c0991395c91e9bc8")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/SPK-03.lisp"
   :BYTES 3664 :DEVICE 16777232 :INODE 1563406436 :MTIME 1793448702 :SHA256
   "d153356973dfacf08b0d2d0ca5450da974cff8a412a407f139c0ddaa467a978e")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/SPK-04.lisp"
   :BYTES 6752 :DEVICE 16777232 :INODE 1563406437 :MTIME 1793448702 :SHA256
   "3a1bb79f08f55bb0de8f740023b8566cb5623a805506e55a36ceb2e48d1ef3cc")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/SPK-05.lisp"
   :BYTES 10140 :DEVICE 16777232 :INODE 1563406438 :MTIME 1793448702 :SHA256
   "636e31c26f9fffefb07ca1ca09d1cdb59e04d38bb70bd9fb398b4d6b31987721")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/SPK-06.lisp"
   :BYTES 24118 :DEVICE 16777232 :INODE 1563406439 :MTIME 1793448702 :SHA256
   "69dc1f9c41065ca8a0255d1b1fa564a90390aa8f6db0214b01c70e5fc5e60334")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/SPK-07.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1563406440 :MTIME 1793448702 :SHA256
   "96d8ebeba3b266b7254b84c9c90a07e22b91f3a6ca20ae29e073b06d55228ae9")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/SPK-07.lisp.gz"
   :BYTES 411739 :DEVICE 16777232 :INODE 1563406441 :MTIME 1793448702 :SHA256
   "818fabc9caeba042189c7faac080f5de224f38dd45ce93819846dabfca2165dc")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/SPK-08.lisp"
   :BYTES 331092 :DEVICE 16777232 :INODE 1563406442 :MTIME 1793448702 :SHA256
   "1e1b2abaa45eab219e1770a3b8f68e380ea2a1913468f8b53bf24c96c3a95eca")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/SPK-09.lisp"
   :BYTES 2472 :DEVICE 16777232 :INODE 1563406443 :MTIME 1793448702 :SHA256
   "4aa68f2c575c23494fb065efc383f892a844d0f35015e5c05ede9d229ab09d30")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/SPK-10.lisp"
   :BYTES 22974 :DEVICE 16777232 :INODE 1563406444 :MTIME 1793448702 :SHA256
   "b4f470fbb3e9fb1eff1ce38a1a58999575fd02170a148a38bf68c022c237b530")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/SPK-11.lisp"
   :BYTES 73986 :DEVICE 16777232 :INODE 1563406445 :MTIME 1793448702 :SHA256
   "423d959e61d9dd0c8b1e9d5c4912cacfd5cea4d70ec1f9c67fedd0382d8960f9")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/conservazione.lisp"
   :BYTES 2352 :DEVICE 16777232 :INODE 1563406446 :MTIME 1793448702 :SHA256
   "dff7305a50630895dc3ec7d72fa67a12563be22b90533356234d3c7b228bc96f")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/report.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1563406447 :MTIME 1793448702 :SHA256
   "76be584a72d317eb048c35f64aa020057e3f8136c6a4f1df398d81162c794b50")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/supporting/spikes/report.lisp.gz"
   :BYTES 484126 :DEVICE 16777232 :INODE 1563406448 :MTIME 1793448702 :SHA256
   "5f99361b73ced65378c6c2bf8c4bb14f94e8bc3db77bd2391bac81d0229f938d")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/targeted-2.6.9/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563406450 :MTIME 1793448702 :SHA256
   "352a11fba684d71b8457af310b9ce78dde0e61750d0cfb1ac7eb8ce53236eba0")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/targeted-2.6.9/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563406451 :MTIME 1793448702 :SHA256
   "8cf192aaab7087e575336dbd3c5e9345222d361027a4ac40b8d39dcb6d9340f3")
  (:PATH
   "spikes/results/2026-10-31-local-index-budget/targeted-2.6.9/report.lisp.gz"
   :BYTES 104045 :DEVICE 16777232 :INODE 1563406452 :MTIME 1793448702 :SHA256
   "10ee77c8c219a40ff1ec748e2af5c40bc6863cc1e1e665282ce3d1043571b745")
  (:PATH "spikes/results/2026-10-31-local-index-budget/targeted.lisp" :BYTES
   573 :DEVICE 16777232 :INODE 1563406453 :MTIME 1793448702 :SHA256
   "2814a2b499b5dacbfe407ce70efcb5add36f45b5ad57ba7688866bc6678a2f2e")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/attempt-1-compile/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356155 :MTIME 1793446791 :SHA256
   "58f4d6b773ce3b5d330b7a562426ab02c2610a9ea54c868de682df36ea432cde")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/attempt-1-compile/report.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1563356156 :MTIME 1793446791 :SHA256
   "e6e0a34386a49b43e51a512001f51109f2a86e1c4aba2efba718e7a2d6373938")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/attempt-1-compile/report.lisp.gz"
   :BYTES 100602 :DEVICE 16777232 :INODE 1563356157 :MTIME 1793446791 :SHA256
   "8649987de7d6af858c13ac61484dae4085d1addee5e7633ffff1a7938ed08686")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/attempt-2-test-ready-gate/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356159 :MTIME 1793446791 :SHA256
   "a92f86e50b6ec0cce63c44d23776c6d391b1ce9cba19b401b5c1e02c35d8a90e")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/attempt-2-test-ready-gate/report.lisp"
   :BYTES 318686 :DEVICE 16777232 :INODE 1563356160 :MTIME 1793446791 :SHA256
   "5cd16883db00911fcb3eaf2befa1b263e9830eceacd96c7d0dfc4c7804c579e5")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/attempt-3-observer-contract/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356162 :MTIME 1793446791 :SHA256
   "e747338b839a43cdb56bfc85da0dc5a16d3d8ba266fe5fce9476494df3b0ddfb")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/attempt-3-observer-contract/report.lisp"
   :BYTES 318698 :DEVICE 16777232 :INODE 1563356163 :MTIME 1793446791 :SHA256
   "77e2143bcceb731a470919e1639a0928065adf5c8872b8b729443e7904772e92")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/ci-selftest/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356166 :MTIME 1793446791 :SHA256
   "1c654eb65cebeb9dd88cb5d369f1775a3356a5af41de4bbd7973e871f6f695a6")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/ci-selftest/report.lisp"
   :BYTES 311943 :DEVICE 16777232 :INODE 1563356167 :MTIME 1793446791 :SHA256
   "82d4b3e9a599f9fe40f537afdd27dd548002fba838ea716343956cda48592c70")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/conservazione.lisp"
   :BYTES 1776 :DEVICE 16777232 :INODE 1563356168 :MTIME 1793446791 :SHA256
   "d5775e339de870bcdf338b23c4d7e7045d537dbfd6c393ae5c1b92528b43242d")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563356169 :MTIME 1793446791 :SHA256
   "1885892da457afb7744ec4ab1416edbc0fc0340063c7c8a44fe54a300c2b0a16")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/report.lisp.gz"
   :BYTES 321916 :DEVICE 16777232 :INODE 1563356170 :MTIME 1793446791 :SHA256
   "d68fd315610b409a42c39964345d34ac8cf440cf8c75d1e05bdd6bd139146eb7")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/SPK-01.lisp"
   :BYTES 27228 :DEVICE 16777232 :INODE 1563356172 :MTIME 1793446791 :SHA256
   "776bb44494ba77cbcfd2dd88abc748cd9b65c508ee0589efb0ca926de55447f0")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/SPK-02.lisp"
   :BYTES 1607 :DEVICE 16777232 :INODE 1563356173 :MTIME 1793446791 :SHA256
   "64f54581a5aa7ede5ce2abe001619d7019defb9ddc5ecbc7fa1b12361376569e")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/SPK-03.lisp"
   :BYTES 3664 :DEVICE 16777232 :INODE 1563356174 :MTIME 1793446791 :SHA256
   "44b4db58a225f0d8abfaa4a972b999a27fd75592812f1c059ed188787a87954c")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/SPK-04.lisp"
   :BYTES 6752 :DEVICE 16777232 :INODE 1563356175 :MTIME 1793446791 :SHA256
   "dda5d3dd9585af7f38b12a65fba323c0221151650cfc8d3f7ac56b7914ba96f0")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/SPK-05.lisp"
   :BYTES 10168 :DEVICE 16777232 :INODE 1563356176 :MTIME 1793446791 :SHA256
   "3b5fdfc6095fcfda5b7f2eb64e9d300050a677457a26ac58eb632d09844f40ce")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/SPK-06.lisp"
   :BYTES 24122 :DEVICE 16777232 :INODE 1563356177 :MTIME 1793446791 :SHA256
   "4b0c4958c26a5813f01a446a746602267ef06b8f49aa527218f963ad6c8359a9")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/SPK-07.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1563356178 :MTIME 1793446791 :SHA256
   "a99103fba1f892b6254c63aeb7255049a15dbfacf5a6a98926c955f0723b2118")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/SPK-07.lisp.gz"
   :BYTES 411739 :DEVICE 16777232 :INODE 1563356179 :MTIME 1793446791 :SHA256
   "0111ab592e65af4084ff57188940cf9803a19a82d52af30fc4ce7157d2eb5417")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/SPK-08.lisp"
   :BYTES 331092 :DEVICE 16777232 :INODE 1563356180 :MTIME 1793446791 :SHA256
   "63e85d188761e67dcffda5170bfc0379922910eb456a882646f7e70e3320e808")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/SPK-09.lisp"
   :BYTES 2472 :DEVICE 16777232 :INODE 1563356181 :MTIME 1793446791 :SHA256
   "0bb90433419b89cc15ea777ac3d35dd108ad50cbbffd1bf45aa552db025708e7")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/SPK-10.lisp"
   :BYTES 22973 :DEVICE 16777232 :INODE 1563356182 :MTIME 1793446791 :SHA256
   "bd7ad98c49149ca50aaecbeb10996c4dc3ce45ed47f57b56f97a81a1dce86eb6")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/SPK-11.lisp"
   :BYTES 73986 :DEVICE 16777232 :INODE 1563356183 :MTIME 1793446791 :SHA256
   "f3480bd7bfd6687f013c81516730b883598d01e362f417d3270be3dc9130f8f7")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/conservazione.lisp"
   :BYTES 2352 :DEVICE 16777232 :INODE 1563356184 :MTIME 1793446791 :SHA256
   "78ae1abe913b37becad058cd967b1ad4247c55b3274fa40238738496f243b96b")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/report.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1563356185 :MTIME 1793446791 :SHA256
   "2714bd70e56413d6c9573bd450ca09b7749047a08cf2f8df97e550030162c630")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/check-run/spikes/report.lisp.gz"
   :BYTES 483781 :DEVICE 16777232 :INODE 1563356186 :MTIME 1793446791 :SHA256
   "c0789655ecd3fc53dbb9070e979f0b83f2b76a6af911c4e5cc161e8ac7c0258d")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/precommit-compaction.lisp"
   :BYTES 504 :DEVICE 16777232 :INODE 1563356187 :MTIME 1793446791 :SHA256
   "9ea4830f65084a55586fba566f9581f6fa081a4b308fb6c806697d9773ec4ee5")
  (:PATH "spikes/results/2026-10-31-local-index-discovery/report.md" :BYTES
   3300 :DEVICE 16777232 :INODE 1563356188 :MTIME 1793446791 :SHA256
   "ce7fcb491f355a7311ef9aaf11ae38c9804d2e60f0b6a2c1eaa4f13ef0d2c451")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/sbcl-2.6.10-targeted/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356190 :MTIME 1793446791 :SHA256
   "b611c7b10497cf6c785ac18fe2761e1a9f202820287d86f13ec3000c26f480b6")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/sbcl-2.6.10-targeted/report.lisp"
   :BYTES 333326 :DEVICE 16777232 :INODE 1563356191 :MTIME 1793446791 :SHA256
   "5f5011f2f1427ccade997a65d030b0682c49531b8d510ac61891eda619104ce7")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/targeted-run/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356193 :MTIME 1793446791 :SHA256
   "8d7ed72d4b450eaaff7b2e8b65f87e96dc869c107316bf0c03b06ebd8a0adb85")
  (:PATH
   "spikes/results/2026-10-31-local-index-discovery/targeted-run/report.lisp"
   :BYTES 333279 :DEVICE 16777232 :INODE 1563356194 :MTIME 1793446791 :SHA256
   "1eccb19af2d09384175cf50831996e5758c33e1b6a30302e0266d5e548fe0bf4")
  (:PATH "spikes/results/2026-10-31-local-index-discovery/targeted.lisp" :BYTES
   604 :DEVICE 16777232 :INODE 1563356195 :MTIME 1793446791 :SHA256
   "9f5dd7e3c584335940344626a7fd13670756184feb986e5e3a6b705e345b5c3f")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/attempt-get-worker-directory/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356198 :MTIME 1793446791 :SHA256
   "508430c19dc10e47be16b653dfdb1f8d9e49a0993f52b60d2b75692ffadf5710")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/attempt-get-worker-directory/report.lisp"
   :BYTES 313052 :DEVICE 16777232 :INODE 1563356199 :MTIME 1793446791 :SHA256
   "720e6da438ec15ed5a844bb80d26cb9bf75e745c08e4ce4a888e2774a04e75e3")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/attempt-mnemonic-disassembly/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356201 :MTIME 1793446791 :SHA256
   "b8c4994d0b60c8a35cc89f5ca7ba24d6c8d96a371faf0803ae6e1a2965f6674e")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/attempt-mnemonic-disassembly/report.lisp"
   :BYTES 329957 :DEVICE 16777232 :INODE 1563356202 :MTIME 1793446791 :SHA256
   "12c80f5ebdce4d4951c7b21b7585fe9ca9ac992d8ff47cd586575ccfebcf8416")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/attempt-test-parser.log.gz"
   :BYTES 168430 :DEVICE 16777232 :INODE 1563356203 :MTIME 1793446791 :SHA256
   "c858b4ad83fcefc4d484fc5a5840823e91d836aad446da0b09852e58013698eb")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/bench-2.6.10-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356205 :MTIME 1793446791 :SHA256
   "2d31a0e0bb88f877fe6a8f7f396953c62960d7d0fce2ed41887f78693157c991")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/bench-2.6.10-command/report.lisp"
   :BYTES 322581 :DEVICE 16777232 :INODE 1563356206 :MTIME 1793446791 :SHA256
   "098fde074227253703899974da490a13f7670415efc45d7db15043d03e3a6629")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/bench-2.6.10-run/result.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563356208 :MTIME 1793446791 :SHA256
   "97cd893299cf42c5d0d453f13508a5db65e4d0d63fe45837a506bf5bce3032cc")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/bench-2.6.10-run/result.lisp.gz"
   :BYTES 582828 :DEVICE 16777232 :INODE 1563356209 :MTIME 1793446791 :SHA256
   "0b9f558f5dc81f1ffde0852f78e5edaae22f8b1349cc05e8e18b4f5456aa4c7e")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/bench-2.6.9-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356211 :MTIME 1793446791 :SHA256
   "71effe19f59d339cc9b49b5f536c21c5b0eff5333fb5016c7084a4848d208afa")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/bench-2.6.9-command/report.lisp"
   :BYTES 322553 :DEVICE 16777232 :INODE 1563356212 :MTIME 1793446791 :SHA256
   "80bab5fd2b8f668cc168586f0f1285769e3d68358a76bf972cb621adc9664398")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/bench-2.6.9-run/result.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563356214 :MTIME 1793446791 :SHA256
   "63553838fe72013698cc7b00b4093fc761e5f74e37dd777d10c03a832d123a4b")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/bench-2.6.9-run/result.lisp.gz"
   :BYTES 596725 :DEVICE 16777232 :INODE 1563356215 :MTIME 1793446791 :SHA256
   "0812395d17a5c1caad8e8779d82fccae2b72e034b2dde0d5c3a75b1364427003")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/cache-native-1/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356217 :MTIME 1793446791 :SHA256
   "68c1308b85622ec73e91583413805c577ec06ac61cee86cfb87b1080b276b3ea")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/cache-native-1/report.lisp"
   :BYTES 312854 :DEVICE 16777232 :INODE 1563356218 :MTIME 1793446791 :SHA256
   "701c0a5b07a824183d42ad66411853912718fa4328911b662aa1d7902b21c1a0")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/cache-native-2/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356220 :MTIME 1793446791 :SHA256
   "c3bda70da3d3bf428cb8f642c2fa31d7bd5d984410247f940134136905f4a56c")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/cache-native-2/report.lisp"
   :BYTES 312854 :DEVICE 16777232 :INODE 1563356221 :MTIME 1793446791 :SHA256
   "75bff88073427d375c40b6b6800cbee1250271505e6bef13fb2d6f4c6ee2ff64")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/cache-software/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356223 :MTIME 1793446791 :SHA256
   "0fb3203f28f1930bf3393f8c13e02a78b58d2c32a84d6b560937e78df0a227e8")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/cache-software/report.lisp"
   :BYTES 312987 :DEVICE 16777232 :INODE 1563356224 :MTIME 1793446791 :SHA256
   "dd29743a8653ef3f847ed73aa72da214962835533b2d0e0fd763587071cf0a03")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/cache-transition.lisp"
   :BYTES 868 :DEVICE 16777232 :INODE 1563356225 :MTIME 1793446791 :SHA256
   "8abf8eb976ba90f9d89f80ea36cf6868521473fc870220fc7a8910a874e21262")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/ci-selftest/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356228 :MTIME 1793446791 :SHA256
   "009cceb86628aee8b53cda2f28e46398960300043c0f687dc95763a2dd25c747")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/ci-selftest/report.lisp"
   :BYTES 313565 :DEVICE 16777232 :INODE 1563356229 :MTIME 1793446791 :SHA256
   "d7ab136641adb456ffff4e1dbf851727e93487d17eb5dde2ec2fec6352782f9f")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/conservazione.lisp"
   :BYTES 1776 :DEVICE 16777232 :INODE 1563356230 :MTIME 1793446791 :SHA256
   "c3d363544228689ab0fdb2ca56056e9712d99143afdd5b45a6f7e2b5177cfd0f")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563356231 :MTIME 1793446791 :SHA256
   "bf0b1c60e2aa7360ebfacd0383a7ea902b9897f857b55a544dafe323ebff7806")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/report.lisp.gz"
   :BYTES 319087 :DEVICE 16777232 :INODE 1563356232 :MTIME 1793446791 :SHA256
   "d0210f4a2b1c912c87012edfe8310bbe02b94cf6b65cec63d57b566a83cffb53")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/SPK-01.lisp"
   :BYTES 27228 :DEVICE 16777232 :INODE 1563356234 :MTIME 1793446791 :SHA256
   "fdfd4255709e380710c8a49e7e306a8a46240dbed986bf7ba93206620aacf205")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/SPK-02.lisp"
   :BYTES 1607 :DEVICE 16777232 :INODE 1563356235 :MTIME 1793446791 :SHA256
   "ddda71a6260b86305f78d8a88a3cf0b3e69e4e8ce3f8000329369e85421046d3")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/SPK-03.lisp"
   :BYTES 3666 :DEVICE 16777232 :INODE 1563356236 :MTIME 1793446791 :SHA256
   "b395760917aa0fcb450b4e400b89dd27bc61086aa0390d03fb37471d7529e2c7")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/SPK-04.lisp"
   :BYTES 6752 :DEVICE 16777232 :INODE 1563356237 :MTIME 1793446791 :SHA256
   "471606b2372f4fd9dd90d8ec501b9e3504d4fc3d3b57e51eba02d08f4b3c958e")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/SPK-05.lisp"
   :BYTES 10130 :DEVICE 16777232 :INODE 1563356238 :MTIME 1793446791 :SHA256
   "300488e226d35265ff828090762b1e5a0d4567b5745c4538f80636ed720b1e04")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/SPK-06.lisp"
   :BYTES 24072 :DEVICE 16777232 :INODE 1563356239 :MTIME 1793446791 :SHA256
   "239c95edea2fb8eb657c15e469fad4701434dbda6cc3764348744d167a1013a2")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/SPK-07.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1563356240 :MTIME 1793446791 :SHA256
   "851dbc93f67ccff43022eb44f1c7fabec1660864d87cfae9436154564305a047")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/SPK-07.lisp.gz"
   :BYTES 411761 :DEVICE 16777232 :INODE 1563356241 :MTIME 1793446791 :SHA256
   "cf68645faa9c995ec3941d311146218568c7ea908bafcbe34d25816a300f70fe")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/SPK-08.lisp"
   :BYTES 319170 :DEVICE 16777232 :INODE 1563356242 :MTIME 1793446791 :SHA256
   "bb98f82b82f10b776be1a7212086d4fe59bcf76e1d1509f443dcc066bc6e2edf")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/SPK-09.lisp"
   :BYTES 2472 :DEVICE 16777232 :INODE 1563356243 :MTIME 1793446791 :SHA256
   "5ceccb8ad814165cd5330d2bf62c63d9fdd4c77bc7cf60221b93e9b68fd30736")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/SPK-10.lisp"
   :BYTES 22976 :DEVICE 16777232 :INODE 1563356244 :MTIME 1793446791 :SHA256
   "cc2d24a249ad4bfbb5da939f48ed1fb827656bad69fc465db9021be712a25ee3")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/SPK-11.lisp"
   :BYTES 75153 :DEVICE 16777232 :INODE 1563356245 :MTIME 1793446791 :SHA256
   "fa0e28205fef9ed3452908c7b12c802397ed8da663ebdaf8cc682fc3f052be63")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/conservazione.lisp"
   :BYTES 2352 :DEVICE 16777232 :INODE 1563356246 :MTIME 1793446791 :SHA256
   "6a8b885816d90f3f545c12f4ba47baa65f9516d08d69de840d16c51b2f4ef35b")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/report.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1563356247 :MTIME 1793446791 :SHA256
   "db5854e9459f342e75df8fd1598c4da6842b1501c5740a38c603b6411eae2d7b")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/check-run/spikes/report.lisp.gz"
   :BYTES 481854 :DEVICE 16777232 :INODE 1563356248 :MTIME 1793446791 :SHA256
   "ac74f715761f086d6838a9655d85c5905e820caeda9934d8646b26a3d929fd46")
  (:PATH "spikes/results/2026-10-31-local-performance-fix/cleanup.lisp" :BYTES
   275 :DEVICE 16777232 :INODE 1563356249 :MTIME 1793446791 :SHA256
   "5f8218d36895cabf6f6dc414bd25644eeaf4d91c4ef3589711aa86d25813440a")
  (:PATH "spikes/results/2026-10-31-local-performance-fix/compaction.lisp"
   :BYTES 1698 :DEVICE 16777232 :INODE 1563356250 :MTIME 1793446791 :SHA256
   "fb03811cef43cabd59acb507937a0e89d76161ec07237783d338375670a6bfdb")
  (:PATH "spikes/results/2026-10-31-local-performance-fix/comparison.csv"
   :BYTES 56871 :DEVICE 16777232 :INODE 1563356251 :MTIME 1793446791 :SHA256
   "40094be277cbb1a2e27a47d059d19db65505bf21086d77fc8c86faca4f21f0e8")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/component-inventory.lisp"
   :BYTES 313 :DEVICE 16777232 :INODE 1563356252 :MTIME 1793446791 :SHA256
   "a3ceda3bbf7692215fcfedb3d480ee045c87658821fb3813461f4f4c6f41e9fa")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/component-metrics.csv"
   :BYTES 12511 :DEVICE 16777232 :INODE 1563356253 :MTIME 1793446791 :SHA256
   "7719e82060098a28aaf54c79448a2336b58beeb0fa793835be15671590b5151d")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/component-summary.lisp"
   :BYTES 3313 :DEVICE 16777232 :INODE 1563356254 :MTIME 1793446791 :SHA256
   "fbe3920e103ba3f72ebdbde175733443a31411ea71f38a18fc1563414e431037")
  (:PATH "spikes/results/2026-10-31-local-performance-fix/driver-manifest.json"
   :BYTES 1396 :DEVICE 16777232 :INODE 1563356255 :MTIME 1793446791 :SHA256
   "67c9a3e98eb49fdc7304916ed204fb5b758652781473b4f539c18c1a53cdf7f9")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/final-cache-native-1/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356257 :MTIME 1793446791 :SHA256
   "ea7509d2eb6522223db6a8b92d1b4f5e04f75d663d8fe837024f42db50dde200")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/final-cache-native-1/report.lisp"
   :BYTES 312940 :DEVICE 16777232 :INODE 1563356258 :MTIME 1793446791 :SHA256
   "4cac0f896898ab44be719139714cec56fd0734da1c5208d687a90c498feb7c69")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/final-cache-native-2/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356260 :MTIME 1793446791 :SHA256
   "2511191842a3e19bdb6ee71b968f5886cd78b972cde4a6135ccd207876815fdc")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/final-cache-native-2/report.lisp"
   :BYTES 312940 :DEVICE 16777232 :INODE 1563356261 :MTIME 1793446791 :SHA256
   "0174dbaeb2118cffb0a5615b3516ea917be0b277e8f4d8809495b31d8083d309")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/final-cache-software/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356263 :MTIME 1793446791 :SHA256
   "730541d8b60b3c6cc1c55133ef5fa16a53ffd1883095870e9ef159d9dee7a5c4")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/final-cache-software/report.lisp"
   :BYTES 313073 :DEVICE 16777232 :INODE 1563356264 :MTIME 1793446791 :SHA256
   "7afbd9c032c097679f66ee0697b0fa121987cdb7802ade464c92ddb5dafd2515")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/get-throughput-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356266 :MTIME 1793446791 :SHA256
   "89195c929b10b5ea9d32867ec087e10cdf984af0e8e5e99b83b3548594af149d")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/get-throughput-command/report.lisp"
   :BYTES 312915 :DEVICE 16777232 :INODE 1563356267 :MTIME 1793446791 :SHA256
   "6f2d0f9cfe73920b480e1ed0ae0a2e90c2b6336009736521104f9c8e199d0790")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/get-throughput-run/report.lisp"
   :BYTES 133942 :DEVICE 16777232 :INODE 1563356269 :MTIME 1793446791 :SHA256
   "4f303c365e51c1c653885d4d9c94486a9e249c5adfdda7413244b002b15e20b5")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/get-workers-command/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356271 :MTIME 1793446791 :SHA256
   "5cf92d465aff3603412b64ee63cadcc9897d107613357ac8e445bf104805749d")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/get-workers-command/report.lisp"
   :BYTES 313007 :DEVICE 16777232 :INODE 1563356272 :MTIME 1793446791 :SHA256
   "f6e9f59f96fee795bd092bbf9759e5e9d9fd10b720342bfe05cbf7974fe6b987")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/get-workers-run/report.lisp"
   :BYTES 272821 :DEVICE 16777232 :INODE 1563356274 :MTIME 1793446791 :SHA256
   "4a01d79d2a8996c3377c5025a10a5f4c5593d9dd2c439e61000c48429f7341d5")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/get-workers-run/self-test-metrics.lisp"
   :BYTES 50825 :DEVICE 16777232 :INODE 1563356275 :MTIME 1793446791 :SHA256
   "f0e6231c5dd73328a23a6b62ea93c17d65ce5aae00dea72ca9ca00d1c99fd9a1")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/get-workers-run/self-test-sensor.lisp"
   :BYTES 347 :DEVICE 16777232 :INODE 1563356276 :MTIME 1793446791 :SHA256
   "616e082585e05733e382f93f4ccf83fb2de053b6117a11b8ab7f68c0de1a1646")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/metrics-2.6.10/metrics.csv"
   :BYTES 20835 :DEVICE 16777232 :INODE 1563356278 :MTIME 1793446791 :SHA256
   "5c45fdee613aa8c257ace6a436c5ad94f05c922e260207322c801b21e9fc8ba6")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/metrics-2.6.10/resources.csv"
   :BYTES 6004 :DEVICE 16777232 :INODE 1563356279 :MTIME 1793446791 :SHA256
   "c9f0b37c4d4ffd05700b48b123b1643d8bdfda95e5a3baac22ff2db848d09dde")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/metrics-2.6.10/startup.csv"
   :BYTES 2124 :DEVICE 16777232 :INODE 1563356280 :MTIME 1793446791 :SHA256
   "6770fc39fc09cf5df289f5d6520953be6392ba3f91ab6e7f2ca23c989332b15a")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/metrics-2.6.10/summary.lisp"
   :BYTES 65877 :DEVICE 16777232 :INODE 1563356281 :MTIME 1793446791 :SHA256
   "a961e9b835b49b83b6a59108816f7b58daec23153b6428f16bd6d0e85fc01a65")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/metrics-2.6.9/metrics.csv"
   :BYTES 20838 :DEVICE 16777232 :INODE 1563356283 :MTIME 1793446791 :SHA256
   "4c8b567df1de0b959b1ddd96bbbdb71b15c475af95135ace373c9767f6348fd3")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/metrics-2.6.9/resources.csv"
   :BYTES 6008 :DEVICE 16777232 :INODE 1563356284 :MTIME 1793446791 :SHA256
   "b7e405c10fd23434827ec2fc41d93d80fb7a713eabb8da9d6a46ac78b340add4")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/metrics-2.6.9/startup.csv"
   :BYTES 2124 :DEVICE 16777232 :INODE 1563356285 :MTIME 1793446791 :SHA256
   "edd2977facdc799ced47c9097cc68cd6ff4bbbec641cacb9d326c526cc8d4645")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/metrics-2.6.9/summary.lisp"
   :BYTES 66169 :DEVICE 16777232 :INODE 1563356286 :MTIME 1793446791 :SHA256
   "b84dfa427bb0b79a014dbd0bb36a5566fcefa6091bc11dbeac033eadbc6078fd")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/pre-owner-qualification/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356288 :MTIME 1793446791 :SHA256
   "2308e0ee91e0845cc14d755fd3509d6be1a2e7b24e919366882e00ee3bbb6913")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/pre-owner-qualification/report.lisp"
   :BYTES 424619 :DEVICE 16777232 :INODE 1563356289 :MTIME 1793446791 :SHA256
   "cc260ae5e255965799bf59f8444d7590aa89a82bacd8c8a509b071ab5ad7a0e8")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/precommit-cleanup.lisp"
   :BYTES 170 :DEVICE 16777232 :INODE 1563356290 :MTIME 1793446791 :SHA256
   "223c30c6904f984dd38a2d12c198c729b411725010b273f106bef6749bb87165")
  (:PATH "spikes/results/2026-10-31-local-performance-fix/qualify.lisp" :BYTES
   2166 :DEVICE 16777232 :INODE 1563356291 :MTIME 1793446791 :SHA256
   "56bf00c0ab14ed51ad7a7f87b54a003ca00d97a057ca57f87d80fe0e2db9ae3d")
  (:PATH "spikes/results/2026-10-31-local-performance-fix/report.md" :BYTES
   9709 :DEVICE 16777232 :INODE 1563356292 :MTIME 1793446791 :SHA256
   "ccec1f25b70a54441ebc595c48b7b44975dcb81536012f3d41af43c49b6acea3")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/strict-2.6.9-run/conservazione.lisp"
   :BYTES 1776 :DEVICE 16777232 :INODE 1563356294 :MTIME 1793446791 :SHA256
   "2585b6c275ca25e8477a1dd9b40b6ed7fd0ad578815c788bdaa2447ab3b57609")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/strict-2.6.9-run/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563356295 :MTIME 1793446791 :SHA256
   "f72081783294b376081622387f042785661e35ce6a31515d4f8ee2235df5dc08")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/strict-2.6.9-run/report.lisp.gz"
   :BYTES 311598 :DEVICE 16777232 :INODE 1563356296 :MTIME 1793446791 :SHA256
   "b93376264064d3ab817523d9ca01f8dc19df580b469f310f6224b2ffcb43f816")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/strict-software-run/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356298 :MTIME 1793446791 :SHA256
   "9496151f0a7845fd8e3457fdeb66fc1d048e6d1e09654b8ca83b0d4151f6ac7b")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/strict-software-run/report.lisp"
   :BYTES 603078 :DEVICE 16777232 :INODE 1563356299 :MTIME 1793446791 :SHA256
   "e8ea3f192d43a084cd1df97e7589427d4f9f5ed8f1d345672c4cd6535c12dd53")
  (:PATH "spikes/results/2026-10-31-local-performance-fix/strict-software.lisp"
   :BYTES 735 :DEVICE 16777232 :INODE 1563356300 :MTIME 1793446791 :SHA256
   "7fa89559d3131bc2486644cef1a36d44103fcebc1bdfd93590c064f4615327c0")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/targeted-qualification/conservazione.lisp"
   :BYTES 1184 :DEVICE 16777232 :INODE 1563356302 :MTIME 1793446791 :SHA256
   "6a18bc799bf2b0dab456f6578e23dadacbce8005f2efa49232a0006579ad3b08")
  (:PATH
   "spikes/results/2026-10-31-local-performance-fix/targeted-qualification/report.lisp"
   :BYTES 424774 :DEVICE 16777232 :INODE 1563356303 :MTIME 1793446791 :SHA256
   "acfe2b2aa6ab3a2d19d2d2c077384423f65b4a560f57d5bbf76fc5077cd9d84e")
  (:PATH "spikes/results/2026-10-31-local-performance-fix/validate.lisp" :BYTES
   3926 :DEVICE 16777232 :INODE 1563356304 :MTIME 1793446791 :SHA256
   "74f9269dab7f879072e5aef8a9a7d282610630d890640f74d267f9e7d792a1f7")
  (:PATH "spikes/results/2026-10-31-local-performance-fix/validation.lisp"
   :BYTES 347 :DEVICE 16777232 :INODE 1563356305 :MTIME 1793446791 :SHA256
   "19bdb7719a9afca1b4395cd2b854e6a7a4e6ab0be124a65be6f1236ec2ad66e4")
  (:PATH
   "spikes/results/2026-10-31-main-integration/full-2.6.10/conservazione.lisp"
   :BYTES 1772 :DEVICE 16777232 :INODE 1563356308 :MTIME 1793446791 :SHA256
   "bfaeb2f72201995a02826578f42a1d53b542de329b20df8f391627dfd2324212")
  (:PATH "spikes/results/2026-10-31-main-integration/full-2.6.10/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563356309 :MTIME 1793446791 :SHA256
   "4ebb427846650891762b56fd38f0b4ab62156bead8a264991d12ed336a8aa188")
  (:PATH
   "spikes/results/2026-10-31-main-integration/full-2.6.10/report.lisp.gz"
   :BYTES 332401 :DEVICE 16777232 :INODE 1563356310 :MTIME 1793446791 :SHA256
   "e0285c8bed4804246e92c0b48a7e13cdd80980b35cdd911029571b85f2d0e256")
  (:PATH
   "spikes/results/2026-10-31-main-integration/interrupted-pre-fixture-adjustment/conservazione.lisp"
   :BYTES 1772 :DEVICE 16777232 :INODE 1563356312 :MTIME 1793446791 :SHA256
   "a9ba57459128c4aa8b2c42fa14309214b363959d7dfeddb0a03deac182d61e13")
  (:PATH
   "spikes/results/2026-10-31-main-integration/interrupted-pre-fixture-adjustment/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563356313 :MTIME 1793446791 :SHA256
   "3d0b534e55f0eac27b98e3ef6f05e14f7c1810ab132590d6300cff158ce43c65")
  (:PATH
   "spikes/results/2026-10-31-main-integration/interrupted-pre-fixture-adjustment/report.lisp.gz"
   :BYTES 310496 :DEVICE 16777232 :INODE 1563356314 :MTIME 1793446791 :SHA256
   "19f9a1107d9ecac68a66b23c552bba755ae6ce987213e2ff64d5472da817eae1")
  (:PATH "spikes/results/2026-10-31-main-integration/report.md" :BYTES 1537
   :DEVICE 16777232 :INODE 1563356315 :MTIME 1793446791 :SHA256
   "b28736387cf62d3ecbe53d67bec5c240f4d3220e95d2e030bfdd968ee0864e4e")
  (:PATH
   "spikes/results/2026-10-31-main-integration/strict-2.6.9/conservazione.lisp"
   :BYTES 1772 :DEVICE 16777232 :INODE 1563356317 :MTIME 1793446791 :SHA256
   "8fc3301f3dbff06f67276c3e58fba3b9366f516f4bebf26be90f34d43fc8f01b")
  (:PATH "spikes/results/2026-10-31-main-integration/strict-2.6.9/report.lisp"
   :BYTES 317 :DEVICE 16777232 :INODE 1563356318 :MTIME 1793446791 :SHA256
   "898078c335abe3e96e60e7013b8287c6f230eb0fefb8e34cadd3e5c052341cdc")
  (:PATH
   "spikes/results/2026-10-31-main-integration/strict-2.6.9/report.lisp.gz"
   :BYTES 325984 :DEVICE 16777232 :INODE 1563356319 :MTIME 1793446791 :SHA256
   "8feced45e23bcbb7c66bacc8474870f97936d7498a29b3d8ac0c532ba21cc6a4")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435016-command-4519-0/self-test-report.lisp"
   :BYTES 157 :DEVICE 16777232 :INODE 1563356322 :MTIME 1793446791 :SHA256
   "7e47f646dc8ee821fcd8e3536a898b414e928bb78b4cbfd416d95f7b431a963b")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-reader-self-test-4539-0/completion-exit/isolated-build.lisp"
   :BYTES 197 :DEVICE 16777232 :INODE 1563356325 :MTIME 1793446791 :SHA256
   "1a45dcf8a6d03f1e8866e49280c6f0edb894320c90624d5620fad1e3d546cea9")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-reader-self-test-4539-0/completion-exit/stderr.log"
   :BYTES 0 :DEVICE 16777232 :INODE 1563356326 :MTIME 1793446791 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-reader-self-test-4539-0/completion-exit/stdout.log"
   :BYTES 105 :DEVICE 16777232 :INODE 1563356327 :MTIME 1793446791 :SHA256
   "5e630c1b44d68ce71b27d151e76bf367e3cbd941200adc36cdd30e0fe7390531")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-reader-self-test-4539-0/report.lisp"
   :BYTES 1997 :DEVICE 16777232 :INODE 1563356328 :MTIME 1793446791 :SHA256
   "baa0d33494c4bf71b541de912ad074cde81e3753efbf045f866c7be7b6cf6554")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-reader-self-test-4539-0/signal/isolated-build.lisp"
   :BYTES 247 :DEVICE 16777232 :INODE 1563356330 :MTIME 1793446791 :SHA256
   "ff5cf55dda241d32ea1b4308172c7dc526436cbf1d546e7471148cee95a873d1")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-reader-self-test-4539-0/signal/stderr.log"
   :BYTES 0 :DEVICE 16777232 :INODE 1563356331 :MTIME 1793446791 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-reader-self-test-4539-0/signal/stdout.log"
   :BYTES 126 :DEVICE 16777232 :INODE 1563356332 :MTIME 1793446791 :SHA256
   "3697c68fa71f124c8d05d8cc5d649a744586a10989eb2e67c5bdce6bfc760142")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-snapshot-self-test-4535-0/completion-exit/isolated-build.lisp"
   :BYTES 199 :DEVICE 16777232 :INODE 1563356335 :MTIME 1793446791 :SHA256
   "b8bb4416a818775bae5c77341eeec2c356a2733f633ac2bc8b6ac3ff955d05e0")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-snapshot-self-test-4535-0/completion-exit/stderr.log"
   :BYTES 0 :DEVICE 16777232 :INODE 1563356336 :MTIME 1793446791 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-snapshot-self-test-4535-0/completion-exit/stdout.log"
   :BYTES 107 :DEVICE 16777232 :INODE 1563356337 :MTIME 1793446791 :SHA256
   "4f22544421d9012fe132a36bf15950cd327ca959b8f9c5ef3d386e0c8b62a25c")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-snapshot-self-test-4535-0/report.lisp"
   :BYTES 2015 :DEVICE 16777232 :INODE 1563356338 :MTIME 1793446791 :SHA256
   "69eb61cc319be212167eb6403088e44b32e270cd301108cc5e383cd4a7d9f5e0")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-snapshot-self-test-4535-0/signal/isolated-build.lisp"
   :BYTES 249 :DEVICE 16777232 :INODE 1563356340 :MTIME 1793446791 :SHA256
   "a345276e3dfe377c0bbd359793165915b1527938a65250d367ce5ac079feecc1")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-snapshot-self-test-4535-0/signal/stderr.log"
   :BYTES 0 :DEVICE 16777232 :INODE 1563356341 :MTIME 1793446791 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435017-snapshot-self-test-4535-0/signal/stdout.log"
   :BYTES 128 :DEVICE 16777232 :INODE 1563356342 :MTIME 1793446791 :SHA256
   "e3502e714a0530acb1f0130c4ced4a016607bcb067e3686f6f29704db8423ea5")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/SPK-01.lisp"
   :BYTES 27228 :DEVICE 16777232 :INODE 1563356344 :MTIME 1793446791 :SHA256
   "7f9cdd54457dd06320493267287afa772503cd24c38522648589514f25bcba20")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/SPK-02.lisp"
   :BYTES 1607 :DEVICE 16777232 :INODE 1563356345 :MTIME 1793446791 :SHA256
   "c018d4a2158cfbd22fc6f0070067b86ec44150b3786a665d334ee7ad89e786c9")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/SPK-03.lisp"
   :BYTES 3666 :DEVICE 16777232 :INODE 1563356346 :MTIME 1793446791 :SHA256
   "f6ef7b4c0818bde6e0d0f4aec067b7d61665b1ae026387a1420ebbcaf895c706")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/SPK-04.lisp"
   :BYTES 6752 :DEVICE 16777232 :INODE 1563356347 :MTIME 1793446791 :SHA256
   "339510f5a3b77ed2f85e0ddc379012a080c10452fada695527d9b95b34abd2ac")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/SPK-05.lisp"
   :BYTES 10102 :DEVICE 16777232 :INODE 1563356348 :MTIME 1793446791 :SHA256
   "0c79dc1a804c5f3ab2bb8cfd6487f611fee57cf95536a618220a91ebac7f65bd")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/SPK-06.lisp"
   :BYTES 24090 :DEVICE 16777232 :INODE 1563356349 :MTIME 1793446791 :SHA256
   "91da7ddc6ebb1873fda37906936e60e9764332dbc9486dc0d4fa926697347d97")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/SPK-07.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1563356350 :MTIME 1793446791 :SHA256
   "4faf498f6059a4d87ed630f57602e0adab669c5c57fddddd9ddf8ff567d01bd2")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/SPK-07.lisp.gz"
   :BYTES 411761 :DEVICE 16777232 :INODE 1563356351 :MTIME 1793446791 :SHA256
   "0d25e06aef03980410a0c6b3a2f38c90f60c2e9cb0a2fcaa0a7148ac421d301c")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/SPK-08.lisp"
   :BYTES 319239 :DEVICE 16777232 :INODE 1563356352 :MTIME 1793446791 :SHA256
   "484e99095f54189adabaa7e5db748eee21fccbae314f578b9cb994acd1c590a6")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/SPK-09.lisp"
   :BYTES 2472 :DEVICE 16777232 :INODE 1563356353 :MTIME 1793446791 :SHA256
   "23c684168adc93eae2a7919dd199e55f638f5e29236f6d0852bdd02f583ccc3d")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/SPK-10.lisp"
   :BYTES 22977 :DEVICE 16777232 :INODE 1563356354 :MTIME 1793446791 :SHA256
   "734cd2eee6af5e2248cd3a79d3b79e7aeedb52b7a41c07031643ccf5cff4e863")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/SPK-11.lisp"
   :BYTES 75014 :DEVICE 16777232 :INODE 1563356355 :MTIME 1793446791 :SHA256
   "8cbf71e521e362ccc52e2732b28ebdbbd890090a21e4634a6105f33e1cb1ab4d")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/conservazione.lisp"
   :BYTES 2347 :DEVICE 16777232 :INODE 1563356356 :MTIME 1793446791 :SHA256
   "32d38eb924213e8ff3d9abc45bef636a6079c7d9eb23a6320f7f689ec53f3006")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/report.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1563356357 :MTIME 1793446791 :SHA256
   "dc31576b6d8176903377f0c979204a272e66b4edfd34c30934de357c3e0c82c1")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435387-check-8007-0/report.lisp.gz"
   :BYTES 484195 :DEVICE 16777232 :INODE 1563356358 :MTIME 1793446791 :SHA256
   "0ecc187c7836a64f866eec6b72f2563b5e1702c5fe98ece322e1bd0c54f14c5c")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435449-command-8561-0/conservazione.lisp"
   :BYTES 1181 :DEVICE 16777232 :INODE 1563356360 :MTIME 1793446791 :SHA256
   "1eebbe4f4a42eaf92238383d4aad68a0f7265bd8a4b14ad60dfa8ac6ca29c7bc")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/4002435449-command-8561-0/report.lisp"
   :BYTES 346057 :DEVICE 16777232 :INODE 1563356361 :MTIME 1793446791 :SHA256
   "9e0a65e4b31eaca059a2e55d2267bfb059034e04d01428127ea83628a926ad91")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/ci/selftest-1793446649-8560/boundaries.lisp"
   :BYTES 976 :DEVICE 16777232 :INODE 1563356364 :MTIME 1793446791 :SHA256
   "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/ci/selftest-1793446649-8560/conditions.lisp"
   :BYTES 663 :DEVICE 16777232 :INODE 1563356365 :MTIME 1793446791 :SHA256
   "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/ci/selftest-1793446649-8560/data.lisp"
   :BYTES 3214 :DEVICE 16777232 :INODE 1563356366 :MTIME 1793446791 :SHA256
   "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/ci/selftest-1793446649-8560/measure.lisp"
   :BYTES 2041 :DEVICE 16777232 :INODE 1563356367 :MTIME 1793446791 :SHA256
   "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/ci/selftest-1793446649-8560/publication.lisp"
   :BYTES 1181 :DEVICE 16777232 :INODE 1563356368 :MTIME 1793446791 :SHA256
   "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/ci/selftest-1793446649-8560/report.lisp"
   :BYTES 632 :DEVICE 16777232 :INODE 1563356369 :MTIME 1793446791 :SHA256
   "3bf53e3748c34568e0fb83b9f6f7ed394be5c711a74ca8b7bdde88a45f49bc23")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/ci/selftest-1793446649-8560/tests.lisp"
   :BYTES 2409 :DEVICE 16777232 :INODE 1563356370 :MTIME 1793446791 :SHA256
   "49acae481faadf756a5650f1c389386f54afc7b6e86fca34b8cb0d65726f76e4")
  (:PATH
   "spikes/results/2026-10-31-main-integration/supporting-records/ci/selftest-1793446649-8560/workflow.lisp"
   :BYTES 27784 :DEVICE 16777232 :INODE 1563356371 :MTIME 1793446791 :SHA256
   "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254")
  (:PATH
   "spikes/results/2026-10-31-main-integration/targeted-discovery/conservazione.lisp"
   :BYTES 1181 :DEVICE 16777232 :INODE 1563356373 :MTIME 1793446791 :SHA256
   "7a675aef15fa60d9a6113872e81a7d6b70ed8026898b1472138e78c989208586")
  (:PATH
   "spikes/results/2026-10-31-main-integration/targeted-discovery/report.lisp"
   :BYTES 367319 :DEVICE 16777232 :INODE 1563356374 :MTIME 1793446791 :SHA256
   "4beb7febe454325fa8fab5e64053916b6dbc2b2d5cd5d91b31575cd37dc794ab")
  (:PATH "spikes/results/README.md" :BYTES 837 :DEVICE 16777232 :INODE
   1531364929 :MTIME 1793395837 :SHA256
   "58e0287b3775c0b5955095557d4651e23ebce64f076ebd7f2dc67ec6b2f408e6")
  (:PATH "spikes/results/ci/README.md" :BYTES 597 :DEVICE 16777232 :INODE
   1560932555 :MTIME 1793395837 :SHA256
   "6c22b16e1707a63a4e245bb48d502da8b26e46c5497464e8e30123a7dd87a79d")
  (:PATH
   "spikes/results/ci/by-source/064f2a6b0d4f2d78a9c16a6e126e4231f5694fdcdd500e5a314fae9789b95cd6/runs/38139975047/1/collections/26df537a62ff6263cd81d42203b18efa35d22c8966d3d80bb9d4a2a46cdcdf16/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112873 :MTIME 1793207956 :SHA256
   "84e195718f81a23208c350025b7619d03237694fb9fb408abc5d86401ee5a64e")
  (:PATH
   "spikes/results/ci/by-source/064f2a6b0d4f2d78a9c16a6e126e4231f5694fdcdd500e5a314fae9789b95cd6/runs/38139975047/1/collections/26df537a62ff6263cd81d42203b18efa35d22c8966d3d80bb9d4a2a46cdcdf16/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112874 :MTIME 1793207956 :SHA256
   "9fafb6d5e1b58a2dabf41f099c70c0492343c7dd419cbb6e6de3e885fb4192e5")
  (:PATH
   "spikes/results/ci/by-source/064f2a6b0d4f2d78a9c16a6e126e4231f5694fdcdd500e5a314fae9789b95cd6/runs/38139975047/1/collections/26df537a62ff6263cd81d42203b18efa35d22c8966d3d80bb9d4a2a46cdcdf16/summary.lisp"
   :BYTES 4173 :DEVICE 16777232 :INODE 1560112875 :MTIME 1793207956 :SHA256
   "28495a849827a08e5c89ca2a03effc14c6caf39643930a146f842cb2796523e1")
  (:PATH
   "spikes/results/ci/by-source/064f2a6b0d4f2d78a9c16a6e126e4231f5694fdcdd500e5a314fae9789b95cd6/runs/38139975047/1/collections/9bc70272c3c3ba03adaa6b168af59fd3ab4831b9cfae2ab71173adaa53c5ba33/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112877 :MTIME 1793207956 :SHA256
   "82e137831f4a46385234f0069b57328330351b2ec5e9cae108878051b5244800")
  (:PATH
   "spikes/results/ci/by-source/064f2a6b0d4f2d78a9c16a6e126e4231f5694fdcdd500e5a314fae9789b95cd6/runs/38139975047/1/collections/9bc70272c3c3ba03adaa6b168af59fd3ab4831b9cfae2ab71173adaa53c5ba33/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112878 :MTIME 1793207956 :SHA256
   "9fafb6d5e1b58a2dabf41f099c70c0492343c7dd419cbb6e6de3e885fb4192e5")
  (:PATH
   "spikes/results/ci/by-source/064f2a6b0d4f2d78a9c16a6e126e4231f5694fdcdd500e5a314fae9789b95cd6/runs/38139975047/1/collections/9bc70272c3c3ba03adaa6b168af59fd3ab4831b9cfae2ab71173adaa53c5ba33/summary.lisp"
   :BYTES 4179 :DEVICE 16777232 :INODE 1560112879 :MTIME 1793207956 :SHA256
   "c94aff2960d53da0e219cef9de11f67bea7e83cce01fd4324e5ca962edca0478")
  (:PATH
   "spikes/results/ci/by-source/064f2a6b0d4f2d78a9c16a6e126e4231f5694fdcdd500e5a314fae9789b95cd6/runs/38139975047/1/publications/6fbad49cb4000aaa45bf3f1ec0d8ad1e763994be1429e84e895b10991c291185.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560112881 :MTIME 1793207956 :SHA256
   "3c221150ed3e0435fbcdbc7f7583270a9469d21f091f7403527ad9e6d4c8a478")
  (:PATH
   "spikes/results/ci/by-source/064f2a6b0d4f2d78a9c16a6e126e4231f5694fdcdd500e5a314fae9789b95cd6/runs/38139975047/1/publications/ac48476554833d16c37f85279a0a8543b336572e142295fedc329f1410689199.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560112883 :MTIME 1793207956 :SHA256
   "7a8e682dce0c094da57066352a3abe1f2d7423ce785cd3a2bb671fbed7a4d17e")
  (:PATH
   "spikes/results/ci/by-source/07563ef3efd383abbec360f14972c61db6498eb1d3227e5016a8faac82fb29f1/runs/38778972983/1/collections/b852164302e190bea178ddb55818b2f0f4d97b577223307ba82d3eb103220207/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112890 :MTIME 1793207956 :SHA256
   "b42d88fbeaf355961192de4bc603fb0acd10359b42389c698531abd239bb56fc")
  (:PATH
   "spikes/results/ci/by-source/07563ef3efd383abbec360f14972c61db6498eb1d3227e5016a8faac82fb29f1/runs/38778972983/1/collections/b852164302e190bea178ddb55818b2f0f4d97b577223307ba82d3eb103220207/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112891 :MTIME 1793207956 :SHA256
   "78865d293dd962af19a0d4b0cc67224c16edea35cd1a4c67bb711606f66948cd")
  (:PATH
   "spikes/results/ci/by-source/07563ef3efd383abbec360f14972c61db6498eb1d3227e5016a8faac82fb29f1/runs/38778972983/1/collections/b852164302e190bea178ddb55818b2f0f4d97b577223307ba82d3eb103220207/summary.lisp"
   :BYTES 4969 :DEVICE 16777232 :INODE 1560112892 :MTIME 1793207956 :SHA256
   "6530d9a5fbefed80e6276d0af180171beb98548a5cb24654b04328139a12f340")
  (:PATH
   "spikes/results/ci/by-source/07563ef3efd383abbec360f14972c61db6498eb1d3227e5016a8faac82fb29f1/runs/38778972983/1/collections/ffa8415358436f8960e2dbcb058164625b4ce3525fca533781cd51e0ee4a9240/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112894 :MTIME 1793207956 :SHA256
   "694b293fa8fa331321b28c225b2be1c91dd5f2dfd7619bf422ff76334cbbe429")
  (:PATH
   "spikes/results/ci/by-source/07563ef3efd383abbec360f14972c61db6498eb1d3227e5016a8faac82fb29f1/runs/38778972983/1/collections/ffa8415358436f8960e2dbcb058164625b4ce3525fca533781cd51e0ee4a9240/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112895 :MTIME 1793207956 :SHA256
   "78865d293dd962af19a0d4b0cc67224c16edea35cd1a4c67bb711606f66948cd")
  (:PATH
   "spikes/results/ci/by-source/07563ef3efd383abbec360f14972c61db6498eb1d3227e5016a8faac82fb29f1/runs/38778972983/1/collections/ffa8415358436f8960e2dbcb058164625b4ce3525fca533781cd51e0ee4a9240/summary.lisp"
   :BYTES 4963 :DEVICE 16777232 :INODE 1560112896 :MTIME 1793207956 :SHA256
   "9b3e91583e0e0eaa2b1d3e3d12a8f7184de3e0e0bbbb0d9b863b257759482134")
  (:PATH
   "spikes/results/ci/by-source/07563ef3efd383abbec360f14972c61db6498eb1d3227e5016a8faac82fb29f1/runs/38778972983/1/publications/008a1b69736bf256069897ea7beabfb18bc31dbe96f99178c914bdf2dc0cdb28.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560112898 :MTIME 1793207956 :SHA256
   "7652332d95677414d1c076a3f5004037b32a14472e95c055f43901e581703030")
  (:PATH
   "spikes/results/ci/by-source/07563ef3efd383abbec360f14972c61db6498eb1d3227e5016a8faac82fb29f1/runs/38778972983/1/publications/213e8a46c924595394e0e71d4748e589953a23a913a5469cac56fb4c355f96ed.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560112899 :MTIME 1793207956 :SHA256
   "1b31de065dbad0b8eabcb7f0ed771fd7e0c9a44e4c55761fb3b4453000eb53bd")
  (:PATH
   "spikes/results/ci/by-source/09f604351edce38e2ac628f65d09ab083c22f5f07ae633a81c2d2ca81ac4f0c7/runs/38942929521/1/collections/0902139464c64d2214f35a8178b9e278e7ec0a026416d167f126d308b48187f6/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112906 :MTIME 1793207956 :SHA256
   "785e9b5f490ea90f4c266e662ddb73dcb45f2a5435542df1e4d0fa9e8b0da30f")
  (:PATH
   "spikes/results/ci/by-source/09f604351edce38e2ac628f65d09ab083c22f5f07ae633a81c2d2ca81ac4f0c7/runs/38942929521/1/collections/0902139464c64d2214f35a8178b9e278e7ec0a026416d167f126d308b48187f6/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112907 :MTIME 1793207956 :SHA256
   "224bdcce6e856fcc05e315daf7f5aa39ef50fc725dd8884e972a92b7a0dc04e4")
  (:PATH
   "spikes/results/ci/by-source/09f604351edce38e2ac628f65d09ab083c22f5f07ae633a81c2d2ca81ac4f0c7/runs/38942929521/1/collections/0902139464c64d2214f35a8178b9e278e7ec0a026416d167f126d308b48187f6/summary.lisp"
   :BYTES 5593 :DEVICE 16777232 :INODE 1560112908 :MTIME 1793207956 :SHA256
   "8d0a2b95461725a30177f2c9609a5df848cb81139de8b4d6583790bf2a06fc59")
  (:PATH
   "spikes/results/ci/by-source/09f604351edce38e2ac628f65d09ab083c22f5f07ae633a81c2d2ca81ac4f0c7/runs/38942929521/1/publications/5d90231f03012c9c9b1fddb2f920b1dc36a88e2f56d13d8d3818237e204c5ff3.lisp"
   :BYTES 725 :DEVICE 16777232 :INODE 1560112910 :MTIME 1793207956 :SHA256
   "e0e3c923fbc3b335d8db1b003a6362e0eedc2b17572a56ff2f1797a30d9c3590")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38472487059/1/collections/6b18d7d7f8eea783d44b68a22196c70d7140193135c93d3a9eb677c1acb732c6/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112917 :MTIME 1793207956 :SHA256
   "d6e057603421fd68e7685747c0fbe1db4c2eaee7fc9494256a39a38ffce438f5")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38472487059/1/collections/6b18d7d7f8eea783d44b68a22196c70d7140193135c93d3a9eb677c1acb732c6/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112918 :MTIME 1793207956 :SHA256
   "0519db3b0d27f89086ccc880e1ef8831905060cf4d0de96128f8ee1ec85f8ddb")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38472487059/1/collections/6b18d7d7f8eea783d44b68a22196c70d7140193135c93d3a9eb677c1acb732c6/summary.lisp"
   :BYTES 4702 :DEVICE 16777232 :INODE 1560112919 :MTIME 1793207956 :SHA256
   "cee7bf567dfb7c2a2c1e8b457e8b49c8d10a60600b878efe2949baa7f989dc77")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38472487059/1/collections/9c6c56ba2dc50ed293f741a83bca80dfdcf03bcd91304d7fef5ce5bf9fa674cd/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112921 :MTIME 1793207956 :SHA256
   "3d27a065569e28e80f510e2bf74cba5b8905cb847c47b71c4edba608577427a7")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38472487059/1/collections/9c6c56ba2dc50ed293f741a83bca80dfdcf03bcd91304d7fef5ce5bf9fa674cd/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112922 :MTIME 1793207956 :SHA256
   "0519db3b0d27f89086ccc880e1ef8831905060cf4d0de96128f8ee1ec85f8ddb")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38472487059/1/collections/9c6c56ba2dc50ed293f741a83bca80dfdcf03bcd91304d7fef5ce5bf9fa674cd/summary.lisp"
   :BYTES 4708 :DEVICE 16777232 :INODE 1560112923 :MTIME 1793207956 :SHA256
   "9fd098019a18db7e026c3ceb31bfb5d7d05c3b117784297ccbc61d9a6455a944")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38472487059/1/publications/ac601d851f1dcbaa9e6fb5f96ef8e302098e07533c0d26ca8c5d27ffdaee5fd5.lisp"
   :BYTES 731 :DEVICE 16777232 :INODE 1560112925 :MTIME 1793207956 :SHA256
   "589adca5ce906c83062479f5175a12afe893edd7f44aa7a4f100ed0d12de6104")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38472487059/1/publications/b9fe07995983183e4da7026c38dcf1e671b9b2ddbd7f7a139bb2884569717c56.lisp"
   :BYTES 728 :DEVICE 16777232 :INODE 1560112926 :MTIME 1793207956 :SHA256
   "b6aaecc99fae79e041334194b7f68a579d8d2cea266dbe0cbd3835453b33463f")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38474157865/1/collections/56efb98690f00c1f0e6c7ae7ed08acd024614874d5ce0b293d4fb9608a4e5111/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112931 :MTIME 1793207956 :SHA256
   "799e6af165bae15a6895da87770d5d6512b232d27e315e5c01d425f0512a1fc7")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38474157865/1/collections/56efb98690f00c1f0e6c7ae7ed08acd024614874d5ce0b293d4fb9608a4e5111/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112932 :MTIME 1793207956 :SHA256
   "b14b3b0ebfcd5bd28ea826210ef07ac319f134b62b4a1cd345acdf29f3e8b57c")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38474157865/1/collections/56efb98690f00c1f0e6c7ae7ed08acd024614874d5ce0b293d4fb9608a4e5111/summary.lisp"
   :BYTES 4663 :DEVICE 16777232 :INODE 1560112933 :MTIME 1793207956 :SHA256
   "45d2d9ee1d648ae2e6da9f75cb21187e02b5611b452641eeebb32d10471b82a6")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38474157865/1/collections/92a3f1c79e9e1134027bedec3bda241c9dac8015f3531a0143a1640498822d61/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112935 :MTIME 1793207956 :SHA256
   "8494ef5cfa08e982ec554b133e266a7d2b645890c09cd01f81b9a36f16ca64fe")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38474157865/1/collections/92a3f1c79e9e1134027bedec3bda241c9dac8015f3531a0143a1640498822d61/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112936 :MTIME 1793207956 :SHA256
   "b14b3b0ebfcd5bd28ea826210ef07ac319f134b62b4a1cd345acdf29f3e8b57c")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38474157865/1/collections/92a3f1c79e9e1134027bedec3bda241c9dac8015f3531a0143a1640498822d61/summary.lisp"
   :BYTES 4657 :DEVICE 16777232 :INODE 1560112937 :MTIME 1793207956 :SHA256
   "8d84ffcf2f73730db1ca3c0934875524106e50d0f5b297d69a944cb78d8c8b50")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38474157865/1/publications/b78aed7d5528f994df541f6b43cc751a7b303d963a2b8af14d7db97f19256011.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560112939 :MTIME 1793207956 :SHA256
   "14b5da8e6bf13994e7c3c74026d4d1591cd9727cef9928580a694cb5542d518e")
  (:PATH
   "spikes/results/ci/by-source/0f5cb8f0af871f41b393076b12a4dc6b98b10132b6f8369121d242c3412de084/runs/38474157865/1/publications/bcacbf7773aaa5e43cef549c278e0cd6f5eb1f99897dbfc78427668df383c754.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560112940 :MTIME 1793207956 :SHA256
   "0db0f98a54426dabbc89f6b9b4d34a98f681ab4e324eef8e9cf3642b5aca04da")
  (:PATH
   "spikes/results/ci/by-source/1135e7e57960593be8d0e479397cc569670129236e35d6e5c31bbcefd7f8f0d9/runs/38463450630/1/collections/7c73fb12df0d8c1bbf14c527a3427435df539a91171454058c89dc1319ea5c8b/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112947 :MTIME 1793207956 :SHA256
   "c1544a53c48cc66854d30e7fd42a038430fc2c2b2e0e7e6fffb083705b40bc6f")
  (:PATH
   "spikes/results/ci/by-source/1135e7e57960593be8d0e479397cc569670129236e35d6e5c31bbcefd7f8f0d9/runs/38463450630/1/collections/7c73fb12df0d8c1bbf14c527a3427435df539a91171454058c89dc1319ea5c8b/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112948 :MTIME 1793207956 :SHA256
   "c5dbdee2cb35961c983b20778a0190d77cbd97c0a8cbb490030ca0226c3b696b")
  (:PATH
   "spikes/results/ci/by-source/1135e7e57960593be8d0e479397cc569670129236e35d6e5c31bbcefd7f8f0d9/runs/38463450630/1/collections/7c73fb12df0d8c1bbf14c527a3427435df539a91171454058c89dc1319ea5c8b/summary.lisp"
   :BYTES 4565 :DEVICE 16777232 :INODE 1560112949 :MTIME 1793207956 :SHA256
   "1c37f971ba236e12fe422468e33f49245ff26116ad4eccb19ebb219d275c61f3")
  (:PATH
   "spikes/results/ci/by-source/1135e7e57960593be8d0e479397cc569670129236e35d6e5c31bbcefd7f8f0d9/runs/38463450630/1/collections/8376e408e9f4ac81706d395c8fe52926be47ae84e4aa78615ea1aac11366c6db/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112951 :MTIME 1793207956 :SHA256
   "59f481c70e768efc656b81356cac42131e0e233f56478e7dc8f8e2091e29ffc6")
  (:PATH
   "spikes/results/ci/by-source/1135e7e57960593be8d0e479397cc569670129236e35d6e5c31bbcefd7f8f0d9/runs/38463450630/1/collections/8376e408e9f4ac81706d395c8fe52926be47ae84e4aa78615ea1aac11366c6db/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112952 :MTIME 1793207956 :SHA256
   "c5dbdee2cb35961c983b20778a0190d77cbd97c0a8cbb490030ca0226c3b696b")
  (:PATH
   "spikes/results/ci/by-source/1135e7e57960593be8d0e479397cc569670129236e35d6e5c31bbcefd7f8f0d9/runs/38463450630/1/collections/8376e408e9f4ac81706d395c8fe52926be47ae84e4aa78615ea1aac11366c6db/summary.lisp"
   :BYTES 4571 :DEVICE 16777232 :INODE 1560112953 :MTIME 1793207956 :SHA256
   "edbfc8457d41b221de1ad9a5d749063913a1537ce019632b8f237727901fca3f")
  (:PATH
   "spikes/results/ci/by-source/1135e7e57960593be8d0e479397cc569670129236e35d6e5c31bbcefd7f8f0d9/runs/38463450630/1/publications/5bd21808e1f2e6f2331c29932564ba2a4c16756195c548b906a7762e2312f868.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560112955 :MTIME 1793207956 :SHA256
   "aff7856827c3c8ec8bf032f8342401ae826e0176239c9b7d91023fc6eede8d2b")
  (:PATH
   "spikes/results/ci/by-source/1135e7e57960593be8d0e479397cc569670129236e35d6e5c31bbcefd7f8f0d9/runs/38463450630/1/publications/aad3cfe295d509ed086393c015ba397cba89f949cfd12d84b1f5e7e42091560f.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560112956 :MTIME 1793207956 :SHA256
   "c0e56196383b70acafebaa05b3bff18dee11e38accd093c1adb2cf3d3962fa96")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/collections/a4d5d6dfce1bb868e3dab6dfc7bfc4d5db4063148f15a6710ffd8f6d4e562fac/manifest.lisp"
   :BYTES 393 :DEVICE 16777232 :INODE 1555495310 :MTIME 1792777714 :SHA256
   "aa673f88906863e714da5755e3b949c20802adf65501b3acbdb51530a6a83aa4")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/collections/a4d5d6dfce1bb868e3dab6dfc7bfc4d5db4063148f15a6710ffd8f6d4e562fac/report.md"
   :BYTES 21824 :DEVICE 16777232 :INODE 1555495311 :MTIME 1792777714 :SHA256
   "454ed597aec0ec7c1ce0547ec41bf201e94fd3ebe208c240cd66e9359376b221")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/collections/a4d5d6dfce1bb868e3dab6dfc7bfc4d5db4063148f15a6710ffd8f6d4e562fac/summary.lisp"
   :BYTES 27453 :DEVICE 16777232 :INODE 1555495312 :MTIME 1792777714 :SHA256
   "f290744d7cdc3d4814c89c826523e3a1c4d0bfa4c31d782fa3797887d0b4345d")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/manifest.lisp"
   :BYTES 9821 :DEVICE 16777232 :INODE 1555495316 :MTIME 1792777714 :SHA256
   "c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/c4-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1555495318 :MTIME 1792777714 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/c4-driver.stdout"
   :BYTES 113 :DEVICE 16777232 :INODE 1555495319 :MTIME 1792777714 :SHA256
   "accd85553cd1ff9661f469aea44b19c522417e9036085e7a8fa23a1a4f2649c0")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/child-result.lisp"
   :BYTES 3313 :DEVICE 16777232 :INODE 1555495320 :MTIME 1792777714 :SHA256
   "e42950cc164b7459889980b5daf78081fce4f96ef9d8b678a3d58f91e53d05c6")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/c4/conservazione.lisp"
   :BYTES 1085 :DEVICE 16777232 :INODE 1555495323 :MTIME 1792777714 :SHA256
   "32ec4256b9d2a805a8c2c3f15bcbcd03e53802af3104602c75ab3f802b70413b")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/c4/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1555495324 :MTIME 1792777714 :SHA256
   "332e36a9de0d0e4f98fcc63257d482cae4cea48c0ed972bb69f870ac875e31ca")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/c4/report.lisp.gz"
   :BYTES 103451 :DEVICE 16777232 :INODE 1555495325 :MTIME 1792777714 :SHA256
   "a917313dbd3f5b181ee5690bdc0f9d06cfba4eb2605acc716ba2d7b411e8629c")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/job/conservazione.lisp"
   :BYTES 1087 :DEVICE 16777232 :INODE 1555495327 :MTIME 1792777714 :SHA256
   "08716813e52cddb913e964fb9a72e89e5ea7a20d085c63e4f6d4256789934b2c")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1555495328 :MTIME 1792777714 :SHA256
   "f39fa191edfaeadc5b3dbebe1c9626c4fdc45c4cfbb581db81afdccc3cb2c394")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/job/report.lisp.gz"
   :BYTES 92190 :DEVICE 16777232 :INODE 1555495329 :MTIME 1792777714 :SHA256
   "97915c3067c043693e2378bde0b26fb79f6fcffe0d43a341f24b09d2a5c7cb90")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/links/conservazione.lisp"
   :BYTES 1091 :DEVICE 16777232 :INODE 1555495331 :MTIME 1792777714 :SHA256
   "71378af6858135be5b7fadfd270d325ff25584e713f5cb938f2442ba330908d3")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/links/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1555495332 :MTIME 1792777714 :SHA256
   "4e24403ec0ef9edb404eca431a2ef8ea48d38394cae7cfc4aa02e0cb12933c75")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/links/report.lisp.gz"
   :BYTES 92178 :DEVICE 16777232 :INODE 1555495333 :MTIME 1792777714 :SHA256
   "f9a79ce0e7178fc745191b3401d75be8788cf62692c82475dca2742dccd29f45")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/lint/conservazione.lisp"
   :BYTES 1089 :DEVICE 16777232 :INODE 1555495335 :MTIME 1792777714 :SHA256
   "d12d5c29931f58b92dde97bdbf55205977cbeccfe0d1eb9364b255ca9b3bb6f1")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/lint/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1555495336 :MTIME 1792777714 :SHA256
   "a1241da75b58aa972360d9cfd983c02872c868c1a08126b5030a6159b6def728")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/lint/report.lisp.gz"
   :BYTES 92171 :DEVICE 16777232 :INODE 1555495337 :MTIME 1792777714 :SHA256
   "dc105d23114fd3e87d51ecdedf24b7e29f4ab20737cab36fe7dffe44bdbe1305")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/trace/conservazione.lisp"
   :BYTES 1091 :DEVICE 16777232 :INODE 1555495339 :MTIME 1792777714 :SHA256
   "95950a2ed65dd50e60fd1d02f31906b9601819c0413ea8257e37056587c34a2e")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/trace/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1555495340 :MTIME 1792777714 :SHA256
   "596d0ff5004be64bdfd64e24c86b538d910440b17dc0f793b6c5e9b79d28c3cc")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/commands/trace/report.lisp.gz"
   :BYTES 92193 :DEVICE 16777232 :INODE 1555495341 :MTIME 1792777714 :SHA256
   "4a4a104cd30b6a42fff28d750170deb3119f9fc170db348900728d19053e3569")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1555495342 :MTIME 1792777714 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1555495343 :MTIME 1792777714 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/job-driver.stdout"
   :BYTES 375 :DEVICE 16777232 :INODE 1555495344 :MTIME 1792777714 :SHA256
   "1463ddf43fb2ac11f178d497d06aee6d2f752e148a4c3bb718178e67c18d0cc5")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/links-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1555495345 :MTIME 1792777714 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/links-driver.stdout"
   :BYTES 321 :DEVICE 16777232 :INODE 1555495346 :MTIME 1792777714 :SHA256
   "d9b191e07ebd090cf5d0fd914520d4fa285faa4df1cf24d4fc88328677c81540")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/links.lisp"
   :BYTES 181 :DEVICE 16777232 :INODE 1555495347 :MTIME 1792777714 :SHA256
   "24898481f7c5574165e2e16d653f7fdae29ba6797f0174086a3a057135080475")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/lint-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1555495348 :MTIME 1792777714 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/lint-driver.stdout"
   :BYTES 314 :DEVICE 16777232 :INODE 1555495349 :MTIME 1792777714 :SHA256
   "5846d96850dc2778fa9b809dad5c4c0ebb099831d89e397071bade80a188eb33")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/lint.lisp"
   :BYTES 354 :DEVICE 16777232 :INODE 1555495350 :MTIME 1792777714 :SHA256
   "103da9fb065b5447dcc76d63f7cff1252731f1b92be3b4e3b348f9a9b56110c8")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/trace-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1555495351 :MTIME 1792777714 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/trace-driver.stdout"
   :BYTES 319 :DEVICE 16777232 :INODE 1555495352 :MTIME 1792777714 :SHA256
   "038065b7e5cfdf9b49deaff6f8759cfd40cebdb25c85041b96d10e66410b420d")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/raw/trace.lisp"
   :BYTES 1607 :DEVICE 16777232 :INODE 1555495353 :MTIME 1792777714 :SHA256
   "cbe1c7d10b0eb871d77cf9c98e7180eb4ac38d23ee1cd3ac4dc9ee5b3451909e")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/audit/c9c1a6edac28217545ba0e42c5eaed54673555fcc6f9f131a0aab589771f1cb6/result.lisp"
   :BYTES 8711 :DEVICE 16777232 :INODE 1555495354 :MTIME 1792777714 :SHA256
   "166ac2342ff949b9a308b1deaedfef35d0629dbf808f904c04b55abd6811f034")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/manifest.lisp"
   :BYTES 7851 :DEVICE 16777232 :INODE 1555495357 :MTIME 1792777714 :SHA256
   "1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/child-result.lisp"
   :BYTES 25141 :DEVICE 16777232 :INODE 1555495359 :MTIME 1792777714 :SHA256
   "eb84afc2cc1a825be1e92538036406d1670f0218f70d2bc55330d8eacbfc3e75")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/commands/job/conservazione.lisp"
   :BYTES 1087 :DEVICE 16777232 :INODE 1555495362 :MTIME 1792777714 :SHA256
   "4ee91fb47baade04c67be83086b41236ed9dfbeacce9cfb002343aeed6a4aedc")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1555495363 :MTIME 1792777714 :SHA256
   "51b3f8c3ccfa6e908ff01e757813d23f505d2f8f794786b72a1ad19523fb99f9")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/commands/job/report.lisp.gz"
   :BYTES 92185 :DEVICE 16777232 :INODE 1555495364 :MTIME 1792777714 :SHA256
   "05c55fec0e18d4b37a838215d45c68aca65ba137db1e1aa577604470300e11e6")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/coordinator-identity.lisp"
   :BYTES 212 :DEVICE 16777232 :INODE 1555495365 :MTIME 1792777714 :SHA256
   "5a0c056154b2fb8b9b078761b498fbe41732ee9e42353c72263bd69362403894")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1555495366 :MTIME 1792777714 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1555495367 :MTIME 1792777714 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/job-driver.stdout"
   :BYTES 375 :DEVICE 16777232 :INODE 1555495368 :MTIME 1792777714 :SHA256
   "fa34e2f7798a393a89dffa0aa64529f59552e4c3e9eb5109fee22bf2b0079d58")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/measure-replica-01.lisp"
   :BYTES 2111 :DEVICE 16777232 :INODE 1555495369 :MTIME 1792777714 :SHA256
   "045cbf05e905c58e79decfa0d1534e7461712b56bff46392d3e9d193d8a14e6e")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/measure-replica-01.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1555495370 :MTIME 1792777714 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/measure-replica-02.lisp"
   :BYTES 2110 :DEVICE 16777232 :INODE 1555495371 :MTIME 1792777714 :SHA256
   "fe29a28af8b30e8c24a1d71ff9e0876d281e2971272317cdad044885fbb06c7b")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/measure-replica-02.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1555495372 :MTIME 1792777714 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/measure-replica-03.lisp"
   :BYTES 2119 :DEVICE 16777232 :INODE 1555495373 :MTIME 1792777714 :SHA256
   "34ce56fd36a53740fc99723742c10e926de1fa01971441a848fc27c3e567364e")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/measure-replica-03.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1555495374 :MTIME 1792777714 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/measure-replica-04.lisp"
   :BYTES 2110 :DEVICE 16777232 :INODE 1555495375 :MTIME 1792777714 :SHA256
   "02dc842ae36fc10061edadfaf3b256f3cfbc75a68d17454c3b7affcbe7995d4a")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/measure-replica-04.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1555495376 :MTIME 1792777714 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/measure-replica-05.lisp"
   :BYTES 2111 :DEVICE 16777232 :INODE 1555495377 :MTIME 1792777714 :SHA256
   "e83bce7b4156a62888fac46e951dcb5241f4214a23da3e2a77331550a79a7d03")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/measure-replica-05.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1555495378 :MTIME 1792777714 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/raw/measure.lisp"
   :BYTES 25141 :DEVICE 16777232 :INODE 1555495379 :MTIME 1792777714 :SHA256
   "eb84afc2cc1a825be1e92538036406d1670f0218f70d2bc55330d8eacbfc3e75")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/bench/1758b7a316c58b804fbf9c77ad68bfbc3fb8e4da5feabde9dc2f879a6ed21fc8/result.lisp"
   :BYTES 18484 :DEVICE 16777232 :INODE 1555495380 :MTIME 1792777714 :SHA256
   "c3b9bbcce98d3372ae9de30ef1f8c0aa36ae7f95eed6f847fff0dc071f52fb32")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/manifest.lisp"
   :BYTES 7080 :DEVICE 16777232 :INODE 1555495383 :MTIME 1792777714 :SHA256
   "d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/raw/child-result.lisp"
   :BYTES 140 :DEVICE 16777232 :INODE 1555495385 :MTIME 1792777714 :SHA256
   "22824bfedad9bffeaa12cb19cec7a38349d3ad8bef65180d8948318d468040c0")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/raw/commands/job/conservazione.lisp"
   :BYTES 1093 :DEVICE 16777232 :INODE 1555495388 :MTIME 1792777714 :SHA256
   "093e741c8ac4ece1c1ba67b635b6d02b9dfc54d536f7dce3bcccfd3906883862")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1555495389 :MTIME 1792777714 :SHA256
   "080e094b5c675bc3992b607c90a844d855915542d09fc869ef5b8f0d2069880a")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/raw/commands/job/report.lisp.gz"
   :BYTES 92252 :DEVICE 16777232 :INODE 1555495390 :MTIME 1792777714 :SHA256
   "e62949ecffabf1cc5a1d56ab0533fa3eec801d5b8ce4dca05a19aadaac950c20")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/raw/coverage.expected.lisp"
   :BYTES 52816 :DEVICE 16777232 :INODE 1555495391 :MTIME 1792777714 :SHA256
   "fe7db2e1968d47efe33bc538e4795d68b6e379b154182e285a77eac4eeaeb76b")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/raw/coverage.stderr.log"
   :BYTES 320 :DEVICE 16777232 :INODE 1555495392 :MTIME 1792777714 :SHA256
   "f9de4e53212209e6fe8d726ed2e26a6a6426fbb7fec14462244111f8c38c9913")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/raw/coverage.stderr.log.gz"
   :BYTES 136784 :DEVICE 16777232 :INODE 1555495393 :MTIME 1792777714 :SHA256
   "1d43a6ed4d3a9dd3af857a656afbe9e10b8d34846bef30c3f7a7d51eeaeb1679")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/raw/coverage.stdout.log"
   :BYTES 318 :DEVICE 16777232 :INODE 1555495394 :MTIME 1792777714 :SHA256
   "88c9bdcc6481629d15d5ebfa497022b4813a78cd15c531bb20a94b99f15cb5e5")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/raw/coverage.stdout.log.gz"
   :BYTES 13840 :DEVICE 16777232 :INODE 1555495395 :MTIME 1792777714 :SHA256
   "b605a2f8a9461e797aac17de1777df976b7cf117350c8040ec8ba5f13fb426e7")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1555495396 :MTIME 1792777714 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1555495397 :MTIME 1792777714 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/raw/job-driver.stdout"
   :BYTES 388 :DEVICE 16777232 :INODE 1555495398 :MTIME 1792777714 :SHA256
   "0bdb10bbfc1eacef9af43cde2296a7d59cafa959b877f81be5cba4f227aae5e4")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/coverage/d469c0b1849a45a40ba78724e8b8265111cbf55f6697ab843a673cdc4964e981/result.lisp"
   :BYTES 5585 :DEVICE 16777232 :INODE 1555495399 :MTIME 1792777714 :SHA256
   "cb399b60c16ab36a360ec766ce5c4cf60b329a93ce57f87ba7972872913e827f")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/plan/b53db3971257cbcbf79241ee1fb5ea535e6afd4727cb6e0a9ace598c58693a2b/manifest.lisp"
   :BYTES 5345 :DEVICE 16777232 :INODE 1555495402 :MTIME 1792777714 :SHA256
   "b53db3971257cbcbf79241ee1fb5ea535e6afd4727cb6e0a9ace598c58693a2b")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/plan/b53db3971257cbcbf79241ee1fb5ea535e6afd4727cb6e0a9ace598c58693a2b/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1555495404 :MTIME 1792777714 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/plan/b53db3971257cbcbf79241ee1fb5ea535e6afd4727cb6e0a9ace598c58693a2b/raw/sources.lisp"
   :BYTES 4738 :DEVICE 16777232 :INODE 1555495405 :MTIME 1792777714 :SHA256
   "6ad9938244a765efb60b468db6f871cf9f7c875a7f3f7638d17761ade5acbc8a")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/plan/b53db3971257cbcbf79241ee1fb5ea535e6afd4727cb6e0a9ace598c58693a2b/result.lisp"
   :BYTES 9725 :DEVICE 16777232 :INODE 1555495406 :MTIME 1792777714 :SHA256
   "4c43b691a94e870026d1d6601e6365ffd068de26072699c425541b3a87a0cb65")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/manifest.lisp"
   :BYTES 7305 :DEVICE 16777232 :INODE 1555495409 :MTIME 1792777714 :SHA256
   "b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/raw/child-result.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1555495411 :MTIME 1792777714 :SHA256
   "e7850cd4feb003b2133cd845f5ef4cc18a0c123e7b7d282b274dc2a8b69354a7")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/raw/child-result.lisp.gz"
   :BYTES 53567 :DEVICE 16777232 :INODE 1555495412 :MTIME 1792777714 :SHA256
   "0003cd964ba296c58af863732010155b5cc5abd8a2be198cf25b1fcecae5f5f8")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/raw/commands/job/conservazione.lisp"
   :BYTES 1101 :DEVICE 16777232 :INODE 1555495415 :MTIME 1792777714 :SHA256
   "46d40864a30667d369cfdc22bc0ab38ffc72d768efa3607230bd8f21d15b9aa3")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/raw/commands/job/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1555495416 :MTIME 1792777714 :SHA256
   "d94d0690eae0fcd73312fc256b0690eebb47e6f1198461051eeb4930b0096023")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/raw/commands/job/report.lisp.gz"
   :BYTES 133332 :DEVICE 16777232 :INODE 1555495417 :MTIME 1792777714 :SHA256
   "391b1d0b81f96115e99b91a05a799a84ebd107f5889f70c15d852fd08c0ad0eb")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1555495418 :MTIME 1792777714 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1555495419 :MTIME 1792777714 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/raw/job-driver.stdout"
   :BYTES 400 :DEVICE 16777232 :INODE 1555495420 :MTIME 1792777714 :SHA256
   "627c21cb33a11cdd76ce8397e2c758f2d8a3a3053b4f2b209a35d83eb0540a43")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/raw/tests.events.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1555495421 :MTIME 1792777714 :SHA256
   "0b29ed0629db7599917ad78482aac20288088ab744e7281b169e61350eb04b7f")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/raw/tests.events.lisp.gz"
   :BYTES 111611 :DEVICE 16777232 :INODE 1555495422 :MTIME 1792777714 :SHA256
   "89f8e480e8afb8b6afe5680963be772ea0758dd0acdd61d084ca1d680ea7521c")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/raw/tests.expected.lisp"
   :BYTES 8542 :DEVICE 16777232 :INODE 1555495423 :MTIME 1792777714 :SHA256
   "94f5e4a477fb6bfb88edc79d530e950a672ab87c856de45be52b367ab091c963")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/raw/tests.lisp"
   :BYTES 309 :DEVICE 16777232 :INODE 1555495424 :MTIME 1792777714 :SHA256
   "21dccae0f7e7a59ae1163e2fa912429dc8f29c4601ec63b8c35fe27e256d7901")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/raw/tests.lisp.gz"
   :BYTES 53567 :DEVICE 16777232 :INODE 1555495425 :MTIME 1792777714 :SHA256
   "0003cd964ba296c58af863732010155b5cc5abd8a2be198cf25b1fcecae5f5f8")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-linux/b1f0a95d4ad41e939ccea712169fcd2ab7489abf81fb4c5a59843dbf6a8e3950/result.lisp"
   :BYTES 5575 :DEVICE 16777232 :INODE 1555495426 :MTIME 1792777714 :SHA256
   "2d77f5bc5dd1b5907cb47fe77f687759caa28a7a7ee6ea32853da60969fbca10")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/manifest.lisp"
   :BYTES 7306 :DEVICE 16777232 :INODE 1555495429 :MTIME 1792777714 :SHA256
   "99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/raw/child-result.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1555495431 :MTIME 1792777714 :SHA256
   "358358564f94eed2427b723afc7b3ac0d16331630cf674eeb2651d01f458eaae")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/raw/child-result.lisp.gz"
   :BYTES 59462 :DEVICE 16777232 :INODE 1555495432 :MTIME 1792777714 :SHA256
   "a52746fc741242a3350974d79e1d153ddc09f5c662563eaf976b500979320bc9")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/raw/commands/job/conservazione.lisp"
   :BYTES 1106 :DEVICE 16777232 :INODE 1555495435 :MTIME 1792777714 :SHA256
   "c5e62e3cb7fef39d944434c4139579fcf2e0cda7af3826455664e68d5935af00")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/raw/commands/job/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1555495436 :MTIME 1792777714 :SHA256
   "488075c96ce8c45712a4444c39e7d7f2346fe8d13b0cebfbaa76ceb5d1a96f61")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/raw/commands/job/report.lisp.gz"
   :BYTES 134134 :DEVICE 16777232 :INODE 1555495437 :MTIME 1792777714 :SHA256
   "029df21d7d51e4bcd087f6202324a4366bba466e3671ba519b256c92745a14f6")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/raw/installation.lisp"
   :BYTES 593 :DEVICE 16777232 :INODE 1555495438 :MTIME 1792777714 :SHA256
   "23ef06a51e40c0fabcaa6d55cd55b3877a11e2ffb04a85f89e935198864224ca")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1555495439 :MTIME 1792777714 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/raw/job-driver.stdout"
   :BYTES 404 :DEVICE 16777232 :INODE 1555495440 :MTIME 1792777714 :SHA256
   "5fe47584a68bbba5b850fcbcb7ef916aa81169cd2282e914db413aa34340fda7")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/raw/tests.events.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1555495441 :MTIME 1792777714 :SHA256
   "aac2f88be1c1072973ad703921c6b217a60509631d5a899e0b1e5569f836b6a1")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/raw/tests.events.lisp.gz"
   :BYTES 126384 :DEVICE 16777232 :INODE 1555495442 :MTIME 1792777714 :SHA256
   "1e61acdc649903eecf3123a7a22518dc9dfa52094881df5c2beed8f206af49af")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/raw/tests.expected.lisp"
   :BYTES 8542 :DEVICE 16777232 :INODE 1555495443 :MTIME 1792777714 :SHA256
   "94f5e4a477fb6bfb88edc79d530e950a672ab87c856de45be52b367ab091c963")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/raw/tests.lisp"
   :BYTES 309 :DEVICE 16777232 :INODE 1555495444 :MTIME 1792777714 :SHA256
   "50c1a0e72b664024202f4a66c4e0834619dbbf7dec163d5a05ce95781faad485")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/raw/tests.lisp.gz"
   :BYTES 59462 :DEVICE 16777232 :INODE 1555495445 :MTIME 1792777714 :SHA256
   "a52746fc741242a3350974d79e1d153ddc09f5c662563eaf976b500979320bc9")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/payloads/verify-macos/99ec41e556968fadac127cf338851631551fe844a5d7d9975f458cc7ec2a05fb/result.lisp"
   :BYTES 5579 :DEVICE 16777232 :INODE 1555495446 :MTIME 1792777714 :SHA256
   "e06627bdedc89b0054eab1c7ec931d617a040166bc0c41c60db0c0cfe31ede55")
  (:PATH
   "spikes/results/ci/by-source/129a0dc0611f86c9ea86f9fe150ddbae59af46646428565d160ff01ef9ae396e/runs/39868790774/1/publications/132bc59ecc9ba1e50240ce45aa3eeaa6d121c827b767c5d7f48869cb6840b4ef.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1555495448 :MTIME 1792777714 :SHA256
   "b9c4e304a25f6614e3389ce87549df5ca5926e698dcf800d6ba145d980e2ac6f")
  (:PATH
   "spikes/results/ci/by-source/143d88a248ac1c289fb9458d121c49987947fc0e734d148547d135fe67991590/runs/38468351892/1/collections/05e71f750ff1d0ae3c58042eb4f2795dc929059dbcb0e69347e9e2e95678a7b7/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112963 :MTIME 1793207956 :SHA256
   "fe37e7e13ebb187888acf396c3a04b7a0b15c2a301c8bdc5b1b75614fa3b9919")
  (:PATH
   "spikes/results/ci/by-source/143d88a248ac1c289fb9458d121c49987947fc0e734d148547d135fe67991590/runs/38468351892/1/collections/05e71f750ff1d0ae3c58042eb4f2795dc929059dbcb0e69347e9e2e95678a7b7/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112964 :MTIME 1793207956 :SHA256
   "6071e2c0e6c5e0441c1bad2600c573ce6d465139a851b3796e7319cef3ef25b0")
  (:PATH
   "spikes/results/ci/by-source/143d88a248ac1c289fb9458d121c49987947fc0e734d148547d135fe67991590/runs/38468351892/1/collections/05e71f750ff1d0ae3c58042eb4f2795dc929059dbcb0e69347e9e2e95678a7b7/summary.lisp"
   :BYTES 4657 :DEVICE 16777232 :INODE 1560112965 :MTIME 1793207956 :SHA256
   "627282488752f530e8d9c1ba0321244f32f0265041aae87231109eadb1da3320")
  (:PATH
   "spikes/results/ci/by-source/143d88a248ac1c289fb9458d121c49987947fc0e734d148547d135fe67991590/runs/38468351892/1/collections/4b404589295d54d4f6fa1eee72bc7f503e43c43079f1fb7f95735afefd2798ce/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112967 :MTIME 1793207956 :SHA256
   "276c5fb489ee3af98417be1e7817a5e05cb9f999492dfe6801cf4374f46d7e34")
  (:PATH
   "spikes/results/ci/by-source/143d88a248ac1c289fb9458d121c49987947fc0e734d148547d135fe67991590/runs/38468351892/1/collections/4b404589295d54d4f6fa1eee72bc7f503e43c43079f1fb7f95735afefd2798ce/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112968 :MTIME 1793207956 :SHA256
   "6071e2c0e6c5e0441c1bad2600c573ce6d465139a851b3796e7319cef3ef25b0")
  (:PATH
   "spikes/results/ci/by-source/143d88a248ac1c289fb9458d121c49987947fc0e734d148547d135fe67991590/runs/38468351892/1/collections/4b404589295d54d4f6fa1eee72bc7f503e43c43079f1fb7f95735afefd2798ce/summary.lisp"
   :BYTES 4663 :DEVICE 16777232 :INODE 1560112969 :MTIME 1793207956 :SHA256
   "4aaabe798a4e409f59ef5dd3ac643260ec482a2a050261582840ffcfc4d72503")
  (:PATH
   "spikes/results/ci/by-source/143d88a248ac1c289fb9458d121c49987947fc0e734d148547d135fe67991590/runs/38468351892/1/publications/17421b1d69d72778000799848e2c92dec2927fb82e4e03dd029e2046dd5a4249.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560112971 :MTIME 1793207956 :SHA256
   "8087ef3815ce64333e84477469080fabc9568d4ce499ab7d4b3ace2a3fd1d5ed")
  (:PATH
   "spikes/results/ci/by-source/143d88a248ac1c289fb9458d121c49987947fc0e734d148547d135fe67991590/runs/38468351892/1/publications/ab117f258cd458d241ff9bf37011f2fcc5379b8d17c97a710b385b781495ba4d.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560112972 :MTIME 1793207956 :SHA256
   "0ac41d389beb0f1c8d0c1fc81704e2475704d5ef513954df1f0e783b083d595d")
  (:PATH
   "spikes/results/ci/by-source/1697737ffd55959345ab5e900403b11e40ae0b5c7ae0a698980a37fca26197d3/runs/38930450007/1/collections/452d996c67802ae6a07c89621d27dfd64d136ce84ba001b303cf7a2d12a9ab1a/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112979 :MTIME 1793207956 :SHA256
   "63a4d32f46876c73299275eb8b64e7983c6bdc229c2e02925f9bdaf670bc4d6a")
  (:PATH
   "spikes/results/ci/by-source/1697737ffd55959345ab5e900403b11e40ae0b5c7ae0a698980a37fca26197d3/runs/38930450007/1/collections/452d996c67802ae6a07c89621d27dfd64d136ce84ba001b303cf7a2d12a9ab1a/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112980 :MTIME 1793207956 :SHA256
   "8c03350a4520b2f3e209297ed7c77e99923e143824e4df988fadc6cec80b964d")
  (:PATH
   "spikes/results/ci/by-source/1697737ffd55959345ab5e900403b11e40ae0b5c7ae0a698980a37fca26197d3/runs/38930450007/1/collections/452d996c67802ae6a07c89621d27dfd64d136ce84ba001b303cf7a2d12a9ab1a/summary.lisp"
   :BYTES 5325 :DEVICE 16777232 :INODE 1560112981 :MTIME 1793207956 :SHA256
   "0471c426d2db65de3dfb7f5dc27e1f2b1647f9c48cc5d43301afe16042c5684b")
  (:PATH
   "spikes/results/ci/by-source/1697737ffd55959345ab5e900403b11e40ae0b5c7ae0a698980a37fca26197d3/runs/38930450007/1/publications/6e14f21b1dd689aa8852a3e727529ca885292afa096f20736dcfe7b4680e7b75.lisp"
   :BYTES 730 :DEVICE 16777232 :INODE 1560112983 :MTIME 1793207956 :SHA256
   "16c79d0623e8a8fd8458323003d244523abe45b53d53d306855d58abbb2f7acf")
  (:PATH
   "spikes/results/ci/by-source/17a0147c3bac03850e26ccda15b127ac9c54f7fe9a283465609b82af0278d8c8/runs/38947465706/1/collections/eb8e59ef6aa4ffa49d208c105ff17682c18d9144568e9a129b5c29290fe1c163/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560112990 :MTIME 1793207956 :SHA256
   "abade01822f9649b3fe32f7369c76ecd0a97c8fd74bf14dd9ffd7496b9a1789c")
  (:PATH
   "spikes/results/ci/by-source/17a0147c3bac03850e26ccda15b127ac9c54f7fe9a283465609b82af0278d8c8/runs/38947465706/1/collections/eb8e59ef6aa4ffa49d208c105ff17682c18d9144568e9a129b5c29290fe1c163/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560112991 :MTIME 1793207956 :SHA256
   "300db21f0c9171b50d3e1f699edf31574bb13caf1e9fee4f119436fc30184b07")
  (:PATH
   "spikes/results/ci/by-source/17a0147c3bac03850e26ccda15b127ac9c54f7fe9a283465609b82af0278d8c8/runs/38947465706/1/collections/eb8e59ef6aa4ffa49d208c105ff17682c18d9144568e9a129b5c29290fe1c163/summary.lisp"
   :BYTES 5604 :DEVICE 16777232 :INODE 1560112992 :MTIME 1793207956 :SHA256
   "5d9b2cc6b8c70e6584f0bd5c7e22c0f92877256e662dbcee9a7a992458616186")
  (:PATH
   "spikes/results/ci/by-source/17a0147c3bac03850e26ccda15b127ac9c54f7fe9a283465609b82af0278d8c8/runs/38947465706/1/publications/e47e54dd97eb9272954ceee7bd3d6a0d58a75149cb0ba35245deb795ac7811bd.lisp"
   :BYTES 730 :DEVICE 16777232 :INODE 1560112994 :MTIME 1793207956 :SHA256
   "288e514ce647c806dddc3309bd7234a42cc1845efbac521ac1758a8380133463")
  (:PATH
   "spikes/results/ci/by-source/19ac28124a8518193f99ed858cb34472aae8103729931c68878c9b08d32b700b/runs/38457282115/1/collections/5b9b12dff031a8436d0e8fb89f263163d67aadb2e7a035e66b844d410160ca28/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113001 :MTIME 1793207956 :SHA256
   "0d28a38b1882af5e07268d9b3badd5bbdbdf8885e72bf4b2f962850607268683")
  (:PATH
   "spikes/results/ci/by-source/19ac28124a8518193f99ed858cb34472aae8103729931c68878c9b08d32b700b/runs/38457282115/1/collections/5b9b12dff031a8436d0e8fb89f263163d67aadb2e7a035e66b844d410160ca28/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113002 :MTIME 1793207956 :SHA256
   "f2b439d4d78e47cf12b27fac227bddfded98f386db7ebd5e274eb34976e5e07d")
  (:PATH
   "spikes/results/ci/by-source/19ac28124a8518193f99ed858cb34472aae8103729931c68878c9b08d32b700b/runs/38457282115/1/collections/5b9b12dff031a8436d0e8fb89f263163d67aadb2e7a035e66b844d410160ca28/summary.lisp"
   :BYTES 4472 :DEVICE 16777232 :INODE 1560113003 :MTIME 1793207956 :SHA256
   "c0bd3f33b000543f0444301e9413ecca33f019a4fe416d53402107b101101733")
  (:PATH
   "spikes/results/ci/by-source/19ac28124a8518193f99ed858cb34472aae8103729931c68878c9b08d32b700b/runs/38457282115/1/collections/c44bbd23849ed769893bf19aeadd8eb5091238a262ee416a6185e4e47da75e84/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113005 :MTIME 1793207956 :SHA256
   "f7dd53d3427b4779e642ab054532f5742736a0dc871cd65b91ac13caa606f164")
  (:PATH
   "spikes/results/ci/by-source/19ac28124a8518193f99ed858cb34472aae8103729931c68878c9b08d32b700b/runs/38457282115/1/collections/c44bbd23849ed769893bf19aeadd8eb5091238a262ee416a6185e4e47da75e84/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113006 :MTIME 1793207956 :SHA256
   "f2b439d4d78e47cf12b27fac227bddfded98f386db7ebd5e274eb34976e5e07d")
  (:PATH
   "spikes/results/ci/by-source/19ac28124a8518193f99ed858cb34472aae8103729931c68878c9b08d32b700b/runs/38457282115/1/collections/c44bbd23849ed769893bf19aeadd8eb5091238a262ee416a6185e4e47da75e84/summary.lisp"
   :BYTES 4478 :DEVICE 16777232 :INODE 1560113007 :MTIME 1793207956 :SHA256
   "2f567a9db34b8bf0239f0c94747b3e408eb8d332b62da6397acea3d4dd4e60ab")
  (:PATH
   "spikes/results/ci/by-source/19ac28124a8518193f99ed858cb34472aae8103729931c68878c9b08d32b700b/runs/38457282115/1/publications/2656ef666bc3b9032e8da19986cd1bc60a624ecc580817371a1a72cfce013432.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113009 :MTIME 1793207956 :SHA256
   "78939f50ebe5e4a8ad0a02153b09261fb3031a26e3c558e08765c2c7138bcb72")
  (:PATH
   "spikes/results/ci/by-source/19ac28124a8518193f99ed858cb34472aae8103729931c68878c9b08d32b700b/runs/38457282115/1/publications/5099b5df1b1d277c4bb4088eac2066d7739819f461b47818c0ef6b4fba98670c.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113010 :MTIME 1793207956 :SHA256
   "63d265aef21f5747a002553a492b0d56de629014b4d1958db5db104981304668")
  (:PATH
   "spikes/results/ci/by-source/1b2519591962c8fe9f48a4723857580b879100c5dfddcd0b766d4d7b4f11dc49/runs/38140649301/1/collections/1ee898732ea2024848eca82cc29a01d489751a5c72a11826b044976e6ecd7420/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113017 :MTIME 1793207956 :SHA256
   "2ebe150613196c128e2ee8241f9260ce9b1f99b4d429bef433a851c275cc692f")
  (:PATH
   "spikes/results/ci/by-source/1b2519591962c8fe9f48a4723857580b879100c5dfddcd0b766d4d7b4f11dc49/runs/38140649301/1/collections/1ee898732ea2024848eca82cc29a01d489751a5c72a11826b044976e6ecd7420/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113018 :MTIME 1793207956 :SHA256
   "59266bfcec1ce2e88e058ef52e7f8516417ab8eaeaa197aafc74fbeaa138e276")
  (:PATH
   "spikes/results/ci/by-source/1b2519591962c8fe9f48a4723857580b879100c5dfddcd0b766d4d7b4f11dc49/runs/38140649301/1/collections/1ee898732ea2024848eca82cc29a01d489751a5c72a11826b044976e6ecd7420/summary.lisp"
   :BYTES 4182 :DEVICE 16777232 :INODE 1560113019 :MTIME 1793207956 :SHA256
   "261d25f6a5bf3eb70bd70e4fa996ec08cb0cbbab16a8d859e7017616ff451ee4")
  (:PATH
   "spikes/results/ci/by-source/1b2519591962c8fe9f48a4723857580b879100c5dfddcd0b766d4d7b4f11dc49/runs/38140649301/1/collections/abc3740bae23a6ef61772d49429e7b856a613e494f4098e7cf291db90a7f14ab/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113021 :MTIME 1793207956 :SHA256
   "5659a4782144554500758f38cbde22f8959bd66a5ff6bd9d9f07d56dcbc2749c")
  (:PATH
   "spikes/results/ci/by-source/1b2519591962c8fe9f48a4723857580b879100c5dfddcd0b766d4d7b4f11dc49/runs/38140649301/1/collections/abc3740bae23a6ef61772d49429e7b856a613e494f4098e7cf291db90a7f14ab/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113022 :MTIME 1793207956 :SHA256
   "59266bfcec1ce2e88e058ef52e7f8516417ab8eaeaa197aafc74fbeaa138e276")
  (:PATH
   "spikes/results/ci/by-source/1b2519591962c8fe9f48a4723857580b879100c5dfddcd0b766d4d7b4f11dc49/runs/38140649301/1/collections/abc3740bae23a6ef61772d49429e7b856a613e494f4098e7cf291db90a7f14ab/summary.lisp"
   :BYTES 4176 :DEVICE 16777232 :INODE 1560113023 :MTIME 1793207956 :SHA256
   "64a5a7d4ff76ef8936b0c7b514305dfeced2f0162b03ce3ceaf4afd3e60ec02a")
  (:PATH
   "spikes/results/ci/by-source/1b2519591962c8fe9f48a4723857580b879100c5dfddcd0b766d4d7b4f11dc49/runs/38140649301/1/publications/46c383728067b2f84f1a15622f94652d68654d6beb0d5f7c4e3809bdd8945dba.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113025 :MTIME 1793207956 :SHA256
   "fc15af2569c501215332fa323fdaaf29a7fdca19dac8de5f17d0d79cb3afa78b")
  (:PATH
   "spikes/results/ci/by-source/1b2519591962c8fe9f48a4723857580b879100c5dfddcd0b766d4d7b4f11dc49/runs/38140649301/1/publications/c4d5bbb882733a6c0afe8d0bb05ddff69e7e073af93a2763f32915b6eae4bd57.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113026 :MTIME 1793207956 :SHA256
   "63331040cdef1bcef902403d8d97c2200d024bb8d1e5936817500e7c7a626ff0")
  (:PATH
   "spikes/results/ci/by-source/1dc1337e0f4e16388e12d7270779d5947fe9700314233de0ea1189e90d78a2fa/runs/38454587852/1/collections/1ce66d33c9597a530d40e0c2111344f677762f7219af7871ce7d52cfcd068381/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113033 :MTIME 1793207956 :SHA256
   "b2eb92f75981631678b834e95a18b3c1cface36fc16d81bf3a5f50cd40d1471a")
  (:PATH
   "spikes/results/ci/by-source/1dc1337e0f4e16388e12d7270779d5947fe9700314233de0ea1189e90d78a2fa/runs/38454587852/1/collections/1ce66d33c9597a530d40e0c2111344f677762f7219af7871ce7d52cfcd068381/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113034 :MTIME 1793207956 :SHA256
   "d320e4caf3ed12b3454d80b87845bd813c2e7f53cfea62fe393efabd9bfa25b1")
  (:PATH
   "spikes/results/ci/by-source/1dc1337e0f4e16388e12d7270779d5947fe9700314233de0ea1189e90d78a2fa/runs/38454587852/1/collections/1ce66d33c9597a530d40e0c2111344f677762f7219af7871ce7d52cfcd068381/summary.lisp"
   :BYTES 4472 :DEVICE 16777232 :INODE 1560113035 :MTIME 1793207956 :SHA256
   "2cdbfa1efedb697094589136999ce5b74cb448b2cc2448daea40ee7a3e947a95")
  (:PATH
   "spikes/results/ci/by-source/1dc1337e0f4e16388e12d7270779d5947fe9700314233de0ea1189e90d78a2fa/runs/38454587852/1/collections/a49905b8b1dba6f62d4baec70bd85c3f04fb8e1c6f9239edc8f23ebce610f83b/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113037 :MTIME 1793207956 :SHA256
   "70b4406e11e8d7f275b5c77fd2fef903b0520e04279558aa24695badee276009")
  (:PATH
   "spikes/results/ci/by-source/1dc1337e0f4e16388e12d7270779d5947fe9700314233de0ea1189e90d78a2fa/runs/38454587852/1/collections/a49905b8b1dba6f62d4baec70bd85c3f04fb8e1c6f9239edc8f23ebce610f83b/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113038 :MTIME 1793207956 :SHA256
   "d320e4caf3ed12b3454d80b87845bd813c2e7f53cfea62fe393efabd9bfa25b1")
  (:PATH
   "spikes/results/ci/by-source/1dc1337e0f4e16388e12d7270779d5947fe9700314233de0ea1189e90d78a2fa/runs/38454587852/1/collections/a49905b8b1dba6f62d4baec70bd85c3f04fb8e1c6f9239edc8f23ebce610f83b/summary.lisp"
   :BYTES 4478 :DEVICE 16777232 :INODE 1560113039 :MTIME 1793207956 :SHA256
   "f2604a347eac6280d7d5711fca04809306f493c65aa3690299847368d67b67b4")
  (:PATH
   "spikes/results/ci/by-source/1dc1337e0f4e16388e12d7270779d5947fe9700314233de0ea1189e90d78a2fa/runs/38454587852/1/publications/92aab4edb7c689e7c29b803d1993c432d61bfb5db96156d907da12ccd513a0bb.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113041 :MTIME 1793207956 :SHA256
   "58f507cdc2c090d6173d866c8e4d87231456baebcdb6e5850caa8273486e825a")
  (:PATH
   "spikes/results/ci/by-source/1dc1337e0f4e16388e12d7270779d5947fe9700314233de0ea1189e90d78a2fa/runs/38454587852/1/publications/9534a7caf3c9297e332c04da47f4ace4af485c94804861ba71012a8481f63175.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113042 :MTIME 1793207956 :SHA256
   "154997edbd3d5a5d5b3d7a1395af25482cb7087d39004b77e958b4c41e0516b0")
  (:PATH
   "spikes/results/ci/by-source/2391085e3c86bb576e92a2220b6ba2c7520bbb75292c111ef3709a501b9bc01f/runs/38785211699/1/collections/d4bce32e20150a6029d23cbc972871d5bff81c4f5eda58db615ee7907195c709/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113049 :MTIME 1793207956 :SHA256
   "8ed008cdd94c21557bb31b993ed0108987e8f800455fcbdf168140f7af22513c")
  (:PATH
   "spikes/results/ci/by-source/2391085e3c86bb576e92a2220b6ba2c7520bbb75292c111ef3709a501b9bc01f/runs/38785211699/1/collections/d4bce32e20150a6029d23cbc972871d5bff81c4f5eda58db615ee7907195c709/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113050 :MTIME 1793207956 :SHA256
   "05e88c15567ff66104ffaa5dd107d4a9f6cde0f556920b7d25512cdc5798eb19")
  (:PATH
   "spikes/results/ci/by-source/2391085e3c86bb576e92a2220b6ba2c7520bbb75292c111ef3709a501b9bc01f/runs/38785211699/1/collections/d4bce32e20150a6029d23cbc972871d5bff81c4f5eda58db615ee7907195c709/summary.lisp"
   :BYTES 5068 :DEVICE 16777232 :INODE 1560113051 :MTIME 1793207956 :SHA256
   "69aae564307d2b003cab09bbdb02b970c9bc5f85c5cab1151b53cf46c831c6ed")
  (:PATH
   "spikes/results/ci/by-source/2391085e3c86bb576e92a2220b6ba2c7520bbb75292c111ef3709a501b9bc01f/runs/38785211699/1/publications/84225be854c11989c22ec089b542de1e9d13a7919382c638b307e201dd354007.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113053 :MTIME 1793207956 :SHA256
   "47558ed8806a8750c1a72bba0b9d7d4dddcde07d36e6b6ed73994967d0cd8b2b")
  (:PATH
   "spikes/results/ci/by-source/27c97505f45c6523f81bfdddfc4e743ed55d4b24209ff1353a03fa93c272a448/runs/38142593653/1/collections/3414cbaacfd55dd6577131254290429ab3f95d018839c9c63edd22fe25994029/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113060 :MTIME 1793207956 :SHA256
   "39dfdb1dc32b33dd4e37ee71fe0b63acc2ccf2ef551a09596038bfde1b597a12")
  (:PATH
   "spikes/results/ci/by-source/27c97505f45c6523f81bfdddfc4e743ed55d4b24209ff1353a03fa93c272a448/runs/38142593653/1/collections/3414cbaacfd55dd6577131254290429ab3f95d018839c9c63edd22fe25994029/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113061 :MTIME 1793207956 :SHA256
   "620409d1a183e116a6893ff0b2abaa595f988796cba433cf2efb42dc3b6afbf6")
  (:PATH
   "spikes/results/ci/by-source/27c97505f45c6523f81bfdddfc4e743ed55d4b24209ff1353a03fa93c272a448/runs/38142593653/1/collections/3414cbaacfd55dd6577131254290429ab3f95d018839c9c63edd22fe25994029/summary.lisp"
   :BYTES 4274 :DEVICE 16777232 :INODE 1560113062 :MTIME 1793207956 :SHA256
   "955860d0f1afee0bb9811111ece0ea2ebcea06265420bd6666dd604483987c1d")
  (:PATH
   "spikes/results/ci/by-source/27c97505f45c6523f81bfdddfc4e743ed55d4b24209ff1353a03fa93c272a448/runs/38142593653/1/collections/39ff3fa772405c57d7024717c2fbd0329dda00b56021d1ff4d87f5d4f6efa0a5/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113064 :MTIME 1793207956 :SHA256
   "ff310e15c7d6f8e54b08491ca95b465adec9a8addabb2c8a2ff82813fdf65627")
  (:PATH
   "spikes/results/ci/by-source/27c97505f45c6523f81bfdddfc4e743ed55d4b24209ff1353a03fa93c272a448/runs/38142593653/1/collections/39ff3fa772405c57d7024717c2fbd0329dda00b56021d1ff4d87f5d4f6efa0a5/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113065 :MTIME 1793207956 :SHA256
   "620409d1a183e116a6893ff0b2abaa595f988796cba433cf2efb42dc3b6afbf6")
  (:PATH
   "spikes/results/ci/by-source/27c97505f45c6523f81bfdddfc4e743ed55d4b24209ff1353a03fa93c272a448/runs/38142593653/1/collections/39ff3fa772405c57d7024717c2fbd0329dda00b56021d1ff4d87f5d4f6efa0a5/summary.lisp"
   :BYTES 4280 :DEVICE 16777232 :INODE 1560113066 :MTIME 1793207956 :SHA256
   "afa023b1c0665c06407c37a3cbb976629083298b7ab03276bee7d9c707f06583")
  (:PATH
   "spikes/results/ci/by-source/27c97505f45c6523f81bfdddfc4e743ed55d4b24209ff1353a03fa93c272a448/runs/38142593653/1/publications/0e1880950bc173d1e727d05920963454e6b3de03a5811c317e3d4c055d06847d.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113068 :MTIME 1793207956 :SHA256
   "f4df556fe9b0e955924509179bf09571ce1e343c0d19e9ec731a03785174cb3b")
  (:PATH
   "spikes/results/ci/by-source/27c97505f45c6523f81bfdddfc4e743ed55d4b24209ff1353a03fa93c272a448/runs/38142593653/1/publications/2c27f5a35ab04c629dc430274f3a5820a49a41cebea35668938a19475dc0dd9c.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113069 :MTIME 1793207956 :SHA256
   "b175a6127c7ec65cabf564ac2b946bd891f6b97bc6649366e28fa9930eb93d3b")
  (:PATH
   "spikes/results/ci/by-source/29638cd03367f8e7d0838223f1d9cd1c5d37c0714401678de56c375328410c92/runs/38633589910/1/collections/2c6ad901a8f040aa286fdff06eaa754bf43f87ed7a3e39ef0723068b84c3e625/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113076 :MTIME 1793207956 :SHA256
   "326ff46925f141301e101e9088b3eed08588c9760610b8b51ba6b8089e789cd1")
  (:PATH
   "spikes/results/ci/by-source/29638cd03367f8e7d0838223f1d9cd1c5d37c0714401678de56c375328410c92/runs/38633589910/1/collections/2c6ad901a8f040aa286fdff06eaa754bf43f87ed7a3e39ef0723068b84c3e625/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113077 :MTIME 1793207956 :SHA256
   "750e30556c63df2ae5475ae620ba4526ed271789727e4c21ad51df5e286816e5")
  (:PATH
   "spikes/results/ci/by-source/29638cd03367f8e7d0838223f1d9cd1c5d37c0714401678de56c375328410c92/runs/38633589910/1/collections/2c6ad901a8f040aa286fdff06eaa754bf43f87ed7a3e39ef0723068b84c3e625/summary.lisp"
   :BYTES 4864 :DEVICE 16777232 :INODE 1560113078 :MTIME 1793207956 :SHA256
   "f3b85a8fab4ebf4454be65a4809fe1ef055330855465ca66708df9b7f5c1f034")
  (:PATH
   "spikes/results/ci/by-source/29638cd03367f8e7d0838223f1d9cd1c5d37c0714401678de56c375328410c92/runs/38633589910/1/collections/41ca2d16a9c332c3d95cd903c00cfd44aee4912eef047a669b73f6f11415ad69/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113080 :MTIME 1793207956 :SHA256
   "acb0f58f5694b4086830a5d82b084ec7a8134519e3f70e5e497365c8d1439246")
  (:PATH
   "spikes/results/ci/by-source/29638cd03367f8e7d0838223f1d9cd1c5d37c0714401678de56c375328410c92/runs/38633589910/1/collections/41ca2d16a9c332c3d95cd903c00cfd44aee4912eef047a669b73f6f11415ad69/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113081 :MTIME 1793207956 :SHA256
   "750e30556c63df2ae5475ae620ba4526ed271789727e4c21ad51df5e286816e5")
  (:PATH
   "spikes/results/ci/by-source/29638cd03367f8e7d0838223f1d9cd1c5d37c0714401678de56c375328410c92/runs/38633589910/1/collections/41ca2d16a9c332c3d95cd903c00cfd44aee4912eef047a669b73f6f11415ad69/summary.lisp"
   :BYTES 4858 :DEVICE 16777232 :INODE 1560113082 :MTIME 1793207956 :SHA256
   "a58d161355df5600c300fe7f317fda9e074fd080d3f1b95af0fb7360c4167227")
  (:PATH
   "spikes/results/ci/by-source/29638cd03367f8e7d0838223f1d9cd1c5d37c0714401678de56c375328410c92/runs/38633589910/1/publications/161a307e91d38ae9435e2fc722d750217530ca0b3c0baff7ae2a2e59e1de0eec.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113084 :MTIME 1793207956 :SHA256
   "1f46e9109b865a90fde60fe84e6bea17f228cdd981f34c2e9cd655e4e49927d9")
  (:PATH
   "spikes/results/ci/by-source/29638cd03367f8e7d0838223f1d9cd1c5d37c0714401678de56c375328410c92/runs/38633589910/1/publications/1976e555cefb86eb5b98d89a7e4189c22a521a1f9e336085384a649939cb2eec.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113085 :MTIME 1793207956 :SHA256
   "e8f2f56a9b8c626273c0911427dac4fb27316a4f9657a31294b8f536b6333609")
  (:PATH
   "spikes/results/ci/by-source/2a6362fae5c0589049eb80b0d829086f86a19e61a0191fdebd130aa060f1550b/runs/38933884219/1/collections/5e5af501a583ed730f18520604398fecf4a26882d467d6e7c0733c284fe0ee9d/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113092 :MTIME 1793207956 :SHA256
   "e503f3fd8537b55c9b6db01e4b188dc7ca22610f5617b2fc5e26882f505d0e7d")
  (:PATH
   "spikes/results/ci/by-source/2a6362fae5c0589049eb80b0d829086f86a19e61a0191fdebd130aa060f1550b/runs/38933884219/1/collections/5e5af501a583ed730f18520604398fecf4a26882d467d6e7c0733c284fe0ee9d/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113093 :MTIME 1793207956 :SHA256
   "d7edf19b768eb851c30a4a5032e17692a1096e9c09a159bedd4e818b5ab45a34")
  (:PATH
   "spikes/results/ci/by-source/2a6362fae5c0589049eb80b0d829086f86a19e61a0191fdebd130aa060f1550b/runs/38933884219/1/collections/5e5af501a583ed730f18520604398fecf4a26882d467d6e7c0733c284fe0ee9d/summary.lisp"
   :BYTES 5275 :DEVICE 16777232 :INODE 1560113094 :MTIME 1793207956 :SHA256
   "303a2b7becf6640b0d2e4be06dbb60013e43c2a31586d74dc6d68618df269d0c")
  (:PATH
   "spikes/results/ci/by-source/2a6362fae5c0589049eb80b0d829086f86a19e61a0191fdebd130aa060f1550b/runs/38933884219/1/publications/c55c72f606a00fc0d8233fa12a35355a78c7f8b733c33217534053772b85079b.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113096 :MTIME 1793207956 :SHA256
   "178cfcb1656c3c4fc4bb9e32660514aa7d46beeaba49ac255c469a8f5c3b367a")
  (:PATH
   "spikes/results/ci/by-source/2a8449a8c5776cab0d261cf67b298aba73f73491daca734f22d7423e7b912af7/runs/38781246234/1/collections/0a85bced32f995fdd0daf1cd2f1c191dbbb7604a461fdbcb978edc2fe3e41ea1/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113103 :MTIME 1793207956 :SHA256
   "2b75531c04a3a9aac8129a292ba94d4992c720b19a1b7fa8a2d543169c556834")
  (:PATH
   "spikes/results/ci/by-source/2a8449a8c5776cab0d261cf67b298aba73f73491daca734f22d7423e7b912af7/runs/38781246234/1/collections/0a85bced32f995fdd0daf1cd2f1c191dbbb7604a461fdbcb978edc2fe3e41ea1/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113104 :MTIME 1793207956 :SHA256
   "32f70e44f96eca7adf2c26219651298fe2704243aba72a7337d82c6b03fee394")
  (:PATH
   "spikes/results/ci/by-source/2a8449a8c5776cab0d261cf67b298aba73f73491daca734f22d7423e7b912af7/runs/38781246234/1/collections/0a85bced32f995fdd0daf1cd2f1c191dbbb7604a461fdbcb978edc2fe3e41ea1/summary.lisp"
   :BYTES 4963 :DEVICE 16777232 :INODE 1560113105 :MTIME 1793207956 :SHA256
   "fa4be1eee6020274cfd08dff0c44552ee1326f1ebdc6e38f0bae6feb74605191")
  (:PATH
   "spikes/results/ci/by-source/2a8449a8c5776cab0d261cf67b298aba73f73491daca734f22d7423e7b912af7/runs/38781246234/1/publications/100ed3b051d162ae5b4e1e79756bbd4650fb3aa83bffb29a238982710a3731fc.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113107 :MTIME 1793207956 :SHA256
   "30b77d59d59e2e77ac9d8843d26a1f29b41182788fad8263ff1be77857621fb6")
  (:PATH
   "spikes/results/ci/by-source/2e2440076fccf1cde82cd23972f866df1e968d18a83784aed382808dac8bf378/runs/38786599087/1/collections/8f12b0f7e346b64472d42d6fe8fbe39bf440749a2d9d5cf664280e35804f0c8e/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113114 :MTIME 1793207956 :SHA256
   "40bac7fa418ffbd924854792041315df0391e6216aee2db237dcbc10f9b92d5b")
  (:PATH
   "spikes/results/ci/by-source/2e2440076fccf1cde82cd23972f866df1e968d18a83784aed382808dac8bf378/runs/38786599087/1/collections/8f12b0f7e346b64472d42d6fe8fbe39bf440749a2d9d5cf664280e35804f0c8e/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113115 :MTIME 1793207956 :SHA256
   "f64aac7fbc23a59f7dc550dba4d2c07c6b4eb28b3f4eba657b3532cdb1f03eda")
  (:PATH
   "spikes/results/ci/by-source/2e2440076fccf1cde82cd23972f866df1e968d18a83784aed382808dac8bf378/runs/38786599087/1/collections/8f12b0f7e346b64472d42d6fe8fbe39bf440749a2d9d5cf664280e35804f0c8e/summary.lisp"
   :BYTES 5068 :DEVICE 16777232 :INODE 1560113116 :MTIME 1793207956 :SHA256
   "6c04cb1b3e1cb45b83668ceb8b8961a041d0ec93fa20ce969119a341dae976b8")
  (:PATH
   "spikes/results/ci/by-source/2e2440076fccf1cde82cd23972f866df1e968d18a83784aed382808dac8bf378/runs/38786599087/1/publications/a57c54a4e8bd6a4a0063c74922098399a86e022b988bbb76b5ae8b7ba0a4096c.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113118 :MTIME 1793207956 :SHA256
   "5e45aa0b462790d9c28c673fa32423a3237509a8dc35d28a3f49a8141c2acffc")
  (:PATH
   "spikes/results/ci/by-source/2f0fa9d9ce8c743386c980a6cada9f780945b306ec94e3d2e28b3d7701df11fc/runs/38781644245/1/collections/ccb5c2f29e1aaf5e02134707180f3a25687e17aa382c6460ff0fc97dc02788df/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113125 :MTIME 1793207956 :SHA256
   "2fd3243b7468bec29586c7445278695038003ea81a73f05edd1bfa58b6830909")
  (:PATH
   "spikes/results/ci/by-source/2f0fa9d9ce8c743386c980a6cada9f780945b306ec94e3d2e28b3d7701df11fc/runs/38781644245/1/collections/ccb5c2f29e1aaf5e02134707180f3a25687e17aa382c6460ff0fc97dc02788df/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113126 :MTIME 1793207956 :SHA256
   "24ab7832ec9c7f1bfbe4ec4ce1c4277ef587679eb5afe4c4d5adf00d8ab93046")
  (:PATH
   "spikes/results/ci/by-source/2f0fa9d9ce8c743386c980a6cada9f780945b306ec94e3d2e28b3d7701df11fc/runs/38781644245/1/collections/ccb5c2f29e1aaf5e02134707180f3a25687e17aa382c6460ff0fc97dc02788df/summary.lisp"
   :BYTES 5067 :DEVICE 16777232 :INODE 1560113127 :MTIME 1793207956 :SHA256
   "ee84f5fea52e44d748ae342643c093e14a518255254cabfe8bed2b772cfb0d7b")
  (:PATH
   "spikes/results/ci/by-source/2f0fa9d9ce8c743386c980a6cada9f780945b306ec94e3d2e28b3d7701df11fc/runs/38781644245/1/publications/75a04f51f48007775671a966ce69eaaf2e7e6da61017a39f241c8d1e14e26db5.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113129 :MTIME 1793207956 :SHA256
   "ed876dd99fddf3554e1f1386ca80016920e060c869e3a8bf81751b5ef359f30f")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/collections/3a06f2938c4fea3563ca97a4dcc81e8a6fbe6e6f842dcaf443a105973be5ab5e/manifest.lisp"
   :BYTES 393 :DEVICE 16777232 :INODE 1560113136 :MTIME 1793207956 :SHA256
   "93630429f2ffd005ec445313e4a1b8c5497a32fa5718203108d28378bd4bc583")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/collections/3a06f2938c4fea3563ca97a4dcc81e8a6fbe6e6f842dcaf443a105973be5ab5e/report.md"
   :BYTES 25082 :DEVICE 16777232 :INODE 1560113137 :MTIME 1793207956 :SHA256
   "6e3d36e9005e31d310606559e0e564d05de227bd3533b60ef989d6dc21769ee0")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/collections/3a06f2938c4fea3563ca97a4dcc81e8a6fbe6e6f842dcaf443a105973be5ab5e/summary.lisp"
   :BYTES 30635 :DEVICE 16777232 :INODE 1560113138 :MTIME 1793207956 :SHA256
   "052e756368ee8bc188247b4c3acd882aefb5740d27156abc7c02c9c617807097")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/manifest.lisp"
   :BYTES 9803 :DEVICE 16777232 :INODE 1560113142 :MTIME 1793207956 :SHA256
   "64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/c4-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560113144 :MTIME 1793207956 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/c4-driver.stdout"
   :BYTES 113 :DEVICE 16777232 :INODE 1560113145 :MTIME 1793207956 :SHA256
   "accd85553cd1ff9661f469aea44b19c522417e9036085e7a8fa23a1a4f2649c0")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/child-result.lisp"
   :BYTES 3313 :DEVICE 16777232 :INODE 1560113146 :MTIME 1793207956 :SHA256
   "73e9c816c382b1e96e38549415b683d3175b435174f02268b6299e32c000af6c")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/c4/conservazione.lisp"
   :BYTES 1085 :DEVICE 16777232 :INODE 1560113149 :MTIME 1793207956 :SHA256
   "3d965622a419ba125517ec72084e2e86338ac6d37fa8e256450585c3743eac33")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/c4/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1560113150 :MTIME 1793207956 :SHA256
   "b250dc434cef2414596d5c9354fb7ec89239947e9de1271e35e23df69272b69d")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/c4/report.lisp.gz"
   :BYTES 105245 :DEVICE 16777232 :INODE 1560113151 :MTIME 1793207956 :SHA256
   "ca8bc53bb96fb704ac879f870c8ed8ab8ade9077ddfa5ae94e1287e120ec50f1")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/job/conservazione.lisp"
   :BYTES 1087 :DEVICE 16777232 :INODE 1560113153 :MTIME 1793207956 :SHA256
   "74bfbbae0f648d6068b7c8834d1f08b76b76683f10855de61bdb17aeee786b76")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1560113154 :MTIME 1793207956 :SHA256
   "f33448678b500a49fc456d461d5d2c3256731bf53f159460a6b9d67ae974af6c")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/job/report.lisp.gz"
   :BYTES 93946 :DEVICE 16777232 :INODE 1560113155 :MTIME 1793207956 :SHA256
   "1e7ace2a28da8d1d1c4fe2235c80ceafd1b049d0666dc01b364b113d5f2a0c4d")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/links/conservazione.lisp"
   :BYTES 1091 :DEVICE 16777232 :INODE 1560113157 :MTIME 1793207956 :SHA256
   "032448f75906eef5b3b5dbd0440abdb3e3be34c49992695c23e6fcfd39bd37fd")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/links/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1560113158 :MTIME 1793207956 :SHA256
   "fea740051f5037798d4019d0a9991d90c002e33fe682a727e6a8ae4f5cf179f9")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/links/report.lisp.gz"
   :BYTES 93935 :DEVICE 16777232 :INODE 1560113159 :MTIME 1793207956 :SHA256
   "bd8057cfa738c6f8016fdea124a41052943b6adc91b9693f9817656804363eb0")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/lint/conservazione.lisp"
   :BYTES 1089 :DEVICE 16777232 :INODE 1560113161 :MTIME 1793207956 :SHA256
   "08198ecc57abb0c107255bf71215b4f34a35426fee9e247a2295f9236c14b8d2")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/lint/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1560113162 :MTIME 1793207956 :SHA256
   "99beaa386822242b3c6e0e4decfd3b46b5da80dd813986731fcc54dce90b13eb")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/lint/report.lisp.gz"
   :BYTES 93931 :DEVICE 16777232 :INODE 1560113163 :MTIME 1793207956 :SHA256
   "b4b48c4267c1b5932f05694783f7e2b82379e0222b03c225550126f7f261caae")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/trace/conservazione.lisp"
   :BYTES 1091 :DEVICE 16777232 :INODE 1560113165 :MTIME 1793207956 :SHA256
   "cd3e59ea85cbb5dc609c5991ab887ae32d2ebd69fafe53931b6391b29da41829")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/trace/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1560113166 :MTIME 1793207956 :SHA256
   "28c8ffa68842e9bfc971818071a8e905862b7d046c8c79a355f5ae6bd52f8604")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/commands/trace/report.lisp.gz"
   :BYTES 93952 :DEVICE 16777232 :INODE 1560113167 :MTIME 1793207956 :SHA256
   "01f9126bcfc5ef72eabfbdb611b52449299267bb07778f9d413baab47087a976")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1560113168 :MTIME 1793207956 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560113169 :MTIME 1793207956 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/job-driver.stdout"
   :BYTES 375 :DEVICE 16777232 :INODE 1560113170 :MTIME 1793207956 :SHA256
   "bc2860565b52317f8a7cec51c2cd125c28fa46ba45e7f014a60c4937b9560ded")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/links-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560113171 :MTIME 1793207956 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/links-driver.stdout"
   :BYTES 321 :DEVICE 16777232 :INODE 1560113172 :MTIME 1793207956 :SHA256
   "8a8eec8150553ae3477e751494d0d9c92e58c36414db192344c627b3e8e18bee")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/links.lisp"
   :BYTES 181 :DEVICE 16777232 :INODE 1560113173 :MTIME 1793207956 :SHA256
   "6ad1b91b918ad68f3f70c9dba0db2c0d2e87ce53a4ec45a16b3eb83a1969aded")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/lint-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560113174 :MTIME 1793207956 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/lint-driver.stdout"
   :BYTES 314 :DEVICE 16777232 :INODE 1560113175 :MTIME 1793207956 :SHA256
   "9ef619380b092336ceaad7d1fedf14de9815e7a55523e35dc1758d36d038bd47")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/lint.lisp"
   :BYTES 354 :DEVICE 16777232 :INODE 1560113176 :MTIME 1793207956 :SHA256
   "b9ef7d4909e975a0eca52d59fdfac7406f3cfad31f01a10c35cb9eb41433a567")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/trace-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560113177 :MTIME 1793207956 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/trace-driver.stdout"
   :BYTES 319 :DEVICE 16777232 :INODE 1560113178 :MTIME 1793207956 :SHA256
   "de2ccd95fbe0b73d7fce3436b989a28a8e49305b5b1b99bef28659fe3eca3537")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/raw/trace.lisp"
   :BYTES 1607 :DEVICE 16777232 :INODE 1560113179 :MTIME 1793207956 :SHA256
   "0d1df0e1b888059d0a24763ddf184c2b67f8db2c1935fa8029819056632faed9")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/audit/64369a593dea75d3f28010f15c465314fa9ad69fd2597e5134bf541b0e62839f/result.lisp"
   :BYTES 8693 :DEVICE 16777232 :INODE 1560113180 :MTIME 1793207956 :SHA256
   "b9a8c1f3d7eeec862518936b407c6e1d5fb1798051e6b16c53bb7e135fd6e416")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/manifest.lisp"
   :BYTES 8312 :DEVICE 16777232 :INODE 1560113183 :MTIME 1793207956 :SHA256
   "2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/child-result.lisp"
   :BYTES 314 :DEVICE 16777232 :INODE 1560113185 :MTIME 1793207956 :SHA256
   "c138298eb13a7ec98984acd606e2aeb71b825083a2c74512ea6faaddae1a01ae")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/child-result.lisp.gz"
   :BYTES 2354 :DEVICE 16777232 :INODE 1560113186 :MTIME 1793207956 :SHA256
   "58868971b56c4d2f1d361b130473e3b297a1ede65f59e486792f0371f97ce0b1")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/commands/job/conservazione.lisp"
   :BYTES 1087 :DEVICE 16777232 :INODE 1560113189 :MTIME 1793207956 :SHA256
   "3f4014734e17427e08989ae769acea56b765687d716ab7c14babcb41cf8a3a2d")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1560113190 :MTIME 1793207956 :SHA256
   "77749b6a434bf9849f5b1345005cccba6d46106acda128cd32c98dee184810c7")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/commands/job/report.lisp.gz"
   :BYTES 93942 :DEVICE 16777232 :INODE 1560113191 :MTIME 1793207956 :SHA256
   "1eb0cb9814eda9caaf85864773ae5c13157ee820d5200ca668d752fcaf80f196")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/coordinator-identity.lisp"
   :BYTES 212 :DEVICE 16777232 :INODE 1560113192 :MTIME 1793207956 :SHA256
   "90eb7815396e62c77c40367f6af69fbcd9b9e7e018d9a839ca6b0f754764fa0f")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1560113193 :MTIME 1793207956 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560113194 :MTIME 1793207956 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/job-driver.stdout"
   :BYTES 375 :DEVICE 16777232 :INODE 1560113195 :MTIME 1793207956 :SHA256
   "bbd3062782ad907c994eb98b8d911652a2cfca1d07f6a2a388647d61dc7d27a3")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/measure-replica-01.lisp"
   :BYTES 2118 :DEVICE 16777232 :INODE 1560113196 :MTIME 1793207956 :SHA256
   "35e14ab15aa8c42b00c581abd246a37606663bd9df9e5818222417c6d84d03ad")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/measure-replica-01.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1560113197 :MTIME 1793207956 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/measure-replica-02.lisp"
   :BYTES 2118 :DEVICE 16777232 :INODE 1560113198 :MTIME 1793207956 :SHA256
   "d4dea1055ce2aab284e0c0795421511718b135b66df438645a552139a2c5d9a5")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/measure-replica-02.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1560113199 :MTIME 1793207956 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/measure-replica-03.lisp"
   :BYTES 2119 :DEVICE 16777232 :INODE 1560113200 :MTIME 1793207956 :SHA256
   "0244991ded658f1652b490dcc26cc1bd7d44804f0d3a78702bec0b917c081f43")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/measure-replica-03.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1560113201 :MTIME 1793207956 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/measure-replica-04.lisp"
   :BYTES 2118 :DEVICE 16777232 :INODE 1560113202 :MTIME 1793207956 :SHA256
   "9c331108fc9b76a22c2af97a9f747c3e8d1536a2598de9f175e9e3956845b49b")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/measure-replica-04.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1560113203 :MTIME 1793207956 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/measure-replica-05.lisp"
   :BYTES 2119 :DEVICE 16777232 :INODE 1560113204 :MTIME 1793207956 :SHA256
   "b81a707957e1caa0a74d12bd07513e4939f277e5234bae43d56eccdba50a416f")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/measure-replica-05.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1560113205 :MTIME 1793207956 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/measure.lisp"
   :BYTES 309 :DEVICE 16777232 :INODE 1560113206 :MTIME 1793207956 :SHA256
   "0567c503ebbcbfc7ad1dce8781ba4cc87fb30b99eb0a0255674d447b95edc3e8")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/raw/measure.lisp.gz"
   :BYTES 2354 :DEVICE 16777232 :INODE 1560113207 :MTIME 1793207956 :SHA256
   "58868971b56c4d2f1d361b130473e3b297a1ede65f59e486792f0371f97ce0b1")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/bench/2416400535ca0410ad80515e5e4fffbe0cc699ce81f5d2d8b05eefec39ad977b/result.lisp"
   :BYTES 18498 :DEVICE 16777232 :INODE 1560113208 :MTIME 1793207956 :SHA256
   "4debdfeb8f3ff0ed2992e4f97f7ebdc3106fdf59b4fa60d85864e3ff33a8c39d")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/manifest.lisp"
   :BYTES 9088 :DEVICE 16777232 :INODE 1560113211 :MTIME 1793207956 :SHA256
   "0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/child-result.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1560113213 :MTIME 1793207956 :SHA256
   "d17adea94de0bdd50664afbd32cf16ad712e173856c2b6f3ca15d5765385bbc0")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/child-result.lisp.gz"
   :BYTES 34223 :DEVICE 16777232 :INODE 1560113214 :MTIME 1793207956 :SHA256
   "855de8e4929f2e6d3975713270268408c0a72a552f31a470d103b81c3a3d1864")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/commands/job/conservazione.lisp"
   :BYTES 1093 :DEVICE 16777232 :INODE 1560113217 :MTIME 1793207956 :SHA256
   "37eb3ff1f962edbadef774171dffd0839c42e638015ea1b0a6e09797d3f26a18")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1560113218 :MTIME 1793207956 :SHA256
   "c5c61eea6b53a08c3d146eba0f22c93de9a37db1f16e80284ba6e0b869c08fba")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/commands/job/report.lisp.gz"
   :BYTES 93945 :DEVICE 16777232 :INODE 1560113219 :MTIME 1793207956 :SHA256
   "bc178b3860c97620c07991923518b96cbecfe6214e48b4cfc328a0e6ad9714ba")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage-tests.events.lisp"
   :BYTES 327 :DEVICE 16777232 :INODE 1560113220 :MTIME 1793207956 :SHA256
   "389cfb82f9c42ef2e05f4513eb35feb8a74b8699401ce9b413f0b983800f3e2d")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage-tests.events.lisp.gz"
   :BYTES 114241 :DEVICE 16777232 :INODE 1560113221 :MTIME 1793207956 :SHA256
   "b1d00938ef3ba4d92a71f0d6348b019a2697e862b64dfd46261e43b089700a7d")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage-tests.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1560113222 :MTIME 1793207956 :SHA256
   "6ef1b8af33351145abaf7b5b3d803feae87d40cd0fa0103ec9b78317c138de0c")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage-tests.lisp.gz"
   :BYTES 53845 :DEVICE 16777232 :INODE 1560113223 :MTIME 1793207956 :SHA256
   "f59af6402033e553bf8097d61d826fc8337cba97b7c4976e1eeec2fb398563a2")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage.expected.lisp"
   :BYTES 320 :DEVICE 16777232 :INODE 1560113224 :MTIME 1793207956 :SHA256
   "a2afdb3aee4caa568ed150843077baefb4a39cf20fcdae2d097514bdca4bd592")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage.expected.lisp.gz"
   :BYTES 14558 :DEVICE 16777232 :INODE 1560113225 :MTIME 1793207956 :SHA256
   "efb29c07ac8a8635a9a6cc6e27f3157a094e61c066c36f8bb1b251807399d6d5")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage.lcov"
   :BYTES 312 :DEVICE 16777232 :INODE 1560113226 :MTIME 1793207956 :SHA256
   "b6fb720d54d9392cb965c646209046d2d170f44afa1abf757f15f421aa56e332")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage.lcov.gz"
   :BYTES 31314 :DEVICE 16777232 :INODE 1560113227 :MTIME 1793207956 :SHA256
   "6a1c4ea8db60908585705b69c101a6c24f75a1637eb177a6ca291d0ba5008784")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage.lisp"
   :BYTES 312 :DEVICE 16777232 :INODE 1560113228 :MTIME 1793207956 :SHA256
   "3be63b1c010b7b41978947dde7dcb9652e5ff5f178a7064f71ad4bc17d9e14a0")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage.lisp.gz"
   :BYTES 34223 :DEVICE 16777232 :INODE 1560113229 :MTIME 1793207956 :SHA256
   "855de8e4929f2e6d3975713270268408c0a72a552f31a470d103b81c3a3d1864")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage.stderr.log"
   :BYTES 320 :DEVICE 16777232 :INODE 1560113230 :MTIME 1793207956 :SHA256
   "0dec7a4357a38afd81dcb249287e853cb1e8f3215904b5373522fac9ca520796")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage.stderr.log.gz"
   :BYTES 131027 :DEVICE 16777232 :INODE 1560113231 :MTIME 1793207956 :SHA256
   "1b052d280989f647816b06943cdebda2ff03c93f94e2b618e1525a123d6a1e75")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage.stdout.log"
   :BYTES 318 :DEVICE 16777232 :INODE 1560113232 :MTIME 1793207956 :SHA256
   "44afee59337ed01f41a542aae91cc71dafab0eaa8ce02df69f2679b3096f5252")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/coverage.stdout.log.gz"
   :BYTES 54821 :DEVICE 16777232 :INODE 1560113233 :MTIME 1793207956 :SHA256
   "8093d69121e59b9466849cad801370d1f70da86dc4d8804ab661c07a5e75771e")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1560113234 :MTIME 1793207956 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560113235 :MTIME 1793207956 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/raw/job-driver.stdout"
   :BYTES 384 :DEVICE 16777232 :INODE 1560113236 :MTIME 1793207956 :SHA256
   "fbd9da41edbd865da7da3f183c75d029b91547faeea7e4670df8e1381d20c1ec")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/coverage/0c833318c499a0f66c633eba3f394f7a38d8558e2e97b392bfdc7eec2ea6bb90/result.lisp"
   :BYTES 8777 :DEVICE 16777232 :INODE 1560113237 :MTIME 1793207956 :SHA256
   "55625a7753c68bf59dd4fd9133eac84c2a8f17caf7ea7e0bbb7c0c18c117be6a")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/plan/612020ea375ac54cf57a66d2ac270da2808b18dd7562b9bc4fc532878f75b745/manifest.lisp"
   :BYTES 5564 :DEVICE 16777232 :INODE 1560113240 :MTIME 1793207956 :SHA256
   "612020ea375ac54cf57a66d2ac270da2808b18dd7562b9bc4fc532878f75b745")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/plan/612020ea375ac54cf57a66d2ac270da2808b18dd7562b9bc4fc532878f75b745/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1560113242 :MTIME 1793207956 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/plan/612020ea375ac54cf57a66d2ac270da2808b18dd7562b9bc4fc532878f75b745/raw/sources.lisp"
   :BYTES 308 :DEVICE 16777232 :INODE 1560113243 :MTIME 1793207956 :SHA256
   "703c8d3e39568c8ff5825511df2816b78bbc12825d9fd29419dd15e30310d22a")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/plan/612020ea375ac54cf57a66d2ac270da2808b18dd7562b9bc4fc532878f75b745/raw/sources.lisp.gz"
   :BYTES 1142 :DEVICE 16777232 :INODE 1560113244 :MTIME 1793207956 :SHA256
   "9774bc188a867feb1c5b0f7d3acfadb16e810bad0bdae30d8492544cd28162c8")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/plan/612020ea375ac54cf57a66d2ac270da2808b18dd7562b9bc4fc532878f75b745/result.lisp"
   :BYTES 9689 :DEVICE 16777232 :INODE 1560113245 :MTIME 1793207956 :SHA256
   "5f5fd9edd5f915337cfeb4ac0ca6aca22be86b6f14d0fa8b314cf944448a9ebb")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/manifest.lisp"
   :BYTES 7531 :DEVICE 16777232 :INODE 1560113248 :MTIME 1793207956 :SHA256
   "5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/child-result.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1560113250 :MTIME 1793207956 :SHA256
   "d793700aa0e848dd88ef7ae4a75ad37e57b39ff4099014791240622b15c28560")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/child-result.lisp.gz"
   :BYTES 53652 :DEVICE 16777232 :INODE 1560113251 :MTIME 1793207956 :SHA256
   "558dad15eb665f24fcda5631e0ddb06ec50077056636ee92b1e73386357298fb")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/commands/job/conservazione.lisp"
   :BYTES 1101 :DEVICE 16777232 :INODE 1560113254 :MTIME 1793207956 :SHA256
   "9c45e53b32ea3f80a6d71c32206e36d7aa2706817c18b52f7e99a249d96c5cb5")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/commands/job/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1560113255 :MTIME 1793207956 :SHA256
   "ee00470024041e3de51534085c32c078b1448b730365ff5378b7f2453470e7ce")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/commands/job/report.lisp.gz"
   :BYTES 134796 :DEVICE 16777232 :INODE 1560113256 :MTIME 1793207956 :SHA256
   "495297522efe4c22cef34d6d04473f0211d93b7ab73c59609779c154ebaa0386")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1560113257 :MTIME 1793207956 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560113258 :MTIME 1793207956 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/job-driver.stdout"
   :BYTES 396 :DEVICE 16777232 :INODE 1560113259 :MTIME 1793207956 :SHA256
   "83aa6a2dbdb771bcdab7ab4964bb2a481512e43fc7d1defa771b0da44153a703")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/tests.events.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1560113260 :MTIME 1793207956 :SHA256
   "63d7a5a16a82cb05901b99a0ecfabe3140b27a341457dea7a13bea74abda901a")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/tests.events.lisp.gz"
   :BYTES 113674 :DEVICE 16777232 :INODE 1560113261 :MTIME 1793207956 :SHA256
   "6b52dae615c132da2663fe2d4e0336d29c0f8f8ed8f2932a26d79dd142b6ed86")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/tests.expected.lisp"
   :BYTES 315 :DEVICE 16777232 :INODE 1560113262 :MTIME 1793207956 :SHA256
   "a9cf6ab1a8acdb8fe219bc8070dbc804d5ef8d32fe3960e009b0eb72b2b573ac")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/tests.expected.lisp.gz"
   :BYTES 1074 :DEVICE 16777232 :INODE 1560113263 :MTIME 1793207956 :SHA256
   "c6aaf4f6cda812bbbe4f490e26608a43801f250d98d7fe26dd7d0ca0d8ee3bdc")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/tests.lisp"
   :BYTES 309 :DEVICE 16777232 :INODE 1560113264 :MTIME 1793207956 :SHA256
   "269a4838bfa601905eac06fae0032cd9b44ab22b74c88940916ffe6b731ee7af")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/raw/tests.lisp.gz"
   :BYTES 53652 :DEVICE 16777232 :INODE 1560113265 :MTIME 1793207956 :SHA256
   "558dad15eb665f24fcda5631e0ddb06ec50077056636ee92b1e73386357298fb")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-linux/5a41cda9eb81fe23d72e9ceab6d329ec1aaa84e7ffc7a26930c73838c12f1b41/result.lisp"
   :BYTES 5546 :DEVICE 16777232 :INODE 1560113266 :MTIME 1793207956 :SHA256
   "1685205f51151e232e74b6d69e12354d2af1634231b77ef41ad8b890a29c670d")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/manifest.lisp"
   :BYTES 7532 :DEVICE 16777232 :INODE 1560113269 :MTIME 1793207956 :SHA256
   "72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/child-result.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1560113271 :MTIME 1793207956 :SHA256
   "8425689a16f93388fc9ef6938f3a566388c47c60c25aeb6eedb1cb8d194f708f")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/child-result.lisp.gz"
   :BYTES 59731 :DEVICE 16777232 :INODE 1560113272 :MTIME 1793207956 :SHA256
   "673c3059f2d3d6c4a365f7cc5ae64862e33b9c1a72a35a3587488a0ec4c1e548")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/commands/job/conservazione.lisp"
   :BYTES 1106 :DEVICE 16777232 :INODE 1560113275 :MTIME 1793207956 :SHA256
   "e460d55d62df42b62da6fdbf731945404156638f146a3c7fa778ab8912d75deb")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/commands/job/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1560113276 :MTIME 1793207956 :SHA256
   "e2df865682c3beaa8ffd41c76006a45f984839644748bb136170f876b0c58b94")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/commands/job/report.lisp.gz"
   :BYTES 135835 :DEVICE 16777232 :INODE 1560113277 :MTIME 1793207956 :SHA256
   "5c879f7506cafafdec23d8fe26847e7d49a3530ff6c7b465bc7fdaaa23456d96")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/installation.lisp"
   :BYTES 593 :DEVICE 16777232 :INODE 1560113278 :MTIME 1793207956 :SHA256
   "1125c4d32371ed7c1990f6a43465c0256f7b743e13b943a6a15efaa71cb802c7")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560113279 :MTIME 1793207956 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/job-driver.stdout"
   :BYTES 400 :DEVICE 16777232 :INODE 1560113280 :MTIME 1793207956 :SHA256
   "ecd348bc8ddd63748b140fe977b1f92355cf37e8486fdbc5cac320db1e301f0e")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/tests.events.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1560113281 :MTIME 1793207956 :SHA256
   "6fef1e5ca8e5bc589f0d85364e4fdff2e61db28752445781935f89f95a1ce1e9")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/tests.events.lisp.gz"
   :BYTES 129171 :DEVICE 16777232 :INODE 1560113282 :MTIME 1793207956 :SHA256
   "ffc6a069fa3b06824779a46083fec1f5139cd74692cfe41dd04f9a9a317f56c9")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/tests.expected.lisp"
   :BYTES 315 :DEVICE 16777232 :INODE 1560113283 :MTIME 1793207956 :SHA256
   "a9cf6ab1a8acdb8fe219bc8070dbc804d5ef8d32fe3960e009b0eb72b2b573ac")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/tests.expected.lisp.gz"
   :BYTES 1074 :DEVICE 16777232 :INODE 1560113284 :MTIME 1793207956 :SHA256
   "c6aaf4f6cda812bbbe4f490e26608a43801f250d98d7fe26dd7d0ca0d8ee3bdc")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/tests.lisp"
   :BYTES 309 :DEVICE 16777232 :INODE 1560113285 :MTIME 1793207956 :SHA256
   "2a265278d5c39659310cf0f4acdb841d99fa22a8654b4e3518a89c5e5ab69530")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/raw/tests.lisp.gz"
   :BYTES 59731 :DEVICE 16777232 :INODE 1560113286 :MTIME 1793207956 :SHA256
   "673c3059f2d3d6c4a365f7cc5ae64862e33b9c1a72a35a3587488a0ec4c1e548")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/payloads/verify-macos/72b0dcc3af074ffc6f6f1f823b4f1de690ae7509afc0265dc2c40b74019f6616/result.lisp"
   :BYTES 5551 :DEVICE 16777232 :INODE 1560113287 :MTIME 1793207956 :SHA256
   "df03809d8a4336abccf3e372b01f38adc7ce74af280b3132db8f10ff2fd8e7ca")
  (:PATH
   "spikes/results/ci/by-source/33e0fe156a55b860abbb6583d56373182a90d8c6de91ca6d6ee2e823b42257be/runs/40023181339/1/publications/5f8995d4cd19e3161113b6c5944ba383781394964a8314f3fb22440ccc50e45e.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113289 :MTIME 1793207956 :SHA256
   "50140712b065e25696e9a10c70377ce7f0df7486abb1f241be907680cbc5107c")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38132589293/1/collections/9132ed6bd72c01078b5592bcad9a92a2aa908b47cdb8be8a77f3cdcb5d490c37/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113296 :MTIME 1793207956 :SHA256
   "b21405c001a41337c98acd9717a8bef1c6a31a0111003b2fd7ae68c70aee6c72")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38132589293/1/collections/9132ed6bd72c01078b5592bcad9a92a2aa908b47cdb8be8a77f3cdcb5d490c37/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113297 :MTIME 1793207956 :SHA256
   "6a00527d1a6103be830a83350b299420b859b91d6c2ec963a04d2416ccfee8d4")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38132589293/1/collections/9132ed6bd72c01078b5592bcad9a92a2aa908b47cdb8be8a77f3cdcb5d490c37/summary.lisp"
   :BYTES 3954 :DEVICE 16777232 :INODE 1560113298 :MTIME 1793207956 :SHA256
   "f6badeef0a155c52449454e1b2db738bfc73a84603e97addd4280cd6dd5a88c3")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38132589293/1/collections/f7eaf581326b965d87e737309840ad87ff81a9deae98d412b8f667f91c113fd2/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113300 :MTIME 1793207956 :SHA256
   "9c6d364994bcd86599c740ae3cbd0fb4859803a8398ca9ea5d5c987803664f2c")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38132589293/1/collections/f7eaf581326b965d87e737309840ad87ff81a9deae98d412b8f667f91c113fd2/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113301 :MTIME 1793207956 :SHA256
   "6a00527d1a6103be830a83350b299420b859b91d6c2ec963a04d2416ccfee8d4")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38132589293/1/collections/f7eaf581326b965d87e737309840ad87ff81a9deae98d412b8f667f91c113fd2/summary.lisp"
   :BYTES 3960 :DEVICE 16777232 :INODE 1560113302 :MTIME 1793207956 :SHA256
   "92fbaf411b2ed226ed24529376a9c6ee1c98b98fd180a7944b5575fa40baf118")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38132589293/1/publications/53c2b6f636ca8cd86d6a06aecb27fc6317ff0364bb8d9a1849ab4451e5e1a605.lisp"
   :BYTES 736 :DEVICE 16777232 :INODE 1560113304 :MTIME 1793207956 :SHA256
   "12cb267f41c99390aff1ce5aed642166e7887d0d4062c1c8de9257412ed79426")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38132589293/1/publications/8068a93946d5da582b4a2ecc26870bc54d0a8ae9d2bea193c18a8f7d2b235386.lisp"
   :BYTES 733 :DEVICE 16777232 :INODE 1560113305 :MTIME 1793207956 :SHA256
   "10c6ecf9bfaa049213d7ad1a9c5894709653fd1d38091bcbb163bfee23150200")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38133330198/1/collections/05060823424fa0ecfeb5ff6f003e6e7fac9e99a9410694468e2d4c6e2874e47f/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113310 :MTIME 1793207956 :SHA256
   "d6d8a6f5499a12767c01aeb0be570003a07591fb2ac2c8cdfd155cbd890c3df5")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38133330198/1/collections/05060823424fa0ecfeb5ff6f003e6e7fac9e99a9410694468e2d4c6e2874e47f/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113311 :MTIME 1793207956 :SHA256
   "6441e9864dd33cae84a48b521790b782d3e43333d16a6ae84ebaa4c18164a46d")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38133330198/1/collections/05060823424fa0ecfeb5ff6f003e6e7fac9e99a9410694468e2d4c6e2874e47f/summary.lisp"
   :BYTES 3905 :DEVICE 16777232 :INODE 1560113312 :MTIME 1793207956 :SHA256
   "b27ac7a99e0c770713246fa08f41a062329a639674955394929e82b34ffe5972")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38133330198/1/collections/51ed995cc3a27a6c5051b87824031fd598bbb52fc4c545240a8b1fe4330aa538/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113314 :MTIME 1793207956 :SHA256
   "92cdd260b3060814d2b1c1c93d37efa95f90a04f176979edd798cd3eded2af4f")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38133330198/1/collections/51ed995cc3a27a6c5051b87824031fd598bbb52fc4c545240a8b1fe4330aa538/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113315 :MTIME 1793207956 :SHA256
   "6441e9864dd33cae84a48b521790b782d3e43333d16a6ae84ebaa4c18164a46d")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38133330198/1/collections/51ed995cc3a27a6c5051b87824031fd598bbb52fc4c545240a8b1fe4330aa538/summary.lisp"
   :BYTES 3899 :DEVICE 16777232 :INODE 1560113316 :MTIME 1793207956 :SHA256
   "07e9076653684bcfbd44ad016eed1ff792d9dbe86f7afe1e0c7d90af145cb0ad")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38133330198/1/publications/1dcf5048ee3dd6ff3048fbfe9ebe3200424b407667afefac8b199b9ebfbe596e.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113318 :MTIME 1793207956 :SHA256
   "b5b210ba46ccf67e6623c4326fadad5c196754eb2e02e9d38fb398f9faf64806")
  (:PATH
   "spikes/results/ci/by-source/34aefc72e1ae24cdf937156eb89e6467e8d47fe7ab8887182590ba0d1beefb2a/runs/38133330198/1/publications/3604506c6e9073a4e1e18ac573f24b5571ff2e248382f1b84471e6ba7f6b4539.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113319 :MTIME 1793207956 :SHA256
   "2e30264ef5362a507209e7b5d7a0b3d9420bb45e43465684213550049dbd12ea")
  (:PATH
   "spikes/results/ci/by-source/353a7167fc14287ed5cb97c814b184b7c804cc37ca7c2bfe429aeb0ddc2aa320/runs/39020814042/1/collections/221e584b5973b37b272b697dc7e68a58af8d0735321488a2eaeb0f6c2476b85a/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113326 :MTIME 1793207956 :SHA256
   "a861f595cddd3363a91de823ffb59847fef8aa423963a45f5157d505cd76c087")
  (:PATH
   "spikes/results/ci/by-source/353a7167fc14287ed5cb97c814b184b7c804cc37ca7c2bfe429aeb0ddc2aa320/runs/39020814042/1/collections/221e584b5973b37b272b697dc7e68a58af8d0735321488a2eaeb0f6c2476b85a/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113327 :MTIME 1793207956 :SHA256
   "9bb557f65cb0a22f6ad0dcf3edd0eb26619e599eabc5a5f18d0642203f1ea281")
  (:PATH
   "spikes/results/ci/by-source/353a7167fc14287ed5cb97c814b184b7c804cc37ca7c2bfe429aeb0ddc2aa320/runs/39020814042/1/collections/221e584b5973b37b272b697dc7e68a58af8d0735321488a2eaeb0f6c2476b85a/summary.lisp"
   :BYTES 5555 :DEVICE 16777232 :INODE 1560113328 :MTIME 1793207956 :SHA256
   "b7dbf71f96472e73534f4188450b06779c572bf7a32773713b74927b3f1fe98b")
  (:PATH
   "spikes/results/ci/by-source/353a7167fc14287ed5cb97c814b184b7c804cc37ca7c2bfe429aeb0ddc2aa320/runs/39020814042/1/publications/9c3fb74ebdd2a6b27de072069c79e8e53e688d9f83e294df618bfc83e64598d6.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113330 :MTIME 1793207956 :SHA256
   "9653bc36ae29e93e23a9deda6509559aed0113f10d70282d164b63f448753895")
  (:PATH
   "spikes/results/ci/by-source/380a1ca7a4a3e636842a3f9d4c0ee839a6f6cf980f2652358e954b5f99d9b9c3/runs/38132152481/1/collections/285f5bb99c162b7c4e04da7c634f5ef2433f260b7f5a969c7d4d1958e8a71441/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113337 :MTIME 1793207956 :SHA256
   "7f48a84b70a45ba8a4eef18635051b48f3df9003f90c00ea845c70c94f2d6192")
  (:PATH
   "spikes/results/ci/by-source/380a1ca7a4a3e636842a3f9d4c0ee839a6f6cf980f2652358e954b5f99d9b9c3/runs/38132152481/1/collections/285f5bb99c162b7c4e04da7c634f5ef2433f260b7f5a969c7d4d1958e8a71441/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113338 :MTIME 1793207956 :SHA256
   "af1378f515b1e0641bbe92c3f0c1786c33eddd7dcfbfc3cdf22906b45c99c786")
  (:PATH
   "spikes/results/ci/by-source/380a1ca7a4a3e636842a3f9d4c0ee839a6f6cf980f2652358e954b5f99d9b9c3/runs/38132152481/1/collections/285f5bb99c162b7c4e04da7c634f5ef2433f260b7f5a969c7d4d1958e8a71441/summary.lisp"
   :BYTES 3899 :DEVICE 16777232 :INODE 1560113339 :MTIME 1793207956 :SHA256
   "52808cac6738115158c359a03c3293c2dbdd2af2f7873472781a7ad18b39a0f3")
  (:PATH
   "spikes/results/ci/by-source/380a1ca7a4a3e636842a3f9d4c0ee839a6f6cf980f2652358e954b5f99d9b9c3/runs/38132152481/1/collections/b6ca5312da876d7e31ce172352f7bb2c068af69f5086f3b26147fd9227a6b280/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113341 :MTIME 1793207956 :SHA256
   "790d437c496cc96d1ac3bcf8e54d7b7af851e52e9196281ffab8c0d908ec9b36")
  (:PATH
   "spikes/results/ci/by-source/380a1ca7a4a3e636842a3f9d4c0ee839a6f6cf980f2652358e954b5f99d9b9c3/runs/38132152481/1/collections/b6ca5312da876d7e31ce172352f7bb2c068af69f5086f3b26147fd9227a6b280/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113342 :MTIME 1793207956 :SHA256
   "af1378f515b1e0641bbe92c3f0c1786c33eddd7dcfbfc3cdf22906b45c99c786")
  (:PATH
   "spikes/results/ci/by-source/380a1ca7a4a3e636842a3f9d4c0ee839a6f6cf980f2652358e954b5f99d9b9c3/runs/38132152481/1/collections/b6ca5312da876d7e31ce172352f7bb2c068af69f5086f3b26147fd9227a6b280/summary.lisp"
   :BYTES 3905 :DEVICE 16777232 :INODE 1560113343 :MTIME 1793207956 :SHA256
   "abf7bc289c1caad50cfce0249db4f94e3b050b3c8da3c8203f4b95e78673bd71")
  (:PATH
   "spikes/results/ci/by-source/380a1ca7a4a3e636842a3f9d4c0ee839a6f6cf980f2652358e954b5f99d9b9c3/runs/38132152481/1/publications/237f44a79b3b50be2699cd5acac28b318fdf8c3ed2bcd493887a5afcdf41ce3a.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113345 :MTIME 1793207956 :SHA256
   "2db29542f7fc4898d313ce1061e7290677687257b4e6c18741a55b306041bc38")
  (:PATH
   "spikes/results/ci/by-source/380a1ca7a4a3e636842a3f9d4c0ee839a6f6cf980f2652358e954b5f99d9b9c3/runs/38132152481/1/publications/a1ac1bfa2fb19350f1c5066004be989237d2abc3d1278e1624d49afcade9da4b.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113346 :MTIME 1793207956 :SHA256
   "d9802fb997ea4f47504f57c8ffa38820a06560f7d520541a0dcdf9fdbcc4f74e")
  (:PATH
   "spikes/results/ci/by-source/38193b58f070c47a226da0640b8f18425df5538c29425c1c87f750efb21e156e/runs/38802880664/1/collections/c69cabc6806a8076b76c068d7af895406801ab9335ddb2902635004386dd0630/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113353 :MTIME 1793207956 :SHA256
   "30ac1e94a903779b84a2be8efbe42903f19fbe6c038b0e813ba887bdaa3db98a")
  (:PATH
   "spikes/results/ci/by-source/38193b58f070c47a226da0640b8f18425df5538c29425c1c87f750efb21e156e/runs/38802880664/1/collections/c69cabc6806a8076b76c068d7af895406801ab9335ddb2902635004386dd0630/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113354 :MTIME 1793207956 :SHA256
   "df5303a9c9238f0cb6d5f7d2602f82abb764bc26971509545bc8b05103ae10a5")
  (:PATH
   "spikes/results/ci/by-source/38193b58f070c47a226da0640b8f18425df5538c29425c1c87f750efb21e156e/runs/38802880664/1/collections/c69cabc6806a8076b76c068d7af895406801ab9335ddb2902635004386dd0630/summary.lisp"
   :BYTES 5170 :DEVICE 16777232 :INODE 1560113355 :MTIME 1793207956 :SHA256
   "7884223e74292aa24c160f69e41f3ddf7c44f33796a27df5d1b16d7abce30b7d")
  (:PATH
   "spikes/results/ci/by-source/38193b58f070c47a226da0640b8f18425df5538c29425c1c87f750efb21e156e/runs/38802880664/1/publications/b753182df73db063b7d359fb1cce1baa5e55db0deb8b84b77c0046a01d665fde.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113357 :MTIME 1793207956 :SHA256
   "dee69ecb612661cc3ddb77f5fb4577d4c7e26d034adc4fa46a53eb08957daa47")
  (:PATH
   "spikes/results/ci/by-source/38fdf10b02b6687e4e7c9cb9cbb1f0a72659f255683131015b19ffff54ecd7ca/runs/38934649642/1/collections/9443d3b9db3ee04be17734f4792106807d4d4733c4a31cdb45cda21b1ae0ae80/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113364 :MTIME 1793207956 :SHA256
   "0a1520764bfc9aa7c010432c4dd7dfcc3ea1635882fc6d377cea51ea0604d272")
  (:PATH
   "spikes/results/ci/by-source/38fdf10b02b6687e4e7c9cb9cbb1f0a72659f255683131015b19ffff54ecd7ca/runs/38934649642/1/collections/9443d3b9db3ee04be17734f4792106807d4d4733c4a31cdb45cda21b1ae0ae80/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113365 :MTIME 1793207956 :SHA256
   "b31d9908ab4c94c8e457b2fa8d29d2f64391889b653cc64737c65532e9051009")
  (:PATH
   "spikes/results/ci/by-source/38fdf10b02b6687e4e7c9cb9cbb1f0a72659f255683131015b19ffff54ecd7ca/runs/38934649642/1/collections/9443d3b9db3ee04be17734f4792106807d4d4733c4a31cdb45cda21b1ae0ae80/summary.lisp"
   :BYTES 5276 :DEVICE 16777232 :INODE 1560113366 :MTIME 1793207956 :SHA256
   "24d4d159cdc22a0a63fa22158431e74c3cc622e392329dd478552702c5e7d925")
  (:PATH
   "spikes/results/ci/by-source/38fdf10b02b6687e4e7c9cb9cbb1f0a72659f255683131015b19ffff54ecd7ca/runs/38934649642/1/publications/a25c35b894ab06bbded51c5790cca92ae01374e3c45351e9edba5f0273cf8be1.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113368 :MTIME 1793207956 :SHA256
   "490ba4c0ff6ddb18d74299f73ea9b1fab3f936d25b127151f30c5f4a8e3f23f5")
  (:PATH
   "spikes/results/ci/by-source/3a1db5f7e9af9047b974eb172f1a0bc495ae5b2b2cff9eac5044a56dda89ed22/runs/38460052466/1/collections/4b6105853119c7573b3680b02bbd128b74136fa6d9b55ce68a0c38ee3b20cbe9/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113375 :MTIME 1793207956 :SHA256
   "7b124dc352332802a25a791f8fccc974823b911683447dfb22b6bcfffd7f119c")
  (:PATH
   "spikes/results/ci/by-source/3a1db5f7e9af9047b974eb172f1a0bc495ae5b2b2cff9eac5044a56dda89ed22/runs/38460052466/1/collections/4b6105853119c7573b3680b02bbd128b74136fa6d9b55ce68a0c38ee3b20cbe9/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113376 :MTIME 1793207956 :SHA256
   "cd96907be68603672a533d67b1dc30243427d6f9dda1384417372eac70909ccb")
  (:PATH
   "spikes/results/ci/by-source/3a1db5f7e9af9047b974eb172f1a0bc495ae5b2b2cff9eac5044a56dda89ed22/runs/38460052466/1/collections/4b6105853119c7573b3680b02bbd128b74136fa6d9b55ce68a0c38ee3b20cbe9/summary.lisp"
   :BYTES 4478 :DEVICE 16777232 :INODE 1560113377 :MTIME 1793207956 :SHA256
   "668dc7bcb91fcced2aa68e60c7d0bba3d65fe7c4720d6cfdb5bd1a60fb167ef6")
  (:PATH
   "spikes/results/ci/by-source/3a1db5f7e9af9047b974eb172f1a0bc495ae5b2b2cff9eac5044a56dda89ed22/runs/38460052466/1/collections/e0000dd2c7ac7cd84593b03db91102d6d06475f46c1182acc89b055d69c86417/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113379 :MTIME 1793207956 :SHA256
   "640195150ed5a021a57410340c8bbc4c4a8c43047251d13b694439c87953bc90")
  (:PATH
   "spikes/results/ci/by-source/3a1db5f7e9af9047b974eb172f1a0bc495ae5b2b2cff9eac5044a56dda89ed22/runs/38460052466/1/collections/e0000dd2c7ac7cd84593b03db91102d6d06475f46c1182acc89b055d69c86417/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113380 :MTIME 1793207956 :SHA256
   "cd96907be68603672a533d67b1dc30243427d6f9dda1384417372eac70909ccb")
  (:PATH
   "spikes/results/ci/by-source/3a1db5f7e9af9047b974eb172f1a0bc495ae5b2b2cff9eac5044a56dda89ed22/runs/38460052466/1/collections/e0000dd2c7ac7cd84593b03db91102d6d06475f46c1182acc89b055d69c86417/summary.lisp"
   :BYTES 4472 :DEVICE 16777232 :INODE 1560113381 :MTIME 1793207956 :SHA256
   "ad401206b848dbd0dfc2d63ecf014fda3011193d067ee4f5e39c72489d91a87e")
  (:PATH
   "spikes/results/ci/by-source/3a1db5f7e9af9047b974eb172f1a0bc495ae5b2b2cff9eac5044a56dda89ed22/runs/38460052466/1/publications/0a798ed16771f144ab2c44020fe5896605bc55cdf0cbe9b7c9936b50ca9234c0.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113383 :MTIME 1793207956 :SHA256
   "3a7572d20b9fdb9f9403173f2693181b2042115137e92988df11908b4dd36176")
  (:PATH
   "spikes/results/ci/by-source/3a1db5f7e9af9047b974eb172f1a0bc495ae5b2b2cff9eac5044a56dda89ed22/runs/38460052466/1/publications/7727a4218ea1567abac35453c7ca3646c316eddf91bd9cb0c07878ea094e4097.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113384 :MTIME 1793207956 :SHA256
   "d9e2d2a878ffffc0d1087c40d0ca4bd0eeedf774884879bd09f9078352272c87")
  (:PATH
   "spikes/results/ci/by-source/3aa40810da36b530b1485eb90c1e2e8185bb1562633bbb92ea21aa309f3fd313/runs/38602188241/1/collections/3fed002320bf3e7757ed95aca31bda4881394fcd2abe377584c6bf2e3a10ab7e/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113391 :MTIME 1793207956 :SHA256
   "5980d1301f902c827e481cef6fb34cd7a1958c96077b1583afe211043b7ab75a")
  (:PATH
   "spikes/results/ci/by-source/3aa40810da36b530b1485eb90c1e2e8185bb1562633bbb92ea21aa309f3fd313/runs/38602188241/1/collections/3fed002320bf3e7757ed95aca31bda4881394fcd2abe377584c6bf2e3a10ab7e/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113392 :MTIME 1793207956 :SHA256
   "86ea5293eaacefd7ad519fc4bc379384feaefc791ff297ba76481c608d2f741c")
  (:PATH
   "spikes/results/ci/by-source/3aa40810da36b530b1485eb90c1e2e8185bb1562633bbb92ea21aa309f3fd313/runs/38602188241/1/collections/3fed002320bf3e7757ed95aca31bda4881394fcd2abe377584c6bf2e3a10ab7e/summary.lisp"
   :BYTES 4760 :DEVICE 16777232 :INODE 1560113393 :MTIME 1793207956 :SHA256
   "90613af0e1d68fcff1081b25f0ecd6bafedee727d77cf75909733219af984f3a")
  (:PATH
   "spikes/results/ci/by-source/3aa40810da36b530b1485eb90c1e2e8185bb1562633bbb92ea21aa309f3fd313/runs/38602188241/1/collections/9a349936036c9cf1a4bf25265bb33b1981c32f244f69df27a539d90150570add/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113395 :MTIME 1793207956 :SHA256
   "f5b23dc7ab1baeed85fec31c495339fcdd320bf52f3db91be47085c421c915fd")
  (:PATH
   "spikes/results/ci/by-source/3aa40810da36b530b1485eb90c1e2e8185bb1562633bbb92ea21aa309f3fd313/runs/38602188241/1/collections/9a349936036c9cf1a4bf25265bb33b1981c32f244f69df27a539d90150570add/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113396 :MTIME 1793207956 :SHA256
   "86ea5293eaacefd7ad519fc4bc379384feaefc791ff297ba76481c608d2f741c")
  (:PATH
   "spikes/results/ci/by-source/3aa40810da36b530b1485eb90c1e2e8185bb1562633bbb92ea21aa309f3fd313/runs/38602188241/1/collections/9a349936036c9cf1a4bf25265bb33b1981c32f244f69df27a539d90150570add/summary.lisp"
   :BYTES 4754 :DEVICE 16777232 :INODE 1560113397 :MTIME 1793207956 :SHA256
   "79b29a531b567d6b005b0417cc948c61cc3502020e6b3e93a4b5463fbde5b24f")
  (:PATH
   "spikes/results/ci/by-source/3aa40810da36b530b1485eb90c1e2e8185bb1562633bbb92ea21aa309f3fd313/runs/38602188241/1/publications/2df06ca5ec815728e808bed930dc7d73ae1ccdba19a3aca5dbf4f2bce75e7622.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113399 :MTIME 1793207956 :SHA256
   "bc5e304d7d755346368c1b4636fbf4e01b5161320be7cd68de8d04bb26ac98dd")
  (:PATH
   "spikes/results/ci/by-source/3aa40810da36b530b1485eb90c1e2e8185bb1562633bbb92ea21aa309f3fd313/runs/38602188241/1/publications/c3ef0a32ba7be50d5532db686d4f060ae9b5343cc08a65f96b84a35c78071096.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113400 :MTIME 1793207956 :SHA256
   "402a48c8f852ac5a3edaf6ed7e6982782eca13a2eb1101a58e803a540671054d")
  (:PATH
   "spikes/results/ci/by-source/42d9991eeb406b28ff2a1eca03e01ad3adf7b6dee45b7ea51db5fa7a8d27d315/runs/38805049772/1/collections/9418a9973af1d9d5b7efaefbd542722c38115015d0c75a27497f58007c9588b5/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113407 :MTIME 1793207956 :SHA256
   "3ad5e533f1890d3fbfed0df22bf33bbb06866f7393733e6519fed84302f056bc")
  (:PATH
   "spikes/results/ci/by-source/42d9991eeb406b28ff2a1eca03e01ad3adf7b6dee45b7ea51db5fa7a8d27d315/runs/38805049772/1/collections/9418a9973af1d9d5b7efaefbd542722c38115015d0c75a27497f58007c9588b5/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113408 :MTIME 1793207956 :SHA256
   "a3d395f66cbaa65b9b6e7c13de722361cccacf78920a0b48443eac44e163097e")
  (:PATH
   "spikes/results/ci/by-source/42d9991eeb406b28ff2a1eca03e01ad3adf7b6dee45b7ea51db5fa7a8d27d315/runs/38805049772/1/collections/9418a9973af1d9d5b7efaefbd542722c38115015d0c75a27497f58007c9588b5/summary.lisp"
   :BYTES 5170 :DEVICE 16777232 :INODE 1560113409 :MTIME 1793207956 :SHA256
   "36cf70415448907fbd39ef7cb60a305434fb8941b4ba20d6f8282f7c6353ae5f")
  (:PATH
   "spikes/results/ci/by-source/42d9991eeb406b28ff2a1eca03e01ad3adf7b6dee45b7ea51db5fa7a8d27d315/runs/38805049772/1/publications/b670e28a53f746e8a3302cc19abf31c071d8b149c03b99b5f2c76ff06da1d797.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113411 :MTIME 1793207956 :SHA256
   "6482937dcd8bffb2bf887b6ce7569212874b63c3d31099a445ad5c87d1437393")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/collections/8b435aa39bd60d5231dcced57a3b3021b6f70537a7b0eb7e49c004cb0637e5b0/manifest.lisp"
   :BYTES 393 :DEVICE 16777232 :INODE 1548822487 :MTIME 1792696244 :SHA256
   "586cea60d623f448ef9cc03c692ed7326a9316c385356bbe083556caf550c6ab")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/collections/8b435aa39bd60d5231dcced57a3b3021b6f70537a7b0eb7e49c004cb0637e5b0/report.md"
   :BYTES 24365 :DEVICE 16777232 :INODE 1548822488 :MTIME 1792696244 :SHA256
   "8e46ccc41b126ba432bf5eb4c961c6a58b0853eb24a799675cf0eed558350ed2")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/collections/8b435aa39bd60d5231dcced57a3b3021b6f70537a7b0eb7e49c004cb0637e5b0/summary.lisp"
   :BYTES 29754 :DEVICE 16777232 :INODE 1548822489 :MTIME 1792696244 :SHA256
   "3e506fa4ebbe204c7aaba4e3fc864aeb031f394a1db4c41741189cd4e93c6354")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/manifest.lisp"
   :BYTES 9634 :DEVICE 16777232 :INODE 1548822493 :MTIME 1792696244 :SHA256
   "0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/c4-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1548822495 :MTIME 1792696244 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/c4-driver.stdout"
   :BYTES 113 :DEVICE 16777232 :INODE 1548822496 :MTIME 1792696244 :SHA256
   "accd85553cd1ff9661f469aea44b19c522417e9036085e7a8fa23a1a4f2649c0")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/child-result.lisp"
   :BYTES 3313 :DEVICE 16777232 :INODE 1548822497 :MTIME 1792696244 :SHA256
   "c2c15018963e18a7ef059c81c12beb0c2e178ca0bb3e9c9738ba6df715fa6cc0")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/c4/conservazione.lisp"
   :BYTES 1085 :DEVICE 16777232 :INODE 1548822500 :MTIME 1792696244 :SHA256
   "5bf271e036d9d8040237c61ef116b946908790c0da8eeeaf974b405996240e13")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/c4/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1548822501 :MTIME 1792696244 :SHA256
   "9cc89921396d460320f456f4892fffc45a1d930e6498ecaebf9fb6c188db91da")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/c4/report.lisp.gz"
   :BYTES 99233 :DEVICE 16777232 :INODE 1548822502 :MTIME 1792696244 :SHA256
   "1cdd6bda31fbb4f3aeeaa09db7480e312db854cea96e3ee55f47406fb70d15e0")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/job/conservazione.lisp"
   :BYTES 1087 :DEVICE 16777232 :INODE 1548822504 :MTIME 1792696244 :SHA256
   "72c24242ce835afc5a9fd989dc4e5e047eb71c3811125c0ef8162eab0ae1cbfc")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1548822505 :MTIME 1792696244 :SHA256
   "522ac101efb8c5ca048e94d200a4807a923ff58545326e20c640084bfa48db5c")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/job/report.lisp.gz"
   :BYTES 87951 :DEVICE 16777232 :INODE 1548822506 :MTIME 1792696244 :SHA256
   "664ebe0a603e06247c858ce54bb826a9a51fe0f85b56dd03527f1c1c71a3aa11")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/links/conservazione.lisp"
   :BYTES 1091 :DEVICE 16777232 :INODE 1548822508 :MTIME 1792696244 :SHA256
   "8e767b347f14c87e932ed47a9d28e94726122f83406e08c0277349ea49d11b61")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/links/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1548822509 :MTIME 1792696244 :SHA256
   "d55b4e102300f4ff4900f61bf63d250df507951cb98268f725ff6b0026c53960")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/links/report.lisp.gz"
   :BYTES 87943 :DEVICE 16777232 :INODE 1548822510 :MTIME 1792696244 :SHA256
   "cd3b1d25dbb39aff53864167154bc90183b6c1e3ec0471f74896dcacff3eb9c6")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/lint/conservazione.lisp"
   :BYTES 1089 :DEVICE 16777232 :INODE 1548822512 :MTIME 1792696244 :SHA256
   "536f7e0d05785ea361f57e836fe1b2b3a1227040bda86e5276968d12bed2fa7f")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/lint/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1548822513 :MTIME 1792696244 :SHA256
   "62d5f1af7e9e47a0be0023805674458c76697d4f50d9c6dac343dcc337926193")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/lint/report.lisp.gz"
   :BYTES 87937 :DEVICE 16777232 :INODE 1548822514 :MTIME 1792696244 :SHA256
   "58a6e8e462ab84ad801a061e6b881938eeafa54067418dbd3b72a7e886a4b60c")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/trace/conservazione.lisp"
   :BYTES 1091 :DEVICE 16777232 :INODE 1548822516 :MTIME 1792696244 :SHA256
   "9fce7e6eda6f1e0de9d8fba6c1f317d47e18efdd1305d32ee92b3e39905ed9fb")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/trace/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1548822517 :MTIME 1792696244 :SHA256
   "50db0f88d4de400ec4d32facca33335fc62e7226fac3ce5232b26c61d45e1299")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/commands/trace/report.lisp.gz"
   :BYTES 87961 :DEVICE 16777232 :INODE 1548822518 :MTIME 1792696244 :SHA256
   "6f17ec7d470e5532e754a344a1bc394b89f8fecc9cf32eb3fc56d48f837260eb")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1548822519 :MTIME 1792696244 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1548822520 :MTIME 1792696244 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/job-driver.stdout"
   :BYTES 375 :DEVICE 16777232 :INODE 1548822521 :MTIME 1792696244 :SHA256
   "25d75919482305ba7bb4858c24c98e433de270bd9653d1350220ef2123f799b2")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/links-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1548822522 :MTIME 1792696244 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/links-driver.stdout"
   :BYTES 321 :DEVICE 16777232 :INODE 1548822523 :MTIME 1792696244 :SHA256
   "925437b5af7e04ef72e3fe79f70734fad01ea0b897d780472faea1b9ab16fc73")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/links.lisp"
   :BYTES 181 :DEVICE 16777232 :INODE 1548822524 :MTIME 1792696244 :SHA256
   "ab9e0df04b3b22e09c2114c761f2df76049398165e6e6d2749759b736796d144")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/lint-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1548822525 :MTIME 1792696244 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/lint-driver.stdout"
   :BYTES 314 :DEVICE 16777232 :INODE 1548822526 :MTIME 1792696244 :SHA256
   "d36474ff4993eee0312d4caf5a266df1d370971e95d9ffd6d5b1c44e1d2eb454")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/lint.lisp"
   :BYTES 354 :DEVICE 16777232 :INODE 1548822527 :MTIME 1792696244 :SHA256
   "f866bfce2bad314a8d91411cc338ff4aa6b8f754df31d01647c0ebb7c573030d")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/trace-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1548822528 :MTIME 1792696244 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/trace-driver.stdout"
   :BYTES 319 :DEVICE 16777232 :INODE 1548822529 :MTIME 1792696244 :SHA256
   "a5d8ec00c1897b16a22c693e127aa1782b335516662b8b379c7959c0f4879520")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/raw/trace.lisp"
   :BYTES 1607 :DEVICE 16777232 :INODE 1548822530 :MTIME 1792696244 :SHA256
   "63849bc5c8b6d45d74170f914d59f5b91b9853cc7f83e1b910a6d9faf7ad1ef0")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/audit/0215513f1ad102c5e3fd299a02dc05815b1c050b0329e107f21f5496d9279946/result.lisp"
   :BYTES 8525 :DEVICE 16777232 :INODE 1548822531 :MTIME 1792696244 :SHA256
   "8c656fc05be7a14c2358792b33a42d7898ee9347dd12b796ee7a29a2851f3286")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/manifest.lisp"
   :BYTES 7665 :DEVICE 16777232 :INODE 1548822534 :MTIME 1792696244 :SHA256
   "dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/child-result.lisp"
   :BYTES 25300 :DEVICE 16777232 :INODE 1548822536 :MTIME 1792696244 :SHA256
   "cd33ec329a816a8263024abeb3a08a085d3985eb7c3ff77e89a70962effe6a09")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/commands/job/conservazione.lisp"
   :BYTES 1087 :DEVICE 16777232 :INODE 1548822539 :MTIME 1792696244 :SHA256
   "7041cc0d82650c8f323e2cbe4415a8e8b1c4e364e3b9648311ffad329f2f16e6")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1548822540 :MTIME 1792696244 :SHA256
   "50db60689c88fe6b3e795f3f0ba9f3114d9d6a3d8f1c9f0f905843dc1a95e968")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/commands/job/report.lisp.gz"
   :BYTES 87950 :DEVICE 16777232 :INODE 1548822541 :MTIME 1792696244 :SHA256
   "a54005781bc579c14a39b2482111b4b9de2aebe47dc2bd0f14530bb0979c95ad")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/coordinator-identity.lisp"
   :BYTES 212 :DEVICE 16777232 :INODE 1548822542 :MTIME 1792696244 :SHA256
   "a5f63755f46d5625188fce59a197afadc5823ceb9b5a6cacec1f9e344116520d")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1548822543 :MTIME 1792696244 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1548822544 :MTIME 1792696244 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/job-driver.stdout"
   :BYTES 375 :DEVICE 16777232 :INODE 1548822545 :MTIME 1792696244 :SHA256
   "f26080a6ceeaf0d9089a4c84a485bb7548a4fcdf8f929e5747fa05d4c5ca0d02")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/measure-replica-01.lisp"
   :BYTES 2124 :DEVICE 16777232 :INODE 1548822546 :MTIME 1792696244 :SHA256
   "192950a6438118e20d80b8dcbd17504d7797dc136ac45ee41104b2d0b74866ca")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/measure-replica-01.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1548822547 :MTIME 1792696244 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/measure-replica-02.lisp"
   :BYTES 2125 :DEVICE 16777232 :INODE 1548822548 :MTIME 1792696244 :SHA256
   "5d23c20eecdcd51f932ee072288884934c1f83ffc8e687be0c5284e0cc597592")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/measure-replica-02.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1548822549 :MTIME 1792696244 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/measure-replica-03.lisp"
   :BYTES 2124 :DEVICE 16777232 :INODE 1548822550 :MTIME 1792696244 :SHA256
   "91c3f58424121e895c0f80bef4c5ac4a6798d40f9fd7ba7f751065da8d362a84")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/measure-replica-03.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1548822551 :MTIME 1792696244 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/measure-replica-04.lisp"
   :BYTES 2124 :DEVICE 16777232 :INODE 1548822552 :MTIME 1792696244 :SHA256
   "100e42b14f4faef2808b999cc088cb0f36478b6890873edf53e4850bb19554c3")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/measure-replica-04.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1548822553 :MTIME 1792696244 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/measure-replica-05.lisp"
   :BYTES 2124 :DEVICE 16777232 :INODE 1548822554 :MTIME 1792696244 :SHA256
   "4b360e3bb4c6d215b5a960cd8694525f849887e806f6a14fc9346cb96bbc7599")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/measure-replica-05.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1548822555 :MTIME 1792696244 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/raw/measure.lisp"
   :BYTES 25300 :DEVICE 16777232 :INODE 1548822556 :MTIME 1792696244 :SHA256
   "cd33ec329a816a8263024abeb3a08a085d3985eb7c3ff77e89a70962effe6a09")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/bench/dbe789df4d4110f5dcf3504bbc7c90daa59e62271b236d18e241d8c070c3fba7/result.lisp"
   :BYTES 18397 :DEVICE 16777232 :INODE 1548822557 :MTIME 1792696244 :SHA256
   "9f8365060d2c6d47d77cbdfe9e6ca7ae0aecab0b9aca2c7bd310d89aa617760e")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/manifest.lisp"
   :BYTES 8672 :DEVICE 16777232 :INODE 1548822560 :MTIME 1792696244 :SHA256
   "b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/child-result.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1548822562 :MTIME 1792696244 :SHA256
   "affa33af6843afe35bfdd8b7764e754265c4ed17c0f9a0c9b647b04cfb9fbe6f")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/child-result.lisp.gz"
   :BYTES 30978 :DEVICE 16777232 :INODE 1548822563 :MTIME 1792696244 :SHA256
   "1529d9cd49b8c051d4158458c261f66e854fddddb465d01c97af7bd59b312f4b")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/commands/job/conservazione.lisp"
   :BYTES 1093 :DEVICE 16777232 :INODE 1548822566 :MTIME 1792696244 :SHA256
   "9ccf0109ec78b896611474d129db311cf6557b8307dba03d9668aaacd22cf512")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1548822567 :MTIME 1792696244 :SHA256
   "1706a0d4ca761aad727c96a0b8244f8321f1ad43655529194982e582a76e5773")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/commands/job/report.lisp.gz"
   :BYTES 87956 :DEVICE 16777232 :INODE 1548822568 :MTIME 1792696244 :SHA256
   "ddad3cca67c1a28655c2317656bef9d00cbad56c1311e183a49de260643f96a4")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/coverage-tests.events.lisp"
   :BYTES 327 :DEVICE 16777232 :INODE 1548822569 :MTIME 1792696244 :SHA256
   "920f3832c095cdad83ec73d689ae6a8482c418a050cf361809c4f41a1fdb7f44")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/coverage-tests.events.lisp.gz"
   :BYTES 108335 :DEVICE 16777232 :INODE 1548822570 :MTIME 1792696244 :SHA256
   "6c66de508fd7453b02f164a3c961851e319db929b832a77a24d4057d157bef47")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/coverage-tests.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1548822571 :MTIME 1792696244 :SHA256
   "d4f558e8cb84b4a7f9c2ef1d60f9c425d16c89d9c951368d64ea7831d1ba15a3")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/coverage-tests.lisp.gz"
   :BYTES 51181 :DEVICE 16777232 :INODE 1548822572 :MTIME 1792696244 :SHA256
   "714214cfcc1047c5d3864e3847f0c07d7b03d0f011c9e9880cdd57a5ad3bad3c")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/coverage.expected.lisp"
   :BYTES 48465 :DEVICE 16777232 :INODE 1548822573 :MTIME 1792696244 :SHA256
   "bd88dd8cbe9dc7b8a189b19502a0236c0bf748916e59c41de2156ee0791e007d")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/coverage.lcov"
   :BYTES 312 :DEVICE 16777232 :INODE 1548822574 :MTIME 1792696244 :SHA256
   "96cea67ce52004a6157fdf79deb4eb6475799e84771f03b80e3c9cbe47af5d9c")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/coverage.lcov.gz"
   :BYTES 25791 :DEVICE 16777232 :INODE 1548822575 :MTIME 1792696244 :SHA256
   "bd533eb52206f793ddedea1ed59f3048260b0bbcfe7d918351feae7433c1fc66")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/coverage.lisp"
   :BYTES 312 :DEVICE 16777232 :INODE 1548822576 :MTIME 1792696244 :SHA256
   "c185a8288afe240eb55178caffe947666a584565f6e1c52f254774df5136b708")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/coverage.lisp.gz"
   :BYTES 30978 :DEVICE 16777232 :INODE 1548822577 :MTIME 1792696244 :SHA256
   "1529d9cd49b8c051d4158458c261f66e854fddddb465d01c97af7bd59b312f4b")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/coverage.stderr.log"
   :BYTES 320 :DEVICE 16777232 :INODE 1548822578 :MTIME 1792696244 :SHA256
   "ca720e600978509801c1d56c329df320fbeadda7057b059d4abadd35a4be6d72")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/coverage.stderr.log.gz"
   :BYTES 115158 :DEVICE 16777232 :INODE 1548822579 :MTIME 1792696244 :SHA256
   "631cfbeca0ff5edd0446a0f77006ce3cb22f23d4b4f94be2120346b805369a96")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/coverage.stdout.log"
   :BYTES 318 :DEVICE 16777232 :INODE 1548822580 :MTIME 1792696244 :SHA256
   "34b0d56f55145079005cbcb64f1b21354630244a6a6e6b966d1c436ba1889b96")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/coverage.stdout.log.gz"
   :BYTES 48168 :DEVICE 16777232 :INODE 1548822581 :MTIME 1792696244 :SHA256
   "5d971a0546182912db4527570beb326b4667d13f499aed995a901ca4ab1ff7c7")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1548822582 :MTIME 1792696244 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1548822583 :MTIME 1792696244 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/raw/job-driver.stdout"
   :BYTES 384 :DEVICE 16777232 :INODE 1548822584 :MTIME 1792696244 :SHA256
   "d8abd2a417a5b391df7f9181459539d882d424bdb667958025f2aa722254f6d3")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/coverage/b41005b70f1aaaaa645f55d4c1d7b3a1db37076fc77c5c17601ca9854dc87a1c/result.lisp"
   :BYTES 8001 :DEVICE 16777232 :INODE 1548822585 :MTIME 1792696244 :SHA256
   "e0582ef7ef30dc0cee60e06003ae6e0cdd34dde8711b93caa6a69c110c8df53b")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/plan/cd3a1a0582baf2127921331a40b891cf0d0a9b3c1a461bef30553d0a00a6db06/manifest.lisp"
   :BYTES 5159 :DEVICE 16777232 :INODE 1548822588 :MTIME 1792696244 :SHA256
   "cd3a1a0582baf2127921331a40b891cf0d0a9b3c1a461bef30553d0a00a6db06")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/plan/cd3a1a0582baf2127921331a40b891cf0d0a9b3c1a461bef30553d0a00a6db06/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1548822590 :MTIME 1792696244 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/plan/cd3a1a0582baf2127921331a40b891cf0d0a9b3c1a461bef30553d0a00a6db06/raw/sources.lisp"
   :BYTES 4552 :DEVICE 16777232 :INODE 1548822591 :MTIME 1792696244 :SHA256
   "5383afd7db4a2488b8f8522af083215dc34a60e0fbf613188a4fbfbb206175e8")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/plan/cd3a1a0582baf2127921331a40b891cf0d0a9b3c1a461bef30553d0a00a6db06/result.lisp"
   :BYTES 9353 :DEVICE 16777232 :INODE 1548822592 :MTIME 1792696244 :SHA256
   "5ffc326208e79aba96b39435865babda11b19a4d09856a5008e33748ba6114c3")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/manifest.lisp"
   :BYTES 7119 :DEVICE 16777232 :INODE 1548822595 :MTIME 1792696244 :SHA256
   "927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/raw/child-result.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1548822597 :MTIME 1792696244 :SHA256
   "45589e3f798f3268dabbf3797c5c13589a35cd4de3162ded313d09871e80b7fd")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/raw/child-result.lisp.gz"
   :BYTES 50738 :DEVICE 16777232 :INODE 1548822598 :MTIME 1792696244 :SHA256
   "0a088645431920573615efcc02ab809d473af2b2a95213e775dfd68269f23cf6")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/raw/commands/job/conservazione.lisp"
   :BYTES 1101 :DEVICE 16777232 :INODE 1548822601 :MTIME 1792696244 :SHA256
   "6a6bebd288cc9b8fb9d6bcd8565fa8663477f91699860d13c9b0f95792ed6157")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/raw/commands/job/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1548822602 :MTIME 1792696244 :SHA256
   "870dddb73a66fe89373682c899613d33a5a1485653a6f4f9f715330f1754ee43")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/raw/commands/job/report.lisp.gz"
   :BYTES 123311 :DEVICE 16777232 :INODE 1548822603 :MTIME 1792696244 :SHA256
   "cf964d5ff932f635f82c4f49deeb7c4319200d97817b7f9823423aafcbff7760")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1548822604 :MTIME 1792696244 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1548822605 :MTIME 1792696244 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/raw/job-driver.stdout"
   :BYTES 396 :DEVICE 16777232 :INODE 1548822606 :MTIME 1792696244 :SHA256
   "9e6424b751b2574c461eefd8c6f26d1134d930e588fd7f1ee840682f75019212")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/raw/tests.events.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1548822607 :MTIME 1792696244 :SHA256
   "35af3b0f791cd03287fc9c233fe5f9187db882f57ca82995780f837f56d2c54a")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/raw/tests.events.lisp.gz"
   :BYTES 107704 :DEVICE 16777232 :INODE 1548822608 :MTIME 1792696244 :SHA256
   "7d6523e5ac95abcb59a3ccf3b6da08fe1cbcd3873d2a3a4b171b7fdea9eb701b")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/raw/tests.expected.lisp"
   :BYTES 7570 :DEVICE 16777232 :INODE 1548822609 :MTIME 1792696244 :SHA256
   "e2bbc31a93c8cab3f1963e4c9ef5bbd071ef5d30e885670822c5db4f80e3d633")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/raw/tests.lisp"
   :BYTES 309 :DEVICE 16777232 :INODE 1548822610 :MTIME 1792696244 :SHA256
   "e83825f061060346435ebc2163a3ca78bd7fff5f6325b58538d8d4cb84487473")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/raw/tests.lisp.gz"
   :BYTES 50738 :DEVICE 16777232 :INODE 1548822611 :MTIME 1792696244 :SHA256
   "0a088645431920573615efcc02ab809d473af2b2a95213e775dfd68269f23cf6")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-linux/927afdada4c917bfde045bac88f061818dec0ac1902a3da293b80d4798b86b5c/result.lisp"
   :BYTES 5378 :DEVICE 16777232 :INODE 1548822612 :MTIME 1792696244 :SHA256
   "f82b1a53a96d05982e847fa166e0301a4398ddf2c11590988e90f57bcff9b64d")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/manifest.lisp"
   :BYTES 7120 :DEVICE 16777232 :INODE 1548822615 :MTIME 1792696244 :SHA256
   "46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/raw/child-result.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1548822617 :MTIME 1792696244 :SHA256
   "bd30843cfb87368e57bde38c52b53677ffdba43159159fa4b5946bc88e2466a3")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/raw/child-result.lisp.gz"
   :BYTES 56368 :DEVICE 16777232 :INODE 1548822618 :MTIME 1792696244 :SHA256
   "5042433dc704497f2eed4f89bad0ce05732339b5317db1a55e3008e5d5df51ed")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/raw/commands/job/conservazione.lisp"
   :BYTES 1106 :DEVICE 16777232 :INODE 1548822621 :MTIME 1792696244 :SHA256
   "13f1b9095fd61ce9a9cd30b631a28601c51109274a31dbb5d7ade789c49a166c")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/raw/commands/job/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1548822622 :MTIME 1792696244 :SHA256
   "8449be43dbfa06c9889fa70d5671072582b2e02b97928a8c3fa1afbd6ce0c427")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/raw/commands/job/report.lisp.gz"
   :BYTES 123668 :DEVICE 16777232 :INODE 1548822623 :MTIME 1792696244 :SHA256
   "3755766cc8dfae75a86fbad88d1f51d51efcc0e1be7c316a32723d0bdb89d32c")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/raw/installation.lisp"
   :BYTES 593 :DEVICE 16777232 :INODE 1548822624 :MTIME 1792696244 :SHA256
   "8a38e6a0584e22d4d98e016fa1c98e51430cde8f281c16c84a03b1be662aa1d5")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1548822625 :MTIME 1792696244 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/raw/job-driver.stdout"
   :BYTES 400 :DEVICE 16777232 :INODE 1548822626 :MTIME 1792696244 :SHA256
   "9f52c29fab77f85a70a0a50fe4b1f5ede94c1fa115c054988b845c9346b7fb7c")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/raw/tests.events.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1548822627 :MTIME 1792696244 :SHA256
   "8b3011e4fda7dc46061e1eeeee069b271b5f90a3b547c48d2dbb514f33d38b4f")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/raw/tests.events.lisp.gz"
   :BYTES 121954 :DEVICE 16777232 :INODE 1548822628 :MTIME 1792696244 :SHA256
   "2ea6baccce8a560f14e032d709ce47b01c49855699dadd88e0eed9c11e83437c")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/raw/tests.expected.lisp"
   :BYTES 7570 :DEVICE 16777232 :INODE 1548822629 :MTIME 1792696244 :SHA256
   "e2bbc31a93c8cab3f1963e4c9ef5bbd071ef5d30e885670822c5db4f80e3d633")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/raw/tests.lisp"
   :BYTES 309 :DEVICE 16777232 :INODE 1548822630 :MTIME 1792696244 :SHA256
   "1d95b175b35df542ed1a7a9edb343bbaa0d8ce7fa253133d6b6ef2b0426f4681")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/raw/tests.lisp.gz"
   :BYTES 56368 :DEVICE 16777232 :INODE 1548822631 :MTIME 1792696244 :SHA256
   "5042433dc704497f2eed4f89bad0ce05732339b5317db1a55e3008e5d5df51ed")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/payloads/verify-macos/46c2fbe6f7b97ded4a462d7d9f756e8e52e02de7a610a25e9772c3b048670bc0/result.lisp"
   :BYTES 5382 :DEVICE 16777232 :INODE 1548822632 :MTIME 1792696244 :SHA256
   "d00add44a8d26c1622e69a050b1ae6ea7bf3cd37b6ac505090176903a93bcc62")
  (:PATH
   "spikes/results/ci/by-source/4536abf223395964be30b91650426cb8f2820932379acf5ed325bd4fdefbd3a1/runs/39834163755/1/publications/e751e67a4fba6eb19f35d41a7b2aa8e21861e2cdf8fc1f7085ac15949c414cd1.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1548822634 :MTIME 1792696244 :SHA256
   "538da472a922c2822a19c6278eddba6740599fc9ddf68f41fb543d437bd63591")
  (:PATH
   "spikes/results/ci/by-source/472effba6d174740b79167e71a80b8d8785cdef5c964c625e66b610219eb1c0e/runs/38485306465/1/collections/3e874dbdab08146411ca0c35e4ceba158359e004b2325dd50d075a18e9b3b2dd/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113418 :MTIME 1793207956 :SHA256
   "5eb005a8e5098c3775eb57759a5697d9bd0a8397a95d69c0f7b75865c6bfdeb0")
  (:PATH
   "spikes/results/ci/by-source/472effba6d174740b79167e71a80b8d8785cdef5c964c625e66b610219eb1c0e/runs/38485306465/1/collections/3e874dbdab08146411ca0c35e4ceba158359e004b2325dd50d075a18e9b3b2dd/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113419 :MTIME 1793207956 :SHA256
   "b66e018a6f2519c942de7e62854d93b19d1411d8bbe1a7b6aa12b6c293e9c794")
  (:PATH
   "spikes/results/ci/by-source/472effba6d174740b79167e71a80b8d8785cdef5c964c625e66b610219eb1c0e/runs/38485306465/1/collections/3e874dbdab08146411ca0c35e4ceba158359e004b2325dd50d075a18e9b3b2dd/summary.lisp"
   :BYTES 4751 :DEVICE 16777232 :INODE 1560113420 :MTIME 1793207956 :SHA256
   "40a10018653110a51ea27bf7832b989f11318223cad4f20009a4463e26c0adce")
  (:PATH
   "spikes/results/ci/by-source/472effba6d174740b79167e71a80b8d8785cdef5c964c625e66b610219eb1c0e/runs/38485306465/1/collections/6685e9273d2e0cafe1b9f789c15ef3e56a6a89cd9a5ecf50e5102a94fdfec338/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113422 :MTIME 1793207956 :SHA256
   "8ea6256464fb1494490f0a463ecbd04e20cd0a3a220a250bf3027b5dc9d8bb10")
  (:PATH
   "spikes/results/ci/by-source/472effba6d174740b79167e71a80b8d8785cdef5c964c625e66b610219eb1c0e/runs/38485306465/1/collections/6685e9273d2e0cafe1b9f789c15ef3e56a6a89cd9a5ecf50e5102a94fdfec338/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113423 :MTIME 1793207956 :SHA256
   "b66e018a6f2519c942de7e62854d93b19d1411d8bbe1a7b6aa12b6c293e9c794")
  (:PATH
   "spikes/results/ci/by-source/472effba6d174740b79167e71a80b8d8785cdef5c964c625e66b610219eb1c0e/runs/38485306465/1/collections/6685e9273d2e0cafe1b9f789c15ef3e56a6a89cd9a5ecf50e5102a94fdfec338/summary.lisp"
   :BYTES 4757 :DEVICE 16777232 :INODE 1560113424 :MTIME 1793207956 :SHA256
   "8afe837b041b059c6e51071ac3b346fb0685d66d1a433af7d0eae88119528603")
  (:PATH
   "spikes/results/ci/by-source/472effba6d174740b79167e71a80b8d8785cdef5c964c625e66b610219eb1c0e/runs/38485306465/1/publications/177703fdf0af17ab323efcdbb6449dda2b44332fd9d436df44cbed39fc337821.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113426 :MTIME 1793207956 :SHA256
   "88d3111ac7d7f41229c917549bc7a26353607e9ab2d8afe0c7321d3e3409c3f4")
  (:PATH
   "spikes/results/ci/by-source/472effba6d174740b79167e71a80b8d8785cdef5c964c625e66b610219eb1c0e/runs/38485306465/1/publications/4012d9d3a32f5c576672cc5f54cb55d293ff0f4899ec1cd01d428fe98d5512fb.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113427 :MTIME 1793207956 :SHA256
   "d7903814a4d7e8176b2fc51221ef2db26108145893efca06608fa066f3b3e6f1")
  (:PATH
   "spikes/results/ci/by-source/473707862e27a298b3a933c58d8bb3257890c3949dcb786e2b2483e4f666dc8a/runs/38790063954/1/collections/cbfcd3bc16ff0b80cef5eb10dcdd215e4c83e13a694a4a92834d36f4d1758589/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113434 :MTIME 1793207956 :SHA256
   "52610bfb4ad3e111f41a81f6edd65f12fe522aab0984e43708fd0bfd9f5c0289")
  (:PATH
   "spikes/results/ci/by-source/473707862e27a298b3a933c58d8bb3257890c3949dcb786e2b2483e4f666dc8a/runs/38790063954/1/collections/cbfcd3bc16ff0b80cef5eb10dcdd215e4c83e13a694a4a92834d36f4d1758589/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113435 :MTIME 1793207956 :SHA256
   "8bc777dc8312cb08c292d511804322807dece3d47d5bb7b14227262af97614f6")
  (:PATH
   "spikes/results/ci/by-source/473707862e27a298b3a933c58d8bb3257890c3949dcb786e2b2483e4f666dc8a/runs/38790063954/1/collections/cbfcd3bc16ff0b80cef5eb10dcdd215e4c83e13a694a4a92834d36f4d1758589/summary.lisp"
   :BYTES 5168 :DEVICE 16777232 :INODE 1560113436 :MTIME 1793207956 :SHA256
   "6f42ecb15e9e587c4f07e513153500bd035fa7d77570ce323d89fd588f42b0fc")
  (:PATH
   "spikes/results/ci/by-source/473707862e27a298b3a933c58d8bb3257890c3949dcb786e2b2483e4f666dc8a/runs/38790063954/1/publications/a4268d622e661714730fa47092bd7eebc900195ad6b832edc6a2b63a543f7cb0.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113438 :MTIME 1793207956 :SHA256
   "e6f549ad1dbc5f35fc1cb508fb4a9c400ad822702303f667dc282d054f03a36c")
  (:PATH
   "spikes/results/ci/by-source/47ad010ec1a1ff3261501dfdf73603bbba3577c5ec747d0315a243add8db0913/runs/38135803760/1/collections/d1b2d3a22bee97fc3e6f162956593d23f1e4b03013df00d1a9f8b36b292f3da7/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113445 :MTIME 1793207956 :SHA256
   "45e753fc2711743058650c05c1e1dd0b9f4a2b8f96675c89b872e6a4b4282931")
  (:PATH
   "spikes/results/ci/by-source/47ad010ec1a1ff3261501dfdf73603bbba3577c5ec747d0315a243add8db0913/runs/38135803760/1/collections/d1b2d3a22bee97fc3e6f162956593d23f1e4b03013df00d1a9f8b36b292f3da7/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113446 :MTIME 1793207956 :SHA256
   "f841c33dc1fd145661db8ed5b63a073d96e3788cee09af6498315c30e36bdd13")
  (:PATH
   "spikes/results/ci/by-source/47ad010ec1a1ff3261501dfdf73603bbba3577c5ec747d0315a243add8db0913/runs/38135803760/1/collections/d1b2d3a22bee97fc3e6f162956593d23f1e4b03013df00d1a9f8b36b292f3da7/summary.lisp"
   :BYTES 4045 :DEVICE 16777232 :INODE 1560113447 :MTIME 1793207956 :SHA256
   "a20e5a7d1b57b554bb2351f8cb939f9d3084db6ab94c716ce4668a0c32706c22")
  (:PATH
   "spikes/results/ci/by-source/47ad010ec1a1ff3261501dfdf73603bbba3577c5ec747d0315a243add8db0913/runs/38135803760/1/collections/e776e4bfdc66863387458276069e3399f61eae58b8a30aa6f49b67f82dfddaca/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113449 :MTIME 1793207956 :SHA256
   "176095db3592ef93afdae5608679ce03bd3bba6a89f0191ef7fb28d3698f5e2e")
  (:PATH
   "spikes/results/ci/by-source/47ad010ec1a1ff3261501dfdf73603bbba3577c5ec747d0315a243add8db0913/runs/38135803760/1/collections/e776e4bfdc66863387458276069e3399f61eae58b8a30aa6f49b67f82dfddaca/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113450 :MTIME 1793207956 :SHA256
   "f841c33dc1fd145661db8ed5b63a073d96e3788cee09af6498315c30e36bdd13")
  (:PATH
   "spikes/results/ci/by-source/47ad010ec1a1ff3261501dfdf73603bbba3577c5ec747d0315a243add8db0913/runs/38135803760/1/collections/e776e4bfdc66863387458276069e3399f61eae58b8a30aa6f49b67f82dfddaca/summary.lisp"
   :BYTES 4051 :DEVICE 16777232 :INODE 1560113451 :MTIME 1793207956 :SHA256
   "ee37a0cb6cb80038f7b7344af4e13696cdc6ca476cd40d43d45189a00a3271fe")
  (:PATH
   "spikes/results/ci/by-source/47ad010ec1a1ff3261501dfdf73603bbba3577c5ec747d0315a243add8db0913/runs/38135803760/1/publications/a9a33ed1e42093597fd3ec21c0906350bba5bb9bf26de42bcba841d9e2537b75.lisp"
   :BYTES 734 :DEVICE 16777232 :INODE 1560113453 :MTIME 1793207956 :SHA256
   "a700dfcc497f7ffd7d16ad5f1fe862a6d1b767a1e3e4ef76d11876f39ab66861")
  (:PATH
   "spikes/results/ci/by-source/47ad010ec1a1ff3261501dfdf73603bbba3577c5ec747d0315a243add8db0913/runs/38135803760/1/publications/bdc36e5e53937d9a2a67f1d8c9b2f69e314f99716fc5ee15e5bc1ee605b3159b.lisp"
   :BYTES 731 :DEVICE 16777232 :INODE 1560113454 :MTIME 1793207956 :SHA256
   "e67c14af14607c7cf7979523dc969f18cc48bc42c3665068095045eeecbffb10")
  (:PATH
   "spikes/results/ci/by-source/4ac40c7b43d419cac06766bdc71ccb9a2e9aeadc582fe2647076dd41cf8e0080/runs/38807537906/1/collections/3a4874637c2a52596decf0489378bf6747d9eb94fdb1b5dcb499b608038cab12/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113461 :MTIME 1793207956 :SHA256
   "00923af32bfe5477a5c03202a93e5a4862b89922ef61c67be60d3d92e7fa29c8")
  (:PATH
   "spikes/results/ci/by-source/4ac40c7b43d419cac06766bdc71ccb9a2e9aeadc582fe2647076dd41cf8e0080/runs/38807537906/1/collections/3a4874637c2a52596decf0489378bf6747d9eb94fdb1b5dcb499b608038cab12/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113462 :MTIME 1793207956 :SHA256
   "b934c210627a692051a55be1e255e1cab1993fa820506503858da18ebf0b3bf9")
  (:PATH
   "spikes/results/ci/by-source/4ac40c7b43d419cac06766bdc71ccb9a2e9aeadc582fe2647076dd41cf8e0080/runs/38807537906/1/collections/3a4874637c2a52596decf0489378bf6747d9eb94fdb1b5dcb499b608038cab12/summary.lisp"
   :BYTES 5170 :DEVICE 16777232 :INODE 1560113463 :MTIME 1793207956 :SHA256
   "f67aaed129d1ab572094f00bfa8bb822a4161fc3f6f8e72fb2da93c485e967c4")
  (:PATH
   "spikes/results/ci/by-source/4ac40c7b43d419cac06766bdc71ccb9a2e9aeadc582fe2647076dd41cf8e0080/runs/38807537906/1/publications/2f6f56d39e6a3aec66374db93a81c7f76b10716290464dfadcd042618c261fb8.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113465 :MTIME 1793207956 :SHA256
   "363a96c03f2263dc4fd7f3c93baaab0a8ddd33a9808781d1e91ff5bfccefd488")
  (:PATH
   "spikes/results/ci/by-source/50d918d89228e9cb1ed80deacd62a16110e089ec7e473944654d46305b0c7078/runs/38933653447/1/collections/09c0e3619ef1fd335da539f0f3c1003b425e2d2b335b6f8358a8a245d37cf8dc/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113472 :MTIME 1793207956 :SHA256
   "7199d3654b561512588a0ca39dc518b3eca93fb03186f33e6d8b8fb025aedd3b")
  (:PATH
   "spikes/results/ci/by-source/50d918d89228e9cb1ed80deacd62a16110e089ec7e473944654d46305b0c7078/runs/38933653447/1/collections/09c0e3619ef1fd335da539f0f3c1003b425e2d2b335b6f8358a8a245d37cf8dc/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113473 :MTIME 1793207956 :SHA256
   "cd034aae0f4e2d33903b2928a34a4cc1f2b56a3fa585dbbb5394166cb7891217")
  (:PATH
   "spikes/results/ci/by-source/50d918d89228e9cb1ed80deacd62a16110e089ec7e473944654d46305b0c7078/runs/38933653447/1/collections/09c0e3619ef1fd335da539f0f3c1003b425e2d2b335b6f8358a8a245d37cf8dc/summary.lisp"
   :BYTES 5275 :DEVICE 16777232 :INODE 1560113474 :MTIME 1793207956 :SHA256
   "cb48a1f79a7340e7a34520fdbc020518bb6331994f4ab7d0dafbea0ff85c777d")
  (:PATH
   "spikes/results/ci/by-source/50d918d89228e9cb1ed80deacd62a16110e089ec7e473944654d46305b0c7078/runs/38933653447/1/publications/c57896069f022079af87d447ef856277bb840a618e203800df468a85da57d358.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113476 :MTIME 1793207956 :SHA256
   "b366522af58a883a8613941241eff044c34753feaff70f63e3092a600035dfa1")
  (:PATH
   "spikes/results/ci/by-source/51b347d8c449c8a54c8b8e59baa334fff3f237b5f8f55d5e1927bb4e718f6eba/runs/38131524858/1/collections/688f31169e183423aa8f1044b01bc58801a97547c0d09c5a362a42d10322d0d9/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113483 :MTIME 1793207956 :SHA256
   "87e0db1d3a2bdc436f9097ca9e0f57f78db11e08c64f39d1dbd4bc9042075b5f")
  (:PATH
   "spikes/results/ci/by-source/51b347d8c449c8a54c8b8e59baa334fff3f237b5f8f55d5e1927bb4e718f6eba/runs/38131524858/1/collections/688f31169e183423aa8f1044b01bc58801a97547c0d09c5a362a42d10322d0d9/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113484 :MTIME 1793207956 :SHA256
   "e7ef1693d2179ea874c98ea5452eb6f02d979e95b16f522c7e31a92d2071cc0e")
  (:PATH
   "spikes/results/ci/by-source/51b347d8c449c8a54c8b8e59baa334fff3f237b5f8f55d5e1927bb4e718f6eba/runs/38131524858/1/collections/688f31169e183423aa8f1044b01bc58801a97547c0d09c5a362a42d10322d0d9/summary.lisp"
   :BYTES 3947 :DEVICE 16777232 :INODE 1560113485 :MTIME 1793207956 :SHA256
   "80138a19650ad579c8132702012f30c2618fda5a9b9a46b70da826389035b453")
  (:PATH
   "spikes/results/ci/by-source/51b347d8c449c8a54c8b8e59baa334fff3f237b5f8f55d5e1927bb4e718f6eba/runs/38131524858/1/collections/c3d1003331c6096955eaf0b2da78c080fe99e46e226ff8a1666f638fff598406/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113487 :MTIME 1793207956 :SHA256
   "28c4a8dacd88d56679a01565bc7bdebf8e0d056b16ab6b5a3bb3a9a993795ba7")
  (:PATH
   "spikes/results/ci/by-source/51b347d8c449c8a54c8b8e59baa334fff3f237b5f8f55d5e1927bb4e718f6eba/runs/38131524858/1/collections/c3d1003331c6096955eaf0b2da78c080fe99e46e226ff8a1666f638fff598406/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113488 :MTIME 1793207956 :SHA256
   "e7ef1693d2179ea874c98ea5452eb6f02d979e95b16f522c7e31a92d2071cc0e")
  (:PATH
   "spikes/results/ci/by-source/51b347d8c449c8a54c8b8e59baa334fff3f237b5f8f55d5e1927bb4e718f6eba/runs/38131524858/1/collections/c3d1003331c6096955eaf0b2da78c080fe99e46e226ff8a1666f638fff598406/summary.lisp"
   :BYTES 3941 :DEVICE 16777232 :INODE 1560113489 :MTIME 1793207956 :SHA256
   "87c255d1bd85d238650cf0c19b0e17808cb83550a29ef08de4404edc331f69ed")
  (:PATH
   "spikes/results/ci/by-source/51b347d8c449c8a54c8b8e59baa334fff3f237b5f8f55d5e1927bb4e718f6eba/runs/38131524858/1/publications/8abb43b16c6ffab6862cfc85c36226aee1512a7e4f33b4a9beea808f7c9ba19d.lisp"
   :BYTES 728 :DEVICE 16777232 :INODE 1560113491 :MTIME 1793207956 :SHA256
   "2a89a6eebdf8cd3b98a6c694727fe2fa6e41d0cb97c62775c1c30f1348c1c63a")
  (:PATH
   "spikes/results/ci/by-source/51b347d8c449c8a54c8b8e59baa334fff3f237b5f8f55d5e1927bb4e718f6eba/runs/38131524858/1/publications/ea6e08f3558b36e5fcdb8c8eee926a5c0da78614bffb8ae0bcf3c58825cda773.lisp"
   :BYTES 725 :DEVICE 16777232 :INODE 1560113492 :MTIME 1793207956 :SHA256
   "d80af720ebeecc9abef9292e01b1b978d6fed0ae715ecec8c483ee99603c3aed")
  (:PATH
   "spikes/results/ci/by-source/5207d96fed4a062dd74095cbe4c3fb339796480e9b2276f1eb721ebc72692606/runs/38933217756/1/collections/2afe1034a41294addb6abeb12e4f0fd0fa505dcaef282a766815965f3efea30a/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113499 :MTIME 1793207956 :SHA256
   "12e70dca3d70e169c4f6f65a03e28c7f0d1608ce370d9d82e5ba43d8ea8033fe")
  (:PATH
   "spikes/results/ci/by-source/5207d96fed4a062dd74095cbe4c3fb339796480e9b2276f1eb721ebc72692606/runs/38933217756/1/collections/2afe1034a41294addb6abeb12e4f0fd0fa505dcaef282a766815965f3efea30a/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113500 :MTIME 1793207956 :SHA256
   "c0b60cf8e5b7f5d97a5bcd6642afcedd9e459416d44e2a653a3f5e86ecf5bbe4")
  (:PATH
   "spikes/results/ci/by-source/5207d96fed4a062dd74095cbe4c3fb339796480e9b2276f1eb721ebc72692606/runs/38933217756/1/collections/2afe1034a41294addb6abeb12e4f0fd0fa505dcaef282a766815965f3efea30a/summary.lisp"
   :BYTES 5501 :DEVICE 16777232 :INODE 1560113501 :MTIME 1793207956 :SHA256
   "a7b3b8091fbc0c91a33921f23d0896c1889561bbdc3214dff10f701062380acc")
  (:PATH
   "spikes/results/ci/by-source/5207d96fed4a062dd74095cbe4c3fb339796480e9b2276f1eb721ebc72692606/runs/38933217756/1/publications/b057e27edb17a5176d4d80033467b4e3f4611531490cd86d38e7d57cbfd25012.lisp"
   :BYTES 725 :DEVICE 16777232 :INODE 1560113503 :MTIME 1793207956 :SHA256
   "4f46219294654515f094cc98c5523ebb9caa2fa212120d8c127acc3bd84162d1")
  (:PATH
   "spikes/results/ci/by-source/5c4e63e2b405c0dbb15265c5f0ee4ce26757ff0c3c459aad3210f0a80d22285c/runs/38133844967/1/collections/a137caaf0f51eac23b2df68d201ae4d3783183a15ae3eb1e9e58da51435eda8e/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113510 :MTIME 1793207956 :SHA256
   "fe1c243ccc3299df8451e6325742b58d1a3a97e994e4dfca0de8b2043ca39829")
  (:PATH
   "spikes/results/ci/by-source/5c4e63e2b405c0dbb15265c5f0ee4ce26757ff0c3c459aad3210f0a80d22285c/runs/38133844967/1/collections/a137caaf0f51eac23b2df68d201ae4d3783183a15ae3eb1e9e58da51435eda8e/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113511 :MTIME 1793207956 :SHA256
   "84eb7f0ed442a3b40e3386234ba65ae63004d01fd9721c419e0b21be5214019e")
  (:PATH
   "spikes/results/ci/by-source/5c4e63e2b405c0dbb15265c5f0ee4ce26757ff0c3c459aad3210f0a80d22285c/runs/38133844967/1/collections/a137caaf0f51eac23b2df68d201ae4d3783183a15ae3eb1e9e58da51435eda8e/summary.lisp"
   :BYTES 3999 :DEVICE 16777232 :INODE 1560113512 :MTIME 1793207956 :SHA256
   "40d7f0d2d6efe978c6faa8843254a84f3329fa284e540762ec321844ae9dfb1b")
  (:PATH
   "spikes/results/ci/by-source/5c4e63e2b405c0dbb15265c5f0ee4ce26757ff0c3c459aad3210f0a80d22285c/runs/38133844967/1/collections/fe428ea8dc33c9d391394bc2cf2b25eef5fc619deedbb69fcc35462f0494955a/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113514 :MTIME 1793207956 :SHA256
   "2f8cf337e6fc755ba4182cc9b710888ef84b6891e227c79c4ade7b453131203e")
  (:PATH
   "spikes/results/ci/by-source/5c4e63e2b405c0dbb15265c5f0ee4ce26757ff0c3c459aad3210f0a80d22285c/runs/38133844967/1/collections/fe428ea8dc33c9d391394bc2cf2b25eef5fc619deedbb69fcc35462f0494955a/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113515 :MTIME 1793207956 :SHA256
   "84eb7f0ed442a3b40e3386234ba65ae63004d01fd9721c419e0b21be5214019e")
  (:PATH
   "spikes/results/ci/by-source/5c4e63e2b405c0dbb15265c5f0ee4ce26757ff0c3c459aad3210f0a80d22285c/runs/38133844967/1/collections/fe428ea8dc33c9d391394bc2cf2b25eef5fc619deedbb69fcc35462f0494955a/summary.lisp"
   :BYTES 3993 :DEVICE 16777232 :INODE 1560113516 :MTIME 1793207956 :SHA256
   "77674be71a0e444a71f5e8df9a0333cc9cf52803c6d35075786b2221cfdbf859")
  (:PATH
   "spikes/results/ci/by-source/5c4e63e2b405c0dbb15265c5f0ee4ce26757ff0c3c459aad3210f0a80d22285c/runs/38133844967/1/publications/11a171005679ee9c85827fa661a8989258488795fb495abb214cd5148697371e.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113518 :MTIME 1793207956 :SHA256
   "f2c436068c55765970a3a6e2b44c12843a317a90485bc672b49c6a1a9ed36cbd")
  (:PATH
   "spikes/results/ci/by-source/5c4e63e2b405c0dbb15265c5f0ee4ce26757ff0c3c459aad3210f0a80d22285c/runs/38133844967/1/publications/890d7b10da64cc39c99e7ff4de4641a38f873fb52b984167cfd9d4710c05465f.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113519 :MTIME 1793207956 :SHA256
   "119c4a14805c3d2cf1f211630b43923fb30b650ec50b16c373718efd2f03906b")
  (:PATH
   "spikes/results/ci/by-source/5f0f69372583743b4657a83c2d866d4ea08f520f5254a6486bd1e4d84d03137f/runs/38475054829/1/collections/19ad79087e797291f997f47808ed58cf4580bea5a3e154d91097655149b6f92e/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113526 :MTIME 1793207956 :SHA256
   "3e15b8553b858e094c876722ba334e23cdcc6d47450acc67705f810284247278")
  (:PATH
   "spikes/results/ci/by-source/5f0f69372583743b4657a83c2d866d4ea08f520f5254a6486bd1e4d84d03137f/runs/38475054829/1/collections/19ad79087e797291f997f47808ed58cf4580bea5a3e154d91097655149b6f92e/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113527 :MTIME 1793207956 :SHA256
   "62cfc2fc10a4e37f2b759f998742fe2ee1cad5a57b41ab601f0c9418d7472bb7")
  (:PATH
   "spikes/results/ci/by-source/5f0f69372583743b4657a83c2d866d4ea08f520f5254a6486bd1e4d84d03137f/runs/38475054829/1/collections/19ad79087e797291f997f47808ed58cf4580bea5a3e154d91097655149b6f92e/summary.lisp"
   :BYTES 4659 :DEVICE 16777232 :INODE 1560113528 :MTIME 1793207956 :SHA256
   "689e35a941ceebe78cbe7fbd7f128d27027552f3906278c33137ab5d7881d2f2")
  (:PATH
   "spikes/results/ci/by-source/5f0f69372583743b4657a83c2d866d4ea08f520f5254a6486bd1e4d84d03137f/runs/38475054829/1/collections/f0c6d30cc48909773b80186f55c73e72d5c54881c1da4b12feda0d490ebab683/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113530 :MTIME 1793207956 :SHA256
   "7de4683ec19218e84f8fda965ec056619b160c282252e53e2264d5a19db35f8a")
  (:PATH
   "spikes/results/ci/by-source/5f0f69372583743b4657a83c2d866d4ea08f520f5254a6486bd1e4d84d03137f/runs/38475054829/1/collections/f0c6d30cc48909773b80186f55c73e72d5c54881c1da4b12feda0d490ebab683/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113531 :MTIME 1793207956 :SHA256
   "62cfc2fc10a4e37f2b759f998742fe2ee1cad5a57b41ab601f0c9418d7472bb7")
  (:PATH
   "spikes/results/ci/by-source/5f0f69372583743b4657a83c2d866d4ea08f520f5254a6486bd1e4d84d03137f/runs/38475054829/1/collections/f0c6d30cc48909773b80186f55c73e72d5c54881c1da4b12feda0d490ebab683/summary.lisp"
   :BYTES 4665 :DEVICE 16777232 :INODE 1560113532 :MTIME 1793207956 :SHA256
   "76defaae7b73b10e6f10a88885f58842a15f627542cd939f5ebcbc60003d7caf")
  (:PATH
   "spikes/results/ci/by-source/5f0f69372583743b4657a83c2d866d4ea08f520f5254a6486bd1e4d84d03137f/runs/38475054829/1/publications/18409fd7c933b43f9bde4aaa532262ad6f0d96ca86e344ba6d9bb31e698c9eb3.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113534 :MTIME 1793207956 :SHA256
   "270d335337b17f7344922a27423ac5f32968e54b3cc91cee2ae82ff1876feee5")
  (:PATH
   "spikes/results/ci/by-source/5f0f69372583743b4657a83c2d866d4ea08f520f5254a6486bd1e4d84d03137f/runs/38475054829/1/publications/7b3418da27d5002c4504cfe1b50102ecae86d5ca04488b4bba0ab7aa30b8ba0a.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113535 :MTIME 1793207956 :SHA256
   "a07293fdeb66a46caf19004130ea71b63a065494f78903a2d67bc9802f967141")
  (:PATH
   "spikes/results/ci/by-source/601ec40ed2da7064735b471834c214d2a2a882ca6b4dd674b3ffb88245550b23/runs/38804487363/1/collections/d3bc6a66f0b7dec5fd42983f77ea3feaeca0972d467c22732175361ef11a3e23/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113542 :MTIME 1793207956 :SHA256
   "c5a0a9dd7c3fe77b8b45618275dac5e716d5afddfa5b7a3f8cb648823ee50158")
  (:PATH
   "spikes/results/ci/by-source/601ec40ed2da7064735b471834c214d2a2a882ca6b4dd674b3ffb88245550b23/runs/38804487363/1/collections/d3bc6a66f0b7dec5fd42983f77ea3feaeca0972d467c22732175361ef11a3e23/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113543 :MTIME 1793207956 :SHA256
   "9f57459399e093ce50025b571b72706508cb01c6a548d12880677b4391c12c5d")
  (:PATH
   "spikes/results/ci/by-source/601ec40ed2da7064735b471834c214d2a2a882ca6b4dd674b3ffb88245550b23/runs/38804487363/1/collections/d3bc6a66f0b7dec5fd42983f77ea3feaeca0972d467c22732175361ef11a3e23/summary.lisp"
   :BYTES 5170 :DEVICE 16777232 :INODE 1560113544 :MTIME 1793207956 :SHA256
   "3a5f080b7655646b58d6e6cdbebf2a20f6b1369a608bfaafccccf09a42e1dfff")
  (:PATH
   "spikes/results/ci/by-source/601ec40ed2da7064735b471834c214d2a2a882ca6b4dd674b3ffb88245550b23/runs/38804487363/1/publications/77739c77e03ef560d04c10e74d61c58e0bd22e019fb6ca3705c2a330c7b7c4ab.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113546 :MTIME 1793207956 :SHA256
   "1ac60313830679fe138c8907c9f6e3712e6829f65ba57da0b1ee6ea44c067f01")
  (:PATH
   "spikes/results/ci/by-source/628e60730cde2a2b25f8b12c10ec2ddbdd1b322af2eb239178d64b34eebbb26f/runs/38782552194/1/collections/c2ec21237355df1381a965605650f839295257ad81c806693e03e03558bf342c/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113553 :MTIME 1793207956 :SHA256
   "8052e732c5b4ae39cdec2669215d6c50f3d549a34bf398cfe99985105a796b98")
  (:PATH
   "spikes/results/ci/by-source/628e60730cde2a2b25f8b12c10ec2ddbdd1b322af2eb239178d64b34eebbb26f/runs/38782552194/1/collections/c2ec21237355df1381a965605650f839295257ad81c806693e03e03558bf342c/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113554 :MTIME 1793207956 :SHA256
   "d3f9420f896d01ac819db1825669317ac503d9c95f820d6be6db2f6b864cf9a9")
  (:PATH
   "spikes/results/ci/by-source/628e60730cde2a2b25f8b12c10ec2ddbdd1b322af2eb239178d64b34eebbb26f/runs/38782552194/1/collections/c2ec21237355df1381a965605650f839295257ad81c806693e03e03558bf342c/summary.lisp"
   :BYTES 5068 :DEVICE 16777232 :INODE 1560113555 :MTIME 1793207956 :SHA256
   "4f40a45c1eeeca7a81cb8d1b63f8da568ab62885df0fb12c393a82f04273c35d")
  (:PATH
   "spikes/results/ci/by-source/628e60730cde2a2b25f8b12c10ec2ddbdd1b322af2eb239178d64b34eebbb26f/runs/38782552194/1/publications/93829b10cfc514012fdc477fab32ddda7c34643ab15c7536cbe394f7f910f78c.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113557 :MTIME 1793207956 :SHA256
   "d47da80ed5238832935b679ed5a41f7a2bee9e0d01d0485b4e59a8526172ee20")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38451507222/1/collections/5a01b4e3ff8b627faed6afab028eee15e0a961734a13edc72c8af7e4babd1ba0/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113564 :MTIME 1793207956 :SHA256
   "0a1c7c7cbf39dd4abc634fec4f9555202ea2bba92f2779a1cb67117248907929")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38451507222/1/collections/5a01b4e3ff8b627faed6afab028eee15e0a961734a13edc72c8af7e4babd1ba0/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113565 :MTIME 1793207956 :SHA256
   "2e2e1f6d8455d509f5a9c58279cf6b52d8a44daa8b4d26778ec58bc68a5e9256")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38451507222/1/collections/5a01b4e3ff8b627faed6afab028eee15e0a961734a13edc72c8af7e4babd1ba0/summary.lisp"
   :BYTES 4445 :DEVICE 16777232 :INODE 1560113566 :MTIME 1793207956 :SHA256
   "10f94e1f0521543372cf27908bf58c8f037531cf2e58ad06028a42499030caa6")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38451507222/1/collections/f1b222d786c1f2df5a720fa17cc6f80fa2dda0a5343eb84dc5a0cc1a62eb8505/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113568 :MTIME 1793207956 :SHA256
   "efda7239fa67bab330161ee7d0f54b3393bc4cc534abf372303d8c1aaa1931e2")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38451507222/1/collections/f1b222d786c1f2df5a720fa17cc6f80fa2dda0a5343eb84dc5a0cc1a62eb8505/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113569 :MTIME 1793207956 :SHA256
   "2e2e1f6d8455d509f5a9c58279cf6b52d8a44daa8b4d26778ec58bc68a5e9256")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38451507222/1/collections/f1b222d786c1f2df5a720fa17cc6f80fa2dda0a5343eb84dc5a0cc1a62eb8505/summary.lisp"
   :BYTES 4439 :DEVICE 16777232 :INODE 1560113570 :MTIME 1793207956 :SHA256
   "e7d2fa3ef6e7e4d253ebf40f8c636c9581a3ae978bc932781b4eda50d8b399b2")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38451507222/1/publications/1cd2f543ebd3a303e155828f769e0f258095fb01b130e7a2ea85eb5de4ce0908.lisp"
   :BYTES 739 :DEVICE 16777232 :INODE 1560113572 :MTIME 1793207956 :SHA256
   "144a83dda8e4f1e8fbb400352852050ac4325653dee15863d2ebace5b879f8bb")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38451507222/1/publications/aa4224cd34bb8ab1732de28e6d4b79fd5ef1f1eb3dc3a9b8f9aab55ce8faa0bc.lisp"
   :BYTES 736 :DEVICE 16777232 :INODE 1560113573 :MTIME 1793207956 :SHA256
   "3cd2b9897f94b5271253e396ecc7f00d75419625762c0d7a87ef2a1def9e8b29")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38453617396/1/collections/70fe0a2e281e970556728249145c79fd3ec5387b9457d9686145542ceeb1dc31/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113578 :MTIME 1793207956 :SHA256
   "593fb2898e787ff5f5e1aaa03efee4953c7726499d4e7d51758a9f76d776c596")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38453617396/1/collections/70fe0a2e281e970556728249145c79fd3ec5387b9457d9686145542ceeb1dc31/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113579 :MTIME 1793207956 :SHA256
   "5c19eb4561a7706ab807f57040d96fc8d6e97f14ce0f97fc282a506c2845fd35")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38453617396/1/collections/70fe0a2e281e970556728249145c79fd3ec5387b9457d9686145542ceeb1dc31/summary.lisp"
   :BYTES 4384 :DEVICE 16777232 :INODE 1560113580 :MTIME 1793207956 :SHA256
   "1ca725c7f9053040cf9ef062a8fd1f27b9a9f4b3cbe985cb9f1972ee4e4ec7ff")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38453617396/1/collections/9aa2effffced70f6da47eb8b61e7ef095eb5bf9471340ae8e05ba05a90865280/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113582 :MTIME 1793207956 :SHA256
   "7dce77307b9219cb35f74ea7f91a2ef45500be2361c33fb43db8e8e3104289de")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38453617396/1/collections/9aa2effffced70f6da47eb8b61e7ef095eb5bf9471340ae8e05ba05a90865280/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113583 :MTIME 1793207956 :SHA256
   "5c19eb4561a7706ab807f57040d96fc8d6e97f14ce0f97fc282a506c2845fd35")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38453617396/1/collections/9aa2effffced70f6da47eb8b61e7ef095eb5bf9471340ae8e05ba05a90865280/summary.lisp"
   :BYTES 4378 :DEVICE 16777232 :INODE 1560113584 :MTIME 1793207956 :SHA256
   "fd73a0a9c3e0b73715830d5658f267a20a9ac48808ba52de2ebc8a1124239d79")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38453617396/1/publications/3f2ec1d697b8f5fa5134962f200d0ea053833ff743c51bb08c8fde3aa9b488c9.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113586 :MTIME 1793207956 :SHA256
   "e13808f68e4c3e6e58b1f47cf992378323d769442edb78e5d46439612c2dce1e")
  (:PATH
   "spikes/results/ci/by-source/6677c290247cde8e16a51a5a4c22b799d5a25686c18e3dbfc8d2f1cd798fb93e/runs/38453617396/1/publications/6d910eba79c4834f080f4b08168f44254a9f2d0044a5fe441142bf3206c5f5ba.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113587 :MTIME 1793207956 :SHA256
   "5d0a3d0fa2316ff4cb70575317f04ffc0afb17ddc03a0b6bb6d5f90db99ec6b8")
  (:PATH
   "spikes/results/ci/by-source/680c65dfb956ca2487e1f678918f4cc67748136672eaff93cf4e9cbb65072145/runs/38637242243/1/collections/40291785fa88f8875886c3b0ea1c48c1e21aa92b59e704df15b43c142a01e2e2/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113594 :MTIME 1793207956 :SHA256
   "5cde5c3720c51a2337120292e6bb39fe7701b92ee57c1aa46041f04391c2ce33")
  (:PATH
   "spikes/results/ci/by-source/680c65dfb956ca2487e1f678918f4cc67748136672eaff93cf4e9cbb65072145/runs/38637242243/1/collections/40291785fa88f8875886c3b0ea1c48c1e21aa92b59e704df15b43c142a01e2e2/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113595 :MTIME 1793207956 :SHA256
   "8e7b46916166e037b14edaf660d518479d5fd16948ebf6a27b33b1fffe26bba9")
  (:PATH
   "spikes/results/ci/by-source/680c65dfb956ca2487e1f678918f4cc67748136672eaff93cf4e9cbb65072145/runs/38637242243/1/collections/40291785fa88f8875886c3b0ea1c48c1e21aa92b59e704df15b43c142a01e2e2/summary.lisp"
   :BYTES 4858 :DEVICE 16777232 :INODE 1560113596 :MTIME 1793207956 :SHA256
   "69d6161cc3d1fe150abfae13b6b4dd67e656c0a9800e2c980f471ca58e354341")
  (:PATH
   "spikes/results/ci/by-source/680c65dfb956ca2487e1f678918f4cc67748136672eaff93cf4e9cbb65072145/runs/38637242243/1/collections/e3f2d057c3d72ab7b03a2c9259ac5fe765a6f5bdafe65d792b64c0c280527ef0/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113598 :MTIME 1793207956 :SHA256
   "7d6a8b63e103130abd40d777b6962c4f6f84378533d209109f0b437d68a0898d")
  (:PATH
   "spikes/results/ci/by-source/680c65dfb956ca2487e1f678918f4cc67748136672eaff93cf4e9cbb65072145/runs/38637242243/1/collections/e3f2d057c3d72ab7b03a2c9259ac5fe765a6f5bdafe65d792b64c0c280527ef0/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113599 :MTIME 1793207956 :SHA256
   "8e7b46916166e037b14edaf660d518479d5fd16948ebf6a27b33b1fffe26bba9")
  (:PATH
   "spikes/results/ci/by-source/680c65dfb956ca2487e1f678918f4cc67748136672eaff93cf4e9cbb65072145/runs/38637242243/1/collections/e3f2d057c3d72ab7b03a2c9259ac5fe765a6f5bdafe65d792b64c0c280527ef0/summary.lisp"
   :BYTES 4864 :DEVICE 16777232 :INODE 1560113600 :MTIME 1793207956 :SHA256
   "716ee7d60ad63b81fa14f6b9b3b9b7658f879e69692eafb73b83cedecfc8e510")
  (:PATH
   "spikes/results/ci/by-source/680c65dfb956ca2487e1f678918f4cc67748136672eaff93cf4e9cbb65072145/runs/38637242243/1/publications/7d29a167ae2657ca5006e4666774b03ca38f4cac616af6d4d95a263cc96995b8.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113602 :MTIME 1793207956 :SHA256
   "ab539658d35bf0f48a9f6df687a15b658de882507cbb984505107b1b36630168")
  (:PATH
   "spikes/results/ci/by-source/680c65dfb956ca2487e1f678918f4cc67748136672eaff93cf4e9cbb65072145/runs/38637242243/1/publications/bd057ab169a57f4f2425add3abe47dc6ce933d938a805c598a5fed6f30810322.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113603 :MTIME 1793207956 :SHA256
   "348827447ba9bf1aa824b2ab9f180d3d8c51d6c6eeb74eb983eba635ee2b99b8")
  (:PATH
   "spikes/results/ci/by-source/6c1cf7efda4edade3c2343ad125b65084558afccbff6128d681720dc6d93f703/runs/38141152887/1/collections/a7d84a79f8d7b988eece554bb30f22e817116f2130db249b6ed84ec857441e92/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113610 :MTIME 1793207956 :SHA256
   "4b8c828ab3edd7ae245f3a7dc42d0ae004bf0fe284146f51020c2216f3c2a2bd")
  (:PATH
   "spikes/results/ci/by-source/6c1cf7efda4edade3c2343ad125b65084558afccbff6128d681720dc6d93f703/runs/38141152887/1/collections/a7d84a79f8d7b988eece554bb30f22e817116f2130db249b6ed84ec857441e92/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113611 :MTIME 1793207956 :SHA256
   "40a09a30fb14276c28b9209ffaf4b87885398381b6b74c6c9cfab39c3f445776")
  (:PATH
   "spikes/results/ci/by-source/6c1cf7efda4edade3c2343ad125b65084558afccbff6128d681720dc6d93f703/runs/38141152887/1/collections/a7d84a79f8d7b988eece554bb30f22e817116f2130db249b6ed84ec857441e92/summary.lisp"
   :BYTES 4273 :DEVICE 16777232 :INODE 1560113612 :MTIME 1793207956 :SHA256
   "4c7ac73c38b648d90a64a0526a1e3ff832c511fc3f0502e6f7a175a019f6e3c5")
  (:PATH
   "spikes/results/ci/by-source/6c1cf7efda4edade3c2343ad125b65084558afccbff6128d681720dc6d93f703/runs/38141152887/1/collections/b140244d41a08b84f40cd3811dae72125b6e4d6495d53470bd8fbe2512d9415b/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113614 :MTIME 1793207956 :SHA256
   "0b620b024d8daa81921636fdecde7c7ab0177ef45140b9e837a7d8b7b8f0527b")
  (:PATH
   "spikes/results/ci/by-source/6c1cf7efda4edade3c2343ad125b65084558afccbff6128d681720dc6d93f703/runs/38141152887/1/collections/b140244d41a08b84f40cd3811dae72125b6e4d6495d53470bd8fbe2512d9415b/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113615 :MTIME 1793207956 :SHA256
   "40a09a30fb14276c28b9209ffaf4b87885398381b6b74c6c9cfab39c3f445776")
  (:PATH
   "spikes/results/ci/by-source/6c1cf7efda4edade3c2343ad125b65084558afccbff6128d681720dc6d93f703/runs/38141152887/1/collections/b140244d41a08b84f40cd3811dae72125b6e4d6495d53470bd8fbe2512d9415b/summary.lisp"
   :BYTES 4279 :DEVICE 16777232 :INODE 1560113616 :MTIME 1793207956 :SHA256
   "07afbe6c05a4e64b76ddbb9a47b47f0242abb4df46c6dc2095e7fb3ab64fe6ad")
  (:PATH
   "spikes/results/ci/by-source/6c1cf7efda4edade3c2343ad125b65084558afccbff6128d681720dc6d93f703/runs/38141152887/1/publications/0ef9e0f1d90e3b60f6d82f34b62b720d72b0c73afdf35608e890e399f42dca4b.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113618 :MTIME 1793207956 :SHA256
   "aa508bca212c293b9de0b1c261001ccccc7172e5b830266654f307dc9bfd1a4f")
  (:PATH
   "spikes/results/ci/by-source/6c1cf7efda4edade3c2343ad125b65084558afccbff6128d681720dc6d93f703/runs/38141152887/1/publications/ecfe8ee79a6d932d92ca339e128e7e9df7b45b36215c976639d62eec0d413585.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113619 :MTIME 1793207956 :SHA256
   "9e18007c63970dfcc840615c604a18cdeb24070ec7b6682968db8cc1abbec8dc")
  (:PATH
   "spikes/results/ci/by-source/6e7845577ff9f4967688f8eda2e1d32a1f35258a61d8e4602d6e50a9f37795f0/runs/39020543426/1/collections/9fc3c78b665f137965e660f00488b20f24821c8a01bd1388c6bc746d8e8b4b9a/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113626 :MTIME 1793207956 :SHA256
   "7c1c7f86a484c1635ce206ae2100de332259dc060a71981345ecbebaef8c1229")
  (:PATH
   "spikes/results/ci/by-source/6e7845577ff9f4967688f8eda2e1d32a1f35258a61d8e4602d6e50a9f37795f0/runs/39020543426/1/collections/9fc3c78b665f137965e660f00488b20f24821c8a01bd1388c6bc746d8e8b4b9a/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113627 :MTIME 1793207956 :SHA256
   "9cad3631f25eeb1b5397679331ad807fbf578db769fd9b6855671328df9eda6c")
  (:PATH
   "spikes/results/ci/by-source/6e7845577ff9f4967688f8eda2e1d32a1f35258a61d8e4602d6e50a9f37795f0/runs/39020543426/1/collections/9fc3c78b665f137965e660f00488b20f24821c8a01bd1388c6bc746d8e8b4b9a/summary.lisp"
   :BYTES 5555 :DEVICE 16777232 :INODE 1560113628 :MTIME 1793207956 :SHA256
   "fc5e7c44685e3f9d04150cfef8a97f5522f07b97114f859ca721455aa508f73a")
  (:PATH
   "spikes/results/ci/by-source/6e7845577ff9f4967688f8eda2e1d32a1f35258a61d8e4602d6e50a9f37795f0/runs/39020543426/1/publications/4d305745683ef9499323e1658676b94ad009cf8d5aee042785bce8fdc7265446.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113630 :MTIME 1793207956 :SHA256
   "80090f430e43418d1910de9b4dfb3e3a2dcf9fb2a3c18690ae414a2a311d63bb")
  (:PATH
   "spikes/results/ci/by-source/70dfa7c2d992a531a1601530cbe3daa00a78eb4b01e3be6a934d7427ce85b5ef/runs/38939953512/1/collections/897ab8adec84ac56da6a430f275924d6a04b6ef669cb306c0a90bb03385f9cb1/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113637 :MTIME 1793207956 :SHA256
   "306cbf4954743c57e955a81c30d5515dc751ee7282e6fc19741ba880df9a1439")
  (:PATH
   "spikes/results/ci/by-source/70dfa7c2d992a531a1601530cbe3daa00a78eb4b01e3be6a934d7427ce85b5ef/runs/38939953512/1/collections/897ab8adec84ac56da6a430f275924d6a04b6ef669cb306c0a90bb03385f9cb1/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113638 :MTIME 1793207956 :SHA256
   "17d40fa606e4ba135c489b59306b4cfbb4121ed5d0832ebac8aff0d8d80af065")
  (:PATH
   "spikes/results/ci/by-source/70dfa7c2d992a531a1601530cbe3daa00a78eb4b01e3be6a934d7427ce85b5ef/runs/38939953512/1/collections/897ab8adec84ac56da6a430f275924d6a04b6ef669cb306c0a90bb03385f9cb1/summary.lisp"
   :BYTES 5593 :DEVICE 16777232 :INODE 1560113639 :MTIME 1793207956 :SHA256
   "7159f179b06867de7a690e7e605618e9f242940e19032c6c03d38cbe0eb36f0f")
  (:PATH
   "spikes/results/ci/by-source/70dfa7c2d992a531a1601530cbe3daa00a78eb4b01e3be6a934d7427ce85b5ef/runs/38939953512/1/publications/638bc716dec3eb7db8f1993af0eb442f039f6b7998984be9da622993a1dce845.lisp"
   :BYTES 725 :DEVICE 16777232 :INODE 1560113641 :MTIME 1793207956 :SHA256
   "9c6e6c2573668370d7bdb91bd5fb2f684710bcffe69232029a41e5e7dc061887")
  (:PATH
   "spikes/results/ci/by-source/721b286e7c813a14f8e25831e5c3af3c9c304d78966e3875d3b667a9ae3e6b19/runs/38941078055/1/collections/1d0db046d8d6f0306c3128c8846780cfef0440382be5638e43ec734925d22203/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113648 :MTIME 1793207956 :SHA256
   "33ae2d583bda70a8378261bdba5b012252193c7e338855a6237d99253e4a12c5")
  (:PATH
   "spikes/results/ci/by-source/721b286e7c813a14f8e25831e5c3af3c9c304d78966e3875d3b667a9ae3e6b19/runs/38941078055/1/collections/1d0db046d8d6f0306c3128c8846780cfef0440382be5638e43ec734925d22203/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113649 :MTIME 1793207956 :SHA256
   "9872d15cb5d273cf90e989ed431ab9e14757051f3bfd4becd9eac8602c1eb209")
  (:PATH
   "spikes/results/ci/by-source/721b286e7c813a14f8e25831e5c3af3c9c304d78966e3875d3b667a9ae3e6b19/runs/38941078055/1/collections/1d0db046d8d6f0306c3128c8846780cfef0440382be5638e43ec734925d22203/summary.lisp"
   :BYTES 5593 :DEVICE 16777232 :INODE 1560113650 :MTIME 1793207956 :SHA256
   "52cc0f14c27f8551e61ccc81efbe340ed55c13000080df1cd0a2098a7ae7ee08")
  (:PATH
   "spikes/results/ci/by-source/721b286e7c813a14f8e25831e5c3af3c9c304d78966e3875d3b667a9ae3e6b19/runs/38941078055/1/publications/9ff35a0742c28a82135f80d238da6a16641429eab024e27e003a10f7e11b3478.lisp"
   :BYTES 725 :DEVICE 16777232 :INODE 1560113652 :MTIME 1793207956 :SHA256
   "fb778960ee77487217de053e28a4d198f913a116731f0fdeb50f2b356ba8ddfc")
  (:PATH
   "spikes/results/ci/by-source/7497d7ce402acb20eef4f4588dff03690ea6a3bbff1206b7f30ebc524dd6e4fd/runs/38798415412/1/collections/88ec5c641ecd8d423d6b43f41c26a6b8d6c9ec03c68fb7aa9fb2e29885ca5ed2/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113659 :MTIME 1793207956 :SHA256
   "9bd4099d655e688ee7d938b9b6411455f2b53a89f0ac1a7212a79ba429c4572f")
  (:PATH
   "spikes/results/ci/by-source/7497d7ce402acb20eef4f4588dff03690ea6a3bbff1206b7f30ebc524dd6e4fd/runs/38798415412/1/collections/88ec5c641ecd8d423d6b43f41c26a6b8d6c9ec03c68fb7aa9fb2e29885ca5ed2/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113660 :MTIME 1793207956 :SHA256
   "58cdd2fe20550a6224331b8f9f25964d881bcbb46e1509d3ebd852916b60a4d8")
  (:PATH
   "spikes/results/ci/by-source/7497d7ce402acb20eef4f4588dff03690ea6a3bbff1206b7f30ebc524dd6e4fd/runs/38798415412/1/collections/88ec5c641ecd8d423d6b43f41c26a6b8d6c9ec03c68fb7aa9fb2e29885ca5ed2/summary.lisp"
   :BYTES 5168 :DEVICE 16777232 :INODE 1560113661 :MTIME 1793207956 :SHA256
   "fe2fb43c383a2dff4a466fe5c5306d0fb6379e85afb325e89d029cdca7fa7ade")
  (:PATH
   "spikes/results/ci/by-source/7497d7ce402acb20eef4f4588dff03690ea6a3bbff1206b7f30ebc524dd6e4fd/runs/38798415412/1/publications/1818d16aa583cfd8c7b5a9c2a220c1ba3a7900ae4985f41550ed90acf6d52fc2.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113663 :MTIME 1793207956 :SHA256
   "58f9f1cc420cdf03c079ea0e6134744a7005271a3aca85c7b0a5ce78c491f97f")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38143623735/1/collections/270bea95954d910b406c02e9f2203a4d7805423d04ab32a97cef7a62fd6b11b8/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113670 :MTIME 1793207956 :SHA256
   "8be1883dbc238a11023192f8cb5dcc9e7697d754aa96cd9c6765d6c76507f78d")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38143623735/1/collections/270bea95954d910b406c02e9f2203a4d7805423d04ab32a97cef7a62fd6b11b8/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113671 :MTIME 1793207956 :SHA256
   "4b18b9eb27e80f1f971424039252b67c5b4389e8500c316d143941cfd46631ca")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38143623735/1/collections/270bea95954d910b406c02e9f2203a4d7805423d04ab32a97cef7a62fd6b11b8/summary.lisp"
   :BYTES 4323 :DEVICE 16777232 :INODE 1560113672 :MTIME 1793207956 :SHA256
   "0001299f39e57c2188ebba51efa182a6b5e545f2ba1ac8e5129330436a0acc76")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38143623735/1/collections/c369649b474f14b88ebd00b6a21b2fb89b09d12db173828a87c8b0754a600335/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113674 :MTIME 1793207956 :SHA256
   "96364bb9d34e405ac18afecf61fcaa8085cfb167fb1747f24e6c55ec090e44a2")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38143623735/1/collections/c369649b474f14b88ebd00b6a21b2fb89b09d12db173828a87c8b0754a600335/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113675 :MTIME 1793207956 :SHA256
   "4b18b9eb27e80f1f971424039252b67c5b4389e8500c316d143941cfd46631ca")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38143623735/1/collections/c369649b474f14b88ebd00b6a21b2fb89b09d12db173828a87c8b0754a600335/summary.lisp"
   :BYTES 4329 :DEVICE 16777232 :INODE 1560113676 :MTIME 1793207956 :SHA256
   "39b506b7c12ecca522b920247f1eb5768b45caadd9f8560927cb5d029da55451")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38143623735/1/publications/66a6c8c26808c22d1fcefe3f50750c60f0d11bf9c5ae10e0bd6aec8806ec7071.lisp"
   :BYTES 728 :DEVICE 16777232 :INODE 1560113678 :MTIME 1793207956 :SHA256
   "a604bed68f061a2ea5246ce402fd3ca5a9681309a3b0bc2dd633bb53659c867d")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38143623735/1/publications/c087e0dadd2c3e80e542a149c34ba36ce5966dcd95c1a72f0c053f277062f9de.lisp"
   :BYTES 731 :DEVICE 16777232 :INODE 1560113679 :MTIME 1793207956 :SHA256
   "981391075bd75982d45e334b6f079df8f6a8e8c292cf7c23de94c91565b79e82")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38144156830/1/collections/6ee1e1550864a70cae16b7b831f8745c5ba017f3df3623a35990330c92d77f84/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113684 :MTIME 1793207956 :SHA256
   "db0826f7cef784ae259b475638d44450817ee6e798a82026db919e56ea16b14b")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38144156830/1/collections/6ee1e1550864a70cae16b7b831f8745c5ba017f3df3623a35990330c92d77f84/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113685 :MTIME 1793207956 :SHA256
   "da3d6a7a1da6057d1b2e408c99f40a1c8fb430af5f00248d9048e9b7934455eb")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38144156830/1/collections/6ee1e1550864a70cae16b7b831f8745c5ba017f3df3623a35990330c92d77f84/summary.lisp"
   :BYTES 4278 :DEVICE 16777232 :INODE 1560113686 :MTIME 1793207956 :SHA256
   "ea66d492b63d951c86e7572f96a63476ae463cd5b627e2501ce9853f9f204986")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38144156830/1/collections/ceb6a67c3c7c4db8a51050130630e8e9aa8691e5894fd69eba7603887c55da20/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113688 :MTIME 1793207956 :SHA256
   "b0bb9e66a97613135df7136e09249c832bfaf08146a41d56cc3ffcdc79880e17")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38144156830/1/collections/ceb6a67c3c7c4db8a51050130630e8e9aa8691e5894fd69eba7603887c55da20/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113689 :MTIME 1793207956 :SHA256
   "da3d6a7a1da6057d1b2e408c99f40a1c8fb430af5f00248d9048e9b7934455eb")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38144156830/1/collections/ceb6a67c3c7c4db8a51050130630e8e9aa8691e5894fd69eba7603887c55da20/summary.lisp"
   :BYTES 4284 :DEVICE 16777232 :INODE 1560113690 :MTIME 1793207956 :SHA256
   "237dba3d7f327fc4515d6b16b2cf8e3d70738baeb5c2231c9bbd8a2e1e6a7700")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38144156830/1/publications/316a753114fc3f0337dccc4a54898134c3f6e561d14ec56443fd0af6530edaeb.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113692 :MTIME 1793207956 :SHA256
   "f0d30df4543bd37655639855cb6171f0592ad3dedb746eba8ae136e4a65f47d4")
  (:PATH
   "spikes/results/ci/by-source/782477f19651a78b387260978c05f11b79daeac4e1f26ea0f718901c2096297f/runs/38144156830/1/publications/fb6c02cc738b43642aa7abdea39193403ecd98ee5019c2d9e86dbc5edef8a916.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113693 :MTIME 1793207956 :SHA256
   "1dfec923841f941ae101eb8441018c97fda8ad9c82168958e759f807e6aae0d5")
  (:PATH
   "spikes/results/ci/by-source/7e3d453d65a48d4917af2b325ec52addf0e11fd17aca1123a69016a183904b89/runs/38927332158/1/collections/0f4374ea476bc861fd86e3bc00c3fa912573c9eba7b19ea5996e54ec7ffe1e4f/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113700 :MTIME 1793207956 :SHA256
   "7f1f5395ffc6e74285743e7c4ce36a8f50d71c4c5b99a3180a27bad0d0a76d84")
  (:PATH
   "spikes/results/ci/by-source/7e3d453d65a48d4917af2b325ec52addf0e11fd17aca1123a69016a183904b89/runs/38927332158/1/collections/0f4374ea476bc861fd86e3bc00c3fa912573c9eba7b19ea5996e54ec7ffe1e4f/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113701 :MTIME 1793207956 :SHA256
   "f6f05167084a31ce70c8fa8e3dbb50dbd3de83e7ec203205af5a5e006882725a")
  (:PATH
   "spikes/results/ci/by-source/7e3d453d65a48d4917af2b325ec52addf0e11fd17aca1123a69016a183904b89/runs/38927332158/1/collections/0f4374ea476bc861fd86e3bc00c3fa912573c9eba7b19ea5996e54ec7ffe1e4f/summary.lisp"
   :BYTES 5275 :DEVICE 16777232 :INODE 1560113702 :MTIME 1793207956 :SHA256
   "9296b41dac097a3dbbb7a1da2ae627582649492b4c4812549abc95cad8b1d19b")
  (:PATH
   "spikes/results/ci/by-source/7e3d453d65a48d4917af2b325ec52addf0e11fd17aca1123a69016a183904b89/runs/38927332158/1/publications/3fe9ce0ac2867274b42857544b7f7212bcafbcdf3c9cc4b5517fe066a57d8db7.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113704 :MTIME 1793207956 :SHA256
   "533d1510e4edc43a21e5d6a0f7d4dc3d99547d86ac7dac0728d6e5b5334a12cb")
  (:PATH
   "spikes/results/ci/by-source/7eb214718d5784b7b8cffa9133133ab3f835f29fdc902a8c5ed12cce832e8778/runs/38143001037/1/collections/0aa4c10556f5e15c0b1f2d1e15314741330c861ea16564f3a2d95d5638b697c8/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113711 :MTIME 1793207956 :SHA256
   "03fba5d91d450c4516868a3da7cf80fa7ff97c9c05fffa88886df679e17235b7")
  (:PATH
   "spikes/results/ci/by-source/7eb214718d5784b7b8cffa9133133ab3f835f29fdc902a8c5ed12cce832e8778/runs/38143001037/1/collections/0aa4c10556f5e15c0b1f2d1e15314741330c861ea16564f3a2d95d5638b697c8/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113712 :MTIME 1793207956 :SHA256
   "4fc637033e91fef1e9a5b78f5f9b4eb1283944ff5326bf2cf8338d87443071c0")
  (:PATH
   "spikes/results/ci/by-source/7eb214718d5784b7b8cffa9133133ab3f835f29fdc902a8c5ed12cce832e8778/runs/38143001037/1/collections/0aa4c10556f5e15c0b1f2d1e15314741330c861ea16564f3a2d95d5638b697c8/summary.lisp"
   :BYTES 4320 :DEVICE 16777232 :INODE 1560113713 :MTIME 1793207956 :SHA256
   "8ffd9d948f217981c4aaa044cd27b92c6c2a2a6b5d121372f491aa52c886a120")
  (:PATH
   "spikes/results/ci/by-source/7eb214718d5784b7b8cffa9133133ab3f835f29fdc902a8c5ed12cce832e8778/runs/38143001037/1/collections/b1962049a87647d72575887a88789f26b6009be3b80225a77b5f1bcc64ec67c7/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113715 :MTIME 1793207956 :SHA256
   "887c9c3dcad60824a21fae33598ead2f57c85d1d984cd0c35f80388237f0665c")
  (:PATH
   "spikes/results/ci/by-source/7eb214718d5784b7b8cffa9133133ab3f835f29fdc902a8c5ed12cce832e8778/runs/38143001037/1/collections/b1962049a87647d72575887a88789f26b6009be3b80225a77b5f1bcc64ec67c7/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113716 :MTIME 1793207956 :SHA256
   "4fc637033e91fef1e9a5b78f5f9b4eb1283944ff5326bf2cf8338d87443071c0")
  (:PATH
   "spikes/results/ci/by-source/7eb214718d5784b7b8cffa9133133ab3f835f29fdc902a8c5ed12cce832e8778/runs/38143001037/1/collections/b1962049a87647d72575887a88789f26b6009be3b80225a77b5f1bcc64ec67c7/summary.lisp"
   :BYTES 4326 :DEVICE 16777232 :INODE 1560113717 :MTIME 1793207956 :SHA256
   "e021fc19423503448e28b81484aed3f2cd019c135423d26d57be2f606001dd94")
  (:PATH
   "spikes/results/ci/by-source/7eb214718d5784b7b8cffa9133133ab3f835f29fdc902a8c5ed12cce832e8778/runs/38143001037/1/publications/d52a6376a0e0502c72692b9f16f96e5459c71fb32679faa1569c53bb0d736b7f.lisp"
   :BYTES 728 :DEVICE 16777232 :INODE 1560113719 :MTIME 1793207956 :SHA256
   "c9658d72d0ae2bdeacb915ebcdb2383f19c58d171fbcd112394c5012d7dc54f4")
  (:PATH
   "spikes/results/ci/by-source/7eb214718d5784b7b8cffa9133133ab3f835f29fdc902a8c5ed12cce832e8778/runs/38143001037/1/publications/eccde4cd07b7e58999cbfa7b7fd0fe76941b37df0aba2ed35baf076d4651f105.lisp"
   :BYTES 731 :DEVICE 16777232 :INODE 1560113720 :MTIME 1793207956 :SHA256
   "407d4ebdfea3a6541bb4904c6393313ed756ba5044c934bd679bb4f4e60c2af4")
  (:PATH
   "spikes/results/ci/by-source/7fe30800b2f84d6f06d6bbba91c24e51e526cc42f2bafa9059e857b21b5a5ab8/runs/38943205784/1/collections/38b7e09b2bc4afd1e6e3ed7ba5181b287d3c8c40f804cff1201695e58c436a0d/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113727 :MTIME 1793207956 :SHA256
   "7c41ce16d563435d56cc71cb95d1438eb8c580ec30370049d3933814f4749c12")
  (:PATH
   "spikes/results/ci/by-source/7fe30800b2f84d6f06d6bbba91c24e51e526cc42f2bafa9059e857b21b5a5ab8/runs/38943205784/1/collections/38b7e09b2bc4afd1e6e3ed7ba5181b287d3c8c40f804cff1201695e58c436a0d/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113728 :MTIME 1793207956 :SHA256
   "f3f4396f639c96ac56b1163f4e363f044e31677f1c7f847cb499342563490634")
  (:PATH
   "spikes/results/ci/by-source/7fe30800b2f84d6f06d6bbba91c24e51e526cc42f2bafa9059e857b21b5a5ab8/runs/38943205784/1/collections/38b7e09b2bc4afd1e6e3ed7ba5181b287d3c8c40f804cff1201695e58c436a0d/summary.lisp"
   :BYTES 5368 :DEVICE 16777232 :INODE 1560113729 :MTIME 1793207956 :SHA256
   "589b8b2f93d7b0281d48bc3303992122878f724579f1ae00f7dc6ae6b8ee6a09")
  (:PATH
   "spikes/results/ci/by-source/7fe30800b2f84d6f06d6bbba91c24e51e526cc42f2bafa9059e857b21b5a5ab8/runs/38943205784/1/publications/bc04505544f3d5d225b9d5dfa5596e75b8c66224330987f26fb98ea8fe7f65d8.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113731 :MTIME 1793207956 :SHA256
   "3e95e43d99cccad7dfc2769b1e35c4e876fc0117e77eedafa745015e02064fbe")
  (:PATH
   "spikes/results/ci/by-source/81a1903dc8fd2353b18c879b01aef5bbcd210012c5151dd7d86b4199705f95bb/runs/38932934064/1/collections/e592bbd4069ff3f118aed4c02ffe7feecc4d4417604facedf1b90353bff10605/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113738 :MTIME 1793207956 :SHA256
   "cfb06cc715071b2f4edc9bf14660ead86c43f46b92ce452f9fbf1dc8fa858fbe")
  (:PATH
   "spikes/results/ci/by-source/81a1903dc8fd2353b18c879b01aef5bbcd210012c5151dd7d86b4199705f95bb/runs/38932934064/1/collections/e592bbd4069ff3f118aed4c02ffe7feecc4d4417604facedf1b90353bff10605/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113739 :MTIME 1793207956 :SHA256
   "7eb61b38912b8bd51a7d2a87aeb5edff69f5871b4005d89f5bb09610108501c9")
  (:PATH
   "spikes/results/ci/by-source/81a1903dc8fd2353b18c879b01aef5bbcd210012c5151dd7d86b4199705f95bb/runs/38932934064/1/collections/e592bbd4069ff3f118aed4c02ffe7feecc4d4417604facedf1b90353bff10605/summary.lisp"
   :BYTES 5501 :DEVICE 16777232 :INODE 1560113740 :MTIME 1793207956 :SHA256
   "f67e34ba2214ab77924f2109988385359d739ce504057c9f56fb8f4bbb778d69")
  (:PATH
   "spikes/results/ci/by-source/81a1903dc8fd2353b18c879b01aef5bbcd210012c5151dd7d86b4199705f95bb/runs/38932934064/1/publications/98cfd40c3b8283a9df67970abf547633a2203c2d6dc8412b06fdfad8dd2bd18b.lisp"
   :BYTES 725 :DEVICE 16777232 :INODE 1560113742 :MTIME 1793207956 :SHA256
   "f0067c81c8a704df7b19a7d70383fe8e782a58a5b248d738a78192361895a6e5")
  (:PATH
   "spikes/results/ci/by-source/81a59be03d3c4b235f6583db10a60978f25acff9e6da3f71d47aa5a587278ae3/runs/38476571352/1/collections/61d552ae103dea78c7b516b9ee60782dd93db496fa9e23d8b899f6792b5c7be0/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113749 :MTIME 1793207956 :SHA256
   "0c65b69af243bcc2f31f4e80ab77c4f4051cc55709d849286cf627137dde159c")
  (:PATH
   "spikes/results/ci/by-source/81a59be03d3c4b235f6583db10a60978f25acff9e6da3f71d47aa5a587278ae3/runs/38476571352/1/collections/61d552ae103dea78c7b516b9ee60782dd93db496fa9e23d8b899f6792b5c7be0/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113750 :MTIME 1793207956 :SHA256
   "a3a55de1a6c0814d0766b4f0a5d955daf13ebc0ce77b62d59b7650745b6d7889")
  (:PATH
   "spikes/results/ci/by-source/81a59be03d3c4b235f6583db10a60978f25acff9e6da3f71d47aa5a587278ae3/runs/38476571352/1/collections/61d552ae103dea78c7b516b9ee60782dd93db496fa9e23d8b899f6792b5c7be0/summary.lisp"
   :BYTES 4751 :DEVICE 16777232 :INODE 1560113751 :MTIME 1793207956 :SHA256
   "afc5c055cb71aec21f9d70bce0d8166005046656351dc28da7df0e6410530b47")
  (:PATH
   "spikes/results/ci/by-source/81a59be03d3c4b235f6583db10a60978f25acff9e6da3f71d47aa5a587278ae3/runs/38476571352/1/collections/af5122c63f59fae72cadabcebf8a3b2271a52c259f891bea282d6048f93d965f/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113753 :MTIME 1793207956 :SHA256
   "aa1489b26f696242c48623a5f1f86d198fac5edf6900d6b6cefea6b5c41056e1")
  (:PATH
   "spikes/results/ci/by-source/81a59be03d3c4b235f6583db10a60978f25acff9e6da3f71d47aa5a587278ae3/runs/38476571352/1/collections/af5122c63f59fae72cadabcebf8a3b2271a52c259f891bea282d6048f93d965f/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113754 :MTIME 1793207956 :SHA256
   "a3a55de1a6c0814d0766b4f0a5d955daf13ebc0ce77b62d59b7650745b6d7889")
  (:PATH
   "spikes/results/ci/by-source/81a59be03d3c4b235f6583db10a60978f25acff9e6da3f71d47aa5a587278ae3/runs/38476571352/1/collections/af5122c63f59fae72cadabcebf8a3b2271a52c259f891bea282d6048f93d965f/summary.lisp"
   :BYTES 4757 :DEVICE 16777232 :INODE 1560113755 :MTIME 1793207956 :SHA256
   "a89b1eaef389f13981d121b5e221a6fc6b2935b207de643b51458173522aa738")
  (:PATH
   "spikes/results/ci/by-source/81a59be03d3c4b235f6583db10a60978f25acff9e6da3f71d47aa5a587278ae3/runs/38476571352/1/publications/2177178ab09fca8bcdbac25242042caec1fd6098fa7716ac2ccd20af322ffdb0.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113757 :MTIME 1793207956 :SHA256
   "807e9c3aaf6be5f0e458c06ab4d33290fddd19b689d670d031f39aa599159207")
  (:PATH
   "spikes/results/ci/by-source/81a59be03d3c4b235f6583db10a60978f25acff9e6da3f71d47aa5a587278ae3/runs/38476571352/1/publications/c588e87e927e0686a57e4442741d868710d62c27f2a3abcede566c2acba2ba41.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113758 :MTIME 1793207956 :SHA256
   "c7c5e3aed02deb1f2e14d2d586a28eb27e8672af7da156acd143490e0193e00d")
  (:PATH
   "spikes/results/ci/by-source/8383525c2602268b5b05d8fbdad2e9fabf5cb05a1baa8f872d0ce6f79d87755f/runs/38780230735/1/collections/18e9271cf52c6bf05555235684ce2d2f6daf91df4c085029b5de420c84b0aadc/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113765 :MTIME 1793207956 :SHA256
   "dd69396c596db5dd05c33df5284c3eb0ea5ca5871a9df92755775f7e8b3822ea")
  (:PATH
   "spikes/results/ci/by-source/8383525c2602268b5b05d8fbdad2e9fabf5cb05a1baa8f872d0ce6f79d87755f/runs/38780230735/1/collections/18e9271cf52c6bf05555235684ce2d2f6daf91df4c085029b5de420c84b0aadc/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113766 :MTIME 1793207956 :SHA256
   "8805cd38b2064e1ed40af114660e2fbb7bd640b9742f3980fbed07a8d1700a1e")
  (:PATH
   "spikes/results/ci/by-source/8383525c2602268b5b05d8fbdad2e9fabf5cb05a1baa8f872d0ce6f79d87755f/runs/38780230735/1/collections/18e9271cf52c6bf05555235684ce2d2f6daf91df4c085029b5de420c84b0aadc/summary.lisp"
   :BYTES 5038 :DEVICE 16777232 :INODE 1560113767 :MTIME 1793207956 :SHA256
   "0a83de0179875494e75a0d89e37a94b0fb4f7632fc98de0eb3499c55e404a803")
  (:PATH
   "spikes/results/ci/by-source/8383525c2602268b5b05d8fbdad2e9fabf5cb05a1baa8f872d0ce6f79d87755f/runs/38780230735/1/collections/30cc7f6accc48ab9b1e0b66a44ced9ecaba26fa64ebed617066461d0f4694a35/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113769 :MTIME 1793207956 :SHA256
   "adfaca1f5bed71bd739f0b4f4e957edf500ff74bcccd87137fa749a567fccdd5")
  (:PATH
   "spikes/results/ci/by-source/8383525c2602268b5b05d8fbdad2e9fabf5cb05a1baa8f872d0ce6f79d87755f/runs/38780230735/1/collections/30cc7f6accc48ab9b1e0b66a44ced9ecaba26fa64ebed617066461d0f4694a35/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113770 :MTIME 1793207956 :SHA256
   "8805cd38b2064e1ed40af114660e2fbb7bd640b9742f3980fbed07a8d1700a1e")
  (:PATH
   "spikes/results/ci/by-source/8383525c2602268b5b05d8fbdad2e9fabf5cb05a1baa8f872d0ce6f79d87755f/runs/38780230735/1/collections/30cc7f6accc48ab9b1e0b66a44ced9ecaba26fa64ebed617066461d0f4694a35/summary.lisp"
   :BYTES 5032 :DEVICE 16777232 :INODE 1560113771 :MTIME 1793207956 :SHA256
   "95181d5e5dcb23c19b5ef7641d368cf09f0efc3cf1dc32c79a24afcc0ae35058")
  (:PATH
   "spikes/results/ci/by-source/8383525c2602268b5b05d8fbdad2e9fabf5cb05a1baa8f872d0ce6f79d87755f/runs/38780230735/1/publications/5080916e396556899eee19cd599e4cf184b441565656884c10c74bb6aba0b036.lisp"
   :BYTES 740 :DEVICE 16777232 :INODE 1560113773 :MTIME 1793207956 :SHA256
   "639af94cda133d856689f5b54bf5fc1796e7b7aa9b478b7ffd5d8448ef02d4a4")
  (:PATH
   "spikes/results/ci/by-source/8383525c2602268b5b05d8fbdad2e9fabf5cb05a1baa8f872d0ce6f79d87755f/runs/38780230735/1/publications/cd8acc7769356f9f2491273caa70d0bea72acba655c3a2049e159b33c787b55a.lisp"
   :BYTES 743 :DEVICE 16777232 :INODE 1560113774 :MTIME 1793207956 :SHA256
   "3cbd500046d38401e256fe19f9772f81301ee537e76888c17b7c99ca80771dbb")
  (:PATH
   "spikes/results/ci/by-source/8b5431ac726cb4fe9115383fad6149c8101b4f71f777e1a0defcf05dd75ee397/runs/38134451393/1/collections/3031b5f8435335a2c93010e67d31830fca526904dad27468119c86566ce4f349/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113781 :MTIME 1793207956 :SHA256
   "a430e148fc2ae2f06a3f1451a7d49e6c6fdfa2a9521caef9f86bd165405636f9")
  (:PATH
   "spikes/results/ci/by-source/8b5431ac726cb4fe9115383fad6149c8101b4f71f777e1a0defcf05dd75ee397/runs/38134451393/1/collections/3031b5f8435335a2c93010e67d31830fca526904dad27468119c86566ce4f349/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113782 :MTIME 1793207956 :SHA256
   "f3556759281f5f5eb09121f1ccdcd47633732a66ac7cba0bf9574c0fee31415e")
  (:PATH
   "spikes/results/ci/by-source/8b5431ac726cb4fe9115383fad6149c8101b4f71f777e1a0defcf05dd75ee397/runs/38134451393/1/collections/3031b5f8435335a2c93010e67d31830fca526904dad27468119c86566ce4f349/summary.lisp"
   :BYTES 4000 :DEVICE 16777232 :INODE 1560113783 :MTIME 1793207956 :SHA256
   "e5726cf38e89336dd3c706c18fde10e9477e92fba9261eac1502e6d9c6569851")
  (:PATH
   "spikes/results/ci/by-source/8b5431ac726cb4fe9115383fad6149c8101b4f71f777e1a0defcf05dd75ee397/runs/38134451393/1/collections/e4ca41ed5284d75d168b5576a5114015bb95bbccc5072514766695712f119dca/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113785 :MTIME 1793207956 :SHA256
   "d35792023fce9a84b3346ca3e3560119bf628c3777b696286b249c71ae591f1e")
  (:PATH
   "spikes/results/ci/by-source/8b5431ac726cb4fe9115383fad6149c8101b4f71f777e1a0defcf05dd75ee397/runs/38134451393/1/collections/e4ca41ed5284d75d168b5576a5114015bb95bbccc5072514766695712f119dca/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113786 :MTIME 1793207956 :SHA256
   "f3556759281f5f5eb09121f1ccdcd47633732a66ac7cba0bf9574c0fee31415e")
  (:PATH
   "spikes/results/ci/by-source/8b5431ac726cb4fe9115383fad6149c8101b4f71f777e1a0defcf05dd75ee397/runs/38134451393/1/collections/e4ca41ed5284d75d168b5576a5114015bb95bbccc5072514766695712f119dca/summary.lisp"
   :BYTES 3994 :DEVICE 16777232 :INODE 1560113787 :MTIME 1793207956 :SHA256
   "10aad9ef436f94d41cbf6d624fcee45d18a0ed611bedb43c5c5bdb4751f8208f")
  (:PATH
   "spikes/results/ci/by-source/8b5431ac726cb4fe9115383fad6149c8101b4f71f777e1a0defcf05dd75ee397/runs/38134451393/1/publications/04da03b14c58fdcca19d42f4dcc72bf7db84bc5535ad9ae5a2e7557054fe03f1.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113789 :MTIME 1793207956 :SHA256
   "be4c467043a37cd8365b224b44582df209e9c6c0512a60ff8326d4c008b57a40")
  (:PATH
   "spikes/results/ci/by-source/8b5431ac726cb4fe9115383fad6149c8101b4f71f777e1a0defcf05dd75ee397/runs/38134451393/1/publications/abeb355b0b3505cf054bf5fac0b5a442a3e9b537d026c84744b19b1782dcdd80.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113790 :MTIME 1793207956 :SHA256
   "a4e1f6f0eaea43e23cf619da65e80677b38a0ae1dae7bd7964cdc8468c8c36ac")
  (:PATH
   "spikes/results/ci/by-source/8c96942bcdfa37c13b719ce402183539664b6b8896a28fd3e1be03f639303a1b/runs/38950327975/1/collections/f05b2dd0368ea2cb5384a238fa00782845389d5a55ab57747f9c2b41987795ed/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113797 :MTIME 1793207956 :SHA256
   "72a69f52a35e7e7f42b8921777ae69b94527b6934ac423f61f12ce8f8d467a33")
  (:PATH
   "spikes/results/ci/by-source/8c96942bcdfa37c13b719ce402183539664b6b8896a28fd3e1be03f639303a1b/runs/38950327975/1/collections/f05b2dd0368ea2cb5384a238fa00782845389d5a55ab57747f9c2b41987795ed/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113798 :MTIME 1793207956 :SHA256
   "bce17f4c96b0b54b9fe1921ecf59f3b084b6fb1c0ce1e9c53e6d6e6c177a9dcb")
  (:PATH
   "spikes/results/ci/by-source/8c96942bcdfa37c13b719ce402183539664b6b8896a28fd3e1be03f639303a1b/runs/38950327975/1/collections/f05b2dd0368ea2cb5384a238fa00782845389d5a55ab57747f9c2b41987795ed/summary.lisp"
   :BYTES 5555 :DEVICE 16777232 :INODE 1560113799 :MTIME 1793207956 :SHA256
   "f5743e30007679d090ab6bc97724d23a9f8321be6ad22f6973641a4d537608b8")
  (:PATH
   "spikes/results/ci/by-source/8c96942bcdfa37c13b719ce402183539664b6b8896a28fd3e1be03f639303a1b/runs/38950327975/1/publications/c9910748af7def55b25f909cd57181a4658657d49d703dd3622b2c06c9daadd9.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113801 :MTIME 1793207956 :SHA256
   "163013fdafe0b2dc19562faa82c0721f2df0f374ed73f101b9e44692aae620af")
  (:PATH
   "spikes/results/ci/by-source/8cd3993d160f603eeea7f5a6256e644f325b6fa20c6bd6c2d68ac13bcf29c72a/runs/38931113488/1/collections/0a575f392ea9a1d90320b043ea2fffd47556e0426d7da908b992172da24419a4/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113808 :MTIME 1793207956 :SHA256
   "05a6fe2a8cd545b99287ab1f8b89d8fb1aed216537cc52d2b0c3990fb834051c")
  (:PATH
   "spikes/results/ci/by-source/8cd3993d160f603eeea7f5a6256e644f325b6fa20c6bd6c2d68ac13bcf29c72a/runs/38931113488/1/collections/0a575f392ea9a1d90320b043ea2fffd47556e0426d7da908b992172da24419a4/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113809 :MTIME 1793207956 :SHA256
   "cf74068ba43b872b66425b751b61f11245cbc34800d1125ed014515cbfdaeb43")
  (:PATH
   "spikes/results/ci/by-source/8cd3993d160f603eeea7f5a6256e644f325b6fa20c6bd6c2d68ac13bcf29c72a/runs/38931113488/1/collections/0a575f392ea9a1d90320b043ea2fffd47556e0426d7da908b992172da24419a4/summary.lisp"
   :BYTES 5275 :DEVICE 16777232 :INODE 1560113810 :MTIME 1793207956 :SHA256
   "08f2e6fc67cbae61f1b9da2592ecd655f744077be0fad1417b1fbf14212781a5")
  (:PATH
   "spikes/results/ci/by-source/8cd3993d160f603eeea7f5a6256e644f325b6fa20c6bd6c2d68ac13bcf29c72a/runs/38931113488/1/publications/0acd6d2879f8dc8c66faec7430d39f70764ef9254404d464c961597232e176d1.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113812 :MTIME 1793207956 :SHA256
   "f2173bf34b3c1b9e74047ed77ec8fabc0ba980318edb13195f5e057475337168")
  (:PATH
   "spikes/results/ci/by-source/8ed4ac0db5df4e976b3644518b88c37a2c3447e499b5cbf87780d5be77a39775/runs/38144795811/1/collections/0853092398a3e94183d0eac52d67da25d05d5cd7d6309080a0f3d07ac742a9f8/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113819 :MTIME 1793207956 :SHA256
   "eb206cfe51deb4151bf2322c98932d7ab59ab8597d5f90207ac2c763ef7e0549")
  (:PATH
   "spikes/results/ci/by-source/8ed4ac0db5df4e976b3644518b88c37a2c3447e499b5cbf87780d5be77a39775/runs/38144795811/1/collections/0853092398a3e94183d0eac52d67da25d05d5cd7d6309080a0f3d07ac742a9f8/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113820 :MTIME 1793207956 :SHA256
   "2dbe93b5061cac88ae67c72410d0b0cd7c1fde14c1939c4b66c5a56702cd0142")
  (:PATH
   "spikes/results/ci/by-source/8ed4ac0db5df4e976b3644518b88c37a2c3447e499b5cbf87780d5be77a39775/runs/38144795811/1/collections/0853092398a3e94183d0eac52d67da25d05d5cd7d6309080a0f3d07ac742a9f8/summary.lisp"
   :BYTES 4278 :DEVICE 16777232 :INODE 1560113821 :MTIME 1793207956 :SHA256
   "e92ec4aff90d892d38ee7b94d71ced848e1bd0da760a82ee4155b9146d9d650f")
  (:PATH
   "spikes/results/ci/by-source/8ed4ac0db5df4e976b3644518b88c37a2c3447e499b5cbf87780d5be77a39775/runs/38144795811/1/collections/6b3e66fffc1f14fd1f3812fb25c1b9de14ca4b6d2262acf43c4565b34cad163d/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113823 :MTIME 1793207956 :SHA256
   "9c03c78b467c9d14582d4fe9bc09ee220ce8d58a30289b829fd7ea62f0e61d63")
  (:PATH
   "spikes/results/ci/by-source/8ed4ac0db5df4e976b3644518b88c37a2c3447e499b5cbf87780d5be77a39775/runs/38144795811/1/collections/6b3e66fffc1f14fd1f3812fb25c1b9de14ca4b6d2262acf43c4565b34cad163d/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113824 :MTIME 1793207956 :SHA256
   "2dbe93b5061cac88ae67c72410d0b0cd7c1fde14c1939c4b66c5a56702cd0142")
  (:PATH
   "spikes/results/ci/by-source/8ed4ac0db5df4e976b3644518b88c37a2c3447e499b5cbf87780d5be77a39775/runs/38144795811/1/collections/6b3e66fffc1f14fd1f3812fb25c1b9de14ca4b6d2262acf43c4565b34cad163d/summary.lisp"
   :BYTES 4284 :DEVICE 16777232 :INODE 1560113825 :MTIME 1793207956 :SHA256
   "4f07e9ec64b5144513e0bab118e69286c69cd4126f7f4139726f456fbb9dfd0d")
  (:PATH
   "spikes/results/ci/by-source/8ed4ac0db5df4e976b3644518b88c37a2c3447e499b5cbf87780d5be77a39775/runs/38144795811/1/publications/1505c27ea3b195709346f62080f3b4e228bc6118692762140873297a88bef440.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113827 :MTIME 1793207956 :SHA256
   "2f0be8ea26b6ddd277ea81ed774ad38f6e0a02f1f9804fe135ae99c119333888")
  (:PATH
   "spikes/results/ci/by-source/8ed4ac0db5df4e976b3644518b88c37a2c3447e499b5cbf87780d5be77a39775/runs/38144795811/1/publications/8a69b30c83f9aa43bf1c3c19a6fef8e991f42d2b3228472d6d46f5fb6159f420.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113828 :MTIME 1793207956 :SHA256
   "de41715d94ed1bf15bec6a3b3322234cf4ab4c8b6f549c4347e98e00c8a06d69")
  (:PATH
   "spikes/results/ci/by-source/946e713dd3213ad5e77daa451670f4d2c6d4a47b8e7b4add36e41e44f3f1be0b/runs/38612475958/1/collections/0c424d8a23d4070a51ff60cee9627f715422ea07be279792f0d90f53e5311587/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113835 :MTIME 1793207956 :SHA256
   "235bd84d0f490264eb95d9be7f40465ae08e40aa6d00237d435f1d2cb5c82dff")
  (:PATH
   "spikes/results/ci/by-source/946e713dd3213ad5e77daa451670f4d2c6d4a47b8e7b4add36e41e44f3f1be0b/runs/38612475958/1/collections/0c424d8a23d4070a51ff60cee9627f715422ea07be279792f0d90f53e5311587/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113836 :MTIME 1793207956 :SHA256
   "b8970fe1a44ca679fcd83cc647cee162095b113420c7634b9e12dff974ab771d")
  (:PATH
   "spikes/results/ci/by-source/946e713dd3213ad5e77daa451670f4d2c6d4a47b8e7b4add36e41e44f3f1be0b/runs/38612475958/1/collections/0c424d8a23d4070a51ff60cee9627f715422ea07be279792f0d90f53e5311587/summary.lisp"
   :BYTES 4763 :DEVICE 16777232 :INODE 1560113837 :MTIME 1793207956 :SHA256
   "c0194b216e222a3c914e183a7e0a07fd3bd9e870f22e2e92f81dec99386e60bf")
  (:PATH
   "spikes/results/ci/by-source/946e713dd3213ad5e77daa451670f4d2c6d4a47b8e7b4add36e41e44f3f1be0b/runs/38612475958/1/collections/2cb7c825f0d5b8c9a88860036ce77990ca365437ce1d6686b36c537006adc3ae/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113839 :MTIME 1793207956 :SHA256
   "fef89957742825660e9d19a1d848ce3041c6571fcf8c9be2153fa5cd9d24eda2")
  (:PATH
   "spikes/results/ci/by-source/946e713dd3213ad5e77daa451670f4d2c6d4a47b8e7b4add36e41e44f3f1be0b/runs/38612475958/1/collections/2cb7c825f0d5b8c9a88860036ce77990ca365437ce1d6686b36c537006adc3ae/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113840 :MTIME 1793207956 :SHA256
   "b8970fe1a44ca679fcd83cc647cee162095b113420c7634b9e12dff974ab771d")
  (:PATH
   "spikes/results/ci/by-source/946e713dd3213ad5e77daa451670f4d2c6d4a47b8e7b4add36e41e44f3f1be0b/runs/38612475958/1/collections/2cb7c825f0d5b8c9a88860036ce77990ca365437ce1d6686b36c537006adc3ae/summary.lisp"
   :BYTES 4757 :DEVICE 16777232 :INODE 1560113841 :MTIME 1793207956 :SHA256
   "78853b2ef2f576cfc38ca560a0b8d089f47d837b455b42bf5e79cc1a5b2c1070")
  (:PATH
   "spikes/results/ci/by-source/946e713dd3213ad5e77daa451670f4d2c6d4a47b8e7b4add36e41e44f3f1be0b/runs/38612475958/1/publications/0ec057cbfeca4997f1a5bd638411f71e9949a2c4989151a0d96e6f6c94d5a293.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113843 :MTIME 1793207956 :SHA256
   "bf6b830938fed5d4c9e8437c8e592890a674d0a104fc9250521737b1b49f95d7")
  (:PATH
   "spikes/results/ci/by-source/946e713dd3213ad5e77daa451670f4d2c6d4a47b8e7b4add36e41e44f3f1be0b/runs/38612475958/1/publications/4b851335e42bac15e64341f544632eae7835241ae86fbb1535ef7f40f8235bab.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113844 :MTIME 1793207956 :SHA256
   "ba47766316c697521d24adcadef3572c807f0bf7e199f71b32c0c6930e70f075")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/collections/82b4304d5d750ebea90dc95779b4d7730f5b4deab918ca32f693cc05effc7808/manifest.lisp"
   :BYTES 393 :DEVICE 16777232 :INODE 1560932562 :MTIME 1793305114 :SHA256
   "4721019bf4b1142e26e6ef902d7a961ecc530f1b1bf3d35afb472f1715438b6d")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/collections/82b4304d5d750ebea90dc95779b4d7730f5b4deab918ca32f693cc05effc7808/report.md"
   :BYTES 25078 :DEVICE 16777232 :INODE 1560932563 :MTIME 1793305114 :SHA256
   "a0c73b11bdf63ba1640b2e6b21d4a34168137f0777b75ab10a21a5cb872b8aa0")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/collections/82b4304d5d750ebea90dc95779b4d7730f5b4deab918ca32f693cc05effc7808/summary.lisp"
   :BYTES 30648 :DEVICE 16777232 :INODE 1560932564 :MTIME 1793305114 :SHA256
   "2b32f1e994701869ab4aefd2ae89cc01ed8913b21131e4cd073eb06cb01a67f9")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/manifest.lisp"
   :BYTES 9803 :DEVICE 16777232 :INODE 1560932568 :MTIME 1793305114 :SHA256
   "b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/c4-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560932570 :MTIME 1793305114 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/c4-driver.stdout"
   :BYTES 117 :DEVICE 16777232 :INODE 1560932571 :MTIME 1793305114 :SHA256
   "a4a243fb82148ccbdffba4bc657f86ac5b8789c52c1e21ed49d5c2d80f9c5f71")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/child-result.lisp"
   :BYTES 3313 :DEVICE 16777232 :INODE 1560932572 :MTIME 1793305114 :SHA256
   "8002dd42b4f521766182080868bb24a5950eff2f164e318c60ed372a4bbb560f")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/c4/conservazione.lisp"
   :BYTES 1085 :DEVICE 16777232 :INODE 1560932576 :MTIME 1793305114 :SHA256
   "5c62561263205e27662b929ac544d8fa50d126df24264fcd02daab9b36388efa")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/c4/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1560932577 :MTIME 1793305114 :SHA256
   "e6c6a6d2a7e116b72b5d62109ff5177d7c2e0c98c65ed01a125cfd8f17210121")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/c4/report.lisp.gz"
   :BYTES 108164 :DEVICE 16777232 :INODE 1560932578 :MTIME 1793305114 :SHA256
   "72ca7bdbd4ec9bc43b404325623b1d9bea691f0dee0f8c30746329f7c6018332")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/job/conservazione.lisp"
   :BYTES 1087 :DEVICE 16777232 :INODE 1560932580 :MTIME 1793305114 :SHA256
   "4fb5ef958747d213625dfd359335e5673ca673341d7fda4fc54f2af562412a2d")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1560932581 :MTIME 1793305114 :SHA256
   "d379b061c6cbf94899f4400ea80d94935cf5adc54fa2a1e073051049ca701e84")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/job/report.lisp.gz"
   :BYTES 96968 :DEVICE 16777232 :INODE 1560932582 :MTIME 1793305114 :SHA256
   "2ec17e7d1aa62f53f4b4bfa5f3474ab131f60e8af850550b790dbd38ee611230")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/links/conservazione.lisp"
   :BYTES 1091 :DEVICE 16777232 :INODE 1560932584 :MTIME 1793305114 :SHA256
   "b97d0ea89fd633828ee0188d560033c3c9e2612ddf278c01a65e9bd0cb4c8dee")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/links/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1560932585 :MTIME 1793305114 :SHA256
   "c7bb28bf4d8763b4df6b1e47be4450d8fa5d71afdc962ec2223c4bd27a90e955")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/links/report.lisp.gz"
   :BYTES 96952 :DEVICE 16777232 :INODE 1560932586 :MTIME 1793305114 :SHA256
   "da37d54dcb8ce8758f32981b2da5ae3951988b19e19befcc3bf2264c267b9216")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/lint/conservazione.lisp"
   :BYTES 1089 :DEVICE 16777232 :INODE 1560932588 :MTIME 1793305114 :SHA256
   "2b8a5b8a93cc73a46b7c18f2960accd002f6299b97446f17ef81a855b4ec30d5")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/lint/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1560932589 :MTIME 1793305114 :SHA256
   "317bd36827ec05b511a580fbe178c24101288039263654c04b837c1552687121")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/lint/report.lisp.gz"
   :BYTES 96945 :DEVICE 16777232 :INODE 1560932590 :MTIME 1793305114 :SHA256
   "2cd6cf6e9f8ad8f1a4ee15ec302a8ff70ae853f0c6d459ce0d02039b05437fdc")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/trace/conservazione.lisp"
   :BYTES 1091 :DEVICE 16777232 :INODE 1560932592 :MTIME 1793305114 :SHA256
   "7fd4a317355ef71fff79f0f367f7d7aa30b756f7ea844ae0bd5fbdd8d459132b")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/trace/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1560932593 :MTIME 1793305114 :SHA256
   "d81dc69dfbefd8d2fbca37cd2df6f592aa0e9e5d10bfc48e4c6fe02340f98da3")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/commands/trace/report.lisp.gz"
   :BYTES 96967 :DEVICE 16777232 :INODE 1560932594 :MTIME 1793305114 :SHA256
   "a66369bc1caf6977c9e6f76e67dda27a3e52585d3c2f50e101961cc469cb7c96")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1560932595 :MTIME 1793305114 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560932596 :MTIME 1793305114 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/job-driver.stdout"
   :BYTES 379 :DEVICE 16777232 :INODE 1560932597 :MTIME 1793305114 :SHA256
   "a85c27e5597a954a0315145bcfa9506e2bd8019bab38fd4d7073a69805fe1dd9")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/links-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560932598 :MTIME 1793305114 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/links-driver.stdout"
   :BYTES 321 :DEVICE 16777232 :INODE 1560932599 :MTIME 1793305114 :SHA256
   "e299ed677538dd96f1a82312b708ce2fa820dd6a5f77a0ad98954bd1370bf67d")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/links.lisp"
   :BYTES 181 :DEVICE 16777232 :INODE 1560932600 :MTIME 1793305114 :SHA256
   "8ae97a7bb07cd407b2293b9a8e727aa0627afe23b1abd6e159bf4555e4e8ab37")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/lint-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560932601 :MTIME 1793305114 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/lint-driver.stdout"
   :BYTES 314 :DEVICE 16777232 :INODE 1560932602 :MTIME 1793305114 :SHA256
   "681f95fc225e51ecc0704b0d466d8ac3763a97d97e667aac69871c6ece23224e")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/lint.lisp"
   :BYTES 354 :DEVICE 16777232 :INODE 1560932603 :MTIME 1793305114 :SHA256
   "fae1e327ee9a84f5d755c2f74e1f2ef96af3296b4778f3fcc7979ee8cc0ba452")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/trace-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560932604 :MTIME 1793305114 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/trace-driver.stdout"
   :BYTES 319 :DEVICE 16777232 :INODE 1560932605 :MTIME 1793305114 :SHA256
   "c569f3b330eafc9a28d170eb5d10d53e89f12aff83593862589f90426363634e")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/raw/trace.lisp"
   :BYTES 1607 :DEVICE 16777232 :INODE 1560932606 :MTIME 1793305114 :SHA256
   "9a5f3227622e77ca2cb215792e508cbe1395604ad74405b78179fdfbd8a76c13")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/audit/b0414536fbe5fa4f60e65d6cb21f973b6d0e9945903b76e2fd337add8a21361f/result.lisp"
   :BYTES 8703 :DEVICE 16777232 :INODE 1560932607 :MTIME 1793305114 :SHA256
   "b0e32106e57c30095eba173f44c6b3cae659ff68e8eebb6aa4f23c7b79d1f039")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/manifest.lisp"
   :BYTES 8312 :DEVICE 16777232 :INODE 1560932610 :MTIME 1793305114 :SHA256
   "a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/child-result.lisp"
   :BYTES 314 :DEVICE 16777232 :INODE 1560932612 :MTIME 1793305114 :SHA256
   "5dc251b658f9ae199ddc7b2dd9c0bcc766f5e5549a4fe9ad936957c2fa4a324d")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/child-result.lisp.gz"
   :BYTES 2324 :DEVICE 16777232 :INODE 1560932613 :MTIME 1793305114 :SHA256
   "72d0ae28f18bbdd64586ce103f78faacb58f1d979ccd826c64653790de6230a4")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/commands/job/conservazione.lisp"
   :BYTES 1087 :DEVICE 16777232 :INODE 1560932616 :MTIME 1793305114 :SHA256
   "f22ca60b36e6c9632ae0b1c52b82b4dbd48e53c9f83ac94ba018cb0f0bb2eca0")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1560932617 :MTIME 1793305114 :SHA256
   "e73ca3676e7ea8010f774126e62e43768c863b51dd7db3a7b363757fb90e6cdf")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/commands/job/report.lisp.gz"
   :BYTES 96961 :DEVICE 16777232 :INODE 1560932618 :MTIME 1793305114 :SHA256
   "95ad703a0b36b032810eacbcef60b1e930443ebf25084fca97f1dc249318bfc1")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/coordinator-identity.lisp"
   :BYTES 212 :DEVICE 16777232 :INODE 1560932619 :MTIME 1793305114 :SHA256
   "8a22e9f5b4e00f5306d2124a91ee94d99fc6ac19f5fb9d499307e2ee1b827ba9")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1560932620 :MTIME 1793305114 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560932621 :MTIME 1793305114 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/job-driver.stdout"
   :BYTES 375 :DEVICE 16777232 :INODE 1560932622 :MTIME 1793305114 :SHA256
   "368ea1d4a81f5961713dd7290a61804260d97f60c54ec89c70a6742d2e2337bf")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/measure-replica-01.lisp"
   :BYTES 2118 :DEVICE 16777232 :INODE 1560932623 :MTIME 1793305114 :SHA256
   "780f7d5b448b75b69d7483aea3680e7aa83e36c220e6bf7af7bedd4038aaaa2c")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/measure-replica-01.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1560932624 :MTIME 1793305114 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/measure-replica-02.lisp"
   :BYTES 2118 :DEVICE 16777232 :INODE 1560932625 :MTIME 1793305114 :SHA256
   "b341cdd7cdaf36c5fad5666aaaf7a23fb675d837263aec5fbcd4f8bb44188dda")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/measure-replica-02.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1560932626 :MTIME 1793305114 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/measure-replica-03.lisp"
   :BYTES 2111 :DEVICE 16777232 :INODE 1560932627 :MTIME 1793305114 :SHA256
   "51f9e96f9927193323c097c6008ddbdca67618316e0e9bc6c430ccb330b99529")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/measure-replica-03.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1560932628 :MTIME 1793305114 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/measure-replica-04.lisp"
   :BYTES 2119 :DEVICE 16777232 :INODE 1560932629 :MTIME 1793305114 :SHA256
   "4ac31d6aa79435461ddc75d5e4938d85f29193110bae5fdb4b792bc13100f521")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/measure-replica-04.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1560932630 :MTIME 1793305114 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/measure-replica-05.lisp"
   :BYTES 2119 :DEVICE 16777232 :INODE 1560932631 :MTIME 1793305114 :SHA256
   "c629a825dc370f421f8b79c8b142c1b586441cd4bbb8b22a40254d255da86a35")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/measure-replica-05.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1560932632 :MTIME 1793305114 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/measure.lisp"
   :BYTES 309 :DEVICE 16777232 :INODE 1560932633 :MTIME 1793305114 :SHA256
   "f5c37f0117bf59659b63b9e5fd68ab5771479f9df2eba0c5d6cf636ca54a9530")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/raw/measure.lisp.gz"
   :BYTES 2324 :DEVICE 16777232 :INODE 1560932634 :MTIME 1793305114 :SHA256
   "72d0ae28f18bbdd64586ce103f78faacb58f1d979ccd826c64653790de6230a4")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/bench/a5c70e55682cdd82cc519838be5a599532edd112b207c95559735e49094e8d12/result.lisp"
   :BYTES 18489 :DEVICE 16777232 :INODE 1560932635 :MTIME 1793305114 :SHA256
   "19c08fc8ebd2c20233242924b5b3a5abb565649a3e0286a1fb0edee4631821a1")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/manifest.lisp"
   :BYTES 9087 :DEVICE 16777232 :INODE 1560932638 :MTIME 1793305114 :SHA256
   "2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/child-result.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1560932640 :MTIME 1793305114 :SHA256
   "da0288640780287ae0dca0a0ac17b80c3c90d48185eecb1645fe11749b4a8c04")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/child-result.lisp.gz"
   :BYTES 35238 :DEVICE 16777232 :INODE 1560932641 :MTIME 1793305114 :SHA256
   "6f063c5a9bc530db78d0ef338aeaf2a116501794f47f2b7c424be5bbcdf41b10")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/commands/job/conservazione.lisp"
   :BYTES 1093 :DEVICE 16777232 :INODE 1560932644 :MTIME 1793305114 :SHA256
   "9e54c764a3c34bd8b6881d9a90d986d1892d65f6911ff6496655238d135c66d4")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1560932645 :MTIME 1793305114 :SHA256
   "12ca8a6f511681f2c3fcb90b3e68679f10273df4b069179b499931b377d12b79")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/commands/job/report.lisp.gz"
   :BYTES 96968 :DEVICE 16777232 :INODE 1560932646 :MTIME 1793305114 :SHA256
   "8fb727cd13a88d1ccb58826dbd48a3bf17a2bf7c639ae7bc725a28aa70f6dcbe")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage-tests.events.lisp"
   :BYTES 326 :DEVICE 16777232 :INODE 1560932647 :MTIME 1793305114 :SHA256
   "142a650fd34ddafbdb6a220272b56f596d59e413052b8ed0535af2fa4146ba81")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage-tests.events.lisp.gz"
   :BYTES 76557 :DEVICE 16777232 :INODE 1560932648 :MTIME 1793305114 :SHA256
   "f5cf8a4c8d201ae2bdde2068d1a3882f0f36d69ca5072957da2419848abaacce")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage-tests.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1560932649 :MTIME 1793305114 :SHA256
   "3c6fc101f3777bda5241e9884db23004e9069fce566a3abc21f21e166df5a9e7")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage-tests.lisp.gz"
   :BYTES 54736 :DEVICE 16777232 :INODE 1560932650 :MTIME 1793305114 :SHA256
   "31d7aa5d69b54e4703caac7344a44fff3f773f2cac8263b119bef0eed5afc145")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage.expected.lisp"
   :BYTES 320 :DEVICE 16777232 :INODE 1560932651 :MTIME 1793305114 :SHA256
   "fd493ac0120c99db2368f6f9a662e65252e690a49903d166b31b3b5f0c033ea6")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage.expected.lisp.gz"
   :BYTES 15315 :DEVICE 16777232 :INODE 1560932652 :MTIME 1793305114 :SHA256
   "1839341c8020ec1bd1a061fffb60ee600b175451fb5550bf43c09c8e52662073")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage.lcov"
   :BYTES 312 :DEVICE 16777232 :INODE 1560932653 :MTIME 1793305114 :SHA256
   "e2d8fabb8c3b61d4dc0ca52603cf52045f53d4fb589540b239e6d2b83daf0749")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage.lcov.gz"
   :BYTES 30169 :DEVICE 16777232 :INODE 1560932654 :MTIME 1793305114 :SHA256
   "66705cb56fbdf93e7cd94688af5266a77c9a90a8e77f4d7587212c89ff8da936")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage.lisp"
   :BYTES 312 :DEVICE 16777232 :INODE 1560932655 :MTIME 1793305114 :SHA256
   "282ad9fb37e0f031628b254dbe18b9dfef95c337178f2096693db246e0afb371")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage.lisp.gz"
   :BYTES 35238 :DEVICE 16777232 :INODE 1560932656 :MTIME 1793305114 :SHA256
   "6f063c5a9bc530db78d0ef338aeaf2a116501794f47f2b7c424be5bbcdf41b10")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage.stderr.log"
   :BYTES 320 :DEVICE 16777232 :INODE 1560932657 :MTIME 1793305114 :SHA256
   "8a37d90f42f770d59ae188f468bba79c9caff2813563b58a00713f28713cf1b9")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage.stderr.log.gz"
   :BYTES 147460 :DEVICE 16777232 :INODE 1560932658 :MTIME 1793305114 :SHA256
   "9b222df364bb4749a95538f6f67d19a4e9dfe9e4063bdf83c1fb66f4e5f5402c")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage.stdout.log"
   :BYTES 318 :DEVICE 16777232 :INODE 1560932659 :MTIME 1793305114 :SHA256
   "81d8e3a2814832248a0ecf803b06f5d0310768edc7f7b78fd0d7564939640414")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/coverage.stdout.log.gz"
   :BYTES 29820 :DEVICE 16777232 :INODE 1560932660 :MTIME 1793305114 :SHA256
   "529b6b139dad3e74a7cc8b686cf996851d70871f35adaa9e2b71f7813b664313")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1560932661 :MTIME 1793305114 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560932662 :MTIME 1793305114 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/raw/job-driver.stdout"
   :BYTES 388 :DEVICE 16777232 :INODE 1560932663 :MTIME 1793305114 :SHA256
   "b1793e0d9b973e8f34df0f072476d0d61efd96b1d0bed7e0892d8fcd7a0c64d8")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/coverage/2157bd08a14bd420b6e3881cce875683a1ab233e0c2865a05d29ccb18a321981/result.lisp"
   :BYTES 8784 :DEVICE 16777232 :INODE 1560932664 :MTIME 1793305114 :SHA256
   "5f603c745264cd0338a0be6224f74138e0120f5f2824c17df75cbd9f30b5dd57")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/plan/4b67e7b44cc33ae5fb9b9bf5ae26fe602f5ed7e73b3b681207a4699a6e202b9a/manifest.lisp"
   :BYTES 5564 :DEVICE 16777232 :INODE 1560932667 :MTIME 1793305114 :SHA256
   "4b67e7b44cc33ae5fb9b9bf5ae26fe602f5ed7e73b3b681207a4699a6e202b9a")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/plan/4b67e7b44cc33ae5fb9b9bf5ae26fe602f5ed7e73b3b681207a4699a6e202b9a/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1560932669 :MTIME 1793305114 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/plan/4b67e7b44cc33ae5fb9b9bf5ae26fe602f5ed7e73b3b681207a4699a6e202b9a/raw/sources.lisp"
   :BYTES 308 :DEVICE 16777232 :INODE 1560932670 :MTIME 1793305114 :SHA256
   "340cee70cd422294203c13d178dd992e66a86ea33ebae76a01c7a5be73960b9d")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/plan/4b67e7b44cc33ae5fb9b9bf5ae26fe602f5ed7e73b3b681207a4699a6e202b9a/raw/sources.lisp.gz"
   :BYTES 1135 :DEVICE 16777232 :INODE 1560932671 :MTIME 1793305114 :SHA256
   "63546276fc80aa402d03e5aa87d8d3378624cf4d5c7d8f5272ed0f1332ad1b52")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/plan/4b67e7b44cc33ae5fb9b9bf5ae26fe602f5ed7e73b3b681207a4699a6e202b9a/result.lisp"
   :BYTES 9692 :DEVICE 16777232 :INODE 1560932672 :MTIME 1793305114 :SHA256
   "7d54d8099b8f32819edf7e4a18051c2040a5b565a67e9b3a953cea14aa97da1d")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/manifest.lisp"
   :BYTES 7531 :DEVICE 16777232 :INODE 1560932675 :MTIME 1793305114 :SHA256
   "34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/child-result.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1560932677 :MTIME 1793305114 :SHA256
   "98c7af7b4b8d3a8e634fd7bff75a5da225537b6c3ba9c06128547ed0c70d1458")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/child-result.lisp.gz"
   :BYTES 55772 :DEVICE 16777232 :INODE 1560932678 :MTIME 1793305114 :SHA256
   "79e1b66ee38130bdead247c0d75e4cffe1fac6f753e8dd2a020f9583c1288fa1")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/commands/job/conservazione.lisp"
   :BYTES 1101 :DEVICE 16777232 :INODE 1560932681 :MTIME 1793305114 :SHA256
   "22fe43f4fc84e5d30136919e16d57070216d6bfdf9e7765ef24c45ac8a52ce36")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/commands/job/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1560932682 :MTIME 1793305114 :SHA256
   "274abab782eeb59813975807559cd8c01072e0a3f2116f6d7382bc6ca86190e9")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/commands/job/report.lisp.gz"
   :BYTES 139260 :DEVICE 16777232 :INODE 1560932683 :MTIME 1793305114 :SHA256
   "8b5a01c3efca6da7431ec7aa2d9c221d7c1fd00af07704b499c39cf44ffee349")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1560932684 :MTIME 1793305114 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560932685 :MTIME 1793305114 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/job-driver.stdout"
   :BYTES 396 :DEVICE 16777232 :INODE 1560932686 :MTIME 1793305114 :SHA256
   "cb3cc3f4af154d178b12142e121ab5538e5e727739351fc6f26661584f46c29a")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/tests.events.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1560932687 :MTIME 1793305114 :SHA256
   "91971ad4526021e3ef20d3feff9aa4e5fe5f3f39c42e08059c26bbad6faf9f32")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/tests.events.lisp.gz"
   :BYTES 118309 :DEVICE 16777232 :INODE 1560932688 :MTIME 1793305114 :SHA256
   "63e410b5cc1213e3ab820e1521f9b55555378c4567f1614bb262272b7e510566")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/tests.expected.lisp"
   :BYTES 315 :DEVICE 16777232 :INODE 1560932689 :MTIME 1793305114 :SHA256
   "b1f97398e8ff59652535f42a446902fae73487a1fdf98fcc2dde92c710578d31")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/tests.expected.lisp.gz"
   :BYTES 1073 :DEVICE 16777232 :INODE 1560932690 :MTIME 1793305114 :SHA256
   "2b80a84cf65b3ba166c1866964cff15941e78ff049d851de31a19f6a8e4f8368")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/tests.lisp"
   :BYTES 309 :DEVICE 16777232 :INODE 1560932691 :MTIME 1793305114 :SHA256
   "c63c9496e0066936d908ab86d8a5c32e253ed11f272941951f2c59bb4b3cecd9")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/raw/tests.lisp.gz"
   :BYTES 55772 :DEVICE 16777232 :INODE 1560932692 :MTIME 1793305114 :SHA256
   "79e1b66ee38130bdead247c0d75e4cffe1fac6f753e8dd2a020f9583c1288fa1")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-linux/34d4c9319751c828b9d403cb7c5c7d14210cf9ef7bc98eab3ac03bcee189bf9a/result.lisp"
   :BYTES 5547 :DEVICE 16777232 :INODE 1560932693 :MTIME 1793305114 :SHA256
   "c759658a96b5b493e5008c9f94418bbe1db045514ce8dbe6229d339b5e10099c")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/manifest.lisp"
   :BYTES 7532 :DEVICE 16777232 :INODE 1560932696 :MTIME 1793305114 :SHA256
   "8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/child-result.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1560932698 :MTIME 1793305114 :SHA256
   "f53297d4e302eea070b2779c1d0a1ed9082878214110e162e57687b0894eda1b")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/child-result.lisp.gz"
   :BYTES 61911 :DEVICE 16777232 :INODE 1560932699 :MTIME 1793305114 :SHA256
   "e945b9fba6a76cc0ddd478157a1c9f173c896f1d1044d19003688ae72fd1dc16")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/commands/job/conservazione.lisp"
   :BYTES 1106 :DEVICE 16777232 :INODE 1560932702 :MTIME 1793305114 :SHA256
   "82c5f6290e813a50dc544de4200f06e0f779d3f9eec5e8eb3514e59479d49ec5")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/commands/job/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1560932703 :MTIME 1793305114 :SHA256
   "b6a7c493bf12f036d80e279eb50fae691e9a7d33f754b1e55e60697ae5db98d6")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/commands/job/report.lisp.gz"
   :BYTES 140502 :DEVICE 16777232 :INODE 1560932704 :MTIME 1793305114 :SHA256
   "30fbec42e1ae647a8cb7da96cb5220b62ff5c35a56259ed9de30d4d093130ee2")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/installation.lisp"
   :BYTES 593 :DEVICE 16777232 :INODE 1560932705 :MTIME 1793305114 :SHA256
   "6934bedfe5d5d1332d8d2294e30dfe62c132a74c2f679b0be2058b3992c22a4a")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1560932706 :MTIME 1793305114 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/job-driver.stdout"
   :BYTES 400 :DEVICE 16777232 :INODE 1560932707 :MTIME 1793305114 :SHA256
   "cb950b11c74b2057982eed2ee1df24a43921d19cf4c2b4f3873837ed197e6304")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/tests.events.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1560932708 :MTIME 1793305114 :SHA256
   "b4d6c74cb65933bbf026bf122ad015001656b78d073144d270ad4a2db2e51be4")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/tests.events.lisp.gz"
   :BYTES 133678 :DEVICE 16777232 :INODE 1560932709 :MTIME 1793305114 :SHA256
   "003afe67e99b7be5a7184f87fa7b0c82e8e157710d75ea174d04c704bd0d98ef")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/tests.expected.lisp"
   :BYTES 315 :DEVICE 16777232 :INODE 1560932710 :MTIME 1793305114 :SHA256
   "b1f97398e8ff59652535f42a446902fae73487a1fdf98fcc2dde92c710578d31")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/tests.expected.lisp.gz"
   :BYTES 1073 :DEVICE 16777232 :INODE 1560932711 :MTIME 1793305114 :SHA256
   "2b80a84cf65b3ba166c1866964cff15941e78ff049d851de31a19f6a8e4f8368")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/tests.lisp"
   :BYTES 309 :DEVICE 16777232 :INODE 1560932712 :MTIME 1793305114 :SHA256
   "a0ec3c4ccd328741463d2b8fc51b8e532d590cdb4a4b0a0a5ea53db645ad1626")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/raw/tests.lisp.gz"
   :BYTES 61911 :DEVICE 16777232 :INODE 1560932713 :MTIME 1793305114 :SHA256
   "e945b9fba6a76cc0ddd478157a1c9f173c896f1d1044d19003688ae72fd1dc16")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/payloads/verify-macos/8013b8ef8d1265e6ec1c4a8014dfd31271f860aa285dc203e786a1d4b40fce61/result.lisp"
   :BYTES 5551 :DEVICE 16777232 :INODE 1560932714 :MTIME 1793305114 :SHA256
   "2c747336aac4451b8cabc699287e456305cb949d763c8b0bc5c268c19aaa84c6")
  (:PATH
   "spikes/results/ci/by-source/98f6f93cc785e8fec9a2746031caca320b0c61fb7a2466917218bf42d75568f9/runs/40874557236/1/publications/277d8756d49ad601f3cb78bff79c45062e618d08e29cbcf94d9c094c05bf8d77.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560932716 :MTIME 1793305114 :SHA256
   "2701be588db297a31745baffcbd1c6c7c8bfd9fc4f67f77072a21e4ccd4623e5")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138029131/1/collections/61013e0d7dd33792b9c6eb637eafc2cca4b529a2935b9f7ed3c1867be52d0a11/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113851 :MTIME 1793207956 :SHA256
   "73acf35bb89223a8c740f1ef668934e03f478c1fe2f06a99a2677e71f8061a57")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138029131/1/collections/61013e0d7dd33792b9c6eb637eafc2cca4b529a2935b9f7ed3c1867be52d0a11/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113852 :MTIME 1793207956 :SHA256
   "3b72ab3f761494f330eb85997b64f0106c7e0e51148d8ce07f71f93944ca4e97")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138029131/1/collections/61013e0d7dd33792b9c6eb637eafc2cca4b529a2935b9f7ed3c1867be52d0a11/summary.lisp"
   :BYTES 4221 :DEVICE 16777232 :INODE 1560113853 :MTIME 1793207956 :SHA256
   "e570c50f26c791dfceddf8df683c1a7af021fef54dc0f04f457b388b870bc10a")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138029131/1/collections/ae28b89c1e5d77152c8bdff0ba42c36f55d818a0277695e8cf1fed50a2db7399/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113855 :MTIME 1793207956 :SHA256
   "7441117ad5b9bc3c7b12fcc6c437b51b30a95624a84427ba3b987a461010fe66")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138029131/1/collections/ae28b89c1e5d77152c8bdff0ba42c36f55d818a0277695e8cf1fed50a2db7399/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113856 :MTIME 1793207956 :SHA256
   "3b72ab3f761494f330eb85997b64f0106c7e0e51148d8ce07f71f93944ca4e97")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138029131/1/collections/ae28b89c1e5d77152c8bdff0ba42c36f55d818a0277695e8cf1fed50a2db7399/summary.lisp"
   :BYTES 4227 :DEVICE 16777232 :INODE 1560113857 :MTIME 1793207956 :SHA256
   "8eb78962277263699215f4120de027071b4ff950a571d8831e7904396a6c9aac")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138029131/1/publications/716066ce6a23ac7f8331504d4d8880978e8a2d688cccfce6e7087cb21f6b64cd.lisp"
   :BYTES 734 :DEVICE 16777232 :INODE 1560113859 :MTIME 1793207956 :SHA256
   "f23071d5b63687878d495c9c588f8bec16fcd1af90c05fe8730309b249ea833c")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138029131/1/publications/f4eaba4b184a3c8985211a278fdcf5d40aabd3bc3a487be89214cd94d9c93dd7.lisp"
   :BYTES 731 :DEVICE 16777232 :INODE 1560113860 :MTIME 1793207956 :SHA256
   "9a2639c6571afda1f5722c35570b7ae68307e4f11d73ab9edf01a0f091d31065")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138503144/1/collections/aa38270a57cf8641af685a95785c036d75634356da91bc7261b9488ab0be0298/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113865 :MTIME 1793207956 :SHA256
   "389b39e0db55a22f7958954e5c3c0da52c6829cdb668c912727f2fc780e28257")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138503144/1/collections/aa38270a57cf8641af685a95785c036d75634356da91bc7261b9488ab0be0298/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113866 :MTIME 1793207956 :SHA256
   "644801a2a5ce5173afc451a9b4065ba3339c743cfbb24ffa9bf7cb48a4d7f4c7")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138503144/1/collections/aa38270a57cf8641af685a95785c036d75634356da91bc7261b9488ab0be0298/summary.lisp"
   :BYTES 4176 :DEVICE 16777232 :INODE 1560113867 :MTIME 1793207956 :SHA256
   "9eb904b98ed7707314dcf8d58cd725e562701b273dd6ae287933dcf0133ae565")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138503144/1/collections/fe79308ee6019fddf2388cd0222b5679ed6afecbff83da2ab00daeb36734e052/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113869 :MTIME 1793207956 :SHA256
   "8f238b6dd3a316f987a5f08f90fc2e320925e1f40fb523e3ddb467814e012ca4")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138503144/1/collections/fe79308ee6019fddf2388cd0222b5679ed6afecbff83da2ab00daeb36734e052/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113870 :MTIME 1793207956 :SHA256
   "644801a2a5ce5173afc451a9b4065ba3339c743cfbb24ffa9bf7cb48a4d7f4c7")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138503144/1/collections/fe79308ee6019fddf2388cd0222b5679ed6afecbff83da2ab00daeb36734e052/summary.lisp"
   :BYTES 4170 :DEVICE 16777232 :INODE 1560113871 :MTIME 1793207956 :SHA256
   "0bb77ea6efb75c2f40cedbbce57d318dad96dbf5d734272c98ca644b2acb9f1b")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138503144/1/publications/046a253bece870f7de18f5299f57176be6de7d55e7abcab3cb1c9d66df51f55b.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113873 :MTIME 1793207956 :SHA256
   "f53a01a2a3e1a71b7690f5be6d290b9629e62ea08a97e5568d0eb92a4b079ea4")
  (:PATH
   "spikes/results/ci/by-source/9b8f785a86e44dd71f386e64071b4b34f49eb31df27b2c2dbbed3779e8d0b004/runs/38138503144/1/publications/bbbd9d140c3e0f7859b7c55edeaa81598cc8d634e4ff4299ee1c0edad7379379.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113874 :MTIME 1793207956 :SHA256
   "078c809dd23bea13f26a9c9ea09903f4c0bb952a075686723d8ed15653b5e9f0")
  (:PATH
   "spikes/results/ci/by-source/9da92dd146553cfefc8fb685cff060ebf02d83a208992c31b92b2f89f4ef390b/runs/38471648778/1/collections/331591e1ba841b1c2218ce6ff3ec13a0d32961eeecbedfc614d8cfd487b4e618/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113881 :MTIME 1793207956 :SHA256
   "396813134c439897b736c914617cd0c7266ff38cc459f17f308983b7dfd380f1")
  (:PATH
   "spikes/results/ci/by-source/9da92dd146553cfefc8fb685cff060ebf02d83a208992c31b92b2f89f4ef390b/runs/38471648778/1/collections/331591e1ba841b1c2218ce6ff3ec13a0d32961eeecbedfc614d8cfd487b4e618/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113882 :MTIME 1793207956 :SHA256
   "0c966af7e6d76ffad34efb6369d640a707203aa542ada308a1a041d64cdb3ffd")
  (:PATH
   "spikes/results/ci/by-source/9da92dd146553cfefc8fb685cff060ebf02d83a208992c31b92b2f89f4ef390b/runs/38471648778/1/collections/331591e1ba841b1c2218ce6ff3ec13a0d32961eeecbedfc614d8cfd487b4e618/summary.lisp"
   :BYTES 4657 :DEVICE 16777232 :INODE 1560113883 :MTIME 1793207956 :SHA256
   "3d528f7d0a819d2edc8844ad54cea99ac0b396736565f6b5349a866f014297e3")
  (:PATH
   "spikes/results/ci/by-source/9da92dd146553cfefc8fb685cff060ebf02d83a208992c31b92b2f89f4ef390b/runs/38471648778/1/collections/5ddf66f5b0d7666a746d41a06edd14df9060c5519ffce0041f9c730a679f8c57/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113885 :MTIME 1793207956 :SHA256
   "3a8de1cf13712424a554dbde436759ccb9e4f122c8f73420ffe778e42a1657d3")
  (:PATH
   "spikes/results/ci/by-source/9da92dd146553cfefc8fb685cff060ebf02d83a208992c31b92b2f89f4ef390b/runs/38471648778/1/collections/5ddf66f5b0d7666a746d41a06edd14df9060c5519ffce0041f9c730a679f8c57/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113886 :MTIME 1793207956 :SHA256
   "0c966af7e6d76ffad34efb6369d640a707203aa542ada308a1a041d64cdb3ffd")
  (:PATH
   "spikes/results/ci/by-source/9da92dd146553cfefc8fb685cff060ebf02d83a208992c31b92b2f89f4ef390b/runs/38471648778/1/collections/5ddf66f5b0d7666a746d41a06edd14df9060c5519ffce0041f9c730a679f8c57/summary.lisp"
   :BYTES 4663 :DEVICE 16777232 :INODE 1560113887 :MTIME 1793207956 :SHA256
   "72fcc616d23c3658d4198df43f811071c95ed554760214176b07710d5a61a980")
  (:PATH
   "spikes/results/ci/by-source/9da92dd146553cfefc8fb685cff060ebf02d83a208992c31b92b2f89f4ef390b/runs/38471648778/1/publications/3ab6724728af46a7cf4f34ec62441918aa06ad9b0ed5a383f8404a8a3cdc4ff0.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113889 :MTIME 1793207956 :SHA256
   "6a14702f733f9a2d639ff1fca889e1f774497f6e01f4d951fcc7231a4692a27f")
  (:PATH
   "spikes/results/ci/by-source/9da92dd146553cfefc8fb685cff060ebf02d83a208992c31b92b2f89f4ef390b/runs/38471648778/1/publications/755b872ca2d751b29fb9faaef884dfb08680e13eea07929d23daeab52bdd9012.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113890 :MTIME 1793207956 :SHA256
   "62d82551d0f203d350bb4a60b3edfeff45c079983fec6bc67ef24cdca34a6db8")
  (:PATH
   "spikes/results/ci/by-source/a432d6c5d20415fa89d8241eca35f1aec8da46bdde5ed0c5e8434a571b5be596/runs/38133122535/1/collections/26224e9e246da68b3125db9a215b8d2815715740592787713551ccf3152f1545/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113897 :MTIME 1793207956 :SHA256
   "9e25d354a01b69c689a488ff7d7b003997b3779b7240a82c05ad2ab7c2611052")
  (:PATH
   "spikes/results/ci/by-source/a432d6c5d20415fa89d8241eca35f1aec8da46bdde5ed0c5e8434a571b5be596/runs/38133122535/1/collections/26224e9e246da68b3125db9a215b8d2815715740592787713551ccf3152f1545/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113898 :MTIME 1793207956 :SHA256
   "7e64318ca65c83ff6c79478495b11ae5c9c5adecd44a4ed8f3b55b2d515a81b9")
  (:PATH
   "spikes/results/ci/by-source/a432d6c5d20415fa89d8241eca35f1aec8da46bdde5ed0c5e8434a571b5be596/runs/38133122535/1/collections/26224e9e246da68b3125db9a215b8d2815715740592787713551ccf3152f1545/summary.lisp"
   :BYTES 3948 :DEVICE 16777232 :INODE 1560113899 :MTIME 1793207956 :SHA256
   "c339435db90e735c3c38b8a5e0d4a4909814a81441fa246c6b69882ef2cac4e4")
  (:PATH
   "spikes/results/ci/by-source/a432d6c5d20415fa89d8241eca35f1aec8da46bdde5ed0c5e8434a571b5be596/runs/38133122535/1/collections/db27560aea31d358c70cec2c97cb50ca0afb074a81170e89e48d8cd77fea2938/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113901 :MTIME 1793207956 :SHA256
   "c2cd6423b0118db60f2e5f394752e4e3a7dff8647f55f1edc548fadcc6aa82af")
  (:PATH
   "spikes/results/ci/by-source/a432d6c5d20415fa89d8241eca35f1aec8da46bdde5ed0c5e8434a571b5be596/runs/38133122535/1/collections/db27560aea31d358c70cec2c97cb50ca0afb074a81170e89e48d8cd77fea2938/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113902 :MTIME 1793207956 :SHA256
   "7e64318ca65c83ff6c79478495b11ae5c9c5adecd44a4ed8f3b55b2d515a81b9")
  (:PATH
   "spikes/results/ci/by-source/a432d6c5d20415fa89d8241eca35f1aec8da46bdde5ed0c5e8434a571b5be596/runs/38133122535/1/collections/db27560aea31d358c70cec2c97cb50ca0afb074a81170e89e48d8cd77fea2938/summary.lisp"
   :BYTES 3942 :DEVICE 16777232 :INODE 1560113903 :MTIME 1793207956 :SHA256
   "64a290cba55382570e4fbb9d52e55e9cc0b181b01cf962d1722e414c9b8253fa")
  (:PATH
   "spikes/results/ci/by-source/a432d6c5d20415fa89d8241eca35f1aec8da46bdde5ed0c5e8434a571b5be596/runs/38133122535/1/publications/6868eb93881cb164fe07c0fbeca722b180918fea46fbcc225195f84e7eb6d7fb.lisp"
   :BYTES 725 :DEVICE 16777232 :INODE 1560113905 :MTIME 1793207956 :SHA256
   "5a4de232ad165fdff320620071c6a49eef94bd286d2daf1fb67d6cf67d407022")
  (:PATH
   "spikes/results/ci/by-source/a432d6c5d20415fa89d8241eca35f1aec8da46bdde5ed0c5e8434a571b5be596/runs/38133122535/1/publications/efa53c718103647aa2d5399207e543077955ce32e8c750f13afc72fc8f70c14d.lisp"
   :BYTES 728 :DEVICE 16777232 :INODE 1560113906 :MTIME 1793207956 :SHA256
   "a0536aca97a0a55b67f8294f5805fbde8779ed046121438d8e259fe2f6a6e8d2")
  (:PATH
   "spikes/results/ci/by-source/a5d363279e67059a8b8d862fd12023aaebd8570f4288d46bbad9cda48a987d2c/runs/38478198985/1/collections/8dcb9de56736d18e62f491e32b90f2f3de463930143315e0a88e16344275aa48/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113913 :MTIME 1793207956 :SHA256
   "f3a1b8399d2cc7fbb962999fc7812093fd2ab74f648bcd0aa94e2b219364fc6a")
  (:PATH
   "spikes/results/ci/by-source/a5d363279e67059a8b8d862fd12023aaebd8570f4288d46bbad9cda48a987d2c/runs/38478198985/1/collections/8dcb9de56736d18e62f491e32b90f2f3de463930143315e0a88e16344275aa48/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113914 :MTIME 1793207956 :SHA256
   "08f6b038cfcb5376ef44b98ccbbcaf226cab0b393361d950d3870899ff63f846")
  (:PATH
   "spikes/results/ci/by-source/a5d363279e67059a8b8d862fd12023aaebd8570f4288d46bbad9cda48a987d2c/runs/38478198985/1/collections/8dcb9de56736d18e62f491e32b90f2f3de463930143315e0a88e16344275aa48/summary.lisp"
   :BYTES 4757 :DEVICE 16777232 :INODE 1560113915 :MTIME 1793207956 :SHA256
   "f9763dedf9b37f52fab67d254d06b1ff9703d39d1db059173908c6306b92e878")
  (:PATH
   "spikes/results/ci/by-source/a5d363279e67059a8b8d862fd12023aaebd8570f4288d46bbad9cda48a987d2c/runs/38478198985/1/collections/cde45ac77b0fdfee537fef39b98eb6569817af3967c18383034671492ba740d6/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113917 :MTIME 1793207956 :SHA256
   "ddee043f5a9cc1d1c3a973dd84acea822751ba5f423b6fa9664c83d2de0dd836")
  (:PATH
   "spikes/results/ci/by-source/a5d363279e67059a8b8d862fd12023aaebd8570f4288d46bbad9cda48a987d2c/runs/38478198985/1/collections/cde45ac77b0fdfee537fef39b98eb6569817af3967c18383034671492ba740d6/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113918 :MTIME 1793207956 :SHA256
   "08f6b038cfcb5376ef44b98ccbbcaf226cab0b393361d950d3870899ff63f846")
  (:PATH
   "spikes/results/ci/by-source/a5d363279e67059a8b8d862fd12023aaebd8570f4288d46bbad9cda48a987d2c/runs/38478198985/1/collections/cde45ac77b0fdfee537fef39b98eb6569817af3967c18383034671492ba740d6/summary.lisp"
   :BYTES 4751 :DEVICE 16777232 :INODE 1560113919 :MTIME 1793207956 :SHA256
   "e0a1db72fba3f85bf11cef2f7379fe573f5866c57df5420755ca5ddf8921545f")
  (:PATH
   "spikes/results/ci/by-source/a5d363279e67059a8b8d862fd12023aaebd8570f4288d46bbad9cda48a987d2c/runs/38478198985/1/publications/50719b71a8dcbbdc736c43c1ddc1aae02eefbf722ef7ffc350b2f2c3f30281b3.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113921 :MTIME 1793207956 :SHA256
   "f5addba295aa4f02ce11277207d5b542ce64c629d0c001da9c4d0c55165b2043")
  (:PATH
   "spikes/results/ci/by-source/a5d363279e67059a8b8d862fd12023aaebd8570f4288d46bbad9cda48a987d2c/runs/38478198985/1/publications/6a3895b82f998dcb3d4035a92c308b3691140205baa17cc1c79b033ff92ec79d.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113922 :MTIME 1793207956 :SHA256
   "ec3479aca32c2436c7ad26762e43fbf44be133b1446ed2478b3eb8b18a25af17")
  (:PATH
   "spikes/results/ci/by-source/aa33c2e918baf19e703ed87a7c4ff9333dfa93fd61acdd14159514a31236c050/runs/38612041196/1/collections/1c923e452c84b691e538cc39a7f3e006dbbb320f0a7910ec40cf9e2ac7d17211/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113929 :MTIME 1793207956 :SHA256
   "5ced47ff66feeca63d8a57d9980306015f3a67eb857daca04ec60d635f7c487b")
  (:PATH
   "spikes/results/ci/by-source/aa33c2e918baf19e703ed87a7c4ff9333dfa93fd61acdd14159514a31236c050/runs/38612041196/1/collections/1c923e452c84b691e538cc39a7f3e006dbbb320f0a7910ec40cf9e2ac7d17211/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113930 :MTIME 1793207956 :SHA256
   "54e9bfa6cf0aa1c544d763c9f7b03fd784e3a18d48b072218293d7ed7f3b1c38")
  (:PATH
   "spikes/results/ci/by-source/aa33c2e918baf19e703ed87a7c4ff9333dfa93fd61acdd14159514a31236c050/runs/38612041196/1/collections/1c923e452c84b691e538cc39a7f3e006dbbb320f0a7910ec40cf9e2ac7d17211/summary.lisp"
   :BYTES 4755 :DEVICE 16777232 :INODE 1560113931 :MTIME 1793207956 :SHA256
   "48341ea38c8a0c700fd0918da651c576eb228baa557e0f8ff055b18e3b3c4c91")
  (:PATH
   "spikes/results/ci/by-source/aa33c2e918baf19e703ed87a7c4ff9333dfa93fd61acdd14159514a31236c050/runs/38612041196/1/collections/c17028c2b63913256b6d0b96ef53f471c495e232c17f0a93629e778982c2bd71/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113933 :MTIME 1793207956 :SHA256
   "4ffd0c8f7dc58bc853f6d01a426c7d028228875dffa41996e5f14cd71b89a62a")
  (:PATH
   "spikes/results/ci/by-source/aa33c2e918baf19e703ed87a7c4ff9333dfa93fd61acdd14159514a31236c050/runs/38612041196/1/collections/c17028c2b63913256b6d0b96ef53f471c495e232c17f0a93629e778982c2bd71/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113934 :MTIME 1793207956 :SHA256
   "54e9bfa6cf0aa1c544d763c9f7b03fd784e3a18d48b072218293d7ed7f3b1c38")
  (:PATH
   "spikes/results/ci/by-source/aa33c2e918baf19e703ed87a7c4ff9333dfa93fd61acdd14159514a31236c050/runs/38612041196/1/collections/c17028c2b63913256b6d0b96ef53f471c495e232c17f0a93629e778982c2bd71/summary.lisp"
   :BYTES 4761 :DEVICE 16777232 :INODE 1560113935 :MTIME 1793207956 :SHA256
   "6a31f6c0713257ef86d063108c85747a8363cfa01da185446c73816a1b2cf599")
  (:PATH
   "spikes/results/ci/by-source/aa33c2e918baf19e703ed87a7c4ff9333dfa93fd61acdd14159514a31236c050/runs/38612041196/1/publications/99e74e58b853ce4737bf793d34650d7f01b47d59645414ecba53115ddf8cbc76.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113937 :MTIME 1793207956 :SHA256
   "29afa66098eabc4e60ebebedbaeb8cb0c59709056236aa5eef2339e6c94ccf0d")
  (:PATH
   "spikes/results/ci/by-source/aa33c2e918baf19e703ed87a7c4ff9333dfa93fd61acdd14159514a31236c050/runs/38612041196/1/publications/c11406569c797c01c4313f60532d6e5f037672b45f701852958734a51abe41ca.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113938 :MTIME 1793207956 :SHA256
   "212ea70792b44a5bd0728c7c52952ffb1d2f7de209a77ebde6cd02e204866e79")
  (:PATH
   "spikes/results/ci/by-source/aa35f5bc9874b7457278f0be33ccba369e5e57be329cc139bacb12e7ff149453/runs/38137334763/1/collections/01bfd5b1b22af9335b20cf093c9b3a6e07e5e24a450d12ae57be1c6065f7f047/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113945 :MTIME 1793207956 :SHA256
   "9e0db2e2ae30eb4c716bec64d2c15c088ca886a0e310e59be8e6ef30ecaa31ec")
  (:PATH
   "spikes/results/ci/by-source/aa35f5bc9874b7457278f0be33ccba369e5e57be329cc139bacb12e7ff149453/runs/38137334763/1/collections/01bfd5b1b22af9335b20cf093c9b3a6e07e5e24a450d12ae57be1c6065f7f047/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113946 :MTIME 1793207956 :SHA256
   "703d592b6acdeb95499e8cbfa0337730cc0da37f62245261e73dccc845638c6a")
  (:PATH
   "spikes/results/ci/by-source/aa35f5bc9874b7457278f0be33ccba369e5e57be329cc139bacb12e7ff149453/runs/38137334763/1/collections/01bfd5b1b22af9335b20cf093c9b3a6e07e5e24a450d12ae57be1c6065f7f047/summary.lisp"
   :BYTES 4176 :DEVICE 16777232 :INODE 1560113947 :MTIME 1793207956 :SHA256
   "95647282293686868c36a67a0dfb2377f30873558b95e4f406438c88a4ef6835")
  (:PATH
   "spikes/results/ci/by-source/aa35f5bc9874b7457278f0be33ccba369e5e57be329cc139bacb12e7ff149453/runs/38137334763/1/collections/d61b888c1fbbe6dc5066e8488ee8f64033a74231a4495436e1a8aa3edc386ee2/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113949 :MTIME 1793207956 :SHA256
   "d168a5e01479e186c29189c6905de6fe5734b230f4878ead3352ccd1d44e8a34")
  (:PATH
   "spikes/results/ci/by-source/aa35f5bc9874b7457278f0be33ccba369e5e57be329cc139bacb12e7ff149453/runs/38137334763/1/collections/d61b888c1fbbe6dc5066e8488ee8f64033a74231a4495436e1a8aa3edc386ee2/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113950 :MTIME 1793207956 :SHA256
   "703d592b6acdeb95499e8cbfa0337730cc0da37f62245261e73dccc845638c6a")
  (:PATH
   "spikes/results/ci/by-source/aa35f5bc9874b7457278f0be33ccba369e5e57be329cc139bacb12e7ff149453/runs/38137334763/1/collections/d61b888c1fbbe6dc5066e8488ee8f64033a74231a4495436e1a8aa3edc386ee2/summary.lisp"
   :BYTES 4170 :DEVICE 16777232 :INODE 1560113951 :MTIME 1793207956 :SHA256
   "1cf709e6afe0b8bbbd68b1dabe8796e36e3d0954566ba9382889e7a66e7fbe9b")
  (:PATH
   "spikes/results/ci/by-source/aa35f5bc9874b7457278f0be33ccba369e5e57be329cc139bacb12e7ff149453/runs/38137334763/1/publications/014118df59058ab26d9c561302e72500cde97a698ffb2589b12878485d0bac9f.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113953 :MTIME 1793207956 :SHA256
   "7c697549f07776f1525ee2ab9d5ef7a3a84e01756791327db50e0fd177da3956")
  (:PATH
   "spikes/results/ci/by-source/aa35f5bc9874b7457278f0be33ccba369e5e57be329cc139bacb12e7ff149453/runs/38137334763/1/publications/1cbdc497f3f3767f41f8bcee5fa22ae357fc84dfab05892ce120d2a8c1f6818d.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113954 :MTIME 1793207956 :SHA256
   "5808ec76c3a0ea93881c74c760a492edeca4b0483f8812e6e0aff7efc602fd1d")
  (:PATH
   "spikes/results/ci/by-source/ac2e4eb33868693407763044148cc93c7cfb03bdcbc0b64fa428af10f28e8ffb/runs/38599788058/1/collections/7dbde36f54e9324630535e8698b8d7c0570105846783e30089de6f84512d0f62/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113961 :MTIME 1793207956 :SHA256
   "742d2b485d1081d4e3be9c6efd2f18b38cab1b37bd889d90a8679ba282e0a990")
  (:PATH
   "spikes/results/ci/by-source/ac2e4eb33868693407763044148cc93c7cfb03bdcbc0b64fa428af10f28e8ffb/runs/38599788058/1/collections/7dbde36f54e9324630535e8698b8d7c0570105846783e30089de6f84512d0f62/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113962 :MTIME 1793207956 :SHA256
   "8cda92ffae3d8d6e4a1a4c85af25f0148ec4690b948325d4123cc9bb74e2fc80")
  (:PATH
   "spikes/results/ci/by-source/ac2e4eb33868693407763044148cc93c7cfb03bdcbc0b64fa428af10f28e8ffb/runs/38599788058/1/collections/7dbde36f54e9324630535e8698b8d7c0570105846783e30089de6f84512d0f62/summary.lisp"
   :BYTES 4754 :DEVICE 16777232 :INODE 1560113963 :MTIME 1793207956 :SHA256
   "93d21c281626e2ab65316ad996748ffef5874e5d035b4d9dc7c7083baacfdd62")
  (:PATH
   "spikes/results/ci/by-source/ac2e4eb33868693407763044148cc93c7cfb03bdcbc0b64fa428af10f28e8ffb/runs/38599788058/1/collections/c4acb437b79737492a297425efee55066f446de20ecc89f3f6c6b8fd5fa63f3b/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113965 :MTIME 1793207956 :SHA256
   "276a141fab81a653436e576db587cff2c2d5ad59f48d2b3f367b9236130f97a6")
  (:PATH
   "spikes/results/ci/by-source/ac2e4eb33868693407763044148cc93c7cfb03bdcbc0b64fa428af10f28e8ffb/runs/38599788058/1/collections/c4acb437b79737492a297425efee55066f446de20ecc89f3f6c6b8fd5fa63f3b/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113966 :MTIME 1793207956 :SHA256
   "8cda92ffae3d8d6e4a1a4c85af25f0148ec4690b948325d4123cc9bb74e2fc80")
  (:PATH
   "spikes/results/ci/by-source/ac2e4eb33868693407763044148cc93c7cfb03bdcbc0b64fa428af10f28e8ffb/runs/38599788058/1/collections/c4acb437b79737492a297425efee55066f446de20ecc89f3f6c6b8fd5fa63f3b/summary.lisp"
   :BYTES 4760 :DEVICE 16777232 :INODE 1560113967 :MTIME 1793207956 :SHA256
   "a12a310e1ec690b3d2de12adb9624b4cc152c13078f8561a81d546d6cb38093d")
  (:PATH
   "spikes/results/ci/by-source/ac2e4eb33868693407763044148cc93c7cfb03bdcbc0b64fa428af10f28e8ffb/runs/38599788058/1/publications/032e0737e11d8975430085c20244aec03f27a1c2d770b3dd3bba64640a99eaba.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113969 :MTIME 1793207956 :SHA256
   "f1c79b0d93214610b14e9ad3f44ba1f210aae4c5a75508f58e78667f885ce2bb")
  (:PATH
   "spikes/results/ci/by-source/ac2e4eb33868693407763044148cc93c7cfb03bdcbc0b64fa428af10f28e8ffb/runs/38599788058/1/publications/3fa2f4594e961f20be1d3e53605e60226ebdb4c40953b0b880b408d2fef9ce05.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113970 :MTIME 1793207956 :SHA256
   "dc93512f561d0bbcec21d49e4e93409964e13884cf4cbec3078ee2a1397a6a51")
  (:PATH
   "spikes/results/ci/by-source/ad615a9db1758574e2ed28a1b0e4df39b36382f8829564a7ab7284a3655ec69f/runs/38460646636/1/collections/35e8894d235e3fdffc51d3438ad815579e28402624f0afae9b9aa247272cde30/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113978 :MTIME 1793207956 :SHA256
   "d07e0e1af9890e84b0d2684a744073fcb182b95eefb9dfebe57ab6c1ed108d74")
  (:PATH
   "spikes/results/ci/by-source/ad615a9db1758574e2ed28a1b0e4df39b36382f8829564a7ab7284a3655ec69f/runs/38460646636/1/collections/35e8894d235e3fdffc51d3438ad815579e28402624f0afae9b9aa247272cde30/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113979 :MTIME 1793207956 :SHA256
   "ed8a499c22324b78633097ec81792d640c9070fb0af603b63bf4f0dca15deeef")
  (:PATH
   "spikes/results/ci/by-source/ad615a9db1758574e2ed28a1b0e4df39b36382f8829564a7ab7284a3655ec69f/runs/38460646636/1/collections/35e8894d235e3fdffc51d3438ad815579e28402624f0afae9b9aa247272cde30/summary.lisp"
   :BYTES 4569 :DEVICE 16777232 :INODE 1560113980 :MTIME 1793207956 :SHA256
   "7717656ee87ceab6de7694eb5c0123f9ff3c01abc42585f88bf055604d16c86d")
  (:PATH
   "spikes/results/ci/by-source/ad615a9db1758574e2ed28a1b0e4df39b36382f8829564a7ab7284a3655ec69f/runs/38460646636/1/collections/ffd839a4336f8bb2f849e673f506d662477a1520e12b74e0e871025413d26f76/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113982 :MTIME 1793207956 :SHA256
   "6c7d1237f946b4f0a16f1399f9d57b5f11b0946d45d02d73e2d4377ddeb198eb")
  (:PATH
   "spikes/results/ci/by-source/ad615a9db1758574e2ed28a1b0e4df39b36382f8829564a7ab7284a3655ec69f/runs/38460646636/1/collections/ffd839a4336f8bb2f849e673f506d662477a1520e12b74e0e871025413d26f76/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113983 :MTIME 1793207956 :SHA256
   "ed8a499c22324b78633097ec81792d640c9070fb0af603b63bf4f0dca15deeef")
  (:PATH
   "spikes/results/ci/by-source/ad615a9db1758574e2ed28a1b0e4df39b36382f8829564a7ab7284a3655ec69f/runs/38460646636/1/collections/ffd839a4336f8bb2f849e673f506d662477a1520e12b74e0e871025413d26f76/summary.lisp"
   :BYTES 4563 :DEVICE 16777232 :INODE 1560113984 :MTIME 1793207956 :SHA256
   "211d0994e61f6202cacca60248479f68d88bad82754fb6e36f0586b13a0c35b5")
  (:PATH
   "spikes/results/ci/by-source/ad615a9db1758574e2ed28a1b0e4df39b36382f8829564a7ab7284a3655ec69f/runs/38460646636/1/publications/0bc964e527172d1ad17c0010dedf6454c686cce621af7a797af7fc21ef16c668.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560113986 :MTIME 1793207956 :SHA256
   "e65145dc14b691a8e168053c3fa7d9304c2323e81f0262b7dc9238383cd5fa62")
  (:PATH
   "spikes/results/ci/by-source/ad615a9db1758574e2ed28a1b0e4df39b36382f8829564a7ab7284a3655ec69f/runs/38460646636/1/publications/7f25e27f1e21bc6892944a3c05c89071cfd7938b20dcbad4d41326c7a760752d.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560113987 :MTIME 1793207956 :SHA256
   "d2d8f5a2cb6e6581618e694f601883032ca74c13763ebb8225ff3333f6ff3004")
  (:PATH
   "spikes/results/ci/by-source/af800555f4e7d087b175ff16b42f1e549ae11be0f215fc7c708717d066d5428d/runs/38145699246/1/collections/7e4a85f5d75187a685e61f9c123e97450f13049d381351c892573a2be5db28e1/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113994 :MTIME 1793207956 :SHA256
   "265098851968d10773aca6c6c3cc1ea285251f086cc797cb2e2990fbae60423a")
  (:PATH
   "spikes/results/ci/by-source/af800555f4e7d087b175ff16b42f1e549ae11be0f215fc7c708717d066d5428d/runs/38145699246/1/collections/7e4a85f5d75187a685e61f9c123e97450f13049d381351c892573a2be5db28e1/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113995 :MTIME 1793207956 :SHA256
   "c35cbe1ff34b4e9d0218ed3fe84d85bc3101fdf04b5d6d012daf03c15150d977")
  (:PATH
   "spikes/results/ci/by-source/af800555f4e7d087b175ff16b42f1e549ae11be0f215fc7c708717d066d5428d/runs/38145699246/1/collections/7e4a85f5d75187a685e61f9c123e97450f13049d381351c892573a2be5db28e1/summary.lisp"
   :BYTES 4286 :DEVICE 16777232 :INODE 1560113996 :MTIME 1793207956 :SHA256
   "b24faad613ee3229a542c5299c52ce7613fa67dbe46ff3c504f99cf3462b3fd0")
  (:PATH
   "spikes/results/ci/by-source/af800555f4e7d087b175ff16b42f1e549ae11be0f215fc7c708717d066d5428d/runs/38145699246/1/collections/a91d80a90d8f4fd7aab2b5de832f9cceedb59f6f73ad168e3d093448a40305d0/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560113998 :MTIME 1793207956 :SHA256
   "f66586d46ee7550488fa8cff5b1f43390b909d33d506c25f78a64bec6ea0fa09")
  (:PATH
   "spikes/results/ci/by-source/af800555f4e7d087b175ff16b42f1e549ae11be0f215fc7c708717d066d5428d/runs/38145699246/1/collections/a91d80a90d8f4fd7aab2b5de832f9cceedb59f6f73ad168e3d093448a40305d0/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560113999 :MTIME 1793207956 :SHA256
   "c35cbe1ff34b4e9d0218ed3fe84d85bc3101fdf04b5d6d012daf03c15150d977")
  (:PATH
   "spikes/results/ci/by-source/af800555f4e7d087b175ff16b42f1e549ae11be0f215fc7c708717d066d5428d/runs/38145699246/1/collections/a91d80a90d8f4fd7aab2b5de832f9cceedb59f6f73ad168e3d093448a40305d0/summary.lisp"
   :BYTES 4280 :DEVICE 16777232 :INODE 1560114000 :MTIME 1793207956 :SHA256
   "fae1b3e9e2d5341eea53fdc164a797828d942ced97109a3b704da6c5d6fca89f")
  (:PATH
   "spikes/results/ci/by-source/af800555f4e7d087b175ff16b42f1e549ae11be0f215fc7c708717d066d5428d/runs/38145699246/1/publications/6d1944be8447880bb9f9ab42fd420d3472e8339da8083be9aca45197eda658fa.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114002 :MTIME 1793207956 :SHA256
   "a357c1611232fa5c8fae297ed03195c84e806351bc3dd96bcaa286677bfa1345")
  (:PATH
   "spikes/results/ci/by-source/af800555f4e7d087b175ff16b42f1e549ae11be0f215fc7c708717d066d5428d/runs/38145699246/1/publications/ef0ee2bb86124c046394ef0f6c0da4a44522d675683ae1945ac260aaac192d96.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114003 :MTIME 1793207956 :SHA256
   "133b36a24b8e8d92d0ba7ee8ff5de8009e5a32618522fb0476264b0badf3f0f4")
  (:PATH
   "spikes/results/ci/by-source/b33d72ed2723f1161877f552c5a7e9e5ff9168dc24f0d74d3c29945b8b8a2785/runs/38805903772/1/collections/0c29a20f5d9a4792508256d7534460c09101461b74589d31b04f5bf5d717b258/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114010 :MTIME 1793207956 :SHA256
   "fbe79c3c8a9a190027908976b5f9c11b3d0907d39b8eef17812964f99a1eea85")
  (:PATH
   "spikes/results/ci/by-source/b33d72ed2723f1161877f552c5a7e9e5ff9168dc24f0d74d3c29945b8b8a2785/runs/38805903772/1/collections/0c29a20f5d9a4792508256d7534460c09101461b74589d31b04f5bf5d717b258/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114011 :MTIME 1793207956 :SHA256
   "46eec151a2985e352bc202cad37ec5860c90bbe96dc6d494c5131e1f2bd2d8f3")
  (:PATH
   "spikes/results/ci/by-source/b33d72ed2723f1161877f552c5a7e9e5ff9168dc24f0d74d3c29945b8b8a2785/runs/38805903772/1/collections/0c29a20f5d9a4792508256d7534460c09101461b74589d31b04f5bf5d717b258/summary.lisp"
   :BYTES 5213 :DEVICE 16777232 :INODE 1560114012 :MTIME 1793207956 :SHA256
   "095193859f5b9daa9c8ce008401e1a309e1179a857148135aa2a3cef8e3cfd08")
  (:PATH
   "spikes/results/ci/by-source/b33d72ed2723f1161877f552c5a7e9e5ff9168dc24f0d74d3c29945b8b8a2785/runs/38805903772/1/publications/32b0863f21e683fdb018cb3965b37599c67361dcf276a4d160a4feaea9569461.lisp"
   :BYTES 727 :DEVICE 16777232 :INODE 1560114014 :MTIME 1793207956 :SHA256
   "a1145269ffd091a77757ba20f58f4e171aff0a92a0b11a62d9e7c359255aee13")
  (:PATH
   "spikes/results/ci/by-source/b6f3dc19676e9bc5ccf93d62cec35a38580fa4f978d4240dc9f259adc716b1d8/runs/38634044870/1/collections/2fc698118b6797152fea74963d243c6c8956bc1a8799d157fc43e2ee7f89a342/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114021 :MTIME 1793207956 :SHA256
   "6dc6c8e776b08cd3d8435e73852136a6bde652060fdea4f25405b17ddc588a37")
  (:PATH
   "spikes/results/ci/by-source/b6f3dc19676e9bc5ccf93d62cec35a38580fa4f978d4240dc9f259adc716b1d8/runs/38634044870/1/collections/2fc698118b6797152fea74963d243c6c8956bc1a8799d157fc43e2ee7f89a342/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114022 :MTIME 1793207956 :SHA256
   "5b99c9d67f9240f2f66856fa8ed413c43f7e783c3e0d46621e126a11aa2b79bf")
  (:PATH
   "spikes/results/ci/by-source/b6f3dc19676e9bc5ccf93d62cec35a38580fa4f978d4240dc9f259adc716b1d8/runs/38634044870/1/collections/2fc698118b6797152fea74963d243c6c8956bc1a8799d157fc43e2ee7f89a342/summary.lisp"
   :BYTES 4911 :DEVICE 16777232 :INODE 1560114023 :MTIME 1793207956 :SHA256
   "4dda99207515355be90918bd83242d0fb5f1fec64fd2250ebbd971cbf9bfe109")
  (:PATH
   "spikes/results/ci/by-source/b6f3dc19676e9bc5ccf93d62cec35a38580fa4f978d4240dc9f259adc716b1d8/runs/38634044870/1/collections/8260cab524dddb09af6f5c19238f14ee915778e8d9277c143b8ab5e00fdcf97a/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114025 :MTIME 1793207956 :SHA256
   "95382dde454184e01a9f11deb6f64e0d773572fae523c190a7afbd88932f5ef3")
  (:PATH
   "spikes/results/ci/by-source/b6f3dc19676e9bc5ccf93d62cec35a38580fa4f978d4240dc9f259adc716b1d8/runs/38634044870/1/collections/8260cab524dddb09af6f5c19238f14ee915778e8d9277c143b8ab5e00fdcf97a/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114026 :MTIME 1793207956 :SHA256
   "5b99c9d67f9240f2f66856fa8ed413c43f7e783c3e0d46621e126a11aa2b79bf")
  (:PATH
   "spikes/results/ci/by-source/b6f3dc19676e9bc5ccf93d62cec35a38580fa4f978d4240dc9f259adc716b1d8/runs/38634044870/1/collections/8260cab524dddb09af6f5c19238f14ee915778e8d9277c143b8ab5e00fdcf97a/summary.lisp"
   :BYTES 4917 :DEVICE 16777232 :INODE 1560114027 :MTIME 1793207956 :SHA256
   "5aa211f7472078e230d7726dc3a3cf04834b250969a9068c086b06a1c57a333c")
  (:PATH
   "spikes/results/ci/by-source/b6f3dc19676e9bc5ccf93d62cec35a38580fa4f978d4240dc9f259adc716b1d8/runs/38634044870/1/publications/d05449945ecf89df4f30d10c7c02983305e422b3e15af619ccaf0ccec60029de.lisp"
   :BYTES 731 :DEVICE 16777232 :INODE 1560114029 :MTIME 1793207956 :SHA256
   "5442d9e8b0c7e40a31c29792fead4944c4661b3fabe15e2dd92c0a6cae942e65")
  (:PATH
   "spikes/results/ci/by-source/b6f3dc19676e9bc5ccf93d62cec35a38580fa4f978d4240dc9f259adc716b1d8/runs/38634044870/1/publications/e6a9b42fcc7ac11039cf7027a9fe0c5136ebad6dde1127038b786a9254d4b63b.lisp"
   :BYTES 734 :DEVICE 16777232 :INODE 1560114030 :MTIME 1793207956 :SHA256
   "176173ff9e77ab77d282f6a87c45baa0ac52d625e4dc54aaf7ce9bd1f63f3078")
  (:PATH
   "spikes/results/ci/by-source/b9488911a33bac94fe75b43482153a87b470d3408f9b17d2ffdb9e1858292282/runs/38775865795/1/collections/45dd378a5cb42212d190daca14c6a865d16c9f121da7aefe9551ef15c6523080/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114037 :MTIME 1793207956 :SHA256
   "6e59997dba26c83217bdf9eb861f220ac6cb03ec48e365711d19669251a8fed8")
  (:PATH
   "spikes/results/ci/by-source/b9488911a33bac94fe75b43482153a87b470d3408f9b17d2ffdb9e1858292282/runs/38775865795/1/collections/45dd378a5cb42212d190daca14c6a865d16c9f121da7aefe9551ef15c6523080/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114038 :MTIME 1793207956 :SHA256
   "c52aebd25b172a399e2d0e3741b9d39d25c60df559eaa8b8731ed94b3e946ef0")
  (:PATH
   "spikes/results/ci/by-source/b9488911a33bac94fe75b43482153a87b470d3408f9b17d2ffdb9e1858292282/runs/38775865795/1/collections/45dd378a5cb42212d190daca14c6a865d16c9f121da7aefe9551ef15c6523080/summary.lisp"
   :BYTES 4967 :DEVICE 16777232 :INODE 1560114039 :MTIME 1793207956 :SHA256
   "46df182f4c87eaaad4a2167ab26920176a739618af437c4bb8201401d335de85")
  (:PATH
   "spikes/results/ci/by-source/b9488911a33bac94fe75b43482153a87b470d3408f9b17d2ffdb9e1858292282/runs/38775865795/1/collections/a10e45fe2683c48d5ecd2461b30277b229a3d9dee858600b4f01ec2da5b56a73/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114041 :MTIME 1793207956 :SHA256
   "0f6ec76fc6c9fdaddbf7cf2744da10a2a66903d473b33bce388515b8b49730a0")
  (:PATH
   "spikes/results/ci/by-source/b9488911a33bac94fe75b43482153a87b470d3408f9b17d2ffdb9e1858292282/runs/38775865795/1/collections/a10e45fe2683c48d5ecd2461b30277b229a3d9dee858600b4f01ec2da5b56a73/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114042 :MTIME 1793207956 :SHA256
   "c52aebd25b172a399e2d0e3741b9d39d25c60df559eaa8b8731ed94b3e946ef0")
  (:PATH
   "spikes/results/ci/by-source/b9488911a33bac94fe75b43482153a87b470d3408f9b17d2ffdb9e1858292282/runs/38775865795/1/collections/a10e45fe2683c48d5ecd2461b30277b229a3d9dee858600b4f01ec2da5b56a73/summary.lisp"
   :BYTES 4961 :DEVICE 16777232 :INODE 1560114043 :MTIME 1793207956 :SHA256
   "880b20830695217837acfc253f650fdbf21e98b6932545e028780f3309633599")
  (:PATH
   "spikes/results/ci/by-source/b9488911a33bac94fe75b43482153a87b470d3408f9b17d2ffdb9e1858292282/runs/38775865795/1/publications/82f930e6d6fd88f77f41b0f23738e675a089db813c1e10e15db2d1565a0763c2.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114045 :MTIME 1793207956 :SHA256
   "c7b0b018d7a2e8e388531032350c9c4c63043d8b8cc0705351e713868cd31386")
  (:PATH
   "spikes/results/ci/by-source/b9488911a33bac94fe75b43482153a87b470d3408f9b17d2ffdb9e1858292282/runs/38775865795/1/publications/8f2c17d22eb9be670b16b1455f475687e595485b3b63ae348fb7ce49c9d48d5c.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114046 :MTIME 1793207956 :SHA256
   "ea984096bbc4e6caffc5869258e37bf58574512d0ec665e523cb3652ce351b0c")
  (:PATH
   "spikes/results/ci/by-source/bacdce52766d52851d2073b5aa04a310a7a5db71d144bed18164d5a9fa58dfac/runs/38931473252/1/collections/6dfb9e1641f1ea80c5699f797a0713c9727455fec58e9ed84adb56fb8aaa5c12/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114053 :MTIME 1793207956 :SHA256
   "4bc0fc717179edba9070ae2192bd7351a8ef3ba7d71abffe224e3d3f23f769b5")
  (:PATH
   "spikes/results/ci/by-source/bacdce52766d52851d2073b5aa04a310a7a5db71d144bed18164d5a9fa58dfac/runs/38931473252/1/collections/6dfb9e1641f1ea80c5699f797a0713c9727455fec58e9ed84adb56fb8aaa5c12/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114054 :MTIME 1793207956 :SHA256
   "cd2f942f57598960bbc79b6e91bd09afba79e5485e25ed7c99d802561ee04449")
  (:PATH
   "spikes/results/ci/by-source/bacdce52766d52851d2073b5aa04a310a7a5db71d144bed18164d5a9fa58dfac/runs/38931473252/1/collections/6dfb9e1641f1ea80c5699f797a0713c9727455fec58e9ed84adb56fb8aaa5c12/summary.lisp"
   :BYTES 5275 :DEVICE 16777232 :INODE 1560114055 :MTIME 1793207956 :SHA256
   "eb5c3b07a7ea8ab6d10c174ed0d0071192db938a30937f5315c24919359803a8")
  (:PATH
   "spikes/results/ci/by-source/bacdce52766d52851d2073b5aa04a310a7a5db71d144bed18164d5a9fa58dfac/runs/38931473252/1/publications/149dc0f47be3ea8d885e31f6864fb95c57604ea9f74af0a27e7d18626a410d18.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114057 :MTIME 1793207956 :SHA256
   "b1c64e7181e16232017709dcd75accc8e4b8b5b33c45ecdcfecb047016f44d4d")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38644364634/1/collections/6d6a98a3511f200ec80fbebc64807f46196894317b5f430767a0a63fce57a276/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114064 :MTIME 1793207956 :SHA256
   "6d26c746f64863e7b2f587c19f0ecb0701c3b438022d73b42262a55937105fbf")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38644364634/1/collections/6d6a98a3511f200ec80fbebc64807f46196894317b5f430767a0a63fce57a276/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114065 :MTIME 1793207956 :SHA256
   "1d655c50409d73442ddbdfd361b29743cec34d10be29ebbb5a24ab34c8867a4a")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38644364634/1/collections/6d6a98a3511f200ec80fbebc64807f46196894317b5f430767a0a63fce57a276/summary.lisp"
   :BYTES 4917 :DEVICE 16777232 :INODE 1560114066 :MTIME 1793207956 :SHA256
   "78f8e2c5e5bad0e8ff1e31fb035c6982ee6588d60349e857a9f78cbb86272b7e")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38644364634/1/collections/c44188b5a03e1be9a4d2957999dec80a7c887925d37f1557f72be7b0aee82994/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114068 :MTIME 1793207956 :SHA256
   "009bf5867205bbc03c6e80180a069b82dab398043bb58dad75989d9419faaeec")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38644364634/1/collections/c44188b5a03e1be9a4d2957999dec80a7c887925d37f1557f72be7b0aee82994/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114069 :MTIME 1793207956 :SHA256
   "1d655c50409d73442ddbdfd361b29743cec34d10be29ebbb5a24ab34c8867a4a")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38644364634/1/collections/c44188b5a03e1be9a4d2957999dec80a7c887925d37f1557f72be7b0aee82994/summary.lisp"
   :BYTES 4911 :DEVICE 16777232 :INODE 1560114070 :MTIME 1793207956 :SHA256
   "26edf9a55d5807ced3a25d74e44cbda8ce805afe9db096d9e5eb6ec879e04c7d")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38644364634/1/publications/0ea98f9380f1c27ca6823a73a5c8f589b20c28a26e2b0d8bbd64215f63f6b284.lisp"
   :BYTES 734 :DEVICE 16777232 :INODE 1560114072 :MTIME 1793207956 :SHA256
   "d0e4274c47debecdadb7870867c807316c0ab086214f970705b08c3dfb941c36")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38644364634/1/publications/b281b099c902bbc6683e5ddf5b5f4b2f7cc6d37ececeb4836e13fae189b2b3ac.lisp"
   :BYTES 731 :DEVICE 16777232 :INODE 1560114073 :MTIME 1793207956 :SHA256
   "fb479224171ffaede3d89a73053331190ca91e4dcf54663a71fa23846cd5e528")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38646390295/1/collections/3abb85bc4242a45b293c4d69f7f25c6113623386e519620dd56d508c60689bf0/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114078 :MTIME 1793207956 :SHA256
   "86ef274d07c45d3f013e1bf7fc64630f5251231ce77136f49377e6594b750066")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38646390295/1/collections/3abb85bc4242a45b293c4d69f7f25c6113623386e519620dd56d508c60689bf0/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114079 :MTIME 1793207956 :SHA256
   "096352edc41d7ccc40a5711a5d3f8f11551dfa5e9c7fdcf59607870873ef4377")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38646390295/1/collections/3abb85bc4242a45b293c4d69f7f25c6113623386e519620dd56d508c60689bf0/summary.lisp"
   :BYTES 4860 :DEVICE 16777232 :INODE 1560114080 :MTIME 1793207956 :SHA256
   "5bc4ad89f1f2eff729a1fcbbb34077df46f385d9ef2e685e56176a3a3e0b32dc")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38646390295/1/collections/62607485bfcb619582543f62f1f4ba023d6dfde152c6022f1952ae29c2e03785/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114082 :MTIME 1793207956 :SHA256
   "2743edcd27f85ad247ccc24bd9792111c9bb6c53e921409eb960204aa1e344ca")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38646390295/1/collections/62607485bfcb619582543f62f1f4ba023d6dfde152c6022f1952ae29c2e03785/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114083 :MTIME 1793207956 :SHA256
   "096352edc41d7ccc40a5711a5d3f8f11551dfa5e9c7fdcf59607870873ef4377")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38646390295/1/collections/62607485bfcb619582543f62f1f4ba023d6dfde152c6022f1952ae29c2e03785/summary.lisp"
   :BYTES 4866 :DEVICE 16777232 :INODE 1560114084 :MTIME 1793207956 :SHA256
   "0b871f97257b470e5fd2f699e194aab8296360c6216ef4c715a8cf353cadf9ff")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38646390295/1/publications/338bab6c108783adbf6e976daced239c0bfff9136119bab83774baf5891d8907.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114086 :MTIME 1793207956 :SHA256
   "cdc3426b77ebb60d193fcea8d2748b2516d977456f73d68c9c712e4631e7a2ef")
  (:PATH
   "spikes/results/ci/by-source/bacf8b2809b0591a700578bff6ba655e18a55e7e6193e7673fc85b63406dfe9b/runs/38646390295/1/publications/89e27ca80855e68fe26d1835dde39dd62810b8e3132bc859e97ad64dd496c62e.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114087 :MTIME 1793207956 :SHA256
   "e13145bc35c29533ad3176f0ae0c751454ac9402892f2e18af5daa64b1385fc4")
  (:PATH
   "spikes/results/ci/by-source/bcc07eba65fa114632ff77db2ecced320322617e2c83aa191323548707b53356/runs/38136437479/1/collections/40c065f8b4b02a66f2dd02afb0aaa5ade24d1b23a966aabb58c62d9cf749611b/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114094 :MTIME 1793207956 :SHA256
   "f017ea83f61fd7ab7423863e9fd340221e3629e08de576157efeac21ab477522")
  (:PATH
   "spikes/results/ci/by-source/bcc07eba65fa114632ff77db2ecced320322617e2c83aa191323548707b53356/runs/38136437479/1/collections/40c065f8b4b02a66f2dd02afb0aaa5ade24d1b23a966aabb58c62d9cf749611b/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114095 :MTIME 1793207956 :SHA256
   "2276db6f28df074dc51cd963eb5148ac3436a634f8dcf4fb90686d0a8e2c9776")
  (:PATH
   "spikes/results/ci/by-source/bcc07eba65fa114632ff77db2ecced320322617e2c83aa191323548707b53356/runs/38136437479/1/collections/40c065f8b4b02a66f2dd02afb0aaa5ade24d1b23a966aabb58c62d9cf749611b/summary.lisp"
   :BYTES 4082 :DEVICE 16777232 :INODE 1560114096 :MTIME 1793207956 :SHA256
   "9d6ecb7d0f4e55ab2debac6a84f9024a4bc2b7788e6e04512d16818709855469")
  (:PATH
   "spikes/results/ci/by-source/bcc07eba65fa114632ff77db2ecced320322617e2c83aa191323548707b53356/runs/38136437479/1/collections/6106da3f42297cd081f9990a1e75b36766e2004cb3f1c9eff0ca02cc6ee7b973/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114098 :MTIME 1793207956 :SHA256
   "d8a2b4848b24ad7015c669b39ea44790d22af479121069f82d6f02bb3346f26d")
  (:PATH
   "spikes/results/ci/by-source/bcc07eba65fa114632ff77db2ecced320322617e2c83aa191323548707b53356/runs/38136437479/1/collections/6106da3f42297cd081f9990a1e75b36766e2004cb3f1c9eff0ca02cc6ee7b973/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114099 :MTIME 1793207956 :SHA256
   "2276db6f28df074dc51cd963eb5148ac3436a634f8dcf4fb90686d0a8e2c9776")
  (:PATH
   "spikes/results/ci/by-source/bcc07eba65fa114632ff77db2ecced320322617e2c83aa191323548707b53356/runs/38136437479/1/collections/6106da3f42297cd081f9990a1e75b36766e2004cb3f1c9eff0ca02cc6ee7b973/summary.lisp"
   :BYTES 4088 :DEVICE 16777232 :INODE 1560114100 :MTIME 1793207956 :SHA256
   "9a82822ae239e8725ccf47f33cc0e93456bacd8d5b17e36ee8a823ba60e65134")
  (:PATH
   "spikes/results/ci/by-source/bcc07eba65fa114632ff77db2ecced320322617e2c83aa191323548707b53356/runs/38136437479/1/publications/1232a85400b049ad158c53d0f986d30c3e83ec7e464df0340b7fcdf685fb8283.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114102 :MTIME 1793207956 :SHA256
   "b2e7bcfb69dc7b605f7e5afc0b185562c59a71a1754385a52530d54d5464a72c")
  (:PATH
   "spikes/results/ci/by-source/bcc07eba65fa114632ff77db2ecced320322617e2c83aa191323548707b53356/runs/38136437479/1/publications/5bd01735e835d9d2e705a9183133d5414fda490762b156c97c0cd6fc26c69142.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114103 :MTIME 1793207956 :SHA256
   "eaf60228a57673e2ed7cbffe5323901a9ce748c5e9851c42b54b71b32aff9f0a")
  (:PATH
   "spikes/results/ci/by-source/bfac3a3b69208cb62a5b48439cfb34db3d9a24e94cda83eb9bedc57dc80ab4b0/runs/38133452034/1/collections/454a029db0dd0e999ec8a38ee0a29f11d00b082582ab99d515cca8efd59a840e/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114110 :MTIME 1793207956 :SHA256
   "16ec4307dd0bb05cdbd92aaefb3857d8192a8baf391e18ff897796fbd464bf1c")
  (:PATH
   "spikes/results/ci/by-source/bfac3a3b69208cb62a5b48439cfb34db3d9a24e94cda83eb9bedc57dc80ab4b0/runs/38133452034/1/collections/454a029db0dd0e999ec8a38ee0a29f11d00b082582ab99d515cca8efd59a840e/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114111 :MTIME 1793207956 :SHA256
   "df4fd3bf905a64c44547e14840dbdd77114f38ce4cd9a5775cf2b44df7004aef")
  (:PATH
   "spikes/results/ci/by-source/bfac3a3b69208cb62a5b48439cfb34db3d9a24e94cda83eb9bedc57dc80ab4b0/runs/38133452034/1/collections/454a029db0dd0e999ec8a38ee0a29f11d00b082582ab99d515cca8efd59a840e/summary.lisp"
   :BYTES 3903 :DEVICE 16777232 :INODE 1560114112 :MTIME 1793207956 :SHA256
   "8504db4bf10f6cd503509ef248ba543ab83c62d811f54271a753bb563da66b01")
  (:PATH
   "spikes/results/ci/by-source/bfac3a3b69208cb62a5b48439cfb34db3d9a24e94cda83eb9bedc57dc80ab4b0/runs/38133452034/1/collections/cf5ea51cd3625e2fc1bb4a67c5b0cad2fc04c52026413eaee6f2e850bc7c8973/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114114 :MTIME 1793207956 :SHA256
   "5cbf46b4b1b7b5259e795b59f8d988b006af402ee323a65883486271589ed847")
  (:PATH
   "spikes/results/ci/by-source/bfac3a3b69208cb62a5b48439cfb34db3d9a24e94cda83eb9bedc57dc80ab4b0/runs/38133452034/1/collections/cf5ea51cd3625e2fc1bb4a67c5b0cad2fc04c52026413eaee6f2e850bc7c8973/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114115 :MTIME 1793207956 :SHA256
   "df4fd3bf905a64c44547e14840dbdd77114f38ce4cd9a5775cf2b44df7004aef")
  (:PATH
   "spikes/results/ci/by-source/bfac3a3b69208cb62a5b48439cfb34db3d9a24e94cda83eb9bedc57dc80ab4b0/runs/38133452034/1/collections/cf5ea51cd3625e2fc1bb4a67c5b0cad2fc04c52026413eaee6f2e850bc7c8973/summary.lisp"
   :BYTES 3909 :DEVICE 16777232 :INODE 1560114116 :MTIME 1793207956 :SHA256
   "b96923105b0c41ebbfdccd3ea118cd6fe204a02a05e9555a6323ab194d88dbb2")
  (:PATH
   "spikes/results/ci/by-source/bfac3a3b69208cb62a5b48439cfb34db3d9a24e94cda83eb9bedc57dc80ab4b0/runs/38133452034/1/publications/6811f4de7e32596fae8e4c89ac4e8ceaabc74f3a349486065c58db16d60bba5f.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114118 :MTIME 1793207956 :SHA256
   "bbc4d2ade5faa992a1b938ceea9927a56134c082baf155f426b652265c1fc122")
  (:PATH
   "spikes/results/ci/by-source/bfac3a3b69208cb62a5b48439cfb34db3d9a24e94cda83eb9bedc57dc80ab4b0/runs/38133452034/1/publications/f4a8eb7568ffe13feb7208de2aef258f91e9fcaa2f82c58f87a70642da454586.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114119 :MTIME 1793207956 :SHA256
   "406dd539cc1fb99595fc33042b54fd5c8eb51093c3ad22713f25727bf4f3a3a0")
  (:PATH
   "spikes/results/ci/by-source/c2226d877864109121d4f1013f1b9128d90b446fdac7e6b38c3f2987339b7a4c/runs/38939175102/1/collections/686e27725a8b8f496c8c5e673f0629de9eae32f0c3df991623ac56ad02d24b32/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114126 :MTIME 1793207956 :SHA256
   "28f35a0b1f6b0d92d284962371da61c933c4daded0223709aa596157e65cd36c")
  (:PATH
   "spikes/results/ci/by-source/c2226d877864109121d4f1013f1b9128d90b446fdac7e6b38c3f2987339b7a4c/runs/38939175102/1/collections/686e27725a8b8f496c8c5e673f0629de9eae32f0c3df991623ac56ad02d24b32/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114127 :MTIME 1793207956 :SHA256
   "a7fb7631f064a9e32b25b5f7237b6364cc04830ad441e7e64b0503c55c63a5c4")
  (:PATH
   "spikes/results/ci/by-source/c2226d877864109121d4f1013f1b9128d90b446fdac7e6b38c3f2987339b7a4c/runs/38939175102/1/collections/686e27725a8b8f496c8c5e673f0629de9eae32f0c3df991623ac56ad02d24b32/summary.lisp"
   :BYTES 5367 :DEVICE 16777232 :INODE 1560114128 :MTIME 1793207956 :SHA256
   "64e0aa2de39fd75482ec5cb72857867a5aa7c86846fb8e89ee5696da0df42fa6")
  (:PATH
   "spikes/results/ci/by-source/c2226d877864109121d4f1013f1b9128d90b446fdac7e6b38c3f2987339b7a4c/runs/38939175102/1/publications/969a5be7e2719160a2b76f5079b61923f5334eed7d2f84d962699d9e22c61753.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114130 :MTIME 1793207956 :SHA256
   "c491442beb1b670c48deaa3270d76ba675289a19166ed84623b99c4ee351ab14")
  (:PATH
   "spikes/results/ci/by-source/c6147cabbc44ba1b9472a8cabb8f1758e2cae9d7209ceebbcf0f57ba049f2663/runs/38794380589/1/collections/5244f0c1e5680063b14c60cc33f77715cd174fe5c49d5d8b2249c7a37a9fe191/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114137 :MTIME 1793207956 :SHA256
   "0388d1979469543f7ba7c802abae3f3baf263ecb5c8574c82327b9c83a4a50dc")
  (:PATH
   "spikes/results/ci/by-source/c6147cabbc44ba1b9472a8cabb8f1758e2cae9d7209ceebbcf0f57ba049f2663/runs/38794380589/1/collections/5244f0c1e5680063b14c60cc33f77715cd174fe5c49d5d8b2249c7a37a9fe191/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114138 :MTIME 1793207956 :SHA256
   "26f91bd162df77e7c32afdc7669ed436b3632236529995356e7464b06a297a53")
  (:PATH
   "spikes/results/ci/by-source/c6147cabbc44ba1b9472a8cabb8f1758e2cae9d7209ceebbcf0f57ba049f2663/runs/38794380589/1/collections/5244f0c1e5680063b14c60cc33f77715cd174fe5c49d5d8b2249c7a37a9fe191/summary.lisp"
   :BYTES 5168 :DEVICE 16777232 :INODE 1560114139 :MTIME 1793207956 :SHA256
   "9cd70f71425c6554ab4071cbe43aa362d1f918941ff045c2a1147c123e4fab6f")
  (:PATH
   "spikes/results/ci/by-source/c6147cabbc44ba1b9472a8cabb8f1758e2cae9d7209ceebbcf0f57ba049f2663/runs/38794380589/1/publications/bad06c28527e8e1eb296f2b145f3dea34395485571d53380399608be63bffcf2.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114141 :MTIME 1793207956 :SHA256
   "b9f31ec07c967dfe3e275ba34ec9b19c8ea0f2fcea041de8bc89b3fa5f75bcd6")
  (:PATH
   "spikes/results/ci/by-source/c67df05cf0daa77082351dae3f208fa927f8da9105e1b4c16cb76a02224c854e/runs/38933068241/1/collections/c2dfecb724bbc58e9d7f3cfe9d065e31e566dfc27ea00aa1a5f48d239c3104ca/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114148 :MTIME 1793207956 :SHA256
   "3d60db31e3584db0e381936218eab566fb5b187345d729825cc3a39dc3e52432")
  (:PATH
   "spikes/results/ci/by-source/c67df05cf0daa77082351dae3f208fa927f8da9105e1b4c16cb76a02224c854e/runs/38933068241/1/collections/c2dfecb724bbc58e9d7f3cfe9d065e31e566dfc27ea00aa1a5f48d239c3104ca/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114149 :MTIME 1793207956 :SHA256
   "925af7b8556daad6b394a8dd9eaa4d31717464ed650d9b7fdeec22b5c32db68c")
  (:PATH
   "spikes/results/ci/by-source/c67df05cf0daa77082351dae3f208fa927f8da9105e1b4c16cb76a02224c854e/runs/38933068241/1/collections/c2dfecb724bbc58e9d7f3cfe9d065e31e566dfc27ea00aa1a5f48d239c3104ca/summary.lisp"
   :BYTES 5325 :DEVICE 16777232 :INODE 1560114150 :MTIME 1793207956 :SHA256
   "5e44d712edde96cf4c8e8fb1689cd198b605ba22c05b7704a8a35c64a43df1a8")
  (:PATH
   "spikes/results/ci/by-source/c67df05cf0daa77082351dae3f208fa927f8da9105e1b4c16cb76a02224c854e/runs/38933068241/1/publications/bdeca6cf240f06bedb63343ec44303352e4d5f66a63b0d08df09d8063e18de88.lisp"
   :BYTES 730 :DEVICE 16777232 :INODE 1560114152 :MTIME 1793207956 :SHA256
   "814c14ab5b1ba84813f2b676ae97ae661a4c6f4806d2dc60b181f5fc14811b1c")
  (:PATH
   "spikes/results/ci/by-source/c99eb1f15f89bbac3b655e021e0c946d7617791d31c233c9c1dec48015263152/runs/38787838336/1/collections/1727527f143b2791fe524e64eaf98b1863cbb605516a551a8da943fa89e9442a/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114159 :MTIME 1793207956 :SHA256
   "4b31335cb2a5a768ad13bd8ffcfe2207a1d1600b527a04ca1ceb9afdc715cf27")
  (:PATH
   "spikes/results/ci/by-source/c99eb1f15f89bbac3b655e021e0c946d7617791d31c233c9c1dec48015263152/runs/38787838336/1/collections/1727527f143b2791fe524e64eaf98b1863cbb605516a551a8da943fa89e9442a/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114160 :MTIME 1793207956 :SHA256
   "b8b41c520e3ea648cba8cdb0d6eccc5340f57f369b1e512c37538f28bb3bd1ba")
  (:PATH
   "spikes/results/ci/by-source/c99eb1f15f89bbac3b655e021e0c946d7617791d31c233c9c1dec48015263152/runs/38787838336/1/collections/1727527f143b2791fe524e64eaf98b1863cbb605516a551a8da943fa89e9442a/summary.lisp"
   :BYTES 5168 :DEVICE 16777232 :INODE 1560114161 :MTIME 1793207956 :SHA256
   "71c5c0aa7c425437e8b1d8d0735f86cc7df8b958de036389a6a956e307f03964")
  (:PATH
   "spikes/results/ci/by-source/c99eb1f15f89bbac3b655e021e0c946d7617791d31c233c9c1dec48015263152/runs/38787838336/1/publications/03d3b667a25528b7046ef9a9508b5590a648018bc05dd622d9b82eb650a1d43d.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114163 :MTIME 1793207956 :SHA256
   "66fc980c96ad790bfe86382130da31aa0b1a63454d1e1fa9eb09f44d4ef7372b")
  (:PATH
   "spikes/results/ci/by-source/cb846222f52e71bb6a463797e3bd9733479ed73ba9fee9c61e0bbf890b78a048/runs/38792608403/1/collections/ab287bfcd30b47423b430e2ce20028bb153db76eadde91119525f96a9ef101c4/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114170 :MTIME 1793207956 :SHA256
   "10d72db226d3b0046472a3dd0b2d193d40311c36ba5938da2fa23bde0fdee8b7")
  (:PATH
   "spikes/results/ci/by-source/cb846222f52e71bb6a463797e3bd9733479ed73ba9fee9c61e0bbf890b78a048/runs/38792608403/1/collections/ab287bfcd30b47423b430e2ce20028bb153db76eadde91119525f96a9ef101c4/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114171 :MTIME 1793207956 :SHA256
   "78ea969562de5fb366f10bc6b807a3ba1230a16cc7ac9c71c5e8a490b7cae82e")
  (:PATH
   "spikes/results/ci/by-source/cb846222f52e71bb6a463797e3bd9733479ed73ba9fee9c61e0bbf890b78a048/runs/38792608403/1/collections/ab287bfcd30b47423b430e2ce20028bb153db76eadde91119525f96a9ef101c4/summary.lisp"
   :BYTES 5168 :DEVICE 16777232 :INODE 1560114172 :MTIME 1793207956 :SHA256
   "5ac8fb84398d64362e6bbe3678c89ca2f1bc06a2f6417db9f3958e57239ad2cc")
  (:PATH
   "spikes/results/ci/by-source/cb846222f52e71bb6a463797e3bd9733479ed73ba9fee9c61e0bbf890b78a048/runs/38792608403/1/publications/2c0648fbdd8f564a2d96f64ba40bf15cc94309b61726c70b7409e5fe50fac6bc.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114174 :MTIME 1793207956 :SHA256
   "ef930d2c1bb18bb6b710106f6cf9cfb043dd845b9e5954cff079497dbde7a817")
  (:PATH
   "spikes/results/ci/by-source/cbd0de1339d38ccad059fa69d37ee41d255786cf9c00882fd5270f705d6668b1/runs/38783626587/1/collections/e686be17867c0bc7a620f218ee74891d016a11b3c6c2afd0440bdedda1aca508/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114181 :MTIME 1793207956 :SHA256
   "37abea39c9ae13fd1022916d7b7be37e52767c85dc77fe81a1f76ada4f4168b4")
  (:PATH
   "spikes/results/ci/by-source/cbd0de1339d38ccad059fa69d37ee41d255786cf9c00882fd5270f705d6668b1/runs/38783626587/1/collections/e686be17867c0bc7a620f218ee74891d016a11b3c6c2afd0440bdedda1aca508/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114182 :MTIME 1793207956 :SHA256
   "a7bc899ba3408ddc68d59c6772bdcf14feec24a2baea409bf67ab7e703b6e4d3")
  (:PATH
   "spikes/results/ci/by-source/cbd0de1339d38ccad059fa69d37ee41d255786cf9c00882fd5270f705d6668b1/runs/38783626587/1/collections/e686be17867c0bc7a620f218ee74891d016a11b3c6c2afd0440bdedda1aca508/summary.lisp"
   :BYTES 5137 :DEVICE 16777232 :INODE 1560114183 :MTIME 1793207956 :SHA256
   "1bfa7fb219310c97a9fc71d79c6622d1dd905270fe7603fbce24baec0b1793a8")
  (:PATH
   "spikes/results/ci/by-source/cbd0de1339d38ccad059fa69d37ee41d255786cf9c00882fd5270f705d6668b1/runs/38783626587/1/publications/ee81d221c53f7e7168fe3618bfd5f46053ece419c91d3f9713e94e75d2846b23.lisp"
   :BYTES 740 :DEVICE 16777232 :INODE 1560114185 :MTIME 1793207956 :SHA256
   "eed0bd60eb9135b82bfc1a7b4550d49cca63cc1c313548847338d51ff896a187")
  (:PATH
   "spikes/results/ci/by-source/cbd0de1339d38ccad059fa69d37ee41d255786cf9c00882fd5270f705d6668b1/runs/38785089113/1/collections/aca1c8b65748020f1206a114593c7a1c8da02031d814f083038f2f2f877b616e/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114190 :MTIME 1793207956 :SHA256
   "ce1ad8568b891100205543ae21bc48aba6cd1578745dd46bb5a1e52f273f6989")
  (:PATH
   "spikes/results/ci/by-source/cbd0de1339d38ccad059fa69d37ee41d255786cf9c00882fd5270f705d6668b1/runs/38785089113/1/collections/aca1c8b65748020f1206a114593c7a1c8da02031d814f083038f2f2f877b616e/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114191 :MTIME 1793207956 :SHA256
   "d124d6f3904fda2aca0ebb27021c9d504bf26f0b5530248f4b6e846d19208424")
  (:PATH
   "spikes/results/ci/by-source/cbd0de1339d38ccad059fa69d37ee41d255786cf9c00882fd5270f705d6668b1/runs/38785089113/1/collections/aca1c8b65748020f1206a114593c7a1c8da02031d814f083038f2f2f877b616e/summary.lisp"
   :BYTES 5068 :DEVICE 16777232 :INODE 1560114192 :MTIME 1793207956 :SHA256
   "b77f7fea49a2fa16842f79e96f8401d2116dc14f88340fa7c8b69671a61ef8a0")
  (:PATH
   "spikes/results/ci/by-source/cbd0de1339d38ccad059fa69d37ee41d255786cf9c00882fd5270f705d6668b1/runs/38785089113/1/publications/eba4560cd1362ae684a8864ed55d91dc03b989a769db55f5a4b22ea1e8e30130.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114194 :MTIME 1793207956 :SHA256
   "d0780621f8c571b780f521ab9e2fa64fde1a7d4f2e867aa417b8463f35d2bd6f")
  (:PATH
   "spikes/results/ci/by-source/ccb553a3a9853159a4e2acf321a3f0cfca9f9c657793518900249e011ad15a41/runs/38798766881/1/collections/2c406982c250e0a883c4057f2d9fce12c7d924e9f2aff07789be03690d1ccbb3/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114201 :MTIME 1793207956 :SHA256
   "261eadaf518d48f74491365daa58e8204b6fbe69d107bed2c5c69360ad14961e")
  (:PATH
   "spikes/results/ci/by-source/ccb553a3a9853159a4e2acf321a3f0cfca9f9c657793518900249e011ad15a41/runs/38798766881/1/collections/2c406982c250e0a883c4057f2d9fce12c7d924e9f2aff07789be03690d1ccbb3/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114202 :MTIME 1793207956 :SHA256
   "057e96bb566adffbd48e3ad0860753e88435154d35fa1656ae433c70ea01838d")
  (:PATH
   "spikes/results/ci/by-source/ccb553a3a9853159a4e2acf321a3f0cfca9f9c657793518900249e011ad15a41/runs/38798766881/1/collections/2c406982c250e0a883c4057f2d9fce12c7d924e9f2aff07789be03690d1ccbb3/summary.lisp"
   :BYTES 5168 :DEVICE 16777232 :INODE 1560114203 :MTIME 1793207956 :SHA256
   "c5c1ce6e7e6eaf5c6e4391f72c51151e3ae3104479552396dfe9182524eb8210")
  (:PATH
   "spikes/results/ci/by-source/ccb553a3a9853159a4e2acf321a3f0cfca9f9c657793518900249e011ad15a41/runs/38798766881/1/publications/0a01392efc3d271281017f16b75468c40cad029fc1ae99940bed93c7d9d7d893.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114205 :MTIME 1793207956 :SHA256
   "9eb0470aee7a442f519c0bcc82fbde46368ddfd10cc5825aadc6fdfbea1aa7f9")
  (:PATH
   "spikes/results/ci/by-source/cd2049ddfbd4925b88131b3a8f898338e3d40b6ec6b56f50e0b133d85dcdcd91/runs/38143321126/1/collections/85956ca563c620d020e5184624820c140477ae849f51cf1d837734a713a66bd0/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114212 :MTIME 1793207956 :SHA256
   "b857d50ae5cc53d401d1013fb2fe2cd61682f65892824fca248afc50818e6384")
  (:PATH
   "spikes/results/ci/by-source/cd2049ddfbd4925b88131b3a8f898338e3d40b6ec6b56f50e0b133d85dcdcd91/runs/38143321126/1/collections/85956ca563c620d020e5184624820c140477ae849f51cf1d837734a713a66bd0/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114213 :MTIME 1793207956 :SHA256
   "6391aec5e3157d7f18a7c5d4255cacd1f9c9bfc160eace29faada9ebdb8595fe")
  (:PATH
   "spikes/results/ci/by-source/cd2049ddfbd4925b88131b3a8f898338e3d40b6ec6b56f50e0b133d85dcdcd91/runs/38143321126/1/collections/85956ca563c620d020e5184624820c140477ae849f51cf1d837734a713a66bd0/summary.lisp"
   :BYTES 4283 :DEVICE 16777232 :INODE 1560114214 :MTIME 1793207956 :SHA256
   "ed121320273186d38a1aab38f782614e207849970f21224f69f681be87fafc65")
  (:PATH
   "spikes/results/ci/by-source/cd2049ddfbd4925b88131b3a8f898338e3d40b6ec6b56f50e0b133d85dcdcd91/runs/38143321126/1/collections/d0233bd7120a7ebed7532ee3aba1006adbb84d62bbe12bef68d6bbac1aadf3c3/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114216 :MTIME 1793207956 :SHA256
   "624f2b667bf3b3c47c1b4b2d9b328ab987f2705d949eafbc57f5061263bcfe3d")
  (:PATH
   "spikes/results/ci/by-source/cd2049ddfbd4925b88131b3a8f898338e3d40b6ec6b56f50e0b133d85dcdcd91/runs/38143321126/1/collections/d0233bd7120a7ebed7532ee3aba1006adbb84d62bbe12bef68d6bbac1aadf3c3/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114217 :MTIME 1793207956 :SHA256
   "6391aec5e3157d7f18a7c5d4255cacd1f9c9bfc160eace29faada9ebdb8595fe")
  (:PATH
   "spikes/results/ci/by-source/cd2049ddfbd4925b88131b3a8f898338e3d40b6ec6b56f50e0b133d85dcdcd91/runs/38143321126/1/collections/d0233bd7120a7ebed7532ee3aba1006adbb84d62bbe12bef68d6bbac1aadf3c3/summary.lisp"
   :BYTES 4277 :DEVICE 16777232 :INODE 1560114218 :MTIME 1793207956 :SHA256
   "9a3428388bf650f7c9dbcb6c962fff9dcd47e53716d394d73f7873df10f726af")
  (:PATH
   "spikes/results/ci/by-source/cd2049ddfbd4925b88131b3a8f898338e3d40b6ec6b56f50e0b133d85dcdcd91/runs/38143321126/1/publications/1995b27196fff94fdf9999ac853e0ea73d7c64d038ee9a7af1fb8ae17639d343.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114220 :MTIME 1793207956 :SHA256
   "055d8b59b5ab3a68a1c80ddafc59d54313c6f11f7982a4c054127bcebd9c2fc6")
  (:PATH
   "spikes/results/ci/by-source/cd2049ddfbd4925b88131b3a8f898338e3d40b6ec6b56f50e0b133d85dcdcd91/runs/38143321126/1/publications/4cdcc5c53ac42fe52198c3e80d6f537ee6561fc83c0813931dc1c491905d63c5.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114221 :MTIME 1793207956 :SHA256
   "0151d66500d963a7561332aa4761983f42fbf8e037f0a730fc956b7682911942")
  (:PATH
   "spikes/results/ci/by-source/cdd0c5630c8a352fbe29e9cb0b1e2e34d51d500934c2dd51e743f2943c750bd6/runs/38799904386/1/collections/7cda4f04c10c919bb7a4a8d14f90384f9334ac4e8913270ddeb71bc4510f6084/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114228 :MTIME 1793207956 :SHA256
   "4e54d30ee6443664a1471d7a5afdb3132c2c18794b8a2ac0c9b173f4042e5881")
  (:PATH
   "spikes/results/ci/by-source/cdd0c5630c8a352fbe29e9cb0b1e2e34d51d500934c2dd51e743f2943c750bd6/runs/38799904386/1/collections/7cda4f04c10c919bb7a4a8d14f90384f9334ac4e8913270ddeb71bc4510f6084/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114229 :MTIME 1793207956 :SHA256
   "3c40111d3a2d8d1e40b412a8ad8c17ec670f9dc6f786142356e0599aa8e6ca8f")
  (:PATH
   "spikes/results/ci/by-source/cdd0c5630c8a352fbe29e9cb0b1e2e34d51d500934c2dd51e743f2943c750bd6/runs/38799904386/1/collections/7cda4f04c10c919bb7a4a8d14f90384f9334ac4e8913270ddeb71bc4510f6084/summary.lisp"
   :BYTES 5168 :DEVICE 16777232 :INODE 1560114230 :MTIME 1793207956 :SHA256
   "9917e1fe98a9ea7a17bfcb82e90aaca022f9563a6acbdb0dbd5cff8f09a9f576")
  (:PATH
   "spikes/results/ci/by-source/cdd0c5630c8a352fbe29e9cb0b1e2e34d51d500934c2dd51e743f2943c750bd6/runs/38799904386/1/publications/98f53a79e7df374331abb09a0af6554e71104325b0db7217f06a2081ec37740c.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114232 :MTIME 1793207956 :SHA256
   "21af0faad156c5df1646592f48822244018256a4cbac5bf0179a8d006b469d36")
  (:PATH
   "spikes/results/ci/by-source/cef410ee08b0a9fa34f19320be438a8105f507e4e80577a6c641564293d25588/runs/38140899357/1/collections/8375e09aef4e9e17fbd0aeac6955f709aa188c7237d2e9cd40c4cd9bb7dcdb05/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114239 :MTIME 1793207956 :SHA256
   "f3e3a7e9ee4746d45b51093255784b43c3f37bfceae953bf75b98385d16b4886")
  (:PATH
   "spikes/results/ci/by-source/cef410ee08b0a9fa34f19320be438a8105f507e4e80577a6c641564293d25588/runs/38140899357/1/collections/8375e09aef4e9e17fbd0aeac6955f709aa188c7237d2e9cd40c4cd9bb7dcdb05/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114240 :MTIME 1793207956 :SHA256
   "bdf636370fbdc4fd3eed03c5991917f08357ab0e40323fad2581b4f400718492")
  (:PATH
   "spikes/results/ci/by-source/cef410ee08b0a9fa34f19320be438a8105f507e4e80577a6c641564293d25588/runs/38140899357/1/collections/8375e09aef4e9e17fbd0aeac6955f709aa188c7237d2e9cd40c4cd9bb7dcdb05/summary.lisp"
   :BYTES 4279 :DEVICE 16777232 :INODE 1560114241 :MTIME 1793207956 :SHA256
   "baad64c97c030207193182e0a7823f1afad342fe38e60f7067f6a8440573ca3a")
  (:PATH
   "spikes/results/ci/by-source/cef410ee08b0a9fa34f19320be438a8105f507e4e80577a6c641564293d25588/runs/38140899357/1/collections/e8c855815961001bd84bfa994b0e1a61c000cda2c0511153f260db917a7511ad/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114243 :MTIME 1793207956 :SHA256
   "ea10ae8c0c92e6a51abf6276a0009ea91e2acd90dac573f9dd817842eed2f2e2")
  (:PATH
   "spikes/results/ci/by-source/cef410ee08b0a9fa34f19320be438a8105f507e4e80577a6c641564293d25588/runs/38140899357/1/collections/e8c855815961001bd84bfa994b0e1a61c000cda2c0511153f260db917a7511ad/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114244 :MTIME 1793207956 :SHA256
   "bdf636370fbdc4fd3eed03c5991917f08357ab0e40323fad2581b4f400718492")
  (:PATH
   "spikes/results/ci/by-source/cef410ee08b0a9fa34f19320be438a8105f507e4e80577a6c641564293d25588/runs/38140899357/1/collections/e8c855815961001bd84bfa994b0e1a61c000cda2c0511153f260db917a7511ad/summary.lisp"
   :BYTES 4273 :DEVICE 16777232 :INODE 1560114245 :MTIME 1793207956 :SHA256
   "5781f9a182b5e97f776819949fdb524ee29735b9942bf75eb3c002f29e8e12d6")
  (:PATH
   "spikes/results/ci/by-source/cef410ee08b0a9fa34f19320be438a8105f507e4e80577a6c641564293d25588/runs/38140899357/1/publications/13ed4f104a5e8a2ef5cdd71f9e405aa3cf66c245c78fc7774c410fddadaa5788.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114247 :MTIME 1793207956 :SHA256
   "f46bf7a8ce3e048b2096d652ce5ee83b0c5eb76905ed73e9d8818c2503eed5c1")
  (:PATH
   "spikes/results/ci/by-source/cef410ee08b0a9fa34f19320be438a8105f507e4e80577a6c641564293d25588/runs/38140899357/1/publications/69ab4cc04d1535563d91372c8a4770ad03889a42843af7c656650f7c1e73baf2.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114248 :MTIME 1793207956 :SHA256
   "4e44ef074949ead3c7243b00ff1d570eb672773a1c63984191f988195a9d99bd")
  (:PATH
   "spikes/results/ci/by-source/d8427a9142ac65de6438a4f79eafd1ba845a3a4dab056e7b12ac3466ef043957/runs/38630336144/1/collections/3623fdf67f2e8ddcee2dca0a701cdae39388989c7b2a97beff37329dbf187046/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114255 :MTIME 1793207956 :SHA256
   "7d097678e2db501e90212824dad071858f4d7a347fc04cac54a418f9afe32143")
  (:PATH
   "spikes/results/ci/by-source/d8427a9142ac65de6438a4f79eafd1ba845a3a4dab056e7b12ac3466ef043957/runs/38630336144/1/collections/3623fdf67f2e8ddcee2dca0a701cdae39388989c7b2a97beff37329dbf187046/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114256 :MTIME 1793207956 :SHA256
   "29449139adc3f10419fee263b29f05ed49a0c399ac4e44df368b94b475360bbc")
  (:PATH
   "spikes/results/ci/by-source/d8427a9142ac65de6438a4f79eafd1ba845a3a4dab056e7b12ac3466ef043957/runs/38630336144/1/collections/3623fdf67f2e8ddcee2dca0a701cdae39388989c7b2a97beff37329dbf187046/summary.lisp"
   :BYTES 4858 :DEVICE 16777232 :INODE 1560114257 :MTIME 1793207956 :SHA256
   "4127dfb9a1fc30bc05bd690a3e6987d86e1f26d60e383742e2e2d86bf7cd5ab9")
  (:PATH
   "spikes/results/ci/by-source/d8427a9142ac65de6438a4f79eafd1ba845a3a4dab056e7b12ac3466ef043957/runs/38630336144/1/collections/4ee5e0645087eab5144fad15bf1f62299de972a9c16e52c1a6fc8d320e0241d7/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114259 :MTIME 1793207956 :SHA256
   "5f69adff431236b9e968e3e901239d3a75bcb2f30c0937cab9eafb90eb4c7f48")
  (:PATH
   "spikes/results/ci/by-source/d8427a9142ac65de6438a4f79eafd1ba845a3a4dab056e7b12ac3466ef043957/runs/38630336144/1/collections/4ee5e0645087eab5144fad15bf1f62299de972a9c16e52c1a6fc8d320e0241d7/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114260 :MTIME 1793207956 :SHA256
   "29449139adc3f10419fee263b29f05ed49a0c399ac4e44df368b94b475360bbc")
  (:PATH
   "spikes/results/ci/by-source/d8427a9142ac65de6438a4f79eafd1ba845a3a4dab056e7b12ac3466ef043957/runs/38630336144/1/collections/4ee5e0645087eab5144fad15bf1f62299de972a9c16e52c1a6fc8d320e0241d7/summary.lisp"
   :BYTES 4864 :DEVICE 16777232 :INODE 1560114261 :MTIME 1793207956 :SHA256
   "3f4468b6da319b5c2ee4f2c33c973e61afbcef347d68718af79933565ae8d390")
  (:PATH
   "spikes/results/ci/by-source/d8427a9142ac65de6438a4f79eafd1ba845a3a4dab056e7b12ac3466ef043957/runs/38630336144/1/publications/18cdbf3addee5c33dd7bb0cc6108af45a111c8c31a31ce3f2282f9a52341610a.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114263 :MTIME 1793207956 :SHA256
   "e0eb3b2d3c94652ee8aa65cf55ef3371d93fc5ccc06ffbbef1f9a916b0d96ce0")
  (:PATH
   "spikes/results/ci/by-source/d8427a9142ac65de6438a4f79eafd1ba845a3a4dab056e7b12ac3466ef043957/runs/38630336144/1/publications/9bcdff78e4a4647317cc8e806149e8e18c00ba70335cb49c7090543ae28b7927.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114264 :MTIME 1793207956 :SHA256
   "ed4406bb10549648c10ff61ce001be25bf0397587ee2639fd0a5c5b32e7ee0f3")
  (:PATH
   "spikes/results/ci/by-source/d92ff23e5cd6f7dafcc4e327d0a7a496fbf5d35ea025e2fe26ed8a4922ccd749/runs/38806697575/1/collections/021c8759765ca867255b82c7cb843b5cecbb0d3c03fdd795201b10bdd830f238/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114271 :MTIME 1793207956 :SHA256
   "b9a3286fb5341d36eee6177ecdeb97a09200230f822e5c2c0eaaf1c076be96fe")
  (:PATH
   "spikes/results/ci/by-source/d92ff23e5cd6f7dafcc4e327d0a7a496fbf5d35ea025e2fe26ed8a4922ccd749/runs/38806697575/1/collections/021c8759765ca867255b82c7cb843b5cecbb0d3c03fdd795201b10bdd830f238/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114272 :MTIME 1793207956 :SHA256
   "33fc774e3d58f25bbc636854163e52f682777e785d0d599ea52c39dce51c8211")
  (:PATH
   "spikes/results/ci/by-source/d92ff23e5cd6f7dafcc4e327d0a7a496fbf5d35ea025e2fe26ed8a4922ccd749/runs/38806697575/1/collections/021c8759765ca867255b82c7cb843b5cecbb0d3c03fdd795201b10bdd830f238/summary.lisp"
   :BYTES 5170 :DEVICE 16777232 :INODE 1560114273 :MTIME 1793207956 :SHA256
   "ec06fea60a570ded9919584bf8afce747445f2d53d5d677ff4a10834a6a7e5fb")
  (:PATH
   "spikes/results/ci/by-source/d92ff23e5cd6f7dafcc4e327d0a7a496fbf5d35ea025e2fe26ed8a4922ccd749/runs/38806697575/1/publications/ff41aa8f187036e03cb4781af9dab74cdc29aa66f42530758dfc319db98a5e02.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114275 :MTIME 1793207956 :SHA256
   "e91874d6f261d72c30e95b6bf731e12a5a9e2732d400281567e42288faca3cef")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38638591424/1/collections/b7d1ce3f769f54359de1600ae0160f7598e9e347f22a9152ab87868946504a27/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114283 :MTIME 1793207956 :SHA256
   "89c3440508e6d17d209afa45c4891277d3cc9819af1d89a9391a1746c2777c6d")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38638591424/1/collections/b7d1ce3f769f54359de1600ae0160f7598e9e347f22a9152ab87868946504a27/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114284 :MTIME 1793207956 :SHA256
   "d114afbb1c38c33d2e92b11c1d923fcaeabf36e68ba950ace819cd8b9c9c880d")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38638591424/1/collections/b7d1ce3f769f54359de1600ae0160f7598e9e347f22a9152ab87868946504a27/summary.lisp"
   :BYTES 4911 :DEVICE 16777232 :INODE 1560114285 :MTIME 1793207956 :SHA256
   "19026b277899d308a33e757c706864a31674f1c8c36720a591c47ff84f2dacc1")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38638591424/1/collections/d7a9035b09bf4b5f675bafc89e7890b35a7097e867d481a9786f5aff673c2bfd/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114287 :MTIME 1793207956 :SHA256
   "c84212fcd9807bb7f4af4715f5a8cf62d628f3a54ebc511a42161af0b6388b6c")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38638591424/1/collections/d7a9035b09bf4b5f675bafc89e7890b35a7097e867d481a9786f5aff673c2bfd/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114288 :MTIME 1793207956 :SHA256
   "d114afbb1c38c33d2e92b11c1d923fcaeabf36e68ba950ace819cd8b9c9c880d")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38638591424/1/collections/d7a9035b09bf4b5f675bafc89e7890b35a7097e867d481a9786f5aff673c2bfd/summary.lisp"
   :BYTES 4917 :DEVICE 16777232 :INODE 1560114289 :MTIME 1793207956 :SHA256
   "b37fc6c96a2e6eae30aae40c0bdc2538ebab47e0e52267dafeb93dec3bcd1e63")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38638591424/1/publications/de52db1a9544110658e11fbd337d3ca4a89a425c0d5107a81498e807b67868b5.lisp"
   :BYTES 734 :DEVICE 16777232 :INODE 1560114291 :MTIME 1793207956 :SHA256
   "dc5f6b9abf491ad7ee915b8de7cf5530478973e8ab2d3ab16e3f88e547038510")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38638591424/1/publications/e33f2be06bf081e5854eae1dee89ded8fe7be0bd9115d83c128c5f67e4e531f3.lisp"
   :BYTES 731 :DEVICE 16777232 :INODE 1560114292 :MTIME 1793207956 :SHA256
   "573eee939fbf6dc57a36665995c11114a21b8398c44c38da1b296de6ef2cc15b")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38640790953/1/collections/4af21d534598d904cbdb10f93d5d432846520d715436c8d0c4626a291c480998/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114297 :MTIME 1793207956 :SHA256
   "b451dc519f7ee30748e5f4faef0f4c754a99fe637ac0cfc6fe5f90bb8e5c3bfd")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38640790953/1/collections/4af21d534598d904cbdb10f93d5d432846520d715436c8d0c4626a291c480998/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114298 :MTIME 1793207956 :SHA256
   "59af1c32e3a6c66634c81c5351dc8da974f6bf8712c09c51e5d6f04e7e70b34c")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38640790953/1/collections/4af21d534598d904cbdb10f93d5d432846520d715436c8d0c4626a291c480998/summary.lisp"
   :BYTES 4860 :DEVICE 16777232 :INODE 1560114299 :MTIME 1793207956 :SHA256
   "cb5c897669abef1a88be9566653bd8ec0b56c10af3b9c858ec35ddbbe541ac73")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38640790953/1/collections/a9d29a23199b0da5e02052cfbfc06d2b089eecdf19c9e896b904b7758a108630/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114301 :MTIME 1793207956 :SHA256
   "0790053b6daa59c503db0cb7270d45ce0c8e14e4147bdb3c4f7028f95a31def6")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38640790953/1/collections/a9d29a23199b0da5e02052cfbfc06d2b089eecdf19c9e896b904b7758a108630/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114302 :MTIME 1793207956 :SHA256
   "59af1c32e3a6c66634c81c5351dc8da974f6bf8712c09c51e5d6f04e7e70b34c")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38640790953/1/collections/a9d29a23199b0da5e02052cfbfc06d2b089eecdf19c9e896b904b7758a108630/summary.lisp"
   :BYTES 4866 :DEVICE 16777232 :INODE 1560114303 :MTIME 1793207956 :SHA256
   "0f57c3fc44266fff141a249f81eb2b6cbc67afc66c357f39c0563a8a74a61522")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38640790953/1/publications/efd1860d475ca5a25143214474bb52696f02d1d46723a7f9b63c67c1a59f2e54.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114305 :MTIME 1793207956 :SHA256
   "0b5dadf5393107701cf5b8ca53f426a06efbeca2aa24fb3286a720cdf2d81d18")
  (:PATH
   "spikes/results/ci/by-source/d9e3a356af8238f1eb92f46e14570ef7713838e8151e016b3d94e2e14fb341ec/runs/38640790953/1/publications/f61fccb839b321092c2195aecb0887413d1e14a3f571e9e03e50b02ad8dca9ee.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114306 :MTIME 1793207956 :SHA256
   "a1bc66fcb4c6ca92ff72982816d12f32c3fee51c6c266b56cc870b377160d87b")
  (:PATH
   "spikes/results/ci/by-source/de580d896c34fea83c92e985238ce9ebf5b57af7b9c3cfcdacffb3a1b86a2a93/runs/38629079311/1/collections/6182dc03a81549f0d325784ac04fc9ae380c6f230a235b9f5772dfb03aa26a20/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114313 :MTIME 1793207956 :SHA256
   "3d708caca34e89693eab45858b15dc3930fea9006d3ca6d36ba0ebe8b1cb8745")
  (:PATH
   "spikes/results/ci/by-source/de580d896c34fea83c92e985238ce9ebf5b57af7b9c3cfcdacffb3a1b86a2a93/runs/38629079311/1/collections/6182dc03a81549f0d325784ac04fc9ae380c6f230a235b9f5772dfb03aa26a20/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114314 :MTIME 1793207956 :SHA256
   "cea6c73c14d40e49b79fbee6fd00f1e0a9cc16bb0dfc46d34b06ec8f27021e24")
  (:PATH
   "spikes/results/ci/by-source/de580d896c34fea83c92e985238ce9ebf5b57af7b9c3cfcdacffb3a1b86a2a93/runs/38629079311/1/collections/6182dc03a81549f0d325784ac04fc9ae380c6f230a235b9f5772dfb03aa26a20/summary.lisp"
   :BYTES 4758 :DEVICE 16777232 :INODE 1560114315 :MTIME 1793207956 :SHA256
   "29583d9bbca459b2e157ffb0dd27cb641d0dfcdea44e6f079c3fb8f891d55376")
  (:PATH
   "spikes/results/ci/by-source/de580d896c34fea83c92e985238ce9ebf5b57af7b9c3cfcdacffb3a1b86a2a93/runs/38629079311/1/collections/7a588a39f527ce3ad858cb95a26497253581feb313c59f339565fe6c043141d1/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114317 :MTIME 1793207956 :SHA256
   "a608e85aab8bfaec4ac95794dcfec6a304407aa82b11d01f192adeb010415a23")
  (:PATH
   "spikes/results/ci/by-source/de580d896c34fea83c92e985238ce9ebf5b57af7b9c3cfcdacffb3a1b86a2a93/runs/38629079311/1/collections/7a588a39f527ce3ad858cb95a26497253581feb313c59f339565fe6c043141d1/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114318 :MTIME 1793207956 :SHA256
   "cea6c73c14d40e49b79fbee6fd00f1e0a9cc16bb0dfc46d34b06ec8f27021e24")
  (:PATH
   "spikes/results/ci/by-source/de580d896c34fea83c92e985238ce9ebf5b57af7b9c3cfcdacffb3a1b86a2a93/runs/38629079311/1/collections/7a588a39f527ce3ad858cb95a26497253581feb313c59f339565fe6c043141d1/summary.lisp"
   :BYTES 4764 :DEVICE 16777232 :INODE 1560114319 :MTIME 1793207956 :SHA256
   "dce20140fdcf1202ef357dd94a1635c63ed2ffc4f7aa225bef9ab4cd4b486b2a")
  (:PATH
   "spikes/results/ci/by-source/de580d896c34fea83c92e985238ce9ebf5b57af7b9c3cfcdacffb3a1b86a2a93/runs/38629079311/1/publications/48743167a1ae1c65731ebe3a5439ca6388ba7a258f7d3fe2aeb97c938ff6cfbe.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114321 :MTIME 1793207956 :SHA256
   "d5466310756813103a0b71d0f02c6b0728f314364dc1655337803b7beb4c25a8")
  (:PATH
   "spikes/results/ci/by-source/de580d896c34fea83c92e985238ce9ebf5b57af7b9c3cfcdacffb3a1b86a2a93/runs/38629079311/1/publications/f7c0261ae88c2a81e0e1f01924e30346246748227a07788d3a14b79c177ca2af.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114322 :MTIME 1793207956 :SHA256
   "0326321a70c93cf2df751ad8af5ba5445d63b7c1c7128ac23def83d279f5d1f1")
  (:PATH
   "spikes/results/ci/by-source/e59e1e36a6b8aece8055743ff4eb8e17e0e4e7082c73758ceac418d5babced3e/runs/38610425693/1/collections/d8391b3db1afa2d8db06a351690ded77d8aec2b2ce8d5c9850f43d0d19ffda88/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114329 :MTIME 1793207956 :SHA256
   "8ed02d2c0ceaf8e41c3803f7a91a276983c66047badc42ed1e4ea81403265576")
  (:PATH
   "spikes/results/ci/by-source/e59e1e36a6b8aece8055743ff4eb8e17e0e4e7082c73758ceac418d5babced3e/runs/38610425693/1/collections/d8391b3db1afa2d8db06a351690ded77d8aec2b2ce8d5c9850f43d0d19ffda88/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114330 :MTIME 1793207956 :SHA256
   "e3d6edd9f256f43d102367eb3f3f02ab2aaa65497d2ffb85d02014b0a768c3b6")
  (:PATH
   "spikes/results/ci/by-source/e59e1e36a6b8aece8055743ff4eb8e17e0e4e7082c73758ceac418d5babced3e/runs/38610425693/1/collections/d8391b3db1afa2d8db06a351690ded77d8aec2b2ce8d5c9850f43d0d19ffda88/summary.lisp"
   :BYTES 4815 :DEVICE 16777232 :INODE 1560114331 :MTIME 1793207956 :SHA256
   "8e0dfd7e9191af8fe65332beb1f0c51c03cbdf508c58867e93c3fbdac26f0ac5")
  (:PATH
   "spikes/results/ci/by-source/e59e1e36a6b8aece8055743ff4eb8e17e0e4e7082c73758ceac418d5babced3e/runs/38610425693/1/collections/fd2e013d6a4566eb3c634a400b6f94d5c0c489151f0ad06c72d377195291e7e2/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114333 :MTIME 1793207956 :SHA256
   "995efbfd618c8030f17a77a23c74b85da5edef7dbb5104073a93f8930d379480")
  (:PATH
   "spikes/results/ci/by-source/e59e1e36a6b8aece8055743ff4eb8e17e0e4e7082c73758ceac418d5babced3e/runs/38610425693/1/collections/fd2e013d6a4566eb3c634a400b6f94d5c0c489151f0ad06c72d377195291e7e2/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114334 :MTIME 1793207956 :SHA256
   "e3d6edd9f256f43d102367eb3f3f02ab2aaa65497d2ffb85d02014b0a768c3b6")
  (:PATH
   "spikes/results/ci/by-source/e59e1e36a6b8aece8055743ff4eb8e17e0e4e7082c73758ceac418d5babced3e/runs/38610425693/1/collections/fd2e013d6a4566eb3c634a400b6f94d5c0c489151f0ad06c72d377195291e7e2/summary.lisp"
   :BYTES 4809 :DEVICE 16777232 :INODE 1560114335 :MTIME 1793207956 :SHA256
   "5e257538d20e58b0bea3ff4c3849a9efd56263247eb662ee2c276fdaf6e405b6")
  (:PATH
   "spikes/results/ci/by-source/e59e1e36a6b8aece8055743ff4eb8e17e0e4e7082c73758ceac418d5babced3e/runs/38610425693/1/publications/286224fe8ac31982690686d025efbb818e15127419938c464bfa2d06b68252fb.lisp"
   :BYTES 735 :DEVICE 16777232 :INODE 1560114337 :MTIME 1793207956 :SHA256
   "44b16135e2c8d5d3359e218c8a9e433c98a398f7ed93fd6b813f65d007817143")
  (:PATH
   "spikes/results/ci/by-source/e59e1e36a6b8aece8055743ff4eb8e17e0e4e7082c73758ceac418d5babced3e/runs/38610425693/1/publications/2dd2f3561be8813ed7897d3ec6853a799092107e142cad2b49f33be14299ef15.lisp"
   :BYTES 732 :DEVICE 16777232 :INODE 1560114338 :MTIME 1793207956 :SHA256
   "ac749469a1257af7ef424662ec434a2b6d3dab1e5c36f2a0dc1036c392a1c431")
  (:PATH
   "spikes/results/ci/by-source/e5a638a399182f3988ee55f83530dc0913b3448a846f95d65c55037f64cc7409/runs/38147525300/1/collections/4fe88c79a38ffe1df090461010b07e756002637a26cb285c4a82a2caa73bac5b/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114345 :MTIME 1793207956 :SHA256
   "d1d4e28e0b69fa3cc4e8971f689fa0d04ab21835fb2b979c8922fe0573099646")
  (:PATH
   "spikes/results/ci/by-source/e5a638a399182f3988ee55f83530dc0913b3448a846f95d65c55037f64cc7409/runs/38147525300/1/collections/4fe88c79a38ffe1df090461010b07e756002637a26cb285c4a82a2caa73bac5b/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114346 :MTIME 1793207956 :SHA256
   "e640ef2a5921f0c0009ef4af19d54207646ef91c65c9f2838de730eaa707e79b")
  (:PATH
   "spikes/results/ci/by-source/e5a638a399182f3988ee55f83530dc0913b3448a846f95d65c55037f64cc7409/runs/38147525300/1/collections/4fe88c79a38ffe1df090461010b07e756002637a26cb285c4a82a2caa73bac5b/summary.lisp"
   :BYTES 4384 :DEVICE 16777232 :INODE 1560114347 :MTIME 1793207956 :SHA256
   "06f55bf6efbefb3b8657fdd7c775cc787f9e0e4211c8b5b7735c619c82dc9563")
  (:PATH
   "spikes/results/ci/by-source/e5a638a399182f3988ee55f83530dc0913b3448a846f95d65c55037f64cc7409/runs/38147525300/1/collections/524ae944f6efa2f28e677bceb946866ec633d4fed5685bc5265f3f066a532bfe/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114349 :MTIME 1793207956 :SHA256
   "322f23a5c77454debad9519d5da83ed9424e5cabb5bf7cc07ae06f1a9e51f37b")
  (:PATH
   "spikes/results/ci/by-source/e5a638a399182f3988ee55f83530dc0913b3448a846f95d65c55037f64cc7409/runs/38147525300/1/collections/524ae944f6efa2f28e677bceb946866ec633d4fed5685bc5265f3f066a532bfe/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114350 :MTIME 1793207956 :SHA256
   "e640ef2a5921f0c0009ef4af19d54207646ef91c65c9f2838de730eaa707e79b")
  (:PATH
   "spikes/results/ci/by-source/e5a638a399182f3988ee55f83530dc0913b3448a846f95d65c55037f64cc7409/runs/38147525300/1/collections/524ae944f6efa2f28e677bceb946866ec633d4fed5685bc5265f3f066a532bfe/summary.lisp"
   :BYTES 4378 :DEVICE 16777232 :INODE 1560114351 :MTIME 1793207956 :SHA256
   "193c59d26a1b5cf68b677e077b22318fc8a9550d1e4f0a295cf79a8c455a2300")
  (:PATH
   "spikes/results/ci/by-source/e5a638a399182f3988ee55f83530dc0913b3448a846f95d65c55037f64cc7409/runs/38147525300/1/publications/510d4d74a06aeab3244db0efcb2d3c49707d9789c65000e6f86f46ad765b0621.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114353 :MTIME 1793207956 :SHA256
   "c4ed0392e582375918e76a2df638739f0386309f39bc865bb3cf94942602186a")
  (:PATH
   "spikes/results/ci/by-source/e5a638a399182f3988ee55f83530dc0913b3448a846f95d65c55037f64cc7409/runs/38147525300/1/publications/c820033f24e8658eedf03a750eae25c78efda255c9d718eea732d6ab98f16b39.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114354 :MTIME 1793207956 :SHA256
   "50a661bac1caf27b25fb6adeeead0da40133bc32645f262e64f9498e525ab9a5")
  (:PATH
   "spikes/results/ci/by-source/e9b958b768d54ddb48bcf3a8047c8a364081a88a6c51fdf580572b9529554d28/runs/38448242409/1/collections/96104218da20833185a415d60a0ff06df31bea93bb0777151685a94c3f8f4140/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114361 :MTIME 1793207956 :SHA256
   "13fa0560fb03857df859e3e7fd8f75183b1314d4cf47398f1bd274f49f1d8df2")
  (:PATH
   "spikes/results/ci/by-source/e9b958b768d54ddb48bcf3a8047c8a364081a88a6c51fdf580572b9529554d28/runs/38448242409/1/collections/96104218da20833185a415d60a0ff06df31bea93bb0777151685a94c3f8f4140/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114362 :MTIME 1793207956 :SHA256
   "233dcd354479ed10034d7c2c2a604aebef6711a3177ac4bc0689dcafc0e9b798")
  (:PATH
   "spikes/results/ci/by-source/e9b958b768d54ddb48bcf3a8047c8a364081a88a6c51fdf580572b9529554d28/runs/38448242409/1/collections/96104218da20833185a415d60a0ff06df31bea93bb0777151685a94c3f8f4140/summary.lisp"
   :BYTES 4384 :DEVICE 16777232 :INODE 1560114363 :MTIME 1793207956 :SHA256
   "64c0db5ef211e36b1c8890709e832067d3bd7f2c8baef5f94e4062ffb15a56b4")
  (:PATH
   "spikes/results/ci/by-source/e9b958b768d54ddb48bcf3a8047c8a364081a88a6c51fdf580572b9529554d28/runs/38448242409/1/collections/e907553601dfb0dc840a663337639187b0b3096bc94316bbf853004e719fd56e/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114365 :MTIME 1793207956 :SHA256
   "d1da7a34d9e892b37910635249bb880d31ce81556af32963b488aa5a1b434947")
  (:PATH
   "spikes/results/ci/by-source/e9b958b768d54ddb48bcf3a8047c8a364081a88a6c51fdf580572b9529554d28/runs/38448242409/1/collections/e907553601dfb0dc840a663337639187b0b3096bc94316bbf853004e719fd56e/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114366 :MTIME 1793207956 :SHA256
   "233dcd354479ed10034d7c2c2a604aebef6711a3177ac4bc0689dcafc0e9b798")
  (:PATH
   "spikes/results/ci/by-source/e9b958b768d54ddb48bcf3a8047c8a364081a88a6c51fdf580572b9529554d28/runs/38448242409/1/collections/e907553601dfb0dc840a663337639187b0b3096bc94316bbf853004e719fd56e/summary.lisp"
   :BYTES 4378 :DEVICE 16777232 :INODE 1560114367 :MTIME 1793207956 :SHA256
   "bec1b46f99f1a5ffa59123e2787dca0dce3945bf12c8d6c64a32cc4d6d93df0e")
  (:PATH
   "spikes/results/ci/by-source/e9b958b768d54ddb48bcf3a8047c8a364081a88a6c51fdf580572b9529554d28/runs/38448242409/1/publications/4584a75bb49e7fa2c4c95632220bb006def5733f9b0011dbe51439c5724c6426.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114369 :MTIME 1793207956 :SHA256
   "96cbd45602ea849a98bbbd7026d475680195760045718ef8bfc6f6a7f4778e89")
  (:PATH
   "spikes/results/ci/by-source/e9b958b768d54ddb48bcf3a8047c8a364081a88a6c51fdf580572b9529554d28/runs/38448242409/1/publications/7975aa1651f757fb049df5bb145069cb37971f9808b5f78a1ba5ae193abc9ce7.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114370 :MTIME 1793207956 :SHA256
   "57d5c6865df9f12249cb585776fd22a7ab6456f1fdf24d4017dc13880d1800e6")
  (:PATH
   "spikes/results/ci/by-source/ea0db42cca77e4a95402a1bf6cbf4df7669a6bd2a05167026b7521de3468cd2d/runs/38929538888/1/collections/b0f9b1d015c8821b04445cd05f8bb25c1477bb41101b045605052d2a2dc4fc2a/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114377 :MTIME 1793207956 :SHA256
   "ddb2441fa804dd6a348311d481989d5e1931ddb70068db3ae689bb3628f525b1")
  (:PATH
   "spikes/results/ci/by-source/ea0db42cca77e4a95402a1bf6cbf4df7669a6bd2a05167026b7521de3468cd2d/runs/38929538888/1/collections/b0f9b1d015c8821b04445cd05f8bb25c1477bb41101b045605052d2a2dc4fc2a/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114378 :MTIME 1793207956 :SHA256
   "6bdbcbaef183383e5ebaf5022426d2e155ac69a9f3d144f6672a09bd78b97856")
  (:PATH
   "spikes/results/ci/by-source/ea0db42cca77e4a95402a1bf6cbf4df7669a6bd2a05167026b7521de3468cd2d/runs/38929538888/1/collections/b0f9b1d015c8821b04445cd05f8bb25c1477bb41101b045605052d2a2dc4fc2a/summary.lisp"
   :BYTES 5275 :DEVICE 16777232 :INODE 1560114379 :MTIME 1793207956 :SHA256
   "cbc14b00ce7d07c832fba52cf8850e28c28c2c25dee1d352221822f0d848a324")
  (:PATH
   "spikes/results/ci/by-source/ea0db42cca77e4a95402a1bf6cbf4df7669a6bd2a05167026b7521de3468cd2d/runs/38929538888/1/publications/a6b3443ee7e03c57047e0f983a4067214488219003cbc00d411c63e33bb68cd4.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114381 :MTIME 1793207956 :SHA256
   "a316dc9fb568900835e867ae043af264e220322adeaf0167278a7b72c244ea5d")
  (:PATH
   "spikes/results/ci/by-source/eb7acdcf256290ee991f837aa9f42808273bd041482236dd873fe1d30bfce06b/runs/38946637554/1/collections/372cbcf0331b07836c57aa41fe26cda886b94fc3b1642c7a3b618b62a2336778/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114388 :MTIME 1793207956 :SHA256
   "0c7b06800b74832bc5556ec7e3e4fec40d72edeb2327dc5ba813eefc34b06b23")
  (:PATH
   "spikes/results/ci/by-source/eb7acdcf256290ee991f837aa9f42808273bd041482236dd873fe1d30bfce06b/runs/38946637554/1/collections/372cbcf0331b07836c57aa41fe26cda886b94fc3b1642c7a3b618b62a2336778/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114389 :MTIME 1793207956 :SHA256
   "745bcfef3b9594d02aedf6b89f5edf7cbc23215e838763d9e011f2d90d3c77a3")
  (:PATH
   "spikes/results/ci/by-source/eb7acdcf256290ee991f837aa9f42808273bd041482236dd873fe1d30bfce06b/runs/38946637554/1/collections/372cbcf0331b07836c57aa41fe26cda886b94fc3b1642c7a3b618b62a2336778/summary.lisp"
   :BYTES 5555 :DEVICE 16777232 :INODE 1560114390 :MTIME 1793207956 :SHA256
   "24ea5bc5804244ee423942787b066e336c5344331d7fb88b1b969da539e619b7")
  (:PATH
   "spikes/results/ci/by-source/eb7acdcf256290ee991f837aa9f42808273bd041482236dd873fe1d30bfce06b/runs/38946637554/1/publications/1b6eadbf18e87ac6b197e1867b9088073db534c77e81f390b2a6f32767603df0.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114392 :MTIME 1793207956 :SHA256
   "b54be6ae14392b4eacbe249d1ee0a9bf95826f56a152a98035fe199a1a7e896d")
  (:PATH
   "spikes/results/ci/by-source/f1d1328f13535b7c73922444b67d5f00596c2add9c59247dba48d1787517dcb0/runs/38455667693/1/collections/2166085f2710f7e03272462cbf225341224bfaf31bfb09ccc787e349747ccbca/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114399 :MTIME 1793207956 :SHA256
   "881e0b7f850878aa2562ed833ac6cddb74d55541eebb4f5e16f8de162afe4594")
  (:PATH
   "spikes/results/ci/by-source/f1d1328f13535b7c73922444b67d5f00596c2add9c59247dba48d1787517dcb0/runs/38455667693/1/collections/2166085f2710f7e03272462cbf225341224bfaf31bfb09ccc787e349747ccbca/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114400 :MTIME 1793207956 :SHA256
   "2496167502553a785104fbcb113d8a256a168fe2e6567865545fb5226bb6e044")
  (:PATH
   "spikes/results/ci/by-source/f1d1328f13535b7c73922444b67d5f00596c2add9c59247dba48d1787517dcb0/runs/38455667693/1/collections/2166085f2710f7e03272462cbf225341224bfaf31bfb09ccc787e349747ccbca/summary.lisp"
   :BYTES 4478 :DEVICE 16777232 :INODE 1560114401 :MTIME 1793207956 :SHA256
   "97cdaf8c00932f644f780cf00950e7a4df32612b0acea6a7310a5cfc337209df")
  (:PATH
   "spikes/results/ci/by-source/f1d1328f13535b7c73922444b67d5f00596c2add9c59247dba48d1787517dcb0/runs/38455667693/1/collections/e8bc17dacda2290fc8829834117a553f77a6803d61f939d30514c31d7c50116b/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114403 :MTIME 1793207956 :SHA256
   "8404b0f73f58c192e36253a5932eacbf53f5fee499e144011491816e3dc73397")
  (:PATH
   "spikes/results/ci/by-source/f1d1328f13535b7c73922444b67d5f00596c2add9c59247dba48d1787517dcb0/runs/38455667693/1/collections/e8bc17dacda2290fc8829834117a553f77a6803d61f939d30514c31d7c50116b/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114404 :MTIME 1793207956 :SHA256
   "2496167502553a785104fbcb113d8a256a168fe2e6567865545fb5226bb6e044")
  (:PATH
   "spikes/results/ci/by-source/f1d1328f13535b7c73922444b67d5f00596c2add9c59247dba48d1787517dcb0/runs/38455667693/1/collections/e8bc17dacda2290fc8829834117a553f77a6803d61f939d30514c31d7c50116b/summary.lisp"
   :BYTES 4472 :DEVICE 16777232 :INODE 1560114405 :MTIME 1793207956 :SHA256
   "4e096567afe4edde3c5aa600975a0aba683b2f020802d2b68c1c3f0cfd35c343")
  (:PATH
   "spikes/results/ci/by-source/f1d1328f13535b7c73922444b67d5f00596c2add9c59247dba48d1787517dcb0/runs/38455667693/1/publications/0f9e98c6ee99d53bf10e1ee535b4989b75d1b3e5746c9315364f642a4605bc83.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114407 :MTIME 1793207956 :SHA256
   "3795f13352c25591ebdd83f81150f0d2f0ec45d993261fa1cf67f4765b08471b")
  (:PATH
   "spikes/results/ci/by-source/f1d1328f13535b7c73922444b67d5f00596c2add9c59247dba48d1787517dcb0/runs/38455667693/1/publications/88fcdb334bf1edbabbfacd583d88cb2f11f3c38fdedca9ea87dc5b51005e4f7b.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114408 :MTIME 1793207956 :SHA256
   "4508a2e188d450cdefe385623e1fc677564363394cbf2ceb13f42cb523b3991f")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/collections/f1f997f12c5b948996e8a2c1a8d25c4e3a0ccd55e98835b10bc99efa30980579/manifest.lisp"
   :BYTES 393 :DEVICE 16777232 :INODE 1557189307 :MTIME 1792782988 :SHA256
   "ae0c0aad2851b4d10287ffb1a9c21f7a4219e5dd4206c710cb9cad3c57c0b948")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/collections/f1f997f12c5b948996e8a2c1a8d25c4e3a0ccd55e98835b10bc99efa30980579/report.md"
   :BYTES 21826 :DEVICE 16777232 :INODE 1557189308 :MTIME 1792782988 :SHA256
   "0e20f2d7f4a00fc56cb5e621cead0e96ac626b9bb57d65a797b5bb2dd0d8f4b1")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/collections/f1f997f12c5b948996e8a2c1a8d25c4e3a0ccd55e98835b10bc99efa30980579/summary.lisp"
   :BYTES 27455 :DEVICE 16777232 :INODE 1557189309 :MTIME 1792782988 :SHA256
   "4d52ee325402aea67ad722de589b619155d35417052fcca92e08683b203fbbf3")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/manifest.lisp"
   :BYTES 9821 :DEVICE 16777232 :INODE 1557189313 :MTIME 1792782988 :SHA256
   "f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/c4-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1557189316 :MTIME 1792782988 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/c4-driver.stdout"
   :BYTES 113 :DEVICE 16777232 :INODE 1557189317 :MTIME 1792782988 :SHA256
   "accd85553cd1ff9661f469aea44b19c522417e9036085e7a8fa23a1a4f2649c0")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/child-result.lisp"
   :BYTES 3313 :DEVICE 16777232 :INODE 1557189318 :MTIME 1792782988 :SHA256
   "8f42bd4f886b52a1d00d0d45f128f023206fb08f36c320dcadd1aad155024024")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/c4/conservazione.lisp"
   :BYTES 1085 :DEVICE 16777232 :INODE 1557189321 :MTIME 1792782988 :SHA256
   "9a07958975152d024dce06b363a9b75fe074cb357a83a6a422cee68caa39f206")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/c4/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1557189322 :MTIME 1792782988 :SHA256
   "fa06e3f1080fd1ed034f4dd622a0b60f6b9a1e2dbcc42717933ccd3d4cf22cce")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/c4/report.lisp.gz"
   :BYTES 103674 :DEVICE 16777232 :INODE 1557189323 :MTIME 1792782988 :SHA256
   "aa0ce5cea54c8a15375573872ab803a963a4863f774e1817d75762b8bd6f0623")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/job/conservazione.lisp"
   :BYTES 1087 :DEVICE 16777232 :INODE 1557189325 :MTIME 1792782988 :SHA256
   "7d2d0f47193c20a7b3b322e69b910bbfb3ad5d98ae6d0911435acb5fd4a73ac6")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1557189326 :MTIME 1792782988 :SHA256
   "560b353c1c5cf05c97013a014e17d6072cb9c9d59a4402fe647859ea619e8ffb")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/job/report.lisp.gz"
   :BYTES 92392 :DEVICE 16777232 :INODE 1557189327 :MTIME 1792782988 :SHA256
   "c4423bb97e5b7882ecd75243ce90ece658db8cc4c951753451b42a2beb023531")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/links/conservazione.lisp"
   :BYTES 1091 :DEVICE 16777232 :INODE 1557189329 :MTIME 1792782988 :SHA256
   "65911d009cb9e7bb6fa6517e9cadeba984787da0e801389c9f78f1ba21857ad8")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/links/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1557189330 :MTIME 1792782988 :SHA256
   "304d73b1765abad565c9c10f012ce4ff67e6019b7d5c679c55469141d1508c39")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/links/report.lisp.gz"
   :BYTES 92380 :DEVICE 16777232 :INODE 1557189331 :MTIME 1792782988 :SHA256
   "10f360ae8f4ccc1300529ccf0df413d50ae8898862d1aa9c0c5cdfcf0c44c68f")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/lint/conservazione.lisp"
   :BYTES 1089 :DEVICE 16777232 :INODE 1557189333 :MTIME 1792782988 :SHA256
   "c15a22a200ae37bf197b91ecc0a60bf41fc2d277a1f0cb2ede86a8011c9036aa")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/lint/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1557189334 :MTIME 1792782988 :SHA256
   "5b5947ad8763dc3856fe5175d1532c1b41074e0c2abfb26068da004e1120c012")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/lint/report.lisp.gz"
   :BYTES 92371 :DEVICE 16777232 :INODE 1557189335 :MTIME 1792782988 :SHA256
   "3c268f761ba193d9b725e3db7a313a14fee85f5acd546c1d18a77a2bbe15dc6b")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/trace/conservazione.lisp"
   :BYTES 1091 :DEVICE 16777232 :INODE 1557189337 :MTIME 1792782988 :SHA256
   "2867d4de03d8dbefcd2adb3dd453b009d74ebedcb5a26a329f8594058186435d")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/trace/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1557189338 :MTIME 1792782988 :SHA256
   "dc36c1704819cb32c43018704f357d66745a495ff454a90ce585b438e39fd9aa")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/commands/trace/report.lisp.gz"
   :BYTES 92394 :DEVICE 16777232 :INODE 1557189339 :MTIME 1792782988 :SHA256
   "92abe6d1f6cb55e4ca9381dc1ec19de0e0ce0e03bbffdc298bf3507f15972efa")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1557189340 :MTIME 1792782988 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1557189341 :MTIME 1792782988 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/job-driver.stdout"
   :BYTES 375 :DEVICE 16777232 :INODE 1557189342 :MTIME 1792782988 :SHA256
   "27d329aa2b5da8fdbd59356700dc421b55d25a03f3f2a98f84f322905fafe458")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/links-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1557189343 :MTIME 1792782988 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/links-driver.stdout"
   :BYTES 321 :DEVICE 16777232 :INODE 1557189344 :MTIME 1792782988 :SHA256
   "473d063d880b5fbe905c35948a1cee69fa19d53a37943caf158b2d8171520450")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/links.lisp"
   :BYTES 181 :DEVICE 16777232 :INODE 1557189345 :MTIME 1792782988 :SHA256
   "4a65c4599e78e1a334f1df767f8be44c2706651dc0c84d84c584fb412d71dd71")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/lint-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1557189346 :MTIME 1792782988 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/lint-driver.stdout"
   :BYTES 314 :DEVICE 16777232 :INODE 1557189347 :MTIME 1792782988 :SHA256
   "5abd0a7a2858c9217c4fd9dc395d78e9aa57d076e4c165c55f75b350905a7dcd")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/lint.lisp"
   :BYTES 354 :DEVICE 16777232 :INODE 1557189348 :MTIME 1792782988 :SHA256
   "103da9fb065b5447dcc76d63f7cff1252731f1b92be3b4e3b348f9a9b56110c8")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/trace-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1557189349 :MTIME 1792782988 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/trace-driver.stdout"
   :BYTES 319 :DEVICE 16777232 :INODE 1557189350 :MTIME 1792782988 :SHA256
   "5fb6eb9b4f1eb94286c4f1f10acb61333145aab2bca8b4b1642e2fdff4220678")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/raw/trace.lisp"
   :BYTES 1607 :DEVICE 16777232 :INODE 1557189351 :MTIME 1792782988 :SHA256
   "e676d3064ee656b1210e5359ad618671d701acdbecb50900c9c13d1dbb70cdc1")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/audit/f43490919ffd76ed4243ca97c1252d4bbdaf2937663d4bbe6a52f725e8c4284c/result.lisp"
   :BYTES 8711 :DEVICE 16777232 :INODE 1557189352 :MTIME 1792782988 :SHA256
   "fd21c531067cb536498bd5d2a20f2a85f57add9ad4aee856934eeec967d49c8c")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/manifest.lisp"
   :BYTES 7851 :DEVICE 16777232 :INODE 1557189355 :MTIME 1792782988 :SHA256
   "0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/child-result.lisp"
   :BYTES 25143 :DEVICE 16777232 :INODE 1557189357 :MTIME 1792782988 :SHA256
   "a75e482780203c38db9f3ff7f18ac178e83898af968fb05ce92199365c10823f")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/commands/job/conservazione.lisp"
   :BYTES 1087 :DEVICE 16777232 :INODE 1557189360 :MTIME 1792782988 :SHA256
   "a6e96b43de5d7c58518b3154f13cb595fc1ce340b4253be771fa982d8762cc0e")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1557189361 :MTIME 1792782988 :SHA256
   "e2ad742e0dd809f785d21709d219defc84a5fc951728b4149088b52111345760")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/commands/job/report.lisp.gz"
   :BYTES 92391 :DEVICE 16777232 :INODE 1557189362 :MTIME 1792782988 :SHA256
   "bc528217030a3671d1fda3484112ae1720b46e8463218505c98a19c359bbaa81")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/coordinator-identity.lisp"
   :BYTES 212 :DEVICE 16777232 :INODE 1557189363 :MTIME 1792782988 :SHA256
   "ad8563abf08ee11bca8e71dc63b552f1593e360577ee77a9335c68e723039a0b")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1557189364 :MTIME 1792782988 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1557189365 :MTIME 1792782988 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/job-driver.stdout"
   :BYTES 375 :DEVICE 16777232 :INODE 1557189366 :MTIME 1792782988 :SHA256
   "72df0cfd4e878951c4b07902da824af61350fb92bf6340b13e2cdd04b2fe9c46")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/measure-replica-01.lisp"
   :BYTES 2110 :DEVICE 16777232 :INODE 1557189367 :MTIME 1792782988 :SHA256
   "29bf38509b6817484c1732303bc2c7914bf28878e5edeec70774161f2e5f4ed9")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/measure-replica-01.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1557189368 :MTIME 1792782988 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/measure-replica-02.lisp"
   :BYTES 2119 :DEVICE 16777232 :INODE 1557189369 :MTIME 1792782988 :SHA256
   "901532d8f13c91d3169faae061add894a20a89c8c40c6687b83746cb6b065c16")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/measure-replica-02.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1557189370 :MTIME 1792782988 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/measure-replica-03.lisp"
   :BYTES 2110 :DEVICE 16777232 :INODE 1557189371 :MTIME 1792782988 :SHA256
   "9c7cef4f569a15702316c501c54d6b7c525d2ebf08ba7071bf84a13991b26cb7")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/measure-replica-03.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1557189372 :MTIME 1792782988 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/measure-replica-04.lisp"
   :BYTES 2111 :DEVICE 16777232 :INODE 1557189373 :MTIME 1792782988 :SHA256
   "e7ff358f0cf10f541e1e959c04fa1c1bc8a90b84fe201ef106bd9b580bc6bcde")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/measure-replica-04.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1557189374 :MTIME 1792782988 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/measure-replica-05.lisp"
   :BYTES 2111 :DEVICE 16777232 :INODE 1557189375 :MTIME 1792782988 :SHA256
   "8596c05728dae9f8093c07a6fe11d3f19446688486a01f22057bb01fb60e9470")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/measure-replica-05.log"
   :BYTES 415 :DEVICE 16777232 :INODE 1557189376 :MTIME 1792782988 :SHA256
   "60e2d25080433645a303517a3d2e2316415be0f2a045249e2723f4c5c4f6febc")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/raw/measure.lisp"
   :BYTES 25143 :DEVICE 16777232 :INODE 1557189377 :MTIME 1792782988 :SHA256
   "a75e482780203c38db9f3ff7f18ac178e83898af968fb05ce92199365c10823f")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/bench/0caa00b015b102f38541d53a7d9dbf264dd4b9996aa038e088a5f891bfb6df1f/result.lisp"
   :BYTES 18486 :DEVICE 16777232 :INODE 1557189378 :MTIME 1792782988 :SHA256
   "d334098b277b095b25cc79217ccd0e9ea111e7f36d24e53785100fc1d2245a7b")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/manifest.lisp"
   :BYTES 7080 :DEVICE 16777232 :INODE 1557189381 :MTIME 1792782988 :SHA256
   "e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/raw/child-result.lisp"
   :BYTES 140 :DEVICE 16777232 :INODE 1557189383 :MTIME 1792782988 :SHA256
   "22824bfedad9bffeaa12cb19cec7a38349d3ad8bef65180d8948318d468040c0")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/raw/commands/job/conservazione.lisp"
   :BYTES 1093 :DEVICE 16777232 :INODE 1557189386 :MTIME 1792782988 :SHA256
   "d6eba69a0c84a80cd9b8cf4bcc5d15cfbe22a70ce3a1f967fcd5621207868233")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/raw/commands/job/report.lisp"
   :BYTES 310 :DEVICE 16777232 :INODE 1557189387 :MTIME 1792782988 :SHA256
   "c14b9ce6f722bacd98e98b9a13be7a156e4091526b6a77217e1b49b6a6eb17d6")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/raw/commands/job/report.lisp.gz"
   :BYTES 92452 :DEVICE 16777232 :INODE 1557189388 :MTIME 1792782988 :SHA256
   "c49b66ae264f3f721e55aa9361d62e16e5e5d629c2853b53790d61c421abc58e")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/raw/coverage.expected.lisp"
   :BYTES 52816 :DEVICE 16777232 :INODE 1557189389 :MTIME 1792782988 :SHA256
   "5e87bf1bd219130f591b65b8fd2ca88bdd35f94f648a05a628335bfadce15e21")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/raw/coverage.stderr.log"
   :BYTES 320 :DEVICE 16777232 :INODE 1557189390 :MTIME 1792782988 :SHA256
   "26746920f49e1ebcf79209b06d5805622ab5341071e5dd3d77a90fc81336ae7a")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/raw/coverage.stderr.log.gz"
   :BYTES 136785 :DEVICE 16777232 :INODE 1557189391 :MTIME 1792782988 :SHA256
   "0bf70e45b704af1128131807462dff35cb316d7b1affa20f04423574b30053a7")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/raw/coverage.stdout.log"
   :BYTES 318 :DEVICE 16777232 :INODE 1557189392 :MTIME 1792782988 :SHA256
   "1484a73a104f4979d2e86610b0c51ab5d68a97ad1cff885318a87d9e6b003c04")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/raw/coverage.stdout.log.gz"
   :BYTES 14038 :DEVICE 16777232 :INODE 1557189393 :MTIME 1792782988 :SHA256
   "053ab9ce831b8b9e7336e45448f21046350a72c273248fd7d30c39793f5c21c4")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1557189394 :MTIME 1792782988 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1557189395 :MTIME 1792782988 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/raw/job-driver.stdout"
   :BYTES 388 :DEVICE 16777232 :INODE 1557189396 :MTIME 1792782988 :SHA256
   "b72e27915db22805d9571c1bdf77da739968f04ca2922c86b9f03dd8e695e17a")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/coverage/e5959a5598c7635edea87c94605adaa775e3f94b74c684a91bda325d72ddbf39/result.lisp"
   :BYTES 5586 :DEVICE 16777232 :INODE 1557189397 :MTIME 1792782988 :SHA256
   "d960771ef03f627faa5cf1a05c25e0cdf723aa87a71f75ae6345fd5e52f717dc")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/plan/181cf4768c32cc34bec63719b748e91636d9ead55d2d28e968e391873489d8e7/manifest.lisp"
   :BYTES 5345 :DEVICE 16777232 :INODE 1557189400 :MTIME 1792782988 :SHA256
   "181cf4768c32cc34bec63719b748e91636d9ead55d2d28e968e391873489d8e7")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/plan/181cf4768c32cc34bec63719b748e91636d9ead55d2d28e968e391873489d8e7/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1557189402 :MTIME 1792782988 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/plan/181cf4768c32cc34bec63719b748e91636d9ead55d2d28e968e391873489d8e7/raw/sources.lisp"
   :BYTES 4738 :DEVICE 16777232 :INODE 1557189403 :MTIME 1792782988 :SHA256
   "c36dbf7a5d81a61d8abfed6351e7e29ac89b3f006e05336c7d92743abfbff10f")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/plan/181cf4768c32cc34bec63719b748e91636d9ead55d2d28e968e391873489d8e7/result.lisp"
   :BYTES 9725 :DEVICE 16777232 :INODE 1557189404 :MTIME 1792782988 :SHA256
   "dc2c7bd477539f3e7c091e0210875b124becbd30432f20290296b3489701da70")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/manifest.lisp"
   :BYTES 7305 :DEVICE 16777232 :INODE 1557189407 :MTIME 1792782988 :SHA256
   "dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/raw/child-result.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1557189409 :MTIME 1792782988 :SHA256
   "ce638e25e66dd6592a1f643b192c21c65c756d11aa0a0eb9911ecd8c3223a2a6")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/raw/child-result.lisp.gz"
   :BYTES 53659 :DEVICE 16777232 :INODE 1557189410 :MTIME 1792782988 :SHA256
   "52fff44ebedcbee92b1429423b904be9c95db29a33ad1db2e43e70e1e4c33a6e")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/raw/commands/job/conservazione.lisp"
   :BYTES 1101 :DEVICE 16777232 :INODE 1557189413 :MTIME 1792782988 :SHA256
   "1044eb04d42fea880ab99eb391392befad2b8514d6ce755f1e2d80fe8bb4794e")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/raw/commands/job/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1557189414 :MTIME 1792782988 :SHA256
   "9144826f2f722693f7120d3ee61c08e05a9ba62af5ecb2fa841d15fcf2c3d491")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/raw/commands/job/report.lisp.gz"
   :BYTES 133530 :DEVICE 16777232 :INODE 1557189415 :MTIME 1792782988 :SHA256
   "8ba35d0e2a56949771ca6bad508930687ab8b50a23a152db0ce5d4cd69ff72d2")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/raw/installation.lisp"
   :BYTES 467 :DEVICE 16777232 :INODE 1557189416 :MTIME 1792782988 :SHA256
   "ef41d17220343dbfb5b3be875742e4ced45543735491e9949bd9d1f938539049")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1557189417 :MTIME 1792782988 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/raw/job-driver.stdout"
   :BYTES 400 :DEVICE 16777232 :INODE 1557189418 :MTIME 1792782988 :SHA256
   "b966d90ade86ad1494cb2e302724246a7500e9da5f5a011ce5a0d2c7874ca195")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/raw/tests.events.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1557189419 :MTIME 1792782988 :SHA256
   "9aee70e28e9922dcaaf31ca8b2f78ac37a9da23496e4b86c023fc44a24285d81")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/raw/tests.events.lisp.gz"
   :BYTES 111499 :DEVICE 16777232 :INODE 1557189420 :MTIME 1792782988 :SHA256
   "7fa4b7b861247a4debf0c6bf2f26dc5357fa3066ccff0e6098a7b1c8314af243")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/raw/tests.expected.lisp"
   :BYTES 8542 :DEVICE 16777232 :INODE 1557189421 :MTIME 1792782988 :SHA256
   "2e84d47c2500716e2fd25335ecef35af7058561a3bc2ee1bdca0c0acf112c812")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/raw/tests.lisp"
   :BYTES 309 :DEVICE 16777232 :INODE 1557189422 :MTIME 1792782988 :SHA256
   "5c7f49f8f480ca15f0ab62f14e6583bfe2e9974da3dc28a787c1a7b56aba15d5")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/raw/tests.lisp.gz"
   :BYTES 53659 :DEVICE 16777232 :INODE 1557189423 :MTIME 1792782988 :SHA256
   "52fff44ebedcbee92b1429423b904be9c95db29a33ad1db2e43e70e1e4c33a6e")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-linux/dec3a4283edebe782ba0b63ede5de8ff9c6746c9fabc3cb7306fc7d1fc626ba1/result.lisp"
   :BYTES 5575 :DEVICE 16777232 :INODE 1557189424 :MTIME 1792782988 :SHA256
   "4e4261497b4578dbcee7fff0ff329055b8dc95f57b6d817000354d8167ccf985")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/manifest.lisp"
   :BYTES 7306 :DEVICE 16777232 :INODE 1557189427 :MTIME 1792782988 :SHA256
   "c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/raw/child-result.lisp"
   :BYTES 316 :DEVICE 16777232 :INODE 1557189429 :MTIME 1792782988 :SHA256
   "ab36985c720673108366d895d8945c08b15b153c6a32379170c86e3cb3545f71")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/raw/child-result.lisp.gz"
   :BYTES 59610 :DEVICE 16777232 :INODE 1557189430 :MTIME 1792782988 :SHA256
   "a06e5075f12c8b081a3440fa66f1999d4d9d63814ac848112b6ed4c570324bcb")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/raw/commands/job/conservazione.lisp"
   :BYTES 1106 :DEVICE 16777232 :INODE 1557189433 :MTIME 1792782988 :SHA256
   "059dacd974ecb8a63591489729d54a53eeb73ff976abc8e840a609caecb699f5")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/raw/commands/job/report.lisp"
   :BYTES 311 :DEVICE 16777232 :INODE 1557189434 :MTIME 1792782988 :SHA256
   "b3ee7f984eb41626b75ecc4c5fe96e1327ed1da5e2198b621ffc695436881b24")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/raw/commands/job/report.lisp.gz"
   :BYTES 134322 :DEVICE 16777232 :INODE 1557189435 :MTIME 1792782988 :SHA256
   "3f3b60cfe3805ad95d0ec461f6ffc17594248c54884655af770a59b033e9f4e7")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/raw/installation.lisp"
   :BYTES 593 :DEVICE 16777232 :INODE 1557189436 :MTIME 1792782988 :SHA256
   "141b86c124ba1c54c4b9aa8b3a794a383cd9c05688bc4ebdc47630c8fc08e065")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/raw/job-driver.stderr"
   :BYTES 0 :DEVICE 16777232 :INODE 1557189437 :MTIME 1792782988 :SHA256
   "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/raw/job-driver.stdout"
   :BYTES 404 :DEVICE 16777232 :INODE 1557189438 :MTIME 1792782988 :SHA256
   "0d06ff1003fecb6300c751dac01107f83762ce820dbac8a7eb721c182cfe9f00")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/raw/tests.events.lisp"
   :BYTES 318 :DEVICE 16777232 :INODE 1557189439 :MTIME 1792782988 :SHA256
   "b27f343cc5f388716d455345cadc08628cfa4a599ecc0758d2b496e1739a1037")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/raw/tests.events.lisp.gz"
   :BYTES 126507 :DEVICE 16777232 :INODE 1557189440 :MTIME 1792782988 :SHA256
   "434c41a6eb2d869030aa7681a5db33f53bd13f7bb2180c288cee168005d8011c")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/raw/tests.expected.lisp"
   :BYTES 8542 :DEVICE 16777232 :INODE 1557189441 :MTIME 1792782988 :SHA256
   "2e84d47c2500716e2fd25335ecef35af7058561a3bc2ee1bdca0c0acf112c812")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/raw/tests.lisp"
   :BYTES 309 :DEVICE 16777232 :INODE 1557189442 :MTIME 1792782988 :SHA256
   "d853b1e1c9c3ded98fefeeea1e9f0d2821b7c5df38e76d5970cd29de3e06d355")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/raw/tests.lisp.gz"
   :BYTES 59610 :DEVICE 16777232 :INODE 1557189443 :MTIME 1792782988 :SHA256
   "a06e5075f12c8b081a3440fa66f1999d4d9d63814ac848112b6ed4c570324bcb")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/payloads/verify-macos/c809f4765ee475aa70f11e472d68530e0dd67b78d944da1f7112eb5d1f475613/result.lisp"
   :BYTES 5579 :DEVICE 16777232 :INODE 1557189444 :MTIME 1792782988 :SHA256
   "01ab6b284652e426c7bb03c5b36269298874a1a896fd13bdc1d8a6e3275cc86f")
  (:PATH
   "spikes/results/ci/by-source/f83d7dbe1a3041fedbe479f7c7b1c4b1594f19923890a425e5964fa07662448a/runs/39998228176/1/publications/1d01c148f2bbf1571c3ea51fc268e7ab9ad9ea1bd6bdbcd814fbbc287b9d2092.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1557189446 :MTIME 1792782988 :SHA256
   "f9d080e4c640ac4e8a24b4b95fc1af198925eb32a8a6ad88105338c14fba0074")
  (:PATH
   "spikes/results/ci/by-source/fb77ca1e12c4c8fdd684ac59fc4b27586e00d2815c6bb9d821d3cdd53f64f8c8/runs/38611100884/1/collections/72f6665747ce00eb85b5a1c50596c2ef5cc071daeb0c61ea7706c9db0d9e2990/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114415 :MTIME 1793207956 :SHA256
   "1f007d47c6f931ce64aea851de3dfa158f75eadc32574cb6eef68d393ae82d8e")
  (:PATH
   "spikes/results/ci/by-source/fb77ca1e12c4c8fdd684ac59fc4b27586e00d2815c6bb9d821d3cdd53f64f8c8/runs/38611100884/1/collections/72f6665747ce00eb85b5a1c50596c2ef5cc071daeb0c61ea7706c9db0d9e2990/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114416 :MTIME 1793207956 :SHA256
   "ded9e40746303e594189964a1e38c0cdb20717d35ba68a82160fda6cd3f13342")
  (:PATH
   "spikes/results/ci/by-source/fb77ca1e12c4c8fdd684ac59fc4b27586e00d2815c6bb9d821d3cdd53f64f8c8/runs/38611100884/1/collections/72f6665747ce00eb85b5a1c50596c2ef5cc071daeb0c61ea7706c9db0d9e2990/summary.lisp"
   :BYTES 4761 :DEVICE 16777232 :INODE 1560114417 :MTIME 1793207956 :SHA256
   "9c79b0bf6574a123229d18499bf6d8363d471bcaf8bc736b28595e91fc8bcb67")
  (:PATH
   "spikes/results/ci/by-source/fb77ca1e12c4c8fdd684ac59fc4b27586e00d2815c6bb9d821d3cdd53f64f8c8/runs/38611100884/1/collections/f233e7492066432aa72b6af0d66e536d5be2e80f8a46895f977d14c879dba6cb/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114419 :MTIME 1793207956 :SHA256
   "60ea1e20ca212bd8912b3313ef2b8e4a002bd835104aa38311bbf4b2d8df1f28")
  (:PATH
   "spikes/results/ci/by-source/fb77ca1e12c4c8fdd684ac59fc4b27586e00d2815c6bb9d821d3cdd53f64f8c8/runs/38611100884/1/collections/f233e7492066432aa72b6af0d66e536d5be2e80f8a46895f977d14c879dba6cb/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114420 :MTIME 1793207956 :SHA256
   "ded9e40746303e594189964a1e38c0cdb20717d35ba68a82160fda6cd3f13342")
  (:PATH
   "spikes/results/ci/by-source/fb77ca1e12c4c8fdd684ac59fc4b27586e00d2815c6bb9d821d3cdd53f64f8c8/runs/38611100884/1/collections/f233e7492066432aa72b6af0d66e536d5be2e80f8a46895f977d14c879dba6cb/summary.lisp"
   :BYTES 4755 :DEVICE 16777232 :INODE 1560114421 :MTIME 1793207956 :SHA256
   "30c5f577134858e2644ffb5f5adf6050958672d0daa204decd9dea5047b7f29b")
  (:PATH
   "spikes/results/ci/by-source/fb77ca1e12c4c8fdd684ac59fc4b27586e00d2815c6bb9d821d3cdd53f64f8c8/runs/38611100884/1/publications/0392545db04c0f02830954ffe9ecd05ac77a1961c1908d982022749aa1fc91b1.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114423 :MTIME 1793207956 :SHA256
   "b141cf0a0ff7cb3df45ace0593b0288610ff3b1d7b4a087b0fcad26177aed3f0")
  (:PATH
   "spikes/results/ci/by-source/fb77ca1e12c4c8fdd684ac59fc4b27586e00d2815c6bb9d821d3cdd53f64f8c8/runs/38611100884/1/publications/61399dd7cadc75731857e5d98dd3b9d824a0c0ef28705d46965f3b04bd16baac.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114424 :MTIME 1793207956 :SHA256
   "27aa81b6191ee5167b73c8bb0e0b7856fddd857271d7451dfb6e3e5870759028")
  (:PATH
   "spikes/results/ci/by-source/fc04259f44f1675a4996489d32fefd48cdb2ebdf77ec0d9214cf2adb7cfba20d/runs/38928598956/1/collections/e8d33cb7dc92b891c274ff99f4261dbadd7d2131554167900e912073741fe6eb/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114431 :MTIME 1793207956 :SHA256
   "1314eae92db446acf4a1398b8f94513d74d7fa2cd426ec0515e75bad1abe7aaa")
  (:PATH
   "spikes/results/ci/by-source/fc04259f44f1675a4996489d32fefd48cdb2ebdf77ec0d9214cf2adb7cfba20d/runs/38928598956/1/collections/e8d33cb7dc92b891c274ff99f4261dbadd7d2131554167900e912073741fe6eb/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114432 :MTIME 1793207956 :SHA256
   "b01fb4a769314d3688c652aab91b44f9279ee70dd2330f7d3b81796727dcca8c")
  (:PATH
   "spikes/results/ci/by-source/fc04259f44f1675a4996489d32fefd48cdb2ebdf77ec0d9214cf2adb7cfba20d/runs/38928598956/1/collections/e8d33cb7dc92b891c274ff99f4261dbadd7d2131554167900e912073741fe6eb/summary.lisp"
   :BYTES 5275 :DEVICE 16777232 :INODE 1560114433 :MTIME 1793207956 :SHA256
   "2f19ecebd897de04295582a52a723ce589f3157324c49e406b6f2cfad6b4078c")
  (:PATH
   "spikes/results/ci/by-source/fc04259f44f1675a4996489d32fefd48cdb2ebdf77ec0d9214cf2adb7cfba20d/runs/38928598956/1/publications/1f288ffe549c64f1fc9e856a246a54da6cd417e3b1dd2201187ab6c3550e2041.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114435 :MTIME 1793207956 :SHA256
   "8c5747a8deefc1f386b9bfff2e9fdb94e38dd2c67bc17f129d3cc19ba4209b50")
  (:PATH
   "spikes/results/ci/by-source/febb5e916dc8d255e9be2afb0d4beed3f22d2cae81cf45f8e747c93f8b6c2ca5/runs/38466484500/1/collections/c8a907ae83330fe5fecdfeef295ecb58bbec75f8a1e68ff0ec489795302f8972/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114442 :MTIME 1793207956 :SHA256
   "e2ea1464fc8b71b32f5d5ac1eabc6274d67b9cc3cf1bc66ca9353affab09f315")
  (:PATH
   "spikes/results/ci/by-source/febb5e916dc8d255e9be2afb0d4beed3f22d2cae81cf45f8e747c93f8b6c2ca5/runs/38466484500/1/collections/c8a907ae83330fe5fecdfeef295ecb58bbec75f8a1e68ff0ec489795302f8972/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114443 :MTIME 1793207956 :SHA256
   "93c9de575ddefdf67c39a90948dee02e60fc31a1d9e9c78ba181ef9cdd3ce70c")
  (:PATH
   "spikes/results/ci/by-source/febb5e916dc8d255e9be2afb0d4beed3f22d2cae81cf45f8e747c93f8b6c2ca5/runs/38466484500/1/collections/c8a907ae83330fe5fecdfeef295ecb58bbec75f8a1e68ff0ec489795302f8972/summary.lisp"
   :BYTES 4663 :DEVICE 16777232 :INODE 1560114444 :MTIME 1793207956 :SHA256
   "181e55ff1d1a4e9694416e30a2f45f97545b48fad030fe37f9df5b9177b589ce")
  (:PATH
   "spikes/results/ci/by-source/febb5e916dc8d255e9be2afb0d4beed3f22d2cae81cf45f8e747c93f8b6c2ca5/runs/38466484500/1/collections/e44332b69cf0550394fbe2217a9ce7ccccb942545c5a9907ec9528c1a6b59488/manifest.lisp"
   :BYTES 390 :DEVICE 16777232 :INODE 1560114446 :MTIME 1793207956 :SHA256
   "13476641b2ec0c945947fef40cbe44e9ca72825fc3ddc941b1c751c26cd6caae")
  (:PATH
   "spikes/results/ci/by-source/febb5e916dc8d255e9be2afb0d4beed3f22d2cae81cf45f8e747c93f8b6c2ca5/runs/38466484500/1/collections/e44332b69cf0550394fbe2217a9ce7ccccb942545c5a9907ec9528c1a6b59488/report.md"
   :BYTES 571 :DEVICE 16777232 :INODE 1560114447 :MTIME 1793207956 :SHA256
   "93c9de575ddefdf67c39a90948dee02e60fc31a1d9e9c78ba181ef9cdd3ce70c")
  (:PATH
   "spikes/results/ci/by-source/febb5e916dc8d255e9be2afb0d4beed3f22d2cae81cf45f8e747c93f8b6c2ca5/runs/38466484500/1/collections/e44332b69cf0550394fbe2217a9ce7ccccb942545c5a9907ec9528c1a6b59488/summary.lisp"
   :BYTES 4657 :DEVICE 16777232 :INODE 1560114448 :MTIME 1793207956 :SHA256
   "2b259a36a90c29b80355a613198f5ed3fd53e5af649cd9600b3a141f58579399")
  (:PATH
   "spikes/results/ci/by-source/febb5e916dc8d255e9be2afb0d4beed3f22d2cae81cf45f8e747c93f8b6c2ca5/runs/38466484500/1/publications/506d78eb4abe3d74721fb4d72e27ecb271f0eecf85728efca211efdb0da4c95e.lisp"
   :BYTES 705 :DEVICE 16777232 :INODE 1560114450 :MTIME 1793207956 :SHA256
   "59d9155f3c417d7233cc123a7cb0340278f0462bea805a926f6d5560ebf8f366")
  (:PATH
   "spikes/results/ci/by-source/febb5e916dc8d255e9be2afb0d4beed3f22d2cae81cf45f8e747c93f8b6c2ca5/runs/38466484500/1/publications/71615f772f2102cd669cc4030fdd4fc6d154b7d5c51a5b297a4097986bc63119.lisp"
   :BYTES 702 :DEVICE 16777232 :INODE 1560114451 :MTIME 1793207956 :SHA256
   "94d08a4ec7b6fcfd260dde7319d3768c9d13a526d6ba3439d7fe280512f4c93f")
  (:PATH "spikes/results/ci/index.lisp" :BYTES 62667 :DEVICE 16777232 :INODE
   1560932717 :MTIME 1793305114 :SHA256
   "0508f1ac6f6a607f4f7cdc212ca9c15e6378148af37fe4149c424d616a141eb9")
  (:PATH "spikes/results/ci/reconciliation/runs/41011241762-1.lisp" :BYTES 6079
   :DEVICE 16777232 :INODE 1562783705 :MTIME 1793386388 :SHA256
   "194c324ed2b9d1cd5118a66680635f9050e49ee9bd4b25cc2739a43a8bf220ab")
  (:PATH "spikes/results/ci/reconciliation/runs/41060269999-1.lisp" :BYTES 6079
   :DEVICE 16777232 :INODE 1562783706 :MTIME 1793386388 :SHA256
   "08836ae6ab25da469ebc795f0c764558bb7dc8e1386d5c3c5ba0508de8194d8d")
  (:PATH "spikes/results/ci/reconciliation/runs/41138175230-1.lisp" :BYTES 6609
   :DEVICE 16777232 :INODE 1563309278 :MTIME 1793444658 :SHA256
   "5dcf808cb471e995f4ad6564fba64ffea1a51142623e34e2b916f9dedab105bf")
  (:PATH "spikes/results/ci/reconciliation/runs/41174337582-1.lisp" :BYTES 3549
   :DEVICE 16777232 :INODE 1563309279 :MTIME 1793444658 :SHA256
   "29416a675171d84d12ac820ddb4a54589c0ff9498523982758446fff33f33c59")
  (:PATH "spikes/results/ci/reconciliation/runs/41202312513-1.lisp" :BYTES 3867
   :DEVICE 16777232 :INODE 1563762639 :MTIME 1793455796 :SHA256
   "34df5f7a9b5fd01f2f7d80f3e382bd687920f6aeeb95a210211fe0763a32bd26")
  (:PATH "spikes/results/ci/reconciliation/state.lisp" :BYTES 3867 :DEVICE
   16777232 :INODE 1563762640 :MTIME 1793455796 :SHA256
   "34df5f7a9b5fd01f2f7d80f3e382bd687920f6aeeb95a210211fe0763a32bd26")))
