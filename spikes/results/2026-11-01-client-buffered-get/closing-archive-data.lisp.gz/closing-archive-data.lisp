(:KIND :BUFFERED-TAIL-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "buffered-close" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "buffered-final-archive" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "buffered-identity-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE))
 :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-close/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-close/conservazione.lisp"
   :SHA256 "82ba62ec928bd2ea5c433a84575cd092976129e725b4abe0ed20e379522174c7"
   :BYTES 1160)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-close/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-close/report.lisp"
   :SHA256 "e1ad83e5260b2c3944741c54847a3d265da3fb7026ae377dcbcef59696158c7b"
   :BYTES 363556)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-final-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-final-archive/conservazione.lisp"
   :SHA256 "93d907c214785e6a4056283c4178ce3b7ae1a074ce86c23746a034c84e5f02f1"
   :BYTES 1176)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-final-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-final-archive/report.lisp"
   :SHA256 "268e1c4caefa1001c0c6b546dc4e74189206c142bd7b0be9d9f14eb5dbb76a1c"
   :BYTES 362874)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-identity-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-identity-final/conservazione.lisp"
   :SHA256 "e51da409197b950326b9f4fb6565084f7bcc1a47b94b6e3f9abaa453083abd29"
   :BYTES 1178)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-identity-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-identity-final/report.lisp"
   :SHA256 "38247bebeb34cc30438440cd11591be591cf23f6ac9f98c90015a74432880399"
   :BYTES 362859))
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-identity-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362859 :STORED-BYTES 116462 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362859 :UNCOMPRESSED-SHA256
    "38247bebeb34cc30438440cd11591be591cf23f6ac9f98c90015a74432880399"
    :COMPRESSED-BYTES 116146 :COMPRESSED-SHA256
    "e0bf2ad9b22fe295459743e179d1703a113b5211648cefd5fe3aa9cdf13a66ab"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-final-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362874 :STORED-BYTES 116452 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362874 :UNCOMPRESSED-SHA256
    "268e1c4caefa1001c0c6b546dc4e74189206c142bd7b0be9d9f14eb5dbb76a1c"
    :COMPRESSED-BYTES 116136 :COMPRESSED-SHA256
    "73c8df268f71b705734570442fcab8df98f7337f13ac65a3ef0705aa70129344"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-close/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363556 :STORED-BYTES 116845 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363556 :UNCOMPRESSED-SHA256
    "e1ad83e5260b2c3944741c54847a3d265da3fb7026ae377dcbcef59696158c7b"
    :COMPRESSED-BYTES 116529 :COMPRESSED-SHA256
    "c5ff0bda6805e1b5f9583c9db85e9486f2ac1ec433c2b67958f6e4e722988f8f")))
 :DRIVER-SHA256
 "ed624c7dc0b43a4b23034653e5aa1e7c0e074291ddb437c0d74d7a1668b738ce")
