(:KIND :BUFFERED-EVIDENCE-CLOSURE :STATUS :PASSED :UNIVERSAL-TIME 4002550056
 :VERIFIED-FILES 619 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/source-identity.lisp"
   :STATUS :OK :ORIGINAL-BYTES 182041 :STORED-BYTES 58636 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "source-identity.lisp.gz" :UNCOMPRESSED-BYTES 182041 :UNCOMPRESSED-SHA256
    "c1e551a8692cdc96179678838f11acbd52254962bd4b654eb7b8e5b4dc8aac10"
    :COMPRESSED-BYTES 58312 :COMPRESSED-SHA256
    "d690e30671476b338168b6be51848ef34a77a2e438a6bcbefc65c2daf6175956"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21824 :STORED-BYTES 4253 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "paired-repeat-analysis.lisp.gz" :UNCOMPRESSED-BYTES 21824
    :UNCOMPRESSED-SHA256
    "05e36f59e66f86a63b109d467e8f061d7bbcd54da562b5d8cf6d3750e00090ec"
    :COMPRESSED-BYTES 3923 :COMPRESSED-SHA256
    "53d50336b84aa281a24fa5ba3427f7d43536896e4abeb526eaf709ef846d8c5b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21803 :STORED-BYTES 4199 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "paired-final-analysis.lisp.gz" :UNCOMPRESSED-BYTES 21803
    :UNCOMPRESSED-SHA256
    "237e5c220af5ee8779566ae3fafb0691b39e433c5e0c5babde2a90fcec86ea20"
    :COMPRESSED-BYTES 3871 :COMPRESSED-SHA256
    "cbb3f55be240304eb88a0e1c7990587a9c217b09d692f295995b58655ae82ef3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/final-archive.lisp"
   :STATUS :OK :ORIGINAL-BYTES 211655 :STORED-BYTES 20625 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-archive.lisp.gz" :UNCOMPRESSED-BYTES 211655 :UNCOMPRESSED-SHA256
    "92ad0082b00c2ca894e4a008ff81458ef0433d1bf50fe3e50a4b69c952ad1423"
    :COMPRESSED-BYTES 20303 :COMPRESSED-SHA256
    "7536c4ff28b4b6c8af0465b0123ac301822d89b68e77be273a4b3b41dc3008c8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/comparison-into.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20820 :STORED-BYTES 4235 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "comparison-into.lisp.gz" :UNCOMPRESSED-BYTES 20820 :UNCOMPRESSED-SHA256
    "13708296d82d3d2be2fb80ad0caa83ea6d5770a838793967ab2913b1b55712ea"
    :COMPRESSED-BYTES 3913 :COMPRESSED-SHA256
    "f6d60456c234409d1557fe02b3b42270bacfe3744f0101b892ed4389090e66fe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/comparison-copy-control.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20783 :STORED-BYTES 4181 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "comparison-copy-control.lisp.gz" :UNCOMPRESSED-BYTES 20783
    :UNCOMPRESSED-SHA256
    "46108cf7d7137a1190cc68b08ea79bf27a2de9872afcb5225bd733bf5453fdfe"
    :COMPRESSED-BYTES 3850 :COMPRESSED-SHA256
    "182e4b4257f6177cb37ea9731be0c0a8e13b96b872b38ab5fe59a88096882bbe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9824 :STORED-BYTES 2315 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-final-analysis.lisp.gz" :UNCOMPRESSED-BYTES 9824
    :UNCOMPRESSED-SHA256
    "99ca7f71b78fcdef1ec867ca20b6d882f7e550651081c20858c7bc02c1ee0c03"
    :COMPRESSED-BYTES 1985 :COMPRESSED-SHA256
    "f885988d72dee6c3c022ec383ffdf56772ad4b69092cb10e5945af3ecdf023e5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9895 :STORED-BYTES 2308 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-analysis.lisp.gz" :UNCOMPRESSED-BYTES 9895 :UNCOMPRESSED-SHA256
    "9721ade797bf893e72b3d1251ee61b4a5947e741248ff302fdba2f642d27c5f2"
    :COMPRESSED-BYTES 1985 :COMPRESSED-SHA256
    "18bb2eaa2d8e9633f67f7da0c05fec493d3e1d60e2c6c3cd0bc564b4b22b8079"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/allocation/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10276 :STORED-BYTES 1310 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 10276 :UNCOMPRESSED-SHA256
    "5821227e5e0f89904363e49f8bfa57d22ac5cae263bc336a8b9579ba27418127"
    :COMPRESSED-BYTES 995 :COMPRESSED-SHA256
    "92e12548ddabfae9ce9f260c7b31501cd7ec04b577a8f63c1e1e43a7988f3d47"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6569 :STORED-BYTES 1303 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6569 :UNCOMPRESSED-SHA256
    "47c01a994949a9224f00674338cebbf30b6f796c39fda57f089ad94a279c052e"
    :COMPRESSED-BYTES 989 :COMPRESSED-SHA256
    "bffa88ea663a345ae8bf917230a0dea694ef0903eefa9a9168933e56b3e3844b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6322 :STORED-BYTES 1164 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6322 :UNCOMPRESSED-SHA256
    "510183f032869ac029b29f4419cdb1496682627dd714544c24cef147520f5062"
    :COMPRESSED-BYTES 847 :COMPRESSED-SHA256
    "d4e6ddc8d952f1e531823881cfd739b068dc65ee98144435366393c36745a67d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16713 :STORED-BYTES 6305 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 16713 :UNCOMPRESSED-SHA256
    "95ea1faf792efc8ffe379153968c530cfc5bb2a645820e94f72f0f3d491780cc"
    :COMPRESSED-BYTES 5995 :COMPRESSED-SHA256
    "146e3e5398508dc6a91969612ed3078656bcbf7ec50c9302e7796fddc842e38e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16734 :STORED-BYTES 6238 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 16734 :UNCOMPRESSED-SHA256
    "07a5f340a05197608871247f0e44b90409a81751628e22e334129285fc5571e8"
    :COMPRESSED-BYTES 5928 :COMPRESSED-SHA256
    "c3d4a7f0f7e96ff8beb99834b989d2ee836c9682ea3e94c4e78874d0d43ca226"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16726 :STORED-BYTES 6017 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 16726 :UNCOMPRESSED-SHA256
    "6122a62e16e05170e316d1cb4046ff7a6ab8b0164869e57c30f1b4cb193fa1cd"
    :COMPRESSED-BYTES 5707 :COMPRESSED-SHA256
    "e2649cceac1e424238bae5a5266965618c1e0a0efc7d67c530d935befa52e945"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16750 :STORED-BYTES 5601 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 16750 :UNCOMPRESSED-SHA256
    "89c26abebc72df8a4971456e703bd5c29f5118198abf022b6045fadf4e282bb3"
    :COMPRESSED-BYTES 5291 :COMPRESSED-SHA256
    "6af94802b435ef9c9f70e32d8d6a022bac41ba24725bb6c7861359aa74a4703e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16735 :STORED-BYTES 6106 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 16735 :UNCOMPRESSED-SHA256
    "013b9781d5fd055a5c8aacf41dd7a6352f899fc96a60f8c5866feda3388e812a"
    :COMPRESSED-BYTES 5796 :COMPRESSED-SHA256
    "517931b9655311603df1d1abe1d4db1168f5399c5c125fc617f5a6ea42ad8d9d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/6-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12827 :STORED-BYTES 4535 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4.lisp.gz" :UNCOMPRESSED-BYTES 12827 :UNCOMPRESSED-SHA256
    "1b8fa7d03ad8f0775f84bf1179a3864b072fba455a70426b80965c87e28b3588"
    :COMPRESSED-BYTES 4225 :COMPRESSED-SHA256
    "b518d9a453e80e6d5755c19dbe950df8a5b86398c5c2b60a41f22f0a43f19ea1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/6-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12948 :STORED-BYTES 4750 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3.lisp.gz" :UNCOMPRESSED-BYTES 12948 :UNCOMPRESSED-SHA256
    "dd27133c504abcbb504d3651fc5dde5af353716dcc40558f46b6968af794458b"
    :COMPRESSED-BYTES 4440 :COMPRESSED-SHA256
    "7c3ff504f2e1bb2521a417b72b96d4bcb21cdf5833321b1a5bf8b4fe08014b66"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/6-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13095 :STORED-BYTES 4996 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2.lisp.gz" :UNCOMPRESSED-BYTES 13095 :UNCOMPRESSED-SHA256
    "c609160bd67362f4a662e64985253bac4be43f7c613bf5ceb0015d89556b6882"
    :COMPRESSED-BYTES 4686 :COMPRESSED-SHA256
    "5974801d8a2520da0b9f9a8ca8efd7a08b27e95253811f9d614ee1d2bd526b86"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/6-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13076 :STORED-BYTES 4971 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1.lisp.gz" :UNCOMPRESSED-BYTES 13076 :UNCOMPRESSED-SHA256
    "6668d1295f75a6264fa1869d5229106728300fb0364b2fc3bc788e2124f13bc5"
    :COMPRESSED-BYTES 4661 :COMPRESSED-SHA256
    "094cda5a0f81b10281fc25f6e0208f0326986aede9cdd7b6ab211f342d042d57"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/6-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13261 :STORED-BYTES 5252 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0.lisp.gz" :UNCOMPRESSED-BYTES 13261 :UNCOMPRESSED-SHA256
    "98b3ff0d9afed13c7cbd43f9c96b8b44b6fea9a41f410ef27a16cf8745a3686b"
    :COMPRESSED-BYTES 4942 :COMPRESSED-SHA256
    "d478c7d961905babfbf35f3a7d4706766940cb54f1e8389797dbde5a10fc20f4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16732 :STORED-BYTES 6485 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 16732 :UNCOMPRESSED-SHA256
    "b50985785b9d204c933ceebfdee63110534422c561212eaed8cb37a96d2a0fd8"
    :COMPRESSED-BYTES 6175 :COMPRESSED-SHA256
    "6c25b3621c44b44a49b3f012a5cb4b6cc59fdb730a9cee16cac4517d3584774f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16701 :STORED-BYTES 6775 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 16701 :UNCOMPRESSED-SHA256
    "7395d93204db70a068c85bb259a5e3ffa12f62a4e521757a92c37c47e984798a"
    :COMPRESSED-BYTES 6465 :COMPRESSED-SHA256
    "969d8479be502059133d47a8b323e3ad5b92a5d6e13597ff5d3a892678b9b2c4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16778 :STORED-BYTES 6899 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 16778 :UNCOMPRESSED-SHA256
    "95a42d01f205dd04515cd09dcd4452b6e3de5f5d0e0656dcf300bf2e7e7120e2"
    :COMPRESSED-BYTES 6589 :COMPRESSED-SHA256
    "42704b659d26740087c8425198f97739a8049b0e62a4d633ea11cd83d20e6342"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16731 :STORED-BYTES 6984 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 16731 :UNCOMPRESSED-SHA256
    "6cbcea3a9efc7db372de3c37bc04f2ca6d9ca5a37f1b07fe1b7dcf67a2c9c595"
    :COMPRESSED-BYTES 6674 :COMPRESSED-SHA256
    "b0f3e57b309885222e616d1e04a9004b1fca94329c896c365c96e6e4a1e51991"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16724 :STORED-BYTES 6560 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 16724 :UNCOMPRESSED-SHA256
    "553fa316adcfab1ba4526ada3badc7e40ae921f752f34e4f718e4b106c7f8bb6"
    :COMPRESSED-BYTES 6250 :COMPRESSED-SHA256
    "9a803c9d56896acd805abe8037937121a455c920086be3f6893b3be1fc8165f6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13000 :STORED-BYTES 4914 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 13000 :UNCOMPRESSED-SHA256
    "c56e6289c3040dfa1f325f49fedfca5324773ee22e5f51550638514c7156695d"
    :COMPRESSED-BYTES 4604 :COMPRESSED-SHA256
    "bd1bb641a269e3e31cdbf70e6f19d96d6e99d6bc87edc7dc80dd2ea6202502a6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13171 :STORED-BYTES 5241 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 13171 :UNCOMPRESSED-SHA256
    "02150e30fc424b4d661ba5fff390fd3dd24adbf52a055e9bd0f1276ff942ece7"
    :COMPRESSED-BYTES 4931 :COMPRESSED-SHA256
    "6c69ad60fb740467edf41367531d18b1a3c5a864d4f8d9682c6e3eda50868e33"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13065 :STORED-BYTES 5025 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 13065 :UNCOMPRESSED-SHA256
    "253a445f26e7a19d946cc30543deb53b620733002c56efff67c7419a14eedb0e"
    :COMPRESSED-BYTES 4715 :COMPRESSED-SHA256
    "06f628e5692db3296610c2bbb9d165ab65168010c83040992753eb062c222c18"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13051 :STORED-BYTES 5037 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 13051 :UNCOMPRESSED-SHA256
    "9244b19127b3426872a788aa80790486886d55b86db58db56e9acf88104d86a8"
    :COMPRESSED-BYTES 4727 :COMPRESSED-SHA256
    "e70507d2a48e6c6b1422865830f1d1b806ffea517d43aa816801158bbfd11248"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline-final/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13276 :STORED-BYTES 5220 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 13276 :UNCOMPRESSED-SHA256
    "3696519c969f771778971bd2c5766869d792ee405da866a397c2f2795645221d"
    :COMPRESSED-BYTES 4910 :COMPRESSED-SHA256
    "dede8cdfde96a8b22ad80a929493c9d42e042f1f83c91c0bc78eeaaa7029fc36"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6450 :STORED-BYTES 1295 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6450 :UNCOMPRESSED-SHA256
    "998557fe48c86e7dc5dbe9acd298a4a64805087f9ed807de49352fd345af1ccd"
    :COMPRESSED-BYTES 981 :COMPRESSED-SHA256
    "0074de31fa4f70e5951e0d7fa256f176ec9c9f32085cfa59818be26c2539f7a9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6210 :STORED-BYTES 1158 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6210 :UNCOMPRESSED-SHA256
    "5ed6286633a471e04dfa578ebf9e32bacc03cf479f97016d0fe10348b3934bf4"
    :COMPRESSED-BYTES 841 :COMPRESSED-SHA256
    "a8ae0bc9a73c4d75bf5e3e072a53cf78e3620fd32295dcc16d227258969c45bb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/driver-variant/bench.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11391 :STORED-BYTES 3742 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "bench.lisp.gz" :UNCOMPRESSED-BYTES 11391 :UNCOMPRESSED-SHA256
    "d6955effccb2e57bc34825a26c68e1df7f24205c60cbea945e5c315ea6e59cd6"
    :COMPRESSED-BYTES 3430 :COMPRESSED-SHA256
    "0131c882c9de345fb069645a30455e0ca17ff3d61f9d4a45c67d056bfa280bea"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18670 :STORED-BYTES 7942 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 18670 :UNCOMPRESSED-SHA256
    "aa8d3883725901efa1bbc9c8968c2f799d998b4003717b02cf79df745e93de4d"
    :COMPRESSED-BYTES 7632 :COMPRESSED-SHA256
    "4625a74aff94740ff009434f402f886461580e1e5847f0e71ac50ddf3249577f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 19284 :STORED-BYTES 8266 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 19284 :UNCOMPRESSED-SHA256
    "909ec6af3c3c4cb7f99ac599b20dd89af842249eb4df461f3727aed27b2cd32b"
    :COMPRESSED-BYTES 7956 :COMPRESSED-SHA256
    "b156ad14fa5889ad9536030248d25b6788a25902ef0efb54fca118e29b5b427b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18708 :STORED-BYTES 7800 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 18708 :UNCOMPRESSED-SHA256
    "767964af3a2b64a2644a434d78dfaf14cf511afbe10c45b7ac1a933b73ecad98"
    :COMPRESSED-BYTES 7490 :COMPRESSED-SHA256
    "1dbeb10c58fdaa83508415ece784d73490bbbe6893eeee35bb00bc22dcd3c0da"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18717 :STORED-BYTES 8012 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 18717 :UNCOMPRESSED-SHA256
    "5d33911210bb6ca37031c3c39ed4f27d1f4602bbf96f8f86c2c852c8f08356df"
    :COMPRESSED-BYTES 7702 :COMPRESSED-SHA256
    "09cf8e8305c074f80247d5661cd4a2e8f695d0555fb65f029c9e31ec23161549"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18990 :STORED-BYTES 8386 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 18990 :UNCOMPRESSED-SHA256
    "a4c18887a8adfbbdcb5fe171163c73fd5ebbec178744c8c9f8a144362efa8918"
    :COMPRESSED-BYTES 8076 :COMPRESSED-SHA256
    "ad8eb8352f27d0c7b3b563f67670109bdbdff0f70e3cc8c7883e5652c3d03c16"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/6-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13398 :STORED-BYTES 5375 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4.lisp.gz" :UNCOMPRESSED-BYTES 13398 :UNCOMPRESSED-SHA256
    "cf083bda7ab896330a47089c5c457350323bf9406180fe8929d64c84690972a3"
    :COMPRESSED-BYTES 5065 :COMPRESSED-SHA256
    "a0ac120ce5477533a6941ceaf8633ae50b68473d3e0215344e645a2a60954b2f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/6-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13263 :STORED-BYTES 5174 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3.lisp.gz" :UNCOMPRESSED-BYTES 13263 :UNCOMPRESSED-SHA256
    "367bcbaeedfca51c4886e2216d25d6a218a65278d0592877bac0d8802bd74ac5"
    :COMPRESSED-BYTES 4864 :COMPRESSED-SHA256
    "060b8f4f427acf08b4a08b19a4491053db2c5ea06aba1187e1bfa9f6c0886199"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/6-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13086 :STORED-BYTES 5040 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2.lisp.gz" :UNCOMPRESSED-BYTES 13086 :UNCOMPRESSED-SHA256
    "ab66fab31376a59f287da41c42853212b20cb193326bace4c74cb9dfcccbb9ad"
    :COMPRESSED-BYTES 4730 :COMPRESSED-SHA256
    "7a7b186fc7834bfc482aedfec92cc3afdb82f923c2d572de309f2147d2d49488"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/6-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13351 :STORED-BYTES 5304 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1.lisp.gz" :UNCOMPRESSED-BYTES 13351 :UNCOMPRESSED-SHA256
    "1ea7decf9d9dd4c16985d9792fa9ff01b9bd54da5ec28cc46c271b4f767b97d3"
    :COMPRESSED-BYTES 4994 :COMPRESSED-SHA256
    "441eeef122a520d658f2b9a6b3e81348e6bfdd7f037b284b5f92c3a2aafaa067"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/6-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13283 :STORED-BYTES 5207 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0.lisp.gz" :UNCOMPRESSED-BYTES 13283 :UNCOMPRESSED-SHA256
    "6b1371427da0287277ceebccd9ec6acd28fdf1bb696d123a9ae2df98a63eef18"
    :COMPRESSED-BYTES 4897 :COMPRESSED-SHA256
    "d5d4a1c4c726d416210dbe7ef3b0bdd0866def6fa1913248643a55f20739e2a1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17557 :STORED-BYTES 7315 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 17557 :UNCOMPRESSED-SHA256
    "58b3cea7e6e98eb6c2d634acb70f56c33545db463bbb2560fc5c3664ee5ef8e0"
    :COMPRESSED-BYTES 7005 :COMPRESSED-SHA256
    "32991c813b98aaaa22748f0980f40227eb3fb3b20850683e143322a8e0f554c1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17602 :STORED-BYTES 7385 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 17602 :UNCOMPRESSED-SHA256
    "5317fa1dfcdf9405df5f7e2584f0ec3689e5f2a803ab162465bf83582108d8de"
    :COMPRESSED-BYTES 7075 :COMPRESSED-SHA256
    "fc49321c2ead499e22d0252dc25255ea4332a22947c8ee9c794899eaa25c7c9e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18718 :STORED-BYTES 7864 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 18718 :UNCOMPRESSED-SHA256
    "969c211b0a9d6606be189f7c223892600fab28280c7228680d8899c2a5167fec"
    :COMPRESSED-BYTES 7554 :COMPRESSED-SHA256
    "a6a1e8ec55ebd47340c0017ef1dc64cecaae2fe102a1fc15d97070d5a5153a1e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17714 :STORED-BYTES 7468 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 17714 :UNCOMPRESSED-SHA256
    "e85ff5800fff4ea48dd9ba00ad0e0e85711097d14350bea0f5d12637e8e76756"
    :COMPRESSED-BYTES 7158 :COMPRESSED-SHA256
    "0283f364619578f6904b55ba5538b2a976c6872026f6ee42fcb6fe2e7af5b6eb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17342 :STORED-BYTES 7162 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 17342 :UNCOMPRESSED-SHA256
    "1066bf09a3f6a21dceff051f99660b6a3c502f1f1516eb686592027b692a2450"
    :COMPRESSED-BYTES 6852 :COMPRESSED-SHA256
    "1dae234c037437f8016829e46cc54ae4f3fe5d7dc5942723d778e9b02fc26c74"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12894 :STORED-BYTES 4919 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 12894 :UNCOMPRESSED-SHA256
    "2de80d18fd6fdaf6220616935de89cdb73f79e62c49927ba899735a9ee87232b"
    :COMPRESSED-BYTES 4609 :COMPRESSED-SHA256
    "0bc8dc60a971e942e9ab98b1a2d486a2e09662465c55331d9af1cdced36f028c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12875 :STORED-BYTES 4914 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 12875 :UNCOMPRESSED-SHA256
    "a5157af2418ef85857e12017adbf33049a63f22f67608425654a89baa96df300"
    :COMPRESSED-BYTES 4604 :COMPRESSED-SHA256
    "fed78bb13deec83e45bad92dc66af143788be1b1e61a7bfc536fcdca6a325dd6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12959 :STORED-BYTES 5017 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 12959 :UNCOMPRESSED-SHA256
    "f199aea68dc29c850bbdd4d57dd609f94d5dc8a6a8ff403546f29e8406841e88"
    :COMPRESSED-BYTES 4707 :COMPRESSED-SHA256
    "19c28c625dc354f651f12da440581d94974ff41cd8ee92c07ad2134628e2ae0a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13024 :STORED-BYTES 5050 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 13024 :UNCOMPRESSED-SHA256
    "420ad4f6fa0fadda0192a7a54fe5a37f5b3615b4b8b835d2ad206fb142b5743f"
    :COMPRESSED-BYTES 4740 :COMPRESSED-SHA256
    "abeb45e489385af7759569f094a9f4a94808d846c041441d1308ce9a5d2b2419"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/baseline/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12980 :STORED-BYTES 5018 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 12980 :UNCOMPRESSED-SHA256
    "979187f60e6cbed5b2cd33d5c19093e23c2d8b03292523b0584d7eda66de89f8"
    :COMPRESSED-BYTES 4708 :COMPRESSED-SHA256
    "b354a3768413f79f6b8fe02cc5911d8ad63e94c64af0a7ca5571454d229d0ab0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/4002547425-command-18920-0/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363495 :STORED-BYTES 116637 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363495 :UNCOMPRESSED-SHA256
    "019cdb791a97a4fa452b86db7a35a629f88ae95c6392ead562219d2da763fc08"
    :COMPRESSED-BYTES 116321 :COMPRESSED-SHA256
    "bdc8de1feb7ddeeea5f644f1959cf3b5c7b15efe9db85ee72d79ae112fc4e02f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-allocation-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363068 :STORED-BYTES 116537 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363068 :UNCOMPRESSED-SHA256
    "831f67f17c4f4f90a39e09fddfe9d408e38b023ce5dc55cd3ed1b81a50b21bc0"
    :COMPRESSED-BYTES 116221 :COMPRESSED-SHA256
    "e9a54c60b40258f244b431a7f91c6c8ffcfcbf1cefbe7d278aff40f566dfcdba"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-allocation/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 367790 :STORED-BYTES 117221 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 367790 :UNCOMPRESSED-SHA256
    "e6f52d0dc2b2581f22f31544ca91c05e5249dd417cc4631dd488c92948ea3c2c"
    :COMPRESSED-BYTES 116905 :COMPRESSED-SHA256
    "45c293f76f08546ebe19c8e620990a11e570e61106ed9b1bfed2ca7a264dbf3c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-analysis-self-test-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 361636 :STORED-BYTES 116086 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 361636 :UNCOMPRESSED-SHA256
    "e85f1f3870ad043d02b47e5584fd252b91119cae947ac47fd44724fed340b5c8"
    :COMPRESSED-BYTES 115770 :COMPRESSED-SHA256
    "95e319461ef839ea52cb5d6b96a1f7e603aaa67ec6bbf0b5483ff2ca76f4ca88"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-analysis-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 361634 :STORED-BYTES 116085 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 361634 :UNCOMPRESSED-SHA256
    "c4e779829e32f238a7f8646c3fc1ae72facca0cc2b03058a7da30dac70caa8ea"
    :COMPRESSED-BYTES 115769 :COMPRESSED-SHA256
    "25db7f349051e4575fe47ac938fb662a7016c9f18168223405a73c5f288e0e56"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-archive-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362854 :STORED-BYTES 116463 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362854 :UNCOMPRESSED-SHA256
    "d2cb35e2027c33b7c2b39ae1a3509d94c61c3faa7acac0e645524b22a8f182c9"
    :COMPRESSED-BYTES 116147 :COMPRESSED-SHA256
    "6afa35800909eb9e53bb4450268cc24ca2520e025733bf894276ec2333c0f96d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-baseline-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362464 :STORED-BYTES 116358 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362464 :UNCOMPRESSED-SHA256
    "6d8d3d0942500bef5226143dc569ae3492747167840a9e3a1183161a7cfffe73"
    :COMPRESSED-BYTES 116042 :COMPRESSED-SHA256
    "84d9a76a0779c23cbd427067b5f16e78876867a627ea0821a86c91a7ddca8c89"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-baseline-final-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363682 :STORED-BYTES 116743 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363682 :UNCOMPRESSED-SHA256
    "d8a2ce8cd11b2c2142c701420e4ea245bde0069423c97f987a07b2a9e804854c"
    :COMPRESSED-BYTES 116427 :COMPRESSED-SHA256
    "689274fdcddfd805df62458a9dd8a34a1df6b26c139727e67a4a8416d3964808"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-baseline-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 371300 :STORED-BYTES 117063 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 371300 :UNCOMPRESSED-SHA256
    "d83f03c3306a3c7e2cd25075163b8e8eac7ee9c43d7931381a0054bebce07252"
    :COMPRESSED-BYTES 116747 :COMPRESSED-SHA256
    "c43ca42b73385b68c5547069d56eaaa83485164c3fec374f7dda4cc572e7aeda"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-baseline/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 371251 :STORED-BYTES 117053 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 371251 :UNCOMPRESSED-SHA256
    "b2657c6ce8d4b432966a69c9027ed7cca90cd51254fb7dad57add775bdf3da69"
    :COMPRESSED-BYTES 116737 :COMPRESSED-SHA256
    "c8b00ecda3adc674672c11d412aa6e4c9b2c8e36c89c0f3b4b5c7a4c127feec1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-byte-check-cost/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 361845 :STORED-BYTES 116121 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 361845 :UNCOMPRESSED-SHA256
    "8f17b989c409c395f54e7faec12ff75ffca94722696602bd11482492f066eb69"
    :COMPRESSED-BYTES 115805 :COMPRESSED-SHA256
    "5bd6543210f4fb2a5b619fa0adfa9cbd9ae93c703f297f4261211203118d4d6f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-checks/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 435714 :STORED-BYTES 128648 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 435714 :UNCOMPRESSED-SHA256
    "1db866e2771265eb5839650455f725fd245711b54bad86d6eb5408a43b9503dd"
    :COMPRESSED-BYTES 128332 :COMPRESSED-SHA256
    "8e0858c1ef96f0a3db24d172dea3abef248695ad210358808f7969e86726f766"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-cleanup-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362885 :STORED-BYTES 116492 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362885 :UNCOMPRESSED-SHA256
    "42cab80b414828725bf517ff5ac4d6f5779c68b68bfafc48f89b1a2573c70234"
    :COMPRESSED-BYTES 116176 :COMPRESSED-SHA256
    "ee6a60909c5465f5ca526deea6f9f56b28bbc3cbd18beebb20becc3fd505fb4d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-close-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362840 :STORED-BYTES 116448 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362840 :UNCOMPRESSED-SHA256
    "6825375dda9bb412e6ec6b92d299f24edc98c0203a51acd1fdccd38323f9aa51"
    :COMPRESSED-BYTES 116132 :COMPRESSED-SHA256
    "2524d9181fdb8393aba8faa357bb016f9da8cc224a1b27aa6e8367d1c257a1cf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-codec-cost/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363458 :STORED-BYTES 116586 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363458 :UNCOMPRESSED-SHA256
    "faad4b20ae50b1702fa8f3156900abd86c445164886eb0e19ba839f268b1a79c"
    :COMPRESSED-BYTES 116270 :COMPRESSED-SHA256
    "8ef89eabcddf44802a051e4a486f52cc73be1bdace4bb4cd39455f5a3aae6df2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-comparison-cost/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 361939 :STORED-BYTES 116144 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 361939 :UNCOMPRESSED-SHA256
    "71bacd4de9d88575a446201fb66a083fe974fce3d67e0c786ed2c6a9d2bb304b"
    :COMPRESSED-BYTES 115828 :COMPRESSED-SHA256
    "b73ceaada6b086e598a983659726990827f24dc75bcbe245a09ff1ca18965cec"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-copy-control-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363469 :STORED-BYTES 116637 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363469 :UNCOMPRESSED-SHA256
    "ddbf8958e2e9fd1b02c10d7be6bfde4ad5bde7fd0082f38a4be160093d61f846"
    :COMPRESSED-BYTES 116321 :COMPRESSED-SHA256
    "7cc40066d38ec73c093120d128c66e454a8b5165e88d1c00b618f01c650c9b91"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-copy-control/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372507 :STORED-BYTES 117436 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372507 :UNCOMPRESSED-SHA256
    "3b83a7d0fa79d1641557913beb659a94429a63a1f8af0e8028296682531c35dd"
    :COMPRESSED-BYTES 117120 :COMPRESSED-SHA256
    "f912fa45fdcb0884b5efc8f5873ee7ea1e1141a6493bbb75075eb328d6a67420"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-documentation/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 368951 :STORED-BYTES 117884 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 368951 :UNCOMPRESSED-SHA256
    "8231ccef997cc47f8521fa74a03196180dc07f9656d48fe5df99b60c04a04a45"
    :COMPRESSED-BYTES 117568 :COMPRESSED-SHA256
    "9546a95cbabfe106669d5f2c2784c481ef217e44d2e184c1884bced7ecc49920"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-focused-01/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 361910 :STORED-BYTES 116174 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 361910 :UNCOMPRESSED-SHA256
    "85248836e923a6bc47eab7fafbed90bb4d1784c4336b9d1b57e3f80113f22098"
    :COMPRESSED-BYTES 115858 :COMPRESSED-SHA256
    "8e2667e562cfc5e07344c27585c6f35c89fa42dc2d471cd1e4b934178f1907c0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-focused-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 370075 :STORED-BYTES 118204 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 370075 :UNCOMPRESSED-SHA256
    "9f6847e90be5e7f1e423f701118bad5058adbb91aebd84e691e6544b976ce744"
    :COMPRESSED-BYTES 117888 :COMPRESSED-SHA256
    "b1497c728f2fdec1a018af742113d1f09aad8bfaf2745fad9f93bd154a09e429"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-focused-03/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362665 :STORED-BYTES 116376 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362665 :UNCOMPRESSED-SHA256
    "5e077af3fba2f8bd09532abd3a91614f0dd54bee2dd06eafa4fd79a5270a5723"
    :COMPRESSED-BYTES 116060 :COMPRESSED-SHA256
    "c4bf09e7773981cbd442eb8f0fcbdbb6eb4a67d88dfed4b7469ca075a8e141f4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-identity-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362865 :STORED-BYTES 116472 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362865 :UNCOMPRESSED-SHA256
    "3b8136ca863755d4d6a9dcc4fde27cf588b1b98517c39d31bd95976476b90055"
    :COMPRESSED-BYTES 116156 :COMPRESSED-SHA256
    "149f5d33420aec4ce96aa23a2188433591f25e57cbf063c15cabcece72bb17fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-into-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363436 :STORED-BYTES 116622 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363436 :UNCOMPRESSED-SHA256
    "d69dd61739c0b4025769d8488d7bb34f3c6bc876d7ca45d8d32e839e646dc9fe"
    :COMPRESSED-BYTES 116306 :COMPRESSED-SHA256
    "8035cea4c8d9c700c46fc3ca13abbf0c7efbd57372cf8cd61577759aa7413c7e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-into/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372498 :STORED-BYTES 117434 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372498 :UNCOMPRESSED-SHA256
    "cdd27af364ffef350b4ae60dd634456d21158290520dad843abab9c2cf1e0ee1"
    :COMPRESSED-BYTES 117118 :COMPRESSED-SHA256
    "01ba55ea71fcfedc44baa6ba1ba6cb56936d127b2a6043336c0fbf6920b5446a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-paired-final-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363691 :STORED-BYTES 116720 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363691 :UNCOMPRESSED-SHA256
    "efe79f6b2376ee9dcd40db7a9251f8c32d72e231744cbbf35bf34685a782c460"
    :COMPRESSED-BYTES 116404 :COMPRESSED-SHA256
    "89dc0fb671e7d185db54999d564da5ab2a8125a06922b79f477cf826da409d07"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-paired-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372393 :STORED-BYTES 117408 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372393 :UNCOMPRESSED-SHA256
    "1134329cf0f82558b49e58cc43bb05f212380c4a4625f17cc211a6c8f79d1fa1"
    :COMPRESSED-BYTES 117092 :COMPRESSED-SHA256
    "d6356bb0702853010a56a63f7f5b8964e3d23f149e1e1712687b4a88dfe11d12"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-paired-repeat-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363692 :STORED-BYTES 116720 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363692 :UNCOMPRESSED-SHA256
    "007dd6c2778d39834b3ccc084e115357262e3c8b5cfcc77cfd9a1ac72c8ae35f"
    :COMPRESSED-BYTES 116404 :COMPRESSED-SHA256
    "ef94fdbf1e45473adf8aa65b050e724ace43fc92c8408f50e4c949710560b41f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-paired-repeat/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372393 :STORED-BYTES 117413 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372393 :UNCOMPRESSED-SHA256
    "b6cfc103408983b809bf3879872e3fd5f25bfbc4d80c379a9747c1a5499fcfd4"
    :COMPRESSED-BYTES 117097 :COMPRESSED-SHA256
    "e233198d7a17f68b4e070606cebd82ae53c9290f9f5de7e4460817f96146a056"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-paired-smoke-analysis-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363066 :STORED-BYTES 116574 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363066 :UNCOMPRESSED-SHA256
    "bcb6b694db970772255ae156acaa3526abb5008f43efa2225f873eb97cf2edf7"
    :COMPRESSED-BYTES 116258 :COMPRESSED-SHA256
    "719ec601293ae0c79319bd6bac52874f1a4fe745abf52c71a4109c822cd89cc9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-paired-smoke-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 368568 :STORED-BYTES 117705 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 368568 :UNCOMPRESSED-SHA256
    "43ecc305a2038d00409022c07d8a5a8efbd15adac4ee55b44193fb421ee3c99c"
    :COMPRESSED-BYTES 117389 :COMPRESSED-SHA256
    "3269cb2387105b252b59b2053376b8d371bc364fbc6f40b4d7ceb015283ca2f0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-paired-smoke/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365471 :STORED-BYTES 117125 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365471 :UNCOMPRESSED-SHA256
    "799930ea88963156d14fa2612856e1939806094a12a85446bad54a39c85b076e"
    :COMPRESSED-BYTES 116809 :COMPRESSED-SHA256
    "ca16c5f079ccd6bf7447d5f6a4873db202af710624d34041be760e9f2165db85"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-process-01/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372581 :STORED-BYTES 117412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372581 :UNCOMPRESSED-SHA256
    "feaf56541c3e42e186dbd19faea5ae8de3478f56c05ac3c8e54807051e5ced31"
    :COMPRESSED-BYTES 117096 :COMPRESSED-SHA256
    "fdf744c2ef505d89fe78e19f395fd1c98d9b074864d95d2dc2d684e537e8ea67"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-qualification-2.6.10/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 599350 :STORED-BYTES 132822 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 599350 :UNCOMPRESSED-SHA256
    "bb5f2feb6c1844efddef5b7ace00986abe301e4031d6468bbd7ea7fec4192d3d"
    :COMPRESSED-BYTES 132506 :COMPRESSED-SHA256
    "41064425adb9fcc48086274ac5ab48dc1c5f03643fdc1a143b5c9cfc91a1e0cb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-qualification-2.6.9/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 599329 :STORED-BYTES 132797 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 599329 :UNCOMPRESSED-SHA256
    "f58a4034ff0a7e381982f6e4c1666ee95aaebae601421eb265c575096cc3124c"
    :COMPRESSED-BYTES 132481 :COMPRESSED-SHA256
    "e3fc85ff211058fee2c201996ba29374fc774c06ad83d034b69c1e63fe30aa35"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-smoke-01/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365111 :STORED-BYTES 117083 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365111 :UNCOMPRESSED-SHA256
    "7db45f8f090ca81bb0c9c88e4b3b37840900b77452c828575b4d854a801d986f"
    :COMPRESSED-BYTES 116767 :COMPRESSED-SHA256
    "e24453cd6ae2f2e8eab007ad8cfbfdbb8012463dc5da88d12e00c785ef6be1a0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-smoke-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364294 :STORED-BYTES 116772 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364294 :UNCOMPRESSED-SHA256
    "874909624542d6b70df272fc4ebb49a026bde4f96e80cf2cb9dd29e5ca63412d"
    :COMPRESSED-BYTES 116456 :COMPRESSED-SHA256
    "0e19104ada2cddb0e6a5ffbb5251e423458ac51a3154929767f025367e8336c0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-smoke-03/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364306 :STORED-BYTES 116778 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364306 :UNCOMPRESSED-SHA256
    "62e4b22e1fda297d4087ed24e2008a10951de660954b905ad363148d5e8bdfbe"
    :COMPRESSED-BYTES 116462 :COMPRESSED-SHA256
    "fea21a797c122e31958300edfe7f91e398e3d008f0c582e39b9c0650e85defaa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6535 :STORED-BYTES 1302 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6535 :UNCOMPRESSED-SHA256
    "5e71d5f6baf6799f08deb3b45576349b0a0dca5b984847687165ccccdf3f9600"
    :COMPRESSED-BYTES 988 :COMPRESSED-SHA256
    "9d7b8b46623d29f237d4a3dda492f665b46e617697420b89fca3dd2a1ee8a312"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6290 :STORED-BYTES 1169 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6290 :UNCOMPRESSED-SHA256
    "e16932211e5510c91bf8b06e76bf140ecf418bbf176086fc8296c53bf92c5db8"
    :COMPRESSED-BYTES 852 :COMPRESSED-SHA256
    "3ec3616972002ed9550030d27c97c77d3c58beec0ec6c9cd5b52be0ebf1d4b8f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18293 :STORED-BYTES 8544 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 18293 :UNCOMPRESSED-SHA256
    "3e3a8ffea7ff1cee44b8cc095b7b9c11b664829fc67c00c330c5c04998eb4c42"
    :COMPRESSED-BYTES 8234 :COMPRESSED-SHA256
    "e2abe8a1edaf4cf9275af5d10f22850599f9c971f44408979277c5e2e9bde99b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17705 :STORED-BYTES 8265 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 17705 :UNCOMPRESSED-SHA256
    "3037be534b58c2f8f8c89a1e8a12319c50afae9e5522ce108f2c8c7010a795d5"
    :COMPRESSED-BYTES 7955 :COMPRESSED-SHA256
    "c9f1b5354293f49702dddc4510a241d6d34a6ee29a090a30495357ff04fa2295"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17860 :STORED-BYTES 8291 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 17860 :UNCOMPRESSED-SHA256
    "5bb17bfd31757fa2271f8813d1bef076ded232254fe87d77ab7a7d44e0cb115c"
    :COMPRESSED-BYTES 7981 :COMPRESSED-SHA256
    "bac16d6e77c032b704b24c68cdd08d742fc0251ac5b2abb49edc758b8c50a8a2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18076 :STORED-BYTES 8530 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 18076 :UNCOMPRESSED-SHA256
    "cb3205b6577fd47fe35a641eca8fda10a203e6d28bf6abbc576f821c9af1fcaa"
    :COMPRESSED-BYTES 8220 :COMPRESSED-SHA256
    "6ae93c981ea0024d06955ac72e9e202c2bb2a4cd4a662eb1a0619530f1bf5a66"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17612 :STORED-BYTES 8318 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 17612 :UNCOMPRESSED-SHA256
    "f408d1eb9045b0ebdcd56df8a6e32c4af7bfb4cee3437a65212360a453dcd416"
    :COMPRESSED-BYTES 8008 :COMPRESSED-SHA256
    "5462f6c434b96c689a94315487174aa0bf29e2831fa18ee61eadbf76c86727d2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/6-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16900 :STORED-BYTES 7609 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4.lisp.gz" :UNCOMPRESSED-BYTES 16900 :UNCOMPRESSED-SHA256
    "90378d284199544e5feff07ae91dcda4edf407d3b7a54fa9fdfcc766427bf7c3"
    :COMPRESSED-BYTES 7299 :COMPRESSED-SHA256
    "a5eefa7fca3c14eb1777f57ed027d5e6242812dd311cbe5503ac0e7bace48d9e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/6-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14852 :STORED-BYTES 5819 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3.lisp.gz" :UNCOMPRESSED-BYTES 14852 :UNCOMPRESSED-SHA256
    "89c3508d5c7872aca1a8b1aa9e02c4d00a4f3d04ec21d875fcc18fec56812af2"
    :COMPRESSED-BYTES 5509 :COMPRESSED-SHA256
    "dda7eba06144b383351eca8f8757b028fef2acd11da0a694aec0044a5d8b676f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/6-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 15387 :STORED-BYTES 5928 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2.lisp.gz" :UNCOMPRESSED-BYTES 15387 :UNCOMPRESSED-SHA256
    "30df224807216548ebc8c91614acfe35f2bfd6bf18a41aec475299b03b187696"
    :COMPRESSED-BYTES 5618 :COMPRESSED-SHA256
    "08af43c91b07c912e6b2032a798d66b8d01668bf1195b1c0f888d547ebbde0c0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/6-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 15525 :STORED-BYTES 6659 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1.lisp.gz" :UNCOMPRESSED-BYTES 15525 :UNCOMPRESSED-SHA256
    "b5f2fe457edf02344c49e3753a0dad7d518d5c0d30c2597e1fc66790156ec71c"
    :COMPRESSED-BYTES 6349 :COMPRESSED-SHA256
    "72c0cab88696fbb03466988f279b040b88a3483bc16dc37dfdf1a6ba43d94018"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/6-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14859 :STORED-BYTES 5864 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0.lisp.gz" :UNCOMPRESSED-BYTES 14859 :UNCOMPRESSED-SHA256
    "c315d8d7b68271656a08dc581e65d051020e858a7612af894631101f8e660c46"
    :COMPRESSED-BYTES 5554 :COMPRESSED-SHA256
    "b12035edb81f27cb344b903f89c841ab8f4711512443463f7fe9f2a16964cbe7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17601 :STORED-BYTES 8352 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 17601 :UNCOMPRESSED-SHA256
    "97544e2e337b49ab97f1d51a436b84b0001fd3e31519c7bc7c4bfe79d5ca5104"
    :COMPRESSED-BYTES 8042 :COMPRESSED-SHA256
    "1917cfc02a3f980878a1fff1dc8054d5fa655997f0d7bfe9c983fd499152aa44"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16790 :STORED-BYTES 7163 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 16790 :UNCOMPRESSED-SHA256
    "a0a838ac30dcfa929491903dd2e82b436d3888b5d7db88312773a7b499be6492"
    :COMPRESSED-BYTES 6853 :COMPRESSED-SHA256
    "6cf8b85e55be039fe1c75a75973bc9828887289823ec4f0d4e40a3237f0beeee"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16849 :STORED-BYTES 7498 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 16849 :UNCOMPRESSED-SHA256
    "d689cfd6530988a15b327c60f0c5dccf111db2cc49312fc27063216c7448ac83"
    :COMPRESSED-BYTES 7188 :COMPRESSED-SHA256
    "441bde245e6ae748ad707a54b67232745d24f594607b25db2c70ccbb55a53a81"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16864 :STORED-BYTES 7280 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 16864 :UNCOMPRESSED-SHA256
    "69061350f11d432c920feb317c401a941f83d50c0d44dcc409da2f502d518e39"
    :COMPRESSED-BYTES 6970 :COMPRESSED-SHA256
    "cf4b7acbdf2ffc5c9591dfcc60b42d7f90efbed7cdf1a39dd7248da7c72919fc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16751 :STORED-BYTES 7081 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 16751 :UNCOMPRESSED-SHA256
    "7e3dd78fcd00c986b770ec41c852d08cfe63054bba38f5a9910ac4aa6cb2c79c"
    :COMPRESSED-BYTES 6771 :COMPRESSED-SHA256
    "029c5a445eac7acdbb9f9109ecb63d0c62c297cdcc5098c6e99b494b2ca9f517"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12726 :STORED-BYTES 4131 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 12726 :UNCOMPRESSED-SHA256
    "f2502761eac3d6a581c3dad6d37425fd8079966253eaf2c49fd2a55efda5c0a1"
    :COMPRESSED-BYTES 3821 :COMPRESSED-SHA256
    "4c14111f8a6716bdc9e70c166129328db68cad70f732fd51ad0ba25cd3d3e5df"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12724 :STORED-BYTES 3960 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 12724 :UNCOMPRESSED-SHA256
    "cbcb1691b01828806c87ce0b74c196750053829c74531242f9220f333490bc79"
    :COMPRESSED-BYTES 3650 :COMPRESSED-SHA256
    "4ce47a3a613487efaab886a80e0faad9f4330998f4bd15de6464b1ebdc1e4e8b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12734 :STORED-BYTES 4175 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 12734 :UNCOMPRESSED-SHA256
    "a4eed11da305fb144d37279af259c49171caed5d080784402d8eb49ff092c8fd"
    :COMPRESSED-BYTES 3865 :COMPRESSED-SHA256
    "6f19fc5bf71e60ad4d448cffa34bd84f63b0dd641700ef692b5cddfbb6985dea"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12718 :STORED-BYTES 4179 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 12718 :UNCOMPRESSED-SHA256
    "df8c8258a92e308cef18b29a68ade9a73cc856301100fc34a55ed94700c4bf61"
    :COMPRESSED-BYTES 3869 :COMPRESSED-SHA256
    "e73d9bd65c702c4721a6c15fb29b70779fbf98f4fcafbcfb92196a58399f6e78"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/copy-control/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12725 :STORED-BYTES 4253 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 12725 :UNCOMPRESSED-SHA256
    "af2f8c16517191dcae19c37dc35f877b2e3f2404ec300dcf0bf7e5434002cd0d"
    :COMPRESSED-BYTES 3943 :COMPRESSED-SHA256
    "415ad6909f2b2f3c79f0e21cadffb4133a446cbc52a823a3367832ac269238e2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/focused-02-variant/client-get-into.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10482 :STORED-BYTES 2486 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "client-get-into.lisp.gz" :UNCOMPRESSED-BYTES 10482 :UNCOMPRESSED-SHA256
    "52e126c39e6b28db7a022ff4fe44414271b02b1071473112af8df7c0815e5328"
    :COMPRESSED-BYTES 2164 :COMPRESSED-SHA256
    "55900e81f45c1027409e354ffe92d68ccc95cfb6c8cdc14e740d1f5a837eee01"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6398 :STORED-BYTES 1300 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6398 :UNCOMPRESSED-SHA256
    "754e2a4bf6fb2ce5a53b0fb7694a312f4689f0135f7a846d9f82e264ac3eed88"
    :COMPRESSED-BYTES 986 :COMPRESSED-SHA256
    "6739acf65dbae25c00e3d7a725f60838bbd30285eea4669b40cdf61da7469d7c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6162 :STORED-BYTES 1163 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6162 :UNCOMPRESSED-SHA256
    "25013c4ac9a64c6226bdd8bc2fac29195994f9ec99947cd22fcde71dedca6587"
    :COMPRESSED-BYTES 846 :COMPRESSED-SHA256
    "7b179d678071461445ddcf2ac92af473d5686554fa2f4ebfc43fc437b72fb70f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17693 :STORED-BYTES 7805 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 17693 :UNCOMPRESSED-SHA256
    "cb77b72ac8f2fa72c24d28359150c3edde18c3cb57e4644e0c8d75656bb835d1"
    :COMPRESSED-BYTES 7495 :COMPRESSED-SHA256
    "73db168b0c76694671c30eb2631e4607cc93e521ab4f1ebe61b0f42b8d9ee901"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16733 :STORED-BYTES 7407 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 16733 :UNCOMPRESSED-SHA256
    "78c8b1b089a7ea37ac4fff79047e66652ca7c8ad461aae0e4890990f599e9047"
    :COMPRESSED-BYTES 7097 :COMPRESSED-SHA256
    "028ea99931cb6a27220d3c76274b25d973e803a1cfa2ea002a5152a57e0ec869"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17326 :STORED-BYTES 8046 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 17326 :UNCOMPRESSED-SHA256
    "e5ed3889322cc6b31b828485b4812eaa75ad671c791592ace4b51b87976c0ec7"
    :COMPRESSED-BYTES 7736 :COMPRESSED-SHA256
    "1c62a091575eb8645746317678696904cb5ae63154ae106dc95c0400b1ba28a5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17543 :STORED-BYTES 8019 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 17543 :UNCOMPRESSED-SHA256
    "1eb59c7830fdeb53a17857a5207dd6921539ba3c5cfc99cc6f60040e28445e5e"
    :COMPRESSED-BYTES 7709 :COMPRESSED-SHA256
    "858aa0b8ec5cf2d827da6aaccd2d85be3b61c5fec0679d7ec687b867ac3f70cf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17141 :STORED-BYTES 7757 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 17141 :UNCOMPRESSED-SHA256
    "b84d385763c81989a6973408fd2b8d69b746ae9c9e69480ca67bab893b25afc0"
    :COMPRESSED-BYTES 7447 :COMPRESSED-SHA256
    "797e3b95c0146542f71a369a06b5bf636c6cc0566ed5b4630b4ed7927599174a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/6-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16496 :STORED-BYTES 6366 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4.lisp.gz" :UNCOMPRESSED-BYTES 16496 :UNCOMPRESSED-SHA256
    "aae6f4ed7e71fc9d0c47a47a38e2793d76a1e78f502586b88307c8772bdcde47"
    :COMPRESSED-BYTES 6056 :COMPRESSED-SHA256
    "cb27c72d31e7b35030737ef360d2f2afca16f7078d70773c8c29f10f3ba1aa47"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/6-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16204 :STORED-BYTES 6367 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3.lisp.gz" :UNCOMPRESSED-BYTES 16204 :UNCOMPRESSED-SHA256
    "56840bc72bd6d1e95083d764f88d3f301eab1695e6b26bbe67678efe6bf77e91"
    :COMPRESSED-BYTES 6057 :COMPRESSED-SHA256
    "0707f836fcd0e3ac22735c0b1972b335f33b45cadaa10a1390f4f3f8063d1fad"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/6-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16516 :STORED-BYTES 6338 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2.lisp.gz" :UNCOMPRESSED-BYTES 16516 :UNCOMPRESSED-SHA256
    "cbbced59a793980f5e64dd56d6f3df82a1f6f610ba20d48de679996a045f0fca"
    :COMPRESSED-BYTES 6028 :COMPRESSED-SHA256
    "6f34a3ab4ff8ad99d55bacee0c45571d3041ceb66fce57ccdaf06cd90404938e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/6-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16814 :STORED-BYTES 6827 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1.lisp.gz" :UNCOMPRESSED-BYTES 16814 :UNCOMPRESSED-SHA256
    "b6d93bcbfb63ec5c03b7d07a9a8a34fe63b02a6ee853cb59eda6fd5cf6e48456"
    :COMPRESSED-BYTES 6517 :COMPRESSED-SHA256
    "07704398f489a10d7d59d8e6f77e0fc667e9ec54cb9ac9a4a3db261d96a9d242"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/6-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 15871 :STORED-BYTES 6909 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0.lisp.gz" :UNCOMPRESSED-BYTES 15871 :UNCOMPRESSED-SHA256
    "9843513720831692bb0f30f111a883752a2296eb9b3cf6391c361061d72765b1"
    :COMPRESSED-BYTES 6599 :COMPRESSED-SHA256
    "4d02d4ee202e5bbf9cbc75493570889d3a8bddeff18f7620da4a412f7a4513d0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17330 :STORED-BYTES 7885 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 17330 :UNCOMPRESSED-SHA256
    "e464ad4cd03afb54eaabab18866fb07c9806cb2050632b4a2cba7be5c0a17dd8"
    :COMPRESSED-BYTES 7575 :COMPRESSED-SHA256
    "d71c47c1e24287913e35547395f5e9c65dca83d752cec006dc109fb41ee0614c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17555 :STORED-BYTES 8167 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 17555 :UNCOMPRESSED-SHA256
    "70cd6a8262d3190671bf56a6a912e2e625d5d318c59db5e9dfa692b8d8f606a7"
    :COMPRESSED-BYTES 7857 :COMPRESSED-SHA256
    "79d34be16f2b4cc9192fc0f983dac4474e3fd66cf24058229f056b08c00e71a2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18593 :STORED-BYTES 8854 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 18593 :UNCOMPRESSED-SHA256
    "c8d070d9da466bf26074df88f650458a719674c12af1705791fd63dea38b5369"
    :COMPRESSED-BYTES 8544 :COMPRESSED-SHA256
    "36068c07e89b4b40d584566151834c6401e0c76c93bdaf97fcf3477e84728946"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17374 :STORED-BYTES 8051 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 17374 :UNCOMPRESSED-SHA256
    "3d340b29f7537156fdd97bdf9f4e43f7748bdf654baeb09e75767cd274472cc5"
    :COMPRESSED-BYTES 7741 :COMPRESSED-SHA256
    "4e794382c57add0deb2809ba98221e230cc81880d6fb9bbddedcbf909e7cb83f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 18202 :STORED-BYTES 8567 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 18202 :UNCOMPRESSED-SHA256
    "b1ea9aba9e54a6190156767a966d43308fbe7173c12be952bea80487a1a358f8"
    :COMPRESSED-BYTES 8257 :COMPRESSED-SHA256
    "1d5413c17b889f6a3758874a3f9b14916844f69bc6a09ace2e3e412cc77fb264"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16055 :STORED-BYTES 6572 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 16055 :UNCOMPRESSED-SHA256
    "16c8d66c7cceab010040889acf5d5b23304e98baa071929c606960ee9a16dbb9"
    :COMPRESSED-BYTES 6262 :COMPRESSED-SHA256
    "0090876a7ed3d650faf97498b0851d24f7167dddb33d308e2e91ef4681d787f5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 15608 :STORED-BYTES 6171 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 15608 :UNCOMPRESSED-SHA256
    "070592e83fc0deb128ee87fa53489db7a33d82d34e695e2949b4901e97f3e55a"
    :COMPRESSED-BYTES 5861 :COMPRESSED-SHA256
    "e0c615fefe499c54b31a8a839dc8b5e26bcac735c3be7a208bdc26ca7e6df532"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16406 :STORED-BYTES 6973 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 16406 :UNCOMPRESSED-SHA256
    "c3fd6578769f4c03bcce3625d3d54c552a96d946098114d1701daa5470cf837e"
    :COMPRESSED-BYTES 6663 :COMPRESSED-SHA256
    "0694aba903a9256d51b97273bed355c4cf3dc0b886e5eb133f52cf2af8d5bee2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 15389 :STORED-BYTES 6612 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 15389 :UNCOMPRESSED-SHA256
    "c9e7bc678c73cf336e65ba61d6631650e454d23346e79cf28405f46eea0762f8"
    :COMPRESSED-BYTES 6302 :COMPRESSED-SHA256
    "fd236eb3adcec48f0ba87f48f5a7c44dcf2eeb10bcd4f6ef5f083d6c8f4eb6f4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/into/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14855 :STORED-BYTES 5697 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 14855 :UNCOMPRESSED-SHA256
    "c4b9ecb5f0944153df0facda537e65d97543c5400ca6711c6733781e864673dc"
    :COMPRESSED-BYTES 5387 :COMPRESSED-SHA256
    "e4a72d81e5eee0b1f5eb8d89a6171dd96b67297491cb501031bdd9b3bf3e6f81"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-analysis-01-variant/paired-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7040 :STORED-BYTES 2301 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "paired-analysis.lisp.gz" :UNCOMPRESSED-BYTES 7040 :UNCOMPRESSED-SHA256
    "fed13606a659f13198e66a1eb35baafaca4bf1e82895bd9e07b9c1cf0e506f29"
    :COMPRESSED-BYTES 1980 :COMPRESSED-SHA256
    "b4a224aed2087586743c1064fb6b251beb95a75c3a0697c03575a3dca9b8a71e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6485 :STORED-BYTES 1283 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6485 :UNCOMPRESSED-SHA256
    "83d52c48f2fa0f7676704299feab1eb651c5ca97c32b8ec70adf99421bfd2926"
    :COMPRESSED-BYTES 969 :COMPRESSED-SHA256
    "f3470761bd7faa1e0dfc7edaaa735aba114e72339c6583dce662b9e0e693c7f5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6274 :STORED-BYTES 1159 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6274 :UNCOMPRESSED-SHA256
    "3c3fa10dc4d9e4a784286c50a407872e886d4484442d637fb3334e965878fb62"
    :COMPRESSED-BYTES 842 :COMPRESSED-SHA256
    "eb23faef10a5fd75f6ba2ff6e2a6678268ff7ad6a85712e425d9e46100bf45e1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/8-4-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16712 :STORED-BYTES 4186 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16712 :UNCOMPRESSED-SHA256
    "daf916d3ed64116f784abee6ae7747b40bb57ea503b6ec55313775838dd9da4d"
    :COMPRESSED-BYTES 3871 :COMPRESSED-SHA256
    "bc6f4e68ac15e6e5d09b4b439d02c408ce4d88ee451e968e0f67c4907eadc28d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/8-4-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16754 :STORED-BYTES 4539 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16754 :UNCOMPRESSED-SHA256
    "a754c9f84e44e990e20d66c36948878a8a4c27d6c9baa661f282d33c3b4d960f"
    :COMPRESSED-BYTES 4224 :COMPRESSED-SHA256
    "b8e0222e84942169137ac923a1ceec672d790143203171c04e516e87d520165e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/8-3-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16712 :STORED-BYTES 3966 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16712 :UNCOMPRESSED-SHA256
    "f5d1ffc1a1e6ab446f719edaaafa0ec2225c7bf056760f591210fc76473fe4c5"
    :COMPRESSED-BYTES 3651 :COMPRESSED-SHA256
    "cbc44b06dbada515f8326f9ba7c7e48251a9b64a3d528bd2d6621310c6580556"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/8-3-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16751 :STORED-BYTES 4304 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16751 :UNCOMPRESSED-SHA256
    "54a2535f0bac674c27d31fcd59729dd6c4125cbe4b5b419ea071022c84f0b8c1"
    :COMPRESSED-BYTES 3989 :COMPRESSED-SHA256
    "f103861c495c40dca125f8378726f198b4d343e25d65ea59653df1f9d3623a13"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/8-2-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16712 :STORED-BYTES 3767 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16712 :UNCOMPRESSED-SHA256
    "fdb5ca888e4812cbea84de0fffa18593f99fb74c129a14735239d39a2342e422"
    :COMPRESSED-BYTES 3452 :COMPRESSED-SHA256
    "9ef014d041d3fbf9d98d7fb212933e2cc612ea20e81f6b0c8429dd951589e662"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/8-2-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16751 :STORED-BYTES 4503 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16751 :UNCOMPRESSED-SHA256
    "b0c66a190f94be467abfcaf1ac0e83181a732cd44cbb26fb38a4492a97cafda4"
    :COMPRESSED-BYTES 4188 :COMPRESSED-SHA256
    "8bb558aafaf608b1911e7f174ecda60c2b5c636b0132d3763584bcd03614fa0d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/8-1-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16698 :STORED-BYTES 5021 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16698 :UNCOMPRESSED-SHA256
    "5be676646afe10b13d93134066853827a7838a710a72156d827d9fae62f58569"
    :COMPRESSED-BYTES 4706 :COMPRESSED-SHA256
    "441b9fb9ae17f7f61f653c5cc0af416c642562d8b5b6608ec5fa52ff877aa467"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/8-1-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16753 :STORED-BYTES 4401 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16753 :UNCOMPRESSED-SHA256
    "321a796221b2250dd1afc374060a4bb8a284b1da24659f24098fc3a7bfcd60f4"
    :COMPRESSED-BYTES 4086 :COMPRESSED-SHA256
    "82fcfaf1423885c13ce5c0b0ac7464d8a79df90a64aa1b0d3c141ae57d392811"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/8-0-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16707 :STORED-BYTES 5151 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16707 :UNCOMPRESSED-SHA256
    "d79543e8832b31774a2785566218d83811df27076c7f29dd106d5bc82f5b953e"
    :COMPRESSED-BYTES 4836 :COMPRESSED-SHA256
    "8b580c595f96e05799c6a68ce62bf07408bc070b33787bb1ae8fe96531ca5315"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/8-0-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16745 :STORED-BYTES 5720 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16745 :UNCOMPRESSED-SHA256
    "de7bde8bd6f9e23435e5f8ea479c9e5f2d239548de151c52b0516ac01dcf2ae1"
    :COMPRESSED-BYTES 5405 :COMPRESSED-SHA256
    "2ec68372dbfd1d990ba459c7ae4182708c8055be4b17a0d76242e708194d733d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/6-4-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12716 :STORED-BYTES 3339 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12716 :UNCOMPRESSED-SHA256
    "78d977d74d5fb00f40b7659687f913a09f776ecec1842c401259743d8b575eed"
    :COMPRESSED-BYTES 3024 :COMPRESSED-SHA256
    "7e651de6c56d3ddfe50d53bfef3bc8a5a1f2901b20f97de3e51de12e3a5bef32"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/6-4-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12716 :STORED-BYTES 3801 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12716 :UNCOMPRESSED-SHA256
    "41b89cabc0b816bb551906ae14916add8abc7b36b7ec8e86da959a16592cdf1b"
    :COMPRESSED-BYTES 3486 :COMPRESSED-SHA256
    "c0eee8b381a39a0332deb5a09d66bea2fdbcb16d5df7bdf89d966a4d24c21fad"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/6-3-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12727 :STORED-BYTES 3518 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12727 :UNCOMPRESSED-SHA256
    "5b6ca715b6cd156ff67f1edac5186f8e6d711f7a61abb9ec0a0b825a335ea723"
    :COMPRESSED-BYTES 3203 :COMPRESSED-SHA256
    "512545c5e7a1c8320e67faf091ec64a5837dacae3ef046db671b5fdd8883140e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/6-3-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12709 :STORED-BYTES 3370 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12709 :UNCOMPRESSED-SHA256
    "c7718202a0835f2f61e0fe71f65d47a64253840731b11d20574da6441c1d0f24"
    :COMPRESSED-BYTES 3055 :COMPRESSED-SHA256
    "c25d601ba8fd66e822d05d63ef6df601f0219323baadb4e97d4b1d9f5ab2b9ae"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/6-2-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12717 :STORED-BYTES 3387 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12717 :UNCOMPRESSED-SHA256
    "63184cdb2e0dcf51ef2739df15bf0c32fb03771357f7d858accf4bcedec27e1e"
    :COMPRESSED-BYTES 3072 :COMPRESSED-SHA256
    "675652f03ceb1436eb50c5142cad0e57930c819e3248375ef773da3214281528"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/6-2-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12719 :STORED-BYTES 4555 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12719 :UNCOMPRESSED-SHA256
    "920016a42a8dd054f0b0f24683ee4b377d68e8e1c804aecd8b76fb3f8d988bd4"
    :COMPRESSED-BYTES 4240 :COMPRESSED-SHA256
    "40f447cbba3448cb9fcd3a41d721c9d84754c1b50fcf2633740920cc2e5b91b8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/6-1-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12709 :STORED-BYTES 3955 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12709 :UNCOMPRESSED-SHA256
    "5ffc0d07b8c443d5f20f621f11b559b6ae45879df6b8b9663f3afd92c98094e1"
    :COMPRESSED-BYTES 3640 :COMPRESSED-SHA256
    "35618ebab79a35d0f7271409264d5d4b150f33b9fc18ff7f6599257667b190ca"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/6-1-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12721 :STORED-BYTES 4282 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12721 :UNCOMPRESSED-SHA256
    "119bba4f7c66f7afcc2130d28d6590cc86b1287dc1fe073f1d3c5ae16373837a"
    :COMPRESSED-BYTES 3967 :COMPRESSED-SHA256
    "b04db7637d1968bfac04cb77712fa6995662b0c618edeaf18727e6b7756a0f41"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/6-0-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12714 :STORED-BYTES 3203 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12714 :UNCOMPRESSED-SHA256
    "be5f56b6025e5014b15b7a4d81d914dc90c109f381473c19d8aa9d838e6b27ec"
    :COMPRESSED-BYTES 2888 :COMPRESSED-SHA256
    "4317102353aa8d7001877fd4e6ee3669663d6564f74338fc8caea14c9c5e7a6d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/6-0-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12715 :STORED-BYTES 3451 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12715 :UNCOMPRESSED-SHA256
    "641d1424a8ce2e207464212b571c08119a42cccb9f6579ecc70c7d57bee4fbd0"
    :COMPRESSED-BYTES 3136 :COMPRESSED-SHA256
    "0eba177b408afff5b3063f1aea8405422d6ba52c8f93ee021a53a88b12a8b4c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/4-4-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 3566 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "be9deba9de6f299f7a1f8dd79eaa15fefcf68624658e1d91326270fc70e458a7"
    :COMPRESSED-BYTES 3251 :COMPRESSED-SHA256
    "e0ef1fb0338f4a98fe74ad7fab07415e8dd3f3a1a4834da21f9a36c26dcd35b9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/4-4-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16755 :STORED-BYTES 4412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16755 :UNCOMPRESSED-SHA256
    "3f5dfa0c00e4027b4215771986bbf5479bc1d4c275f142a8150e8f538f8ad062"
    :COMPRESSED-BYTES 4097 :COMPRESSED-SHA256
    "e50cceab85707b84b956ae1bc7a632be6f4a84eaff661c0cd49dd09edece5b4c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/4-3-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 3623 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "430382f81937e84b553a530643c7bfeecdbea41db4d9e4f922b937aa8575ddf9"
    :COMPRESSED-BYTES 3308 :COMPRESSED-SHA256
    "a0641290540521bfcb870ea1ac72d869102961841f05f692263870f7eb77e47b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/4-3-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16759 :STORED-BYTES 4600 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16759 :UNCOMPRESSED-SHA256
    "16733904b5c102832ce50eee04e280b042c356112c8f7a367a825404dd85ef29"
    :COMPRESSED-BYTES 4285 :COMPRESSED-SHA256
    "0904f8666a2e8fe48a3a5805c8fc7fcccd09116d9c681d46287239b61862a4bf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/4-2-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 3615 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "746ab4156e1bffdd48e407a9af58507fde69a92a5df9ea6839438dbf1f9717d9"
    :COMPRESSED-BYTES 3300 :COMPRESSED-SHA256
    "42941795eb4c576a11446bdec7e5775dd42f417ec161b6037d2bf7671cc2b50d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/4-2-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16757 :STORED-BYTES 4404 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16757 :UNCOMPRESSED-SHA256
    "350d75afa2a764e86b25203cf6430560d2f92e8c44055af91c9e2b39f51cbb68"
    :COMPRESSED-BYTES 4089 :COMPRESSED-SHA256
    "938f080e11ee3cc0f39c518b01b2a73cbcd22af41e8af0c76b828f372ce9aa51"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/4-1-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 4148 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "a4e8956698e6100db29c2f062e9eb21ce8260e6bde8c3c031ba670b61689b858"
    :COMPRESSED-BYTES 3833 :COMPRESSED-SHA256
    "d0a092f04aa0a04acaa5c214b82a761c7edc1d8d4abb29cab4603401343cdaa8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/4-1-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16764 :STORED-BYTES 4458 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16764 :UNCOMPRESSED-SHA256
    "f98b2f73b5f60fe5223275f843c9949c53d7cd3a1113e256fa82fd1d35314718"
    :COMPRESSED-BYTES 4143 :COMPRESSED-SHA256
    "71c7dab85a16edeaeed5cb71248fb5145d33b6840d530a003b9263442bdaf41e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/4-0-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 3618 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "89c8f39aa4b07cd46e5b52252fd4ad40441f5d535dc06e96fa3e9c4aa3b0c1d8"
    :COMPRESSED-BYTES 3303 :COMPRESSED-SHA256
    "7045011dca440f8d1c610340dbe14da1015946c0e858f5346a49d53026204056"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/4-0-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16759 :STORED-BYTES 4436 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16759 :UNCOMPRESSED-SHA256
    "db94063bc604bce2ffccbce2ab158d2f72c9e5174fe82e7f157cb94df8e4e061"
    :COMPRESSED-BYTES 4121 :COMPRESSED-SHA256
    "58b5d4c8676b6c2073d48f7de2d1faae4a4db7a8b0fb68c1f8bf89b009f77410"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/2-4-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12721 :STORED-BYTES 4436 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12721 :UNCOMPRESSED-SHA256
    "c176801d5e72fc281321b2053922323846bcba25480af0a20f311d7bff1151c7"
    :COMPRESSED-BYTES 4121 :COMPRESSED-SHA256
    "9ef89a7695a1c0df78828a04fc5100b6ff59f14d21a6ead0c687238e3227b39a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/2-4-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12716 :STORED-BYTES 4574 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12716 :UNCOMPRESSED-SHA256
    "ab833104f1162365fb45eee2cd88381048171f5b87aa03efe70e2d4a28c0a3e0"
    :COMPRESSED-BYTES 4259 :COMPRESSED-SHA256
    "5ef80a046a31ba5a2780431b675c9b23835cd0a8c84875ccafb4b36cacd25e7b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/2-3-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12717 :STORED-BYTES 4392 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12717 :UNCOMPRESSED-SHA256
    "7a173922861d13969489f82d49ea790f2c619c4d2f95282c792141274e2fbe20"
    :COMPRESSED-BYTES 4077 :COMPRESSED-SHA256
    "4ad20306f21be14d07fe288e94b38844d562e5c638e47a3a009c1100c841efa8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/2-3-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12725 :STORED-BYTES 4581 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12725 :UNCOMPRESSED-SHA256
    "7a63fdeb2b3dce48e5a687497b3a6254235960335957f977612b8bdd595d5f74"
    :COMPRESSED-BYTES 4266 :COMPRESSED-SHA256
    "686f69db7ed152c3a158c30b43a8dd2095c583e6005e719453356e723ebdb998"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/2-2-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12717 :STORED-BYTES 3704 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12717 :UNCOMPRESSED-SHA256
    "8adbd2fb3acc5ec88615e512398793185468a95b0b6c34b87bb6360aad06c3f2"
    :COMPRESSED-BYTES 3389 :COMPRESSED-SHA256
    "946a63b9d258cab2ded041cd9185b5548d464843fc32aebe3f1ef295eed15433"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/2-2-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12722 :STORED-BYTES 3951 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12722 :UNCOMPRESSED-SHA256
    "8bffaa0f8d1e72566156da6a20015b73db16564be20dbd9f2083827c0b123b81"
    :COMPRESSED-BYTES 3636 :COMPRESSED-SHA256
    "895f2e9cc9a260241a480d2ec4df522dc0422abbc35e8864d5aee7e07b653d7a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/2-1-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12719 :STORED-BYTES 3888 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12719 :UNCOMPRESSED-SHA256
    "31a2528ee06ab06727cc5d5a4f7abbfff30f3b83c36c84ef87fe15598f814ec8"
    :COMPRESSED-BYTES 3573 :COMPRESSED-SHA256
    "6fc5267165a3d99c78aedf5fc84486f0ddc6a51cf2fb3cec9daf59f0f51d8e92"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/2-1-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12719 :STORED-BYTES 4184 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12719 :UNCOMPRESSED-SHA256
    "c051165a5475c818f1e47abce1e591c321897781a4733d4193714ec4df0475bf"
    :COMPRESSED-BYTES 3869 :COMPRESSED-SHA256
    "9c4b8302db21534b2a3d843385edf69e4bb1d975c5ceee58b95201b7b59c5840"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/2-0-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12718 :STORED-BYTES 4057 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12718 :UNCOMPRESSED-SHA256
    "beb43cd731152bdac91409f043de5e49d16476cb6087e2ec4c38693e547a5b5d"
    :COMPRESSED-BYTES 3742 :COMPRESSED-SHA256
    "49afd203800cd5f1db3c77025d0697721a738fae16f9ddc07c132a46a5f5b4d9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-final/windows/2-0-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12720 :STORED-BYTES 3917 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12720 :UNCOMPRESSED-SHA256
    "ece6fbd5b68d93399cac71537b72e9478b237d5cee5d2145e9d3cf218e697fff"
    :COMPRESSED-BYTES 3602 :COMPRESSED-SHA256
    "f5207c5082971872f7fe38a253bb4bc8fbb9a2131b372a6665453c72d2092f65"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6502 :STORED-BYTES 1290 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6502 :UNCOMPRESSED-SHA256
    "10edc40d62a32141a7ce995ae30ff1c088287787d0c5bf9cd99924a2c9316c43"
    :COMPRESSED-BYTES 976 :COMPRESSED-SHA256
    "791560671a70fa35c55130d9afd58e30ef3ee9b1a95e35920e7322213cebc162"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6290 :STORED-BYTES 1166 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6290 :UNCOMPRESSED-SHA256
    "f687427fc16854593a3eb0167d09294037a7570bea5835f637d45a6caa35b7bb"
    :COMPRESSED-BYTES 849 :COMPRESSED-SHA256
    "5badc13627a788f8ac20fe38cd0a2e20f54f5e5e25fc61a3d292da55abd390b8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/8-4-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16712 :STORED-BYTES 4035 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16712 :UNCOMPRESSED-SHA256
    "cfbe598fa7b97b1005413d0c6dd0641ea1648cb13f24f8bf4fc6c524d01fc2e4"
    :COMPRESSED-BYTES 3720 :COMPRESSED-SHA256
    "a01188f4ec9840347c42c583eaa0c5729f40ea7ff54ff81331025f53795358af"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/8-4-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16752 :STORED-BYTES 4419 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16752 :UNCOMPRESSED-SHA256
    "66964b54d70b418299e2df2373281f0cde50840917af21fdde1e37f4d6ef1ce5"
    :COMPRESSED-BYTES 4104 :COMPRESSED-SHA256
    "2cbcd2b9e3e1a9022081657cdc0be1a1493e3b0a0350a02087a44877b76075c1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/8-3-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16712 :STORED-BYTES 3995 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16712 :UNCOMPRESSED-SHA256
    "62b3b12c4d34f88b4cd551eefb6c8c6ac1cc109a1995d03cbd6c87f8055cb74e"
    :COMPRESSED-BYTES 3680 :COMPRESSED-SHA256
    "a982bb6daa4004a0e914b5ccdc55b13d7a1c9df0a98c09b6664dfcac56a234bb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/8-3-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16751 :STORED-BYTES 4372 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16751 :UNCOMPRESSED-SHA256
    "57b8356b226fe6fabcf7856e02a4ab1f7bb6080de38a3715efb8bcc72f8067fd"
    :COMPRESSED-BYTES 4057 :COMPRESSED-SHA256
    "45f20a98662bd64374a649bab37f5d6e3470a8a86180f726e07bdf59b6c0f382"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/8-2-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16712 :STORED-BYTES 3996 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16712 :UNCOMPRESSED-SHA256
    "4aae104d37482e21d4889df0f64d57f904e6b3b0345543e93167abad74c1c23a"
    :COMPRESSED-BYTES 3681 :COMPRESSED-SHA256
    "dca32221ae79dbb68028e4fa85b633e8b0fb0e21b3a7f20c1b26cac7cceb6e8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/8-2-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16754 :STORED-BYTES 4332 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16754 :UNCOMPRESSED-SHA256
    "dcf0352447296986b32ed6931aa4943bf136e8cc6ab5383deb9437c33a537824"
    :COMPRESSED-BYTES 4017 :COMPRESSED-SHA256
    "60a60ed3d61143f30bd812df7232014202504fae60cd867da8c6c6603f87daef"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/8-1-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16711 :STORED-BYTES 3780 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16711 :UNCOMPRESSED-SHA256
    "eca00b4bcf25408c71556969f4db9b9a17f82e2890507828c8a5cb0995c11f3f"
    :COMPRESSED-BYTES 3465 :COMPRESSED-SHA256
    "02c16089cac032528364fb093e596ae25de61c908a9c7eacaeb811027dc858ea"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/8-1-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16751 :STORED-BYTES 4455 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16751 :UNCOMPRESSED-SHA256
    "5d88c530162460a8330a7c01505827f833571287b4a6d4436465c989e23ef638"
    :COMPRESSED-BYTES 4140 :COMPRESSED-SHA256
    "6c0223f46b9099669fc01908e42b18f126a83f3dbecc2a1d69529bf0ecb31d98"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/8-0-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16710 :STORED-BYTES 4264 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16710 :UNCOMPRESSED-SHA256
    "15d0c64a35da95687c6617e635f3024f37e2924d51e2e287a7423383e41cd97b"
    :COMPRESSED-BYTES 3949 :COMPRESSED-SHA256
    "07f577aa0ac5effd18f8dff98084d481e4a262b1ed524381dfc5b4ca693312ad"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/8-0-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16751 :STORED-BYTES 4153 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16751 :UNCOMPRESSED-SHA256
    "9f5ac92e64888cbbb4b35c485d7149ab8748f8cf5fbf1aaec3af519eba340f8d"
    :COMPRESSED-BYTES 3838 :COMPRESSED-SHA256
    "2161ac0804314bf30ebf3807ee775520baa3000c7209fedd2609fe6706d44f5a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/6-4-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12715 :STORED-BYTES 3306 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12715 :UNCOMPRESSED-SHA256
    "aa631713e53d4313c35af11c54cfe7fc0e788712345aebaa0bca185732976c88"
    :COMPRESSED-BYTES 2991 :COMPRESSED-SHA256
    "b92e0f62fdfb6fa599ad9b846aff194cc9b6e87b3e332aa58031c1ab8a63dfa2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/6-4-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12724 :STORED-BYTES 3902 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12724 :UNCOMPRESSED-SHA256
    "f4cc2e4a6f5a6a3ff2763c7e5d7ff239372e627020cb55f9d757e61956f1e188"
    :COMPRESSED-BYTES 3587 :COMPRESSED-SHA256
    "39ade6e3a2f490c5f6478081776e4a519e3e73b3b502d12d6f66baef52da6910"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/6-3-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12715 :STORED-BYTES 3553 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12715 :UNCOMPRESSED-SHA256
    "09eb574932fff8abcadce5d5a149eb3fdcf05e00de41c5c24198e5962e71be80"
    :COMPRESSED-BYTES 3238 :COMPRESSED-SHA256
    "575869f8ed55ee3d7e7df1665c4d6902b323f4637232fbd8e425271f039b2d1f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/6-3-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12715 :STORED-BYTES 3728 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12715 :UNCOMPRESSED-SHA256
    "48deddcdd677b60f08e2dffc08bb13e28e872e12487d96ef0c433f2190cc96af"
    :COMPRESSED-BYTES 3413 :COMPRESSED-SHA256
    "14c92e84886d977f2a58f74eddaf6dbb313a0b452c27b17dd13f852b7c3eea1d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/6-2-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12714 :STORED-BYTES 3355 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12714 :UNCOMPRESSED-SHA256
    "0df1a99de791e3dc8232d819368d532c101c3bca553bc5526395958ff473869a"
    :COMPRESSED-BYTES 3040 :COMPRESSED-SHA256
    "964ad900436618ae59f5ea0ca36041b22cab3562522fecbc480ebca5b38b8d71"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/6-2-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12717 :STORED-BYTES 3731 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12717 :UNCOMPRESSED-SHA256
    "fd06262687980b4372f8196d17d255ea8ae69040444394a66531ac8e083f55d4"
    :COMPRESSED-BYTES 3416 :COMPRESSED-SHA256
    "904494dfd3ebbe29c1a0cb45334fc2c25187ce10b2b33a13987d1516866e7462"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/6-1-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12715 :STORED-BYTES 3721 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12715 :UNCOMPRESSED-SHA256
    "da71c7f7ebf426831c824bad9ea6bb93a1c0207ca3530fb73c89a8f4a3500ac6"
    :COMPRESSED-BYTES 3406 :COMPRESSED-SHA256
    "63fc5e6c6f441e89c9d0e75ea138f6ba5cd39be8310c16b3025e60d46a4192d8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/6-1-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12716 :STORED-BYTES 3929 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12716 :UNCOMPRESSED-SHA256
    "286da9d52fe21f7df9ad2d1e5c436eafe208baa8898cefc831fa80710061b025"
    :COMPRESSED-BYTES 3614 :COMPRESSED-SHA256
    "a6849367aff24d72d220d964d740b80fd9a989ac88ca723cc0a0376c0d09327b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/6-0-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12718 :STORED-BYTES 3608 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12718 :UNCOMPRESSED-SHA256
    "968b291eb6676b49681c484c9cea6536233ea1618131851a9f3768551303103e"
    :COMPRESSED-BYTES 3293 :COMPRESSED-SHA256
    "ed5141db1373fc9fbdb679a2846147f8379776e817fc1813a5d342dc7b90c24a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/6-0-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12720 :STORED-BYTES 3910 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12720 :UNCOMPRESSED-SHA256
    "071e0907aac5a5202b69f038c15708b503fd34bcf98780713da1b64c01703faf"
    :COMPRESSED-BYTES 3595 :COMPRESSED-SHA256
    "46e89fa64e85182086f16fa6d6240e51ab9064c864adcc169e4bf12fb263874d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/4-4-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 4178 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "9708637d3c43a2ca574e94d66a3695547f9762c918e9da5bc3d0ba10d67d1736"
    :COMPRESSED-BYTES 3863 :COMPRESSED-SHA256
    "1318350914ab13210a8bbe7f6f5fbcf23d4b01fcb7b8649f8f934de0ac067838"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/4-4-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16754 :STORED-BYTES 4855 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16754 :UNCOMPRESSED-SHA256
    "c0762a31f439909778c66f9ee84ae03f303d0f95f9ca3340149e90bf0e642060"
    :COMPRESSED-BYTES 4540 :COMPRESSED-SHA256
    "82f143b3da7d447ab53adcc4fb89f502055371b60d4cfc6027f59d602d17a021"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/4-3-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 4135 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "7f3f2acbe398187dd64e7299eb17b7e11e702da57b95f0a4cc3e21772fe6f538"
    :COMPRESSED-BYTES 3820 :COMPRESSED-SHA256
    "e1506f7f742cb8d730e0be979b38b6aa967f71252250d36e909a128e9a98a029"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/4-3-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16756 :STORED-BYTES 4696 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16756 :UNCOMPRESSED-SHA256
    "4321ac6e0246c728de1f161c330c33459b7541e69af193917f6775f47799af82"
    :COMPRESSED-BYTES 4381 :COMPRESSED-SHA256
    "31c7b2d722c5ea8d69b38a3dcd157688fe69833893640e79fc4653c02260665f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/4-2-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16707 :STORED-BYTES 5531 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16707 :UNCOMPRESSED-SHA256
    "aa262ae15b0fbf2e65324e9baa890a1877dcac4aa3901dd20bad67677b46be13"
    :COMPRESSED-BYTES 5216 :COMPRESSED-SHA256
    "28c8eaa4eb10fd3b89a6b28146dfb590581cb3a5cf8bdfbea001c5d320cdb84b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/4-2-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16714 :STORED-BYTES 6338 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16714 :UNCOMPRESSED-SHA256
    "8b893b761c7c53996b11bed5c6e28830c4e2f758ae3cc00d7fa7470481cb3b29"
    :COMPRESSED-BYTES 6023 :COMPRESSED-SHA256
    "9c332f41528b8997a8663242fdfb1e2454e901fecea083093283897921c4b7d6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/4-1-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 4039 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "6fc7a18160a5a83582f58fd4b14747970ba0added381d8eccb18554a81e205bf"
    :COMPRESSED-BYTES 3724 :COMPRESSED-SHA256
    "c70a6656b75cb56875fecc4aabc4abe3968fb5bacd407680dc1172e90f5bc14b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/4-1-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16757 :STORED-BYTES 4276 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16757 :UNCOMPRESSED-SHA256
    "58354a630427f90ccc4012a33740b81e1215b9e35cf2a6a89b758199a6e01877"
    :COMPRESSED-BYTES 3961 :COMPRESSED-SHA256
    "11dce6666d633f67a957fc16b1062eb5a2910f10b7415efb5542eac73d49286a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/4-0-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 3766 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-INTO.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "dce82abdd280364fd9f391b061e649556408f8dfb4353ace7302ebd7d4108b81"
    :COMPRESSED-BYTES 3451 :COMPRESSED-SHA256
    "82a631a556a88a7440c3c1c183b6862177e3f00d58dcfb4164fecc6700c4df7d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/4-0-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16760 :STORED-BYTES 4340 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-COPY.lisp.gz" :UNCOMPRESSED-BYTES 16760 :UNCOMPRESSED-SHA256
    "8d54c466decf7bc57bd97a616f131da1e4d0590ac5862ae1fc769be397b302a1"
    :COMPRESSED-BYTES 4025 :COMPRESSED-SHA256
    "19c9baddf547564eb07d1dd9474f8441659a896943a38fd9ab379e5975b09f3e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/2-4-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12719 :STORED-BYTES 3639 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12719 :UNCOMPRESSED-SHA256
    "5c394d56407df3d9503383b4b3c58894375c5b5b569ffa70ee46d6634fc998c1"
    :COMPRESSED-BYTES 3324 :COMPRESSED-SHA256
    "49f828dfe24df22a3cdb1de87cac21282487cfc4a2f7f20b695e0209183fc47c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/2-4-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12720 :STORED-BYTES 4119 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12720 :UNCOMPRESSED-SHA256
    "3036e6f3491fca30e207da037304fee2a4abd2ad4142724c447d52a4ac536ab7"
    :COMPRESSED-BYTES 3804 :COMPRESSED-SHA256
    "28192be70e4bc940064f37d985bf12cc056ec01ab24286c2d466173789376ab8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/2-3-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12716 :STORED-BYTES 3790 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12716 :UNCOMPRESSED-SHA256
    "52b741861c6b39ebe9aa68f78005d24d5c50c9b0a86a33bd4396ff90f427ad0c"
    :COMPRESSED-BYTES 3475 :COMPRESSED-SHA256
    "141c6ae2357bfa4d5ff2310ed14c8532c2936da0ef6e83b759522c589bc70d55"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/2-3-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12721 :STORED-BYTES 3859 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12721 :UNCOMPRESSED-SHA256
    "4fa3d3f1ef67af83accc663d49405dfee991f2b56c6dbbb5fe72d99d873050fc"
    :COMPRESSED-BYTES 3544 :COMPRESSED-SHA256
    "f26ceff7a38289350e4c5bbf9136ddf1aa69ca2044286123b1077aef69c58fe7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/2-2-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12720 :STORED-BYTES 3607 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12720 :UNCOMPRESSED-SHA256
    "2811f4e7f8914b5ab844706c8d3a4141b821effd3aa06d9008db163473de7190"
    :COMPRESSED-BYTES 3292 :COMPRESSED-SHA256
    "53a113328176a88faecfc6aceaf997c7d0ec1e02882b19bce3cf0b2d5ee2604c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/2-2-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12720 :STORED-BYTES 3862 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12720 :UNCOMPRESSED-SHA256
    "20429086ef16591cfb08eeecdf44b10a469ac2413c6d4f2e90e28b783e846fde"
    :COMPRESSED-BYTES 3547 :COMPRESSED-SHA256
    "71bd5af0ca57d9ecc4ee66fce189460dc6117c66ff7bd8416c09ae8801c187fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/2-1-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12974 :STORED-BYTES 4667 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12974 :UNCOMPRESSED-SHA256
    "ba34001c27ebf67c0b65b887c23706bc6f41ff46c90c6a1d9b805eeb6f6e458b"
    :COMPRESSED-BYTES 4352 :COMPRESSED-SHA256
    "2d5aec46f356b3425d822e104f9be02828e3ae0fea9cc4a9cfb9c8a3fbb2be93"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/2-1-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12853 :STORED-BYTES 4461 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12853 :UNCOMPRESSED-SHA256
    "cf88894aa3c3ab68f5d5f2aaa7e424e5c386cc00f61e7f9b85a1353f211f71a0"
    :COMPRESSED-BYTES 4146 :COMPRESSED-SHA256
    "121b5e4f5c9863b86705ea85c06ad629276edc43721f18b797b6cf363fa22135"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/2-0-INTO.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12861 :STORED-BYTES 4745 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-INTO.lisp.gz" :UNCOMPRESSED-BYTES 12861 :UNCOMPRESSED-SHA256
    "b9d7c75bb23c00b5c5c240b4e9c9cd83bf559d6d49a180e98df5cca081529669"
    :COMPRESSED-BYTES 4430 :COMPRESSED-SHA256
    "cd678626ce4d07250bc46ec7f8917f4179aa7e18e3c0e8fa6e59b21c5f351829"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/paired-repeat/windows/2-0-COPY.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12723 :STORED-BYTES 4110 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-COPY.lisp.gz" :UNCOMPRESSED-BYTES 12723 :UNCOMPRESSED-SHA256
    "8d21fa9eface103432dde5bba327a6a2d3303fc98ea6d860c756611b32ba1b13"
    :COMPRESSED-BYTES 3795 :COMPRESSED-SHA256
    "6aa48c7367ba88962103a90480bd53a24e8a20d0d0a62554d860474609919dc8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/qualification-2.6.10/started.lisp"
   :STATUS :OK :ORIGINAL-BYTES 26105 :STORED-BYTES 5219 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "started.lisp.gz" :UNCOMPRESSED-BYTES 26105 :UNCOMPRESSED-SHA256
    "3f6e2d27df67a072cdbf730366c7dc84b1f176418a95d9084405673ab860037c"
    :COMPRESSED-BYTES 4905 :COMPRESSED-SHA256
    "9a2a83b11057599b869852c673d10a91683bf2a61597e0eacd8eeb4dd6753f80"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/qualification-2.6.10/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 62461 :STORED-BYTES 6428 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 62461 :UNCOMPRESSED-SHA256
    "6fc8334e0470f7a7c4b0da618f9b02e4186fcf55c912667bd128226c08cc737b"
    :COMPRESSED-BYTES 6115 :COMPRESSED-SHA256
    "59cf7f8fba760a0a88a13c0b847a8b9bd0b6615a29238be833ec34b9deee7c0a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/qualification-2.6.10/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 25874 :STORED-BYTES 5188 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 25874 :UNCOMPRESSED-SHA256
    "3094da64e17dec796cdfedcb78fb1f2fe442b03189936d276626c1b738ea7ad8"
    :COMPRESSED-BYTES 4872 :COMPRESSED-SHA256
    "fed0f02c2ba68d7b0e55b7b09634595ca8ffee29496b2af0d7406c9fcbbd8373"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/qualification-2.6.9/started.lisp"
   :STATUS :OK :ORIGINAL-BYTES 26104 :STORED-BYTES 5216 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "started.lisp.gz" :UNCOMPRESSED-BYTES 26104 :UNCOMPRESSED-SHA256
    "12f2498d5cd795355512a0663e2e765a9bac9540b293c938a41538a8089e8991"
    :COMPRESSED-BYTES 4902 :COMPRESSED-SHA256
    "f03aee07ffd12668be519f1b1e84b1567704eb84e3fe0f5a8769d972e45837d3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/qualification-2.6.9/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 62461 :STORED-BYTES 6428 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 62461 :UNCOMPRESSED-SHA256
    "6fc8334e0470f7a7c4b0da618f9b02e4186fcf55c912667bd128226c08cc737b"
    :COMPRESSED-BYTES 6115 :COMPRESSED-SHA256
    "59cf7f8fba760a0a88a13c0b847a8b9bd0b6615a29238be833ec34b9deee7c0a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/qualification-2.6.9/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 25873 :STORED-BYTES 5187 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 25873 :UNCOMPRESSED-SHA256
    "ca9bbc7f052f8b76280b5fd935f8350e59987440ffa01642078235efe80fe5fd"
    :COMPRESSED-BYTES 4871 :COMPRESSED-SHA256
    "f1d4e4a3ebf8c38a08eec7aeef29a8a077b88c85c01468aa126f7dec7a05e1f7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/smoke-01-variant/bench.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11324 :STORED-BYTES 3730 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "bench.lisp.gz" :UNCOMPRESSED-BYTES 11324 :UNCOMPRESSED-SHA256
    "447f48457c05dda8d2ea282533f7b62f6ac50d916633cb1862311de271bbb9c3"
    :COMPRESSED-BYTES 3418 :COMPRESSED-SHA256
    "4ad4d7473fc54b909ca35ca5382783596e5ac81e40b635b804db63a780ade84c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/smoke-02/driver-variant/bench.lisp"
   :STATUS :OK :ORIGINAL-BYTES 11391 :STORED-BYTES 3742 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "bench.lisp.gz" :UNCOMPRESSED-BYTES 11391 :UNCOMPRESSED-SHA256
    "d6955effccb2e57bc34825a26c68e1df7f24205c60cbea945e5c315ea6e59cd6"
    :COMPRESSED-BYTES 3430 :COMPRESSED-SHA256
    "0131c882c9de345fb069645a30455e0ca17ff3d61f9d4a45c67d056bfa280bea"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/support/4002547375-check-17845-0/SPK-11.lisp"
   :STATUS :OK :ORIGINAL-BYTES 74130 :STORED-BYTES 8346 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-11.lisp.gz" :UNCOMPRESSED-BYTES 74130 :UNCOMPRESSED-SHA256
    "7b94129fb6d4886ab5be59fb3d7feab118131f6a8979e7293f1e7e3d648c86e2"
    :COMPRESSED-BYTES 8033 :COMPRESSED-SHA256
    "08c331b21684ec4ed02a36ca4a815213e478b8ed261890c023c2e84c01aa9df0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/support/4002547375-check-17845-0/SPK-10.lisp"
   :STATUS :OK :ORIGINAL-BYTES 22977 :STORED-BYTES 4609 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-10.lisp.gz" :UNCOMPRESSED-BYTES 22977 :UNCOMPRESSED-SHA256
    "cfea1d309bf56c23a12d44fe1dcb78f60d2a99095cc819adead30694b06ac2e3"
    :COMPRESSED-BYTES 4296 :COMPRESSED-SHA256
    "c12ff1850b058853e0586141c7b99890800cdae116c1c361720a02f700357bdc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/support/4002547375-check-17845-0/SPK-08.lisp"
   :STATUS :OK :ORIGINAL-BYTES 331092 :STORED-BYTES 45767 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-08.lisp.gz" :UNCOMPRESSED-BYTES 331092 :UNCOMPRESSED-SHA256
    "f1aef4e38ac2f6238a7888ae5f30b9fd1b6beb943a541cc42045f7676666b6dc"
    :COMPRESSED-BYTES 45452 :COMPRESSED-SHA256
    "333ffb22b0ff1746504a80cd0dee27e46977ff708e655c21fa2065cb26b0f281"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/support/4002547375-check-17845-0/SPK-06.lisp"
   :STATUS :OK :ORIGINAL-BYTES 24098 :STORED-BYTES 4272 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-06.lisp.gz" :UNCOMPRESSED-BYTES 24098 :UNCOMPRESSED-SHA256
    "f6ce8527c9fd4c1b8a1c2137f1652d5422b4b0b3eb9e3d3c961d8d0cb42f5023"
    :COMPRESSED-BYTES 3959 :COMPRESSED-SHA256
    "2b824fc27a033ddebc916eaa528c83808d6c8e1800c6416d48b8919b2b5bfde8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/support/4002547375-check-17845-0/SPK-05.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10170 :STORED-BYTES 2224 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-05.lisp.gz" :UNCOMPRESSED-BYTES 10170 :UNCOMPRESSED-SHA256
    "883dd81dad5986544fd6e4db2f45f9a129acdf8b424586367de5a962f708fa8c"
    :COMPRESSED-BYTES 1911 :COMPRESSED-SHA256
    "c4f325190665a5a5cc4507fcca5ef16dd79daa163aeb08e774a4fbfb8ca94bea"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/support/4002547375-check-17845-0/SPK-04.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6752 :STORED-BYTES 1923 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-04.lisp.gz" :UNCOMPRESSED-BYTES 6752 :UNCOMPRESSED-SHA256
    "448c943442ae9062ee6f5ab3d435f31a45c457d58fd57656f28e6a6050a358f4"
    :COMPRESSED-BYTES 1611 :COMPRESSED-SHA256
    "6d5883d6fe4741723700923ff9e93eb75bfd87bbda15551bb8a837223252176d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/support/4002547375-check-17845-0/SPK-01.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27228 :STORED-BYTES 3188 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-01.lisp.gz" :UNCOMPRESSED-BYTES 27228 :UNCOMPRESSED-SHA256
    "472e7237455c18d90840627098e849daabef6292dcb418b3cd35e4eccadfdfc4"
    :COMPRESSED-BYTES 2875 :COMPRESSED-SHA256
    "3bcda4aceda944d172a9f92b81a9560dba14094717f73ed122fd47781b20e97b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/support/ci/selftest-1793558625-18919/workflow.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27784 :STORED-BYTES 3698 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "workflow.lisp.gz" :UNCOMPRESSED-BYTES 27784 :UNCOMPRESSED-SHA256
    "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"
    :COMPRESSED-BYTES 3383 :COMPRESSED-SHA256
    "65ef5865e2a8bcb699e2b198c990c96183d7e9da6772156178630f8e76782735"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/support/command-archive-collector-self-test-172uZc/self-test-report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28790 :STORED-BYTES 3537 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "self-test-report.lisp.gz" :UNCOMPRESSED-BYTES 28790 :UNCOMPRESSED-SHA256
    "3dd34ff6879ee1119189c7223de858f6503bd0fd23d98e7ac6d199214c843939"
    :COMPRESSED-BYTES 3214 :COMPRESSED-SHA256
    "568e63c9aa241461e6743caa7225ebabc4abcd2c6179cc69355062900a1f74e9")))
 :DRIVER-SHA256
 "bd4a2991611ccd8f8629d777fd7fe86f13217d857ac7b2e4a63aaaca5cb387b1" :LIMITS
 (:OWN-RESULT-ROOT-ONLY :RAW-BYTE-HASHES :VERIFIED-LOSSLESS-EXPANSION
  :SPECIAL-IPC-NODE-METADATA-ONLY :NO-NEGATIVE-FIXTURE-QUALIFICATION))
