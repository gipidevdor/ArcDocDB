(:KIND :BUFFERED-TAIL-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "buffered-close" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "buffered-final-archive" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "buffered-identity-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "buffered-closing-archive" :STATUS :OK :SOURCE-CONSISTENCY :STABLE))
 :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-close/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-close/conservazione.lisp"
   :SHA256 "82ba62ec928bd2ea5c433a84575cd092976129e725b4abe0ed20e379522174c7"
   :BYTES 1160)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-close/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-close/report.lisp"
   :SHA256 "e1ad83e5260b2c3944741c54847a3d265da3fb7026ae377dcbcef59696158c7b"
   :BYTES 363556)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-final-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-final-archive/conservazione.lisp"
   :SHA256 "93d907c214785e6a4056283c4178ce3b7ae1a074ce86c23746a034c84e5f02f1"
   :BYTES 1176)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-final-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-final-archive/report.lisp"
   :SHA256 "268e1c4caefa1001c0c6b546dc4e74189206c142bd7b0be9d9f14eb5dbb76a1c"
   :BYTES 362874)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-identity-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-identity-final/conservazione.lisp"
   :SHA256 "e51da409197b950326b9f4fb6565084f7bcc1a47b94b6e3f9abaa453083abd29"
   :BYTES 1178)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-identity-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-identity-final/report.lisp"
   :SHA256 "38247bebeb34cc30438440cd11591be591cf23f6ac9f98c90015a74432880399"
   :BYTES 362859)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-closing-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-closing-archive/conservazione.lisp"
   :SHA256 "56d07a59c25398f5e74554b31b6a437e23c0b050278938e49dc5c6afd9996d0a"
   :BYTES 1180)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/buffered-closing-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-closing-archive/report.lisp"
   :SHA256 "55af4b0e97d143e0a1089f79d267434619ec9b0cceac754edec36a2e00c5ccab"
   :BYTES 362857))
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-buffered-get/commands/buffered-closing-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362857 :STORED-BYTES 116460 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362857 :UNCOMPRESSED-SHA256
    "55af4b0e97d143e0a1089f79d267434619ec9b0cceac754edec36a2e00c5ccab"
    :COMPRESSED-BYTES 116144 :COMPRESSED-SHA256
    "b5ababe16cc150256ad77300483c523fd912a08c1c16a9ae0ae6c793927f5672")))
 :DRIVER-SHA256
 "ed624c7dc0b43a4b23034653e5aa1e7c0e074291ddb437c0d74d7a1668b738ce")
