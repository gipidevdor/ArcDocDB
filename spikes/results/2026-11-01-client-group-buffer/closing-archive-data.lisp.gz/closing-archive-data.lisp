(:KIND :GROUP-BUFFER-TAIL-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "group-buffer-close" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-final-archive" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-identity-final" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE))
 :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-close/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-close/conservazione.lisp"
   :SHA256 "18af3951977ccb252480349bc6bbaf09300fce5ef3248d410f1432cbf6bdc2fe"
   :BYTES 1168)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-close/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-close/report.lisp"
   :SHA256 "298303b3da109a1a19d2fb3df0b93cef54f2fd6b2dc089aaf0dc798a5e0e282b"
   :BYTES 364199)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-final-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-final-archive/conservazione.lisp"
   :SHA256 "34f1ae392d2262b37e1ecd7031283ca79ee49663fd8317e0b23e2aba4f33151b"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-final-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-final-archive/report.lisp"
   :SHA256 "0d3c8b05912f8489d1ee222d113069ee667a6aa3d06055b4baeb30415d5dd71d"
   :BYTES 363517)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-identity-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-identity-final/conservazione.lisp"
   :SHA256 "705d60e7d0606749ceae913b77b3f62b78b53aa8ce88224db4a8bf62d131c9d7"
   :BYTES 1186)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-identity-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-identity-final/report.lisp"
   :SHA256 "b71d69f58ebd13de7cbd238d24420afa0e4d24fe5d90d216a5184696d29a5cdc"
   :BYTES 363503))
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-identity-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363503 :STORED-BYTES 116677 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363503 :UNCOMPRESSED-SHA256
    "b71d69f58ebd13de7cbd238d24420afa0e4d24fe5d90d216a5184696d29a5cdc"
    :COMPRESSED-BYTES 116361 :COMPRESSED-SHA256
    "07d7ae83b6b33e0b29e99929939a66ce9e799980f9a576ebef3b9b84d84ea0d3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-final-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363517 :STORED-BYTES 116660 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363517 :UNCOMPRESSED-SHA256
    "0d3c8b05912f8489d1ee222d113069ee667a6aa3d06055b4baeb30415d5dd71d"
    :COMPRESSED-BYTES 116344 :COMPRESSED-SHA256
    "ab94c5308bfd30fc0ba10e6cbe89537d92fde5bf4def4615d4d713878f9678d1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-close/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364199 :STORED-BYTES 117056 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364199 :UNCOMPRESSED-SHA256
    "298303b3da109a1a19d2fb3df0b93cef54f2fd6b2dc089aaf0dc798a5e0e282b"
    :COMPRESSED-BYTES 116740 :COMPRESSED-SHA256
    "44de253a2d3b4c3d6323b14f62e49c9cdae5ef82711b1367c5bc3c77f2e0a152")))
 :DRIVER-SHA256
 "3285174b2b0794a5d84b53fbdd67218234e82d4ee975ddf72caf1d7ec244a4ae")
