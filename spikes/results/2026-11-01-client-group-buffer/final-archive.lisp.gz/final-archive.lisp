(:KIND :GROUP-BUFFER-COMMAND-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "4002560893-command-24381-0" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-analysis-self-test" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "group-buffer-archive-self-test" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "group-buffer-baseline" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-baseline-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "group-buffer-checks" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-cleanup-self-test" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "group-buffer-close-self-test" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "group-buffer-codec" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-documentation" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-example" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-focused-01" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-focused-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-focused-initial" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "group-buffer-identity-self-test" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "group-buffer-paired" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-paired-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "group-buffer-process" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-qualification-2.6.10" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "group-buffer-qualification-2.6.9" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "group-buffer-smoke-before" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-smoke-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-smoke-final-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE))
 :FAILED-FIXTURE-ROOTS NIL :SPECIAL-NODES NIL :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793572093-24380/workflow.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/ci/selftest-1793572093-24380/workflow.lisp"
   :SHA256 "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"
   :BYTES 27784)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793572093-24380/tests.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/ci/selftest-1793572093-24380/tests.lisp"
   :SHA256 "72d8ca8f69a6df2de0109bffa94908d4d6e32d4b899bad224a91d9e25814a51c"
   :BYTES 2463)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793572093-24380/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/ci/selftest-1793572093-24380/report.lisp"
   :SHA256 "1ae97ae4103f11530749a8627e2ba2cc908579dc933ba091a1eafd94a48a5125"
   :BYTES 632)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793572093-24380/publication.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/ci/selftest-1793572093-24380/publication.lisp"
   :SHA256 "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc"
   :BYTES 1181)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793572093-24380/measure.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/ci/selftest-1793572093-24380/measure.lisp"
   :SHA256 "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c"
   :BYTES 2041)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793572093-24380/data.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/ci/selftest-1793572093-24380/data.lisp"
   :SHA256 "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2"
   :BYTES 3214)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793572093-24380/conditions.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/ci/selftest-1793572093-24380/conditions.lisp"
   :SHA256 "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f"
   :BYTES 663)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793572093-24380/boundaries.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/ci/selftest-1793572093-24380/boundaries.lisp"
   :SHA256 "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23"
   :BYTES 976)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/command-archive-collector-self-test-qQacp7/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/command-archive-collector-self-test-qQacp7/self-test-report.lisp"
   :SHA256 "701f983f7137b4966811958ea48481bdc0d5f4c96e4f6e2bcd4a3cc1aa9f2c87"
   :BYTES 28790)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560540-command-20744-0/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560540-command-20744-0/self-test-report.lisp"
   :SHA256 "7e47f646dc8ee821fcd8e3536a898b414e928bb78b4cbfd416d95f7b431a963b"
   :BYTES 157)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560893-command-24381-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/4002560893-command-24381-0/conservazione.lisp"
   :SHA256 "9d51da726c69ecf8a1dc564b468b75bdedce02d9b80a0fdcd5b45228b10c7954"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560893-command-24381-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/4002560893-command-24381-0/report.lisp"
   :SHA256 "f2105831e433d9911c6fed8bd31214dcfc8b97474b1fec531d557c3742385d09"
   :BYTES 364134)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-analysis-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-analysis-self-test/conservazione.lisp"
   :SHA256 "93715e56dcfd4d1f36855790c010e3ec6a8e0a58021cbe8eacc12841a5e8f030"
   :BYTES 1194)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-analysis-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-analysis-self-test/report.lisp"
   :SHA256 "c557df4db30c6a7789b89d364dea60b6e5cce4d6cbed6cf13f7dd80afcdce16b"
   :BYTES 362790)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-archive-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-archive-self-test/conservazione.lisp"
   :SHA256 "a28a29e525cee0d3426ed2aacc7c04eb6f4efd4f3dbe5704019b1ec04eb2318d"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-archive-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-archive-self-test/report.lisp"
   :SHA256 "75241d6172679444718ea9657bed5c214781ecb1314413e063fdeaf8fa57f258"
   :BYTES 363497)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-baseline-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-baseline-analysis/conservazione.lisp"
   :SHA256 "aed828017d642895ef7f22ac47f14db00abd4ec16e4de10245726afefb183edc"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-baseline-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-baseline-analysis/report.lisp"
   :SHA256 "ec7e0eff54f526cfdd789202c14c931b244ff21fc2876cb639d8ca10ac9f0883"
   :BYTES 364340)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-baseline/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-baseline/conservazione.lisp"
   :SHA256 "31608ed2c5d78eafaf85ce8f1404134e3de8e3e6bddaa7832a6bf22021dd5bc2"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-baseline/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-baseline/report.lisp"
   :SHA256 "0ff040fd4d4dae5840cf8484501761782ebd0694e895e7719c0a6b61abeb0b3a"
   :BYTES 381694)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-checks/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-checks/conservazione.lisp"
   :SHA256 "38e6e7cdae8e6c55509f560df6532077e9917acc68393650f73515cb2c8bd60b"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-checks/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-checks/report.lisp"
   :SHA256 "db1f643cdfeed193945d0d598f6fd0ffea567046602c574f6e68a162edb33958"
   :BYTES 436359)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-cleanup-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-cleanup-self-test/conservazione.lisp"
   :SHA256 "7d5628012db5c865bff1befea12a049822a28db5003c3543bdb85ad0d7e1af1f"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-cleanup-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-cleanup-self-test/report.lisp"
   :SHA256 "fc6ca9de628013163f7721418ff86cd2b46a54cae1aa0a7f1f8f32040694d781"
   :BYTES 363527)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-close-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-close-self-test/conservazione.lisp"
   :SHA256 "3dd9d0d286b4a6eb30c47242f469ed7194035528798dee36db15323fa61b99d8"
   :BYTES 1188)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-close-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-close-self-test/report.lisp"
   :SHA256 "5eb09af1e6f3aa5f367a844a4f8e9e465dd919682bb418b151dad9ddef707e3e"
   :BYTES 363483)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-codec/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-codec/conservazione.lisp"
   :SHA256 "e564c28ac772aa6a7b4e406792b5d06b6b62584aa780e4d631ef97a67a21125d"
   :BYTES 1167)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-codec/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-codec/report.lisp"
   :SHA256 "e005c8158fccea044eb261f3d8af4fbef43404f220fa1b0d77c13b15425bb733"
   :BYTES 365193)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-documentation/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-documentation/conservazione.lisp"
   :SHA256 "180de21818930b84efde1d5c8d12c096aaa2c7ae77f7b2143a95062b4d91db6a"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-documentation/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-documentation/report.lisp"
   :SHA256 "5fae1f50a271246fc0ec6fe86546ae55b95f175c2f1642c7d4b9256129075907"
   :BYTES 369604)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-example/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-example/conservazione.lisp"
   :SHA256 "0c74bc78e9c9cbabbfb1098a3b8534c01457422c4237b35caf77509a46dc43eb"
   :BYTES 1171)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-example/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-example/report.lisp"
   :SHA256 "fbf248875e94c6bb87b47ee5e8faf3f011ce8f55bb1e7500ffe75f9661b10245"
   :BYTES 363454)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-focused-01/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-focused-01/conservazione.lisp"
   :SHA256 "363e5e0ff2ebf2df9da2146ee974e22e7c9fb1ba06796334bbf20af4c782fbef"
   :BYTES 1178)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-focused-01/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-focused-01/report.lisp"
   :SHA256 "67ef66ac6ea3755dcabb5dc554c7906d7d3f8cf9d35ce6ac433ef7cbd595d355"
   :BYTES 363013)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-focused-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-focused-final/conservazione.lisp"
   :SHA256 "82d05b165083140b6b8fa4fbc79913ec05260a9fc7997a134f1bf08e047cb6fe"
   :BYTES 1183)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-focused-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-focused-final/report.lisp"
   :SHA256 "3249d1e95ff58805bee923b9520c45ec16406d67beb5a0b51762f356307bd681"
   :BYTES 363436)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-focused-initial/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-focused-initial/conservazione.lisp"
   :SHA256 "9a995a2cd2cc14842ee827ac9df865a71ee14a10fb9f6a4fbe2c71f206f0e406"
   :BYTES 1188)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-focused-initial/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-focused-initial/report.lisp"
   :SHA256 "7e780376bd13cd07aabc38e3f037888769288e06be4a3e42a328bc7e83af097b"
   :BYTES 362741)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-identity-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-identity-self-test/conservazione.lisp"
   :SHA256 "8d583eaa27f3d29f8625de27f00dccc0dc2fc0ccb246f0d8452dce24ab605d86"
   :BYTES 1194)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-identity-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-identity-self-test/report.lisp"
   :SHA256 "87ff1f35c49628c66e03f34cf24338e61006a9861344f93c32db744d8a677cd2"
   :BYTES 363508)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-paired-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-paired-analysis/conservazione.lisp"
   :SHA256 "e3055466ae1ce5409de48c5f106b479cb4bc13a61cf611164d37c1785bcff0ff"
   :BYTES 1188)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-paired-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-paired-analysis/report.lisp"
   :SHA256 "a10c1728314c0378d6f91d39406f787b9b681fccdbff8c99de7a762b4a7c3763"
   :BYTES 365684)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-paired/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-paired/conservazione.lisp"
   :SHA256 "aa330b745f2fa3fb21c816018034a85d5abd7f51189dae5857f57dd6b2ca6c4c"
   :BYTES 1169)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-paired/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-paired/report.lisp"
   :SHA256 "87988e86b38622ae5fab7bcdc0a0d06bf1f7042a5ad7d391335b70cda6bb9817"
   :BYTES 382417)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-process/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-process/conservazione.lisp"
   :SHA256 "9f66fb966c23839f7258d52387bf5ee323b7f324b5654c5ba8dfeeafb9991cc4"
   :BYTES 1171)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-process/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-process/report.lisp"
   :SHA256 "336652db8932e68aa643a65606732ef70c536c0090d2fcc0cd577b7e4f7df302"
   :BYTES 373506)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-qualification-2.6.10/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-qualification-2.6.10/conservazione.lisp"
   :SHA256 "6e8e8a711d2309b3570df5d33a0f6aa36dd00fbe0058ace9ab0fdf019321db5f"
   :BYTES 1198)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-qualification-2.6.10/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-qualification-2.6.10/report.lisp"
   :SHA256 "f03296915161270130a9755c27f505faeff8563258314621d9b6494966774436"
   :BYTES 611837)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-qualification-2.6.9/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-qualification-2.6.9/conservazione.lisp"
   :SHA256 "f24db4393dd3b412cfb7a16e3c42aaab3fa5ba4e2de1785fadd5e12838d5680c"
   :BYTES 1196)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-qualification-2.6.9/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-qualification-2.6.9/report.lisp"
   :SHA256 "3645ee36b39989f5b853efd9b20f79e17957182ff44ec4ccdccacf4a242fa79e"
   :BYTES 611804)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-smoke-before/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-smoke-before/conservazione.lisp"
   :SHA256 "61ac2a90e61aa1c27adbab06435d0f3b8f25964aca7807674110bbb0be9a294b"
   :BYTES 1182)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-smoke-before/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-smoke-before/report.lisp"
   :SHA256 "4d8855f77148cd51241d9a7cab4aa2ea786787e745835be3cfb7b07c08dedc81"
   :BYTES 365344)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-smoke-final-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-smoke-final-analysis/conservazione.lisp"
   :SHA256 "a0267f43247329a88ba12a0f9c0decd4dd352cc817d6d92aa8bb68403403b247"
   :BYTES 1198)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-smoke-final-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-smoke-final-analysis/report.lisp"
   :SHA256 "cc9730449b74e921f7c24cd4b7fd87910a1023542f4b5c0ccd402db938497b84"
   :BYTES 363682)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-smoke-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-smoke-final/conservazione.lisp"
   :SHA256 "4df495062435c1baddad9bda836d65d83a7d3bf24e80015aeee50e89325c5643"
   :BYTES 1179)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-smoke-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-smoke-final/report.lisp"
   :SHA256 "7fb5bff57b2d6bd0d4a195b39fdfbb686dcab1eaf70378ae517a28e57d62a803"
   :BYTES 366144)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/SPK-01.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/SPK-01.lisp"
   :SHA256 "691c8058630a3fb1749026997525f95f93b3c0b9a57e46dd2e87a929f7250ed1"
   :BYTES 27228)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/SPK-02.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/SPK-02.lisp"
   :SHA256 "fc1a96a4ff7b0030db0654c79b35799b5fc8e312aca378e125c2c64d41a85c98"
   :BYTES 1607)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/SPK-03.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/SPK-03.lisp"
   :SHA256 "66d1f2bb61a0336c136b41004fa180f8bcf65d0e6425249b63a703f58512baa6"
   :BYTES 3664)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/SPK-04.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/SPK-04.lisp"
   :SHA256 "44b32fc25d35983906a233ff474fb893dd1000b0d1b538cda97417dae1aa3571"
   :BYTES 6752)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/SPK-05.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/SPK-05.lisp"
   :SHA256 "cfb69e32f6d34ecc8841c12931e9af1c48c7fe2894e9544bf459029640e65bec"
   :BYTES 10138)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/SPK-06.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/SPK-06.lisp"
   :SHA256 "54963d9f7578a9055e4d9c745d63bb3df6b5b4eebbbae1245ff8694720011cc3"
   :BYTES 24126)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/SPK-07.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/SPK-07.lisp"
   :SHA256 "390a801bcb95a4f741b8b9c2c95f12429206551aa38a98fbb4c57d57fc83f1e9"
   :BYTES 318)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/SPK-07.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/SPK-07.lisp.gz"
   :SHA256 "d2109866eb40807fd7815898cbd927b85c3eb1238fca233e3e059ebd704b87a4"
   :BYTES 411738)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/SPK-08.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/SPK-08.lisp"
   :SHA256 "85506eb9f4b45a215a5b442477c730c6acd43ce4e0dfb9a8e8c8e0503be6d7fb"
   :BYTES 331092)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/SPK-09.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/SPK-09.lisp"
   :SHA256 "b1c052f84bb292ea17f69f94f10782a0ae6905e66a2c45120abd0b120fb33a6c"
   :BYTES 2471)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/SPK-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/SPK-10.lisp"
   :SHA256 "d4153c7e20a79e2eae3573714e3f6065d093f1bcd8b0163105f425266bc03a71"
   :BYTES 22977)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/SPK-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/SPK-11.lisp"
   :SHA256 "fe2fcef18dc634d42469ae026c5a48d4929294502373ba08fb5cf91de529e37a"
   :BYTES 74131)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/conservazione.lisp"
   :SHA256 "c0544fe85f7cdb36f35f19edee6b70b06c9ed25c1c45ee8977c88de9bee1f2e0"
   :BYTES 2352)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/report.lisp"
   :SHA256 "24f02960038b85fced9d60ec272d8de07b7505c385de960b93d3477cd0e1296c"
   :BYTES 318)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002560835-check-24038-0/report.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/4002560835-check-24038-0/report.lisp.gz"
   :SHA256 "ac33cb642e0dce5c53d40624c781bdc863ed11eab8186a73aba222665d5f3194"
   :BYTES 484319)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/0/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/0/scan-4.lisp"
   :SHA256 "cf97d55b66def72b215f621d3fe1c869c3186f6bd782d877d2f2b9fde23c7b8f"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/0/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/0/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/0/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/0/scan-4.stdout.log"
   :SHA256 "a611689b36624c0e0b1c9975f4f0e85d219b95f255675dbdbc5449e856b67802"
   :BYTES 4200)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/0/session.pid"
   :SHA256 "0a446b88f6a05779bd286a6955a83b2fa38fc33810420f940762db474b66eba0"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/0/stdout.lisp"
   :SHA256 "3c3e1d0db8c3c9caca1995916027d78492d2f580d5e50cdf94d4e59281dd4aed"
   :BYTES 220)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/1/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/1/scan-1.lisp"
   :SHA256 "fe4dfe06acdff49135cba33f5d108c68d6748a2def7b9023fb1f2cc1a883760b"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/1/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/1/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/1/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/1/scan-1.stdout.log"
   :SHA256 "3305f5e38c938374b0ac661955517a5dfc15451ffeb02d70841086ffbb34d26a"
   :BYTES 4206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/1/session.pid"
   :SHA256 "d43c672b00681deaeb256016542e22ca50bb6e37c6eafdc20c2f0b836755a066"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/1/stdout.lisp"
   :SHA256 "1408b0f66ab661b8673cd350d40e192493dba517be5a2705d382c63c8438d28d"
   :BYTES 239)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/10/scan-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/10/scan-11.lisp"
   :SHA256 "e90a29f82d0e4f196ffb32dc7c3b8ca877d5a0c8fedc6755f80b60fa7f92b8cd"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/10/scan-11.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/10/scan-11.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/10/scan-11.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/10/scan-11.stdout.log"
   :SHA256 "2876ac069722ef384274378372d435f5ceafdc2aa751cc4dec5a02fedb02cf7d"
   :BYTES 4206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/10/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/10/session.pid"
   :SHA256 "fdea8c747128c31743caa5dacf909ce096c9e30f7a67d6f4c3c30ce8a69fa8d6"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/10/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/10/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/10/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/10/stdout.lisp"
   :SHA256 "b41750084e5f40f0277ebeb497e481080e7fe941baa7d744125d2c371e440c85"
   :BYTES 240)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/11/scan-12.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/11/scan-12.lisp"
   :SHA256 "a505f06ab21434652fea8d8421063cb6c19344e92152b3d43c356ee040fa2a7e"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/11/scan-12.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/11/scan-12.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/11/scan-12.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/11/scan-12.stdout.log"
   :SHA256 "da6f33de67f4929dbc29738b99bd75809c1f6bf797a3b18e5608b11561d1275f"
   :BYTES 4200)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/11/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/11/session.pid"
   :SHA256 "4109ea390775664f1feb63a821f4f7c50ebca8a2254e10fa8780b6bfdc080e1e"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/11/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/11/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/11/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/11/stdout.lisp"
   :SHA256 "e73c108e307445a6e4194c203f4b1ccd50a0f8bcf263d48fe3f388de1923c5b4"
   :BYTES 230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/12/scan-13.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/12/scan-13.lisp"
   :SHA256 "8704a933477b375d5c11fea5263dd995b2770f1532c7cdd07dc3ff32d93a392e"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/12/scan-13.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/12/scan-13.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/12/scan-13.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/12/scan-13.stdout.log"
   :SHA256 "a696238b3cdd69e0188a6de6c16247238e757039e7e0c21c4477cbe6f748d3ff"
   :BYTES 4194)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/12/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/12/session.pid"
   :SHA256 "a2b559d5ccdb133731769a911b116fee285e512250a52f7bde6c6d1d0bd41c05"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/12/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/12/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/12/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/12/stdout.lisp"
   :SHA256 "a502520708b2fd9a0b2abcd2f7fc2c040042c9249c3a9966193a4cc08b941c3b"
   :BYTES 240)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/13/scan-14.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/13/scan-14.lisp"
   :SHA256 "0f2647902138ecd6a97267536e67a009868403ca0cdfd7bc0e8aa0cb6de44b6c"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/13/scan-14.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/13/scan-14.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/13/scan-14.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/13/scan-14.stdout.log"
   :SHA256 "ec38a31a8119e4e8408d849041b49509a0ec6ba5ed71ed0621dd6938fa4a9597"
   :BYTES 4188)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/13/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/13/session.pid"
   :SHA256 "f6f32c5edd16ce08ac12e56f21befaa6fbc69c3e27769bf96eec79ed0a0e037a"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/13/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/13/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/13/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/13/stdout.lisp"
   :SHA256 "4e98678e376e4a4625750ede03b73fcc8e9408333e83c8de7972982f0e35eddf"
   :BYTES 230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/2/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/2/scan-2.lisp"
   :SHA256 "12893e783922298602d17160855cb1d8faec4be536f01aeb719133ae7cc496f6"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/2/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/2/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/2/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/2/scan-2.stdout.log"
   :SHA256 "84eaf969fdda89d704e9addddff80648a5da06cc9942e83847edfb51c835e12e"
   :BYTES 4206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/2/session.pid"
   :SHA256 "29b2abe54d68bbb5a87c6da5938b640d8a2d7f22951fa84e3475f36c1ccfaa00"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/2/stdout.lisp"
   :SHA256 "2e7fca2d9e2fc0d9537df579c78b038ae3c1477cd817cd40fffacbc4cda80597"
   :BYTES 229)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/3/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/3/scan-3.lisp"
   :SHA256 "ffd7366eeeb7a8e30b05147c1a4dea744afca14e3b608c9f8ad5e1c366770dba"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/3/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/3/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/3/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/3/scan-3.stdout.log"
   :SHA256 "bf738de019f44ad4e667e72c98e045d818f76d78f72cf41ee4aa78cc57024360"
   :BYTES 4200)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/3/session.pid"
   :SHA256 "8e5827843099712364c341f40f22a87d93007b3da3a4a3627d0220819adcb7a4"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/3/stdout.lisp"
   :SHA256 "25564bda945c2105101cc7d392d13240d14238d1a27e9acf8da5f5ae0875158d"
   :BYTES 232)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/4/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/4/scan-5.lisp"
   :SHA256 "b89f1ac2e242026ade856586b5828adbc1d415f6714acbba803709ed71f89509"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/4/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/4/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/4/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/4/scan-5.stdout.log"
   :SHA256 "dc56b735d60fab607dd53fa9a84b5048cf1884e09002bde370b1595a59d4bcd5"
   :BYTES 4206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/4/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/4/session.pid"
   :SHA256 "c47fe1d8222b8239dbd93b4d5c30c1adefd0908e8cfd14dd4cbde5f6142bda41"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/4/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/4/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/4/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/4/stdout.lisp"
   :SHA256 "2be099c08baa117e6464bba3c631874220ab09ec3b9d2dfa3fa3a54fb50eb69f"
   :BYTES 235)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/5/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/5/scan-6.lisp"
   :SHA256 "bd981f00639ea3c465bc8ed447c5ba4524aa656b6c46d7fc56c0525973e0b674"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/5/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/5/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/5/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/5/scan-6.stdout.log"
   :SHA256 "df19a716f9c757df629044c0299e72e341b0477a7bb23b1930074addc0aa9deb"
   :BYTES 4206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/5/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/5/session.pid"
   :SHA256 "4bd328f259ec0b61414af5adf336c98708265a9008b1c439c56ea4d8c78a1d09"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/5/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/5/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/5/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/5/stdout.lisp"
   :SHA256 "c020b7cfad97537e62a5b046c84a727494a77429c7ba3d0b3c88699d692fadea"
   :BYTES 234)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/6/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/6/scan-7.lisp"
   :SHA256 "da529f81a8474cab8770ea281eaefde9bc6b0b1cf951fa97fb8ab4729bf7cc61"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/6/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/6/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/6/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/6/scan-7.stdout.log"
   :SHA256 "4daee77337d9e5861a6486bfbb5c099bf94faa622365480b94cc56de92f94bf3"
   :BYTES 4206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/6/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/6/session.pid"
   :SHA256 "72f3e402bff8f9aa479a80fd8a814b7dcd2bb3aec0f7c4344100ce1de8d7e5cd"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/6/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/6/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/6/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/6/stdout.lisp"
   :SHA256 "632ff70d8e777211e68c9c6aa18fbbacd544790316335340e811020c0820425a"
   :BYTES 235)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/7/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/7/scan-8.lisp"
   :SHA256 "88f2c4e2eca1ac42b4760ad4a12d9ed6e1c5b43d0846365e7018b8e9cef66fa4"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/7/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/7/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/7/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/7/scan-8.stdout.log"
   :SHA256 "e8b2f8952924fb5bf41776a739a84f61d797ad65d4d5e17a5fb7cabfd4b6e8bd"
   :BYTES 4200)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/7/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/7/session.pid"
   :SHA256 "a4cfc9053447a7305a7334b49e3d553cf793af5c2daa103e85292374033786ec"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/7/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/7/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/7/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/7/stdout.lisp"
   :SHA256 "ba7fcea75bc2864a21f3b940483384447375da9144341dee0b2be1a13f199598"
   :BYTES 226)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/8/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/8/scan-9.lisp"
   :SHA256 "9c2e4ff673c91a4b3c33dca8e9d37d06710f7320166d5c84e7386b826e8b75d2"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/8/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/8/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/8/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/8/scan-9.stdout.log"
   :SHA256 "4dd0cfe3004805abe9e4acf8a26d8ea70d44662ceb464d027c8c7f3d0a5d0670"
   :BYTES 4206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/8/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/8/session.pid"
   :SHA256 "b3f3476e51d4433d3c877238b035b64ef3b38d6f6ce29c891efed4aac338fb32"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/8/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/8/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/8/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/8/stdout.lisp"
   :SHA256 "31ea0941716566ef078790085e72650d0e0e931bcea03088f090c3f9e6fb9c66"
   :BYTES 239)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/9/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/9/scan-10.lisp"
   :SHA256 "95e39ecedb9c6016bcab1eb6f46a115e32a4348a6489e1ce330c695377204067"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/9/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/9/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/9/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/9/scan-10.stdout.log"
   :SHA256 "ca7a120b1851002c28097331e5100fe30847f590d3565a3ef45bab9a90f6c587"
   :BYTES 4206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/9/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/9/session.pid"
   :SHA256 "690994e361a0f17952ea4f67d933788405de5bfb81c7698b638ce3e45d770870"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/9/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/9/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-141ZPI/9/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-141ZPI/9/stdout.lisp"
   :SHA256 "15ed29b95978e446d17cd9f520516673c21d11b1ceb647a83107d088cbc75fb4"
   :BYTES 229)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-14XD8o/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-14XD8o/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-14XD8o/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-14XD8o/0/stdout.lisp"
   :SHA256 "32343d6276c6146179d8776115ceaabfc2410fce0629dc9ede1fff52ba3eb58c"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-14XD8o/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-14XD8o/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-14XD8o/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-14XD8o/1/stdout.lisp"
   :SHA256 "aeafc188dd4fbfca5ddcb1887f687d3a4cd3bd09b1d64437e5b941f056aaa23d"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-14XD8o/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-14XD8o/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-14XD8o/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-14XD8o/2/stdout.lisp"
   :SHA256 "0e6bda4414c97115c8bed5f4765e52bf0515b7a19178fbb863315faf266e786b"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-14XD8o/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-14XD8o/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-14XD8o/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-14XD8o/3/stdout.lisp"
   :SHA256 "fe6852662e324dba7d7b87cfef924e5e4d1a243a5b06497fa053ec5a8ce94de4"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1OfFir/0/scan-25.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-1OfFir/0/scan-25.lisp"
   :SHA256 "8633d1bb04c86d888deefeba844255775f07f9d49bcc0687802cd3b19e4839d0"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1OfFir/0/scan-25.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-1OfFir/0/scan-25.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1OfFir/0/scan-25.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-1OfFir/0/scan-25.stdout.log"
   :SHA256 "2bed3f25cdb51eabb0e045e66cebb18deefeac1bcb9daf7033fbaa79f391c580"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1OfFir/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-1OfFir/0/session.pid"
   :SHA256 "ee5462ad0a0b9a0f90c8a097eea93d458b86641d1920c3dff1fdd5c30a28cdac"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1OfFir/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-1OfFir/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1OfFir/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-1OfFir/0/stdout.lisp"
   :SHA256 "e9ae83df3bf1219776134fefa5205338c66db66878eb321de439d7c94d7554cb"
   :BYTES 563)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/0/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/0/scan-5.lisp"
   :SHA256 "c672253a05f7b17e5a73d96ac500076c0255190c49003c808056bcbd367500b0"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/0/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/0/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/0/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/0/scan-5.stdout.log"
   :SHA256 "caae9aa66684b2d098791616bc3ef7796cef15c040580980393ba7cd977e75db"
   :BYTES 4062)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/0/session.pid"
   :SHA256 "4a5d2461777089f536ea9c609b26488187319f45da5749994e72f6f351000f54"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/0/stdout.lisp"
   :SHA256 "1231bfb718dd0886eb6e4410ed6f75d46d369da6ff1d92f4ed01356cbda7ad93"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/1/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/1/scan-6.lisp"
   :SHA256 "14e8d4c6a9d09c92f0559faab6fdd2c761b0b7bdec35d8b5c33e0380eb19a93a"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/1/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/1/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/1/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/1/scan-6.stdout.log"
   :SHA256 "628c9ccff33ca66571e620aa42b7e844a31509ac24ce1e7aee73409286b94ad8"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/1/session.pid"
   :SHA256 "5443af8cca860d7b183043b21eba4d16dd0771cd5b1e4aebd5129359c156faee"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/1/stdout.lisp"
   :SHA256 "b73bf7936c9411917b15b1b938645b069034c70e7cfc6a3a71e5ec231f0feffd"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/2/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/2/scan-8.lisp"
   :SHA256 "c614940e7469d3c46bf568a4ba16c247f53dab16a9b8f0c1c4b2ad6c2c1ac1f4"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/2/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/2/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/2/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/2/scan-8.stdout.log"
   :SHA256 "eedcfcf85c187bea5b872562a4a21fd342f2508a75d490e3331452616aab7c75"
   :BYTES 4050)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/2/session.pid"
   :SHA256 "c4733919826ba7410eab85a17efc908a2a2553f1955d06b5de1deb460dcb59a8"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/2/stdout.lisp"
   :SHA256 "566235ed80993ae8225c787d7c3455e6f1deaf5fb96c034fe21b8d1873335c00"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/3/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/3/scan-7.lisp"
   :SHA256 "dd4a0a5b9568cc984a76044baf91c2c77eedaea47b25626e28b4ae7b979acc1d"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/3/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/3/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/3/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/3/scan-7.stdout.log"
   :SHA256 "318dbe948b7a848de80ed88d2b16e92742b7ec89295ff70c0eae959501ffc161"
   :BYTES 4050)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/3/session.pid"
   :SHA256 "abdaae89ef9679b9bda976e923173fdba81d0da5fafdcd37a97f43ff138ec943"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2T2slP/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2T2slP/3/stdout.lisp"
   :SHA256 "104d8544f9b470ed8279ce3a9efa805fca2808fc72cd49d61451713a606d73f3"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2aTTey/0/scan-30.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2aTTey/0/scan-30.lisp"
   :SHA256 "8901738fc1e6ffc01c51ac06968085fe4be68b4b4a5e9d1213a9c9f39a21cd86"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2aTTey/0/scan-30.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2aTTey/0/scan-30.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2aTTey/0/scan-30.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2aTTey/0/scan-30.stdout.log"
   :SHA256 "71419cdecc74e0c000c1fa8c8df16b23a827c619a0a8146c9add0cf5cb116c64"
   :BYTES 4080)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2aTTey/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2aTTey/0/session.pid"
   :SHA256 "4fccd1d69414be40ba0c43ace5ac48cbd2b07800e7f6ea6d6242be9086ff2ce9"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2aTTey/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2aTTey/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2aTTey/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-2aTTey/0/stdout.lisp"
   :SHA256 "95a9daafcbb8ddd00051a4343cd8199da210d92a5147c094f8c9f8ef1b70c06c"
   :BYTES 927)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6fv0tX/0/scan-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-6fv0tX/0/scan-11.lisp"
   :SHA256 "9ec6a30d36070a669f9568b0a703c471186bb4e45977b3e182af8a154c7816ed"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6fv0tX/0/scan-11.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-6fv0tX/0/scan-11.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6fv0tX/0/scan-11.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-6fv0tX/0/scan-11.stdout.log"
   :SHA256 "224e8cad6581fba46355fcbb6ff872e713f540168aea7d22a409310dd3ecd7f5"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6fv0tX/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-6fv0tX/0/session.pid"
   :SHA256 "c3b7d60946ddec3a65515d7b9f35e13b9e27e3ca37f35ecd2fa7c504aa1c9add"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6fv0tX/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-6fv0tX/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6fv0tX/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-6fv0tX/0/stdout.lisp"
   :SHA256 "3306d1826885f0fee57472d24469595d5c5f54b589787e0537797e490480ddfe"
   :BYTES 296)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7FQXX6/0/scan-27.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-7FQXX6/0/scan-27.lisp"
   :SHA256 "1c7a0af7ac2be9d785cbd0685f51156caa1b959013d64c710d9de9467f0606ee"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7FQXX6/0/scan-27.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-7FQXX6/0/scan-27.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7FQXX6/0/scan-27.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-7FQXX6/0/scan-27.stdout.log"
   :SHA256 "865d03ef47d8475d98430a94916a4420de85e1e5a49c77eee680209627abc863"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7FQXX6/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-7FQXX6/0/session.pid"
   :SHA256 "9fc445d59fca32a1e3af937ba38cbe460c733c47392c86fc7a5d3add914ec1fb"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7FQXX6/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-7FQXX6/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7FQXX6/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-7FQXX6/0/stdout.lisp"
   :SHA256 "862cdd04c516fee93dd90b5733e5a058cecf03807cbdf067781a98d48c027ba9"
   :BYTES 277)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/0/scan-38.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/0/scan-38.lisp"
   :SHA256 "cb7bd5a8ab739a76ac982819ab9e91e2291b0f54d20b3956c9d566a4ac93b15d"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/0/scan-38.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/0/scan-38.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/0/scan-38.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/0/scan-38.stdout.log"
   :SHA256 "c020d4b1082b0ca97c8e1997fbbcbff6ffd9fd150cf2ff763d2d49f33e55b1c0"
   :BYTES 4230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/0/session.pid"
   :SHA256 "20ed876311ef7761019bb38aed6a62071d0765caeb8386c0c854d92ff3807a63"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/0/stdout.lisp"
   :SHA256 "a2e705b689758c61edc0c8f19b0915061ed6a9e194806f2623f2b23e06464825"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/1/scan-37.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/1/scan-37.lisp"
   :SHA256 "45a81b720e3625dfd8957098a607daabb08a8a85da436480031245fcefcc0cf6"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/1/scan-37.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/1/scan-37.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/1/scan-37.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/1/scan-37.stdout.log"
   :SHA256 "fee86a000b5047cc5deef1a5824b70965296ccaf0d0e48e4cc783b8bce7f79b2"
   :BYTES 4230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/1/session.pid"
   :SHA256 "bf00d8d789527f86147ea8069bf52d60083792e85643621dc1a867dd127ff307"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/1/stdout.lisp"
   :SHA256 "7b22075c5e13a19f325fa6b8b057f4e23a76224936751a86886b6837fed106f0"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/2/scan-36.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/2/scan-36.lisp"
   :SHA256 "3f7d7e7688a306a86548df71c4469b1bebd2ab9950dad4d1591269f957c2e173"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/2/scan-36.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/2/scan-36.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/2/scan-36.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/2/scan-36.stdout.log"
   :SHA256 "db58513b123c750ae9bdac258fc520b887404c15e27b8b485245d63e5467dd1f"
   :BYTES 4230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/2/session.pid"
   :SHA256 "9d22b5e1ff03b08a00bbaaa9cb3390411a13058c18a70d19954e0e8b389dd52b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/2/stdout.lisp"
   :SHA256 "1468ced7bcff4d2e525b310d6a1d0e5ee046cc664eb6b209c4a0d5653522cc25"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/3/scan-35.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/3/scan-35.lisp"
   :SHA256 "a372dfbb33d264c325ff2c0122fc3296566b5fd05d82f87c29904ba3faaa72f5"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/3/scan-35.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/3/scan-35.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/3/scan-35.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/3/scan-35.stdout.log"
   :SHA256 "f1ed662775e3739d71cb5eef3714ca25f817d836676c858c506d0bd6cf9b57e1"
   :BYTES 4230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/3/session.pid"
   :SHA256 "49ff4400ba4a795e5e794db508cad041910b1ebc624c6d0873f8b13e4883871b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8hz2Ki/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-8hz2Ki/3/stdout.lisp"
   :SHA256 "688ffc973edabdc5cc7ac89f66fa2c68fde2ca6170f2df87c2e57f4b36ba4cad"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AsdLfv/0/scan-28.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-AsdLfv/0/scan-28.lisp"
   :SHA256 "469d0f2bfbaf948bd1011b10d116978046a348024e2f654313ba3b9a8d952f66"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AsdLfv/0/scan-28.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-AsdLfv/0/scan-28.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AsdLfv/0/scan-28.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-AsdLfv/0/scan-28.stdout.log"
   :SHA256 "2c49d15c391cc517b5cbea1c964cd90902a213e6267796d54399d06c24d78f5f"
   :BYTES 4080)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AsdLfv/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-AsdLfv/0/session.pid"
   :SHA256 "acc422ed6ef6d3549499d3fd668ed44649bc83529e36f1af739b13ae5c74eee7"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AsdLfv/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-AsdLfv/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AsdLfv/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-AsdLfv/0/stdout.lisp"
   :SHA256 "862cdd04c516fee93dd90b5733e5a058cecf03807cbdf067781a98d48c027ba9"
   :BYTES 277)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-CGcPOD/0/scan-13.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-CGcPOD/0/scan-13.lisp"
   :SHA256 "d2a6cce6b08f0cce52f8acf906d2d3de14dc7012a8281e5d5924d70c3f9d8c6f"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-CGcPOD/0/scan-13.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-CGcPOD/0/scan-13.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-CGcPOD/0/scan-13.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-CGcPOD/0/scan-13.stdout.log"
   :SHA256 "efc21b444e014525ac0d176e57004e138b598872709a192c19ea0bee3d3cd071"
   :BYTES 4074)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-CGcPOD/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-CGcPOD/0/session.pid"
   :SHA256 "8f7535ddf364494005516a5deeedadde1bd00f16c5ca9eb4826c4dc21ca0c26f"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-CGcPOD/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-CGcPOD/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-CGcPOD/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-CGcPOD/0/stdout.lisp"
   :SHA256 "ce6268f796f2d28c818a9335b6309d2d44936c5c2fa6f247b761f1c82979d2ed"
   :BYTES 307)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/0/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/0/scan-1.lisp"
   :SHA256 "e0dda27e6928d557fd1efeb3988f6760e1a1f0476c1c2aa551562d95d4675967"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/0/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/0/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/0/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/0/scan-1.stdout.log"
   :SHA256 "914313fa330e337e83cd1269ba479a15f605b237d90a8ee06e956a99de041f64"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/0/session.pid"
   :SHA256 "1a73e334d30887738b0d413af34c843d94632b653433b0f9b4e97500c46a9795"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/0/stdout.lisp"
   :SHA256 "1231bfb718dd0886eb6e4410ed6f75d46d369da6ff1d92f4ed01356cbda7ad93"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/1/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/1/scan-2.lisp"
   :SHA256 "7c9ce176a95e62df25e9425b2d363cf4745d43b4f583f9b4a9fd40582959aef9"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/1/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/1/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/1/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/1/scan-2.stdout.log"
   :SHA256 "f1e610d85c8a582cfa4cd7db805906c2e9393e9cde42b7e4c3c61426fc430fdf"
   :BYTES 4062)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/1/session.pid"
   :SHA256 "d49469e631d970ad59f25e7a3550a9810bbbe21931107555056ffa49f2b10785"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/1/stdout.lisp"
   :SHA256 "b73bf7936c9411917b15b1b938645b069034c70e7cfc6a3a71e5ec231f0feffd"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/2/scan-3.lisp"
   :SHA256 "2e158d06de1f5fa4cd4e078c74b849f0235e0c0a75336ec04e58b5e8a4d3b256"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/2/scan-3.stdout.log"
   :SHA256 "366ea2ffb79fa7e1713ba5e5431e748b36eff2638dd4217788fb9d4d4c69a22c"
   :BYTES 4062)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/2/session.pid"
   :SHA256 "97e44b556413d551ad787b8d4a76dfcd807f45e58a5324fbde7c00b7e16fe33a"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/2/stdout.lisp"
   :SHA256 "566235ed80993ae8225c787d7c3455e6f1deaf5fb96c034fe21b8d1873335c00"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/3/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/3/scan-4.lisp"
   :SHA256 "cd962ea834ea16cf60e9dcde6604eb61c8116622299bf57026a7c0f2b5a8c391"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/3/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/3/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/3/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/3/scan-4.stdout.log"
   :SHA256 "340a4ddab1e4bdee3cf6607fc4755b6c368829f68c474561e3c45f58678863c3"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/3/session.pid"
   :SHA256 "180a9c73c66ddcf2823eab8fda4474d35d29e4466b9b460b445b185b0d4ec8ce"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GomzJb/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-GomzJb/3/stdout.lisp"
   :SHA256 "104d8544f9b470ed8279ce3a9efa805fca2808fc72cd49d61451713a606d73f3"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JqDq6P/0/scan-18.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-JqDq6P/0/scan-18.lisp"
   :SHA256 "89f575b6d0e8e148c69178065efdee1a073ea337c8cb315ca8992fd635b1f3c3"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JqDq6P/0/scan-18.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-JqDq6P/0/scan-18.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JqDq6P/0/scan-18.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-JqDq6P/0/scan-18.stdout.log"
   :SHA256 "555c35c6b512765345d7ff9b96fdfb97a684200da990dee4bbe33d82a1a22cc4"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JqDq6P/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-JqDq6P/0/session.pid"
   :SHA256 "432a0fc824ffed4fcfbafe61eaa461d2b47e104621f150559a44a75e93c4cd1f"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JqDq6P/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-JqDq6P/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JqDq6P/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-JqDq6P/0/stdout.lisp"
   :SHA256 "96258bd07a9c21c3ebe344ca8100bb76647e4425f72c6a857d36d32d0dc00c41"
   :BYTES 474)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-KtlztC/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-KtlztC/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-KtlztC/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-KtlztC/0/stdout.lisp"
   :SHA256 "aacc7704cf971078c6da1f7bc12c40825ce337ae972df9a7047b250251ac65d7"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-KtlztC/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-KtlztC/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-KtlztC/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-KtlztC/1/stdout.lisp"
   :SHA256 "5aa6c7e76701096611a48e61ce8c24ddd30834c08d82da2f820b9a113dfa8da8"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-KtlztC/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-KtlztC/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-KtlztC/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-KtlztC/2/stdout.lisp"
   :SHA256 "c33fbd57b0c5e21c548df897966bf7f3b339f428fcaed3791ef9dd325702d823"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-KtlztC/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-KtlztC/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-KtlztC/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-KtlztC/3/stdout.lisp"
   :SHA256 "cd2a0dc39368b45bbbe3bfea064d376b42ff459b861331f440389b0233713427"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MHP19s/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MHP19s/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MHP19s/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MHP19s/0/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MHP19s/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MHP19s/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MHP19s/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MHP19s/1/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MHP19s/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MHP19s/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MHP19s/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MHP19s/2/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MHP19s/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MHP19s/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MHP19s/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MHP19s/3/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MfchKS/0/scan-20.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MfchKS/0/scan-20.lisp"
   :SHA256 "de8b2bfe4fae95a88f2c979856ccfb35390d6cc7bd00c861c7dfda867c7583e0"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MfchKS/0/scan-20.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MfchKS/0/scan-20.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MfchKS/0/scan-20.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MfchKS/0/scan-20.stdout.log"
   :SHA256 "f1072a879a982270fbb413bd7ce18549c28c5be3b06065da99222f273b6eed22"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MfchKS/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MfchKS/0/session.pid"
   :SHA256 "0f172b43b4d4214d70e624b93595396fe1f927e32991d92227a187422af42f34"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MfchKS/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MfchKS/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MfchKS/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-MfchKS/0/stdout.lisp"
   :SHA256 "fc4b632d5b8f238660e87ab2ccd2387d238c70959c7f849cff8e605937a27cd5"
   :BYTES 472)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NSXZsM/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-NSXZsM/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NSXZsM/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-NSXZsM/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NSXZsM/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-NSXZsM/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NSXZsM/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-NSXZsM/1/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NSXZsM/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-NSXZsM/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NSXZsM/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-NSXZsM/2/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NSXZsM/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-NSXZsM/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NSXZsM/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-NSXZsM/3/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OPszmv/0/scan-26.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OPszmv/0/scan-26.lisp"
   :SHA256 "e28d4286998895f458594bc670f8178561529f4fe63294c739b03b0a09567eb2"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OPszmv/0/scan-26.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OPszmv/0/scan-26.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OPszmv/0/scan-26.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OPszmv/0/scan-26.stdout.log"
   :SHA256 "3a0e776126505ecf21d22b6992540f66578aeaed9e0162906a9035dd2c1a98b3"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OPszmv/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OPszmv/0/session.pid"
   :SHA256 "d47fa3b414b10ea13d8f4b8840835f08967304ed8f33e4910f2fe3b5bcb67d7d"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OPszmv/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OPszmv/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OPszmv/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OPszmv/0/stdout.lisp"
   :SHA256 "1b4b8a08944662f6cee8f876b8da4c5459953de2446b992850a31fbabf3da2fb"
   :BYTES 498)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OkJX7T/0/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OkJX7T/0/scan-9.lisp"
   :SHA256 "5ad68000875bca115c8b657bdf2d69882860675071f258a6fab45c588f5291a8"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OkJX7T/0/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OkJX7T/0/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OkJX7T/0/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OkJX7T/0/scan-9.stdout.log"
   :SHA256 "1b4346c039f2341f59b448132ca1f4b10a763693b27831b72099d53097f0731a"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OkJX7T/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OkJX7T/0/session.pid"
   :SHA256 "f0033a7c35c473e523c7936ce53482359828e57b18385005d883d2560e894357"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OkJX7T/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OkJX7T/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OkJX7T/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OkJX7T/0/stdout.lisp"
   :SHA256 "fcea65a7685a278396e48d074ae3ad57413a3901e93f2f463af4d1474180164b"
   :BYTES 293)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/0/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/0/scan-1.lisp"
   :SHA256 "52e6562cf3df01b494be38c44b1f350b0572a6e327a058bf31e3aa750e868a92"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/0/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/0/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/0/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/0/scan-1.stdout.log"
   :SHA256 "2572ad6397ddfc94bde5af733ce0786626c54daedeca9be755c5c100e59ff338"
   :BYTES 4074)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/0/session.pid"
   :SHA256 "29fcae0742f8ddee4198d3a7b6987ee0918ce0391cb1b4e14d5c5ebf883b0fa6"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/0/stdout.lisp"
   :SHA256 "1231bfb718dd0886eb6e4410ed6f75d46d369da6ff1d92f4ed01356cbda7ad93"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/1/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/1/scan-3.lisp"
   :SHA256 "4f7ca07d7c5a7ca2e8cc7d74e8e4671f8608ffc8a7be2749c1bca015925fff6f"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/1/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/1/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/1/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/1/scan-3.stdout.log"
   :SHA256 "bd263d650b78d82d15862a6acf23c081e0a6b640d8b9a1053b5279a5535e5ba9"
   :BYTES 4062)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/1/session.pid"
   :SHA256 "c959a6283d80eb9e8257ca1c9a68131a7c51d33ec2b7e6e18d69f7ca7b1485f1"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/1/stdout.lisp"
   :SHA256 "b73bf7936c9411917b15b1b938645b069034c70e7cfc6a3a71e5ec231f0feffd"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/2/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/2/scan-2.lisp"
   :SHA256 "ae2fe38fb3d00033d05981199e15033624b55741ff209cb527c63effd9207ee8"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/2/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/2/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/2/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/2/scan-2.stdout.log"
   :SHA256 "36b9c99e1ea550653d51c4cd9f56cca9d2d1b2b9800ae70b0eadbe2856b5bacf"
   :BYTES 4062)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/2/session.pid"
   :SHA256 "f2fdba03e84681ed0dfecbdbcd405774bd7dfbbd69113edd4e09ec03261aaaef"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/2/stdout.lisp"
   :SHA256 "566235ed80993ae8225c787d7c3455e6f1deaf5fb96c034fe21b8d1873335c00"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/3/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/3/scan-4.lisp"
   :SHA256 "977d18d5e386bd5786f52b66edfba3755a54f06c665bfc8071ff8e642891e4e3"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/3/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/3/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/3/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/3/scan-4.stdout.log"
   :SHA256 "fc91f6b7407d8d4282e0c0c4e576b4b94ed94ba5f2e4a115e04bce2567975ad0"
   :BYTES 4062)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/3/session.pid"
   :SHA256 "64ffb3317427779812160513c7c1f39a8c556a3fa833a6788ad8f68fe0d9421e"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OteXwU/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-OteXwU/3/stdout.lisp"
   :SHA256 "104d8544f9b470ed8279ce3a9efa805fca2808fc72cd49d61451713a606d73f3"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PLIfuu/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-PLIfuu/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PLIfuu/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-PLIfuu/0/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PLIfuu/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-PLIfuu/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PLIfuu/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-PLIfuu/1/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PLIfuu/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-PLIfuu/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PLIfuu/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-PLIfuu/2/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PLIfuu/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-PLIfuu/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PLIfuu/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-PLIfuu/3/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-T0b7yh/0/scan-14.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-T0b7yh/0/scan-14.lisp"
   :SHA256 "ff2d66c79eaeb4b990f18b7de4e6e67197cddb88356591d003e26dc030b7ebf4"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-T0b7yh/0/scan-14.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-T0b7yh/0/scan-14.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-T0b7yh/0/scan-14.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-T0b7yh/0/scan-14.stdout.log"
   :SHA256 "8f6783fa01692f8d040f434a839a0fe1e2b7c673557759f49ae064b392b6907c"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-T0b7yh/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-T0b7yh/0/session.pid"
   :SHA256 "d2497fac4cf4eaad2b83fa4d2024be5ef15eca7f56050a60d79198c1d496c5b0"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-T0b7yh/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-T0b7yh/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-T0b7yh/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-T0b7yh/0/stdout.lisp"
   :SHA256 "75f066c7e266fb34cfd443606bf502898c74e40dcf185f3d6b5d74e31663f5bd"
   :BYTES 308)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-X11ZPP/0/scan-17.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-X11ZPP/0/scan-17.lisp"
   :SHA256 "4971d5e1adc1dfb4763440f71b02d4278946783373a33f1122a774c057e23580"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-X11ZPP/0/scan-17.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-X11ZPP/0/scan-17.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-X11ZPP/0/scan-17.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-X11ZPP/0/scan-17.stdout.log"
   :SHA256 "2768fb80c68ae69eb8cab0037a7388af3385857867415cb1d1c0f92f83e41895"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-X11ZPP/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-X11ZPP/0/session.pid"
   :SHA256 "8b8aacb40cf4c91afecd5ba9565a7bde64f435aaf3a6604a1e6737f14d959374"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-X11ZPP/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-X11ZPP/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-X11ZPP/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-X11ZPP/0/stdout.lisp"
   :SHA256 "7311e891fab097bb2331332cf7837536506fb4d23df9da7708144c665c7d467d"
   :BYTES 454)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XrRwSj/0/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-XrRwSj/0/scan-10.lisp"
   :SHA256 "969855368c443c22f6c97909712ad16983b527584233b7b6a4370b1fcf68ca63"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XrRwSj/0/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-XrRwSj/0/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XrRwSj/0/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-XrRwSj/0/scan-10.stdout.log"
   :SHA256 "05738d70e0cf6178c8ee8b7ba5795d2ffab4b3caa2f1eed3727342326b555bc0"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XrRwSj/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-XrRwSj/0/session.pid"
   :SHA256 "4baaf4cefa68546a04cf40a99d313405dc0334758ba549e5491967543fc6b2f7"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XrRwSj/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-XrRwSj/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XrRwSj/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-XrRwSj/0/stdout.lisp"
   :SHA256 "fd0d1e524f5176b3ef6a606512d8561fa6c0933b85779babb7089e09d4177ba5"
   :BYTES 295)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aKRNot/0/scan-29.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-aKRNot/0/scan-29.lisp"
   :SHA256 "c13e74d793570eaf8984bbc4d42e4be689ba024b5e343bddbb400654aa0bf133"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aKRNot/0/scan-29.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-aKRNot/0/scan-29.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aKRNot/0/scan-29.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-aKRNot/0/scan-29.stdout.log"
   :SHA256 "c85c201e970a1c01bbd03d5734669e47eb65380138cf39561d405b527dba786a"
   :BYTES 4080)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aKRNot/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-aKRNot/0/session.pid"
   :SHA256 "4d42f25e51f05ec88208af734b772fda796ce5e19d5fbe2c61f442e7e026605e"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aKRNot/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-aKRNot/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aKRNot/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-aKRNot/0/stdout.lisp"
   :SHA256 "dd004dc341c90b533173144dbdde51a3f6c49460591f99f2002fbcc0d2f10ad9"
   :BYTES 514)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bd67Jc/0/scan-19.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-bd67Jc/0/scan-19.lisp"
   :SHA256 "7f0b21218b08566b7055708c7c86d635d5f3caeb6fccf380ba37f3301ae29fb5"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bd67Jc/0/scan-19.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-bd67Jc/0/scan-19.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bd67Jc/0/scan-19.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-bd67Jc/0/scan-19.stdout.log"
   :SHA256 "e08226c6a5f92d84f5c19f11ce07ce8135a9ba4c81c07406d227586d6f56950c"
   :BYTES 4074)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bd67Jc/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-bd67Jc/0/session.pid"
   :SHA256 "483f093a5680e73f81ee332ab3e5eedcbab5beb73b3faf3172c4d3dfe2eac1d4"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bd67Jc/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-bd67Jc/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bd67Jc/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-bd67Jc/0/stdout.lisp"
   :SHA256 "538e6973f461e59b6345fd8dc491a1d862f481d51014f6f992439e4321e9af85"
   :BYTES 697)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/0/scan-32.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/0/scan-32.lisp"
   :SHA256 "60805918515dedf9dd9acdf465f4133aa950a64e1d5e8974251e68c111c59716"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/0/scan-32.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/0/scan-32.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/0/scan-32.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/0/scan-32.stdout.log"
   :SHA256 "36ba75b081c0f823a29f4bfe8c5747282a78d13ad1fae2208e9bee815a4a0044"
   :BYTES 4224)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/0/session.pid"
   :SHA256 "ae45d2622924b93714109b7159fe9aa53c0dde39355574ba7fdb730a17c5fa9c"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/0/stdout.lisp"
   :SHA256 "6878a3341573d6e8ae62ea57412187323cf4efe323ef1841e39ec047bbe16e55"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/1/scan-31.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/1/scan-31.lisp"
   :SHA256 "abbb7bc4a62147449d6643af2ddff7459edb108fa36dca60e3dc495c02fd8eb5"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/1/scan-31.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/1/scan-31.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/1/scan-31.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/1/scan-31.stdout.log"
   :SHA256 "75dd774d208628c912e127766431f0e3bb375f2fa3787631d8ced2730e31009f"
   :BYTES 4230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/1/session.pid"
   :SHA256 "aa7202c5a86d9f4646fbadc8007ccf3b41eb2d66f3b4b8238cd51ea5e2662abe"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/1/stdout.lisp"
   :SHA256 "2d198215ad91843522a2c6dc23cbe9198c09b99f272a2addeef207693d9c9a20"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/2/scan-34.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/2/scan-34.lisp"
   :SHA256 "6281d0ea5583c916e33ad6efc70ba6808e338bb37910690d91fb30bd520ea40b"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/2/scan-34.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/2/scan-34.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/2/scan-34.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/2/scan-34.stdout.log"
   :SHA256 "03ff7260b4454d24c5e203ebf4b81ec7685ce49dcf231061ef97e7f01dde4c6b"
   :BYTES 4224)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/2/session.pid"
   :SHA256 "f588e2b4420ca7d77da6886bc86cc828cbc3726879554dc6397b760b2c154991"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/2/stdout.lisp"
   :SHA256 "f0a350a50187be1fc4e8a65a11fa1e6e2f111ac798f95fa1d519aaaf4288d1b3"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/3/scan-33.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/3/scan-33.lisp"
   :SHA256 "964e498fc0dca3185ec4fee6af646c55b3af49e9fdd404337cf381fa1142c128"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/3/scan-33.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/3/scan-33.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/3/scan-33.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/3/scan-33.stdout.log"
   :SHA256 "544b8e2f44253ea93e923d62d951beac01a0a0b87c5eaf7bac6e1c366b88cb15"
   :BYTES 4224)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/3/session.pid"
   :SHA256 "602cfed56692da7c9188361cc445f4cb2dce49fc6410343815397dbbe1529fef"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-fHUb2Y/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-fHUb2Y/3/stdout.lisp"
   :SHA256 "c85d7bf24940b9a0c7f982fa62e7526db4f45c5d59a9037c0806b32de62ca352"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-g3Q0w9/0/scan-15.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-g3Q0w9/0/scan-15.lisp"
   :SHA256 "55f204a90cc566699be4ab56309b49769a79bd046cfdc486c1d597792cc6d352"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-g3Q0w9/0/scan-15.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-g3Q0w9/0/scan-15.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-g3Q0w9/0/scan-15.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-g3Q0w9/0/scan-15.stdout.log"
   :SHA256 "eea53bafb01e1d946c1e0542e7c338cdeca05d340fd04b27e3494bf501305a2b"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-g3Q0w9/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-g3Q0w9/0/session.pid"
   :SHA256 "e18346fb763294b89c975c289c7856bfbfb9ae56ab095f63caaebb6dd00c2ff5"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-g3Q0w9/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-g3Q0w9/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-g3Q0w9/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-g3Q0w9/0/stdout.lisp"
   :SHA256 "28078dc5d2c6f036fdc85adedba77e18b91e5cb95a6de981ab5a38117cf47d26"
   :BYTES 295)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/0/scan-21.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/0/scan-21.lisp"
   :SHA256 "dfabff47e638b9a5f430978c698fef1b385dc7aa4f9dd9f6ca7255a9b4990cc0"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/0/scan-21.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/0/scan-21.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/0/scan-21.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/0/scan-21.stdout.log"
   :SHA256 "35a211da675fe958070a91802e07c01b4721653645bd86deba65f1d2a65d5cbd"
   :BYTES 4086)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/0/session.pid"
   :SHA256 "9fd0291d033187c2a26ede456296c11a226569677d25c33953a58d4c805944f2"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/0/stdout.lisp"
   :SHA256 "89ebaf5adb50ecfd62411b3a9f714caf32a85af9f0c592eb8cce8bc7dc38656e"
   :BYTES 750)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/1/scan-22.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/1/scan-22.lisp"
   :SHA256 "d40a832ba4235a935f62bd7ec5d757bf3c6c5f5418760fa72e80c32321ea7024"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/1/scan-22.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/1/scan-22.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/1/scan-22.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/1/scan-22.stdout.log"
   :SHA256 "b68f89eed7023eb34c9414a83d9e32756e07cb25355c22872c666e6b9fcca864"
   :BYTES 4086)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/1/session.pid"
   :SHA256 "653c4d00806b623fbcaf8e158cfeea1f8ad8df8df487d52e053a573129b73029"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/1/stdout.lisp"
   :SHA256 "a3727e9dd7ec6806ade38def919384cc0a5fd51958643d8286c73a5e6fd3e174"
   :BYTES 752)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/2/scan-24.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/2/scan-24.lisp"
   :SHA256 "fa6958abeb6c80676f593620654f59813eab3ca37d0b205b564c38322d17c511"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/2/scan-24.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/2/scan-24.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/2/scan-24.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/2/scan-24.stdout.log"
   :SHA256 "f60c5be78c3fb33ea7473b34e9a175152ccd8321b2dfb0fa52389a0410cb7706"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/2/session.pid"
   :SHA256 "f29964ad4ecc0ce334b8ecb9d3d34f78a4f7f81586d6dc223905ada0c79e1aab"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/2/stdout.lisp"
   :SHA256 "b7cb748b1c6d20a91818042a56fa2cb82d65b267090a25ebbd8e5758773dfffa"
   :BYTES 286)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/3/scan-23.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/3/scan-23.lisp"
   :SHA256 "0e2b64c8e1808c6dc6b76dbbf45c69bad6c34042f784ab7666b1011c90745f0a"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/3/scan-23.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/3/scan-23.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/3/scan-23.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/3/scan-23.stdout.log"
   :SHA256 "5660665c105c0ed7fddd6e7aac92e7edce7d2693741672f973d6528324a2b92e"
   :BYTES 4074)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/3/session.pid"
   :SHA256 "58bbcf329d3006001ed5971ba82886806e5d38b79f707de5dc272bffce8b2158"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jrgn1T/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jrgn1T/3/stdout.lisp"
   :SHA256 "b78499312eb8b40ab5b55730ef97a0084aeb6aa46fad45881659c8801060643b"
   :BYTES 286)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jvuDlm/0/scan-16.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jvuDlm/0/scan-16.lisp"
   :SHA256 "7982cdde2539f04d875aea405694f08c9b7a9cc25b85028651db1f9b2696da3b"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jvuDlm/0/scan-16.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jvuDlm/0/scan-16.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jvuDlm/0/scan-16.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jvuDlm/0/scan-16.stdout.log"
   :SHA256 "dd90076d89a050ef165babaa8cb6270ce41f47808183982e8981a6806fdd5770"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jvuDlm/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jvuDlm/0/session.pid"
   :SHA256 "4bbd6cc02ac5a6db692e66716d1321514e6c9ad67d1f9be58907ec4123c1dbdb"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jvuDlm/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jvuDlm/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jvuDlm/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-jvuDlm/0/stdout.lisp"
   :SHA256 "4056510d3bdf5244fbe5b8e8dc14de30caf8b919a3cde109cee9a424de80f623"
   :BYTES 452)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pqMChB/0/scan-39.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-pqMChB/0/scan-39.lisp"
   :SHA256 "e8dd96c722578580f594b82288b77e81d9f6990f63d6fb0994fbbcecbb2393f9"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pqMChB/0/scan-39.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-pqMChB/0/scan-39.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pqMChB/0/scan-39.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-pqMChB/0/scan-39.stdout.log"
   :SHA256 "6b090004e50fb7f3b70acc3a584b616fb58c72516ca00006dc553539576a93b0"
   :BYTES 4260)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pqMChB/0/scan-40.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-pqMChB/0/scan-40.lisp"
   :SHA256 "0ef09615ff8f01bd63f587f08e7fc2c515f96550f6cf388d7a0967a5d90f1f14"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pqMChB/0/scan-40.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-pqMChB/0/scan-40.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pqMChB/0/scan-40.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-pqMChB/0/scan-40.stdout.log"
   :SHA256 "ea1fe36a18aa0aa377651513f6fc6485e9a0db7c1bc1cc2dd108564517de078e"
   :BYTES 4254)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pqMChB/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-pqMChB/0/session.pid"
   :SHA256 "e832ddb0fbedbbbafc98298991ba2cddc8264ed4734e51ec79b8386868f61811"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pqMChB/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-pqMChB/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pqMChB/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-pqMChB/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vN4Orx/0/scan-12.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-vN4Orx/0/scan-12.lisp"
   :SHA256 "ed4341de54b51c584a292548b881a812ca7462da9da29e7051647eff01c2b60b"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vN4Orx/0/scan-12.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-vN4Orx/0/scan-12.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vN4Orx/0/scan-12.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-vN4Orx/0/scan-12.stdout.log"
   :SHA256 "9331992a8eed84e4d9ac33d3cd55ad8c55a780a780d62ce477f6519b550e618d"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vN4Orx/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-vN4Orx/0/session.pid"
   :SHA256 "27c884fcfb10d47d58cf19dfc87b62ca618b6ff85f432deb762b729689c199e5"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vN4Orx/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-vN4Orx/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vN4Orx/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-vN4Orx/0/stdout.lisp"
   :SHA256 "4a4030d9904b1bf9fce3243194b990cf8a9ac2d6144bee8797dde7ce46466693"
   :BYTES 308)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xDKGsX/0/scan-41.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xDKGsX/0/scan-41.lisp"
   :SHA256 "d4c858421d99610a7fdbef5660e8d7d8a592c7ebc2100ba8b6902533d92fc027"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xDKGsX/0/scan-41.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xDKGsX/0/scan-41.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xDKGsX/0/scan-41.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xDKGsX/0/scan-41.stdout.log"
   :SHA256 "52cec94369a9179d9dcbebb6080dd845646e7d94d812421686a2c4dc847e7caf"
   :BYTES 4260)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xDKGsX/0/scan-42.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xDKGsX/0/scan-42.lisp"
   :SHA256 "4db083c076fca17e98dff0568bd71bee3440838f1ed33e099646703517e6ea66"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xDKGsX/0/scan-42.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xDKGsX/0/scan-42.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xDKGsX/0/scan-42.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xDKGsX/0/scan-42.stdout.log"
   :SHA256 "fbc15085fd3f9f6138a28edd7466e97f37f02a004a785bccc026cfbc406fdc1a"
   :BYTES 4254)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xDKGsX/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xDKGsX/0/session.pid"
   :SHA256 "cb1407588ae81f6d9eae9682c24f739ec1eb2c43c04cfe1fab9403b50bfa8d11"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xDKGsX/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xDKGsX/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xDKGsX/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xDKGsX/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xv63r0/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xv63r0/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xv63r0/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xv63r0/0/stdout.lisp"
   :SHA256 "f5c7e34dea5585cf1caa0161ff6797f3b8cf5c39ba69830ff50b0532b5d10a95"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xv63r0/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xv63r0/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xv63r0/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xv63r0/1/stdout.lisp"
   :SHA256 "f5c7e34dea5585cf1caa0161ff6797f3b8cf5c39ba69830ff50b0532b5d10a95"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xv63r0/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xv63r0/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xv63r0/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xv63r0/2/stdout.lisp"
   :SHA256 "f5c7e34dea5585cf1caa0161ff6797f3b8cf5c39ba69830ff50b0532b5d10a95"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xv63r0/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xv63r0/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xv63r0/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/support/evidence-check-xv63r0/3/stdout.lisp"
   :SHA256 "f5c7e34dea5585cf1caa0161ff6797f3b8cf5c39ba69830ff50b0532b5d10a95"
   :BYTES 268))
 :LIMITS (:NEGATIVE-NESTED-SELF-TEST-FIXTURES-EXCLUDED))
