(:KIND :GROUP-BUFFER-TAIL-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "group-buffer-close" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-final-archive" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-identity-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "group-buffer-closing-archive" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE))
 :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-close/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-close/conservazione.lisp"
   :SHA256 "18af3951977ccb252480349bc6bbaf09300fce5ef3248d410f1432cbf6bdc2fe"
   :BYTES 1168)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-close/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-close/report.lisp"
   :SHA256 "298303b3da109a1a19d2fb3df0b93cef54f2fd6b2dc089aaf0dc798a5e0e282b"
   :BYTES 364199)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-final-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-final-archive/conservazione.lisp"
   :SHA256 "34f1ae392d2262b37e1ecd7031283ca79ee49663fd8317e0b23e2aba4f33151b"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-final-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-final-archive/report.lisp"
   :SHA256 "0d3c8b05912f8489d1ee222d113069ee667a6aa3d06055b4baeb30415d5dd71d"
   :BYTES 363517)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-identity-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-identity-final/conservazione.lisp"
   :SHA256 "705d60e7d0606749ceae913b77b3f62b78b53aa8ce88224db4a8bf62d131c9d7"
   :BYTES 1186)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-identity-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-identity-final/report.lisp"
   :SHA256 "b71d69f58ebd13de7cbd238d24420afa0e4d24fe5d90d216a5184696d29a5cdc"
   :BYTES 363503)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-closing-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-closing-archive/conservazione.lisp"
   :SHA256 "4e9e2a7f342b407d2f461e1e66e0c6b03ac38e6d7ea928382c66b2da22c372fa"
   :BYTES 1188)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/group-buffer-closing-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-closing-archive/report.lisp"
   :SHA256 "7962a3e126c6bda6204e9c2bf99efdddcfb9f9eb4710b32420739f858c3b12b1"
   :BYTES 363501))
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-group-buffer/commands/group-buffer-closing-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363501 :STORED-BYTES 116672 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363501 :UNCOMPRESSED-SHA256
    "7962a3e126c6bda6204e9c2bf99efdddcfb9f9eb4710b32420739f858c3b12b1"
    :COMPRESSED-BYTES 116356 :COMPRESSED-SHA256
    "ef57e4a54bd011f8c9f4f9bc96581fb710bd5a0eccb9f59e7101eed1a6f19e0e")))
 :DRIVER-SHA256
 "3285174b2b0794a5d84b53fbdd67218234e82d4ee975ddf72caf1d7ec244a4ae")
