(:KIND :RECEIVE-TAIL-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "receive-close" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-final-archive" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-identity-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE))
 :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-close/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-close/conservazione.lisp"
   :SHA256 "c3758422da9ba6ce67275e6a46aaccd239cb01ea07661b8f567a5388151bb25c"
   :BYTES 1156)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-close/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-close/report.lisp"
   :SHA256 "96e953e4342632b8f3eb095d74cdd68bad336ff4926b0708b3bca9ddf4ea4c33"
   :BYTES 363517)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-final-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-archive/conservazione.lisp"
   :SHA256 "33d02bc6baabe0c48cf0c6af2280561925591cd049d776758cb6345628967906"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-final-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-archive/report.lisp"
   :SHA256 "d313bd8db8754c79277340b2b03c6276d25f272a4031bd41774ba28eefa2ee4c"
   :BYTES 362845)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-identity-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-identity-final/conservazione.lisp"
   :SHA256 "5e9a82c819fdb6c1a1f6f1425831e11ccd7e8cb3eca0623465cac01e66531db6"
   :BYTES 1176)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-identity-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-identity-final/report.lisp"
   :SHA256 "32e56e9030d78710c37548f91293941317d8a12eeab274f6de823784b7595798"
   :BYTES 362830))
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-identity-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362830 :STORED-BYTES 116476 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362830 :UNCOMPRESSED-SHA256
    "32e56e9030d78710c37548f91293941317d8a12eeab274f6de823784b7595798"
    :COMPRESSED-BYTES 116160 :COMPRESSED-SHA256
    "3977a0240345fcd79cf8ed6c3542fb90d8daf4927e94f818adcb3aa99b079b3b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362845 :STORED-BYTES 116462 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362845 :UNCOMPRESSED-SHA256
    "d313bd8db8754c79277340b2b03c6276d25f272a4031bd41774ba28eefa2ee4c"
    :COMPRESSED-BYTES 116146 :COMPRESSED-SHA256
    "af18555742a8ce5219664dbf310c76d8a1a4c4b0eab1332e56cd6c0e7d8e27ef"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-close/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363517 :STORED-BYTES 116854 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363517 :UNCOMPRESSED-SHA256
    "96e953e4342632b8f3eb095d74cdd68bad336ff4926b0708b3bca9ddf4ea4c33"
    :COMPRESSED-BYTES 116538 :COMPRESSED-SHA256
    "4c63327c15f4b76a427a06495d2bbbffce9db1cee1c6726cc2e2bcbc4414fe5b")))
 :DRIVER-SHA256
 "0e0cd9585fdbb83253ce38c8eb4538615d8ec0a45fcfd3adf5ad1134b063c1d4")
