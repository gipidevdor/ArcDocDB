(:KIND :RECEIVE-EVIDENCE-CLOSURE :STATUS :PASSED :UNIVERSAL-TIME 4002554522
 :VERIFIED-FILES 710 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/source-identity.lisp"
   :STATUS :OK :ORIGINAL-BYTES 182164 :STORED-BYTES 58669 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "source-identity.lisp.gz" :UNCOMPRESSED-BYTES 182164 :UNCOMPRESSED-SHA256
    "db1b5890e777b1929c6ef07700807c4bc9c03360c58ec0fa2d24f98f8f0c98e7"
    :COMPRESSED-BYTES 58345 :COMPRESSED-SHA256
    "a5bb950913b8fd81c3c8e0b20c50823ea029caf31127042b19fa1f8bcb2c9d9c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21153 :STORED-BYTES 3970 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "ready-spike-analysis.lisp.gz" :UNCOMPRESSED-BYTES 21153
    :UNCOMPRESSED-SHA256
    "8c5bcf32d75b1f4691c0a176fa0c2341cd38a35ede0cc93e9c5d6cb68624b596"
    :COMPRESSED-BYTES 3643 :COMPRESSED-SHA256
    "dd21f6feb9405cd3f55aedeed81e97fbabba3228feaab8f5d5eb69c3ff43cfea"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21156 :STORED-BYTES 3994 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "ready-only-spike-analysis.lisp.gz" :UNCOMPRESSED-BYTES 21156
    :UNCOMPRESSED-SHA256
    "e9a793e405a4b2caf40c0c0322d79793efb23694c7f53d0a30f4489ea846fd6a"
    :COMPRESSED-BYTES 3661 :COMPRESSED-SHA256
    "7e38e3a9305f50a093b02ac0d4508661dc055a7bbc1e7f07f841d797fab7acef"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21170 :STORED-BYTES 4065 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "paired-repeat-analysis.lisp.gz" :UNCOMPRESSED-BYTES 21170
    :UNCOMPRESSED-SHA256
    "94495a97c7f4ffa618951f0c3bd00ef62149d9c5766cd24d08fd300540248a53"
    :COMPRESSED-BYTES 3735 :COMPRESSED-SHA256
    "746242877f2f6b35c7eb402d218f963b8cbcbab2dad8b35bc2e0a722e01d54b1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21126 :STORED-BYTES 3938 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "paired-final-analysis.lisp.gz" :UNCOMPRESSED-BYTES 21126
    :UNCOMPRESSED-SHA256
    "743743e3d993e84dbf30fc992de701e615db013b3c8115a3b63a3c2015ed1d82"
    :COMPRESSED-BYTES 3610 :COMPRESSED-SHA256
    "6d90700986020563f779398cef2ba951b695135cf12fa58d0f895458ccd92672"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21155 :STORED-BYTES 3970 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "optimized-repeat-analysis.lisp.gz" :UNCOMPRESSED-BYTES 21155
    :UNCOMPRESSED-SHA256
    "7a3fcde2d12a8ce54bc71575bacf15c6fe3a2c9ca5fe9dbba1f2978986532e75"
    :COMPRESSED-BYTES 3637 :COMPRESSED-SHA256
    "b922e4b5b97f2be276560f44696201ded08a7bd1bf40469f9f304fa62cb06de5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 21158 :STORED-BYTES 4053 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "optimized-final-analysis.lisp.gz" :UNCOMPRESSED-BYTES 21158
    :UNCOMPRESSED-SHA256
    "21bd8d201f40d5e802592ad142066d1a4bd7e7468fd70dee5973085c2fd26c5a"
    :COMPRESSED-BYTES 3721 :COMPRESSED-SHA256
    "afaa1df6ce2540255060a977aed2caade1e51338ed2cec9033e428ade58263ed"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-archive.lisp"
   :STATUS :OK :ORIGINAL-BYTES 216062 :STORED-BYTES 21478 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-archive.lisp.gz" :UNCOMPRESSED-BYTES 216062 :UNCOMPRESSED-SHA256
    "456e4b98a6d178dc4dcdc3716657eec1c36a9535754ba47476568f916d8f34f8"
    :COMPRESSED-BYTES 21156 :COMPRESSED-SHA256
    "7bf8b7075d805e33b8170a86e651c28446693ded0577cbd05fa6d473e7bbcd83"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/comparison-final-candidate-repeat.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20476 :STORED-BYTES 3695 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "comparison-final-candidate-repeat.lisp.gz" :UNCOMPRESSED-BYTES 20476
    :UNCOMPRESSED-SHA256
    "23a9d2ff00d20a42b37dccbd47a422ea2ff286d24bd2c600d4c3800080731c49"
    :COMPRESSED-BYTES 3354 :COMPRESSED-SHA256
    "38adda1febf16b49f9b6b2461ac34798d151010926acf7b8e041235f5e950a0d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/comparison-candidate.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20476 :STORED-BYTES 3679 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "comparison-candidate.lisp.gz" :UNCOMPRESSED-BYTES 20476
    :UNCOMPRESSED-SHA256
    "db2a2bace2875d9a8e82196dea55db0ceca6b2c1c24908d4122c5177fe473565"
    :COMPRESSED-BYTES 3352 :COMPRESSED-SHA256
    "271ace10e3d6679a6d9d773a34ff21bfac43c947e070d47c325118d6bcd303b8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9722 :STORED-BYTES 2081 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-analysis.lisp.gz" :UNCOMPRESSED-BYTES 9722 :UNCOMPRESSED-SHA256
    "0d6be6a02d99f78ab40ab85fa4288e6a1b0367efba9b4fc686852556c81ac7d3"
    :COMPRESSED-BYTES 1758 :COMPRESSED-SHA256
    "25aacd50598803493f8f8cb8060647cc528b3e702f03d5cd7921cacba2cb7a93"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6386 :STORED-BYTES 1299 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6386 :UNCOMPRESSED-SHA256
    "ad1011690dc04973c2b88ce5cba20cfd32f51e9a848afa6a578e2d71aa9f66be"
    :COMPRESSED-BYTES 985 :COMPRESSED-SHA256
    "22884e6e3601889499824bf4a67e9fcdfb9ed79a897be4d258cb883d3a92c99e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6146 :STORED-BYTES 1159 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6146 :UNCOMPRESSED-SHA256
    "78e44b3d186d52730dc5b6372ef4ef4b56c2f987b1d62c75804ee05ff819c623"
    :COMPRESSED-BYTES 842 :COMPRESSED-SHA256
    "5d2d302af531e3056955313da395fcc07bc5e97ba0adc86dd87941e849dd7f04"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16709 :STORED-BYTES 4723 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 16709 :UNCOMPRESSED-SHA256
    "6c084b085d18be716d71741119f101ead27c13e29ca059623a31f212adeccf43"
    :COMPRESSED-BYTES 4413 :COMPRESSED-SHA256
    "9a4519ddbdd101a5773f0d227e8a9b805f54c4efd3add71d9b55ab1c9400b01b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16696 :STORED-BYTES 5642 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 16696 :UNCOMPRESSED-SHA256
    "85b01098e61d8af6821d5d8a30cf18ff3510a44b1a8a09629182f3907686d38f"
    :COMPRESSED-BYTES 5332 :COMPRESSED-SHA256
    "06005b5832ae32cd789f804ca14dcbba6176f16064610e1c2d025b7815d15b3a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16701 :STORED-BYTES 5199 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 16701 :UNCOMPRESSED-SHA256
    "273b3bb4fb4a2a4a718a429160a2aa790d5147e36bb75a1c71e5fa66ca549d0b"
    :COMPRESSED-BYTES 4889 :COMPRESSED-SHA256
    "ccd0d04a80f6cadd0828cc47fbeec3b70527ab4fa20e2d4b84a6661966b6c603"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16712 :STORED-BYTES 4940 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 16712 :UNCOMPRESSED-SHA256
    "bd56076b2742c7325da672e5bfb8da3797ece3a9a4cade7c2f6ebd26f1b5b516"
    :COMPRESSED-BYTES 4630 :COMPRESSED-SHA256
    "139a057fee64bb74400f9f4c46fa3a96c678165f379a4a42486daa119bfd247b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16709 :STORED-BYTES 5015 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 16709 :UNCOMPRESSED-SHA256
    "91d6f3b640d2a22673356402d930ffd0f47c61ea40b1d7fd9ca89f27df4e7b74"
    :COMPRESSED-BYTES 4705 :COMPRESSED-SHA256
    "f147e17bbe352ab2d02b6a3a8013759d723a65462a667bddbd7ca5f070c34a38"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/6-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12777 :STORED-BYTES 4081 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4.lisp.gz" :UNCOMPRESSED-BYTES 12777 :UNCOMPRESSED-SHA256
    "0cec3db46884490b88ecf65956cf18f0c1d68b7ee300c88be5eb6d05c1bbb9ea"
    :COMPRESSED-BYTES 3771 :COMPRESSED-SHA256
    "3ca4fa5a49f677700f7a31af11cfca8484e2a92997acd3f4e58cdd03039bc016"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/6-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12742 :STORED-BYTES 3893 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3.lisp.gz" :UNCOMPRESSED-BYTES 12742 :UNCOMPRESSED-SHA256
    "c5729ef1fcb91b983440fcaa2f4ff6f1c7fba6cdbc4b8e1d66a0f57fbc94f2c9"
    :COMPRESSED-BYTES 3583 :COMPRESSED-SHA256
    "b26cb86d6958bcd999a6c72cd148ef7c7a78cf0124593726d1d0cda82f87b9f7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/6-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12732 :STORED-BYTES 3811 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2.lisp.gz" :UNCOMPRESSED-BYTES 12732 :UNCOMPRESSED-SHA256
    "bb68884d2ab12f1e341902ea33212005d2511f72ed6ed8d90fa862c8889cb065"
    :COMPRESSED-BYTES 3501 :COMPRESSED-SHA256
    "d1053942898e3bc6fbdc48005f32a0054e39298cfebb430113ef13ad64a8f1ef"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/6-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12768 :STORED-BYTES 4169 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1.lisp.gz" :UNCOMPRESSED-BYTES 12768 :UNCOMPRESSED-SHA256
    "fb7002640e69c640513c6c6839e642cbb5e83f279ff6e9feed87ddcae8b9a48a"
    :COMPRESSED-BYTES 3859 :COMPRESSED-SHA256
    "bfc2c7184d5f4a5a31af883f2fa04addc0ef0f29b9b871e6f117e5d33b76b2a9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/6-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12789 :STORED-BYTES 4424 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0.lisp.gz" :UNCOMPRESSED-BYTES 12789 :UNCOMPRESSED-SHA256
    "3c43bcb6f5c185f2ecc7dbd2127c70e2fb1c29214d24143aa3dc75b36568e8fa"
    :COMPRESSED-BYTES 4114 :COMPRESSED-SHA256
    "cdc7cdad4ee75c9f54b9df5d64b745a3cf5db141cf45efed7da01734c005371e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 4458 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "c7a7c7aec91c5d3c6e0c2132c765b14038842a59a0e1e535eff7a5a86167c3cf"
    :COMPRESSED-BYTES 4148 :COMPRESSED-SHA256
    "45e6558e85397955e629eec93bf5384cdc200622988e6d6f7f2027e5064ebdba"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 4115 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "5a0a6a3079d462d069d56b263d5e81ebeb8b9c9699a97bf327fb3ac9c0c67d9e"
    :COMPRESSED-BYTES 3805 :COMPRESSED-SHA256
    "ee45238fadb8b069adab7bf203b5f0d5dc4a3f22637c2e9bbd2bfcf1a39ae394"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16702 :STORED-BYTES 4665 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 16702 :UNCOMPRESSED-SHA256
    "b85637ac72592995341e1ad0b0c3de900081b39b41455033e8652a0058a9e33a"
    :COMPRESSED-BYTES 4355 :COMPRESSED-SHA256
    "8ac655913d0037affc2616f4ca57dd3ed3f574f15ebca75cd1693d5fded30a30"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 3995 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "7d5025dc31902d792c9cff5995e443917713a482ef4d000f6d167d1e899a260d"
    :COMPRESSED-BYTES 3685 :COMPRESSED-SHA256
    "4f38c8b8eb40be246a554d0b03a8825f0745b34c67a47bae83eb7531a48071e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16713 :STORED-BYTES 4401 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 16713 :UNCOMPRESSED-SHA256
    "c0db043b8fc61d3a7590a65a174a39ec9ddb75a5d3d7020515b9e6da675fc63d"
    :COMPRESSED-BYTES 4091 :COMPRESSED-SHA256
    "741748aeb0c89e4db561a28dda37c6af78200eb56a00f5293030c810669d68a7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12769 :STORED-BYTES 4678 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 12769 :UNCOMPRESSED-SHA256
    "556d666995eaf0c5b88b864ba21ab28340c7248bfd977437eca15e4d2363022e"
    :COMPRESSED-BYTES 4368 :COMPRESSED-SHA256
    "b63b6779fab170047adcb23344a5ab3383db011e78c55db5f278398eff3c3f71"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12759 :STORED-BYTES 4121 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 12759 :UNCOMPRESSED-SHA256
    "981e17555cf8dd8e17aa2664875a78bbe6d2dd1bc2bb34da42d2009ed475b83f"
    :COMPRESSED-BYTES 3811 :COMPRESSED-SHA256
    "e8458e7cfcfaeb159ccbd61c37dbeb5c0d1acf7e61275c019f6269ec1c042d92"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12767 :STORED-BYTES 4180 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 12767 :UNCOMPRESSED-SHA256
    "aac942dc6cbef25a5aaea8dbc16310f056d4957fa12ec56bb053caaf875c1723"
    :COMPRESSED-BYTES 3870 :COMPRESSED-SHA256
    "017a3a747f6b42baf89d70532ec8ead19583533d9b596b090e5dc689cf36ce84"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12790 :STORED-BYTES 4473 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 12790 :UNCOMPRESSED-SHA256
    "fdb40df8690dcf32170866f873922c7c65ff98da4b221f93959e9e7484580821"
    :COMPRESSED-BYTES 4163 :COMPRESSED-SHA256
    "d7bde355d121617942d7f1affbd18cc7c1d7d6cb332a43f70d4e65de13b21da1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/baseline/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12727 :STORED-BYTES 4143 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 12727 :UNCOMPRESSED-SHA256
    "00a252cc9ae377dec32b4d54396ccb98aefc40b9d17d9fd4968c562be99c7c82"
    :COMPRESSED-BYTES 3833 :COMPRESSED-SHA256
    "a12cac1fc6e222b6c31e93c319c59b77641b67059a42d06ea00d5f80a20c8e44"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6388 :STORED-BYTES 1305 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6388 :UNCOMPRESSED-SHA256
    "a9e63beb80ec8d96cc0b32755def4b6efd86ec0c92ed54a29482c1bb88e46fa1"
    :COMPRESSED-BYTES 991 :COMPRESSED-SHA256
    "d6ed06023f4ec88ee55fdf0dcf64a88fe00ae2d2294c29c230c170db8e54c7fe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6146 :STORED-BYTES 1170 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6146 :UNCOMPRESSED-SHA256
    "872bc1f48c8ffd208a3a52c0dae319a3a5f865454202775d825435f3a01a3df1"
    :COMPRESSED-BYTES 853 :COMPRESSED-SHA256
    "32f8a4db8872ec5a491ad75d2f1a2726d0a48a79a74fc044d4b6ff2f5006c657"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16709 :STORED-BYTES 4748 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 16709 :UNCOMPRESSED-SHA256
    "7d4c824345bc3a46573bb08b7acce11380fb912a97e48b32ae8dab781c90ba7b"
    :COMPRESSED-BYTES 4438 :COMPRESSED-SHA256
    "4d197187b3ff3d7199c304441bd0868c41dac7a7b72d52ca38a0a8ac6ac49ea2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16710 :STORED-BYTES 4620 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 16710 :UNCOMPRESSED-SHA256
    "cc7a2024b3964cf03d300f7ff1f49fc815aed1e7600abaa8d25d9f8a27cfafd5"
    :COMPRESSED-BYTES 4310 :COMPRESSED-SHA256
    "b5cbd566a8cf1403ec037c76d090c701feb81f8bca14c47f9cfe0ba218273100"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16710 :STORED-BYTES 4830 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 16710 :UNCOMPRESSED-SHA256
    "9034f7dd2ce58ae3233ac0f7df13a072ba031d35d4d38f488195f1fcf1fe3643"
    :COMPRESSED-BYTES 4520 :COMPRESSED-SHA256
    "ec4c778119390650ff3b9c7a8732c24efe1c7577fc956a43708ed9eb75e86a99"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16708 :STORED-BYTES 5107 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 16708 :UNCOMPRESSED-SHA256
    "3ff3f9d9660b527f836691a22f8d03d6d9ea42f1450a0a813a1dc4fdd9eeee96"
    :COMPRESSED-BYTES 4797 :COMPRESSED-SHA256
    "f40e454cd1cd26c0be201991b119787ae706ff24d26d998077ebb56f2224b95e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16711 :STORED-BYTES 4529 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 16711 :UNCOMPRESSED-SHA256
    "567d7bdd309d0dfeb3f24b23605442e8724dbd5892629e17d5cd084d60c41a54"
    :COMPRESSED-BYTES 4219 :COMPRESSED-SHA256
    "f103ef0145cccf5c2160bebafd476c7572faf3821c042b010ed2df2da4a57e5f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/6-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12877 :STORED-BYTES 4701 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4.lisp.gz" :UNCOMPRESSED-BYTES 12877 :UNCOMPRESSED-SHA256
    "c40a7c206f49d14ec2b5c9dc0bbc5f679a6190504d94d0ad7929d2d09c367016"
    :COMPRESSED-BYTES 4391 :COMPRESSED-SHA256
    "3cbe822ce17dc8c719a29b8c84d6675936108ae49346e05e0e2ea1ba6ce30b74"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/6-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12735 :STORED-BYTES 3486 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3.lisp.gz" :UNCOMPRESSED-BYTES 12735 :UNCOMPRESSED-SHA256
    "87561fff25d35f2281da2bad3d0002f9c72b13fc3514eee735bafe2a4ab728f0"
    :COMPRESSED-BYTES 3176 :COMPRESSED-SHA256
    "05be9959c06e2a033c6bb84f5d45efee8a7d7e4a545be6aa127daebf98d59c1a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/6-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12728 :STORED-BYTES 3547 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2.lisp.gz" :UNCOMPRESSED-BYTES 12728 :UNCOMPRESSED-SHA256
    "a118eeda1123af9c8391359f3ee4a72869831f72f6353d9b6904f6f589aa9039"
    :COMPRESSED-BYTES 3237 :COMPRESSED-SHA256
    "af478401b8cea717a2658e5b5aa4927f70bcbca4bb3cd79663a77dc589fcfcda"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/6-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12732 :STORED-BYTES 3457 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1.lisp.gz" :UNCOMPRESSED-BYTES 12732 :UNCOMPRESSED-SHA256
    "023189c94dc3359558c13dc29a0f4be5f51a1e03246a6213f6a0e330dbb777f5"
    :COMPRESSED-BYTES 3147 :COMPRESSED-SHA256
    "45e2bc3f78ebf67580f166bb7731db45d8034a2707b93420b44be4e85121c7e5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/6-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12723 :STORED-BYTES 3459 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0.lisp.gz" :UNCOMPRESSED-BYTES 12723 :UNCOMPRESSED-SHA256
    "671771c23c4ef84a6a13389a905b17c4553eb3ad9308997f7f68255aa71e5ddf"
    :COMPRESSED-BYTES 3149 :COMPRESSED-SHA256
    "b245303ac6521aa1156f44ed33f299b94f45f318c2952ab0cb152ecd20a043c0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16714 :STORED-BYTES 4510 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 16714 :UNCOMPRESSED-SHA256
    "3c6be3a2df8873dc0520b9d4857140faec64386bbf18e54ab69b7e07eef916b0"
    :COMPRESSED-BYTES 4200 :COMPRESSED-SHA256
    "761dee128fe6bfc903491a7e0a6b31fc1508f55a05104c327e10159d8eb5b180"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16714 :STORED-BYTES 4287 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 16714 :UNCOMPRESSED-SHA256
    "4ca01a18a49a7a415aed9d97eb89c94062bddd1370bc167dcb19035e8e5e9179"
    :COMPRESSED-BYTES 3977 :COMPRESSED-SHA256
    "21144f13bef8aa9df1221d523262b9ff767f9026f105451853e65448894bb4c2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16845 :STORED-BYTES 7128 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 16845 :UNCOMPRESSED-SHA256
    "6d9596077b8b659a83d778fdcdd395829ea15aef02e81533d62b7ad9b625b153"
    :COMPRESSED-BYTES 6818 :COMPRESSED-SHA256
    "2e0be710e2fb5137dcbc8a98b45e1e3fde0bd01b660dbe94db30d013655ec67e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16700 :STORED-BYTES 5552 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 16700 :UNCOMPRESSED-SHA256
    "a4ad1be4fb2c3a82a2921e3c9b98e77f6a9ced209971675414bfc0ae4b8c5a2e"
    :COMPRESSED-BYTES 5242 :COMPRESSED-SHA256
    "d075192c215813bcbd377f44b748f007616c330e6b4cdb77fb76422a4d817057"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16690 :STORED-BYTES 5448 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 16690 :UNCOMPRESSED-SHA256
    "af3f7f9682badd67e0531c76b5b29e4e01abb5a2fe272df0a3d464d006f7a12d"
    :COMPRESSED-BYTES 5138 :COMPRESSED-SHA256
    "584d5065052ecc3c8c10c0da7b935bf962a4b89a983db5b955688106cefba046"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12747 :STORED-BYTES 3679 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 12747 :UNCOMPRESSED-SHA256
    "5897eef07fc596b5d1049bedbb74c74e2fc2b511aa543045144515aa1b26ec4b"
    :COMPRESSED-BYTES 3369 :COMPRESSED-SHA256
    "19b8a5dbdd7b7be9266a424e551ebc367dac6df07b555078e1006ee445ed7c80"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12833 :STORED-BYTES 4127 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 12833 :UNCOMPRESSED-SHA256
    "2b548465cb09702dbe36e6aaebe4367cd612866516ae7e2568ed8110671f2e57"
    :COMPRESSED-BYTES 3817 :COMPRESSED-SHA256
    "79fda8b668112aa549eb6eab0fe9458672e1867abc387566fbc7de50a762e106"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12840 :STORED-BYTES 4228 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 12840 :UNCOMPRESSED-SHA256
    "7d579644bd69acbe8ba2ba93ea07b13c047ca3a6b3efcfcb64cbc52c55d7f5e9"
    :COMPRESSED-BYTES 3918 :COMPRESSED-SHA256
    "651374ec1a45623511360708d04d6c341a000e06b758483948752761c6b0cb59"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12882 :STORED-BYTES 4857 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 12882 :UNCOMPRESSED-SHA256
    "982a356d1e3554163012f875b6c93fe52a5a8cbc6e2653daa9cbec1ddb46aa7a"
    :COMPRESSED-BYTES 4547 :COMPRESSED-SHA256
    "f965bf820672bff2762308ededb55d261eb1f84d4dd9dc3df07357725c150b20"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/candidate/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12863 :STORED-BYTES 4851 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 12863 :UNCOMPRESSED-SHA256
    "1401bf682fb1101b24a8089788205b4a198ccdd0279acae9674af97968f2ae66"
    :COMPRESSED-BYTES 4541 :COMPRESSED-SHA256
    "da52522c29da3ccd49cc58acb1f24a51a25defab3b91fb10101e6cba82723263"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/4002553784-command-72500-0/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363477 :STORED-BYTES 116650 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363477 :UNCOMPRESSED-SHA256
    "be3b1fe1670074e61113a5c24113a2304ab2096e4f5497fca83b29a67ee27d9a"
    :COMPRESSED-BYTES 116334 :COMPRESSED-SHA256
    "b0b73d5eadcdf65b174b691220e1e1e9b19e07006d51ba4ee01fb41e96935665"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-analysis-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362815 :STORED-BYTES 116465 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362815 :UNCOMPRESSED-SHA256
    "c626a16ef3ae6ce075cdb945c73645815f1d974a4d0e38fcc0b9c6810296bfd2"
    :COMPRESSED-BYTES 116149 :COMPRESSED-SHA256
    "f44e24cba7d3bab8e98ebe81e7f8ba6d6938f8580f904ec22c075152a328bef9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-archive-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362826 :STORED-BYTES 116476 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362826 :UNCOMPRESSED-SHA256
    "4f85ed25ead29373783e4825ac66fea51841b9979cdf86aeaee4a01cc9d46a5a"
    :COMPRESSED-BYTES 116160 :COMPRESSED-SHA256
    "829ab0cc92d029df97dadf28fb02422a64c47fe385e4a1ac6d3e221ccfa1dbcb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-baseline-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363267 :STORED-BYTES 116599 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363267 :UNCOMPRESSED-SHA256
    "d49cd71ba633646643097145f86d53b28dc211d8b96b73f859daae9ff4abd75f"
    :COMPRESSED-BYTES 116283 :COMPRESSED-SHA256
    "75e41a134c503ac7bb2a68569d91b1004a9125902b021d2ea378838b1f263d77"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-baseline/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372069 :STORED-BYTES 117318 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372069 :UNCOMPRESSED-SHA256
    "9a1018c6d69e06a7124a59377f39aa54c917bad76b6083f61835fbc752eb5020"
    :COMPRESSED-BYTES 117002 :COMPRESSED-SHA256
    "0a0afa5a7c9defed6ba46004edeadbe68c3f22cf3ae9c6d44b1ba8acefdefc45"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-candidate-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363407 :STORED-BYTES 116590 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363407 :UNCOMPRESSED-SHA256
    "900964feb2d92c579c9a7a12969e2b4b2c939ae3b054bb255f299f5ddcebfea2"
    :COMPRESSED-BYTES 116274 :COMPRESSED-SHA256
    "3eff65dbaed29f9816d10a157d6a58d2e0bc5f3182507f50fd96e832ba7cd144"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-candidate/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372377 :STORED-BYTES 117423 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372377 :UNCOMPRESSED-SHA256
    "3ba407ea42c022d9e32ed8008ba9919ab8c5e62030b37c39d5e375666e132831"
    :COMPRESSED-BYTES 117107 :COMPRESSED-SHA256
    "1d12983b957c243c4a4e7982df5e39fe3e323b6cdb8a02f3ebb2fda07375c2d7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-checks-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 435703 :STORED-BYTES 128663 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 435703 :UNCOMPRESSED-SHA256
    "4355dce342f1bcd882a96b123720e791a1d44e90efdf452d0887adeb35e1d67d"
    :COMPRESSED-BYTES 128347 :COMPRESSED-SHA256
    "ad2932c6b4a3b705f883c150c8cd2ee0b7961dfd68a1be2e8beeee5c182443dc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-checks/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 394559 :STORED-BYTES 122049 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 394559 :UNCOMPRESSED-SHA256
    "673270641db82137fad0a64878341095a8555f20f2b029a9224f837f8aef008c"
    :COMPRESSED-BYTES 121733 :COMPRESSED-SHA256
    "0d02cae7ded995e8f6a8b531040bea59dabf057a4eb08ec2dcca765cd5c93d4d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-cleanup-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362861 :STORED-BYTES 116510 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362861 :UNCOMPRESSED-SHA256
    "407548888a532ba013645728c67e92cd687f91dc94874bcb0ccc1b082564a820"
    :COMPRESSED-BYTES 116194 :COMPRESSED-SHA256
    "8b2d240544326e68408689f6cde39aa8cf55e03d50e5f1183204c3832fe9f71c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-close-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362812 :STORED-BYTES 116460 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362812 :UNCOMPRESSED-SHA256
    "cf9795c5debb83905dc949e4929d5e076ac7b7145bb6e4b5f3f8f10a69dde2fe"
    :COMPRESSED-BYTES 116144 :COMPRESSED-SHA256
    "c290e2e507359c88a36b934ae0a39fb94648301785b7c127a74005eb8b5f0241"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-compaction-cost/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363044 :STORED-BYTES 116535 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363044 :UNCOMPRESSED-SHA256
    "532954b35ded26d9e902b79a1abd56180fc6dd7a397c0eba586082a8d078c024"
    :COMPRESSED-BYTES 116219 :COMPRESSED-SHA256
    "f0fc31c5183073a5fb7d3c7a7e3a840233a4da2b6d24a67bc8f0821396bfab51"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-counts-after/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 368375 :STORED-BYTES 117429 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 368375 :UNCOMPRESSED-SHA256
    "cdeaba2ef5ca9b858be0b91d9f5548ff51eb22a34919ab7a1da3246918618f79"
    :COMPRESSED-BYTES 117113 :COMPRESSED-SHA256
    "eb8aca1aacfb0a3de9507296d9fa05dc0ce1c4ce8edf4605c2695b6f8a1a2b6c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-counts-before/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 368044 :STORED-BYTES 117320 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 368044 :UNCOMPRESSED-SHA256
    "bba2c268d8691803b69ffe293469e8e51e7349aacec81fef9f0c9fa805751ca7"
    :COMPRESSED-BYTES 117004 :COMPRESSED-SHA256
    "cb52016cc0b4039c1ddc74120430a8b32693d05aa27734ad0849bc8685ec915d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-counts-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 368382 :STORED-BYTES 117430 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 368382 :UNCOMPRESSED-SHA256
    "a0477fe2e60e770ee84f234cb9ccc72806c8df10021a00be400f60618ef0b649"
    :COMPRESSED-BYTES 117114 :COMPRESSED-SHA256
    "a5bbde2da76858c9245d1e5cc0e9562bd1f0225fbc5da773f4c0323422c65428"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-documentation/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 368933 :STORED-BYTES 117896 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 368933 :UNCOMPRESSED-SHA256
    "1626e89791f027bb8e89ad6b1c48e7da7ae496f0421bc63441a8f4d9af85b4eb"
    :COMPRESSED-BYTES 117580 :COMPRESSED-SHA256
    "6cc19f36cf1d1ec58b7a382e8e6a9ad6fb772e58d329ca9512a3ff6eeaa4551b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-candidate-repeat-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363421 :STORED-BYTES 116606 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363421 :UNCOMPRESSED-SHA256
    "ee90f44b6683ac0f5feac3cc5b5758b5273872dbbb364d52f95dd8757a570a3e"
    :COMPRESSED-BYTES 116290 :COMPRESSED-SHA256
    "099cad425e422cd7ebf75442f8ee9da3fe7f9b83a62b892629e0196fc3d44633"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-candidate-repeat/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372408 :STORED-BYTES 117444 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372408 :UNCOMPRESSED-SHA256
    "6aa17c80ec67bcf1251a23aaea8bd1dd7d16423ef4c785252dbb0ee7867db6c3"
    :COMPRESSED-BYTES 117128 :COMPRESSED-SHA256
    "6512738bd8f2c10606bb503f6c7484af0e72185e9c00b1612a33f9ded0a1afa4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-candidate/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372401 :STORED-BYTES 117429 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372401 :UNCOMPRESSED-SHA256
    "2f6f066acd31b8888ee9c0048db1f40f464aafa1719d74e91ccbc13eff0a4e68"
    :COMPRESSED-BYTES 117113 :COMPRESSED-SHA256
    "f623b794d5cce6cd2492f959177e56f8b68e39e881d843c74caef4191fd1e62b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-01/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 370492 :STORED-BYTES 118378 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 370492 :UNCOMPRESSED-SHA256
    "aa73cec8a4864de2bf9aeaf5287f33d4e535b873fe6e429ee2760d1d17b9e67e"
    :COMPRESSED-BYTES 118062 :COMPRESSED-SHA256
    "bd0a41f1df7d477057bb50f16c073ecdeed9f46ad89f539e9f253be9ed19a20c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 370451 :STORED-BYTES 118346 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 370451 :UNCOMPRESSED-SHA256
    "fe3c44bf72d9eef17481bcfa2836b97e7acce8ae6df85b26ff310dbd227167a2"
    :COMPRESSED-BYTES 118030 :COMPRESSED-SHA256
    "e122ae8b685d05a28433cfb28256b09648ac5254962a378ed7e264630c1089c9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-03/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 370428 :STORED-BYTES 118334 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 370428 :UNCOMPRESSED-SHA256
    "c587620d870276d2612c4680766034f94d7602afd896989374b1860885d292d9"
    :COMPRESSED-BYTES 118018 :COMPRESSED-SHA256
    "d2093b243e35cfdf5dbf3083208645c9d7c227f1373ff1ba4328b72237db71af"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-04/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362702 :STORED-BYTES 116420 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362702 :UNCOMPRESSED-SHA256
    "1bed130243e2d1f93ce3e12bc2209b97cdf33d0b3eccae1e233d229362c76405"
    :COMPRESSED-BYTES 116104 :COMPRESSED-SHA256
    "3ef71e0416f0b9bd845c87c897b94e113bc5274a15a62955a5c471054b6f3ccf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362768 :STORED-BYTES 116444 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362768 :UNCOMPRESSED-SHA256
    "b36dbd2885323721ecb31e7f2cfda2b6647782db372dd5dc909a41681982e7bf"
    :COMPRESSED-BYTES 116128 :COMPRESSED-SHA256
    "dc699c38774745baab9734364ed1a0f6c62d1d908ccb6dc916011767533bf315"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-optimized/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362770 :STORED-BYTES 116451 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362770 :UNCOMPRESSED-SHA256
    "ab16b56e7410004e046b903dedab3d0280ab554e99397efcf3e86a0cc6b3ff5c"
    :COMPRESSED-BYTES 116135 :COMPRESSED-SHA256
    "09d5217e62955d22aaf04fdb88072ab7451e075c37c5c93e45ac8a1a87ed13e3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-identity-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362838 :STORED-BYTES 116480 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362838 :UNCOMPRESSED-SHA256
    "ee0a276b0983051e9f67c1bca2db591f200d615f6c820e2ad6a27dc38c278e74"
    :COMPRESSED-BYTES 116164 :COMPRESSED-SHA256
    "f3b6022af8e92af20e4b2958d89055b2820595755c90cbbe9adf4b44c65ae1e8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-maximum-allocation/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362869 :STORED-BYTES 116502 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362869 :UNCOMPRESSED-SHA256
    "3a4d2b61459f74059ca85681bcae205fc97d49a9fdfdbbf3f558eea8037180cb"
    :COMPRESSED-BYTES 116186 :COMPRESSED-SHA256
    "e3650489092390a87503f7fad37ed3018efb8e33c04bfa3cb6d9ea38fa1091f2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-optimized-final-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363473 :STORED-BYTES 116690 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363473 :UNCOMPRESSED-SHA256
    "ca4021a043f57515a4f3eae5a224fd4da60eefe7bfc88c91aea5c64756d62728"
    :COMPRESSED-BYTES 116374 :COMPRESSED-SHA256
    "a11a856e20d454ba881d0fa7b61b14b2bd515d99af70dc640a266c41402a4026"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-optimized-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372344 :STORED-BYTES 117442 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372344 :UNCOMPRESSED-SHA256
    "9261155a24e253d3914bbcc7cd06e2179e176668f811f69c3e264505d1ff5281"
    :COMPRESSED-BYTES 117126 :COMPRESSED-SHA256
    "5d0d2bd143e6147554a40c8946700a4e99549632f2eb5e507172c3085cf27f6f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-optimized-repeat-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363476 :STORED-BYTES 116691 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363476 :UNCOMPRESSED-SHA256
    "20cf96db983fc6d2cdb49cbbe7f85ed5b9a3ae9bcb76c3804c7572d8f6c12341"
    :COMPRESSED-BYTES 116375 :COMPRESSED-SHA256
    "bab0d982f8c384ef03b7a1726ed856f18834535310e61cb74a70564180f71da9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-optimized-repeat/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372344 :STORED-BYTES 117431 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372344 :UNCOMPRESSED-SHA256
    "b6cfb96da6127ac783bfc3e523822e31ebf224a76386402adf4adbe530ea1c45"
    :COMPRESSED-BYTES 117115 :COMPRESSED-SHA256
    "94e317d9a0bca7207790208d2c14816455497ca3538dcb7699cf96874fe78842"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-final-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363470 :STORED-BYTES 116683 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363470 :UNCOMPRESSED-SHA256
    "7376c4491019fd1009713582c9ef9f72ddb6bbb3614c9a045fd425792bebb03c"
    :COMPRESSED-BYTES 116367 :COMPRESSED-SHA256
    "8fadd5703e1ebc60d4bd746db918433103a440f1df2628a22d9075818aea47f8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372340 :STORED-BYTES 117417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372340 :UNCOMPRESSED-SHA256
    "24191aae0d5a929d1307f74d580aa14317cacf439851bda0551be669bbda91c1"
    :COMPRESSED-BYTES 117101 :COMPRESSED-SHA256
    "6fb956328b4a00c9c5e95729b84775d6128b96bdd53b7008b41805e7f0eea125"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-repeat-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363471 :STORED-BYTES 116684 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363471 :UNCOMPRESSED-SHA256
    "544856b255ec3930e23a907b72e388a9fe5f64b3e9b75a67b9608b8b54fab004"
    :COMPRESSED-BYTES 116368 :COMPRESSED-SHA256
    "3f6400c0fb2dfee24818b5ac46f28c4563d37c1e4aafb2fc882e2e6b8519edcb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-repeat/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372342 :STORED-BYTES 117432 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372342 :UNCOMPRESSED-SHA256
    "bd91ae834f268ea7c1482239448525051a14ea159bd78d7d333e22cbd8965b0f"
    :COMPRESSED-BYTES 117116 :COMPRESSED-SHA256
    "76c2a979467c5cfea36575057bcaf2136a350fef5c40b95df78cb1b2cb0aa0b3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-smoke-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365438 :STORED-BYTES 117138 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365438 :UNCOMPRESSED-SHA256
    "f0a17d6b18a61fb080c334f06f00dde142e4896155717619e10ccbc358a8a879"
    :COMPRESSED-BYTES 116822 :COMPRESSED-SHA256
    "c9b877e3fc13e3563fb7295bbf01a1d9a164ac13beb31b44f397ddcbb63bfb51"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-smoke-03/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365445 :STORED-BYTES 117144 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365445 :UNCOMPRESSED-SHA256
    "7ae61f0905644ddd9b586bedc96339113e566615c3e15914ddc00d541e088318"
    :COMPRESSED-BYTES 116828 :COMPRESSED-SHA256
    "797722b594f1afd7eabadfedbe830e0ff1f99923e3acd90f8dba6a7bbc7ad23f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-smoke-final-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363001 :STORED-BYTES 116576 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363001 :UNCOMPRESSED-SHA256
    "ccecbaea70acbf7fdf96e2605771b4fe4ff6f3c167f09205916fa9d4f1c4617c"
    :COMPRESSED-BYTES 116260 :COMPRESSED-SHA256
    "262a0d50fb15d6f9e4a3209693d85840f0ea26add8eca7378f128b0bfc6115f1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-smoke/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 366225 :STORED-BYTES 117447 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 366225 :UNCOMPRESSED-SHA256
    "49a8372eff228afcfd71636ce791a9698fcd5577d06e0ae82a4a470929f63234"
    :COMPRESSED-BYTES 117131 :COMPRESSED-SHA256
    "a5bdebdbaf96b9d7fce047737499de5f96db1c474a1aa7a54bd5a3d9e508f21c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-qualification-2.6.10/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 600391 :STORED-BYTES 132976 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 600391 :UNCOMPRESSED-SHA256
    "4d50d57be1f1891074d828e38531687afe04f93de9d17f04821bdf1a53fd76fd"
    :COMPRESSED-BYTES 132660 :COMPRESSED-SHA256
    "adb70d8146a0257aa5b6f5c26e832daefd2ec04427ff649f69523ecad3772629"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-qualification-2.6.9/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 600362 :STORED-BYTES 132972 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 600362 :UNCOMPRESSED-SHA256
    "282a66884eaf1815425532071788765cb73d9f5d192fe64a097d952b4f0ed904"
    :COMPRESSED-BYTES 132656 :COMPRESSED-SHA256
    "3c16a010617c1bd371f6b7ce7253a32d66e720a599a37b3192f045158f36f023"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-ready-only-spike-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363475 :STORED-BYTES 116681 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363475 :UNCOMPRESSED-SHA256
    "3a899b08d12170ffe210691c293715286f544f02c9566c2f6acef707743b8876"
    :COMPRESSED-BYTES 116365 :COMPRESSED-SHA256
    "1eae58d1aad69f4c5396a8e6243b2039bbe8c66155ba8a3d1dbd8b6f0e42feff"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-ready-only-spike/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372362 :STORED-BYTES 117435 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372362 :UNCOMPRESSED-SHA256
    "0b8c058228dba8f2f1768991ba5210c1a7f5babb117ada30503b64ac768a232b"
    :COMPRESSED-BYTES 117119 :COMPRESSED-SHA256
    "5b142616c9288dfb05cdb7abbc483dc23c151a24e438b948102f53edc9db1023"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-ready-spike-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363469 :STORED-BYTES 116678 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363469 :UNCOMPRESSED-SHA256
    "cc67f799be1f543ca9d7e0faa8e54c011ba2ebe01644f456e7b1d017b2e3777a"
    :COMPRESSED-BYTES 116362 :COMPRESSED-SHA256
    "67dfd6de1923273328d86466e01e987d03b68a46f9ef6b7e45dd4d14550251b5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-ready-spike/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 372351 :STORED-BYTES 117428 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 372351 :UNCOMPRESSED-SHA256
    "003722db9a739c20bad12f1592ccb28e17029231d9d02877c2895a34146dea88"
    :COMPRESSED-BYTES 117112 :COMPRESSED-SHA256
    "3782606fa7f60142de60c042b1933342051e4d8510dac01db6aa6f5207a77b5b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6609 :STORED-BYTES 1311 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6609 :UNCOMPRESSED-SHA256
    "e63632668e3a99789e7a273dc1632bf4d6ad4f35b36c32536f85a5f55a651edf"
    :COMPRESSED-BYTES 997 :COMPRESSED-SHA256
    "9b64eb782ac864c033c8d56f231032b1ddec41315e9a520aa7cbe569e9a2d2b0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6354 :STORED-BYTES 1171 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6354 :UNCOMPRESSED-SHA256
    "26bcc0a1d61c176d32c78a57e54baaaf1cbfb30c5875860aaf385b112e2678f7"
    :COMPRESSED-BYTES 854 :COMPRESSED-SHA256
    "472b05e9c1dc56a0bcbdb060ad3122cb543592e34e3d8d1b0f21a0c35c59e172"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16684 :STORED-BYTES 6325 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 16684 :UNCOMPRESSED-SHA256
    "62bb9cd2a62b643cf8e6f18eab259f50b6cf422c936683b67b4ec7d071350a25"
    :COMPRESSED-BYTES 6015 :COMPRESSED-SHA256
    "e0d2b80c0dc15b46d701a081790a7b4211bcb91a14c4326c6afe7de597909cdd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16719 :STORED-BYTES 6722 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 16719 :UNCOMPRESSED-SHA256
    "ea256b3393a30d0bbb354777073597c2f8b22595281596881e5f95f305e9a144"
    :COMPRESSED-BYTES 6412 :COMPRESSED-SHA256
    "e4079661dda1e0d1ce2c8423b462bc8c7a350b2cc483555386d8daa95b59369f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16700 :STORED-BYTES 5697 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 16700 :UNCOMPRESSED-SHA256
    "a88c3520e2e7080d5ba146c51a673be4c09f4b8a6d0175003eed3360da7c857a"
    :COMPRESSED-BYTES 5387 :COMPRESSED-SHA256
    "ce1aa8a666644dd7d3eb4fdc8985a3f77d503f4989b0e1a3e9d3ee6db6f1d50c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16706 :STORED-BYTES 5300 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 16706 :UNCOMPRESSED-SHA256
    "0f5fd006ca124ae78a7befe28db47ae500f92a744d6fd44da97d383b4cc08925"
    :COMPRESSED-BYTES 4990 :COMPRESSED-SHA256
    "0d0636d0bee3852e0e954fefa98eee83aebc7b5a5a44aabb99022a699f938b6c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16698 :STORED-BYTES 5529 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 16698 :UNCOMPRESSED-SHA256
    "a5a074510e3d9f4ea3249e69f61305853ae2da348eecb20d120095ea11a28c8b"
    :COMPRESSED-BYTES 5219 :COMPRESSED-SHA256
    "23440dc3e8093f50939ec021344afcc89104ee546a463cf685286d118d4ae71e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/6-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12917 :STORED-BYTES 4945 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4.lisp.gz" :UNCOMPRESSED-BYTES 12917 :UNCOMPRESSED-SHA256
    "b1c739f2f8c63c13a17a2408298220af7aab924fb4f71fef973dfcb52e4f4545"
    :COMPRESSED-BYTES 4635 :COMPRESSED-SHA256
    "3ef61e9e7f1e91c9b203828dbdbbf92b4b9a1051e18b5a879398f05f047e8d00"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/6-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12915 :STORED-BYTES 4698 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3.lisp.gz" :UNCOMPRESSED-BYTES 12915 :UNCOMPRESSED-SHA256
    "d9d3ed75143daff74057316bcc3d335252251587e4794d91adeddcf8c8ef9a95"
    :COMPRESSED-BYTES 4388 :COMPRESSED-SHA256
    "1666b0b1c8d9fb8b68852d2189422d719da13caf32792bbd66c2d41a98f0c148"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/6-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12859 :STORED-BYTES 3821 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2.lisp.gz" :UNCOMPRESSED-BYTES 12859 :UNCOMPRESSED-SHA256
    "fc62332b0e55834f2743c4cbc5c1a5953069ff0d4403733b412bb49df7e11e83"
    :COMPRESSED-BYTES 3511 :COMPRESSED-SHA256
    "0ad1f16b53f5bc6c6aaea1713bd6fd77f1825d110205e37a2111b84676298548"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/6-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12848 :STORED-BYTES 4736 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1.lisp.gz" :UNCOMPRESSED-BYTES 12848 :UNCOMPRESSED-SHA256
    "cbcbc56465cdebbb42e8272033a3d58d6099af19276265767f51303ed0607e80"
    :COMPRESSED-BYTES 4426 :COMPRESSED-SHA256
    "1fb58463b94c02747a7133995cfc325cde6a4cba3dd95226b9c17b337438704c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/6-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13039 :STORED-BYTES 4442 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0.lisp.gz" :UNCOMPRESSED-BYTES 13039 :UNCOMPRESSED-SHA256
    "05fc41dbce298dfcaa1fe1d759612eecb345038f15e778f11a77f272c6293ab5"
    :COMPRESSED-BYTES 4132 :COMPRESSED-SHA256
    "482a46e3c9cc7b8d0d1ab38b4b5d5f4be03013f28da5b3fd04f214697d5dd846"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16695 :STORED-BYTES 5787 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 16695 :UNCOMPRESSED-SHA256
    "d0a00278c4dd662b9c07b720597ca71e89cc16dff1def7bffdd0915ce20dd1d9"
    :COMPRESSED-BYTES 5477 :COMPRESSED-SHA256
    "82898b824a60ec15f017e6f816de5e93d53ae0bd93a75f84af89927cf69ac9dc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16704 :STORED-BYTES 5381 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 16704 :UNCOMPRESSED-SHA256
    "9a8749f7b6ab8b9cee8aaaaae2bf0403f38f32837f23edc79460ee8ad536a451"
    :COMPRESSED-BYTES 5071 :COMPRESSED-SHA256
    "ad24d4d8f897adadc79d419eb2d9fc9f28aa7a1b21d75124881eb9ff1566017d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16713 :STORED-BYTES 4579 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 16713 :UNCOMPRESSED-SHA256
    "488fcd54065bc682760ebed5d8564296804dee1267e4d78dcd1231b39ccf1fef"
    :COMPRESSED-BYTES 4269 :COMPRESSED-SHA256
    "dff1f9dc9e25c2f6c008c055b79ad9f0cc153e0a5861c3706a27aa3612380f8b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16705 :STORED-BYTES 5095 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 16705 :UNCOMPRESSED-SHA256
    "fb05927d82213c12c7bd19aaba1ce2fc769ecb580e74bca654b19e05a8f0b8d8"
    :COMPRESSED-BYTES 4785 :COMPRESSED-SHA256
    "6cd5f8e06de74d71f826392dce5359f7fba3ca049e4c06c39fff3e305798a50b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16714 :STORED-BYTES 4536 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 16714 :UNCOMPRESSED-SHA256
    "f3ca4b7d3cd18771cea70be1323cbe8f16d35b13b6e29849b8dc9bc35e877c07"
    :COMPRESSED-BYTES 4226 :COMPRESSED-SHA256
    "5f9e573616800af4d9b794d6e3cf62a5907b9fa91d2e320f4f1a04d06c821cca"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12731 :STORED-BYTES 3624 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 12731 :UNCOMPRESSED-SHA256
    "3e0379692e31f000784e10aa47057915f47a0b425d5b70ef65c91dedce6bf602"
    :COMPRESSED-BYTES 3314 :COMPRESSED-SHA256
    "22cda805ef1f3bce99d6059cbd350d6672bbdc60be36852e5846470e25f5c3b7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12733 :STORED-BYTES 3890 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 12733 :UNCOMPRESSED-SHA256
    "d21150785da619018c90a99199580d9d71ea90576209346714a43e8ac4f3dbaf"
    :COMPRESSED-BYTES 3580 :COMPRESSED-SHA256
    "2585c1f40835858d077b8a1762a8d9ba76c279e052945359a1c9de2c72dc2cd0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12750 :STORED-BYTES 3567 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 12750 :UNCOMPRESSED-SHA256
    "d2a62e2a453e1220dbdfe12aaae21b53fd4ef296b06e1df21dad3c8d91371f20"
    :COMPRESSED-BYTES 3257 :COMPRESSED-SHA256
    "423aad26bbca7138676fcd01e0419871b570ae6b6bebbbaa5fa7644504393251"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12738 :STORED-BYTES 3597 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 12738 :UNCOMPRESSED-SHA256
    "e15927456db42ba1c8bb5bf237cbd53cd515e789a4e41696c688b50e0b8aaea3"
    :COMPRESSED-BYTES 3287 :COMPRESSED-SHA256
    "9d0b41023f6ed278f27779895b29cad8d92f7f44f2d4aa6ec19a9d44a834f4b3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate-repeat/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12807 :STORED-BYTES 3896 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 12807 :UNCOMPRESSED-SHA256
    "3c42cb635440bbd569a022a9f355922dd4622cbf66e703a43893efd9d0e71200"
    :COMPRESSED-BYTES 3586 :COMPRESSED-SHA256
    "2815078ba40eb279938608d1e0f63b1edd9464ac3f773aee1e7b17cbd0d5cf57"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6490 :STORED-BYTES 1306 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6490 :UNCOMPRESSED-SHA256
    "079632cc8a316e352bfb9cca91f691f9e5a1774b278d850fb36fdfea0cc76dac"
    :COMPRESSED-BYTES 992 :COMPRESSED-SHA256
    "83efb7b937f9a6c08163cc79f8a67de409fa38791c58cb5a59b53d5dee968f27"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6242 :STORED-BYTES 1167 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6242 :UNCOMPRESSED-SHA256
    "20ba1b3825933f46b15465f36fc2afc068bea4926951b51c3a2da36493be46dd"
    :COMPRESSED-BYTES 850 :COMPRESSED-SHA256
    "ccbd4f72a70f822de1800baaf283050f04bcb6df1e137f07a25fba92a8bdb827"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16708 :STORED-BYTES 4913 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 16708 :UNCOMPRESSED-SHA256
    "e0dd026ae870e5222173832a964a4dd96f55aa6c52a43eb9316c086ba4cbd802"
    :COMPRESSED-BYTES 4603 :COMPRESSED-SHA256
    "5cbb42f7f1b80ec7387aed6f8735b2f216758521b6382e6f602dc6322edc0313"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16708 :STORED-BYTES 5142 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 16708 :UNCOMPRESSED-SHA256
    "9d04a527659f1e4ea6e113bb00adc9548408372d940a1d73cef0e48d6eff4cbc"
    :COMPRESSED-BYTES 4832 :COMPRESSED-SHA256
    "8246780b95595e2f62c61fbd899db3103170e2a339c8860c3ce8cd4d6ea14231"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16697 :STORED-BYTES 5320 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 16697 :UNCOMPRESSED-SHA256
    "6d7dac735417ee7c514f7f7a28608d9e8c1a03b3533f1389b1a7be80de2ee694"
    :COMPRESSED-BYTES 5010 :COMPRESSED-SHA256
    "1d9d2e9165c7c7e5328838d31331e9f930689b70c029f0a26be8dfdfc83a6f78"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16696 :STORED-BYTES 5338 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 16696 :UNCOMPRESSED-SHA256
    "fa5f30295fd702c9d03cc77b04a0ac173197012300dde3782ef678cde1f9cecc"
    :COMPRESSED-BYTES 5028 :COMPRESSED-SHA256
    "0d8620cb9a39ce6ea4265e59ca6f91a6dc7effbcd8c085a52fbd18fbf0ee33b8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16710 :STORED-BYTES 4864 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 16710 :UNCOMPRESSED-SHA256
    "bbf0fce045541c50e8cdf0c0aec7a54c0ae87d04e616864f768e4b4e22222ac8"
    :COMPRESSED-BYTES 4554 :COMPRESSED-SHA256
    "904b706c9bd944584af68d15a13bcf964a35b788d134df252583325c17f68c83"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/6-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12791 :STORED-BYTES 4214 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4.lisp.gz" :UNCOMPRESSED-BYTES 12791 :UNCOMPRESSED-SHA256
    "8df69ac07f86866aee70e40ebc5d961200ba9a18d190289c268cf110a5150005"
    :COMPRESSED-BYTES 3904 :COMPRESSED-SHA256
    "c5915ed3d1816d5bd5661c662cd426600b6e4356b88227b0a210024bbcb7f23e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/6-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12755 :STORED-BYTES 3839 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3.lisp.gz" :UNCOMPRESSED-BYTES 12755 :UNCOMPRESSED-SHA256
    "1805837f2e36e98f1a8fbb82906c49690dd65c2ccd5e99c2002c919d996cd423"
    :COMPRESSED-BYTES 3529 :COMPRESSED-SHA256
    "e1883817b7f0a4860164cd44c7012d3e3f06228e262e6a979a45012440b0e04f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/6-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12754 :STORED-BYTES 3713 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2.lisp.gz" :UNCOMPRESSED-BYTES 12754 :UNCOMPRESSED-SHA256
    "57d55178393ccfa4fcbc2b74df40752c14a9385faee2a07064ca0fc5ad7a8411"
    :COMPRESSED-BYTES 3403 :COMPRESSED-SHA256
    "cdc5443f9171adaf8609eabd05b42355a1edeacfb8bd0711da5619283b3f9994"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/6-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12813 :STORED-BYTES 4202 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1.lisp.gz" :UNCOMPRESSED-BYTES 12813 :UNCOMPRESSED-SHA256
    "a764d4fce0f361862948c18fe228d37319979a2afd8d27517872ef4623fadd1c"
    :COMPRESSED-BYTES 3892 :COMPRESSED-SHA256
    "5a4a452d25336eee4b76f882636139e0f98a99010de35b37d07de15f933f5ae6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/6-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12789 :STORED-BYTES 4169 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0.lisp.gz" :UNCOMPRESSED-BYTES 12789 :UNCOMPRESSED-SHA256
    "55bade960c50c646ac0e1f00f358905bccb25b52ba55fcb5099fde2627c565a5"
    :COMPRESSED-BYTES 3859 :COMPRESSED-SHA256
    "fa9cd6eb992350e4e457df6158085c15577c5079028544730e672567f4c6b8bd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16685 :STORED-BYTES 6063 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 16685 :UNCOMPRESSED-SHA256
    "f96d13be644d7de68ac96feb96c8ff17318532cdc10279ef95683d08100beeff"
    :COMPRESSED-BYTES 5753 :COMPRESSED-SHA256
    "115fc71811d65c2a6382d10bb35e311b25a22af3f6bcbffdd7d9b1e82e794619"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16700 :STORED-BYTES 5321 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 16700 :UNCOMPRESSED-SHA256
    "e90c3e630307f85e9118084e5732b1fbd0cc03f56eac5df98ac70a10e7f7dac8"
    :COMPRESSED-BYTES 5011 :COMPRESSED-SHA256
    "52919e51fbed6a0e76c1ca4b5e827019f6698f51da9e8e7fd8f2865462094303"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16705 :STORED-BYTES 5268 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 16705 :UNCOMPRESSED-SHA256
    "89a0a7350d761f195d7f11bee44c0d8137e1a5a427d3fd3f1d96ad5957fed404"
    :COMPRESSED-BYTES 4958 :COMPRESSED-SHA256
    "e92bbcbb8f036d2fa74783fd439d9768467bec058d24c82d00998f7fed1b5812"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16694 :STORED-BYTES 5881 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 16694 :UNCOMPRESSED-SHA256
    "269a0f60c2f8a092fcbb7ba3b53972159ecdd6be5308e88a6052258a6ec3d7bb"
    :COMPRESSED-BYTES 5571 :COMPRESSED-SHA256
    "6306a8eebf0a6dc35ab5734f17fdad000ba447d9535c4e2ef68f6b4e880b63b7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16693 :STORED-BYTES 5602 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 16693 :UNCOMPRESSED-SHA256
    "c8fb39e100c4172379bf1c54fc9ce98f56eac6339e8fd7e51607a771d154967c"
    :COMPRESSED-BYTES 5292 :COMPRESSED-SHA256
    "69cb13cb8fb0f95c93b111ac4dfc78868e8084a71a4f016e8eae53971b68a581"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12755 :STORED-BYTES 3525 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 12755 :UNCOMPRESSED-SHA256
    "ac45e36553da322a93cb3eee2327cbaa93e5f541ce9d7d7a34a19d72eadf87b2"
    :COMPRESSED-BYTES 3215 :COMPRESSED-SHA256
    "cf29769a832df8ed0761968d23245ca77afbbeaa95093d4702599c4f160d7d49"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12859 :STORED-BYTES 4005 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 12859 :UNCOMPRESSED-SHA256
    "453d026347d442fc656076e3a1f6057040eb8bc667a377a39ff1466f069a94c6"
    :COMPRESSED-BYTES 3695 :COMPRESSED-SHA256
    "84a9bf9cc2a48e6957a82e03085f486bee2fed2eecbe4ed93928a38b535a2485"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12771 :STORED-BYTES 3454 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 12771 :UNCOMPRESSED-SHA256
    "657565c972438a5f670a340fefcaeaf512879cf248ca9e4e2d1026f3344f19c4"
    :COMPRESSED-BYTES 3144 :COMPRESSED-SHA256
    "e63487aeaacec1ea269d02532d62dc5dff2f91042b2d915be47b8c8b916372ae"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12784 :STORED-BYTES 4000 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 12784 :UNCOMPRESSED-SHA256
    "2eb8532e23c4cda2b2320a7df425f8bf30d824ba6067c839d61da0128a2f4920"
    :COMPRESSED-BYTES 3690 :COMPRESSED-SHA256
    "9797502583fa491f504ce7f319b383500afa2e9f2f32782a8481b6fa05fda3b2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/final-candidate/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12747 :STORED-BYTES 3236 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 12747 :UNCOMPRESSED-SHA256
    "4cefa90b6b72b448b28b84ed8054aee2ae8bb1cc23265c5be265b77c08c53a38"
    :COMPRESSED-BYTES 2926 :COMPRESSED-SHA256
    "ba8f95b7b0b960edfceb41d7320b2e7891435b03042263ec176298dea003b1c4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/focused-01-variant/client-receive.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12491 :STORED-BYTES 3029 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "client-receive.lisp.gz" :UNCOMPRESSED-BYTES 12491 :UNCOMPRESSED-SHA256
    "74f66d9e25ccd05531e59af68d8be4963487cd6fc79dfc38a127a7be7bf69544"
    :COMPRESSED-BYTES 2708 :COMPRESSED-SHA256
    "403b5aa7d3fa8eca6a55376ed5745704fbb1f461fc9ac7520ebf4c6393291d0f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/focused-02-variant/client-receive.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13434 :STORED-BYTES 3228 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "client-receive.lisp.gz" :UNCOMPRESSED-BYTES 13434 :UNCOMPRESSED-SHA256
    "59b79f033aa79c89c04e6471d8dbf0a23a830221458ba09e8035310801f46b94"
    :COMPRESSED-BYTES 2907 :COMPRESSED-SHA256
    "34e49554124df3f682974cbc3f34bbd78bd8170d6b71aa309b852b43198eca52"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/focused-03-variant/client-receive.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14120 :STORED-BYTES 3321 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "client-receive.lisp.gz" :UNCOMPRESSED-BYTES 14120 :UNCOMPRESSED-SHA256
    "79aca23cc9468191f038bd80514cfc8db854695725960177ea979a47d258a173"
    :COMPRESSED-BYTES 3000 :COMPRESSED-SHA256
    "9935b32fbea765523a801f67be74be8a8066a87dc7653e6a7a986e9fb2aa006d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/initial-read-ahead-variant/src/local/state.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6225 :STORED-BYTES 2303 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "state.lisp.gz" :UNCOMPRESSED-BYTES 6225 :UNCOMPRESSED-SHA256
    "4514d203687b6462a89f97c5d5c44f0ba5f29bf3d23a55102fa58860c5365abd"
    :COMPRESSED-BYTES 1992 :COMPRESSED-SHA256
    "408eb147e41397af41488b814b7157177e0c4914c628be029b2018c21bdae378"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/initial-read-ahead-variant/src/local/client.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16165 :STORED-BYTES 4153 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "client.lisp.gz" :UNCOMPRESSED-BYTES 16165 :UNCOMPRESSED-SHA256
    "c0863aa897d988e050732e510438c73d80d466e9b31cf271737dd02a4348a655"
    :COMPRESSED-BYTES 3840 :COMPRESSED-SHA256
    "b824046abbb84c46b3ada904d3e72141500661fdb351c348d34fbb0183b06367"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/initial-read-ahead-variant/tests/local/client-receive.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14121 :STORED-BYTES 3321 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "client-receive.lisp.gz" :UNCOMPRESSED-BYTES 14121 :UNCOMPRESSED-SHA256
    "9c52908e7f27ac14b65a1bd34c12923fa74174aa7741166d104ab2042c89be63"
    :COMPRESSED-BYTES 3000 :COMPRESSED-SHA256
    "5248d53623d77306afe3fa5cce911640190379b97c7e5c21b009762980c42fb6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6457 :STORED-BYTES 1298 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6457 :UNCOMPRESSED-SHA256
    "02027a21a03de583308fb217a192fff384ad7201ff1d5b8e2050fc393d9799bb"
    :COMPRESSED-BYTES 984 :COMPRESSED-SHA256
    "b685f109c476ca2e1d04f07bed7828f6b181b7e3f334df89870cfb52e7a95e2d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6242 :STORED-BYTES 1174 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6242 :UNCOMPRESSED-SHA256
    "2cd61782e639d39e73c9b467eb5d7c34afa12fb802501a6a1b70f8eeedd25e56"
    :COMPRESSED-BYTES 857 :COMPRESSED-SHA256
    "0bbefe3ec4b1e3425d67966f13850435be6bdc7bed5ab735a3927aea29f515b2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/8-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16704 :STORED-BYTES 5370 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16704 :UNCOMPRESSED-SHA256
    "8b2dd33d576f58aa97838c526b8e0844ff8aadcc4799af26ba680d6d260c4f2f"
    :COMPRESSED-BYTES 5050 :COMPRESSED-SHA256
    "cd4ae230a912a92aa8e63ac654c272915ed3adb32a52f623a7629ac5cbdc5c41"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/8-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16689 :STORED-BYTES 5833 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16689 :UNCOMPRESSED-SHA256
    "7750776f62719c2db2f5c00b895c65a48fda5585ef2012cbdfc9f81a296c29e4"
    :COMPRESSED-BYTES 5514 :COMPRESSED-SHA256
    "931242f3c6c9c4bdcd417b1e0cf11e5d73c09def9c4cafc71ccd832191832243"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/8-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16705 :STORED-BYTES 5419 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16705 :UNCOMPRESSED-SHA256
    "6c88982fe460299baaed8792dc0c05d1e6421e5a6b31bb5e3a4d19983af9a466"
    :COMPRESSED-BYTES 5099 :COMPRESSED-SHA256
    "ad3e7aedbb216fdee2ae5947c87ec92764fb6d4db5dd2929d774beff5a64955d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/8-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16690 :STORED-BYTES 5725 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16690 :UNCOMPRESSED-SHA256
    "2e66152f043384e1c68b362e0c5db011f875e50aac1791a29f38cf99debbb71b"
    :COMPRESSED-BYTES 5406 :COMPRESSED-SHA256
    "9218660e877ab7b2f86c9d92d7b6f1958801522eb6191cf9cc718319ca4a6ab0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/8-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16703 :STORED-BYTES 5455 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16703 :UNCOMPRESSED-SHA256
    "648424fca8ee188aa959e1de370e96088b9a6da60666a9bfd3b49ebd32e388e2"
    :COMPRESSED-BYTES 5135 :COMPRESSED-SHA256
    "2b1dc2613c89a070c08246a2ea6f71a6c40abf62c9da369585ce385203318593"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/8-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16704 :STORED-BYTES 5533 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16704 :UNCOMPRESSED-SHA256
    "4ed068fc0e7a2bbd1cab8e4d6c71befcee5f0ca790ee3f60cb3245d231c03c37"
    :COMPRESSED-BYTES 5214 :COMPRESSED-SHA256
    "868624c9984c0b82000502cd611f2403ec2230245ccb2b915ec80a4e9b7ae911"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/8-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16683 :STORED-BYTES 6030 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16683 :UNCOMPRESSED-SHA256
    "7e55b96b4b30e56920914eb36aa54796bba522032d84fd537dd5dc1ecb1061d7"
    :COMPRESSED-BYTES 5710 :COMPRESSED-SHA256
    "05baea8c27c6da64ea2a358061fb3db638ab11e2579eb3b710baf1ffb520fecd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/8-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16707 :STORED-BYTES 5579 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16707 :UNCOMPRESSED-SHA256
    "181558e8aba1c862cfb3996625d2d5b8e8e6b7399d81429536392e1050ea46c9"
    :COMPRESSED-BYTES 5260 :COMPRESSED-SHA256
    "21855d2876c2849301c9832962879785e19aaf1a741e5ae55b3484f25e18f341"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/8-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16691 :STORED-BYTES 6166 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16691 :UNCOMPRESSED-SHA256
    "4c18424b9a2dfe8d25d316fa7b8fb23a451a02d308a4a456dc0bda31385dd57a"
    :COMPRESSED-BYTES 5846 :COMPRESSED-SHA256
    "89881c10ce128d6d9866a6b44150844bfce6cae320ec6347c4ed3a2443412b96"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/8-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16701 :STORED-BYTES 5987 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16701 :UNCOMPRESSED-SHA256
    "a5e99883798b1795a3330a02d6af3873235630ec2eeb0afe49d20040df745fe8"
    :COMPRESSED-BYTES 5668 :COMPRESSED-SHA256
    "2f7142d507e228e70441c377669403ced4e753632e88666806dad09229c74ae0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/6-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12794 :STORED-BYTES 4680 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12794 :UNCOMPRESSED-SHA256
    "5e8035cc1cc269a9d87a1fd103c6fbc7410b32930e47557e7752e17a57dadb33"
    :COMPRESSED-BYTES 4360 :COMPRESSED-SHA256
    "e886042b1cf1f854850e5d1855ca43625fcb5a0cd75583dc1cf6af1d511683a0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/6-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12955 :STORED-BYTES 4974 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12955 :UNCOMPRESSED-SHA256
    "8e8d74c50440d670b0fa240137f22dbe9e558c5b45e2740f3c71c60ce79bca1a"
    :COMPRESSED-BYTES 4655 :COMPRESSED-SHA256
    "ce85240cd21a2de5c037de7285987f0b3cf3163eb104c4d02d65007954462af0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/6-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12808 :STORED-BYTES 4748 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12808 :UNCOMPRESSED-SHA256
    "8f406cc14ba184f125f9369786de79057b29419d3e5583bc1ea846d1df74a93f"
    :COMPRESSED-BYTES 4428 :COMPRESSED-SHA256
    "cb95594f6fb3248c56a22719fac46af77f97f3c70200838e844d901e66bd90ad"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/6-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12833 :STORED-BYTES 4770 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12833 :UNCOMPRESSED-SHA256
    "c734698090feaaa559ffa56927660851a711d25d09111ba982e0ad0c96d10610"
    :COMPRESSED-BYTES 4451 :COMPRESSED-SHA256
    "8dd6279de5f9a2c330a8978f672f0acb5e45eda4786bdf2df39c474edaad96a3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/6-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12821 :STORED-BYTES 4694 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12821 :UNCOMPRESSED-SHA256
    "8074d810cee69c3c15691e1e77348d480cd95c255d3c31ffd864b8260c77f897"
    :COMPRESSED-BYTES 4374 :COMPRESSED-SHA256
    "3e2ef5248744f3647c3c57d670e9f946fcf868dc877fe5698d9c45b175ca1973"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/6-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12892 :STORED-BYTES 4805 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12892 :UNCOMPRESSED-SHA256
    "92727b4d937793f52fe405b4de0629b9284a6137b9a14c4dbafd1d2f6603b9df"
    :COMPRESSED-BYTES 4486 :COMPRESSED-SHA256
    "0a850531adaf3fcfe44a6d2b3164e2573c3786cd7762332ba975fd730483c657"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/6-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12838 :STORED-BYTES 4759 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12838 :UNCOMPRESSED-SHA256
    "613e743faa64b705c452ab2b48288005d8e2a87b962b4dffbcac60cdb17b8dfd"
    :COMPRESSED-BYTES 4439 :COMPRESSED-SHA256
    "099d92d721a90dfa3c91c239a62fc5f3632bce6de5ab73785cbaf6572dfbe2d5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/6-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12805 :STORED-BYTES 4771 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12805 :UNCOMPRESSED-SHA256
    "0556487041459fb22c4d954891cb4fb2b2988709a5df40c55e537bddddec83f8"
    :COMPRESSED-BYTES 4452 :COMPRESSED-SHA256
    "eb4c343e588c8a7951641c11a9026b03a338ea50a96e174e69a154cd5b76b94d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/6-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12877 :STORED-BYTES 4808 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12877 :UNCOMPRESSED-SHA256
    "b1ccedab6127365d2f88e61a31a5ef2ece27f4e42f2cbe6a9ee12e4dbce00ed6"
    :COMPRESSED-BYTES 4488 :COMPRESSED-SHA256
    "b4040f30961f2e7a816743147936dead9f10b025ee2b7c67ee5497e0570fb457"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/6-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12802 :STORED-BYTES 4696 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12802 :UNCOMPRESSED-SHA256
    "b6a1f32207f3329bc5666f9d3cb9cfbf0ded8c82eef281267dc3ad6bb44b8596"
    :COMPRESSED-BYTES 4377 :COMPRESSED-SHA256
    "561008aba8faae6abe32cfbb40686ef89a245bfd32908c683e7d4b278696986b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/4-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16703 :STORED-BYTES 5800 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16703 :UNCOMPRESSED-SHA256
    "4cc90cc09ee6f46953fd3383e70cf2851c4b2d98eb572b1db2cc58fda01df13d"
    :COMPRESSED-BYTES 5480 :COMPRESSED-SHA256
    "5f37c3f83a5cd5194034fb18ccdcdfa4c067070d75f6de9803b6e92b1b5df089"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/4-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16705 :STORED-BYTES 5714 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16705 :UNCOMPRESSED-SHA256
    "bea3831135672f8849db2c50b66c6fee87b7bd9726bd9f28117e8228cbd91755"
    :COMPRESSED-BYTES 5395 :COMPRESSED-SHA256
    "8a900652673b0ac4138d9d2438ae5d4c9ea4e8903f24d2d08d8c1a5ac25c9fad"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/4-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16705 :STORED-BYTES 5332 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16705 :UNCOMPRESSED-SHA256
    "f06e58b620e9227c7d441aa5f0fde14a98abd424358a033f00f2f7a494c88160"
    :COMPRESSED-BYTES 5012 :COMPRESSED-SHA256
    "982a4a273d60684da1671106909173422da344b895ae64078e2b94acb338add3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/4-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16708 :STORED-BYTES 5398 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16708 :UNCOMPRESSED-SHA256
    "adb3443c2dfeebe1aa9d80b3ea554c0d18d29467f7948acb76fe670094a828e2"
    :COMPRESSED-BYTES 5079 :COMPRESSED-SHA256
    "5eda2a38dfc1d63e206e2a5057d389e6e1f5fc283cd5c662b8365b9d30188296"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/4-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16700 :STORED-BYTES 5440 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16700 :UNCOMPRESSED-SHA256
    "00e24fc20745528d55d053fca27dd5db2323bb93200650ea70cfc6631123f25a"
    :COMPRESSED-BYTES 5120 :COMPRESSED-SHA256
    "ce82c5efc79df1b2ad1ee05b55bcce7800f8a75ccd88ca45d9e65878a2d57fd6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/4-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16701 :STORED-BYTES 5546 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16701 :UNCOMPRESSED-SHA256
    "76ecd855f0a46328160efc6df9eb078b369629f36cf4d3f69ca20ac10420c3cc"
    :COMPRESSED-BYTES 5227 :COMPRESSED-SHA256
    "9788a67ba400fe1c1432b2087c8bba66eba864b64dd6c7e49a111f1e1966c2ab"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/4-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16696 :STORED-BYTES 5978 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16696 :UNCOMPRESSED-SHA256
    "5d6e08df8ecb19f3b55bf5d8713ebb899425c180e49e27aaca0a6c6fd90305f2"
    :COMPRESSED-BYTES 5658 :COMPRESSED-SHA256
    "b692d87a7043b113afa9744f56fc6b6d95cc90642472715b50f3e8b8dcfb3c59"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/4-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16704 :STORED-BYTES 5450 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16704 :UNCOMPRESSED-SHA256
    "9981e0607d8d707fa8fbf02233054835be3851d82bcd21f33e5f0d9e1952ddcb"
    :COMPRESSED-BYTES 5131 :COMPRESSED-SHA256
    "a7bba58349ea62d513d64dce06b1fa7ed68172c748ca4463df260aa361f7630e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/4-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16689 :STORED-BYTES 5551 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16689 :UNCOMPRESSED-SHA256
    "9d48ae864485bca5829ad571c47fef0d915e81cd2b1764462e353c632d470a5e"
    :COMPRESSED-BYTES 5231 :COMPRESSED-SHA256
    "7f4932116124e83cecc75773613502d8be4c904e349a23663314a7ea37d77194"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/4-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16711 :STORED-BYTES 5312 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16711 :UNCOMPRESSED-SHA256
    "bc6e2fd9a40d0f6075c03069ce9d0faabda7bdd35884158e663cb25bc42cf678"
    :COMPRESSED-BYTES 4993 :COMPRESSED-SHA256
    "954bd0334f638f2a030c43b55c2c5697f43d6cafbfaed3ca26faa666879cfe6e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/2-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 15001 :STORED-BYTES 6302 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 15001 :UNCOMPRESSED-SHA256
    "59eaf474e13cc3dad5bf2f5529ea2d50fce35c8c1af9887fc6da0c453ecb877a"
    :COMPRESSED-BYTES 5982 :COMPRESSED-SHA256
    "4b69aab67d07ff0889a7fb878dc1d10936dd7d360a794eedb513942f49eac27f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/2-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13880 :STORED-BYTES 5641 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 13880 :UNCOMPRESSED-SHA256
    "f39c00fe872ed5e83da028b00634937b38fd78a577c5986c95de5b2f37cf55bd"
    :COMPRESSED-BYTES 5322 :COMPRESSED-SHA256
    "2d66cd9665c93eaab0b87ba82f0479f5aa1e5655b7513a8a5323b529a6851879"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/2-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13547 :STORED-BYTES 5070 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13547 :UNCOMPRESSED-SHA256
    "23e8cbfc59061d209b9d0048c5409328449b9f4117c00fa023c7c5430c57e842"
    :COMPRESSED-BYTES 4750 :COMPRESSED-SHA256
    "ebe96b1e87897d44d279e13bd185e6dc310fa18b8589d722ebbd808f83d03081"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/2-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13186 :STORED-BYTES 4491 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 13186 :UNCOMPRESSED-SHA256
    "8b2bff746165475196ae7f16c6202ce602852e7eb4f0da2d337382f4dc0d7277"
    :COMPRESSED-BYTES 4172 :COMPRESSED-SHA256
    "896123d84cb96063c4ead8571a6391145b992e350eb70a33120a418bf69fc415"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/2-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14886 :STORED-BYTES 6174 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 14886 :UNCOMPRESSED-SHA256
    "956b622ab325e0dc7830302f324055a9a8a0d5718515f61373c88a5470b270fc"
    :COMPRESSED-BYTES 5854 :COMPRESSED-SHA256
    "678d098f24a0b0093865b8510343ccea0ced238e32ccdb6a0d82fa81a157d7d3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/2-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14575 :STORED-BYTES 5965 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 14575 :UNCOMPRESSED-SHA256
    "9536c35a3186a441e4255d05103bfc42e1e47f82cfcb738f01a92a436aa28c99"
    :COMPRESSED-BYTES 5646 :COMPRESSED-SHA256
    "d554f2275940dc4a88590b644af6811ab572f1bb11044e9ba58c1f40589f9fff"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/2-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13527 :STORED-BYTES 5138 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13527 :UNCOMPRESSED-SHA256
    "c2d72e595e1c99345c8ac7e2c848fbec41c785f7b64891873efce3c226b270d9"
    :COMPRESSED-BYTES 4818 :COMPRESSED-SHA256
    "8bfc129dd93769ac5fdb0829d1a0665e1060550cf3fbce690a30dbf9f12a5562"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/2-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14333 :STORED-BYTES 5995 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 14333 :UNCOMPRESSED-SHA256
    "8c1c42f088788dca64d0e9422bdea37052d8d41ffc936494655e82e24f4441c8"
    :COMPRESSED-BYTES 5676 :COMPRESSED-SHA256
    "2519c79665b80511f0366b6e452f525d180cec88c25886a31d06b0ca68ab195f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/2-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13612 :STORED-BYTES 5334 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13612 :UNCOMPRESSED-SHA256
    "b5ba10b2bf24306e561f11405223297dfe53b32d09a7a24cb183bb43bda908a4"
    :COMPRESSED-BYTES 5014 :COMPRESSED-SHA256
    "e158c16f97907e9df8aeb8a422f2c8f661af98b4f2f7841d47074c3696d7c7a4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-final/windows/2-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13429 :STORED-BYTES 5036 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 13429 :UNCOMPRESSED-SHA256
    "183d3d81d8a9967fd4c2136cee29fdfbcc5e80c615ee61c1c926af77d4d3809e"
    :COMPRESSED-BYTES 4717 :COMPRESSED-SHA256
    "663a4f515456c8491ab5c8bf342f4703a4ce3e37b6bedc4305e3fff3d89c26f2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6474 :STORED-BYTES 1295 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6474 :UNCOMPRESSED-SHA256
    "9d3cdfdc6f929d35747c740aca6b3088b8ed8588586f67f084cafc379bb533cb"
    :COMPRESSED-BYTES 981 :COMPRESSED-SHA256
    "208f98573c4fd229c015072fed1a7191eaf8a03e051131e24458e5c27e5a5262"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6258 :STORED-BYTES 1170 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6258 :UNCOMPRESSED-SHA256
    "a076de88980187ffeb37636f107f381a5ccd90d0591c834208068fd631bf9745"
    :COMPRESSED-BYTES 853 :COMPRESSED-SHA256
    "223d06deb187a676c2e973564574171eef8fa928e7d363994e3e81eab0e37120"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/8-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16708 :STORED-BYTES 5177 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16708 :UNCOMPRESSED-SHA256
    "8695ac9118f27ef47d607eda261c0d2062aa66c1aaeabffde2139891cc563857"
    :COMPRESSED-BYTES 4857 :COMPRESSED-SHA256
    "afefc3ff0e4660c23017f6cd7c57311b3e74662f973a48056a58428097dfbaac"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/8-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16712 :STORED-BYTES 5074 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16712 :UNCOMPRESSED-SHA256
    "e911ada81a1eaeebb8837d2ed2e83dc6cab36be7da580fbbca96741c243feaeb"
    :COMPRESSED-BYTES 4755 :COMPRESSED-SHA256
    "0370a0064c581b296cc521c15b659f96c6424f13365d6233e780f6c5f2a10005"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/8-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16716 :STORED-BYTES 4904 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16716 :UNCOMPRESSED-SHA256
    "28ea10d9ec81c4f9e724e10020a339f7606a5ddc6f5ef615768f106620a24657"
    :COMPRESSED-BYTES 4584 :COMPRESSED-SHA256
    "514da8484a64c5c6e2ce7168427a69c0134be8ad795a2904cd49661e9015d42f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/8-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16700 :STORED-BYTES 5648 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16700 :UNCOMPRESSED-SHA256
    "c662de1273f848cf3dc41e919f8d059aa1b6106528a6b0a5f088796737cf0a4e"
    :COMPRESSED-BYTES 5329 :COMPRESSED-SHA256
    "4fa957f0cd1fc4f0193a06987badde3fa60dd2d86f3b81bea27ca43f2d9dee4a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/8-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16712 :STORED-BYTES 5240 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16712 :UNCOMPRESSED-SHA256
    "3a2cd99503c3dc71283df12689a6e6cffaee7a430fe22031340259251f09ce82"
    :COMPRESSED-BYTES 4920 :COMPRESSED-SHA256
    "6da2b402fb574e1518d58e4b4a9cb21a8240c71a9540e9d3ac5192a2537ea681"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/8-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16709 :STORED-BYTES 5402 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16709 :UNCOMPRESSED-SHA256
    "9bd125b1232539e9487986de68d1dc4a31096b307038880cbd50dc8f2e75144e"
    :COMPRESSED-BYTES 5083 :COMPRESSED-SHA256
    "014b6da2e2e8d26cb4e458ea7216e23aa0a7f21712781ce2b68dc7410c80a534"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/8-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16709 :STORED-BYTES 5475 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16709 :UNCOMPRESSED-SHA256
    "3321da43b8dc944731fc06e9e4ed301e807e9e55e4dac861a5f86a11d5f9d114"
    :COMPRESSED-BYTES 5155 :COMPRESSED-SHA256
    "7ddd50e0ce8f1da3bb567bd7adc9685b075f3c024bdfcc4c1d473696e3e12865"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/8-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16711 :STORED-BYTES 5127 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16711 :UNCOMPRESSED-SHA256
    "2326a303344e95f4e4ca2c197864ddd3b7a473ee645d9620ca366582e47309e0"
    :COMPRESSED-BYTES 4808 :COMPRESSED-SHA256
    "f3221c64e6c5e5d1b7080473a93661f4ad8082f404ddf6d1e0e1ed08e44391e8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/8-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 5174 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "3d3ae887c8344d68c13fc6e07919995d4759cf944e7cef92fd78555dd22b4932"
    :COMPRESSED-BYTES 4854 :COMPRESSED-SHA256
    "26240984dd65aacaebda0981c37f8a58db71223e18839c03a2d6aebf92c39570"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/8-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16708 :STORED-BYTES 5121 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16708 :UNCOMPRESSED-SHA256
    "f5270cb089d6974774f266de48e9b9c54e8645aaf1310f0083483ff570add651"
    :COMPRESSED-BYTES 4802 :COMPRESSED-SHA256
    "e65568ac7bb9002ae015395e9294214937e81291ed70de6862367307d93ee695"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/6-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12901 :STORED-BYTES 4567 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12901 :UNCOMPRESSED-SHA256
    "c283ebb72be598d2da7a83b40beefa5df2291fa24cb78ffa07628e279ca2c331"
    :COMPRESSED-BYTES 4247 :COMPRESSED-SHA256
    "00a9215868df33561ec5720013bbdc4bc02ccf1d8f15e144e7371364e60e77c2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/6-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12863 :STORED-BYTES 4158 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12863 :UNCOMPRESSED-SHA256
    "9c604698078d6e3fec4b6633ec182baebd6329b3c6d101b4ae5f4bd6192c2689"
    :COMPRESSED-BYTES 3839 :COMPRESSED-SHA256
    "8f94d8a0a104ccf0dc637fa77154f6b6b3404d7ed66214867c70d0ba3113d383"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/6-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12854 :STORED-BYTES 4367 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12854 :UNCOMPRESSED-SHA256
    "5dfb1ca48e3896fcd306199e2ad6b178c14cf96cacb4173438b8aaeff25358ae"
    :COMPRESSED-BYTES 4047 :COMPRESSED-SHA256
    "cb3dabe4deda79f6aead711531b2b6f844fbb0131cdb15e3ae03dcc8db6961ab"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/6-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12885 :STORED-BYTES 4413 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12885 :UNCOMPRESSED-SHA256
    "c238d3973b3eac0f0f8acfb377f473f644aa9bde595440ba4ddbc9cc92c3e1c4"
    :COMPRESSED-BYTES 4094 :COMPRESSED-SHA256
    "7e167bc5a776e95dec93abc282f00ff268ff2f76aa0089b3452e3167b560a999"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/6-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12953 :STORED-BYTES 4729 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12953 :UNCOMPRESSED-SHA256
    "f8027f24d6b7b3fb9691be4a98f55ceb40de6d41fc85e83813b4419a2a487ab6"
    :COMPRESSED-BYTES 4409 :COMPRESSED-SHA256
    "64f1e47b9309e9cbfd37ac16caa97c0398cfb4d18415d04fb2020b443e5c042c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/6-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12938 :STORED-BYTES 4713 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12938 :UNCOMPRESSED-SHA256
    "caf0c08c44cd0296f4bbae66e5b8e3edaea4b2135e2bcdfb3c72f662b94cb5ff"
    :COMPRESSED-BYTES 4394 :COMPRESSED-SHA256
    "65e80a6a4eda470597f9b198b06d513d379ed97e4384f97020ef45a285975b36"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/6-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12972 :STORED-BYTES 4716 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12972 :UNCOMPRESSED-SHA256
    "20a364c4de80066a015b361298cf199c382a4080d88461132f2d67af464b3546"
    :COMPRESSED-BYTES 4396 :COMPRESSED-SHA256
    "3003fe6e4d93b846045dd451a1bcffed3b5d85e2e7fb12e8c508d73b3c326260"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/6-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13080 :STORED-BYTES 4921 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 13080 :UNCOMPRESSED-SHA256
    "6fcbe75e5b492b50bd0a11b29878dac31bbe90986b72420565ae050cf226c4a2"
    :COMPRESSED-BYTES 4602 :COMPRESSED-SHA256
    "851fbde836e389e9af2a75079c02ecb9abe9d412757ab78709747c1808011780"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/6-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12797 :STORED-BYTES 3910 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12797 :UNCOMPRESSED-SHA256
    "4f31ee5c6810f3feb88690fd947dccbba56bdff4aa93bdaf01aab5a6d14c0ea7"
    :COMPRESSED-BYTES 3590 :COMPRESSED-SHA256
    "f7404c5c53f0801bd0d6b4df93b8453af3b6fff11f2d3b528a2f61f0d2761947"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/6-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12863 :STORED-BYTES 4133 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12863 :UNCOMPRESSED-SHA256
    "1277bfce1fb00f605044dd85f6d760075ec099dd65e5cc49762da28d1f145b43"
    :COMPRESSED-BYTES 3814 :COMPRESSED-SHA256
    "36657dd1a25d3c8b954c043c24889f2bf03f755d9904dcc638be4debc9522fde"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/4-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16716 :STORED-BYTES 4782 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16716 :UNCOMPRESSED-SHA256
    "d721d556b80acd9d51f11afa9b357bff63d300db9b312d09b6c5732615ea775d"
    :COMPRESSED-BYTES 4462 :COMPRESSED-SHA256
    "7243b69bf4ab24daa0823f73d9018bb2c1db4f0bca79186e88cf0056f4c81d4b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/4-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16705 :STORED-BYTES 5097 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16705 :UNCOMPRESSED-SHA256
    "15e8a3465d4f306eeb9a8251a1ec7a883d5a8bc6b2fab01f996ab7747d922823"
    :COMPRESSED-BYTES 4778 :COMPRESSED-SHA256
    "5d85adea2cae12dcda359859924196609263bd08b66ed2ebed9cda5aa191b434"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/4-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16708 :STORED-BYTES 5569 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16708 :UNCOMPRESSED-SHA256
    "00dd9003336c3f545db435ee28ccc0e1d6332f99b3ff2a98f6ffd265c00b8169"
    :COMPRESSED-BYTES 5249 :COMPRESSED-SHA256
    "2e4858307fd4bf3ea5c28156fd59379de30ded2e92a5ce8c5744c60c89cf0577"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/4-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16711 :STORED-BYTES 5403 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16711 :UNCOMPRESSED-SHA256
    "2743b4facda16f2d9ab445beb7c8dc7432eb1cdd48ffb6b555de79bd7fba8d30"
    :COMPRESSED-BYTES 5084 :COMPRESSED-SHA256
    "7736f4ccf9b76017bb5b7a73b0f33d8e7d1de372627859f59ce2114a352a1ecb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/4-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16718 :STORED-BYTES 6172 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16718 :UNCOMPRESSED-SHA256
    "b55121a6678156bf10295520760539bf8c46ffc17dbf67f6931ca23ce2bad4ba"
    :COMPRESSED-BYTES 5852 :COMPRESSED-SHA256
    "0cd564b87c0ee80b3d25685161f866352185bc85278b009cf086882f6904464f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/4-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16717 :STORED-BYTES 5927 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16717 :UNCOMPRESSED-SHA256
    "a20f64ee31cc385eff38fa146feb3b0313084b324896c8697fa2b4ad210b9e97"
    :COMPRESSED-BYTES 5608 :COMPRESSED-SHA256
    "ad4474ad218303071d486086b06aeefb8fe95a850e877ec2d70cc7d2dcc48766"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/4-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16717 :STORED-BYTES 5599 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16717 :UNCOMPRESSED-SHA256
    "5b76e87e6b90a084663552ee027474b56a4091cbd10a5f8c7236341d827d6cd2"
    :COMPRESSED-BYTES 5279 :COMPRESSED-SHA256
    "cffdf1a37d9e21d9b13adb4b6a3b40321dc6b313b53a8fca83ea4f63ec71946e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/4-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16694 :STORED-BYTES 6910 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16694 :UNCOMPRESSED-SHA256
    "e1e6a7aac8d7723c7b693e6209aa7f5975323487c60b42dab662ab5c34808315"
    :COMPRESSED-BYTES 6591 :COMPRESSED-SHA256
    "fce5f83416d9c2e5335cdc2dc0d1e0e547ac941533b04f91b9260d7c03cd7530"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/4-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16704 :STORED-BYTES 5988 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16704 :UNCOMPRESSED-SHA256
    "ee0a1c3800c8bf66561f49f30c0fec56b184718b7e61ba856cff987ad9e8abe0"
    :COMPRESSED-BYTES 5668 :COMPRESSED-SHA256
    "87da6cfacb9e90cf141d8208fc1e217b7ec791cc4d7ed365452943b9a8e5f8df"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/4-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16696 :STORED-BYTES 6371 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16696 :UNCOMPRESSED-SHA256
    "9c09463cde30bc26dd54d02006bd0e950a2d4c863fac781aac818d02060789eb"
    :COMPRESSED-BYTES 6052 :COMPRESSED-SHA256
    "3404c985eb275b219639e65196acb3583ff9006847b4ac107ee3dcf84e481c01"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/2-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12786 :STORED-BYTES 3968 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12786 :UNCOMPRESSED-SHA256
    "e173a3c260145ae80bbcead7acad227d6e514484cbcee6f2cdf67e0f92b7b2e9"
    :COMPRESSED-BYTES 3648 :COMPRESSED-SHA256
    "1f4431473904480777e7de3bb08cc8bd0d56ce0368e72f90ebaa0ed7d9a5f752"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/2-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12776 :STORED-BYTES 4001 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12776 :UNCOMPRESSED-SHA256
    "4b99eccbbe8e96bad18b74067bbc9fd0f81db0bed80d64f28bb4abe71b744632"
    :COMPRESSED-BYTES 3682 :COMPRESSED-SHA256
    "123aafb5c3ef13230a679f77d45d8e28e7d6abab70918f0611f00c69d8c1d036"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/2-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12797 :STORED-BYTES 3908 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12797 :UNCOMPRESSED-SHA256
    "e1a14c82b42e3ccc7d122371beeb8114673a9f98e4188c2205bfaebd0440934a"
    :COMPRESSED-BYTES 3588 :COMPRESSED-SHA256
    "0b4313a081b551300cc234712c447bdd5df92b7b1588e593ed1e3e47c8eedd7a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/2-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12729 :STORED-BYTES 3606 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12729 :UNCOMPRESSED-SHA256
    "8fc322287e3dbc436d1a0a0f5155ee9ba7f199fc716af49fb55ca23add77cea0"
    :COMPRESSED-BYTES 3287 :COMPRESSED-SHA256
    "6766f68ab9569b3fcf80441ca187ee24fc7a487a85bd434c305d8466dab297b2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/2-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12785 :STORED-BYTES 3807 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12785 :UNCOMPRESSED-SHA256
    "c4413bc90df66c470a22d674ed9a5bfc6a5981538f9e1859459eccc02c080565"
    :COMPRESSED-BYTES 3487 :COMPRESSED-SHA256
    "5d40199b5f3d8ac622f2b1c7b85f080e07b5efd485d1762fe661b850a0265124"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/2-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12758 :STORED-BYTES 4063 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12758 :UNCOMPRESSED-SHA256
    "b83126413e4888a2ddd50b255edcf204b1102295b3c830ebd02b84433fab19dc"
    :COMPRESSED-BYTES 3744 :COMPRESSED-SHA256
    "8e4e8c11a3e882e7f6dba4bc2e50f3874b7589071aaff10170cfede790ff3133"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/2-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12756 :STORED-BYTES 3713 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12756 :UNCOMPRESSED-SHA256
    "0df470cd8352cdd37e130b714df7204388ac5f7c276c18503066fb8ecd4a57ba"
    :COMPRESSED-BYTES 3393 :COMPRESSED-SHA256
    "dc0dfe86df31e6a4591e9b421c1cf9cd77960c23556ba03e85f11c9227d37f45"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/2-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12769 :STORED-BYTES 3932 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12769 :UNCOMPRESSED-SHA256
    "6b139fbf6c9990b8d73715cfddd2be52e0fbe8f3db4652c655cdd30340655f68"
    :COMPRESSED-BYTES 3613 :COMPRESSED-SHA256
    "f6e7b33ac0dc11d180c23150486ee30dc63f000690d73e6cf43bcd96409890de"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/2-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12811 :STORED-BYTES 4096 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12811 :UNCOMPRESSED-SHA256
    "e9d1cf6a3fd2a444636071b14e667d20d44e3ce4356db879a64c71602c782662"
    :COMPRESSED-BYTES 3776 :COMPRESSED-SHA256
    "9ff6733e6ffffef88fff055ad2f0694e408b46d098d80352e5490d9f4327a889"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/optimized-repeat/windows/2-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12946 :STORED-BYTES 4691 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12946 :UNCOMPRESSED-SHA256
    "ca79d5f65d4008fa8349a57810b12bef682c6d7841f58faae087227484633a20"
    :COMPRESSED-BYTES 4372 :COMPRESSED-SHA256
    "4043ee3533284c94bbf7007891711e838c3d5844c3b5d83642f276f1a6dc5528"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6406 :STORED-BYTES 1294 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6406 :UNCOMPRESSED-SHA256
    "f09a0d4cde33fed55c40c40b40396392b480801e31bc0915fccd9bd5288b0158"
    :COMPRESSED-BYTES 980 :COMPRESSED-SHA256
    "bef9cec05a997dc6a1fc30a203ff288f11fe4caf5aa2df6a15200f1e806ff01c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6194 :STORED-BYTES 1168 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6194 :UNCOMPRESSED-SHA256
    "b5c11bdf875333cccdeacf70876379a2c74b2f6d04035439d45bb943079b2fde"
    :COMPRESSED-BYTES 851 :COMPRESSED-SHA256
    "4e42cd9ebdaedb894389bcfebfd95ddaf8f4e0b398d17ab2f530eb17b39e64bf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/8-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16711 :STORED-BYTES 4909 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16711 :UNCOMPRESSED-SHA256
    "9f30d18749283cf293f1a99d008ae32e529dcadd4f6f396aba60f4020ad38c9f"
    :COMPRESSED-BYTES 4589 :COMPRESSED-SHA256
    "d4172aa8fd9810d919a320070a54f5f04c56452250e5f1b337b62f6da86cd89b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/8-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16714 :STORED-BYTES 4682 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16714 :UNCOMPRESSED-SHA256
    "f5e06f4f8dd5b559569208ccc7714730e19a1f9f381b98c7325d6cb33b05a2f1"
    :COMPRESSED-BYTES 4363 :COMPRESSED-SHA256
    "aa9e105bb0f77bb8ae52cb369f608f86e78eda884c2fc2cab374db6485dda0a3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/8-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16717 :STORED-BYTES 4419 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16717 :UNCOMPRESSED-SHA256
    "6a229a0f55c1d6bcd95b82a587046a08e4f3269ff03a88d333983b21cfe7c448"
    :COMPRESSED-BYTES 4099 :COMPRESSED-SHA256
    "e1140272117643a72f5f59255f7e44a3a2d0d08586e6859650e5360bb3ca7897"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/8-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16714 :STORED-BYTES 4579 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16714 :UNCOMPRESSED-SHA256
    "a0e69b5851a5213c2bac06cf5055f257a4d64a75743c03003c71ded27cef0fc9"
    :COMPRESSED-BYTES 4260 :COMPRESSED-SHA256
    "b12ae7d79932f6cef67430caa2c711f9549c3999982fb4c2ae4ed45d70dd4212"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/8-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16717 :STORED-BYTES 4481 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16717 :UNCOMPRESSED-SHA256
    "297c8bb4992c88ae92f8fa37de0fef3474aebadd2323f4b3c937f40e20ddbe7c"
    :COMPRESSED-BYTES 4161 :COMPRESSED-SHA256
    "03d94ed362942d139ce626260724b54a7b1a9dde2b7c625688801e0cd131ca13"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/8-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16716 :STORED-BYTES 4422 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16716 :UNCOMPRESSED-SHA256
    "b07edaf6667315230bc3ab6d19563325311cc98d4812af13a08879024018a0ae"
    :COMPRESSED-BYTES 4103 :COMPRESSED-SHA256
    "d6195c73c56b8fba2bca0cfec200089997f63bde5293a042e4ed2cc453da218f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/8-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16716 :STORED-BYTES 4841 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16716 :UNCOMPRESSED-SHA256
    "15eecbcdd52c90832c0b8e3d904eb2ba808f8ec67fcaa67156763b22ac121155"
    :COMPRESSED-BYTES 4521 :COMPRESSED-SHA256
    "7830cd80b7fb446698847a3f447c4d11ac1f59daecd98c6271519a0628d289da"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/8-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16713 :STORED-BYTES 4486 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16713 :UNCOMPRESSED-SHA256
    "9bc18ecbcd09283387ec9b4e7c22b468c0ce3463ee27c4be43804993b0a30952"
    :COMPRESSED-BYTES 4167 :COMPRESSED-SHA256
    "8a1dcee2bd267f788fcdb415b42fc3ff0de7dc5fdab371c7831ae4e7f17bda0e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/8-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16714 :STORED-BYTES 5049 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16714 :UNCOMPRESSED-SHA256
    "82eb38e026a2debc6330c5df0664afa62d8a17c6d2e01f351ecdddd3919be8f0"
    :COMPRESSED-BYTES 4729 :COMPRESSED-SHA256
    "e46d3c26b2d009d035ed7a39fc56b5af3e22ff56788777eefe6b29c1b56a20c2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/8-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16697 :STORED-BYTES 5515 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16697 :UNCOMPRESSED-SHA256
    "ba98e41285ff2f8e603992a908c8c6b084aae523ed9aa2a46efb4b1dc786e6bf"
    :COMPRESSED-BYTES 5196 :COMPRESSED-SHA256
    "bba4b182d6dc40935e6239179b3ea901d194aa0c3b3365cb601522c88b987b63"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/6-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13156 :STORED-BYTES 4991 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13156 :UNCOMPRESSED-SHA256
    "82fda848813d92f73e3b1f719bad28a730fd2ea7121cc7f9be9fb6f2f705c73b"
    :COMPRESSED-BYTES 4671 :COMPRESSED-SHA256
    "9e3fd931996cf61832d98bf7dba0d04127ae155137ebde63b559a5bd0540a1e5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/6-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13086 :STORED-BYTES 5153 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 13086 :UNCOMPRESSED-SHA256
    "b0dc580daed2756d0b705f32f28f3978a2054b504710f363dbb7bdbbf4f18b0c"
    :COMPRESSED-BYTES 4834 :COMPRESSED-SHA256
    "983b2af271f645b33b81555350122ae2675e5939ddaa4a7c951c3ef38e886e54"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/6-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12787 :STORED-BYTES 4284 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12787 :UNCOMPRESSED-SHA256
    "0205fb5f5f949edbc7f56b26596690e10afc342567fe4f5d86905b75bde97394"
    :COMPRESSED-BYTES 3964 :COMPRESSED-SHA256
    "796e6ab220648fc23b2c680c9877fafb137ca6c00129261575538a75cbb81c6a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/6-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12727 :STORED-BYTES 3880 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12727 :UNCOMPRESSED-SHA256
    "dfd5e4454bf2f5fddb08e01a6295b6cb030743f668e7de88d9517de14f97b535"
    :COMPRESSED-BYTES 3561 :COMPRESSED-SHA256
    "2d3692da08e4388eb736d3661e7c75e23257330e00438d860d9a2a8cb2ea31d1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/6-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12730 :STORED-BYTES 3617 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12730 :UNCOMPRESSED-SHA256
    "affc118e4e0ad0acccf399882fba7ccd65230341aa890019c01be060fe2d6189"
    :COMPRESSED-BYTES 3297 :COMPRESSED-SHA256
    "0ad298de14fc3e363d3f5dd569199750bd7f8b8a8bfb6f114a8c68ad803a84f8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/6-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12734 :STORED-BYTES 3712 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12734 :UNCOMPRESSED-SHA256
    "ac5dd95b330c511fef6ccecb9ba72cf19044c3b6f89a7baea879d51b6ea21ba2"
    :COMPRESSED-BYTES 3393 :COMPRESSED-SHA256
    "3bf251173ffe357a00af0e2327fe762d2ebe93c617da6ca5a99bad4ae2ed276f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/6-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12755 :STORED-BYTES 3938 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12755 :UNCOMPRESSED-SHA256
    "51b8f8b27b44da10c3b02e97c2d3c4b161b5c07a7ef9291903297a42cffc5abd"
    :COMPRESSED-BYTES 3618 :COMPRESSED-SHA256
    "5e2ef4f24e6ceb456b52476cd903cb81b472b7f038dfe26617eb276220dc0fdc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/6-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12740 :STORED-BYTES 4120 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12740 :UNCOMPRESSED-SHA256
    "3956892609beed8433c62ab79ac226a27971498d0f79797e68e00993a30eff96"
    :COMPRESSED-BYTES 3801 :COMPRESSED-SHA256
    "098db212fb8d42f0e85364173d322e42505e14a815f3c87bed2f7ce4be850676"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/6-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12782 :STORED-BYTES 3892 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12782 :UNCOMPRESSED-SHA256
    "14ee6ec93bf534a4095e7bb222cb7f8b42bc12000174fec3591d72d3f04a4b01"
    :COMPRESSED-BYTES 3572 :COMPRESSED-SHA256
    "abfd8f5aa90bc932724340ccd8f554b13b5f21614a0c57dd003eb7f379d3cc2d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/6-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12960 :STORED-BYTES 4963 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12960 :UNCOMPRESSED-SHA256
    "7a44d4b75cb03c25d7410136ebcd8a67d132a159fd6733134723b8b3dbbe69c4"
    :COMPRESSED-BYTES 4644 :COMPRESSED-SHA256
    "194c55ca5e9541715ddd04615cc87dcc1a7e91ea39226c022ee7990f16a9ddef"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/4-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16690 :STORED-BYTES 6117 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16690 :UNCOMPRESSED-SHA256
    "0657dd3821c0f6a24b0cc89c78d79a388b860ee864548b93b9a5e212a16ca000"
    :COMPRESSED-BYTES 5797 :COMPRESSED-SHA256
    "2cd2802281dfd7faeff6c6062cbfc2c0de288af0a7baebc4fe9c7211fbbb9a1c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/4-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16713 :STORED-BYTES 4878 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16713 :UNCOMPRESSED-SHA256
    "ee99ddfe1607ae92cd402ae3e1422a58c41d877bca236a88cce898641e286877"
    :COMPRESSED-BYTES 4559 :COMPRESSED-SHA256
    "8ae38545bdd82f4f74dcadf112406e919ce63874e0b74ac68b8cba7ad390c72c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/4-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16714 :STORED-BYTES 4902 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16714 :UNCOMPRESSED-SHA256
    "f182bf014fb05d3bcaf88cb9f1a24e679336f1507fda1cf05bbb4ff8d469820d"
    :COMPRESSED-BYTES 4582 :COMPRESSED-SHA256
    "7769d9e201e4bc822218c3f14941a305cfefe481c2f68214b3d845568e02923a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/4-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16707 :STORED-BYTES 5178 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16707 :UNCOMPRESSED-SHA256
    "9e718b8954c275036d31edc51b6f48ee302bb54dcd4112524674bb120c9bef14"
    :COMPRESSED-BYTES 4859 :COMPRESSED-SHA256
    "6b71d04720fdc31c60a967d3f9a44bb407b682aea7980aded37b5edc9349c034"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/4-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16717 :STORED-BYTES 4756 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16717 :UNCOMPRESSED-SHA256
    "1e00d902c4d96cbc2eecf58db520087f45b4c526a3410a01ce66159c0d6e49f6"
    :COMPRESSED-BYTES 4436 :COMPRESSED-SHA256
    "f154bac3fcf217311b23c7a4493aafd206784ae7ab52765145d03bfa39fb2fcc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/4-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16712 :STORED-BYTES 4883 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16712 :UNCOMPRESSED-SHA256
    "3ecb78e162741d36853d7859650bdb76ea14afd2dda5c7453462cf69df21702e"
    :COMPRESSED-BYTES 4564 :COMPRESSED-SHA256
    "fe6a119eb6becb58667ad0d16080b3bf5f30ce6cb7c518a324372e880e3a8663"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/4-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16718 :STORED-BYTES 4639 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16718 :UNCOMPRESSED-SHA256
    "f07dfb289e4463539544f82eae2d950c34390a587630e11faaaff78741853133"
    :COMPRESSED-BYTES 4319 :COMPRESSED-SHA256
    "21c7310bb406457b297fcaec6487e7f99c4dc8d9a89ff22ead774447d29c71f5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/4-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16717 :STORED-BYTES 4792 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16717 :UNCOMPRESSED-SHA256
    "004a824fc04cd4b2e492c02a71e870ce15e59de53ece78caa17dd6f0fd70e631"
    :COMPRESSED-BYTES 4473 :COMPRESSED-SHA256
    "2c74d2ae8a109768d8fac62c7f7708e8ff2389e057d2cfbfcd7d1649521717fc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/4-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16713 :STORED-BYTES 5159 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16713 :UNCOMPRESSED-SHA256
    "9e1c272c561249a4db9f3adf8243d723a241019bc2ee15e165c85f2d999a7749"
    :COMPRESSED-BYTES 4839 :COMPRESSED-SHA256
    "1a1ad5cd532d1567e51684b6d9c9578eb00f439f6e3edc4da2f5495f57193691"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/4-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16713 :STORED-BYTES 4939 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16713 :UNCOMPRESSED-SHA256
    "ea05b0570da335e4bb03b4a22ca10c03f5e02e653f81ad58fdd250ff32308034"
    :COMPRESSED-BYTES 4620 :COMPRESSED-SHA256
    "62330489e24523712e324a718bee8817583210c5a26bc8c6882ac1ff5e32316b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/2-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12741 :STORED-BYTES 3813 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12741 :UNCOMPRESSED-SHA256
    "fcee6697c9b164856c832c288253b768e0e6026f901585dbf7def9c6a304b481"
    :COMPRESSED-BYTES 3493 :COMPRESSED-SHA256
    "b5db357b335a29b6904530f175fe8dc7210ffcc4b4373dbd3b1a887d51dc20df"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/2-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12776 :STORED-BYTES 4374 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12776 :UNCOMPRESSED-SHA256
    "9b73d816d5dceea282a64c6d2d73d65377ce7b7cc2fd60847cfb2638764573e0"
    :COMPRESSED-BYTES 4055 :COMPRESSED-SHA256
    "f64c12349fd1520ba9f6cf81f927dca06d612d4598c6c18611b1942aecde8d78"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/2-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12761 :STORED-BYTES 4028 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12761 :UNCOMPRESSED-SHA256
    "a145c47335f6d89a54e7866ff4fbeb399b9c9681d3de699839c23a963d1005e0"
    :COMPRESSED-BYTES 3708 :COMPRESSED-SHA256
    "91e60f387fb5094cd22b9a79953fa4e33449827a7cc0c28dabe71e7f4a8920bc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/2-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12794 :STORED-BYTES 4196 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12794 :UNCOMPRESSED-SHA256
    "45359ee75922c6f0f6e2c2c005ecc9120e82bfec77d4b6c09a1eef621e053bd7"
    :COMPRESSED-BYTES 3877 :COMPRESSED-SHA256
    "ec637d20333beaef5593aeaf5f275738251ebc3fd8d084c872ee2d628827bd94"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/2-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12760 :STORED-BYTES 4211 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12760 :UNCOMPRESSED-SHA256
    "5fa577d95df621a4939b00065ea47a514b5f45409db475ab267c8f888931d76b"
    :COMPRESSED-BYTES 3891 :COMPRESSED-SHA256
    "d3527d9d5c1592f8637dba10feb26b84487b30032ce8650ba01ce1cbcd738709"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/2-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12779 :STORED-BYTES 4330 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12779 :UNCOMPRESSED-SHA256
    "d7dae1ba0c80fc81d1481c1ae53a3da97b05c9145b2ece0929c237b97d2baf67"
    :COMPRESSED-BYTES 4011 :COMPRESSED-SHA256
    "1fc7f728aeaae19d5928fabed6d918414cae20e9f4052c77026ddf293755284d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/2-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12830 :STORED-BYTES 4807 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12830 :UNCOMPRESSED-SHA256
    "f3d965fa5edad49ec5e338a84b3a8ff342a37eb6c7d1baef6b3a9cc4719047d2"
    :COMPRESSED-BYTES 4487 :COMPRESSED-SHA256
    "56828c06b48444e51b3a777613e99736ed3960502136d30e527f2a16c3dea980"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/2-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12958 :STORED-BYTES 5061 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12958 :UNCOMPRESSED-SHA256
    "4183f20d56de3c655929908197aef3cee12eb9e9552589993ff2304fd01995bc"
    :COMPRESSED-BYTES 4742 :COMPRESSED-SHA256
    "a3092735559e15d30f810bd88b3d54ca4ef0bcba19296c6527d2d4d9176b6b4e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/2-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12805 :STORED-BYTES 4637 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12805 :UNCOMPRESSED-SHA256
    "5b9fdf445054afc701f6c1782419ba98f48d37808a90e9a1a1f1d493c1af8f53"
    :COMPRESSED-BYTES 4317 :COMPRESSED-SHA256
    "44fe26b9d1ecf946a002bb835a543fd3daad56f0c50d67d792199e76dd2d2135"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-final/windows/2-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12848 :STORED-BYTES 4480 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12848 :UNCOMPRESSED-SHA256
    "69e7cf2c4c3bc867559600004f78ca7bc07ff4ed3fdd347ea18c06d7f4abe886"
    :COMPRESSED-BYTES 4161 :COMPRESSED-SHA256
    "dc3e3ee0d506c06f8af3deb9d99857f5389632649108edbf28dd34d534870495"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6423 :STORED-BYTES 1289 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6423 :UNCOMPRESSED-SHA256
    "2d0cae53d4b744f15d5def4753b99004ef7a81d875dcdf61c3bd9891fc5d93e4"
    :COMPRESSED-BYTES 975 :COMPRESSED-SHA256
    "b0e5d8f2091b33fcdea6f4ef3fc14c8c39ed9a9af034a5ebbf7e3463b0abb12c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6210 :STORED-BYTES 1164 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6210 :UNCOMPRESSED-SHA256
    "b2f459177a9c03b7260f1911a38b41667f9d0db6b4be9dcd699e928e8120528d"
    :COMPRESSED-BYTES 847 :COMPRESSED-SHA256
    "42d0b41dc12fe18393b7b27b70075a2a59b55eab4c62666f428dc9021abccb65"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/8-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16694 :STORED-BYTES 5174 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16694 :UNCOMPRESSED-SHA256
    "bec18fe03fa1c8018d32ea490e94b1361eb206605f27722da654a091af411a44"
    :COMPRESSED-BYTES 4854 :COMPRESSED-SHA256
    "0086ecbfe8573be759d3cc0e8dc0dfbd7421041c89ad122bb5b852ed3939d4c8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/8-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16698 :STORED-BYTES 5401 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16698 :UNCOMPRESSED-SHA256
    "11f3f140cc84f641622daacf09fa83d3fa6eb420a86eb11303f71198086a9352"
    :COMPRESSED-BYTES 5082 :COMPRESSED-SHA256
    "7867e75958a20023d1c6daf07662e36f5769a562484bf4c4983fa865c95c9074"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/8-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16708 :STORED-BYTES 5783 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16708 :UNCOMPRESSED-SHA256
    "8df3b6c8f4bb5a37d7b5fd21ea9e977baa3cb3e261ce28f0bcd73c3c6c47d11a"
    :COMPRESSED-BYTES 5463 :COMPRESSED-SHA256
    "7aa58e4dc42285667972ead1c4227606ec01d12c3e33d5ff36976c9d6b57bffe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/8-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16687 :STORED-BYTES 6151 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16687 :UNCOMPRESSED-SHA256
    "cdf06f0fd87995e0a51e902f26df86b84a7fe1cff8d7a76656f975715551b1b5"
    :COMPRESSED-BYTES 5832 :COMPRESSED-SHA256
    "27714193ee94d83a521759dccd1f01d615401a79f1719445346b9664d3584d89"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/8-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16714 :STORED-BYTES 5222 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16714 :UNCOMPRESSED-SHA256
    "67860d56aeadc9dad0020451c0338c86f59d7ba7aae74e76d9f5072befe6f81f"
    :COMPRESSED-BYTES 4902 :COMPRESSED-SHA256
    "705530a35fb6abf6398a26ca5e158db1c619ade020b26d0d764420befc9e6c53"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/8-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16707 :STORED-BYTES 5041 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16707 :UNCOMPRESSED-SHA256
    "73eb4137f2d3f132c64f102f836406c55f3d30f98e7659a9dc153ae3e347446c"
    :COMPRESSED-BYTES 4722 :COMPRESSED-SHA256
    "4cf98c668358237ff591368fe4733ce95c5954f6c6b43515fecd1bc6f7dcd4ae"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/8-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16703 :STORED-BYTES 5013 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16703 :UNCOMPRESSED-SHA256
    "923b06eb030890a99a613628de72d62b3796baacff3dfd5cc5415d82356e8282"
    :COMPRESSED-BYTES 4693 :COMPRESSED-SHA256
    "40cf6a8336de6df9c33971f0ffeefe17405594919f4dac66e11af192cfa2b02d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/8-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16696 :STORED-BYTES 5293 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16696 :UNCOMPRESSED-SHA256
    "f285b8af917732c7d3df741689542468f1da3fcb4ac00d38b3790d1f6a2f6d8c"
    :COMPRESSED-BYTES 4974 :COMPRESSED-SHA256
    "03cd6bb03b4a96f0c144dddefaf049b9527b38ece780b85d3bfd19e888ff0c5f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/8-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16697 :STORED-BYTES 5221 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16697 :UNCOMPRESSED-SHA256
    "dc436de6e926c9d5ba997829e4f01d4d36b6f247db699185e728ef506806756e"
    :COMPRESSED-BYTES 4901 :COMPRESSED-SHA256
    "e81db386965fcaf07bf14172763bdc5fc318467b7f11794501e063c198718c46"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/8-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16708 :STORED-BYTES 5580 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16708 :UNCOMPRESSED-SHA256
    "5df8034f767d34b021d7d7db44f161bd2196d1e81fe521b053e58d7610e5761d"
    :COMPRESSED-BYTES 5261 :COMPRESSED-SHA256
    "01ddc494b360dd9deb4919c27945fe3c821dfb79745770cde2e93b815781914c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/6-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12760 :STORED-BYTES 4295 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12760 :UNCOMPRESSED-SHA256
    "e184c5659b4fc83f4db02072c3e78f204ed2a6a7a94ab5daa963e9a197b0238d"
    :COMPRESSED-BYTES 3975 :COMPRESSED-SHA256
    "27554515b54102da8e0870d7a0c6cdc3300766477ac0c4992d75255b05fcf9e9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/6-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12754 :STORED-BYTES 4606 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12754 :UNCOMPRESSED-SHA256
    "0a3a4cfb8dbbe58ef5e249ddd4dccb8337ad1a2aa23fec62243016c1bd079d2b"
    :COMPRESSED-BYTES 4287 :COMPRESSED-SHA256
    "158eb58875f9dbc4b197a5075cd2768644269f3329c9e815fc976932f364b09f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/6-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12739 :STORED-BYTES 4536 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12739 :UNCOMPRESSED-SHA256
    "4b5b47654eec2c86dd76a3d044270c9d39160c0a2bd3f46e9282484e9f3aa23e"
    :COMPRESSED-BYTES 4216 :COMPRESSED-SHA256
    "e7722494b300c6d5dc060fd4dbcf18bc688eda4003c0e99f98663187c75158cb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/6-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12764 :STORED-BYTES 4672 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12764 :UNCOMPRESSED-SHA256
    "1a60285925dd08e0eb117da510a80f51a79c293c662d671d63913a36916268b4"
    :COMPRESSED-BYTES 4353 :COMPRESSED-SHA256
    "7057dfced1731962f345eacabc2ccc4feadb9eed4a25233a818d44fb5ff953d7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/6-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12752 :STORED-BYTES 4598 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12752 :UNCOMPRESSED-SHA256
    "1db35d8dd067e6e2091e459e52ef486362fbc549f3a984d1d1569fe6571db687"
    :COMPRESSED-BYTES 4278 :COMPRESSED-SHA256
    "9b82a37d7b7b173841df5bf99f768a24d4465e31f7ecb82cc1650dccb4fdd256"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/6-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12757 :STORED-BYTES 4679 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12757 :UNCOMPRESSED-SHA256
    "a12bdcf5721445a15c7c419f4202a36ea6fa279eb492b8dd31f3f3006ac3972b"
    :COMPRESSED-BYTES 4360 :COMPRESSED-SHA256
    "da7f5fad0948265977111dcfe61e2b152517b00c96d6d8076eb6bea355788b26"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/6-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12735 :STORED-BYTES 4027 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12735 :UNCOMPRESSED-SHA256
    "c77e79fb393bd951652a51e5ce5cb0bee20c45a29cbee32b91f19c57319be207"
    :COMPRESSED-BYTES 3707 :COMPRESSED-SHA256
    "cd888f6a151f37295acfd555e41ba9b00415adb93bd1bd8f1b61751b2bad4643"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/6-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12758 :STORED-BYTES 4539 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12758 :UNCOMPRESSED-SHA256
    "65dd5f505257eb4c7879ac3494d42e4fda79cd62bd880cdadf11357e6858bf75"
    :COMPRESSED-BYTES 4220 :COMPRESSED-SHA256
    "9e4c13d9427db418256eacd6598524bbd280e99fc119919df042548eef52a125"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/6-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12750 :STORED-BYTES 4519 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12750 :UNCOMPRESSED-SHA256
    "e60819cb77e3d46a684c2ccfb138df3bf3f887aaf458675b68acf19c6e7e8c6e"
    :COMPRESSED-BYTES 4199 :COMPRESSED-SHA256
    "40188bec2ee60e3e7fec3be22c3f2c8a6fd4a9685a2a61e1bef5f6362e5e243a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/6-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12809 :STORED-BYTES 4797 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12809 :UNCOMPRESSED-SHA256
    "348bc0ebd768995379309fa3969de605afa20d518bc3e5d27719c7c69fd6481b"
    :COMPRESSED-BYTES 4478 :COMPRESSED-SHA256
    "19b1d06b2f42fe835fd1220345d0cf73545aca32498afb082e26b75769e36c82"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/4-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16696 :STORED-BYTES 6305 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16696 :UNCOMPRESSED-SHA256
    "ab1a805c5af73001c088e8bb5ec000dcab48a6a521de12d35d1360b62cdef42b"
    :COMPRESSED-BYTES 5985 :COMPRESSED-SHA256
    "8a22b9809331bcc5f6fc8003a285dd6b22fedf2cd793ea694b5190abfb07ae28"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/4-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16671 :STORED-BYTES 6601 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16671 :UNCOMPRESSED-SHA256
    "5edf9f99eb9e1b54abd9364da9a17fa78a77a7637b2a99ed6b3625de5cac0b02"
    :COMPRESSED-BYTES 6282 :COMPRESSED-SHA256
    "a7af733822aecd2ead27ced101401e3191f7ccc883861f81006cdb8af33aa6c7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/4-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16717 :STORED-BYTES 5393 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16717 :UNCOMPRESSED-SHA256
    "5677811c17bbc17f0271489dfd07987462d0804a27595eb1efe7a025a87c1f51"
    :COMPRESSED-BYTES 5073 :COMPRESSED-SHA256
    "669af357eb4a06e773fe2d143040f126ca403c29a9a3dc66a6dec27c5d215378"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/4-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16680 :STORED-BYTES 6080 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16680 :UNCOMPRESSED-SHA256
    "106715ed13cd3b876b588891dbebe04a314900463743852b5aae9ce111f34e6f"
    :COMPRESSED-BYTES 5761 :COMPRESSED-SHA256
    "03ce33752316e2bb1fe0a0d95b8ea9eef622a62778a116fb260c4d770eddb186"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/4-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16708 :STORED-BYTES 6331 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16708 :UNCOMPRESSED-SHA256
    "9be9aa8eae2a17f383e869b86f9257b0cbe885cb60f42bc28062dc434e98db62"
    :COMPRESSED-BYTES 6011 :COMPRESSED-SHA256
    "ec0cbc2291617d05ff5548b1ea0ebbce11ddc6a0656b9acd46db0a51192acf15"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/4-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16777 :STORED-BYTES 7359 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16777 :UNCOMPRESSED-SHA256
    "a01ea3697d7b44f62ef94a6f57dbd127df07f683a9e2eb9a0ef09be571db0463"
    :COMPRESSED-BYTES 7040 :COMPRESSED-SHA256
    "fb321bd926de7872c0e8b094052df3e91664839246d75047b7925d403206f29a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/4-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16697 :STORED-BYTES 5939 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16697 :UNCOMPRESSED-SHA256
    "9a44933eeb85140fef974a0ce5d7808e0784a386371474222be644df845abca2"
    :COMPRESSED-BYTES 5619 :COMPRESSED-SHA256
    "0fc96e482121dd665adc87496de0d3be134e4f16029fe8629a7458ac8748ef05"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/4-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16659 :STORED-BYTES 6305 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16659 :UNCOMPRESSED-SHA256
    "f9ac06fda0c4fa8d49b128a1975dcdb09e1d1aad4fe8e7243fcba366079c4721"
    :COMPRESSED-BYTES 5986 :COMPRESSED-SHA256
    "c728ac07b37f4a326ea3907192ef2418d1749bcb8daf1759f0bca42478f6fef2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/4-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16713 :STORED-BYTES 5672 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16713 :UNCOMPRESSED-SHA256
    "464b2fe18209c12540f6217780e3a180149c229c01b1cbd4ea55f30b118ce136"
    :COMPRESSED-BYTES 5352 :COMPRESSED-SHA256
    "6743c211a6732a83208ce473f4dd116fddb724f17d959231286dbe71e25dfcdf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/4-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16717 :STORED-BYTES 5225 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16717 :UNCOMPRESSED-SHA256
    "bb0f285165dbe56a3d6eef9479bf5490b6dd27df3a27012b7f519cdf3325faf7"
    :COMPRESSED-BYTES 4906 :COMPRESSED-SHA256
    "063b9aa31449f6b8be58cefb79430641bb9f44f740fd846e88eba05958e6ec73"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/2-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13462 :STORED-BYTES 5058 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13462 :UNCOMPRESSED-SHA256
    "bce3f1ab0b650cca09340dcb69d97246acfd3c272677672224090d217618c170"
    :COMPRESSED-BYTES 4738 :COMPRESSED-SHA256
    "292c8eb23a8120a210973a94729b00bbcc6f7f708598ffd3b51a01f8f7261fbd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/2-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13152 :STORED-BYTES 4651 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 13152 :UNCOMPRESSED-SHA256
    "1371e3e204a7140f6184edba55cddfa2abaff62b5dea057ebd1bcacbc7580087"
    :COMPRESSED-BYTES 4332 :COMPRESSED-SHA256
    "3d928118965413f9bdea1d230afdec348eb94ab3da6be3502d3ab89b3a263ff3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/2-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12980 :STORED-BYTES 4349 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12980 :UNCOMPRESSED-SHA256
    "de2be06aab662d446cc33f1efa3b082e83ee6dc38dba34981ada1be3f36cecae"
    :COMPRESSED-BYTES 4029 :COMPRESSED-SHA256
    "589896f3087270978549786d8550390d6c744bb179611a9c18a284b758d67a84"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/2-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13278 :STORED-BYTES 5022 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 13278 :UNCOMPRESSED-SHA256
    "2819b8237cac023a88e26521b13ec143a03e5d15d20e1ee3d7c04fb1e11dfa5f"
    :COMPRESSED-BYTES 4703 :COMPRESSED-SHA256
    "3dad47cd0c31172516c96331588fc7ae47d2011078c0b97f3b8731a667297e8b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/2-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13135 :STORED-BYTES 4670 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13135 :UNCOMPRESSED-SHA256
    "7ca919912377a6750b94becbcb22c8ecdc0793d400fcd2e571cafa27a268a067"
    :COMPRESSED-BYTES 4350 :COMPRESSED-SHA256
    "9e4dcc044d573c8e09aff1aa77791913e6987014bd23c37055926f2db2b2b638"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/2-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13119 :STORED-BYTES 4690 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 13119 :UNCOMPRESSED-SHA256
    "7868d1b8ab8418a15ce4744a9f55338442bc01d2d5b198f17e3e7b124e8b52ce"
    :COMPRESSED-BYTES 4371 :COMPRESSED-SHA256
    "48fc0ee7c1f3d2598138599e4600739cbf30083dd5c97f7c7154e13db46a5080"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/2-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12838 :STORED-BYTES 4653 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12838 :UNCOMPRESSED-SHA256
    "ce48b16a639c11169e688775af65945c25ffbe5089c009e944426b179a2046b8"
    :COMPRESSED-BYTES 4333 :COMPRESSED-SHA256
    "943346af2504079132980eefd70d2a5b5341ccc8340547c65ff44d04ee8d096f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/2-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13016 :STORED-BYTES 4039 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 13016 :UNCOMPRESSED-SHA256
    "087ad24d289d05dfe6eaae2dfb3dc9960d0a86f3faaeef56ca94179df1378f88"
    :COMPRESSED-BYTES 3720 :COMPRESSED-SHA256
    "6ea5ab9cb358f402eacd6d42e124ba54fb69e228c993a847db62ad6953c9bfb1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/2-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12939 :STORED-BYTES 4171 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12939 :UNCOMPRESSED-SHA256
    "42b43726ba7e19e9f2e75fef66a3a50963b25bcd800734d3012f1708201e345a"
    :COMPRESSED-BYTES 3851 :COMPRESSED-SHA256
    "4dba60232778b6d105ec176f9681f8e585c59207ef3f9f47dbd7e3caec051ea8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-repeat/windows/2-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12986 :STORED-BYTES 4146 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12986 :UNCOMPRESSED-SHA256
    "c766979ea601b24cb6c72e840ec7be2312771afca36b391f0b9da16b4cd694b4"
    :COMPRESSED-BYTES 3827 :COMPRESSED-SHA256
    "a36aeae4ba066c52131487da0cdd5708e04e4257c7b5f8bfb9967831fbdbd8b2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-smoke-01-variant/paired.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5947 :STORED-BYTES 2341 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "paired.lisp.gz" :UNCOMPRESSED-BYTES 5947 :UNCOMPRESSED-SHA256
    "fa28bce8dd6ee94ddc3bd3a2a6afd27de55901a4d6616350d804e49c63b660a4"
    :COMPRESSED-BYTES 2029 :COMPRESSED-SHA256
    "ffaabb431afb53d05897bfa28c62ac1e5a237f081e3eab32831dc74c07239f18"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/paired-smoke-02-variant/paired.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5948 :STORED-BYTES 2341 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "paired.lisp.gz" :UNCOMPRESSED-BYTES 5948 :UNCOMPRESSED-SHA256
    "876e80c4f9e2969f32a8f5bea3e9bcdc221b7260b2d2c3fbf1e860a0850c3910"
    :COMPRESSED-BYTES 2029 :COMPRESSED-SHA256
    "b44cc1f4d556aa893891eba4ad3f69d8c7a0685646d08fa78b3681994d3f3ca7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/qualification-2.6.10/started.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27242 :STORED-BYTES 5407 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "started.lisp.gz" :UNCOMPRESSED-BYTES 27242 :UNCOMPRESSED-SHA256
    "1db1074f2ca8aa78ac5046da1e662bd162ae72dccd8c1f7c8e68a33bd36024c5"
    :COMPRESSED-BYTES 5093 :COMPRESSED-SHA256
    "96663a4ccb8cce3cb0cad81497a50d42db8e4a6e6b1770c3aea968a604be5b2b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/qualification-2.6.10/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 65186 :STORED-BYTES 6686 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 65186 :UNCOMPRESSED-SHA256
    "e1023a649b1697babd158fa730f9b47c1511d1b8b0a3bb1618704f603709b7d2"
    :COMPRESSED-BYTES 6373 :COMPRESSED-SHA256
    "a04a9fd7cb259c893bc484ba2239fcd13f2ba9c149de151717a90d4da0b74989"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/qualification-2.6.10/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27011 :STORED-BYTES 5379 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 27011 :UNCOMPRESSED-SHA256
    "1c08107dbeb051844ce457f810ad8be84e561ea9272852124db0e66d78be7958"
    :COMPRESSED-BYTES 5063 :COMPRESSED-SHA256
    "c773663baf27e713c81e669c94e118d42d4337ae8705832958233998c97afa12"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/qualification-2.6.9/started.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27241 :STORED-BYTES 5407 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "started.lisp.gz" :UNCOMPRESSED-BYTES 27241 :UNCOMPRESSED-SHA256
    "b3f7056fc6810e994f1d11a741a65636e7e431a562d765b068af7708f4daf412"
    :COMPRESSED-BYTES 5093 :COMPRESSED-SHA256
    "7a7699317f0e7253121685b0371049c58faa2b568f88c4d8ee40b8aa8c7459a7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/qualification-2.6.9/events.lisp"
   :STATUS :OK :ORIGINAL-BYTES 65186 :STORED-BYTES 6686 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "events.lisp.gz" :UNCOMPRESSED-BYTES 65186 :UNCOMPRESSED-SHA256
    "e1023a649b1697babd158fa730f9b47c1511d1b8b0a3bb1618704f603709b7d2"
    :COMPRESSED-BYTES 6373 :COMPRESSED-SHA256
    "a04a9fd7cb259c893bc484ba2239fcd13f2ba9c149de151717a90d4da0b74989"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/qualification-2.6.9/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27010 :STORED-BYTES 5378 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 27010 :UNCOMPRESSED-SHA256
    "f904ffeebf93891f93dcad5d6eb72a2a4982b453a6f74301c690f7aa58b67684"
    :COMPRESSED-BYTES 5062 :COMPRESSED-SHA256
    "ad7af5677ee55d21433fe01930eb44a120da3bdbaef978c5d9e1e7a6a3059471"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6474 :STORED-BYTES 1292 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6474 :UNCOMPRESSED-SHA256
    "c452331f24dd24cbbaac5f2462cdc3b628b6e95df1b53b5da600b8b3a62e4332"
    :COMPRESSED-BYTES 978 :COMPRESSED-SHA256
    "fb8e94673500974d92fb83b2e7ff473d13ec6e45eb30208bf7111991df82a1a6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6258 :STORED-BYTES 1165 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6258 :UNCOMPRESSED-SHA256
    "450bd68c688787693cd9de99d64cf474f7593b6bef331adcb89a5ec6f7117fb2"
    :COMPRESSED-BYTES 848 :COMPRESSED-SHA256
    "36e93727984300b2b2ee0a1b72aebd50911906cf24b6539521402c4f673f762c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/8-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16709 :STORED-BYTES 5301 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16709 :UNCOMPRESSED-SHA256
    "8dd556576a8e6138af8648a712d397c5dd912bc82a9eeb2ff789fd1b90d9ae69"
    :COMPRESSED-BYTES 4981 :COMPRESSED-SHA256
    "91db892e3e43a9355e5a45836dea1be6cd81559f377f2e6422b1a4fdfce2e3b6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/8-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16713 :STORED-BYTES 4895 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16713 :UNCOMPRESSED-SHA256
    "78f60457dad96383cc91c134710946ebb5651f0dda566545a83bf2ff848f65cf"
    :COMPRESSED-BYTES 4576 :COMPRESSED-SHA256
    "6315c56e46b85ddac931ddff3fe5020b696587534c2515f3b6ce176b3f7c199a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/8-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16688 :STORED-BYTES 5733 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16688 :UNCOMPRESSED-SHA256
    "4bb657ff59d7bf2b3ab270686bc982a6dc4965e21689f8d34a8feb4725748e79"
    :COMPRESSED-BYTES 5413 :COMPRESSED-SHA256
    "45d09487717bb348aa181d39e74b9274a0b7cd00a8dadbc767e06e78de021447"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/8-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16706 :STORED-BYTES 5485 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16706 :UNCOMPRESSED-SHA256
    "73fcbbd1244d5c63d170d51dc128a1388dea6df5dbe28a65349e9f185e2c6187"
    :COMPRESSED-BYTES 5166 :COMPRESSED-SHA256
    "96cfc5189721055c286626e9d72d72d4f066b359027759039700d57ec8631a1e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/8-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16691 :STORED-BYTES 6014 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16691 :UNCOMPRESSED-SHA256
    "985199ddee0636b7058c8169383c81bf5bb7d8d275c7777d18317498ec353d73"
    :COMPRESSED-BYTES 5694 :COMPRESSED-SHA256
    "0411eb025c5d481c1004410b92c93cad7d7b6ba9b82e42551e0d5c4251f0c690"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/8-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16690 :STORED-BYTES 5721 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16690 :UNCOMPRESSED-SHA256
    "fd914292d2d8ffe33036883ca489e123d9320f535b8cd1bc09548f49bb9e14ff"
    :COMPRESSED-BYTES 5402 :COMPRESSED-SHA256
    "e1f7090a223d7b7693ba1ab119db7bbf7f25aaf6b85fe55a320150388dbd10a8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/8-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16687 :STORED-BYTES 6107 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16687 :UNCOMPRESSED-SHA256
    "7278597810e1b32c7467056d07a2f2f3dcb000d4d6ec7ec0da0ce89a252f2037"
    :COMPRESSED-BYTES 5787 :COMPRESSED-SHA256
    "f5ebb10c99eaffdb277dfb5a3cdb665f604948b95c5ce1c935a2e65a7c5f7c68"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/8-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16703 :STORED-BYTES 5987 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16703 :UNCOMPRESSED-SHA256
    "75f183440d977e91d3a339ba94bb944c3beae5085ad8be42e04b11963ce9a5b1"
    :COMPRESSED-BYTES 5668 :COMPRESSED-SHA256
    "6cff55fb29ce8b35792bf920e651e8b85c14509786169af44a824e1c25fa19ec"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/8-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17389 :STORED-BYTES 7485 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 17389 :UNCOMPRESSED-SHA256
    "4545ed86870cbba00b3b059605ab00b7c58b61c3ade949a11625a0c2d4936759"
    :COMPRESSED-BYTES 7165 :COMPRESSED-SHA256
    "f3ba0d0109ff80f795471fc6ce0092a62d32c4aedd8481cfc5b6789f1afe1dcb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/8-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16733 :STORED-BYTES 6331 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16733 :UNCOMPRESSED-SHA256
    "92370e473fb8e44f12c1d83add66548655ac6341b0d7df9884200b8a57d4b3ae"
    :COMPRESSED-BYTES 6012 :COMPRESSED-SHA256
    "166221c8ac20935a1ab92f2145ef02e2379fd5487bce98dd15c5e502d3064e91"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/6-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12809 :STORED-BYTES 4298 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12809 :UNCOMPRESSED-SHA256
    "1a0664ba15be67c7bfb26daef944f88829093053a8226d888c4fae854e63c183"
    :COMPRESSED-BYTES 3978 :COMPRESSED-SHA256
    "1ff07c2db27a8f6bf980b55dc21381de0fecfff31f772526cd77a7858f0f3048"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/6-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12765 :STORED-BYTES 4678 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12765 :UNCOMPRESSED-SHA256
    "31b4ccb5fcb4915cd38c1e732cb302f49f645dd30c61d293de7487b3b80083c0"
    :COMPRESSED-BYTES 4359 :COMPRESSED-SHA256
    "f70fe28d0ea794d1504223840206801b67d3590be77ec73b41c00f68c1ccba2a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/6-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12917 :STORED-BYTES 4721 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12917 :UNCOMPRESSED-SHA256
    "17263fd629d195403dc24cd761bbbcbff6b1612fcc6703c861a33babccb60646"
    :COMPRESSED-BYTES 4401 :COMPRESSED-SHA256
    "dab87be2149dd24262e3ff2978d805fc65193ef1975bba71712a70f3f05f0d02"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/6-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12943 :STORED-BYTES 4959 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12943 :UNCOMPRESSED-SHA256
    "67f98474e14fd278e9200c872523788dd2a20a419dee3e7d35be36f446d51c58"
    :COMPRESSED-BYTES 4640 :COMPRESSED-SHA256
    "d45740cbfae479f2a4d0f70653cd1e77ab19ccfaa7bb1ae031d36976000d90c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/6-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13326 :STORED-BYTES 5259 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13326 :UNCOMPRESSED-SHA256
    "f18cace513b41ea49e806ed9f116a764ccfc377499648b5918c2be9513d6d910"
    :COMPRESSED-BYTES 4939 :COMPRESSED-SHA256
    "4c688a77449f118d33a33ffc971f5246ea7566727e9a6544a006a5aacd4e1f38"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/6-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12970 :STORED-BYTES 4030 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12970 :UNCOMPRESSED-SHA256
    "4c76422770569822e6088c54d3acc79ed45e3d3e172544001ce85667c9003655"
    :COMPRESSED-BYTES 3711 :COMPRESSED-SHA256
    "c750e1551352762ca9c6c89ef0923e28656b98ee38b1bdd610ce2a2210394247"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/6-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13148 :STORED-BYTES 4754 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13148 :UNCOMPRESSED-SHA256
    "d0474b36c727754359aa6c88b89d541f08ed3f780b708c1920680abeb1546cb3"
    :COMPRESSED-BYTES 4434 :COMPRESSED-SHA256
    "bc1366f9cb7c1fe47eafcbba06ae8871745fbef1c019c3ed673d12a46d11a981"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/6-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13463 :STORED-BYTES 5050 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 13463 :UNCOMPRESSED-SHA256
    "6ab41271aeea5633f743cb9365765a06cf8f08d533503d4d11bedc67244f85d8"
    :COMPRESSED-BYTES 4731 :COMPRESSED-SHA256
    "b1d934f0f6e1f16a8ddc3e90d009e00f137804c0b5e452b8416316ed5f47e60c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/6-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12806 :STORED-BYTES 4511 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12806 :UNCOMPRESSED-SHA256
    "2d0e71de6066d6e507f6ff61779206ee480bba51599763221224ecf286404c61"
    :COMPRESSED-BYTES 4191 :COMPRESSED-SHA256
    "7e95343050fa576dd2fc795b2e8a0e3073a67937a80ea4b4d1ee577a0e6a03fe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/6-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12801 :STORED-BYTES 4789 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12801 :UNCOMPRESSED-SHA256
    "3f64382eed72dc0373a04229d4ca01be405c519540177633f64c5e70d4b453ff"
    :COMPRESSED-BYTES 4470 :COMPRESSED-SHA256
    "9669899701f7cb55d614787af4ef0d68bca2b00084e7fb32e6642892b83c29e5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/4-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16688 :STORED-BYTES 5858 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16688 :UNCOMPRESSED-SHA256
    "b59ec1ea67a837b800c4907dec8f6f4df72c1cafd8f9b59fcc0d581007f86d5f"
    :COMPRESSED-BYTES 5538 :COMPRESSED-SHA256
    "6857bb1ff663cd41ba8138830091d166759553f1ba00bf77fcd055add537d425"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/4-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16712 :STORED-BYTES 5876 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16712 :UNCOMPRESSED-SHA256
    "dce335edcc6b2211592c7ba6acf0a508799c80bd069bf94b3ae2e2f7801bad38"
    :COMPRESSED-BYTES 5557 :COMPRESSED-SHA256
    "735081635a4f262a7a2d853f9eb3720432e4ed647790645fa555b5f4effcb640"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/4-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16704 :STORED-BYTES 6506 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16704 :UNCOMPRESSED-SHA256
    "463d321ad947b62c6f8117c0027085c4bee17a47127304090e8c5740757f1c97"
    :COMPRESSED-BYTES 6186 :COMPRESSED-SHA256
    "bc2f4b707a2e02095a6f2a6ef181bf573c0bba194336174b09e03b7902da4b78"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/4-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16703 :STORED-BYTES 6419 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16703 :UNCOMPRESSED-SHA256
    "cd0ddd1a628f889434dc2610922256c8c0e415620b0f28acccd8084d480baf22"
    :COMPRESSED-BYTES 6100 :COMPRESSED-SHA256
    "4d94196b1e28d84afc557d5ff9bba51d2e8212dec1b45a19fc6835eaa2bbe5e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/4-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16683 :STORED-BYTES 6504 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16683 :UNCOMPRESSED-SHA256
    "30e6619e333e399b70a9d55b0bd72aaa6e1a879a013c9fd7ec6b3e397a017602"
    :COMPRESSED-BYTES 6184 :COMPRESSED-SHA256
    "40483389ff3d73f4a875de8300dc3620b099b32c429d29734f8a9f33b93ee58b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/4-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16708 :STORED-BYTES 5731 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16708 :UNCOMPRESSED-SHA256
    "011c0859ba0fa70d79aa2ec1d46d415b338140a267d35fc04a8dfdf3f70d05d2"
    :COMPRESSED-BYTES 5412 :COMPRESSED-SHA256
    "8fef941127787c509265c88da14b3580d7e044bc2e4910d0cd02531fd0d30bff"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/4-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16705 :STORED-BYTES 5618 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16705 :UNCOMPRESSED-SHA256
    "1c5992b0df71c916974c92739a1d265204b3efea9da6d353acb1211dbb565f10"
    :COMPRESSED-BYTES 5298 :COMPRESSED-SHA256
    "8cdf4291c739f7e9bd3372414ded5e8de8cfaa61038fed62406557f01baca728"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/4-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16698 :STORED-BYTES 5642 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16698 :UNCOMPRESSED-SHA256
    "8b9f19e36da8f070350415ecc774ede8dbde5ce7c4552c97e0572bb7de46ec71"
    :COMPRESSED-BYTES 5323 :COMPRESSED-SHA256
    "9d038e5ef5e72397a215615a672b9043877808f3c909e9c75b399758a6778fb3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/4-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16705 :STORED-BYTES 5740 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16705 :UNCOMPRESSED-SHA256
    "b440be3847dfdb9c9c9e7aae296a41118236032aa38ad4d8d7fcbe6430a328d9"
    :COMPRESSED-BYTES 5420 :COMPRESSED-SHA256
    "def3fa09ce2950426de5a8bb9a082298b606bc7c76584cf41575a7f15f3981fb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/4-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16692 :STORED-BYTES 5933 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16692 :UNCOMPRESSED-SHA256
    "41ceaea704911c1ca00bb51be79f3cc13829317d80f6069f2d125758fecb2afa"
    :COMPRESSED-BYTES 5614 :COMPRESSED-SHA256
    "5dc0dcca7192fbc7f14d4b5030ed3765ed29823cfca6dd082022fe9aed4b1efa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/2-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12799 :STORED-BYTES 4763 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12799 :UNCOMPRESSED-SHA256
    "87f2dd19eddb5de944a8b9b6a00a7eb2b9ef2e7be5fb0d26d7c2f84f7766dffb"
    :COMPRESSED-BYTES 4443 :COMPRESSED-SHA256
    "e9b91f57bcf991cb0a46a3a5a1304f3bbf47451c65e1210fd311ef07f07371c7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/2-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12862 :STORED-BYTES 4927 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12862 :UNCOMPRESSED-SHA256
    "f1eb485592ef4531651c4ebb8ed111e30a1751bbeb62d009e1eb83c3d06f20a1"
    :COMPRESSED-BYTES 4608 :COMPRESSED-SHA256
    "204f28eacdc04788d06fa3dedefeafe239c4815ad112cefe658143ed4d9b1dfc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/2-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12783 :STORED-BYTES 4722 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12783 :UNCOMPRESSED-SHA256
    "0c6f1d34ec046f1570b53a2eb1191a582254fb7e875ba045cea5b4732b2c79cd"
    :COMPRESSED-BYTES 4402 :COMPRESSED-SHA256
    "69c89966516c0dabba2465319cb0c1266f4ca284b18da98d46eaa4c7ae9675c2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/2-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12820 :STORED-BYTES 4806 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12820 :UNCOMPRESSED-SHA256
    "d416a2691301eea2cc9fd25ccb047b849989a51b222bb28e3d0612335963febf"
    :COMPRESSED-BYTES 4487 :COMPRESSED-SHA256
    "7e2b182b4f6eee300f91783a9c0525e8339fe660518c513f0d4639f975aaa4c6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/2-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12799 :STORED-BYTES 4715 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12799 :UNCOMPRESSED-SHA256
    "63a0045c475ced6964696b254ebc160c0537c7558926e2c4344a05fda7c33791"
    :COMPRESSED-BYTES 4395 :COMPRESSED-SHA256
    "260389d0de2e24492915bb5861c5279f8338d0de874104e014d63f79c5aa3c49"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/2-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12813 :STORED-BYTES 4780 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12813 :UNCOMPRESSED-SHA256
    "d4f0c2131216189c5f9951eb4e8543ccc275d8f3aa62b52d24013f62759b93a4"
    :COMPRESSED-BYTES 4461 :COMPRESSED-SHA256
    "f8cb77c767919165dc46bd9d28267d50afb1a1fff7e152409e54e48f09ab40b4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/2-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12849 :STORED-BYTES 4839 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12849 :UNCOMPRESSED-SHA256
    "f69fa71e6c53c2312545ec67eebfa53af44de1c4a6a072b19b65e692a8d08b4c"
    :COMPRESSED-BYTES 4519 :COMPRESSED-SHA256
    "e9daefb723a83b61565596f9aa759444ec2b8c83256b5941be682dd631fda5b8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/2-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12933 :STORED-BYTES 4942 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12933 :UNCOMPRESSED-SHA256
    "f94f145561f72dc141ba9f2c845d60b971f98c78043fcbe95fc063567303551d"
    :COMPRESSED-BYTES 4623 :COMPRESSED-SHA256
    "d4f093934c13b6298d959e9b3743456410773f133c6ba4b159e4adfca2e03f1e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/2-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13178 :STORED-BYTES 5271 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13178 :UNCOMPRESSED-SHA256
    "d1f37993ee69e791e3c5a9fb5c0e5183c2e08d2ec48467323719cd6b9792daf4"
    :COMPRESSED-BYTES 4951 :COMPRESSED-SHA256
    "a5fd521b59123c49cfed9c10d3136d618b049d950af8e5e33b3ac80139d297d4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-only-spike/windows/2-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13045 :STORED-BYTES 4799 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 13045 :UNCOMPRESSED-SHA256
    "0b6164e2f1570ef1e9df56615f0fe06cc281361ad3ff5e2e0825272d6ed0a52a"
    :COMPRESSED-BYTES 4480 :COMPRESSED-SHA256
    "fdac91cac958ed8ed283e2f18bb7a14e0e71c1aa704222b19777d622c5222631"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6389 :STORED-BYTES 1291 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 6389 :UNCOMPRESSED-SHA256
    "622d10cc25acd48f06422b3519d4ad5033300fcb0e60e6326aacd79725590677"
    :COMPRESSED-BYTES 977 :COMPRESSED-SHA256
    "4bfe6da1e01532c935a7e8bad3f27573475d1aaa1253caaf023078360377dac1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6178 :STORED-BYTES 1165 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 6178 :UNCOMPRESSED-SHA256
    "27d5e7f9458679f2ce38a6cac4adad2626c6c97435f358f08637d0ecadfbb5ab"
    :COMPRESSED-BYTES 848 :COMPRESSED-SHA256
    "60cbcc41b88afd8e3787701de8d3f52efd69d598b1731643f2bf36ed918f1f85"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/8-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16685 :STORED-BYTES 5907 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16685 :UNCOMPRESSED-SHA256
    "a72a80b04a04bbe10c81019012caa5d09d5a0a4dcd16b07c8669d8aa4303a4ba"
    :COMPRESSED-BYTES 5587 :COMPRESSED-SHA256
    "0a2e3b0cfdda6a4c4956d57f6bd8db8a27d52046cd7e5cd41e099e7c1cdcf002"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/8-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16710 :STORED-BYTES 5108 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16710 :UNCOMPRESSED-SHA256
    "d13503cad9d995ac6b2b6443337896c000a17b9b3ebb2c8fff2b58206410819d"
    :COMPRESSED-BYTES 4789 :COMPRESSED-SHA256
    "e71135f370223e00019c1476fd059c342dc93b71589de7c097f273eed2841976"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/8-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16699 :STORED-BYTES 5768 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16699 :UNCOMPRESSED-SHA256
    "5db5d21529af53cd535d58dbf2c5a7f35e0f3383370367faa7c31c23dd6a52f3"
    :COMPRESSED-BYTES 5448 :COMPRESSED-SHA256
    "f93f4593b4176b07f20dc12c54ec7d249911e9ea40b7bd917d9e41394ca73de2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/8-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16703 :STORED-BYTES 5428 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16703 :UNCOMPRESSED-SHA256
    "73a7f9fee2ae41fcd153a30d8333e43fd563925bfd9564e21fdc233a6fe1ef11"
    :COMPRESSED-BYTES 5109 :COMPRESSED-SHA256
    "a3a40456a5fb8382b5158daec0a5504c98937e4553f9e5dbf70bef5f2c3b15a5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/8-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16676 :STORED-BYTES 6215 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16676 :UNCOMPRESSED-SHA256
    "c783636aa121a36ddc17355a35faef48d8df546d0e00fd35e945cd2af9ca5b2d"
    :COMPRESSED-BYTES 5895 :COMPRESSED-SHA256
    "2a0cf7db001f8fdf42c14f8fa64a4743100a36dd5f59ca8aab242de141965b41"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/8-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16713 :STORED-BYTES 5633 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16713 :UNCOMPRESSED-SHA256
    "b831edd6cc713dc7834821795c1832a656f670021bf13afdb584e993fc5190a1"
    :COMPRESSED-BYTES 5314 :COMPRESSED-SHA256
    "1a3f397eb340713a26da20a77371bde5d023f52dfcc511e323eab24a9802ae35"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/8-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16713 :STORED-BYTES 4903 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16713 :UNCOMPRESSED-SHA256
    "795f107755ff88f39df96b5c443f94b3ce1b69d8a0159a05bd44cd9d3ea80064"
    :COMPRESSED-BYTES 4583 :COMPRESSED-SHA256
    "feb54ffc35430a64480c3dcda3b267e622fb0b3af4a572421270cb5f1fb224fa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/8-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16714 :STORED-BYTES 4963 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16714 :UNCOMPRESSED-SHA256
    "2d08af26559bc96f0348ce27b7a3e1b6dacffe6a42937ece50ec6ba6178ada40"
    :COMPRESSED-BYTES 4644 :COMPRESSED-SHA256
    "0a71e9bfbbc38b8ab543617bb5163b1f836a14de1a7ab160d3ec2f836874200f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/8-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16707 :STORED-BYTES 5238 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16707 :UNCOMPRESSED-SHA256
    "d4bdd7fbb3b36865508c205d9dd64b07350a90881ac341d8ac58c716f049f6d1"
    :COMPRESSED-BYTES 4918 :COMPRESSED-SHA256
    "57beda56e9a939248f80b42d169a9e729f3e4f99d0db8ff0ad48ccec4bb18ee8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/8-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16694 :STORED-BYTES 5823 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16694 :UNCOMPRESSED-SHA256
    "7b29527d480303c1b0a2253db27fe1904af9d54ed36ea96c99e907e78045bd44"
    :COMPRESSED-BYTES 5504 :COMPRESSED-SHA256
    "07ac24fa403fb6ad6a90461078979a06b4d9483c358e403d025c1236f313fc33"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/6-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12802 :STORED-BYTES 4657 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12802 :UNCOMPRESSED-SHA256
    "6a7eaf93103f56da7837030cc31c2e081e4eeff1a36a0e25ef3e7801f4acee9e"
    :COMPRESSED-BYTES 4337 :COMPRESSED-SHA256
    "a05681d39cd90321a71d77367e47adbc8d75204d5aa15be9cba7f24eba0730b7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/6-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12754 :STORED-BYTES 4654 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12754 :UNCOMPRESSED-SHA256
    "da4c4e6d76549e725c01cc0982ce01da952e27d0e8e5f3398905034c83afa56d"
    :COMPRESSED-BYTES 4335 :COMPRESSED-SHA256
    "b9af9173565f0bc570783305d259d42861e2be8fc4c7846f6ea84d9e82e3a532"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/6-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12810 :STORED-BYTES 4744 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12810 :UNCOMPRESSED-SHA256
    "3e4e711f29c8262c1c1f7a2e1af8a01678a4e112957f1041f01217b73cc8701b"
    :COMPRESSED-BYTES 4424 :COMPRESSED-SHA256
    "63cbb15ec525080846952e1b5f69e40834fa4f062a34180fbef5d95853fe2b0f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/6-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12795 :STORED-BYTES 4782 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12795 :UNCOMPRESSED-SHA256
    "aeee8b9fdfc206b56f6c026e4806105fe4e478bf0ef068bc3d17654472108555"
    :COMPRESSED-BYTES 4463 :COMPRESSED-SHA256
    "576014dd90ea46f55d3c31fc1e1c82666618aa3621c65b4b2f319bb31200fdaa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/6-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12815 :STORED-BYTES 4761 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12815 :UNCOMPRESSED-SHA256
    "bfe7f173b63c508e27361325551d87cf5766936e8f5f47267e1cdffc242cfcb1"
    :COMPRESSED-BYTES 4441 :COMPRESSED-SHA256
    "68f18c33241dc325d73f96e35d991876d20b2dc91864507a27c208116da00d3a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/6-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12787 :STORED-BYTES 4797 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12787 :UNCOMPRESSED-SHA256
    "23b2b4b934dd016c134a425e714b06d852e4ae31cfb517252da6e7e5733d7065"
    :COMPRESSED-BYTES 4478 :COMPRESSED-SHA256
    "092a6cb861db23386fc4b43ec7152fc7c70207a0519b9861d98f1df63cc94102"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/6-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12862 :STORED-BYTES 4775 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12862 :UNCOMPRESSED-SHA256
    "d8dbc4518a4e35fcfd79c5cf56bba0aa6925e5184358644b1ebe204bdeeec1c8"
    :COMPRESSED-BYTES 4455 :COMPRESSED-SHA256
    "48e382ae18a2903796d0886b1ed489324164fb962add11838424cb9ca6eeb02f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/6-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12788 :STORED-BYTES 4746 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12788 :UNCOMPRESSED-SHA256
    "9d0ead8aaeb09a89a67799bd5753a110ae56c1f835a749058aa59508f428835c"
    :COMPRESSED-BYTES 4427 :COMPRESSED-SHA256
    "631145a2bd8509a805a7275d7cf17ddc5a13d8c73a32755b1a7aa5278aaab0a6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/6-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12754 :STORED-BYTES 4590 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 12754 :UNCOMPRESSED-SHA256
    "f921c6fede0b8695fdf882940aa1579e87d0d5df6927fe8a6ac8ab7f34f9ffea"
    :COMPRESSED-BYTES 4270 :COMPRESSED-SHA256
    "acf0c72b8c2a8be44416197d87ed86b7771a9849ac11ad0ba047ff3ff5de8fcc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/6-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12902 :STORED-BYTES 4944 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "6-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12902 :UNCOMPRESSED-SHA256
    "ca332f6027a092c64aec14b149c99c1be136eea5644f6004301a2e793c18f84d"
    :COMPRESSED-BYTES 4625 :COMPRESSED-SHA256
    "ad9aae755613527ce140b9ef594e6a317ba813b895c9d27dc2c81d27acf743e7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/4-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16709 :STORED-BYTES 5463 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16709 :UNCOMPRESSED-SHA256
    "15432686defaf111012adae6b972e6bbb5888e087decb291f00d503f9c832724"
    :COMPRESSED-BYTES 5143 :COMPRESSED-SHA256
    "41c81944f3348b4ca8ebabcba4a34f7de62f8f779e24b3ab292b1045cdef2d6d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/4-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16699 :STORED-BYTES 5523 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16699 :UNCOMPRESSED-SHA256
    "d39463d60f1f08b45a7be75b3ebd15187c5c0bf11ff507cbba77b80063af0a77"
    :COMPRESSED-BYTES 5204 :COMPRESSED-SHA256
    "0d049f856f3a8cc0bc45855548d15d594ba0adf0baabd409d3214ed6924da7d7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/4-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16717 :STORED-BYTES 5555 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16717 :UNCOMPRESSED-SHA256
    "81037a1478a0d333c9c7c7d2404138f0961cab00acaf71464623002577810c1a"
    :COMPRESSED-BYTES 5235 :COMPRESSED-SHA256
    "0bd498be5aa61bc836771249a3433c134e60bbbe657c792698f1dfbcb5c7dd8e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/4-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16706 :STORED-BYTES 5165 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16706 :UNCOMPRESSED-SHA256
    "741e7c133724c4bfa89b296b48203262f4493cc19983faa0236074aff26b8ae4"
    :COMPRESSED-BYTES 4846 :COMPRESSED-SHA256
    "13324584a66ebeb02e671e3db46f54310547a3f8a676b00802dd39676089b244"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/4-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16715 :STORED-BYTES 5152 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16715 :UNCOMPRESSED-SHA256
    "d64476c6ba8d9c4f01771ec2a68322d0becf810464992a8e47e71fc9c0d5bc09"
    :COMPRESSED-BYTES 4832 :COMPRESSED-SHA256
    "71f4f7756864366bb4b8a046d412929e4458ac9415dd9b81c2933a3d62d6b09f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/4-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16700 :STORED-BYTES 5476 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16700 :UNCOMPRESSED-SHA256
    "9ef4a01a92ae5febef57b253e2136ca351df8efeaacacd1ce9cff9163ace35ac"
    :COMPRESSED-BYTES 5157 :COMPRESSED-SHA256
    "19ac3e9b5ac2f686b0a14d3ebfc5b24fc528955a98d331e189888f116e6d9cc6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/4-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16710 :STORED-BYTES 5516 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16710 :UNCOMPRESSED-SHA256
    "ae58d5c99fd8d842689867a4b030d7f0d2338284ddc8ba6e797c7430f8bf06bb"
    :COMPRESSED-BYTES 5196 :COMPRESSED-SHA256
    "84bc70416e58d27f78d3bab2bb87c5ac3c198781e7863d863fb109767b27fcdf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/4-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16704 :STORED-BYTES 5773 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16704 :UNCOMPRESSED-SHA256
    "19dd39cefed5d61c1aa418c603b9898ad8f2cbb1816bc2bca86ad417c6ffea17"
    :COMPRESSED-BYTES 5454 :COMPRESSED-SHA256
    "bc59b5f1c55ff5d794d89ba4f96642b127aa8bbc7abbbcc9bb8427f5ea429c1b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/4-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16705 :STORED-BYTES 5624 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 16705 :UNCOMPRESSED-SHA256
    "d49c510b33b530b433cc4c8938828b4f80ef0f3f80b2448493a0e805437da794"
    :COMPRESSED-BYTES 5304 :COMPRESSED-SHA256
    "794aab9fc56c9f5da5b6d813b547366ec4f66715d2fe45935838fe6ce3196d3a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/4-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 16704 :STORED-BYTES 5529 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 16704 :UNCOMPRESSED-SHA256
    "ca36ff60485dfd924e240f6c6bcbc2b1f04e5e8d166fc1471f71f0f92732ecdd"
    :COMPRESSED-BYTES 5210 :COMPRESSED-SHA256
    "21539e36cffcda8d0e0fa1384bd0e1ed05daeaac739acd6062e464e6093f2643"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/2-4-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13006 :STORED-BYTES 4531 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13006 :UNCOMPRESSED-SHA256
    "3335d7bcf3981632c553e1b68ba2367dc485ca9f07319f44f09c9dbff833d629"
    :COMPRESSED-BYTES 4211 :COMPRESSED-SHA256
    "ee157164adc78d48bd16e41eb0d3b5e7cf16d49429634219e71c5d2c8d80abb6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/2-4-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13321 :STORED-BYTES 4589 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 13321 :UNCOMPRESSED-SHA256
    "53f3c712b1618af667a49ab2d78a52de6df7810ebebba07598c6675437f1f250"
    :COMPRESSED-BYTES 4270 :COMPRESSED-SHA256
    "6b10cb76597225cd2179119e2212014dfc298a9ff129608b186ef2e77e8b350c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/2-3-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13057 :STORED-BYTES 4199 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13057 :UNCOMPRESSED-SHA256
    "0456aa654ee7899d9916aa076b5f59382464d55bf7d738a2fb84411a89173b34"
    :COMPRESSED-BYTES 3879 :COMPRESSED-SHA256
    "9f5d558f706e3cd23430f46dc07f9b413be2ae519d153dbdcbb27274ba6bcca9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/2-3-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12949 :STORED-BYTES 4273 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12949 :UNCOMPRESSED-SHA256
    "ec6d77c6d5f552ef99d8a6fa708ce2dadb2a4d5ae221e60613b7c666ec3972d9"
    :COMPRESSED-BYTES 3954 :COMPRESSED-SHA256
    "e47ff8542dd3db09876b75c923ca366841720b3a9255b05b43eaf70a5196e9ac"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/2-2-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13025 :STORED-BYTES 4691 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13025 :UNCOMPRESSED-SHA256
    "1d31f26941c6d97064355a15a992c235bec1c393f6a869a56a9920c7445a3b04"
    :COMPRESSED-BYTES 4371 :COMPRESSED-SHA256
    "f10b4942921df057ad96ac78b95ecb217c6c65dd157d1a8cac6a3df1fb1f0b65"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/2-2-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12975 :STORED-BYTES 4606 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12975 :UNCOMPRESSED-SHA256
    "b43a5aae6c01e405f86c36e8e8b8b06f9fd31bcb51ae7acc8d49487ad550acd4"
    :COMPRESSED-BYTES 4287 :COMPRESSED-SHA256
    "cff97c74ff7c7a7605d78201aeff2576ed58051c65877a1be964964540eb8673"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/2-1-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13291 :STORED-BYTES 4711 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13291 :UNCOMPRESSED-SHA256
    "a67bce0c767b371483ec7c81a122732058e92e6920173e38f2bbfce7f2cdc50b"
    :COMPRESSED-BYTES 4391 :COMPRESSED-SHA256
    "d009fdfbab1b93f26cc2c2128ec5278315f9291580218a45f3d6086429ccf195"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/2-1-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13006 :STORED-BYTES 4497 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 13006 :UNCOMPRESSED-SHA256
    "9585bb5fd84694f68295209b29a1f30b31f4501ec79aea771897353b37f42a29"
    :COMPRESSED-BYTES 4178 :COMPRESSED-SHA256
    "ff5e0b9086f0c2ab01e6a5461f9da3d32f4eb031754b75965febddb891843da6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/2-0-CANDIDATE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13108 :STORED-BYTES 5015 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-CANDIDATE.lisp.gz" :UNCOMPRESSED-BYTES 13108 :UNCOMPRESSED-SHA256
    "52c38052239fe174cb61822b070ae253da7500089dcc80921a94681ec03dccae"
    :COMPRESSED-BYTES 4695 :COMPRESSED-SHA256
    "d9bb062040ea8097fb7b96dd83694b0dc3945b9be18838cc8f7bbb5eeb021a28"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/ready-spike/windows/2-0-BASELINE.lisp"
   :STATUS :OK :ORIGINAL-BYTES 12762 :STORED-BYTES 4705 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0-BASELINE.lisp.gz" :UNCOMPRESSED-BYTES 12762 :UNCOMPRESSED-SHA256
    "653b59274026b162cc364404912edb27b215f96faae73b1bd5a1691e21621aa6"
    :COMPRESSED-BYTES 4386 :COMPRESSED-SHA256
    "c50329d7626b9c08e7a4d4eef2eefea862497a24c67050593e3c0c507c16a529"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-11.lisp"
   :STATUS :OK :ORIGINAL-BYTES 74130 :STORED-BYTES 8358 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-11.lisp.gz" :UNCOMPRESSED-BYTES 74130 :UNCOMPRESSED-SHA256
    "99fc53c7b4723be99c0667bfa74708222958afa443f4f354f624a0a86cb7939a"
    :COMPRESSED-BYTES 8045 :COMPRESSED-SHA256
    "247715c66ccc7e4a46d068d34fe769b876db58f2f7eb929a0d0f13bea1c78694"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-10.lisp"
   :STATUS :OK :ORIGINAL-BYTES 22969 :STORED-BYTES 4607 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-10.lisp.gz" :UNCOMPRESSED-BYTES 22969 :UNCOMPRESSED-SHA256
    "29843bf183cfde97c72091fe9a53dacf47aceaca1690d179d6c4da3c7babcaa3"
    :COMPRESSED-BYTES 4294 :COMPRESSED-SHA256
    "2fb78aea87dca6799850e7d24f141ac5555a3dbb56d4fe304d26f5985b99f2c6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-08.lisp"
   :STATUS :OK :ORIGINAL-BYTES 331090 :STORED-BYTES 45766 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-08.lisp.gz" :UNCOMPRESSED-BYTES 331090 :UNCOMPRESSED-SHA256
    "0d83dbbab977a16e5f4c821e15865314f5a3ef733fd7b99763493b591bda4861"
    :COMPRESSED-BYTES 45451 :COMPRESSED-SHA256
    "ce47bc5da18049277509496f75903129b81229f22c255ab89f81d8666a84e1d0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-06.lisp"
   :STATUS :OK :ORIGINAL-BYTES 23971 :STORED-BYTES 4365 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-06.lisp.gz" :UNCOMPRESSED-BYTES 23971 :UNCOMPRESSED-SHA256
    "c108a97a7e010b2ad5b078abcbab45758fbdf83b8e7e9143a61bc2e6c0184835"
    :COMPRESSED-BYTES 4052 :COMPRESSED-SHA256
    "df6dcf36811d0032349b67e20d28769263ccd99184080ae3b22af0d4d809bd39"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-05.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10055 :STORED-BYTES 2241 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-05.lisp.gz" :UNCOMPRESSED-BYTES 10055 :UNCOMPRESSED-SHA256
    "843111ef3b36decb1027204d85c8ceaf31b76bc60ce75f997447ba5560fc94b8"
    :COMPRESSED-BYTES 1928 :COMPRESSED-SHA256
    "52bbf1bab03bb282b590f238a4168fdf6ca92aeaa3a0756a678e117f4c8a061f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-04.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6752 :STORED-BYTES 1923 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-04.lisp.gz" :UNCOMPRESSED-BYTES 6752 :UNCOMPRESSED-SHA256
    "8b2b55fa2d0874b2fd486aa84008ecb7df156a883d8f3b2bf4fdcaab474a148d"
    :COMPRESSED-BYTES 1611 :COMPRESSED-SHA256
    "341b88cb4bffa35250548f983315b0ad87a23cd334f998a89f978dc847aa7550"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-01.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27228 :STORED-BYTES 3190 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-01.lisp.gz" :UNCOMPRESSED-BYTES 27228 :UNCOMPRESSED-SHA256
    "27dfd8ee7d3fcdeb41a29cd9366c7cb4e0f48d111e0654eac191ca50e12a6380"
    :COMPRESSED-BYTES 2877 :COMPRESSED-SHA256
    "bc089596fb75e478ff5affa0ffd1eaad1bd3266f878ea8a8322d77baff414acd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/ci/selftest-1793564983-72499/workflow.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27784 :STORED-BYTES 3698 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "workflow.lisp.gz" :UNCOMPRESSED-BYTES 27784 :UNCOMPRESSED-SHA256
    "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"
    :COMPRESSED-BYTES 3383 :COMPRESSED-SHA256
    "65ef5865e2a8bcb699e2b198c990c96183d7e9da6772156178630f8e76782735"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/command-archive-collector-self-test-3lm4jo/self-test-report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28790 :STORED-BYTES 3536 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "self-test-report.lisp.gz" :UNCOMPRESSED-BYTES 28790 :UNCOMPRESSED-SHA256
    "3a7136c226be707b03ad08cbe60827d9e36bd5095017ed3d21ee694227b52b76"
    :COMPRESSED-BYTES 3213 :COMPRESSED-SHA256
    "56d8e2173f2b19ada54a8fd2bcb65a789ef35ec2f948a6e312b824560c588857")))
 :DRIVER-SHA256
 "14cd39115d0a6309980ae9eef97f8d4074c56d256699fdce2832032531bbbcde" :LIMITS
 (:OWN-RESULT-ROOT-ONLY :RAW-BYTE-HASHES :VERIFIED-LOSSLESS-EXPANSION
  :SPECIAL-IPC-NODE-METADATA-ONLY :NO-NEGATIVE-FIXTURE-QUALIFICATION))
