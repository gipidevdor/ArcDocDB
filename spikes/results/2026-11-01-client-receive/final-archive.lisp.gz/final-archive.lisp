(:KIND :RECEIVE-COMMAND-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "4002553784-command-72500-0" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-analysis-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-archive-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-baseline" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-baseline-analysis" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-candidate" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-candidate-analysis" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-checks" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-checks-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-cleanup-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-close-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-compaction-cost" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-counts-after" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-counts-before" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-counts-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-documentation" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-final-candidate" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-final-candidate-repeat" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "receive-final-candidate-repeat-analysis" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-focused-01" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-focused-02" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-focused-03" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-focused-04" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-focused-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-focused-optimized" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-identity-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-maximum-allocation" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-optimized-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-optimized-final-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "receive-optimized-repeat" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-optimized-repeat-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "receive-paired-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-paired-final-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "receive-paired-repeat" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-paired-repeat-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "receive-paired-smoke" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-paired-smoke-02" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-paired-smoke-03" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-paired-smoke-final-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "receive-qualification-2.6.10" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "receive-qualification-2.6.9" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-ready-only-spike" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-ready-only-spike-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "receive-ready-spike" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-ready-spike-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE))
 :FAILED-FIXTURE-ROOTS NIL :SPECIAL-NODES NIL :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793564983-72499/workflow.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/ci/selftest-1793564983-72499/workflow.lisp"
   :SHA256 "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"
   :BYTES 27784)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793564983-72499/tests.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/ci/selftest-1793564983-72499/tests.lisp"
   :SHA256 "72d8ca8f69a6df2de0109bffa94908d4d6e32d4b899bad224a91d9e25814a51c"
   :BYTES 2463)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793564983-72499/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/ci/selftest-1793564983-72499/report.lisp"
   :SHA256 "1ae97ae4103f11530749a8627e2ba2cc908579dc933ba091a1eafd94a48a5125"
   :BYTES 632)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793564983-72499/publication.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/ci/selftest-1793564983-72499/publication.lisp"
   :SHA256 "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc"
   :BYTES 1181)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793564983-72499/measure.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/ci/selftest-1793564983-72499/measure.lisp"
   :SHA256 "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c"
   :BYTES 2041)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793564983-72499/data.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/ci/selftest-1793564983-72499/data.lisp"
   :SHA256 "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2"
   :BYTES 3214)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793564983-72499/conditions.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/ci/selftest-1793564983-72499/conditions.lisp"
   :SHA256 "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f"
   :BYTES 663)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793564983-72499/boundaries.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/ci/selftest-1793564983-72499/boundaries.lisp"
   :SHA256 "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23"
   :BYTES 976)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/command-archive-collector-self-test-3lm4jo/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/command-archive-collector-self-test-3lm4jo/self-test-report.lisp"
   :SHA256 "3a7136c226be707b03ad08cbe60827d9e36bd5095017ed3d21ee694227b52b76"
   :BYTES 28790)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553467-command-59873-0/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553467-command-59873-0/self-test-report.lisp"
   :SHA256 "7e47f646dc8ee821fcd8e3536a898b414e928bb78b4cbfd416d95f7b431a963b"
   :BYTES 157)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553303-command-52387-0/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553303-command-52387-0/self-test-report.lisp"
   :SHA256 "7e47f646dc8ee821fcd8e3536a898b414e928bb78b4cbfd416d95f7b431a963b"
   :BYTES 157)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553784-command-72500-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/4002553784-command-72500-0/conservazione.lisp"
   :SHA256 "436689e1e0de697c42be377764dbc1ce4323279ca7e762d39bee366512dd693f"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553784-command-72500-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/4002553784-command-72500-0/report.lisp"
   :SHA256 "be3b1fe1670074e61113a5c24113a2304ab2096e4f5497fca83b29a67ee27d9a"
   :BYTES 363477)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-analysis-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-analysis-self-test/conservazione.lisp"
   :SHA256 "68768bd7dc7b8caa65b970258bbae34c27adbd3e3fa6dae0cc73c1329e031e74"
   :BYTES 1183)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-analysis-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-analysis-self-test/report.lisp"
   :SHA256 "c626a16ef3ae6ce075cdb945c73645815f1d974a4d0e38fcc0b9c6810296bfd2"
   :BYTES 362815)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-archive-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-archive-self-test/conservazione.lisp"
   :SHA256 "fd62719a0c42f6e1b0c128241518a21f94f6317bb65dd922b0d340f7815b25d7"
   :BYTES 1182)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-archive-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-archive-self-test/report.lisp"
   :SHA256 "4f85ed25ead29373783e4825ac66fea51841b9979cdf86aeaee4a01cc9d46a5a"
   :BYTES 362826)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-baseline-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-baseline-analysis/conservazione.lisp"
   :SHA256 "0c1cb1c812594e7cd3f54a0f8fd05fc5925d3359ac7fff72a49c53780be5b3d9"
   :BYTES 1182)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-baseline-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-baseline-analysis/report.lisp"
   :SHA256 "d49cd71ba633646643097145f86d53b28dc211d8b96b73f859daae9ff4abd75f"
   :BYTES 363267)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-baseline/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-baseline/conservazione.lisp"
   :SHA256 "64732015d0a31a07bc5830d03f65f0c3e5b1d63db53e4b7f7732ecac87ec60e9"
   :BYTES 1164)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-baseline/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-baseline/report.lisp"
   :SHA256 "9a1018c6d69e06a7124a59377f39aa54c917bad76b6083f61835fbc752eb5020"
   :BYTES 372069)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-candidate-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-candidate-analysis/conservazione.lisp"
   :SHA256 "bb22c1d7bb34fcb6f4ff26890363f5fbef7791ffb997fb1597069761e380a908"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-candidate-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-candidate-analysis/report.lisp"
   :SHA256 "900964feb2d92c579c9a7a12969e2b4b2c939ae3b054bb255f299f5ddcebfea2"
   :BYTES 363407)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-candidate/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-candidate/conservazione.lisp"
   :SHA256 "ffca41e4bfd60b82f3eaf162d35dc70b25015856679bd87a21f8b717b844ed70"
   :BYTES 1165)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-candidate/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-candidate/report.lisp"
   :SHA256 "3ba407ea42c022d9e32ed8008ba9919ab8c5e62030b37c39d5e375666e132831"
   :BYTES 372377)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-checks-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-checks-final/conservazione.lisp"
   :SHA256 "961cd27f5a5d07235a512b2e3c4d1349219a5a1960b003197126c7cb68c60dfa"
   :BYTES 1172)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-checks-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-checks-final/report.lisp"
   :SHA256 "4355dce342f1bcd882a96b123720e791a1d44e90efdf452d0887adeb35e1d67d"
   :BYTES 435703)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-checks/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-checks/conservazione.lisp"
   :SHA256 "996b0ef9ddb309b65c4f7d0b6acc1cb8597775f708dd0659cda5975ae3fd4f9f"
   :BYTES 1160)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-checks/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-checks/report.lisp"
   :SHA256 "673270641db82137fad0a64878341095a8555f20f2b029a9224f837f8aef008c"
   :BYTES 394559)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-cleanup-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-cleanup-self-test/conservazione.lisp"
   :SHA256 "904baa5035e62e122f7ff9105556be605684afb6377c7351b04fe4f865230156"
   :BYTES 1182)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-cleanup-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-cleanup-self-test/report.lisp"
   :SHA256 "407548888a532ba013645728c67e92cd687f91dc94874bcb0ccc1b082564a820"
   :BYTES 362861)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-close-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-close-self-test/conservazione.lisp"
   :SHA256 "a638b9790247e691bb1a963b0654cee98a80625ba74116c0c536fa6fb08a64e1"
   :BYTES 1178)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-close-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-close-self-test/report.lisp"
   :SHA256 "cf9795c5debb83905dc949e4929d5e076ac7b7145bb6e4b5f3f8f10a69dde2fe"
   :BYTES 362812)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-compaction-cost/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-compaction-cost/conservazione.lisp"
   :SHA256 "73f08ff271446047cf1f4f1ca9660081604b3aad11e3db36f63791f59a2c1145"
   :BYTES 1178)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-compaction-cost/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-compaction-cost/report.lisp"
   :SHA256 "532954b35ded26d9e902b79a1abd56180fc6dd7a397c0eba586082a8d078c024"
   :BYTES 363044)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-counts-after/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-counts-after/conservazione.lisp"
   :SHA256 "d00f157ded89f5388f3ffda981c299ca1f2e01b62def833afb97baee5743fc51"
   :BYTES 1171)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-counts-after/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-counts-after/report.lisp"
   :SHA256 "cdeaba2ef5ca9b858be0b91d9f5548ff51eb22a34919ab7a1da3246918618f79"
   :BYTES 368375)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-counts-before/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-counts-before/conservazione.lisp"
   :SHA256 "e853ee3fba96b8ff92040268a3b3997f738825d4d2e99ed0187134eda8bd8339"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-counts-before/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-counts-before/report.lisp"
   :SHA256 "bba2c268d8691803b69ffe293469e8e51e7349aacec81fef9f0c9fa805751ca7"
   :BYTES 368044)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-counts-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-counts-final/conservazione.lisp"
   :SHA256 "b243cabff4aa7c2cd1838d38b4ba75dc315362ff574bfafa99808fa13026b5c4"
   :BYTES 1172)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-counts-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-counts-final/report.lisp"
   :SHA256 "a0477fe2e60e770ee84f234cb9ccc72806c8df10021a00be400f60618ef0b649"
   :BYTES 368382)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-documentation/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-documentation/conservazione.lisp"
   :SHA256 "1eefaa20b1fd8b441487e5d350e2bdf9c311e3f79e606e9ccc3048f79d970524"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-documentation/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-documentation/report.lisp"
   :SHA256 "1626e89791f027bb8e89ad6b1c48e7da7ae496f0421bc63441a8f4d9af85b4eb"
   :BYTES 368933)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-final-candidate-repeat-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-candidate-repeat-analysis/conservazione.lisp"
   :SHA256 "888c128484866d83f52e8d980f6adf5c8afcdf889660c327d27f02b49c81f06e"
   :BYTES 1210)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-final-candidate-repeat-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-candidate-repeat-analysis/report.lisp"
   :SHA256 "ee90f44b6683ac0f5feac3cc5b5758b5273872dbbb364d52f95dd8757a570a3e"
   :BYTES 363421)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-final-candidate-repeat/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-candidate-repeat/conservazione.lisp"
   :SHA256 "3b4ef3ccf85f09fc15a99834f81564d72c71aa57f86b6e083e66e4aac81a80b5"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-final-candidate-repeat/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-candidate-repeat/report.lisp"
   :SHA256 "6aa17c80ec67bcf1251a23aaea8bd1dd7d16423ef4c785252dbb0ee7867db6c3"
   :BYTES 372408)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-final-candidate/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-candidate/conservazione.lisp"
   :SHA256 "52cdea7c629957e140d596929d471a908e5b4181e89426fffc721b2c60f889b0"
   :BYTES 1178)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-final-candidate/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-candidate/report.lisp"
   :SHA256 "2f6f066acd31b8888ee9c0048db1f40f464aafa1719d74e91ccbc13eff0a4e68"
   :BYTES 372401)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-focused-01/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-01/conservazione.lisp"
   :SHA256 "3bf49916120d03156f9ffd399496e35d80bce32f448cb828d35910c5c1e916bd"
   :BYTES 1168)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-focused-01/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-01/report.lisp"
   :SHA256 "aa73cec8a4864de2bf9aeaf5287f33d4e535b873fe6e429ee2760d1d17b9e67e"
   :BYTES 370492)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-focused-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-02/conservazione.lisp"
   :SHA256 "3227ed7ad269d39cd64322c8d55eac5f211488958041d2339f429dd571434060"
   :BYTES 1168)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-focused-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-02/report.lisp"
   :SHA256 "fe3c44bf72d9eef17481bcfa2836b97e7acce8ae6df85b26ff310dbd227167a2"
   :BYTES 370451)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-focused-03/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-03/conservazione.lisp"
   :SHA256 "1b6f5a32b786b5733a7a054e687f8014f4933e41d0679797a3289c379420194e"
   :BYTES 1168)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-focused-03/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-03/report.lisp"
   :SHA256 "c587620d870276d2612c4680766034f94d7602afd896989374b1860885d292d9"
   :BYTES 370428)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-focused-04/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-04/conservazione.lisp"
   :SHA256 "e59b7633ca4637ccd54600b641c9b97a736f2b499776b11353ac153e05df7459"
   :BYTES 1166)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-focused-04/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-04/report.lisp"
   :SHA256 "1bed130243e2d1f93ce3e12bc2209b97cdf33d0b3eccae1e233d229362c76405"
   :BYTES 362702)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-focused-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-final/conservazione.lisp"
   :SHA256 "1e0b87c64e79d59f5c7c9dc61b9a31c30a121a8da486a1a6d2d2102e9bd8895f"
   :BYTES 1173)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-focused-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-final/report.lisp"
   :SHA256 "b36dbd2885323721ecb31e7f2cfda2b6647782db372dd5dc909a41681982e7bf"
   :BYTES 362768)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-focused-optimized/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-optimized/conservazione.lisp"
   :SHA256 "b16b42e9edd0cc990174ee2d81c652ae852af3ad0add95732d08aefc5c020138"
   :BYTES 1182)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-focused-optimized/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-focused-optimized/report.lisp"
   :SHA256 "ab16b56e7410004e046b903dedab3d0280ab554e99397efcf3e86a0cc6b3ff5c"
   :BYTES 362770)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-identity-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-identity-self-test/conservazione.lisp"
   :SHA256 "a612ad9408819f933cb20db551b9e84bb542e32d391f8ffbf67254421bf1aadb"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-identity-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-identity-self-test/report.lisp"
   :SHA256 "ee0a276b0983051e9f67c1bca2db591f200d615f6c820e2ad6a27dc38c278e74"
   :BYTES 362838)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-maximum-allocation/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-maximum-allocation/conservazione.lisp"
   :SHA256 "7f74f9ef5928910c1874659e99e9bff08a6a74c8856f95fc249d6b70668dea32"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-maximum-allocation/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-maximum-allocation/report.lisp"
   :SHA256 "3a4d2b61459f74059ca85681bcae205fc97d49a9fdfdbbf3f558eea8037180cb"
   :BYTES 362869)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-optimized-final-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-optimized-final-analysis/conservazione.lisp"
   :SHA256 "667275cf047be7e713096924b481478051090bb05f1b86bd2467dd82ed854c6e"
   :BYTES 1196)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-optimized-final-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-optimized-final-analysis/report.lisp"
   :SHA256 "ca4021a043f57515a4f3eae5a224fd4da60eefe7bfc88c91aea5c64756d62728"
   :BYTES 363473)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-optimized-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-optimized-final/conservazione.lisp"
   :SHA256 "4ca274483d4a6be71e725e9f186cb0c9183e2aa01dbeac0fe877f79c250dc802"
   :BYTES 1178)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-optimized-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-optimized-final/report.lisp"
   :SHA256 "9261155a24e253d3914bbcc7cd06e2179e176668f811f69c3e264505d1ff5281"
   :BYTES 372344)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-optimized-repeat-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-optimized-repeat-analysis/conservazione.lisp"
   :SHA256 "d176510ce0739f8c212dc4ea6f1d065600018ad973c846fcf5fe634b9c58bfb0"
   :BYTES 1198)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-optimized-repeat-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-optimized-repeat-analysis/report.lisp"
   :SHA256 "20cf96db983fc6d2cdb49cbbe7f85ed5b9a3ae9bcb76c3804c7572d8f6c12341"
   :BYTES 363476)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-optimized-repeat/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-optimized-repeat/conservazione.lisp"
   :SHA256 "18b8c9e319ac6471e18b7310c785d6c23ea420fe447b58a37498b8a357336cb4"
   :BYTES 1180)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-optimized-repeat/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-optimized-repeat/report.lisp"
   :SHA256 "b6cfb96da6127ac783bfc3e523822e31ebf224a76386402adf4adbe530ea1c45"
   :BYTES 372344)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-final-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-final-analysis/conservazione.lisp"
   :SHA256 "16b23b2abbee5d4d833b95b1405b85aad94b4e707c3fe2f22df625d0f8846c4f"
   :BYTES 1190)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-final-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-final-analysis/report.lisp"
   :SHA256 "7376c4491019fd1009713582c9ef9f72ddb6bbb3614c9a045fd425792bebb03c"
   :BYTES 363470)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-final/conservazione.lisp"
   :SHA256 "f73b5bcf485bb04cd92d0fcb945b549417362402e69871d9552b876a78413ab6"
   :BYTES 1172)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-final/report.lisp"
   :SHA256 "24191aae0d5a929d1307f74d580aa14317cacf439851bda0551be669bbda91c1"
   :BYTES 372340)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-repeat-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-repeat-analysis/conservazione.lisp"
   :SHA256 "bd2d8281a0804042b64348b746fb07ade84270190a6930b22d7a7ba055dd89bc"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-repeat-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-repeat-analysis/report.lisp"
   :SHA256 "544856b255ec3930e23a907b72e388a9fe5f64b3e9b75a67b9608b8b54fab004"
   :BYTES 363471)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-repeat/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-repeat/conservazione.lisp"
   :SHA256 "3980c2dfcf59df93b0b6bcd55dc9136efc57dc40cf5b778c8d51c1c670f3faaa"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-repeat/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-repeat/report.lisp"
   :SHA256 "bd91ae834f268ea7c1482239448525051a14ea159bd78d7d333e22cbd8965b0f"
   :BYTES 372342)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-smoke-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-smoke-02/conservazione.lisp"
   :SHA256 "fbca73ad55044b19331ce9aebdd0d07faadc6363e9ed31a8e8cea6756b67c39d"
   :BYTES 1178)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-smoke-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-smoke-02/report.lisp"
   :SHA256 "f0a17d6b18a61fb080c334f06f00dde142e4896155717619e10ccbc358a8a879"
   :BYTES 365438)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-smoke-03/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-smoke-03/conservazione.lisp"
   :SHA256 "21e5bf46769d679eb70a76dd380c99c0e75da74f6cf5708ce2f548f1699658ce"
   :BYTES 1178)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-smoke-03/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-smoke-03/report.lisp"
   :SHA256 "7ae61f0905644ddd9b586bedc96339113e566615c3e15914ddc00d541e088318"
   :BYTES 365445)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-smoke-final-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-smoke-final-analysis/conservazione.lisp"
   :SHA256 "d4613f3620c00a993d063e57f46b00bfd578b4b2da619450de7b130bac91c2fd"
   :BYTES 1202)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-smoke-final-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-smoke-final-analysis/report.lisp"
   :SHA256 "ccecbaea70acbf7fdf96e2605771b4fe4ff6f3c167f09205916fa9d4f1c4617c"
   :BYTES 363001)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-smoke/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-smoke/conservazione.lisp"
   :SHA256 "ccb061434d4c85c7fb7ef9d24e04561beb37f5ce8767d1b97db0abbfdc999713"
   :BYTES 1171)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-paired-smoke/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-paired-smoke/report.lisp"
   :SHA256 "49a8372eff228afcfd71636ce791a9698fcd5577d06e0ae82a4a470929f63234"
   :BYTES 366225)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-qualification-2.6.10/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-qualification-2.6.10/conservazione.lisp"
   :SHA256 "6afb0a35732e992b800e205f159bc0a6e6ba11e5b53ddfac4afc87cdd7be95bd"
   :BYTES 1188)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-qualification-2.6.10/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-qualification-2.6.10/report.lisp"
   :SHA256 "4d50d57be1f1891074d828e38531687afe04f93de9d17f04821bdf1a53fd76fd"
   :BYTES 600391)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-qualification-2.6.9/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-qualification-2.6.9/conservazione.lisp"
   :SHA256 "8299bfdb2a5b3def33b0d41e6758c3f8fa3cd5d9f7dbeead99a0f8b06e1f73f2"
   :BYTES 1186)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-qualification-2.6.9/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-qualification-2.6.9/report.lisp"
   :SHA256 "282a66884eaf1815425532071788765cb73d9f5d192fe64a097d952b4f0ed904"
   :BYTES 600362)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-ready-only-spike-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-ready-only-spike-analysis/conservazione.lisp"
   :SHA256 "5178a5e45bc41b5939b74deb89d29fdae361de4895d0f32f8e49b3307aca384c"
   :BYTES 1198)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-ready-only-spike-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-ready-only-spike-analysis/report.lisp"
   :SHA256 "3a899b08d12170ffe210691c293715286f544f02c9566c2f6acef707743b8876"
   :BYTES 363475)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-ready-only-spike/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-ready-only-spike/conservazione.lisp"
   :SHA256 "d24f2a378b4fde637d16c40065b4880aa1a091fe4819c66fbe32590660ac29ee"
   :BYTES 1180)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-ready-only-spike/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-ready-only-spike/report.lisp"
   :SHA256 "0b8c058228dba8f2f1768991ba5210c1a7f5babb117ada30503b64ac768a232b"
   :BYTES 372362)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-ready-spike-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-ready-spike-analysis/conservazione.lisp"
   :SHA256 "c96d1db652343faca9797db3c15ee366c8fea948ba0e36d2994a3a21e3312e6f"
   :BYTES 1188)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-ready-spike-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-ready-spike-analysis/report.lisp"
   :SHA256 "cc67f799be1f543ca9d7e0faa8e54c011ba2ebe01644f456e7b1d017b2e3777a"
   :BYTES 363469)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-ready-spike/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-ready-spike/conservazione.lisp"
   :SHA256 "6ae72cc3427628388c80902063a9596e0bf11add526fdb6402c115d8ea2fcc78"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-ready-spike/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-ready-spike/report.lisp"
   :SHA256 "003722db9a739c20bad12f1592ccb28e17029231d9d02877c2895a34146dea88"
   :BYTES 372351)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/SPK-01.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-01.lisp"
   :SHA256 "27dfd8ee7d3fcdeb41a29cd9366c7cb4e0f48d111e0654eac191ca50e12a6380"
   :BYTES 27228)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/SPK-02.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-02.lisp"
   :SHA256 "26e0c856695398d5ea06394bcb4cae79e5d377e8083c1952b1e60fbf9560df46"
   :BYTES 1607)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/SPK-03.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-03.lisp"
   :SHA256 "51fd1ea19aa99039438eeb6632565c4d957b50dee4599583b3b9255ea1f444ba"
   :BYTES 3663)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/SPK-04.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-04.lisp"
   :SHA256 "8b2b55fa2d0874b2fd486aa84008ecb7df156a883d8f3b2bf4fdcaab474a148d"
   :BYTES 6752)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/SPK-05.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-05.lisp"
   :SHA256 "843111ef3b36decb1027204d85c8ceaf31b76bc60ce75f997447ba5560fc94b8"
   :BYTES 10055)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/SPK-06.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-06.lisp"
   :SHA256 "c108a97a7e010b2ad5b078abcbab45758fbdf83b8e7e9143a61bc2e6c0184835"
   :BYTES 23971)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/SPK-07.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-07.lisp"
   :SHA256 "6c473f19311506ab11c6a938d876bf7cf7a0cb8f5a2210e9a51a70ba3270802b"
   :BYTES 318)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/SPK-07.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-07.lisp.gz"
   :SHA256 "bb49fd741ed84e4380b474a49342f25c1d17b943d2892fcdf2d9953027b31228"
   :BYTES 411735)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/SPK-08.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-08.lisp"
   :SHA256 "0d83dbbab977a16e5f4c821e15865314f5a3ef733fd7b99763493b591bda4861"
   :BYTES 331090)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/SPK-09.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-09.lisp"
   :SHA256 "c9796435b9fe0f5acf2f5bb717f8ae218b8636360f1d4c4a0689e4230356cea0"
   :BYTES 2472)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/SPK-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-10.lisp"
   :SHA256 "29843bf183cfde97c72091fe9a53dacf47aceaca1690d179d6c4da3c7babcaa3"
   :BYTES 22969)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/SPK-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/SPK-11.lisp"
   :SHA256 "99fc53c7b4723be99c0667bfa74708222958afa443f4f354f624a0a86cb7939a"
   :BYTES 74130)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/conservazione.lisp"
   :SHA256 "cacde663079361aa0781b3698143b9ffb4ffbe2aa5f783323535012773b31301"
   :BYTES 2352)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/report.lisp"
   :SHA256 "dc669a4393296801570e178135e3b931f40fb305632ea0c625511505a87f242b"
   :BYTES 318)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002553736-check-70020-0/report.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/4002553736-check-70020-0/report.lisp.gz"
   :SHA256 "723e4358a377702f9ed384caabd8aae41a99f0ae3253c689e327c39d9f891f28"
   :BYTES 483844)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-0C4AGX/0/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-0C4AGX/0/scan-9.lisp"
   :SHA256 "35a21e2ab95e4de5f0523b0ad528c9df079debab22603c3879f24ae3231d3e68"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-0C4AGX/0/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-0C4AGX/0/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-0C4AGX/0/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-0C4AGX/0/scan-9.stdout.log"
   :SHA256 "1264d042cf149be87cce40f10501c7ead88737c3dec729f8db68b0e9b133a05f"
   :BYTES 4044)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-0C4AGX/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-0C4AGX/0/session.pid"
   :SHA256 "ee2a43e9d3db1f2f885e3cf7016445bdf12bcf7540458a57fc6cc442490bf3c6"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-0C4AGX/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-0C4AGX/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-0C4AGX/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-0C4AGX/0/stdout.lisp"
   :SHA256 "400eb853d099c20dd451ff7d67cc334ffea07ac6215f7c1fedb92a3d68c4bba4"
   :BYTES 293)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4OlOLB/0/scan-39.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-4OlOLB/0/scan-39.lisp"
   :SHA256 "d3ac92c10ed4f010db11b7f93c5e10e15085a5d2ef188b8281da374a5457d63e"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4OlOLB/0/scan-39.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-4OlOLB/0/scan-39.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4OlOLB/0/scan-39.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-4OlOLB/0/scan-39.stdout.log"
   :SHA256 "a60cfd1d2af3ffa111668e1071953ab01575889733c1fdfaa1ecc3dad4f261bc"
   :BYTES 4098)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4OlOLB/0/scan-40.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-4OlOLB/0/scan-40.lisp"
   :SHA256 "149fbed4c7c27786b11af0a5267ffbff3389457c010a92b29b719be9a8dadad7"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4OlOLB/0/scan-40.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-4OlOLB/0/scan-40.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4OlOLB/0/scan-40.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-4OlOLB/0/scan-40.stdout.log"
   :SHA256 "0fc16b1e4c836f3297a9e18705efdd33bf44234fad0a09f37768161e6fc37eb5"
   :BYTES 4092)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4OlOLB/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-4OlOLB/0/session.pid"
   :SHA256 "5bc37ff6113796eb6dcbbaf69f3a6e02e641f670dd9173d1dcec05c7db834499"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4OlOLB/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-4OlOLB/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-4OlOLB/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-4OlOLB/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/0/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/0/scan-5.lisp"
   :SHA256 "c682104220f41e9a78ce48a11d7d51f091aba6761e65e68309ecfab71dcfa6d3"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/0/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/0/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/0/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/0/scan-5.stdout.log"
   :SHA256 "4e3e2b4793cd6555b922b0e37d21147d18588c6631d9ce18d0e0acb1525ceec7"
   :BYTES 4104)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/0/session.pid"
   :SHA256 "1871bbc4a805ceff8d114d9c1e58ee9efcb9e2a1a1ea413599cc47a3e68468c2"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/0/stdout.lisp"
   :SHA256 "5308987d0ed5e6648b0caa49a3ad2045710b8e4c689ce969eb22165fc1ee7a1b"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/1/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/1/scan-6.lisp"
   :SHA256 "60c0d091e39a2110c789af5bf5e11a79ad1e10e8b2ff7489d7b29cafddcbc312"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/1/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/1/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/1/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/1/scan-6.stdout.log"
   :SHA256 "40a67d0c6d88b917ae27843ce961104323252673a1dd0e066d2d5244bb944e7a"
   :BYTES 4098)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/1/session.pid"
   :SHA256 "446e48c188d0523b9c5cd2c5f0682a7d8eecd2d8afc79c489eb2ff365c91c47c"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/1/stdout.lisp"
   :SHA256 "9a8de273c4febecded1b2263c9f9efb3d4fde9798de26aa6cb3e1e9286b4dcfd"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/2/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/2/scan-8.lisp"
   :SHA256 "7982839a57771330394f0df631c4e4e9f6c698c7256e125e6acaad05faa44866"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/2/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/2/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/2/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/2/scan-8.stdout.log"
   :SHA256 "5747bf32e3c2e9d4a270c3ce93feddbb5d5f04ff0f7b0b9dcd1590e1783b5374"
   :BYTES 4104)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/2/session.pid"
   :SHA256 "7ef7ec61b91b925e6ec8a0abe08cc19ea11f6bba7af053b0a35157e78cf170c7"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/2/stdout.lisp"
   :SHA256 "4c4be637a738f2b2f2ea8acb4ce4b9efbb4f426d7af766561f7af7e600c11f4c"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/3/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/3/scan-7.lisp"
   :SHA256 "c66132a5de69b37ad4f1a7634e14596cfbbdc4a97ab3306b12dc97d673ba5a19"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/3/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/3/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/3/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/3/scan-7.stdout.log"
   :SHA256 "b39afc18c7c7783a06fe78d6c06f95a0f9ef126816f210c7c0edcc6e23f267bf"
   :BYTES 4098)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/3/session.pid"
   :SHA256 "e74b40ff687d6842a7f7db57f70885bbbdbc29d33d9ccd143ed88b387af9a524"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5cI3LQ/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5cI3LQ/3/stdout.lisp"
   :SHA256 "c13c0ae8a9bc375bac89fae252a045ce64e57940926af4060389f304fc0a091b"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5knLBx/0/scan-13.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5knLBx/0/scan-13.lisp"
   :SHA256 "5f56bcd4eefbf7de5e307339ef3149392be022ca91f626e8379372a8cf606a1c"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5knLBx/0/scan-13.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5knLBx/0/scan-13.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5knLBx/0/scan-13.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5knLBx/0/scan-13.stdout.log"
   :SHA256 "c1cf7ee75972ee26245adbb94b97cec6a59689b73c26848e0a58cbc73ed887d1"
   :BYTES 4188)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5knLBx/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5knLBx/0/session.pid"
   :SHA256 "3136468167605b591906e0bd2b5addc9d11fec0539f0367823626a2482431559"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5knLBx/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5knLBx/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-5knLBx/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-5knLBx/0/stdout.lisp"
   :SHA256 "c5b72b1982b2d542aca129081e4be062b1f187e65a652f26a72cc9b212847e81"
   :BYTES 307)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6Zfbbb/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6Zfbbb/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6Zfbbb/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6Zfbbb/0/stdout.lisp"
   :SHA256 "1aba1b8411237abaed6442501e0e799f95ed9ee0869201cfc812d40c06ac90a7"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6Zfbbb/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6Zfbbb/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6Zfbbb/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6Zfbbb/1/stdout.lisp"
   :SHA256 "a992cb836813dd297036773702f237fbd534ad062747a1c2d3ee29bd3653ebea"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6Zfbbb/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6Zfbbb/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6Zfbbb/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6Zfbbb/2/stdout.lisp"
   :SHA256 "01fb48854a8d8bdb2dddde7f6d7bc1c008b13d9f6a06338c23d0b0fd8e6bc9ef"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6Zfbbb/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6Zfbbb/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6Zfbbb/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6Zfbbb/3/stdout.lisp"
   :SHA256 "15d8a275bbd162d7ab5d7e157757726fd56233820623ad854d3a90287a627843"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/0/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/0/scan-1.lisp"
   :SHA256 "b9a1edbc9c159eb5f954fbd6cce873fd2c18d2269f780b6a97063c5ea43695de"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/0/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/0/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/0/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/0/scan-1.stdout.log"
   :SHA256 "e3f942b737718227283066bf7b2b51e57ff962891cb0755be95b366333e1ca99"
   :BYTES 4080)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/0/session.pid"
   :SHA256 "7bc4a34efb0abbaafc15e0bfb878a175c672e55d4838a9045447681e54910b40"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/0/stdout.lisp"
   :SHA256 "5308987d0ed5e6648b0caa49a3ad2045710b8e4c689ce969eb22165fc1ee7a1b"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/1/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/1/scan-2.lisp"
   :SHA256 "a930319b2f53324b6ae1d5828f83cdd34744ad3ea4d26fd2075afaf35c88b4f1"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/1/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/1/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/1/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/1/scan-2.stdout.log"
   :SHA256 "c5752cb6067cd95ccb1eaa24709e8b3096dec9a321000350e82a1edd89a43caf"
   :BYTES 4074)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/1/session.pid"
   :SHA256 "e41be7f685dd968e0e46b238527b451bde57a3dc23f7dac5aa017f50f2467ec6"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/1/stdout.lisp"
   :SHA256 "9a8de273c4febecded1b2263c9f9efb3d4fde9798de26aa6cb3e1e9286b4dcfd"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/2/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/2/scan-4.lisp"
   :SHA256 "6312ba1fda627ea68d89e12273cdf2e6f8a34d364157088eea3273e508465daa"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/2/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/2/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/2/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/2/scan-4.stdout.log"
   :SHA256 "d97b2df1916b24322687d8bc245544f8e8cbfd9336350e5dcb40b21aa45383b0"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/2/session.pid"
   :SHA256 "20bfc54ec19bf96ebc5371379e63c328d447a5d5a408a7da06ca690bc34de5d9"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/2/stdout.lisp"
   :SHA256 "4c4be637a738f2b2f2ea8acb4ce4b9efbb4f426d7af766561f7af7e600c11f4c"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/3/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/3/scan-3.lisp"
   :SHA256 "1abfb15a2a448f73bb1f06f9ca3240383428727dc7617c7085921f30f5da8073"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/3/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/3/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/3/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/3/scan-3.stdout.log"
   :SHA256 "b6f06fc747723b30fc035e865b6557efeced1e4859c05df60731cdc1e23ac1c0"
   :BYTES 4062)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/3/session.pid"
   :SHA256 "873bb42c43b16574f348a52aa69d83f8413bb3a030c02fb3f496e79508c4bf58"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6aX126/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-6aX126/3/stdout.lisp"
   :SHA256 "c13c0ae8a9bc375bac89fae252a045ce64e57940926af4060389f304fc0a091b"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7Los1n/0/scan-26.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-7Los1n/0/scan-26.lisp"
   :SHA256 "8f28d4217f5a50412eb2ab2ca15b820ffb95f7c7212dc29a2cc2486f77568faf"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7Los1n/0/scan-26.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-7Los1n/0/scan-26.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7Los1n/0/scan-26.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-7Los1n/0/scan-26.stdout.log"
   :SHA256 "aae37e1c67a9230f22641f3d0bccc4f8c52d490a0008cadc83e0d9e335db9a80"
   :BYTES 4020)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7Los1n/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-7Los1n/0/session.pid"
   :SHA256 "46597b767b181bd0c1311dbdeeda642009df81c6aafb4059d8848c7e1986748b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7Los1n/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-7Los1n/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7Los1n/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-7Los1n/0/stdout.lisp"
   :SHA256 "07813a194769ea53c08ecd5f646f56f41fce7595fd6f73ab59521daeef6d4355"
   :BYTES 498)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7XDYic/0/scan-30.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-7XDYic/0/scan-30.lisp"
   :SHA256 "46226aaea532a420ec2a90baec5ad394d07fded5ebcd4496e5ed2e9162c7bc62"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7XDYic/0/scan-30.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-7XDYic/0/scan-30.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7XDYic/0/scan-30.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-7XDYic/0/scan-30.stdout.log"
   :SHA256 "28c2b4409d157ee04d3070ddea9ff5de24d59e0d1bbb817f7df96f90dd57c172"
   :BYTES 3954)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7XDYic/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-7XDYic/0/session.pid"
   :SHA256 "d8e9b04e166e174e5663263f5712e49fdb3b3d8bfff595a2fe3bf2afd5f4cd58"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7XDYic/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-7XDYic/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7XDYic/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-7XDYic/0/stdout.lisp"
   :SHA256 "6393e952dc4cdeebed3b547f9830f2c49ae4582419e3ab68204fef55ad2a6aed"
   :BYTES 927)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8lXWiF/0/scan-28.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-8lXWiF/0/scan-28.lisp"
   :SHA256 "c9cefffd4533ddba3027b04ea7b3cf8f2c950cd77657b781a94c54892add404e"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8lXWiF/0/scan-28.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-8lXWiF/0/scan-28.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8lXWiF/0/scan-28.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-8lXWiF/0/scan-28.stdout.log"
   :SHA256 "d314a80105848e4306e781861429d69d3cb08407bf9abfdcd4380488b7812b44"
   :BYTES 3996)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8lXWiF/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-8lXWiF/0/session.pid"
   :SHA256 "e8a4a1f14c0a449aba5127e2883f3915a665512e818f1a12e303fef26b0aa6bc"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8lXWiF/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-8lXWiF/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8lXWiF/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-8lXWiF/0/stdout.lisp"
   :SHA256 "02eed5e4b7d0c840b230d416fcd9c15e63919f962fbfe6dac2f639c3651aed6c"
   :BYTES 277)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-9XjNU9/0/scan-12.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-9XjNU9/0/scan-12.lisp"
   :SHA256 "021129b399b83272249c00696915c92ee68aeced00ca56d81fcf5c4be2c1a5a3"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-9XjNU9/0/scan-12.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-9XjNU9/0/scan-12.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-9XjNU9/0/scan-12.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-9XjNU9/0/scan-12.stdout.log"
   :SHA256 "4ce5992e89bb3e6961e64a2fede17529d412a34a5a65cfd1cc10e474af69cc49"
   :BYTES 4080)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-9XjNU9/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-9XjNU9/0/session.pid"
   :SHA256 "6eea1c653bc716f2feba1185dbe71966fe0efe3a3b22a4910d66dba56fd77170"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-9XjNU9/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-9XjNU9/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-9XjNU9/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-9XjNU9/0/stdout.lisp"
   :SHA256 "b4e53dceed6bf2b62ed555cc017f19b8f4779f57fd0c6db0632a9011f6bccab7"
   :BYTES 308)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AgOz2z/0/scan-41.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-AgOz2z/0/scan-41.lisp"
   :SHA256 "af6b72b0778b08c0c2cdc6c87d825ec84c6a5c124c698873682fb2a0c1e8d1b4"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AgOz2z/0/scan-41.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-AgOz2z/0/scan-41.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AgOz2z/0/scan-41.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-AgOz2z/0/scan-41.stdout.log"
   :SHA256 "6382504d5fe0f04e33a0242aeb8c1ce62e7f8f05006216835a4557218d96cfa4"
   :BYTES 4098)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AgOz2z/0/scan-42.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-AgOz2z/0/scan-42.lisp"
   :SHA256 "9a84cad12624373f671890e0d8662c59be5e09c6c8a85f5c5134eaa7a744c87d"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AgOz2z/0/scan-42.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-AgOz2z/0/scan-42.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AgOz2z/0/scan-42.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-AgOz2z/0/scan-42.stdout.log"
   :SHA256 "a8e6b03d2874247a47bf9dbe7755ed706087d1892fc5b990968de67f49a5bc29"
   :BYTES 4098)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AgOz2z/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-AgOz2z/0/session.pid"
   :SHA256 "f4c0be426827fbcce0d15fda8621aaa5f106420c12268da72f051e0e224b01dd"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AgOz2z/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-AgOz2z/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AgOz2z/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-AgOz2z/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BFpWq5/0/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-BFpWq5/0/scan-10.lisp"
   :SHA256 "cd6495225e9bdd362605d3d92027e8b2549d0b371e652a42698efc0a991336d8"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BFpWq5/0/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-BFpWq5/0/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BFpWq5/0/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-BFpWq5/0/scan-10.stdout.log"
   :SHA256 "9a4e78529b0bc1a37192b2957ae264aa579dbaac6f64b5227ac74aca0a5524d7"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BFpWq5/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-BFpWq5/0/session.pid"
   :SHA256 "f31d5823cd4eda2b4bc79aee767a9c002a49ada7dbce22f33a0a2b76b046dbcb"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BFpWq5/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-BFpWq5/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BFpWq5/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-BFpWq5/0/stdout.lisp"
   :SHA256 "38622a2ffa623b544979f28e057f0ea591f0e7cf7d166aa651610401ca82c324"
   :BYTES 295)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BH9T7v/0/scan-27.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-BH9T7v/0/scan-27.lisp"
   :SHA256 "0f80f311c92e290c6591c0fa025674c0f5d69c8fc63f026cc09a6b780611df02"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BH9T7v/0/scan-27.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-BH9T7v/0/scan-27.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BH9T7v/0/scan-27.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-BH9T7v/0/scan-27.stdout.log"
   :SHA256 "ca93a6eb3d2c56e8aea11f53a298a8e13d4f63e0e647da01b4f60b7181e0d2da"
   :BYTES 3996)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BH9T7v/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-BH9T7v/0/session.pid"
   :SHA256 "03a0acfb4e1757b78ff4b11fe00159d68e9b73999b796ef1a814d278fee56511"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BH9T7v/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-BH9T7v/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BH9T7v/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-BH9T7v/0/stdout.lisp"
   :SHA256 "02eed5e4b7d0c840b230d416fcd9c15e63919f962fbfe6dac2f639c3651aed6c"
   :BYTES 277)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Bjk0vE/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Bjk0vE/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Bjk0vE/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Bjk0vE/0/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Bjk0vE/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Bjk0vE/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Bjk0vE/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Bjk0vE/1/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Bjk0vE/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Bjk0vE/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Bjk0vE/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Bjk0vE/2/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Bjk0vE/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Bjk0vE/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Bjk0vE/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Bjk0vE/3/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ColnPP/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-ColnPP/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ColnPP/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-ColnPP/0/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ColnPP/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-ColnPP/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ColnPP/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-ColnPP/1/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ColnPP/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-ColnPP/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ColnPP/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-ColnPP/2/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ColnPP/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-ColnPP/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ColnPP/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-ColnPP/3/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/0/scan-32.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/0/scan-32.lisp"
   :SHA256 "93f8a1e6c0676fee6600015b14a06dd967419a373b5a04e9125bf9d6545bf020"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/0/scan-32.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/0/scan-32.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/0/scan-32.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/0/scan-32.stdout.log"
   :SHA256 "0e3a7d284df13381eb79fcb5227f0dccffcb1919127cc6c2b6e70a444dcf98e8"
   :BYTES 4080)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/0/session.pid"
   :SHA256 "5b5bc581158d30da418f75495b0398ff599f26ff07a6bc4d00823b119eddad7b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/0/stdout.lisp"
   :SHA256 "a47252223c01910f0488859d95ee2579e3e42545cb298570af59e2defccc7196"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/1/scan-31.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/1/scan-31.lisp"
   :SHA256 "3b000d0cee7f2acab1eb555d6672d896f367c32e447c25c20d215a0c6cd9e87e"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/1/scan-31.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/1/scan-31.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/1/scan-31.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/1/scan-31.stdout.log"
   :SHA256 "a47e9a18fcc52feee6f382c3ae7226b41d33238f09ce9d0c381fdb4fb6b30036"
   :BYTES 4080)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/1/session.pid"
   :SHA256 "0901a1c0ba6a1bdae8a7c87316b5347aef74a92caee99c6aee08768b363e33bd"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/1/stdout.lisp"
   :SHA256 "77613bba25368f6afa6aac4194ef2d3afe9f7982b9343839f5adcd50177a183c"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/2/scan-34.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/2/scan-34.lisp"
   :SHA256 "b39f7d8cd1c153b4c88e08a49b0b26d307b8b009cef2d3df4d72f7ca8b4bdd79"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/2/scan-34.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/2/scan-34.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/2/scan-34.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/2/scan-34.stdout.log"
   :SHA256 "94e6c265606399749e16dd84e887cf4cfcb49ffc80c285e691336fb24d8e32a4"
   :BYTES 4086)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/2/session.pid"
   :SHA256 "3103b3dfa9c0fd6d02de6fdcebb9082bd460b546c7a3122a517b40dffecf9a88"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/2/stdout.lisp"
   :SHA256 "816f358c054623dfde9c70437d634b6e0f1d8bd2b99bfad6dcde097404820e51"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/3/scan-33.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/3/scan-33.lisp"
   :SHA256 "e7362dd46a2deabe5295795f019d507b35814733054bc30a39f9855fe0a01197"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/3/scan-33.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/3/scan-33.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/3/scan-33.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/3/scan-33.stdout.log"
   :SHA256 "ae1ba83cabdc40f0520d7aed7465a4f24f447cb038c76ec1a702e423f666ae7a"
   :BYTES 4086)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/3/session.pid"
   :SHA256 "bd2a301a22cd0fe97b925c4b2aa9077efa713f348b0f17620d6440df0ce03387"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DS6lA0/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-DS6lA0/3/stdout.lisp"
   :SHA256 "0c1da6f2edeb8247d6633b6ccbdea32d7f39b9ab9e275c97f327399eb2e05e14"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-FCnIFk/0/scan-17.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-FCnIFk/0/scan-17.lisp"
   :SHA256 "460c55548bcddbf2367165faaccd6c840a35367777bb0e11de1e0d6585a3ec41"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-FCnIFk/0/scan-17.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-FCnIFk/0/scan-17.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-FCnIFk/0/scan-17.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-FCnIFk/0/scan-17.stdout.log"
   :SHA256 "741bb4cd917809ba4bda2c94b6f06290e9b04d526b436cf818bb6749470e3a3c"
   :BYTES 4098)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-FCnIFk/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-FCnIFk/0/session.pid"
   :SHA256 "217002599aba565424acc04fb1e03ffc5c2704720b60abb3ebd63f650c9c4faa"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-FCnIFk/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-FCnIFk/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-FCnIFk/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-FCnIFk/0/stdout.lisp"
   :SHA256 "58cc73d6328682e92d746fd63414030c672e17da1a489a3b8b213be5d5d81ffa"
   :BYTES 454)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-LwYLHC/0/scan-16.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-LwYLHC/0/scan-16.lisp"
   :SHA256 "04166e9f3aed6be741afcc68dd7b8468256a2cfa3c8845df172ea9ed632fe6c1"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-LwYLHC/0/scan-16.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-LwYLHC/0/scan-16.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-LwYLHC/0/scan-16.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-LwYLHC/0/scan-16.stdout.log"
   :SHA256 "844f27e60e99807fd26d2887ad4f857b63766d3687a4accbadefd59f5b5dcec0"
   :BYTES 4092)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-LwYLHC/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-LwYLHC/0/session.pid"
   :SHA256 "fd4703feafe4a29f4d9f694e1c781bbd850e6b83980e13af6dc486519fe9a673"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-LwYLHC/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-LwYLHC/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-LwYLHC/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-LwYLHC/0/stdout.lisp"
   :SHA256 "afaef750f895a042dbdf08385c2f8b3a0a6092c7fa020a08854476383a293314"
   :BYTES 452)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MuhHkd/0/scan-29.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-MuhHkd/0/scan-29.lisp"
   :SHA256 "6d6223ae4ce7dbba7b9f3d56dcfa6b5435fd459bcb367f6790abcfa57a2c66cb"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MuhHkd/0/scan-29.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-MuhHkd/0/scan-29.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MuhHkd/0/scan-29.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-MuhHkd/0/scan-29.stdout.log"
   :SHA256 "9c68dbf37e7750bda522e93fbeaac069a8047bbd1288f180eea64bb14a186a2a"
   :BYTES 3966)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MuhHkd/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-MuhHkd/0/session.pid"
   :SHA256 "2442927763bc421b298eacc98db7cf11bd81cfa1c4fd4f173997bf7fde9f8478"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MuhHkd/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-MuhHkd/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-MuhHkd/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-MuhHkd/0/stdout.lisp"
   :SHA256 "d0a5cced30de0f15858be64cf62635c91ad888af4a204386c9f5a4a7222a5ac4"
   :BYTES 514)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/0/scan-38.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/0/scan-38.lisp"
   :SHA256 "63ebc55d632a95443e85109f763ba33b0f11930ee35a828b905df1c7a0ce9ea4"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/0/scan-38.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/0/scan-38.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/0/scan-38.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/0/scan-38.stdout.log"
   :SHA256 "fbfcef7d315faeff5aab29ce5536a6e2ad885ad9d899fdc59383fb5ff1680bab"
   :BYTES 4104)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/0/session.pid"
   :SHA256 "5593887c6c886e0f0a27a63adc6331eb2b2c7644307b25ef23d9b424e87063e7"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/0/stdout.lisp"
   :SHA256 "e82a7f300e53be591e9d094fced1db6f478104ec3ff270404ad133150d52360d"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/1/scan-37.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/1/scan-37.lisp"
   :SHA256 "aa9cdb61173a929eef71395f7c40a2fc2d02c910cad64747582b597aa5f56324"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/1/scan-37.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/1/scan-37.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/1/scan-37.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/1/scan-37.stdout.log"
   :SHA256 "58ef4baef27fddb04a6a6d583df115d1d0dd6916f38dd841bc68e51864bd8774"
   :BYTES 4104)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/1/session.pid"
   :SHA256 "c4e57d8bf3b08cc6be7f355c4a985e6655cbb41eccb82277a6dddb47e4ef09b5"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/1/stdout.lisp"
   :SHA256 "d4b7053549008c9b8203b40f93a66f7f7445902c88a33cac3c545389c33cc3d8"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/2/scan-36.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/2/scan-36.lisp"
   :SHA256 "ec1694e964da5823a33cc5f3666894f7c5fded30c94e0a5c408b860ce7fdcd8c"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/2/scan-36.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/2/scan-36.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/2/scan-36.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/2/scan-36.stdout.log"
   :SHA256 "2191758ba7c0dcf3cd6e6c4db8f96262eaea41661764e6f20564385277daf7f8"
   :BYTES 4104)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/2/session.pid"
   :SHA256 "7467f8daaf24a311c7eb67767374b431b50c4e43dfd9efe86eaeb2e1402c8f88"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/2/stdout.lisp"
   :SHA256 "ad01ded00c2acc8e30622335d211e37fc72ab89b8da752bf2904da2551e8e87c"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/3/scan-35.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/3/scan-35.lisp"
   :SHA256 "24d96e36778297fe75f6d1c6b825d4193adabef46a70b6059cac0f9158de4703"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/3/scan-35.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/3/scan-35.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/3/scan-35.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/3/scan-35.stdout.log"
   :SHA256 "853d14e8528f38b77df4866897f2f5ef76911a4ff2644a631a8a616973b66b59"
   :BYTES 4104)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/3/session.pid"
   :SHA256 "a53be672669de4964461dbc642daa42dcc37fbbd47689dec8eb49f645baad003"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NCKq3z/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-NCKq3z/3/stdout.lisp"
   :SHA256 "4f91b729bfa80473e1b24b28c1addbf8b667c028a9b4e2a9c2086fe7f777e055"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/0/scan-21.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/0/scan-21.lisp"
   :SHA256 "2c8e89934730c20e71fd881fb8670e2b928d42ad231077304c522763f847eccb"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/0/scan-21.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/0/scan-21.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/0/scan-21.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/0/scan-21.stdout.log"
   :SHA256 "0a53de8a94b77a3e5427dcf2d8938e4fa93a7b557c240b4005f3bf189f49a4af"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/0/session.pid"
   :SHA256 "46bb5d61a8e10ee8db6f83dcb9b7fd68744aacc0c289df870d11b9db3f645a7f"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/0/stdout.lisp"
   :SHA256 "529c3ff5be6bc1ba29442ca04eb060b613565209f62ad674a92d21a01ab97bb0"
   :BYTES 750)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/1/scan-22.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/1/scan-22.lisp"
   :SHA256 "a88516a7a6ee0b3a1a712ff14f8d8eeae7cc17b46c976a899885e57c47a43ad7"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/1/scan-22.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/1/scan-22.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/1/scan-22.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/1/scan-22.stdout.log"
   :SHA256 "270b9a342b3e283372953e93f034bb37e550bbef69f51b8dbcb4ad36de698c58"
   :BYTES 4062)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/1/session.pid"
   :SHA256 "2d87bbca47b19030a202b15eafc4635d753217a747f806bf464423e0e7e07725"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/1/stdout.lisp"
   :SHA256 "eec7fd9a41446788a3dbb7a8b15f3729f9c13b95152350a9c39f6ba5f3d6f437"
   :BYTES 752)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/2/scan-24.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/2/scan-24.lisp"
   :SHA256 "dd3758710e98b610d195a026e6fdd16b6a0d99e07ee7fc1c31e36cdf1cf9f313"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/2/scan-24.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/2/scan-24.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/2/scan-24.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/2/scan-24.stdout.log"
   :SHA256 "cfde19a854e994e2b59acaed3aaf26b45a55a469735209e422731942df223a22"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/2/session.pid"
   :SHA256 "b689f78c5f6972d8e23439a2fa1f0555ece6d86ad11563abc77d8196dc832445"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/2/stdout.lisp"
   :SHA256 "a08ff6554ebbd429c29c3b9529451d391fa357fb4230414644e66c5be8456c7c"
   :BYTES 286)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/3/scan-23.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/3/scan-23.lisp"
   :SHA256 "aba24f4203b96d54f3bbe2ecdaa5982651143e76274ac52d7a41dbcc1a24fb27"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/3/scan-23.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/3/scan-23.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/3/scan-23.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/3/scan-23.stdout.log"
   :SHA256 "297783ac7725252b6d66aadbc8874fc6bcbeb6830c3c0d2eab1d57dc43f6d3aa"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/3/session.pid"
   :SHA256 "856b0be86f1b620338b6f7d814c465442a2630e4c422184adcab5fcbcc68ee5d"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P3jbD4/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-P3jbD4/3/stdout.lisp"
   :SHA256 "2cc445c515b6b155c69c54af87374b82cb2d0f70c33c6cd2f0db60c85d847fa8"
   :BYTES 286)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PCdP05/0/scan-20.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-PCdP05/0/scan-20.lisp"
   :SHA256 "57bf52fe4c6b52cbe0ff048959324d57b766045244a9c2e289cefb11aedeb74d"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PCdP05/0/scan-20.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-PCdP05/0/scan-20.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PCdP05/0/scan-20.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-PCdP05/0/scan-20.stdout.log"
   :SHA256 "64e199ae675c7457e49dd85b6b949d2c2875b5ce764406f3f7dd609d89df9636"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PCdP05/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-PCdP05/0/session.pid"
   :SHA256 "2f68a4e1dfdd3f5b75f83fdde510373b4281be1d076d9f09fec8f8ab609a1002"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PCdP05/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-PCdP05/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PCdP05/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-PCdP05/0/stdout.lisp"
   :SHA256 "c048b2d69aefcde781a23fa6c62255415f6ea51b5daaa21cec0c7a2c50f0f817"
   :BYTES 472)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Pug5m2/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Pug5m2/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Pug5m2/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Pug5m2/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Pug5m2/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Pug5m2/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Pug5m2/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Pug5m2/1/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Pug5m2/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Pug5m2/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Pug5m2/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Pug5m2/2/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Pug5m2/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Pug5m2/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Pug5m2/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-Pug5m2/3/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/0/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/0/scan-4.lisp"
   :SHA256 "1f99b9f7922d132c9af0eb2a5f46ed84fe7ae722340630960465b1bf08ed6252"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/0/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/0/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/0/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/0/scan-4.stdout.log"
   :SHA256 "d75e6f8cf4f6b4db059cdcc5815df2ce050f449fe67409f88ed52581b4e705c2"
   :BYTES 4596)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/0/session.pid"
   :SHA256 "ba31a0798aaa77ad14f49e328b23286e70cde5e4d204771f9f41593c0ce434d8"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/0/stdout.lisp"
   :SHA256 "3c3e1d0db8c3c9caca1995916027d78492d2f580d5e50cdf94d4e59281dd4aed"
   :BYTES 220)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/1/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/1/scan-1.lisp"
   :SHA256 "f4c13dd8ea46454056d35db41418c491f48378341c129083e1f64e3780ae9f16"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/1/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/1/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/1/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/1/scan-1.stdout.log"
   :SHA256 "092d892d860ec5e24f15a875a90dd84988e198eaf15fa5fc9e016cb845581d6c"
   :BYTES 4596)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/1/session.pid"
   :SHA256 "7ed0ac4a5038e93589a634204fdfc2266b46e7422a59ddc662cda4c5d5f4daf0"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/1/stdout.lisp"
   :SHA256 "1408b0f66ab661b8673cd350d40e192493dba517be5a2705d382c63c8438d28d"
   :BYTES 239)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/10/scan-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/10/scan-11.lisp"
   :SHA256 "a1c1d4b82e75c45cf83fc7d37df54512c22b52ce994767b764224662bf8febb7"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/10/scan-11.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/10/scan-11.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/10/scan-11.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/10/scan-11.stdout.log"
   :SHA256 "a8bbebb5b0435863ed983b8fb912ccf301853d62ae2c0a0ccd36c304ca8f2653"
   :BYTES 4596)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/10/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/10/session.pid"
   :SHA256 "dc348b32bab9b0338a2782b89b7bc7d9a1539e53d49e0d1c306fafd82a3e13b7"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/10/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/10/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/10/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/10/stdout.lisp"
   :SHA256 "b41750084e5f40f0277ebeb497e481080e7fe941baa7d744125d2c371e440c85"
   :BYTES 240)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/11/scan-12.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/11/scan-12.lisp"
   :SHA256 "8e070393d83be71758997403d2b54279657ee3b8f89d42ee2bb9bdfdc65d5ae9"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/11/scan-12.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/11/scan-12.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/11/scan-12.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/11/scan-12.stdout.log"
   :SHA256 "7926d68773851d62aa1d4156f8bdd13d50114352dff7124f2e44878b2b72ca6b"
   :BYTES 4590)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/11/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/11/session.pid"
   :SHA256 "0fcca5663588e6f1497d89456d5cde0cf716e706731251f0b09a10c54293792d"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/11/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/11/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/11/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/11/stdout.lisp"
   :SHA256 "e73c108e307445a6e4194c203f4b1ccd50a0f8bcf263d48fe3f388de1923c5b4"
   :BYTES 230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/12/scan-13.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/12/scan-13.lisp"
   :SHA256 "a60e4cfbabf688405f61dbefff9e059d5112c0cd8b6663cd23042825ae0732d5"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/12/scan-13.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/12/scan-13.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/12/scan-13.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/12/scan-13.stdout.log"
   :SHA256 "336fa7c72f65969f43f646dddb58798d06e5b6c437e3aeab79dff36d3e2066e3"
   :BYTES 4584)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/12/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/12/session.pid"
   :SHA256 "61fbe1e3351a66af8f4198b67f0ce0c1bab3d3554d91f02b285e2dbae60fdcb0"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/12/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/12/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/12/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/12/stdout.lisp"
   :SHA256 "a502520708b2fd9a0b2abcd2f7fc2c040042c9249c3a9966193a4cc08b941c3b"
   :BYTES 240)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/13/scan-14.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/13/scan-14.lisp"
   :SHA256 "11375553e5daa5b90364e4c6e30ac71684a359d118c965b705422a4ed71ded0d"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/13/scan-14.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/13/scan-14.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/13/scan-14.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/13/scan-14.stdout.log"
   :SHA256 "cc019dce93d688f80be21e17713ef0fb9f1bbd6db6c3c8ec579d47623bf6c714"
   :BYTES 4572)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/13/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/13/session.pid"
   :SHA256 "ffc87a4c5a337425d7d9383b715057969405b96832b9fd13816f5825038546cd"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/13/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/13/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/13/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/13/stdout.lisp"
   :SHA256 "4e98678e376e4a4625750ede03b73fcc8e9408333e83c8de7972982f0e35eddf"
   :BYTES 230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/2/scan-3.lisp"
   :SHA256 "3b4fdbaba066896274c225c861677b29cb2f3243d09bb52716d31c7ed2132bed"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/2/scan-3.stdout.log"
   :SHA256 "7b03027305beebe93a1b8cf10585ddca6f0a9511ef317535f92ad25a8c369d4e"
   :BYTES 4590)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/2/session.pid"
   :SHA256 "87ce2c96a7711cae712ff1ebd9f4fc50c423c8d9e832eae7d7fb3c2179e4665f"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/2/stdout.lisp"
   :SHA256 "2e7fca2d9e2fc0d9537df579c78b038ae3c1477cd817cd40fffacbc4cda80597"
   :BYTES 229)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/3/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/3/scan-2.lisp"
   :SHA256 "92a802010df386869adaff3ff271220d059c211ead30fa21bb956e98c7e6dc03"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/3/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/3/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/3/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/3/scan-2.stdout.log"
   :SHA256 "0207815bdf61c0c7905732fc722b35ef3f35cf3c1ecb5a088abc7e4710c96c02"
   :BYTES 4590)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/3/session.pid"
   :SHA256 "1a555ba0b74240477d96ff74e7a986a9f35006e914b9f787f5525a426ff528cd"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/3/stdout.lisp"
   :SHA256 "25564bda945c2105101cc7d392d13240d14238d1a27e9acf8da5f5ae0875158d"
   :BYTES 232)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/4/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/4/scan-5.lisp"
   :SHA256 "8dfbf79f1287d11fa959e7fb88f850cf30ece1861a203e6aed3b4338b023e84e"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/4/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/4/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/4/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/4/scan-5.stdout.log"
   :SHA256 "1aa36b4444ed7a20522038460cce7680de63189a814bdacb64df56f48d25ae30"
   :BYTES 4596)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/4/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/4/session.pid"
   :SHA256 "c95b46c01c40ac53b74fb11fd0e1a3a61b16ae62d15a23eaea8f32f2da711995"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/4/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/4/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/4/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/4/stdout.lisp"
   :SHA256 "2be099c08baa117e6464bba3c631874220ab09ec3b9d2dfa3fa3a54fb50eb69f"
   :BYTES 235)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/5/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/5/scan-6.lisp"
   :SHA256 "bd61f9effb5b4eea8871524a9097aff65eabd00741935d873b5cea62e6e88438"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/5/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/5/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/5/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/5/scan-6.stdout.log"
   :SHA256 "4bef2ef897f66b91940cf13a9d2913449e668e917e0576ad34e7308e6935dad9"
   :BYTES 4590)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/5/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/5/session.pid"
   :SHA256 "064fdde9f20438e0db56e9af49cb35cc430771337f7dd1bfb871ba1fb1fbe281"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/5/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/5/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/5/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/5/stdout.lisp"
   :SHA256 "c020b7cfad97537e62a5b046c84a727494a77429c7ba3d0b3c88699d692fadea"
   :BYTES 234)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/6/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/6/scan-7.lisp"
   :SHA256 "8cba41dc39072dc37f5ed5c7f1706859f7944ad30aa457d9350d8d4c5263cb27"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/6/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/6/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/6/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/6/scan-7.stdout.log"
   :SHA256 "f52293762791da53813e3f565a8d4230cc4f6b14332b7aeb9c32b9c9c4d550e3"
   :BYTES 4596)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/6/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/6/session.pid"
   :SHA256 "275444ea58ca8029f216a43f0ce03fd170535f5be4bcef450b3acb093c2d9771"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/6/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/6/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/6/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/6/stdout.lisp"
   :SHA256 "632ff70d8e777211e68c9c6aa18fbbacd544790316335340e811020c0820425a"
   :BYTES 235)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/7/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/7/scan-8.lisp"
   :SHA256 "a73459d93afdd7ab2b624615eabdfc421cdc01ac1cbf7abd9ca8ae47a26f4f54"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/7/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/7/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/7/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/7/scan-8.stdout.log"
   :SHA256 "d347eab0cf7f3585273d33fe8a797f0639b3f58c1b8a3a156364a13345f2a0b3"
   :BYTES 4590)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/7/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/7/session.pid"
   :SHA256 "c0acf9d8f081b1af1039e4ac069d7f0806c3054ab3a6bc936a071ef0e056b947"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/7/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/7/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/7/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/7/stdout.lisp"
   :SHA256 "ba7fcea75bc2864a21f3b940483384447375da9144341dee0b2be1a13f199598"
   :BYTES 226)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/8/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/8/scan-9.lisp"
   :SHA256 "8a16af2125002ef261dfcce4fae8e1dcf3cd0617ed84ce63fd45251f6d77cc72"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/8/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/8/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/8/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/8/scan-9.stdout.log"
   :SHA256 "331affbb2257eff41c840720abfd5a396d2195f1fe09fb6531e8d2043ae7d7f7"
   :BYTES 4596)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/8/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/8/session.pid"
   :SHA256 "bb7b423bd887ee8c2c95196a10af3e43ad4ef04a64a556ba8a5158995d62f908"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/8/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/8/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/8/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/8/stdout.lisp"
   :SHA256 "31ea0941716566ef078790085e72650d0e0e931bcea03088f090c3f9e6fb9c66"
   :BYTES 239)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/9/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/9/scan-10.lisp"
   :SHA256 "cedfe99e41167f219b23ecaa2d83d0bddaf0c8ae274b5dae6f31b06554a62d71"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/9/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/9/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/9/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/9/scan-10.stdout.log"
   :SHA256 "ad7c208fcf290a0fce2874dc8bd9cdaf2ddeee15ef160846440fbf470bd8d8e6"
   :BYTES 4596)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/9/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/9/session.pid"
   :SHA256 "7fd63f9884812e5d6ff460df1d64cbe25142d53b911be4eff52f2e8b5e592b2f"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/9/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/9/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RtQUQX/9/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-RtQUQX/9/stdout.lisp"
   :SHA256 "15ed29b95978e446d17cd9f520516673c21d11b1ceb647a83107d088cbc75fb4"
   :BYTES 229)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TrrCe0/0/scan-14.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-TrrCe0/0/scan-14.lisp"
   :SHA256 "ea2ac33685832e5b4ff6771bc713ca8f9f44fe8059df3aef3d04bb212463b854"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TrrCe0/0/scan-14.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-TrrCe0/0/scan-14.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TrrCe0/0/scan-14.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-TrrCe0/0/scan-14.stdout.log"
   :SHA256 "fdc05cd30ed688a12daac1ac010c842b012ad062b7a7d8b00dd512354f595112"
   :BYTES 4416)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TrrCe0/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-TrrCe0/0/session.pid"
   :SHA256 "fe2da50225e052202ad1faca60e6bcaad9957c1185fc7d8cc67dea4e7080888e"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TrrCe0/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-TrrCe0/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TrrCe0/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-TrrCe0/0/stdout.lisp"
   :SHA256 "b50f27955a9829449105b5fcae5ca59bc3db5798270f06654963ea7ba305d758"
   :BYTES 308)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WuOtlN/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-WuOtlN/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WuOtlN/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-WuOtlN/0/stdout.lisp"
   :SHA256 "9e087ee0238aef37990a59ccf823652669f3783072c1080b19e00d70e4d03817"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WuOtlN/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-WuOtlN/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WuOtlN/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-WuOtlN/1/stdout.lisp"
   :SHA256 "d4139f79125d475eb0b004a96908a6aeff001b4de52d793dac4d46aa87e71763"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WuOtlN/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-WuOtlN/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WuOtlN/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-WuOtlN/2/stdout.lisp"
   :SHA256 "dc95d22f8fafff6701bc6944bdf75dac2f266c2519e62c82498d6d10440fb083"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WuOtlN/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-WuOtlN/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WuOtlN/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-WuOtlN/3/stdout.lisp"
   :SHA256 "658e99d98e4469d4af64b092b47d1eaa411b291c18c4b911a8a6d84ab853c3f5"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YKR3K9/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-YKR3K9/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YKR3K9/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-YKR3K9/0/stdout.lisp"
   :SHA256 "830ab0204e5e65f6ed31c211bb3f3804e6b1db67e3f8f6309f05da67d4e38825"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YKR3K9/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-YKR3K9/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YKR3K9/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-YKR3K9/1/stdout.lisp"
   :SHA256 "830ab0204e5e65f6ed31c211bb3f3804e6b1db67e3f8f6309f05da67d4e38825"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YKR3K9/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-YKR3K9/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YKR3K9/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-YKR3K9/2/stdout.lisp"
   :SHA256 "830ab0204e5e65f6ed31c211bb3f3804e6b1db67e3f8f6309f05da67d4e38825"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YKR3K9/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-YKR3K9/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YKR3K9/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-YKR3K9/3/stdout.lisp"
   :SHA256 "830ab0204e5e65f6ed31c211bb3f3804e6b1db67e3f8f6309f05da67d4e38825"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-dP4q63/0/scan-15.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-dP4q63/0/scan-15.lisp"
   :SHA256 "d6b1a23d66831c2e3a8ddc784736ed4486f0b603f7241bc1c9972813dbf80688"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-dP4q63/0/scan-15.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-dP4q63/0/scan-15.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-dP4q63/0/scan-15.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-dP4q63/0/scan-15.stdout.log"
   :SHA256 "9131f41856cc07c336316515bc4b70e5dda3e1cbdb80b0c7492b354178847a65"
   :BYTES 4398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-dP4q63/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-dP4q63/0/session.pid"
   :SHA256 "da5c6f1e74c32efbd70abec1d93f8035ada8ac60a4ebde26ccfbc4a6cc50f370"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-dP4q63/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-dP4q63/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-dP4q63/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-dP4q63/0/stdout.lisp"
   :SHA256 "1e22ce4ba850fd31fc55503f577ee0601f39642e53cb7d65071e5c1847f6f124"
   :BYTES 295)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hwrJw6/0/scan-18.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-hwrJw6/0/scan-18.lisp"
   :SHA256 "4f94858b6d4b25cbd3817647e0fdea4e519a3abedf947f6bfaaca1f38a969514"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hwrJw6/0/scan-18.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-hwrJw6/0/scan-18.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hwrJw6/0/scan-18.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-hwrJw6/0/scan-18.stdout.log"
   :SHA256 "5748c03c6a3ad1f0d36a0fea9085dc7723b4259a98b5d0ba5bc695c2649444f9"
   :BYTES 4092)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hwrJw6/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-hwrJw6/0/session.pid"
   :SHA256 "511fe3111532e1e1c4bbdd5027307cf5a2f9781c53c83448f8af3142012f85ae"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hwrJw6/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-hwrJw6/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hwrJw6/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-hwrJw6/0/stdout.lisp"
   :SHA256 "00f1068bc5d7bbbf1dab4274d2a9d73a1910cb72be76b0dbcaf10c84b659678c"
   :BYTES 474)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jLqtMb/0/scan-19.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-jLqtMb/0/scan-19.lisp"
   :SHA256 "b4a94291c5c3b9f7c1138ce28990798e834bfe7822757c00de5025317933a3c0"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jLqtMb/0/scan-19.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-jLqtMb/0/scan-19.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jLqtMb/0/scan-19.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-jLqtMb/0/scan-19.stdout.log"
   :SHA256 "cc55c0685f48eb3c0e8235bcf3cdc58845745d876c77a576b73fbd1abe374e0b"
   :BYTES 4074)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jLqtMb/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-jLqtMb/0/session.pid"
   :SHA256 "aaf263b057a72ff74bca3432f4cb645d08cfd31a6199998eabf371cfd4232871"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jLqtMb/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-jLqtMb/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-jLqtMb/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-jLqtMb/0/stdout.lisp"
   :SHA256 "e94f32932f8fbbf8cfdec2a51828668d0f8eccb87788c985621299eeeb3625f5"
   :BYTES 697)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-o65tJZ/0/scan-25.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-o65tJZ/0/scan-25.lisp"
   :SHA256 "442baa346b0a6baec1ef26ed49210d766319cc70ebb2031903e07b6d21ba2cd1"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-o65tJZ/0/scan-25.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-o65tJZ/0/scan-25.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-o65tJZ/0/scan-25.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-o65tJZ/0/scan-25.stdout.log"
   :SHA256 "69a38807d52aab7504bc098f150b9cb9a7835fa4bdcc643f4c7a8996e8b3f4b2"
   :BYTES 4032)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-o65tJZ/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-o65tJZ/0/session.pid"
   :SHA256 "6e307a4591838ae58db9744011bf14dccbb06a62c8baade52fea279877ed617c"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-o65tJZ/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-o65tJZ/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-o65tJZ/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-o65tJZ/0/stdout.lisp"
   :SHA256 "1b341e57b112b83b50b040e34d77c67d97db5c0374b0423ff51518a613586631"
   :BYTES 563)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uIJFAE/0/scan-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uIJFAE/0/scan-11.lisp"
   :SHA256 "e55322233fce36921489cd6dacfe2bc1a580c6d667821c764e1daf95c12196df"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uIJFAE/0/scan-11.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uIJFAE/0/scan-11.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uIJFAE/0/scan-11.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uIJFAE/0/scan-11.stdout.log"
   :SHA256 "caef80e9045fc366d7e62d19baeeeb52daf3ff10ba2237f34f5b427f3d49113c"
   :BYTES 4050)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uIJFAE/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uIJFAE/0/session.pid"
   :SHA256 "5bb97bce8af0a283319392a8f7ca4452c4d1544b6ede1e05aefefae4dfde500f"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uIJFAE/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uIJFAE/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uIJFAE/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uIJFAE/0/stdout.lisp"
   :SHA256 "43ada90c7c94646fc0350ac8dbe30f4ec6af342952fa0e125e1b4ae442492956"
   :BYTES 296)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/0/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/0/scan-1.lisp"
   :SHA256 "14776979b2c16234e9c3f229eea6a9c1fcc9da6bd2480df833aaee52c6cfdb65"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/0/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/0/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/0/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/0/scan-1.stdout.log"
   :SHA256 "0ee6aab5478a591630fbc871f01c11a52c01d4f3d6131a8c606008f6d8e8edfd"
   :BYTES 4092)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/0/session.pid"
   :SHA256 "82fa9c7414c89a524252dfdd1305d444fc31a84cf0509035b6335410a4e659b6"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/0/stdout.lisp"
   :SHA256 "5308987d0ed5e6648b0caa49a3ad2045710b8e4c689ce969eb22165fc1ee7a1b"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/1/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/1/scan-2.lisp"
   :SHA256 "7f1e912a4423b66edb3b5953ccad0f95cfa12bb6ea1b6c34e249adb95014b96a"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/1/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/1/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/1/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/1/scan-2.stdout.log"
   :SHA256 "d55944a8cafedf10e5ebf08f4e935ef224da5aeca54803715dbdee38f9235152"
   :BYTES 4092)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/1/session.pid"
   :SHA256 "31a6c4646fae0bb27154f7c5e9c3e6f5475384549457aa5cea04a5ad629dbf76"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/1/stdout.lisp"
   :SHA256 "9a8de273c4febecded1b2263c9f9efb3d4fde9798de26aa6cb3e1e9286b4dcfd"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/2/scan-3.lisp"
   :SHA256 "478e93a30373831cef9d553cabdc40dfba195e1926db7606fc60b29c60cf8977"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/2/scan-3.stdout.log"
   :SHA256 "6dfb4743e679c85884d15c9fa320f1e4505ad55c85c51588c1852d980182f0f8"
   :BYTES 4098)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/2/session.pid"
   :SHA256 "572ac5d2fac213015e8174513f625e9008d7f993afefd5e2f75ee8912379e1e4"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/2/stdout.lisp"
   :SHA256 "4c4be637a738f2b2f2ea8acb4ce4b9efbb4f426d7af766561f7af7e600c11f4c"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/3/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/3/scan-4.lisp"
   :SHA256 "70433b2419f15c9b40d4a8b9e88e84cd56518571ed5de967e00359afbe27e142"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/3/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/3/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/3/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/3/scan-4.stdout.log"
   :SHA256 "762e0dd8fbb8d9c44a799ff8ea08da271cde173239dcefc90a1b86f43de26496"
   :BYTES 4092)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/3/session.pid"
   :SHA256 "c7d0666af609d41bdd676eb69bef27ddd5fde02ef9df9c198d05a3a39da60e88"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-uLV1Zx/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/support/evidence-check-uLV1Zx/3/stdout.lisp"
   :SHA256 "c13c0ae8a9bc375bac89fae252a045ce64e57940926af4060389f304fc0a091b"
   :BYTES 280))
 :LIMITS (:NEGATIVE-NESTED-SELF-TEST-FIXTURES-EXCLUDED))
