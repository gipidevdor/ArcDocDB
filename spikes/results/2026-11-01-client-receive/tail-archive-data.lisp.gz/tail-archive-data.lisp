(:KIND :RECEIVE-TAIL-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "receive-close" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-final-archive" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-identity-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "receive-closing-archive" :STATUS :OK :SOURCE-CONSISTENCY :STABLE))
 :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-close/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-close/conservazione.lisp"
   :SHA256 "c3758422da9ba6ce67275e6a46aaccd239cb01ea07661b8f567a5388151bb25c"
   :BYTES 1156)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-close/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-close/report.lisp"
   :SHA256 "96e953e4342632b8f3eb095d74cdd68bad336ff4926b0708b3bca9ddf4ea4c33"
   :BYTES 363517)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-final-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-archive/conservazione.lisp"
   :SHA256 "33d02bc6baabe0c48cf0c6af2280561925591cd049d776758cb6345628967906"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-final-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-final-archive/report.lisp"
   :SHA256 "d313bd8db8754c79277340b2b03c6276d25f272a4031bd41774ba28eefa2ee4c"
   :BYTES 362845)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-identity-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-identity-final/conservazione.lisp"
   :SHA256 "5e9a82c819fdb6c1a1f6f1425831e11ccd7e8cb3eca0623465cac01e66531db6"
   :BYTES 1176)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-identity-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-identity-final/report.lisp"
   :SHA256 "32e56e9030d78710c37548f91293941317d8a12eeab274f6de823784b7595798"
   :BYTES 362830)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-closing-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-closing-archive/conservazione.lisp"
   :SHA256 "686dde288457e9e5d8358f8d21eb50766fb3c126f940468887ccf5b0b02048b0"
   :BYTES 1178)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/receive-closing-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-closing-archive/report.lisp"
   :SHA256 "e1086497e76cdc693daee30eb17db3a0cdc6cc498643aaf1231c2d00f3ec8a8a"
   :BYTES 362828))
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-receive/commands/receive-closing-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362828 :STORED-BYTES 116466 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362828 :UNCOMPRESSED-SHA256
    "e1086497e76cdc693daee30eb17db3a0cdc6cc498643aaf1231c2d00f3ec8a8a"
    :COMPRESSED-BYTES 116150 :COMPRESSED-SHA256
    "fb010be8c9a3238001362aa4e5794c2a6c42b594ae9165fce5519d81a53166a5")))
 :DRIVER-SHA256
 "0e0cd9585fdbb83253ce38c8eb4538615d8ec0a45fcfd3adf5ad1134b063c1d4")
