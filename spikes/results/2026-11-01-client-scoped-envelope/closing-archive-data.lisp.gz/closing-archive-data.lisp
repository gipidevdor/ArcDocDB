(:KIND :SCOPED-ENVELOPE-TAIL-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "scoped-envelope-close" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-final-archive" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-identity-final" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE))
 :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-close/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-close/conservazione.lisp"
   :SHA256 "456a539f45ba845d7f04ca77befd2d1c872c2ca7c4a63bfb4cd1c2c00a1c8fcf"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-close/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-close/report.lisp"
   :SHA256 "b9c108b259c27d5ffc4e2c325152f13fcb9c39ec8c9425ec55a9e7cab51fdd40"
   :BYTES 364577)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-final-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-final-archive/conservazione.lisp"
   :SHA256 "a95b19facb4da9574b240a63eddaa3a23c74b798eb2f1ed3aa8dc53fd86101e7"
   :BYTES 1190)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-final-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-final-archive/report.lisp"
   :SHA256 "5d13c51fac6b13b9cabe82eb73b4dcefae51af0ef92d2941d4a4cf6bea6416b5"
   :BYTES 363889)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-identity-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-identity-final/conservazione.lisp"
   :SHA256 "97a7dcc886354e774a24399b8eaf32b8581fd62b42261620f90181b38c1dabc7"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-identity-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-identity-final/report.lisp"
   :SHA256 "ae8a196dfb7369a27da7e0fe729e388b011b4f9fd9144f070b56227d35e9a309"
   :BYTES 363875))
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-identity-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363875 :STORED-BYTES 116781 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363875 :UNCOMPRESSED-SHA256
    "ae8a196dfb7369a27da7e0fe729e388b011b4f9fd9144f070b56227d35e9a309"
    :COMPRESSED-BYTES 116465 :COMPRESSED-SHA256
    "d971273daeba9690ed0577af27d3e23e97b12b897fcdf8297422308f77de98ac"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-final-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363889 :STORED-BYTES 116770 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363889 :UNCOMPRESSED-SHA256
    "5d13c51fac6b13b9cabe82eb73b4dcefae51af0ef92d2941d4a4cf6bea6416b5"
    :COMPRESSED-BYTES 116454 :COMPRESSED-SHA256
    "48922e6be8312b22a45bd29a98cf65e7f5d6b5c0ddc7d125f05f4af605a0632b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-close/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 364577 :STORED-BYTES 117158 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 364577 :UNCOMPRESSED-SHA256
    "b9c108b259c27d5ffc4e2c325152f13fcb9c39ec8c9425ec55a9e7cab51fdd40"
    :COMPRESSED-BYTES 116842 :COMPRESSED-SHA256
    "cbc1f57f7a6276026764660d0477e106be4150ac7c844c4fa6bd58563849d97a")))
 :DRIVER-SHA256
 "cd1f0204c426fb141bd177a0fb75f3f66ec038df5f76fb3bdbd8c6df9f0ca32c")
