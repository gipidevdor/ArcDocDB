(:KIND :SCOPED-ENVELOPE-COMMAND-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "4002565740-command-81365-0" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "4002567031-command-12540-0" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-analysis-self-test" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-archive-self-test" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-baseline" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-baseline-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-checks" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-cleanup-self-test" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-close-self-test" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-codec" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-codec-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-diagnostic" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-documentation" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-focused-02" :STATUS :FAILED :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-focused-03" :STATUS :FAILED :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-focused-04" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-focused-final" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-focused-final-02" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-focused-initial" :STATUS :FAILED :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-focused-inline" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-freeze-uninlined" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-identity-self-test" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-identity-self-test-02" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-identity-self-test-03" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-mock" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-mock-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-paired" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-paired-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-paired-final" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-paired-final-analysis" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-poll-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-poll-probe" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-probe-2.6.10-02" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-probe-2.6.9" :STATUS :FAILED :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-probe-2.6.9-02" :STATUS :FAILED :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-probe-2.6.9-03" :STATUS :FAILED :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-probe-2.6.9-04" :STATUS :FAILED :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-probe-2.6.9-05" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-product-diagnostic" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-qualification-2.6.10" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-qualification-2.6.9" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-qualification-final-2.6.10" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-qualification-final-2.6.9" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-runtime-path-reproduction" :STATUS :FAILED
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-smoke-before" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "scoped-envelope-smoke-before-analysis" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-smoke-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "scoped-envelope-smoke-final-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE))
 :FAILED-FIXTURE-ROOTS NIL :SPECIAL-NODES NIL :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793578231-12539/workflow.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/ci/selftest-1793578231-12539/workflow.lisp"
   :SHA256 "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"
   :BYTES 27784)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793578231-12539/tests.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/ci/selftest-1793578231-12539/tests.lisp"
   :SHA256 "72d8ca8f69a6df2de0109bffa94908d4d6e32d4b899bad224a91d9e25814a51c"
   :BYTES 2463)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793578231-12539/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/ci/selftest-1793578231-12539/report.lisp"
   :SHA256 "1ae97ae4103f11530749a8627e2ba2cc908579dc933ba091a1eafd94a48a5125"
   :BYTES 632)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793578231-12539/publication.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/ci/selftest-1793578231-12539/publication.lisp"
   :SHA256 "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc"
   :BYTES 1181)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793578231-12539/measure.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/ci/selftest-1793578231-12539/measure.lisp"
   :SHA256 "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c"
   :BYTES 2041)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793578231-12539/data.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/ci/selftest-1793578231-12539/data.lisp"
   :SHA256 "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2"
   :BYTES 3214)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793578231-12539/conditions.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/ci/selftest-1793578231-12539/conditions.lisp"
   :SHA256 "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f"
   :BYTES 663)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793578231-12539/boundaries.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/ci/selftest-1793578231-12539/boundaries.lisp"
   :SHA256 "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23"
   :BYTES 976)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/command-archive-collector-self-test-BnTA12/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/command-archive-collector-self-test-BnTA12/self-test-report.lisp"
   :SHA256 "3975283ee99003a6b41c9dcf6668b68083a2d58479d1dd5c2163a0aeb934d471"
   :BYTES 28790)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566726-command-4648-0/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566726-command-4648-0/self-test-report.lisp"
   :SHA256 "7e47f646dc8ee821fcd8e3536a898b414e928bb78b4cbfd416d95f7b431a963b"
   :BYTES 157)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002565740-command-81365-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/4002565740-command-81365-0/conservazione.lisp"
   :SHA256 "648c4445bca9ddc0e15abfcea5e8cb57b941e929aaba7c3ddc8f6692fd637cf0"
   :BYTES 1775)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002565740-command-81365-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/4002565740-command-81365-0/report.lisp"
   :SHA256 "ebdd3d774a7caf66c221561e7303bb1dbd9ba5da1ad3b00ee58999e0b7ad0544"
   :BYTES 317)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002565740-command-81365-0/report.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/4002565740-command-81365-0/report.lisp.gz"
   :SHA256 "70060080718cf2b6b9fd3cb16b24b6e93e142ceac1bf4b0146c8211578bd98ce"
   :BYTES 397558)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002567031-command-12540-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/4002567031-command-12540-0/conservazione.lisp"
   :SHA256 "3474b9766a93666075764b5f5a782bfb663ebb952a86abab87b98056117ce54e"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002567031-command-12540-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/4002567031-command-12540-0/report.lisp"
   :SHA256 "c60b079b2b2b2542896181d369dc3c0e8237a25ee74f5b5beb89c9220a5ddae6"
   :BYTES 364500)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-analysis-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-analysis-self-test/conservazione.lisp"
   :SHA256 "4d00789eceeca0ba328b6d6882f782741f8248fcfb6080c75fd1f6b6fb45574c"
   :BYTES 1200)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-analysis-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-analysis-self-test/report.lisp"
   :SHA256 "cdc3daa6cd94f30a181c7c3d4bd1e10c9224d9a8b72aa4cd957f35c677dc17fd"
   :BYTES 363131)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-archive-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-archive-self-test/conservazione.lisp"
   :SHA256 "31d06c3a42527622a66fbabdfdb5cebd425139a48e9ab8ade31c335f891ba6f4"
   :BYTES 1198)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-archive-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-archive-self-test/report.lisp"
   :SHA256 "83f5a4d896e8162cc8647426efa94d1916ff65249a08ca73f3b8b3c3b302f90e"
   :BYTES 363869)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-baseline-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-baseline-analysis/conservazione.lisp"
   :SHA256 "7f36e8063c9d895cd04afacf4b59cf0976af7c3f3cbced8ca10d31e2097a958a"
   :BYTES 1198)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-baseline-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-baseline-analysis/report.lisp"
   :SHA256 "ae5ee2a4ee3ed25eeeb015e7b8efee8390a7eaf96ce20b62258a6c3efd6cfd94"
   :BYTES 365334)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-baseline/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-baseline/conservazione.lisp"
   :SHA256 "caab0c4b597f50106a13cd68546c2f68529709d4fae1c8a38f8253fa15800da1"
   :BYTES 1180)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-baseline/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-baseline/report.lisp"
   :SHA256 "b665245590b0e6efa8b9519be0a6b0dc3c0522958c23fa87c3e6418e0fed934e"
   :BYTES 382200)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-checks/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-checks/conservazione.lisp"
   :SHA256 "64e02a8ad3a81580bcf95ea0d55dcff58fb60ab2d29b378a5e47303f3659f54c"
   :BYTES 1176)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-checks/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-checks/report.lisp"
   :SHA256 "08a4b1d4e7730bdc12bf11eae81f928e51e3c3c1eaee12d96fe304606f524b72"
   :BYTES 363951)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-cleanup-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-cleanup-self-test/conservazione.lisp"
   :SHA256 "5b6cb99886807c182f3c09f98a78ef1d94e90c63b58e66405a66b669a5ae5182"
   :BYTES 1198)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-cleanup-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-cleanup-self-test/report.lisp"
   :SHA256 "038c3d7aad2cf10dfba737db07622a5b63e59711a1a08435447a56d1b5681318"
   :BYTES 363900)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-close-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-close-self-test/conservazione.lisp"
   :SHA256 "0b84aa3bd6535a85a3303c1f35e09fc95f54cb029580b6cfe8ea17566fc9325e"
   :BYTES 1194)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-close-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-close-self-test/report.lisp"
   :SHA256 "d16ebe254a75c9e6141dca80132f39ae326bf02f90b7350a2c602ec1900499d0"
   :BYTES 363856)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-codec-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-codec-final/conservazione.lisp"
   :SHA256 "b5e655beabf4721f38203c80e799c377f1bfec85299b74cf64baa4050f8dbbcc"
   :BYTES 1186)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-codec-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-codec-final/report.lisp"
   :SHA256 "114f01e6fe546e048926bb4569d57a9c0a61d04d37fd08e300f05a777661e33d"
   :BYTES 372925)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-codec/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-codec/conservazione.lisp"
   :SHA256 "8f9bcb16fc03429af5f9125eaa730d9b39ab2bbe8a5b1b5dc7f49c8d6c14c696"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-codec/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-codec/report.lisp"
   :SHA256 "062e11ae4fc10558cd61f8cd59e647ab92ec00cc1f79b5e75435bebb6dea3ebd"
   :BYTES 372911)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-diagnostic/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-diagnostic/conservazione.lisp"
   :SHA256 "0bc1a736841c43d8e2bc66d4629d23d016bc024deb908935858727e4f7cb4d83"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-diagnostic/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-diagnostic/report.lisp"
   :SHA256 "102f417b5ad63f311a5da3b2c6c7663fd497d0da54de09596c7ba031d086998f"
   :BYTES 383500)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-documentation/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-documentation/conservazione.lisp"
   :SHA256 "9f503c04982207ae363b961151da7a3b0e73d5c9055bb9e22b2f3512b27f071d"
   :BYTES 1190)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-documentation/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-documentation/report.lisp"
   :SHA256 "56532e19e0ea5c5ce0f8844f36e9a2209e9d24be9c3ea845cb4ccf17f9966d6c"
   :BYTES 369970)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-02/conservazione.lisp"
   :SHA256 "45888152d0b807c0f17beeec4f4584fa062a6203e37462bcaee5701495416d21"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-02/report.lisp"
   :SHA256 "28460f81bc4af332f66523d776f10874c154391f38ca99ec7168c713e4d6a0ef"
   :BYTES 371547)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-03/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-03/conservazione.lisp"
   :SHA256 "f95330e846f35cef3dafc923d3bc6009cb4801e222cbf7c54983428174091ce3"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-03/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-03/report.lisp"
   :SHA256 "00e7b2a0a80b1013a8268783ced553133020233bee984b3dbb10378c56074152"
   :BYTES 371545)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-04/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-04/conservazione.lisp"
   :SHA256 "14c3ed0c0b7080dd0d85d9738972f50bf8eccefc83a16600cc1754ae4aafa084"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-04/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-04/report.lisp"
   :SHA256 "6c6002bac362149f60152f35c06b3da2bdb69db85ce324ef72280723fc547d05"
   :BYTES 363686)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-final-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-final-02/conservazione.lisp"
   :SHA256 "c93b64f078cec8f1e45b0d1062a2242d824b9cd264263fd80b126816acecfa5e"
   :BYTES 1196)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-final-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-final-02/report.lisp"
   :SHA256 "86a0d173dd629e2dbbde72c4571d966c476b228029c2122f888866907eecf93e"
   :BYTES 363805)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-final/conservazione.lisp"
   :SHA256 "7b80c96b1e97a419111ccd1c21bd9681e1143fc741857108b42d10c71a3cdba2"
   :BYTES 1190)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-final/report.lisp"
   :SHA256 "6b1048a78b579906408fc9a8dedfaee3dcc726d3cdc60aa0f78a7982827ae5ff"
   :BYTES 363752)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-initial/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-initial/conservazione.lisp"
   :SHA256 "63ed2f929d7cc96307d6a713bad530794a8fe1398758f18c37d1572cc28b35be"
   :BYTES 1194)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-initial/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-initial/report.lisp"
   :SHA256 "9085756936c01030e8096007532d0e0bfa13ad1263a45fa378d78f9a1d522886"
   :BYTES 390242)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-inline/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-inline/conservazione.lisp"
   :SHA256 "48d9b4196f267aff78bab19d91c8da3dcc800317ff87110f831f819b933f867e"
   :BYTES 1191)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-focused-inline/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-focused-inline/report.lisp"
   :SHA256 "d526f272d11d756873dfd57ba678f46b98bb00ea1c819037846052eb60759682"
   :BYTES 363753)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-freeze-uninlined/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-freeze-uninlined/conservazione.lisp"
   :SHA256 "3ee304b5dfb492de82248118ba65812332428f10fbf730433b12d9b19f935581"
   :BYTES 1195)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-freeze-uninlined/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-freeze-uninlined/report.lisp"
   :SHA256 "142d95d53fddbcd9df012ba1c201436b1d6afd7dc7dc15ca9d2a02dcbdc9ab63"
   :BYTES 363783)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-identity-self-test-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-identity-self-test-02/conservazione.lisp"
   :SHA256 "5622685915e2b7b0a26c46688f58ffbdb1d48a0e37a52a1c8d6b503ce617b192"
   :BYTES 1206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-identity-self-test-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-identity-self-test-02/report.lisp"
   :SHA256 "46c2a75cbdca71b64e6d92c1beb6b4d9168bd26d1cf7c56ce9d377b679fcfbe0"
   :BYTES 363881)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-identity-self-test-03/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-identity-self-test-03/conservazione.lisp"
   :SHA256 "282904aacc1c5fcb3b245a2302073b97225fd16088b8bacd561c17a0e1e1c3cf"
   :BYTES 1206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-identity-self-test-03/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-identity-self-test-03/report.lisp"
   :SHA256 "6fa47e902d28ccee46ddc93dc6e32c1a7cf0be6f03ae5efa98a98b217d7bdda9"
   :BYTES 363881)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-identity-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-identity-self-test/conservazione.lisp"
   :SHA256 "398420cfc6b6cda3db5e7d24ba17ea064807a6084e45600b0ef6dc6652178d10"
   :BYTES 1200)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-identity-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-identity-self-test/report.lisp"
   :SHA256 "15a1e0ad1d6f4e7315827f5b69b7d9ea7784ebc64df713426607f790c73cbcde"
   :BYTES 363881)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-mock-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-mock-final/conservazione.lisp"
   :SHA256 "766738a98672b5b3d31170a2db968e57746d53854a6ef2aa26261fb5b5b43f6b"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-mock-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-mock-final/report.lisp"
   :SHA256 "ff9a1a9e3e4d57d2fcf33841c7e55e47bc1cd247aed9b0cf9a4e4fe38dab185c"
   :BYTES 364096)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-mock/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-mock/conservazione.lisp"
   :SHA256 "544f41aa0f7c681d033646daee8c45d69e74418b99b0c3bf1f51cea150d6e374"
   :BYTES 1172)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-mock/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-mock/report.lisp"
   :SHA256 "1e06754e62c663ba1d8ae63d0dbd53a3c8f2ee74ab1317b84446826552362c9a"
   :BYTES 364044)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-paired-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-paired-analysis/conservazione.lisp"
   :SHA256 "946e76ad721c041c37620ed5cd82f7e78d5344994af79506bedc96cc3358ee02"
   :BYTES 1194)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-paired-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-paired-analysis/report.lisp"
   :SHA256 "bc82d48117a770b3239db7a7bcf9f2f97aa43d48664c38827a9ef76ba0e69576"
   :BYTES 365962)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-paired-final-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-paired-final-analysis/conservazione.lisp"
   :SHA256 "3c079301fe04046defc4c81bbfcc7b65df58c5507a363f291f7fab3f7362831a"
   :BYTES 1206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-paired-final-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-paired-final-analysis/report.lisp"
   :SHA256 "8b19c1bf48085b21c02cc9875396a6468e51b4915e641bfe4e8f0fe4ff318388"
   :BYTES 365967)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-paired-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-paired-final/conservazione.lisp"
   :SHA256 "42326733ffa265f26167a074797a4f81048e3d1afd9353ed4650f77f52b24819"
   :BYTES 1188)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-paired-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-paired-final/report.lisp"
   :SHA256 "ec55c33b96913a9a5a452dedf231c0d082d76743f4daafeeedcad273d0abd7c7"
   :BYTES 382943)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-paired/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-paired/conservazione.lisp"
   :SHA256 "616257054698244153ac898c0d56099524243ae5eab1aa7bf0e0484c5ad3abb4"
   :BYTES 1176)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-paired/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-paired/report.lisp"
   :SHA256 "d0131a7eb1359e386b17599d0e9a63888302420e1c7c302dd41eb599e921786e"
   :BYTES 382806)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-poll-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-poll-final/conservazione.lisp"
   :SHA256 "f44a25a56f76664a155e24a6660cef05f358c3a4645c9832cab1b82ed9e2e2f2"
   :BYTES 1183)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-poll-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-poll-final/report.lisp"
   :SHA256 "dcd92ccba485a7d2bb616a5c5502b7d4630cd12db014f2ba76f22e5288207559"
   :BYTES 364310)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-poll-probe/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-poll-probe/conservazione.lisp"
   :SHA256 "de90a15b89bfa78dfdfa72a0907baea4e8c27180760ed3d2b72f6f8ae551dc73"
   :BYTES 1182)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-poll-probe/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-poll-probe/report.lisp"
   :SHA256 "196fe2ece6f4c9369a0b286632cd844932e5996dbb978e5537d615a16b0ef444"
   :BYTES 364258)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-probe-2.6.10-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-probe-2.6.10-02/conservazione.lisp"
   :SHA256 "886c143b58f39f5cc57dfd5bc596f5cf9d4e4f49ba8ac4f32bc05cf472fc8b0a"
   :BYTES 1194)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-probe-2.6.10-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-probe-2.6.10-02/report.lisp"
   :SHA256 "f9de2a99bc4546c576408d0f3821674e99c0c969f13a2f94c29df516c6267a45"
   :BYTES 363338)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-probe-2.6.9-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-probe-2.6.9-02/conservazione.lisp"
   :SHA256 "3ea8575e072d8c0e8ee866dcc9d716c9894137718824e5ebf03a74ab068c3bf5"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-probe-2.6.9-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-probe-2.6.9-02/report.lisp"
   :SHA256 "c7811f57d94d18824f06336e0087d902825a804724afec182ba2810f2444909d"
   :BYTES 371684)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-probe-2.6.9-03/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-probe-2.6.9-03/conservazione.lisp"
   :SHA256 "f84b76a0daf30c6debaa215bb2f8f467a08be02b8780f30cdb0a0e77aeece86d"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-probe-2.6.9-03/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-probe-2.6.9-03/report.lisp"
   :SHA256 "dcc03181bef5065be507ddfe4069b5a765f151b44be44e77b2a5e586dd7e18c2"
   :BYTES 371946)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-probe-2.6.9-04/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-probe-2.6.9-04/conservazione.lisp"
   :SHA256 "a0f673ec9a352f8abed5d21798a8919d7e43dd6e170eaac9723150592b151dd2"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-probe-2.6.9-04/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-probe-2.6.9-04/report.lisp"
   :SHA256 "7df3d79142cc5e74b127d4fa80bca735a4f745d3a595c4ae39cd2877a0c44781"
   :BYTES 371946)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-probe-2.6.9-05/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-probe-2.6.9-05/conservazione.lisp"
   :SHA256 "895f5f4257d5c1548ea49e4aef47033a04ee5772e832d8009dbfc7bfd1b71a63"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-probe-2.6.9-05/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-probe-2.6.9-05/report.lisp"
   :SHA256 "7db3c64ceb9116bd0650423a5d03956982995e9b09c35daa1ef11c6521d49880"
   :BYTES 363311)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-probe-2.6.9/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-probe-2.6.9/conservazione.lisp"
   :SHA256 "cfcf420e3502ad6b138b5fc475db9930de26cda3788a6257f1ceef3038162004"
   :BYTES 1186)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-probe-2.6.9/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-probe-2.6.9/report.lisp"
   :SHA256 "afea47ff0712b01b3a21fff35fb9c2cdd68d51096dc6c4ce66ba45583b1ad8a3"
   :BYTES 374380)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-product-diagnostic/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-product-diagnostic/conservazione.lisp"
   :SHA256 "6d54a31135d6002bf247ff84133e7c2edab777aac113c44f517860066a7c44c4"
   :BYTES 1200)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-product-diagnostic/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-product-diagnostic/report.lisp"
   :SHA256 "447ff9c1725c9d98363a15b46fa50ef085e1c6fb0ca736d59a1a7e4b870a61c9"
   :BYTES 398319)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-qualification-2.6.10/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-qualification-2.6.10/conservazione.lisp"
   :SHA256 "ce2b6aa022904eba33508f3e10733a166698bcabc77cf893f8aebbc8dcc9f55f"
   :BYTES 1204)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-qualification-2.6.10/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-qualification-2.6.10/report.lisp"
   :SHA256 "4e1a4c78103df0d00fc2afa817477002e8db9ccd18c73934f639bc17b6cfc183"
   :BYTES 613766)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-qualification-2.6.9/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-qualification-2.6.9/conservazione.lisp"
   :SHA256 "4a68d454d77cf6274705c35ca877883db77cc34654c562620d5ecdb48a00940b"
   :BYTES 1202)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-qualification-2.6.9/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-qualification-2.6.9/report.lisp"
   :SHA256 "07d9c9a130e75559d67ebabb400237f9b6f6e9b847f9f6ecac83fc166648e5ff"
   :BYTES 613731)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-qualification-final-2.6.10/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-qualification-final-2.6.10/conservazione.lisp"
   :SHA256 "91b2248e7f4fe8828bd1c2032dc5c2c461230dabc6944ccce05d4eab63eda1fb"
   :BYTES 1216)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-qualification-final-2.6.10/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-qualification-final-2.6.10/report.lisp"
   :SHA256 "f8f7abf39e4b9ace14f893c14c41de3a901d74bdf32cc8dc6571e0904e6208c3"
   :BYTES 624584)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-qualification-final-2.6.9/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-qualification-final-2.6.9/conservazione.lisp"
   :SHA256 "e454df4751fbc1cfcec84863d5fbd2f68461bb509ffdc50ccdc8f120f85d78f9"
   :BYTES 1213)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-qualification-final-2.6.9/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-qualification-final-2.6.9/report.lisp"
   :SHA256 "9a91ef42d24c6512a7b93d1162fea989980a53b887944fb6ea910e2ed6dcd23e"
   :BYTES 624544)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-runtime-path-reproduction/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-runtime-path-reproduction/conservazione.lisp"
   :SHA256 "252980989191440b2940b5df8d571bb41442c9cb2b3b50b3e529d41db67682b2"
   :BYTES 1214)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-runtime-path-reproduction/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-runtime-path-reproduction/report.lisp"
   :SHA256 "1541e9f02bc2bbec47e6d06ca7a61c5d1d281f123b756eee14735d616bc7a00b"
   :BYTES 363770)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-smoke-before-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-smoke-before-analysis/conservazione.lisp"
   :SHA256 "ad1e6c1e91396d835688144982540903610184baada54969c6c694adb8d7e906"
   :BYTES 1206)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-smoke-before-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-smoke-before-analysis/report.lisp"
   :SHA256 "c328f1b5ecd3e2578fad276e5141302eeb7e2652461a09a293dc69c33f3cdcf7"
   :BYTES 363293)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-smoke-before/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-smoke-before/conservazione.lisp"
   :SHA256 "7e6bbf314c0e0db2e7875c0ec60e7c833b9cfdbb76698b1dea8298db8d3db015"
   :BYTES 1188)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-smoke-before/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-smoke-before/report.lisp"
   :SHA256 "6b18ff99e5c228bbe3c9ce178cd72ac231d7afba42a4e5ac8506d360338880e0"
   :BYTES 365809)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-smoke-final-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-smoke-final-analysis/conservazione.lisp"
   :SHA256 "a16f72b24b25925abca13c7bf0274fd0dbee5330b591212061309a8c21cec48c"
   :BYTES 1204)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-smoke-final-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-smoke-final-analysis/report.lisp"
   :SHA256 "8dc84a5a48315a695f6b73bd4c1601471d4e878809e56591a031927c26f4d6b1"
   :BYTES 364003)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-smoke-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-smoke-final/conservazione.lisp"
   :SHA256 "e236a05246774250b322ecef29e9d8257d9019b8fec76df94c02073d30cb4221"
   :BYTES 1186)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/scoped-envelope-smoke-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/commands/scoped-envelope-smoke-final/report.lisp"
   :SHA256 "a97305203f99458294309e13d902dad395a31c7528191f6ea88ba8cd4bd906e8"
   :BYTES 366475)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/SPK-01.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/SPK-01.lisp"
   :SHA256 "ae3b42c66c561328777e2768be2298ed903405550fea6a2e3ae036ac8c4d3d74"
   :BYTES 27228)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/SPK-02.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/SPK-02.lisp"
   :SHA256 "27835f0bae190fe3e2f9c16b27d8c701e4740a55d0e18f0821aa5f2d25f8c7e9"
   :BYTES 1607)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/SPK-03.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/SPK-03.lisp"
   :SHA256 "e360c8a5603d4bcc7a2e8dee901f3953026e947605eb2707fd045b2ee33adc35"
   :BYTES 3664)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/SPK-04.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/SPK-04.lisp"
   :SHA256 "83120b90aabd0c6cb5a5f185a1e7fb791d9f4761a1f6161a3d7f6a8d333e7967"
   :BYTES 6752)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/SPK-05.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/SPK-05.lisp"
   :SHA256 "15e904b3398263cb51d873dcccea48afc4eda2d84bf4c798e056caea0d07a106"
   :BYTES 10138)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/SPK-06.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/SPK-06.lisp"
   :SHA256 "b3055637e2e077b4061237d0cd68c29d2e3749d8bce13db3b28dc66d094eaa4a"
   :BYTES 24118)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/SPK-07.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/SPK-07.lisp"
   :SHA256 "32d621d4796e86dab1e555802cd0af82613e3e6263e344c582e74b74b2cc182f"
   :BYTES 318)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/SPK-07.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/SPK-07.lisp.gz"
   :SHA256 "c0ee44777bfbb5c60f7d813b925e465ee394c038618555266313ee7c678d7e1d"
   :BYTES 411733)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/SPK-08.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/SPK-08.lisp"
   :SHA256 "57aa6a15255bb43938fa2a184c9c6868930f8c72d782b674c2a5de9621cdb9c8"
   :BYTES 331092)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/SPK-09.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/SPK-09.lisp"
   :SHA256 "d5f34dd8cb9a7ecc247096d08fe1d321bdef3ee5d311ae613065edfca5a65bf6"
   :BYTES 2472)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/SPK-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/SPK-10.lisp"
   :SHA256 "2a3035b33fc8ab55419879b809ccda8c323277cc96a0fb16811a3ccd470729ef"
   :BYTES 22977)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/SPK-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/SPK-11.lisp"
   :SHA256 "73d3c2b562506ae2b441fe14bfbe46fe580d0613e171ed33a7ced3da934c6738"
   :BYTES 74130)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/conservazione.lisp"
   :SHA256 "2ecc39bdd4d2e4551a4904eb5ba09675dae2340b4852067d2530f0b61f04d422"
   :BYTES 2352)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/report.lisp"
   :SHA256 "59aa7d8bf68e8e8f8bd19e406242314ad0ddd8dc7467becc709cc0b571a7abba"
   :BYTES 318)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002566979-check-12049-0/report.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/4002566979-check-12049-0/report.lisp.gz"
   :SHA256 "6a4deef6305dcc8d42f32accbbc4256779d841ad5171dbcbfd00b0cca9a1bca4"
   :BYTES 483864)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1OIG4H/0/scan-30.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-1OIG4H/0/scan-30.lisp"
   :SHA256 "47c734599c4f42411728ec563151ef385fd4624952bc91cae8b1ec825021e8f6"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1OIG4H/0/scan-30.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-1OIG4H/0/scan-30.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1OIG4H/0/scan-30.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-1OIG4H/0/scan-30.stdout.log"
   :SHA256 "e1e956577903e7656ea87c2ace99e7838e3263c2951db3f8e110a6c6b4b4b05c"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1OIG4H/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-1OIG4H/0/session.pid"
   :SHA256 "6c623b817cb2fec068ac487627dacae5ad07a248974a61ea64ab5c06e3e013e4"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1OIG4H/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-1OIG4H/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-1OIG4H/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-1OIG4H/0/stdout.lisp"
   :SHA256 "d5abf843469f5332f2df4096add73237439f896d14f410ab603ce35acbe550ce"
   :BYTES 927)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2gHF4R/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-2gHF4R/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2gHF4R/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-2gHF4R/0/stdout.lisp"
   :SHA256 "94a997257b236441fa7210e79745e7e57bb887104a64c069a28a537df6ce4333"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2gHF4R/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-2gHF4R/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2gHF4R/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-2gHF4R/1/stdout.lisp"
   :SHA256 "94a997257b236441fa7210e79745e7e57bb887104a64c069a28a537df6ce4333"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2gHF4R/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-2gHF4R/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2gHF4R/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-2gHF4R/2/stdout.lisp"
   :SHA256 "94a997257b236441fa7210e79745e7e57bb887104a64c069a28a537df6ce4333"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2gHF4R/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-2gHF4R/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-2gHF4R/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-2gHF4R/3/stdout.lisp"
   :SHA256 "94a997257b236441fa7210e79745e7e57bb887104a64c069a28a537df6ce4333"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/0/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/0/scan-5.lisp"
   :SHA256 "677e58aecd74c9f139a90c626e72d35184b5d693512d63aef51bf3a2a407c6ce"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/0/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/0/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/0/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/0/scan-5.stdout.log"
   :SHA256 "435ea2df49bd5c05bfdb529a66fd05613dfc23114225b3649c5dd0b999fac6c2"
   :BYTES 4638)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/0/session.pid"
   :SHA256 "3bf7e474c4ba7b4e0062bd5e413010a0c47cfe9d31b7d0db248060a0bd00d745"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/0/stdout.lisp"
   :SHA256 "5b535aae53f5f5dde642f2ff9f2609de885c61c81264c6445f181a1cf4960859"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/1/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/1/scan-6.lisp"
   :SHA256 "7230556be27fcaba19b27f294c547af13592d035dc101acf7aa316514bb4b374"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/1/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/1/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/1/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/1/scan-6.stdout.log"
   :SHA256 "232c9281c01ea85b97f870b3900e90186c1bf4dcbffc7190eb42708da778fdf7"
   :BYTES 4626)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/1/session.pid"
   :SHA256 "ee06bdc2fdb17077f88ba71bb251f154eea57615d7f6eeb97ab911b7ee644aa5"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/1/stdout.lisp"
   :SHA256 "ea2dbc5177b9a30d66760dcff058cea86decd386b43a2c8678bbe8ffb42830c6"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/2/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/2/scan-8.lisp"
   :SHA256 "698aaa92fad04b83f31681928e9948fe8dce8b122c25558d30fc2e31709287dc"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/2/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/2/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/2/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/2/scan-8.stdout.log"
   :SHA256 "f18e4153a1c5c94b6242494511921548b156f97b154a4bacc57b1b321563108d"
   :BYTES 4626)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/2/session.pid"
   :SHA256 "9880a156adc0caaad2057d3f15bdea1a50ff9ae81c059b9c3a6f08e84c2dbaed"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/2/stdout.lisp"
   :SHA256 "f29ead817fd94c165dc89605041876cb951c6ae0761c49754199d27ea0992476"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/3/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/3/scan-7.lisp"
   :SHA256 "c2b64eabe3313e07e0035332db560e2925b753a6b51a264a44ab19291501b20e"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/3/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/3/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/3/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/3/scan-7.stdout.log"
   :SHA256 "a806c2c771e278a41273cc797722399b1ad93e919215bec0ff535ade156d5b16"
   :BYTES 4626)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/3/session.pid"
   :SHA256 "4fddbe10e810d64cc3a2eaf9cc4a9125dded033bd070ac2a3d2f7f1c702d98e9"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-3OPomE/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-3OPomE/3/stdout.lisp"
   :SHA256 "9bd4d3528e73981c66df42ff7ea931d9aedca7a4a0654c65188e5ece54be899b"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/0/scan-21.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/0/scan-21.lisp"
   :SHA256 "ccdf6b1a63d664fab91a6420b3686ae2d7a07f4ad929c56c67c356239d504e2a"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/0/scan-21.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/0/scan-21.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/0/scan-21.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/0/scan-21.stdout.log"
   :SHA256 "c33e4cf3ff6c8fbcaddbf375c1149c812134fb3a5609dbb92f96f43bc27566ce"
   :BYTES 4614)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/0/session.pid"
   :SHA256 "feb21dd4c264c36bb31aeb763de232039b114296ce3e06c739a47f501de753c6"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/0/stdout.lisp"
   :SHA256 "23569680e8d1b46d2b934223ebc2c151dfdb46f6f6ac6986a6fcefc607b58e49"
   :BYTES 750)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/1/scan-22.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/1/scan-22.lisp"
   :SHA256 "f6a4bc1fae821996f84167503161d116599a2c5b7d43a5c73af65eadc1c73290"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/1/scan-22.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/1/scan-22.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/1/scan-22.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/1/scan-22.stdout.log"
   :SHA256 "58b86d2d7ccb1d91ee9fa7721e3921895ca81b73a75f19e8bc6fc13a32f4da8c"
   :BYTES 4608)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/1/session.pid"
   :SHA256 "8a462538698b7772b44c082dc85ff55fef20f4e52f2412b836b34e6937a62085"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/1/stdout.lisp"
   :SHA256 "ff32e9893afd9edc0e7d5f9ac4d62b34c657d0e51790a27f33a5ce112527a8b0"
   :BYTES 752)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/2/scan-24.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/2/scan-24.lisp"
   :SHA256 "f010db29b6615ee9b461686e271ddf8604f3be413e174e19b5dbc98c42598f50"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/2/scan-24.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/2/scan-24.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/2/scan-24.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/2/scan-24.stdout.log"
   :SHA256 "d477a95e1daf8dc12d2c3e39f24811509f0115d635fb29a27d948e9b7336e574"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/2/session.pid"
   :SHA256 "77cce635663aff4bce9135c0b45e7841eae7128141872931eab81654cdaf9826"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/2/stdout.lisp"
   :SHA256 "1fed6c34b97d4d47fca482856102f97b11e2d8175ad1e157447ba37e04ac3837"
   :BYTES 286)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/3/scan-23.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/3/scan-23.lisp"
   :SHA256 "849dc9ef0906da762c89654752739a29740cbf09253d634256392bb9aa67605b"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/3/scan-23.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/3/scan-23.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/3/scan-23.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/3/scan-23.stdout.log"
   :SHA256 "f13cbad22dad7f21856dba31bf6edd91752e51ec8f6488c63eaff6c477235143"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/3/session.pid"
   :SHA256 "15d7ccd97a5f010a51dd65a0037e2078b05893a9af68d9d6821f1068b642f90d"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-AA1wox/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-AA1wox/3/stdout.lisp"
   :SHA256 "9ab1434eb928fcbecf53b1f05eb5c1e013206ca697fd43dfdf6409b21e881f32"
   :BYTES 286)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DEImhl/0/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-DEImhl/0/scan-9.lisp"
   :SHA256 "08fe1a021c5a13f60800ea7dcd9fcc92a2b601901ceab27bd9f94346408f4e4d"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DEImhl/0/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-DEImhl/0/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DEImhl/0/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-DEImhl/0/scan-9.stdout.log"
   :SHA256 "bc2213e4b46a8c7b22fdac2a047d12e40efd30740ee4ded75eef27a93409a2b9"
   :BYTES 4620)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DEImhl/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-DEImhl/0/session.pid"
   :SHA256 "77122f772e3de5d801703818782fb17324d0b63c4213c804baaecaa7e939142e"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DEImhl/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-DEImhl/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-DEImhl/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-DEImhl/0/stdout.lisp"
   :SHA256 "5c6991819f1828d6f229209ae80da1dec43866bf0886d896da852758e5f315ca"
   :BYTES 293)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/0/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/0/scan-1.lisp"
   :SHA256 "215e82145049829be0354b78d69328f8fefd39ef42283bf18c23c08e2b383d1a"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/0/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/0/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/0/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/0/scan-1.stdout.log"
   :SHA256 "b6e99cd79e81733782a6f1cc9dd0b8ba00a5b78b9527dd0a96dcf097316f4fcd"
   :BYTES 4620)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/0/session.pid"
   :SHA256 "a6367eb58ffc8e1242696a96630b80c310ff9f1eed64194574bbef0cf6add0a0"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/0/stdout.lisp"
   :SHA256 "5b535aae53f5f5dde642f2ff9f2609de885c61c81264c6445f181a1cf4960859"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/1/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/1/scan-2.lisp"
   :SHA256 "e205d5b4cd3843e5dbf389f9fcc3ef9acc4060e45e5704bfc333f6926cbe86e3"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/1/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/1/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/1/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/1/scan-2.stdout.log"
   :SHA256 "194ca50d9ea2c192f0566f71365ddcdc076e76c501f14b0ed173defe9c02607b"
   :BYTES 4626)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/1/session.pid"
   :SHA256 "aae562eeacd25d0ec26f99883847391477ccfc541718e70f8b9b7f29163dc0e2"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/1/stdout.lisp"
   :SHA256 "ea2dbc5177b9a30d66760dcff058cea86decd386b43a2c8678bbe8ffb42830c6"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/2/scan-3.lisp"
   :SHA256 "eadcd9f1916c4c82adad963e400f4dd3e1f7270038f309a5ffb9704150ba0a30"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/2/scan-3.stdout.log"
   :SHA256 "4ba3e55ad02287240b275ff0c89bf0548e68ed4e645cc6568bb76846609f20b0"
   :BYTES 4632)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/2/session.pid"
   :SHA256 "86f30cdb5404a750394ba9163c648432c086e520716178f29cdb121ecb11d9c4"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/2/stdout.lisp"
   :SHA256 "f29ead817fd94c165dc89605041876cb951c6ae0761c49754199d27ea0992476"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/3/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/3/scan-4.lisp"
   :SHA256 "e3dc9976ee7a22777b3d6736ec623942bcecec500cafe6b9764750359977d4c5"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/3/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/3/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/3/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/3/scan-4.stdout.log"
   :SHA256 "568ccced1c9926d3804fe283a8a5b8bbcbfd87f9106bde5c805c51ab0cb7faab"
   :BYTES 4620)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/3/session.pid"
   :SHA256 "fe4e3bab9fb4bab90dd1607f94319043a1b6dbb6bdd7fe670420291b89263098"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Kj282B/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Kj282B/3/stdout.lisp"
   :SHA256 "9bd4d3528e73981c66df42ff7ea931d9aedca7a4a0654c65188e5ece54be899b"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OzwVEm/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-OzwVEm/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OzwVEm/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-OzwVEm/0/stdout.lisp"
   :SHA256 "00c6aa53ed287be729d6ac990eb0771aab1854674288bf6f27be9edb7d92dd38"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OzwVEm/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-OzwVEm/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OzwVEm/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-OzwVEm/1/stdout.lisp"
   :SHA256 "0a1ac70dde683346dc591a03bd1deaf984395c34c325f97b6ffe64f4d46ebd24"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OzwVEm/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-OzwVEm/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OzwVEm/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-OzwVEm/2/stdout.lisp"
   :SHA256 "9e23821804bbe59fcd8096a5d061f492a560ecf60b26e53ead9ec6562d20f43b"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OzwVEm/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-OzwVEm/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-OzwVEm/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-OzwVEm/3/stdout.lisp"
   :SHA256 "1629dcc4f82115b738f6d727e50c259091f7726bcd323ef0ef0977863263c4da"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/0/scan-32.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/0/scan-32.lisp"
   :SHA256 "94740a6537dda5bb2e9c39d5fcf2bcca02e8ff8146220a92146b88f5d683637d"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/0/scan-32.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/0/scan-32.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/0/scan-32.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/0/scan-32.stdout.log"
   :SHA256 "20a6b68744cbb94e9e03c4b05224cb3092d5016a870622b02cdec18d98c4dfe5"
   :BYTES 4608)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/0/session.pid"
   :SHA256 "05e2f7f4e8644d071b6b76a879551c85fd1c203539eff4587e3e134956fb253f"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/0/stdout.lisp"
   :SHA256 "8cfc0604715a04fcfa6c86d6a01c4be0e2ac55c9be9f24b753af1ceabd994a9b"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/1/scan-31.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/1/scan-31.lisp"
   :SHA256 "443ab8b0169ea3c2716cfa877a63797a446e0b9d22c366c689ee6a157cf6f5ba"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/1/scan-31.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/1/scan-31.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/1/scan-31.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/1/scan-31.stdout.log"
   :SHA256 "b46e47c13b95d8076c859e324de7db92b3496b437359c8540a8ea60878867c9b"
   :BYTES 4608)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/1/session.pid"
   :SHA256 "44b7441b2e41eba3de643c2ca9728d4fd4b0462dd9d5616829221ea0d80b7184"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/1/stdout.lisp"
   :SHA256 "d3321ba80ed49c054cf78f2dcb89b091c8c9bc52afa0fcd3d884413a218faead"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/2/scan-34.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/2/scan-34.lisp"
   :SHA256 "e4467e465b5baf58228eb20579a71a4e1b439e939f2ce7bbbb376dc047cfb245"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/2/scan-34.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/2/scan-34.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/2/scan-34.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/2/scan-34.stdout.log"
   :SHA256 "4337257db0042e14410c38f6d054b7a9067453e21452644e316cd1bcd8757fbb"
   :BYTES 4608)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/2/session.pid"
   :SHA256 "0cd6f42c45665c8fd25c6e9640ecf293ee46870f33e0e10092d54c0a8f1bcbd8"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/2/stdout.lisp"
   :SHA256 "16e4820938a525899ecccf00795329f17228068558fd24792a9ec30bebce5416"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/3/scan-33.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/3/scan-33.lisp"
   :SHA256 "94f4b940321b8dff767a3c989d784e15e286b611f2fa290de5f658c8b6166a7f"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/3/scan-33.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/3/scan-33.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/3/scan-33.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/3/scan-33.stdout.log"
   :SHA256 "5412cd793e7b1d8e7de40ce621cc1d1a8f12ba2d9155d72d4b0c949b28a9b140"
   :BYTES 4608)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/3/session.pid"
   :SHA256 "985a39682b1638477c6ca7030429ae904dc5868682d5f91dedc0758f489e15de"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-P5wBTv/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-P5wBTv/3/stdout.lisp"
   :SHA256 "8926b04cd1bf761be3725364bf27e3880f40b12d9b0e332244925f303e2dc6c2"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PYDuFt/0/scan-12.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-PYDuFt/0/scan-12.lisp"
   :SHA256 "d4dce6fa2cefbaacef40495faee9b59681ad1f361663ee8dbfdb4297cab1a4a3"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PYDuFt/0/scan-12.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-PYDuFt/0/scan-12.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PYDuFt/0/scan-12.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-PYDuFt/0/scan-12.stdout.log"
   :SHA256 "4eb40efe76c1b88dea6a2a5eff9d9cbbce65064963c201a7e759063a2b36e779"
   :BYTES 4614)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PYDuFt/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-PYDuFt/0/session.pid"
   :SHA256 "f882a763e2c79077fdc30490b34311e2c421934db41572f265db72e9ddabfb6b"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PYDuFt/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-PYDuFt/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PYDuFt/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-PYDuFt/0/stdout.lisp"
   :SHA256 "946836c6134418e7b929abeed7e3d70754c97978a60149eb571c747b68036e77"
   :BYTES 308)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Psp2ch/0/scan-39.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Psp2ch/0/scan-39.lisp"
   :SHA256 "6de76ef0000d72338281bca4d2a1aaf4db55f1daddfeca40a6169c4b8d15841c"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Psp2ch/0/scan-39.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Psp2ch/0/scan-39.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Psp2ch/0/scan-39.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Psp2ch/0/scan-39.stdout.log"
   :SHA256 "2c8dc8b2ed1085572f5865461f54a95cff74602cf13e7d9de0ca4a03f38eef17"
   :BYTES 4608)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Psp2ch/0/scan-40.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Psp2ch/0/scan-40.lisp"
   :SHA256 "dbb1cf47a756417dac405d890d4265ffac8460e7c28c580a47800a0de5658c22"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Psp2ch/0/scan-40.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Psp2ch/0/scan-40.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Psp2ch/0/scan-40.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Psp2ch/0/scan-40.stdout.log"
   :SHA256 "d7c628ef9b7290a1f0d4375411ceb8cf2f7de2bf7f055064d316392e90f1eb03"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Psp2ch/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Psp2ch/0/session.pid"
   :SHA256 "a6f1c2646fc311707161f6da64382a8b82e6e84327801636768fc97438f8dad9"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Psp2ch/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Psp2ch/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Psp2ch/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Psp2ch/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RIFUmW/0/scan-20.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-RIFUmW/0/scan-20.lisp"
   :SHA256 "dff0fb530fff71de758c7d9b3fd741e392c292a43830adadadc3b744388f186e"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RIFUmW/0/scan-20.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-RIFUmW/0/scan-20.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RIFUmW/0/scan-20.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-RIFUmW/0/scan-20.stdout.log"
   :SHA256 "d31120c235a2673f978099e7193c0211c7cb24bbf944bd12215de664ae9ef525"
   :BYTES 4614)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RIFUmW/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-RIFUmW/0/session.pid"
   :SHA256 "98531aadc54e0fe67e5d563402836bb2cc56a1586678de1dcf3aeff6fb3cf1ea"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RIFUmW/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-RIFUmW/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RIFUmW/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-RIFUmW/0/stdout.lisp"
   :SHA256 "ddb4c5620925c87a40ba79faf408fad831c375ce7a3b649cfe2fe63f420a9d67"
   :BYTES 472)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-SmQLJk/0/scan-17.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-SmQLJk/0/scan-17.lisp"
   :SHA256 "bfae974c766e0fd01c7a3dc3d89c67eaf279d87a66206ec8d58bec48777291be"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-SmQLJk/0/scan-17.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-SmQLJk/0/scan-17.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-SmQLJk/0/scan-17.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-SmQLJk/0/scan-17.stdout.log"
   :SHA256 "5218f86647f1f37eb32da82e9d59aa4763a02b9f037573d10f82d9cfc310d27e"
   :BYTES 4614)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-SmQLJk/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-SmQLJk/0/session.pid"
   :SHA256 "fc450ed246afc504bb141453ddf81554fc5f6cc83dce86c2bf36ecac82ff5c90"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-SmQLJk/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-SmQLJk/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-SmQLJk/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-SmQLJk/0/stdout.lisp"
   :SHA256 "5c3532fa6d8c78f3ae37daad8e619166b635abea9b3c7c9d911ac98e0de034eb"
   :BYTES 454)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/0/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/0/scan-4.lisp"
   :SHA256 "d45378db4ed5af94b139c06ab418377eaac0809d94544dc6afdd6622c80ec2f1"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/0/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/0/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/0/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/0/scan-4.stdout.log"
   :SHA256 "f950f71efe830fc1718cefefbfa288d47972ee61a31fc9bb66bd3566c2c0ef3a"
   :BYTES 4608)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/0/session.pid"
   :SHA256 "fcc1f41b9bdb0dddd1c3d2cc3a0a8458ab16bb02a1e21f5aa907fec71da92197"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/0/stdout.lisp"
   :SHA256 "3c3e1d0db8c3c9caca1995916027d78492d2f580d5e50cdf94d4e59281dd4aed"
   :BYTES 220)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/1/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/1/scan-1.lisp"
   :SHA256 "6e30ca4378ac111ad6f40d299463f72dc8545751b23be7847b19a3165c15201e"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/1/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/1/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/1/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/1/scan-1.stdout.log"
   :SHA256 "0dbcada6dca33278f9af7b87232ba191e5cd7ef5675452c7bbe4996134512e73"
   :BYTES 4590)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/1/session.pid"
   :SHA256 "9dfc74ddbbfb0ef491e2ea527c7faf6cf3ed5e4e947aac0a1d0dac3490b0aed6"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/1/stdout.lisp"
   :SHA256 "1408b0f66ab661b8673cd350d40e192493dba517be5a2705d382c63c8438d28d"
   :BYTES 239)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/10/scan-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/10/scan-11.lisp"
   :SHA256 "d0089c312852712d80954f286e8cd70557f0c6fb108a2b0facfe09047169d6cf"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/10/scan-11.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/10/scan-11.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/10/scan-11.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/10/scan-11.stdout.log"
   :SHA256 "08c018dca7295e960a8f6e16d47f877eca1a47a6d946baa41b31939d05d77a7b"
   :BYTES 4584)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/10/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/10/session.pid"
   :SHA256 "3039b82fd9ba9865b9bc7de33a8c5ea403134f507f4771c6472ebf12695d5396"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/10/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/10/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/10/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/10/stdout.lisp"
   :SHA256 "b41750084e5f40f0277ebeb497e481080e7fe941baa7d744125d2c371e440c85"
   :BYTES 240)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/11/scan-12.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/11/scan-12.lisp"
   :SHA256 "4159ee7ddb3252b8e4c19a3fa3456c69f91925bc60eea0cf168da644acfa5361"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/11/scan-12.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/11/scan-12.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/11/scan-12.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/11/scan-12.stdout.log"
   :SHA256 "81ad91f14a97a5c61b9a6cd0ed1f173cdd01238e3321f4ade056a8a6a9862008"
   :BYTES 4578)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/11/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/11/session.pid"
   :SHA256 "32b4811fd7df742bb237e1d9883c7b3b4851df3733ff3d7b750e602e394103ba"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/11/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/11/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/11/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/11/stdout.lisp"
   :SHA256 "e73c108e307445a6e4194c203f4b1ccd50a0f8bcf263d48fe3f388de1923c5b4"
   :BYTES 230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/12/scan-13.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/12/scan-13.lisp"
   :SHA256 "330feda122b4b85d0e1541a9c964506481cda196d352901676a96dc40e477cae"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/12/scan-13.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/12/scan-13.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/12/scan-13.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/12/scan-13.stdout.log"
   :SHA256 "0089fe98b8947646b5f16067f6c0dd8f2ad851f59e895717ceae59024c1af2bc"
   :BYTES 4572)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/12/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/12/session.pid"
   :SHA256 "2f1e2a84ca19025c98e3dbc4b737e4f54debb1928fb19aa6355e9e7b9ca7a568"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/12/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/12/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/12/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/12/stdout.lisp"
   :SHA256 "a502520708b2fd9a0b2abcd2f7fc2c040042c9249c3a9966193a4cc08b941c3b"
   :BYTES 240)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/13/scan-14.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/13/scan-14.lisp"
   :SHA256 "67441feaf3cad1f1fd1980c0bebebefa6d8409b0867bfb615968999176693eb4"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/13/scan-14.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/13/scan-14.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/13/scan-14.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/13/scan-14.stdout.log"
   :SHA256 "3f0eaff1e1a741aa48a99a116cb400f1c9612460c08152c2947a1252bbb07898"
   :BYTES 4566)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/13/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/13/session.pid"
   :SHA256 "cecd21d7fab3ea97a4fd54c24ea1ec24ea8f0cf3675fa304b781f3a7d5acb8f4"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/13/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/13/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/13/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/13/stdout.lisp"
   :SHA256 "4e98678e376e4a4625750ede03b73fcc8e9408333e83c8de7972982f0e35eddf"
   :BYTES 230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/2/scan-3.lisp"
   :SHA256 "8d107e56e6a4ea8b6b92037a91e7bc00cc803b1c758a00825db34ca215d69fbd"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/2/scan-3.stdout.log"
   :SHA256 "611faf5cf7a0b94bd425eed38537874daf7631a5b6d3b41e18f5debfe164efad"
   :BYTES 4596)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/2/session.pid"
   :SHA256 "fb7dc758ee9e4cd663da292585d55533732f85587cff4572846607285613c578"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/2/stdout.lisp"
   :SHA256 "2e7fca2d9e2fc0d9537df579c78b038ae3c1477cd817cd40fffacbc4cda80597"
   :BYTES 229)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/3/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/3/scan-2.lisp"
   :SHA256 "d9a5cfbc1982138299918f2147abfff078ef37cb1254dda63aa678d487cdcc96"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/3/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/3/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/3/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/3/scan-2.stdout.log"
   :SHA256 "f3628b50f9ed0798966de7ee91612925cb923be0f9aa2fb5fc274b17c390f509"
   :BYTES 4590)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/3/session.pid"
   :SHA256 "1ebdac4a52e00635d970b8c24c719984444cfaaa640fd5155479d0bb7f001491"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/3/stdout.lisp"
   :SHA256 "25564bda945c2105101cc7d392d13240d14238d1a27e9acf8da5f5ae0875158d"
   :BYTES 232)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/4/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/4/scan-5.lisp"
   :SHA256 "b1a6cbf49f083d43609c3d7af8a299b9d3b0a57adf1fea5cd46d354caf4169b2"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/4/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/4/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/4/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/4/scan-5.stdout.log"
   :SHA256 "1e0cb1cd5cdb94e310abe9c59da05cff58f2a22da8d3792a3d606af5ead618e2"
   :BYTES 4596)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/4/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/4/session.pid"
   :SHA256 "9f3d9fcd7855fe0a1dd0b648538d6b537cca5ea4ebfe7ebfe90b1245cd8db071"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/4/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/4/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/4/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/4/stdout.lisp"
   :SHA256 "2be099c08baa117e6464bba3c631874220ab09ec3b9d2dfa3fa3a54fb50eb69f"
   :BYTES 235)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/5/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/5/scan-6.lisp"
   :SHA256 "1c29138c752673c195660018d192c84025c32b2aa7a47dee477b094481f7fab4"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/5/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/5/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/5/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/5/scan-6.stdout.log"
   :SHA256 "bd3014c7ebedc1484a31e271ed96afa8685ce39e8385baca6ea1b4692135080b"
   :BYTES 4590)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/5/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/5/session.pid"
   :SHA256 "9e440a97419d373a01a08d5865fece290ab61faad472f98ae3fe1f072e6648fe"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/5/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/5/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/5/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/5/stdout.lisp"
   :SHA256 "c020b7cfad97537e62a5b046c84a727494a77429c7ba3d0b3c88699d692fadea"
   :BYTES 234)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/6/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/6/scan-7.lisp"
   :SHA256 "bd2f0369bf6d5a63446e0b95da9e3699353aaff1eb37b3126ab0213704e52d37"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/6/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/6/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/6/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/6/scan-7.stdout.log"
   :SHA256 "f34a4f7ea30695f2e77112e0a3e4a72aa9d090fba84c7673cf7e52ff6c1d37cc"
   :BYTES 4596)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/6/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/6/session.pid"
   :SHA256 "cf5f3b8b0efd94a88b97b19c8553ee3bd41012ea4f0c6d5e9234dd1b34ab2b85"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/6/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/6/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/6/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/6/stdout.lisp"
   :SHA256 "632ff70d8e777211e68c9c6aa18fbbacd544790316335340e811020c0820425a"
   :BYTES 235)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/7/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/7/scan-8.lisp"
   :SHA256 "16b7a8aecd4d53c34b34fcb022ee9c17cf2b1033933b108d33fbd97b4a7c278e"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/7/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/7/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/7/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/7/scan-8.stdout.log"
   :SHA256 "1ab74997980d1d454f19b85c791e49bc013d7fc69480a3d09e2a757218af0518"
   :BYTES 4578)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/7/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/7/session.pid"
   :SHA256 "ddda1846f15b29b4f1bc8386e84fad2c5dfbdd3613157ce8da04e07268b15e1b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/7/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/7/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/7/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/7/stdout.lisp"
   :SHA256 "ba7fcea75bc2864a21f3b940483384447375da9144341dee0b2be1a13f199598"
   :BYTES 226)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/8/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/8/scan-9.lisp"
   :SHA256 "21aae86dd612020965ad5df6ac33de4938f9525ba21709dfd8c5947d53a1745f"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/8/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/8/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/8/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/8/scan-9.stdout.log"
   :SHA256 "4e6451b0908d521f4af2244dd9a9b48c3a3df063625ddc5522b3f0950667fe2d"
   :BYTES 4584)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/8/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/8/session.pid"
   :SHA256 "2e5027c9cc1f9bb85e3dbf98244fb07f441005e9c57a330dc2868b872c93cf73"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/8/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/8/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/8/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/8/stdout.lisp"
   :SHA256 "31ea0941716566ef078790085e72650d0e0e931bcea03088f090c3f9e6fb9c66"
   :BYTES 239)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/9/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/9/scan-10.lisp"
   :SHA256 "b513213d3125052a2b7a6b696ff4a03a8aedeb8be81bfe09e119f66af439d312"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/9/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/9/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/9/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/9/scan-10.stdout.log"
   :SHA256 "cba46143d33ae631143fc958afeb44c2b521859dc5f23d4dfd2124324720bd49"
   :BYTES 4590)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/9/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/9/session.pid"
   :SHA256 "42bfc4b66ce50d1e0bfe2be232fcd2a0cdcbd286add0d751cfceb49bbcd24287"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/9/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/9/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TbhwgA/9/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TbhwgA/9/stdout.lisp"
   :SHA256 "15ed29b95978e446d17cd9f520516673c21d11b1ceb647a83107d088cbc75fb4"
   :BYTES 229)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TtUwh6/0/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TtUwh6/0/scan-10.lisp"
   :SHA256 "4120dfa0d918c96fc15accda34e0335b331bc9c7232b0131db31914293682348"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TtUwh6/0/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TtUwh6/0/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TtUwh6/0/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TtUwh6/0/scan-10.stdout.log"
   :SHA256 "fdadbb218a0944cca4afec66b6254cb5209085cdc8433ec0a1558c3909950943"
   :BYTES 4620)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TtUwh6/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TtUwh6/0/session.pid"
   :SHA256 "311ac3c555ddf55e810806b38676257fcc6501ef916916309d918ae541a03ae2"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TtUwh6/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TtUwh6/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TtUwh6/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-TtUwh6/0/stdout.lisp"
   :SHA256 "20609e80f31873a8f579d7c9e685a332b6c3832348d64d7d79537bdef8477d3e"
   :BYTES 295)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-VsmmCP/0/scan-15.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-VsmmCP/0/scan-15.lisp"
   :SHA256 "7d1b7c8693b35d540160b9382733f2f9e8a33898c99a6a506288e75ecb0f0344"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-VsmmCP/0/scan-15.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-VsmmCP/0/scan-15.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-VsmmCP/0/scan-15.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-VsmmCP/0/scan-15.stdout.log"
   :SHA256 "ef5c8b380de46b52d6bde2c66fdd9c0fce2b281ce7ef0341fb1338344c962976"
   :BYTES 4614)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-VsmmCP/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-VsmmCP/0/session.pid"
   :SHA256 "de83819d49bed62a1adceb4be5ce18b09284c932050a90292e4099962783d83c"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-VsmmCP/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-VsmmCP/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-VsmmCP/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-VsmmCP/0/stdout.lisp"
   :SHA256 "3e9c8c9d4df532fd633267c7c487bcc3c0346a260869f97a1fdccb6e2f7bfb31"
   :BYTES 295)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Xfi3Kz/0/scan-18.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Xfi3Kz/0/scan-18.lisp"
   :SHA256 "0b2ff542d1410300e406a2527e4511c09ae18dbfddfebeed71f8d189715ca833"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Xfi3Kz/0/scan-18.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Xfi3Kz/0/scan-18.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Xfi3Kz/0/scan-18.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Xfi3Kz/0/scan-18.stdout.log"
   :SHA256 "24f48f24b953dde598c86f268c62cc4129d69247fef52d13c8ed735949dd1103"
   :BYTES 4614)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Xfi3Kz/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Xfi3Kz/0/session.pid"
   :SHA256 "d12f7bd8c2837b625dfeb1c2d39e9373c5217a91f20a256dbc55dc36a510fe5c"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Xfi3Kz/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Xfi3Kz/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Xfi3Kz/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-Xfi3Kz/0/stdout.lisp"
   :SHA256 "7c465f1f7939425ef3bc58c76e245272d1e305e758239ae1fd89de7454ddd014"
   :BYTES 474)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XvD6c6/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-XvD6c6/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XvD6c6/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-XvD6c6/0/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XvD6c6/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-XvD6c6/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XvD6c6/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-XvD6c6/1/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XvD6c6/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-XvD6c6/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XvD6c6/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-XvD6c6/2/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XvD6c6/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-XvD6c6/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-XvD6c6/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-XvD6c6/3/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YkQ0B0/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-YkQ0B0/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YkQ0B0/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-YkQ0B0/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YkQ0B0/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-YkQ0B0/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YkQ0B0/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-YkQ0B0/1/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YkQ0B0/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-YkQ0B0/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YkQ0B0/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-YkQ0B0/2/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YkQ0B0/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-YkQ0B0/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YkQ0B0/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-YkQ0B0/3/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bAOpUC/0/scan-41.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-bAOpUC/0/scan-41.lisp"
   :SHA256 "49dd24b19f44f57d2c456b1c70d5affd0e3a2018079e114f5ed95f9194a4cef3"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bAOpUC/0/scan-41.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-bAOpUC/0/scan-41.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bAOpUC/0/scan-41.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-bAOpUC/0/scan-41.stdout.log"
   :SHA256 "101d3389acbb91382e64d6c034c992dd374151ec75ed9d511eedc98a33eb6814"
   :BYTES 4608)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bAOpUC/0/scan-42.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-bAOpUC/0/scan-42.lisp"
   :SHA256 "c61a41575d9f788dce23da585b6a52a1242da9774290742e579804d52de25f62"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bAOpUC/0/scan-42.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-bAOpUC/0/scan-42.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bAOpUC/0/scan-42.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-bAOpUC/0/scan-42.stdout.log"
   :SHA256 "d7f5b6a3ef373e9ff902ea15d61b8cb481e1856d1df28a185f90ca8019938c17"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bAOpUC/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-bAOpUC/0/session.pid"
   :SHA256 "1bb97d64d4d4fc3f8d92745085a99bcc5d25e6c40bb7dda5c31576c786b396e5"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bAOpUC/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-bAOpUC/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-bAOpUC/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-bAOpUC/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-clCldC/0/scan-28.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-clCldC/0/scan-28.lisp"
   :SHA256 "69fbc576190b559462bbcf1b67bd55c25f66be8ed7272e4e3ac6bd3e51f215c9"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-clCldC/0/scan-28.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-clCldC/0/scan-28.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-clCldC/0/scan-28.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-clCldC/0/scan-28.stdout.log"
   :SHA256 "c270ab8ffddce4abccebaa1d0ebcad942403baba74902c4bcb6206092202331c"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-clCldC/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-clCldC/0/session.pid"
   :SHA256 "9a401278e599e1c6f603272b7117de73a8294bb77afb242cecfda54ba0547d48"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-clCldC/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-clCldC/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-clCldC/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-clCldC/0/stdout.lisp"
   :SHA256 "292a1a681dccf7b9eed0692f1d511b8334e236f63a3f41097fe192140693043b"
   :BYTES 277)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mGRtMC/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-mGRtMC/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mGRtMC/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-mGRtMC/0/stdout.lisp"
   :SHA256 "4c06abba39ea0a4e2606609bfbe356b75f61b73d26c712b9d8234ff7d6617312"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mGRtMC/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-mGRtMC/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mGRtMC/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-mGRtMC/1/stdout.lisp"
   :SHA256 "06dc0294e1037cb5e1f6a5f74414e7437f47e8d16b8cffde11aa461dab37db90"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mGRtMC/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-mGRtMC/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mGRtMC/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-mGRtMC/2/stdout.lisp"
   :SHA256 "a1cfc01c349e48bf59cd5e99ebe427b5d75af81b1a99eeb822129eebece00b38"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mGRtMC/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-mGRtMC/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mGRtMC/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-mGRtMC/3/stdout.lisp"
   :SHA256 "2892411e61921e2dfc6db0b8281bdd4625d578c34a8bb041df382a2227a9009f"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ppvV8h/0/scan-26.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-ppvV8h/0/scan-26.lisp"
   :SHA256 "a400766289b5bbecd2caa68857b298e5487f7d5dea05a86f85404f802925c28d"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ppvV8h/0/scan-26.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-ppvV8h/0/scan-26.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ppvV8h/0/scan-26.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-ppvV8h/0/scan-26.stdout.log"
   :SHA256 "743622c0d4bc1b2cfd3fafa3ce68d562a653bb8b189c1ae1d740a7b083c9d1f9"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ppvV8h/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-ppvV8h/0/session.pid"
   :SHA256 "b4d77d0f43abec6113610c81e3f81cedd153e55f231cf9bc1ed473bce37eade4"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ppvV8h/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-ppvV8h/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ppvV8h/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-ppvV8h/0/stdout.lisp"
   :SHA256 "2af466d28153aa09bea114b25ce71b795f66e8eb5c64ff6a70b9c79d42a8b2a5"
   :BYTES 498)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-qI5dpL/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-qI5dpL/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-qI5dpL/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-qI5dpL/0/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-qI5dpL/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-qI5dpL/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-qI5dpL/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-qI5dpL/1/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-qI5dpL/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-qI5dpL/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-qI5dpL/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-qI5dpL/2/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-qI5dpL/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-qI5dpL/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-qI5dpL/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-qI5dpL/3/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rJwFGZ/0/scan-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rJwFGZ/0/scan-11.lisp"
   :SHA256 "12a03e2071fefb0b4f3954ed27e4232627764e79cd72e37abb302655738e54a9"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rJwFGZ/0/scan-11.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rJwFGZ/0/scan-11.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rJwFGZ/0/scan-11.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rJwFGZ/0/scan-11.stdout.log"
   :SHA256 "9d1cf412338064c43de1cf4dc280dbf5c1a78dcaeafb9f853300ddfe9eece981"
   :BYTES 4620)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rJwFGZ/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rJwFGZ/0/session.pid"
   :SHA256 "0c6e7a6bdba91f25e7d20cce32e89cbb990bd61a5b6d4d52dda77972e86ebe12"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rJwFGZ/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rJwFGZ/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rJwFGZ/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rJwFGZ/0/stdout.lisp"
   :SHA256 "df97030ac73c04726ba800fc3912c93f09b4c03acc03b67f9982ab97d0362866"
   :BYTES 296)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/0/scan-38.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/0/scan-38.lisp"
   :SHA256 "ef794cbfee791024791234b36ad65ef83936211b6c25eac795474109f83e51aa"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/0/scan-38.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/0/scan-38.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/0/scan-38.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/0/scan-38.stdout.log"
   :SHA256 "4adb5804190d8b7c0e99fa43de851ffe251a93a61fbd7c3ba1354b800e418e4b"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/0/session.pid"
   :SHA256 "3ec942ef05b7e7edcdbc0b2cf6f7e7bbba91a52312314a61740e2cdf064e644e"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/0/stdout.lisp"
   :SHA256 "c0669c168ad85f6dd19524368ce77836a2a57bdebf22dbea59103553676c2295"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/1/scan-37.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/1/scan-37.lisp"
   :SHA256 "d718cc5c493d2ca370fbf267e74691de9827289f3c2f5a03cc87789a674e2492"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/1/scan-37.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/1/scan-37.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/1/scan-37.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/1/scan-37.stdout.log"
   :SHA256 "c4cc34dbd75253e6d5cf8f2ae46229d4b9ccf3964b28bc4facbbd5283298dda4"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/1/session.pid"
   :SHA256 "0eb37deaa15dcb2943aad8f57a9aa52bbecb16e78a8070196f6b78ada1f4a10e"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/1/stdout.lisp"
   :SHA256 "4a24d87cdb9c05ad489a33a270f568ee1a4caf2d485deedbe3f313172bad0085"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/2/scan-36.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/2/scan-36.lisp"
   :SHA256 "6951808f49b0818e3d8a7c8a1a5ff1aecdcb73b28a9e735ae7800826b830c6dd"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/2/scan-36.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/2/scan-36.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/2/scan-36.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/2/scan-36.stdout.log"
   :SHA256 "6ecf080d933d0e397411e4fbfbcd1505b4fbbee21cb53bd02478e4fb11fd9414"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/2/session.pid"
   :SHA256 "13b66d3ae38d5be2b22e0480295942e5b108627bf329c4fa81fe1c59ef0be315"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/2/stdout.lisp"
   :SHA256 "03a226bbe2415edccc11b1af83128e3ae7b9385f4d013400186e47f55045b64f"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/3/scan-35.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/3/scan-35.lisp"
   :SHA256 "b82ccfd7c2a9bcb949881abc7b825550f6a249cfe8f7838c1604872304f21b72"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/3/scan-35.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/3/scan-35.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/3/scan-35.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/3/scan-35.stdout.log"
   :SHA256 "c22cfef588d7ab3cee4851b75fecebc6f136a7a2a2fc33d8ccd197a7c7f46a2e"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/3/session.pid"
   :SHA256 "5923f6be54119db06b1e0aa835c286728cdb150bd4924a212e78771d5031ebe1"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rbFtrc/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rbFtrc/3/stdout.lisp"
   :SHA256 "24d22fb972d6d3c7edbb70a571d5427c2149349190e98b1b32671c9c10ad3679"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rrhGa5/0/scan-27.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rrhGa5/0/scan-27.lisp"
   :SHA256 "34fdf0545447884dd9e0ebfeb96eec05e46a456f7a4ebbbb7e5fce182fbeaf56"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rrhGa5/0/scan-27.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rrhGa5/0/scan-27.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rrhGa5/0/scan-27.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rrhGa5/0/scan-27.stdout.log"
   :SHA256 "4bebde5b0ae1e089c0e3e1debd3c2663576e21371358f5c34f218022f30d9f8b"
   :BYTES 4608)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rrhGa5/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rrhGa5/0/session.pid"
   :SHA256 "09671f09bccb88c87acced40642a061e0d257d13282c22a1128807aab3d1719b"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rrhGa5/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rrhGa5/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rrhGa5/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rrhGa5/0/stdout.lisp"
   :SHA256 "292a1a681dccf7b9eed0692f1d511b8334e236f63a3f41097fe192140693043b"
   :BYTES 277)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rxROuj/0/scan-13.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rxROuj/0/scan-13.lisp"
   :SHA256 "02f324809e8918a6fe1eaabe92a82bdb32cafed13902f09607decf87329d9edd"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rxROuj/0/scan-13.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rxROuj/0/scan-13.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rxROuj/0/scan-13.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rxROuj/0/scan-13.stdout.log"
   :SHA256 "6dfe2721e3f5ca9361cee5c48dd785ad8e83393bec17463fd8396e8838fc0752"
   :BYTES 4614)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rxROuj/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rxROuj/0/session.pid"
   :SHA256 "89cbd50b0466e628fc1c27dafb887013ce21f278aca2811cf96f6c6c1ee2c7ce"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rxROuj/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rxROuj/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rxROuj/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-rxROuj/0/stdout.lisp"
   :SHA256 "dc8c87f355f770d68270f577265048f8cce4f9188df2a80694e4c12b3410615b"
   :BYTES 307)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-s0k2I8/0/scan-16.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-s0k2I8/0/scan-16.lisp"
   :SHA256 "f5e71a63dd886857c26e90226588dfbf52c64c87f66a0b16fce1ac9926ec10d7"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-s0k2I8/0/scan-16.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-s0k2I8/0/scan-16.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-s0k2I8/0/scan-16.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-s0k2I8/0/scan-16.stdout.log"
   :SHA256 "ad8f8526e6c216117bbe79d6157e5c6f9677428479ac78560b698d9c6328001c"
   :BYTES 4620)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-s0k2I8/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-s0k2I8/0/session.pid"
   :SHA256 "8ea1fe5f33fb0adb7953b670d5f6f1cd2c726a7628644dd28afd201366ae605d"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-s0k2I8/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-s0k2I8/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-s0k2I8/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-s0k2I8/0/stdout.lisp"
   :SHA256 "35931db009d497087a3ccc25fa634f3d88389a83589961c60481dfeb129f25a1"
   :BYTES 452)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-szJ2dk/0/scan-19.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-szJ2dk/0/scan-19.lisp"
   :SHA256 "5f0c1509137f3ff09e6478fdef5d30029bf08126fd4b3da65c987340d815956b"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-szJ2dk/0/scan-19.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-szJ2dk/0/scan-19.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-szJ2dk/0/scan-19.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-szJ2dk/0/scan-19.stdout.log"
   :SHA256 "360f5b0136f68323601ad9e6be76f9ecb3b61053976ccab1a6bc6282227c78a3"
   :BYTES 4614)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-szJ2dk/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-szJ2dk/0/session.pid"
   :SHA256 "989beaf03db0fa8c03daad39e2fab71c748d26552066f601568c383efbf44584"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-szJ2dk/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-szJ2dk/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-szJ2dk/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-szJ2dk/0/stdout.lisp"
   :SHA256 "e962662c53cead26538c63a599216c929502d85da32f6891cb2e383f0a37c056"
   :BYTES 697)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vOwqZL/0/scan-29.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-vOwqZL/0/scan-29.lisp"
   :SHA256 "3fac9f3460c91f5aececc4b85af4750d50552ff2242a0f62a4e126c7c555f0f9"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vOwqZL/0/scan-29.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-vOwqZL/0/scan-29.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vOwqZL/0/scan-29.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-vOwqZL/0/scan-29.stdout.log"
   :SHA256 "2020f86a9ef4291d4debd98734b7661d0a393d473eefd947655890c1a12c31c1"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vOwqZL/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-vOwqZL/0/session.pid"
   :SHA256 "67d598d1d99aea32dcf4b6757479f7cefeff8a64f8c93ab52cb573102a9f11a1"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vOwqZL/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-vOwqZL/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vOwqZL/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-vOwqZL/0/stdout.lisp"
   :SHA256 "a691777c3ecaf752aaf5af897b18602754877d33d19b49945bba15e63ffac202"
   :BYTES 514)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-wCezZD/0/scan-25.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-wCezZD/0/scan-25.lisp"
   :SHA256 "09c924448c7cf5cc1e754d12a8558668daa26a22082db4d79380e6dff496bc59"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-wCezZD/0/scan-25.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-wCezZD/0/scan-25.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-wCezZD/0/scan-25.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-wCezZD/0/scan-25.stdout.log"
   :SHA256 "b68ed8975ef322d22c8002e18433be310ae3a7407cd72ef7237aa99f4b9acb2f"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-wCezZD/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-wCezZD/0/session.pid"
   :SHA256 "37468a44da3298c22bd825fe76d237ccb82b9173e60fcadb77816a950115f8af"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-wCezZD/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-wCezZD/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-wCezZD/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-wCezZD/0/stdout.lisp"
   :SHA256 "e85716c2d9aaa497a5d6a9c852932cf20b311f231f015f835e0b393b312ec6cc"
   :BYTES 563)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xq0YeZ/0/scan-14.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-xq0YeZ/0/scan-14.lisp"
   :SHA256 "22ec0881fb671ece9af61fd72c8c1ed95e99f5c9529b98957a4b7428568c2920"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xq0YeZ/0/scan-14.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-xq0YeZ/0/scan-14.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xq0YeZ/0/scan-14.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-xq0YeZ/0/scan-14.stdout.log"
   :SHA256 "2e1a3addec698aae054ae72a5eacabfe4b54648abd5c84b73b666bda9cd032a7"
   :BYTES 4602)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xq0YeZ/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-xq0YeZ/0/session.pid"
   :SHA256 "cc5c159af9a6e09802af27006128ddd5ea041ba7ac40907159b6ae77c16b86bb"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xq0YeZ/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-xq0YeZ/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-xq0YeZ/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-xq0YeZ/0/stdout.lisp"
   :SHA256 "69592181c0668a6dcf8e18e2a54fc5dfebf52332e93459daa725af9b7466a60a"
   :BYTES 308)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/0/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/0/scan-1.lisp"
   :SHA256 "b57367f55f6e500fef37740e2c4a5886d93b2d3485a5f4d763e2724a5b257a92"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/0/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/0/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/0/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/0/scan-1.stdout.log"
   :SHA256 "18107b59ff41952bfef87189a085eed140ead363b9d44387ba7a80f3c0407299"
   :BYTES 4632)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/0/session.pid"
   :SHA256 "fe428dd23b62a26e1ceee240ba8f8b9b9e4401bf102317495ed5b8e6a5c0a4da"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/0/stdout.lisp"
   :SHA256 "5b535aae53f5f5dde642f2ff9f2609de885c61c81264c6445f181a1cf4960859"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/1/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/1/scan-2.lisp"
   :SHA256 "e78da95923c484e7d678e11bbdb6a3696b32cc10f94f15abac62dd58a18e977e"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/1/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/1/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/1/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/1/scan-2.stdout.log"
   :SHA256 "312744e5770b896d2a159e2629a41ede7c1c8c9d2be23e34f6f89c445fd0b0cc"
   :BYTES 4620)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/1/session.pid"
   :SHA256 "4376f151ec8d5ee5e95a945edbdfceb2b284d25f79192e37cd37286588d111c3"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/1/stdout.lisp"
   :SHA256 "ea2dbc5177b9a30d66760dcff058cea86decd386b43a2c8678bbe8ffb42830c6"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/2/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/2/scan-4.lisp"
   :SHA256 "66971ac2cd3fd680a4a9c8c8a014afdea999601b90d92d848eba0af70e152e56"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/2/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/2/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/2/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/2/scan-4.stdout.log"
   :SHA256 "376dc0119243cb695938ae482ac4b2c933c6bf76212b492d9729d0c44f782ea7"
   :BYTES 4620)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/2/session.pid"
   :SHA256 "0d327ea12b9a917ad85c62766b5d3f0355765e856fcb23e8a1eaaa39c72470f1"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/2/stdout.lisp"
   :SHA256 "f29ead817fd94c165dc89605041876cb951c6ae0761c49754199d27ea0992476"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/3/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/3/scan-3.lisp"
   :SHA256 "306bec4cfc31cca3281402078691cc2eef48f3198d9dcfef72b3caf4976782b5"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/3/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/3/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/3/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/3/scan-3.stdout.log"
   :SHA256 "2f064afa5c151205d0dd3be22df064296fd85f1deb37505a3176facdb4fdc0af"
   :BYTES 4620)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/3/session.pid"
   :SHA256 "eb82cee5a1f20fc9e41629126841a4269ca1e9342983801d819197467fea5c97"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zX9lru/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-client-scoped-envelope/support/evidence-check-zX9lru/3/stdout.lisp"
   :SHA256 "9bd4d3528e73981c66df42ff7ea931d9aedca7a4a0654c65188e5ece54be899b"
   :BYTES 280))
 :LIMITS (:NEGATIVE-NESTED-SELF-TEST-FIXTURES-EXCLUDED))
