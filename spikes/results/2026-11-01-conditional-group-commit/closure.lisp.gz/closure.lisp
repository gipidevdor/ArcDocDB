(:KIND :CONDITIONAL-COHORT-EVIDENCE-CLOSURE :STATUS :PASSED :UNIVERSAL-TIME
 4002518908 :DRIVER-SHA256
 "639fcd112467f193af1fbba5c308df1af1ee4d426e816ab13866d20061c29e06"
 :INPUT-SHA256
 "da53771d063a9391bb59c4c07c08d96ac9ba7c9da0ce8b8cc07af7381644cbb7" :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002515115-command-43648-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/initial-archive-command/conservazione.lisp"
   :SHA256 "5106253e4ded57400e32fef81cb5718de37f03dc48a3a39ee1a16f88e3314c64")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002515115-command-43648-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/initial-archive-command/report.lisp"
   :SHA256 "b9771b6bd9712f11a4f4ad3e0ccda6ab036a8c37acd9a80573d16772982ee62c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002515115-command-43649-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/failed-fixture-archive-command/conservazione.lisp"
   :SHA256 "80f219017174d02bf41c5b8562f1098f696fceb4bf6e8425d003dcf3bc44c1a5")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002515115-command-43649-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/failed-fixture-archive-command/report.lisp"
   :SHA256 "cc7e5548235de5850e771325b04ed8d6270be62a2b9ab53a410bd2b01063d654")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002515550-command-48641-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/analyzer-self-test/conservazione.lisp"
   :SHA256 "40f730eada4f14378cf957aa574ee456ebedf21ae1488964c2a560747c44a1db")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002515550-command-48641-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/analyzer-self-test/report.lisp"
   :SHA256 "8db265000471f0098aeeb4b8b656e2e36358ede7e19247b24c89cee4056cf6fa")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002515685-command-49229-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-integrity-initial/conservazione.lisp"
   :SHA256 "afef94321ed326a068e329ddf842e8904cbb09dd3f573c11a1e95095b46a1840")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002515685-command-49229-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-integrity-initial/report.lisp"
   :SHA256 "307147375da97f8327230c695025641ba127ea1bfeb45e13788658b863613754")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002515917-command-51968-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-integrity-final/conservazione.lisp"
   :SHA256 "c8245efeaedc59962afd1fcf5b9755eeea1c7d36a99e4c6fb294f0dd51b8341b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002515917-command-51968-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-integrity-final/report.lisp"
   :SHA256 "548832c0882dbae9e6864a1e8c3d6eb998a9f57d5b1ab1c10ba938cd2dbf9154")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002515917-command-51967-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/identity-self-test/conservazione.lisp"
   :SHA256 "f8bc2694ac6e3f2422d0a630544f82f0f79c16e43aa6aabe037837c425252281")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002515917-command-51967-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/identity-self-test/report.lisp"
   :SHA256 "c845059dbdb8a6aa3255775c8cf299e1a1d7f31f75d283101a380ee0e791a226")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002516099-command-54850-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/archive-self-test/conservazione.lisp"
   :SHA256 "fe1dbd39b75bbfd1bbb9b04fbf359fde0f237dae09c25423a33a31a3a6fd3ae4")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002516099-command-54850-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/archive-self-test/report.lisp"
   :SHA256 "61fa3a82667587dffb4792c2a6580a0b85099f3229d9b9365eb1f14501e12fa3")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002516548-command-75246-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-archive-command/conservazione.lisp"
   :SHA256 "1f350a7a944b4449fc895f6cab735dc8c786fe3397d93638ee0f099ef40f0f76")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002516548-command-75246-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-archive-command/report.lisp"
   :SHA256 "09b748095ff4983e5cfe16b0daba515789d23943eb4b0627057b0f5008c0b604")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002516569-command-75485-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/qualification-summary-command/conservazione.lisp"
   :SHA256 "08622939ec6c9dc13683ee0b72c8dc410221070d7611ae3977a4cdbc4c95de7b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002516569-command-75485-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/qualification-summary-command/report.lisp"
   :SHA256 "b34ed918ce09157d03ca4d4e000f0507248c06e200679a1376cd5736568fe0c8")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002517081-command-83539-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/benchmark-archive-command/conservazione.lisp"
   :SHA256 "a02c8278472a2ee4d461e4c593d8264be97185d0f8f8c08016bb000ed72d602e")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002517081-command-83539-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/benchmark-archive-command/report.lisp"
   :SHA256 "4656d213fa077c75f894c6727a9cb62558bca571553419a4a48a7fc95f74c398")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002517081-command-83538-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/analysis-command/conservazione.lisp"
   :SHA256 "cf1c1de3fa02e5e6819b6656b07bd6b1ffd8aff8869498aaa0cf95c396fd156e")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002517081-command-83538-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/analysis-command/report.lisp"
   :SHA256 "8477265f483134e9e81eeefc5066334d5e4e58696be0f86cb5cf2ef1cbfcbcc5")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002517244-command-86218-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/identity-command/conservazione.lisp"
   :SHA256 "353717501db1f5528bd7147ff37404b59eb3ff8af435e80e6ebf35d82606647c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002517244-command-86218-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/identity-command/report.lisp"
   :SHA256 "106c78da3271f3deb4458b3441ca576083435c5b72473af4519e90ac93233f74")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002517414-command-93480-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/inspect-costs-command/conservazione.lisp"
   :SHA256 "081e08c390fec6c7ffff88d5a01d301d4c3d43d074dfb630d8dcb4c158ffd6e5")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002517414-command-93480-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/inspect-costs-command/report.lisp"
   :SHA256 "138d97f3385b0c9abb43ae2ca84dc7d19c2d0d5e904c6f9ac438571305e37fd9")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002517964-command-4618-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/diagnostic-command/conservazione.lisp"
   :SHA256 "f598dfee2d4fec3c1b801a9eff7289a8a6e0bcec944edc991a5b52a966530fc8")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002517964-command-4618-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/diagnostic-command/report.lisp"
   :SHA256 "48c6d78099bd9a67f5d82f13c0833e8bad7194fdecd270cb0a01b8d92bc6af82")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002518224-command-9197-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/diagnostic-analysis-command/conservazione.lisp"
   :SHA256 "689a32e3af430a64776669d098e821b54b1826eb62475fd6aac9f2ab4be1f63b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002518224-command-9197-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/diagnostic-analysis-command/report.lisp"
   :SHA256 "b1ef81bd6e837be675ce1aa2b9cbae1b19b9c49be40214a56071be92e4a31a76")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002518757-command-17175-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/current-source-command/conservazione.lisp"
   :SHA256 "8d2d5b3348e39d3f9f6a5dca7d37c0fcacb96c418b000c9039bc3974e63e1399")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002518757-command-17175-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/current-source-command/report.lisp"
   :SHA256 "751ec06801d75dcfcb52a1990f5617e10e404bd3f86dc2ad75306960d33e2779")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002518757-command-17174-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-checks/conservazione.lisp"
   :SHA256 "b98b9386cdb8fa843b0fc5af8c72cddd82a0cbb5c43bd8e0a8f9f7c484067e91")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002518757-command-17174-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-checks/report.lisp"
   :SHA256 "abe0161b296649f455b534b7d2ae2aa533253da08e2255ce5d31744a073df958")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/0/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/0/scan-4.lisp"
   :SHA256 "ad6b062b7db6d13cafcc7ad7b965312e83a80466b0ec03f95eabb8897d9e14e2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/0/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/0/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/0/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/0/scan-4.stdout.log"
   :SHA256 "d255f5ab0307a3ae26f0f05800b71dca7718e883cdd796f0face5014e9f0f723")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/0/session.pid"
   :SHA256 "cd586cd37b63ae69903dcff688444b3bd2784275b86cfe5095d33937f84eb004")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/0/stdout.lisp"
   :SHA256 "3c3e1d0db8c3c9caca1995916027d78492d2f580d5e50cdf94d4e59281dd4aed")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/1/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/1/scan-1.lisp"
   :SHA256 "43da854cb98ce6124c7982bd33feff2589ac97c78f1a246b2b11e3ae2c55b157")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/1/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/1/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/1/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/1/scan-1.stdout.log"
   :SHA256 "d9ecc1029c38e185baf4ae4ef56807a348bc289e9bb375d85c8c62e1fc07bbd9")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/1/session.pid"
   :SHA256 "8a7ae760739f9cfa365836e873be5619dc0bb6aa210f33a2f1d57f6a2fc3a0db")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/1/stdout.lisp"
   :SHA256 "1408b0f66ab661b8673cd350d40e192493dba517be5a2705d382c63c8438d28d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/2/scan-3.lisp"
   :SHA256 "5a2b1355ba017fbe8fd21d92b401f13d8464eb2b4ca7b008e018d3530a74d827")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/2/scan-3.stdout.log"
   :SHA256 "6cece327889c71063e6d787ce131f328208daaa3725c3d890c4494b9385f0040")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/2/session.pid"
   :SHA256 "7474c63fa0c61bfe7061b39e8ce7d5c8530f8b564230a7a463e72f16c74ba9ba")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/2/stdout.lisp"
   :SHA256 "2e7fca2d9e2fc0d9537df579c78b038ae3c1477cd817cd40fffacbc4cda80597")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/3/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/3/scan-2.lisp"
   :SHA256 "f48abda32bc985860c153c730347a0f2bf83843cfc1933baa11f6af8d31fb897")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/3/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/3/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/3/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/3/scan-2.stdout.log"
   :SHA256 "fd08a0090ea02becedb2e84030780bb4007d90141351a4e490a83dc89897dd0a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/3/session.pid"
   :SHA256 "efd58c1b8cdf9bb4627a7f014ee4e900ee156b71590e24e6ce000f27898998fe")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/3/stdout.lisp"
   :SHA256 "25564bda945c2105101cc7d392d13240d14238d1a27e9acf8da5f5ae0875158d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/4/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/4/scan-5.lisp"
   :SHA256 "2b50916385f88b051d5816573ba55f68848578478e4ed2647dcad68f54d53a09")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/4/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/4/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/4/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/4/scan-5.stdout.log"
   :SHA256 "f582469031801e463fa47995082d0c850f1553d5554a86feee57800f079b4df2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/4/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/4/session.pid"
   :SHA256 "0415e113ba8c8f9da21516a331829fd68bc4b723ce35bbc603028e1b83da6e99")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/4/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/4/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/4/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/4/stdout.lisp"
   :SHA256 "2be099c08baa117e6464bba3c631874220ab09ec3b9d2dfa3fa3a54fb50eb69f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/5/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/5/scan-6.lisp"
   :SHA256 "ef0f934a132d83dbe285d646e2959a18030cd34a5623b67876369bd2084b29d8")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/5/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/5/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/5/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/5/scan-6.stdout.log"
   :SHA256 "7aeb4e04bde98ebd1bb077ff8022582f67a9dc5476cdc5a96a433513b38dbb28")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/5/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/5/session.pid"
   :SHA256 "4bdd5fc82528d55fcad85a7004518cc515a3c10cb8328031f327d136cf9f0dd2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/5/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/5/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/5/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/5/stdout.lisp"
   :SHA256 "c020b7cfad97537e62a5b046c84a727494a77429c7ba3d0b3c88699d692fadea")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/6/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/6/scan-7.lisp"
   :SHA256 "53898da284eaedeb985c2f1db93c5429e282f6458cb6d4595e00950ca6846a32")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/6/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/6/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/6/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/6/scan-7.stdout.log"
   :SHA256 "fa42cfb816e0656816e3f2563b6202412618dce3ef82727edd4f197eeb1174df")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/6/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/6/session.pid"
   :SHA256 "e03cb84209294eb9ac9fd53bd49a14f45bbed7584e229ac265c686d6e1e70004")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/6/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/6/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/6/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/6/stdout.lisp"
   :SHA256 "632ff70d8e777211e68c9c6aa18fbbacd544790316335340e811020c0820425a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/7/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/7/scan-9.lisp"
   :SHA256 "b3eb8174a58faaf70802302a0fe65e09526cca989b78c5a2e066b912489b66d7")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/7/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/7/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/7/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/7/scan-9.stdout.log"
   :SHA256 "485cc95d81e47462bf63f359689b22d58af552d8bb2badd48c934aa93c30c7e9")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/7/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/7/session.pid"
   :SHA256 "eb4da8a9a807ee64680e5eb45d49c5be05fb33c86637abd9977a2fa3478d25db")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/7/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/7/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/7/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/7/stdout.lisp"
   :SHA256 "ba7fcea75bc2864a21f3b940483384447375da9144341dee0b2be1a13f199598")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/8/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/8/scan-8.lisp"
   :SHA256 "e08554069fa643c7ea1a01a2ba2dc3a5ffffc44c26ff87ccfbc0c98d069cd6ce")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/8/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/8/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/8/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/8/scan-8.stdout.log"
   :SHA256 "34b411425e0699aac6e29cb4e484d0950a8788f5433017474ef5bf2f48df8e6a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/8/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/8/session.pid"
   :SHA256 "e4e97d44ec3b2d71a0ed4000b43d23fd02e6672e7fd67e1f1805287ee3ba65bc")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/8/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/8/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/8/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/8/stdout.lisp"
   :SHA256 "31ea0941716566ef078790085e72650d0e0e931bcea03088f090c3f9e6fb9c66")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/9/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/9/scan-10.lisp"
   :SHA256 "2035f6069d6262e74a294981d947debd4219827b422aa30929ce3bda2bfd4115")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/9/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/9/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/9/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/9/scan-10.stdout.log"
   :SHA256 "74e32ccba23737162dad3dba909aa432b372e0f12058aca2a7799f447dff7d75")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/9/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/9/session.pid"
   :SHA256 "2b4d00b3a6fa8c6fd17d0e08ee0b365dfdc42d223284bb9e6fb93bba117b46e4")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/9/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/9/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-rFQxwa/9/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-check-rFQxwa/9/stdout.lisp"
   :SHA256 "15ed29b95978e446d17cd9f520516673c21d11b1ceb647a83107d088cbc75fb4")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002516079-command-54613-0/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/4002516079-command-54613-0/self-test-report.lisp"
   :SHA256 "7e47f646dc8ee821fcd8e3536a898b414e928bb78b4cbfd416d95f7b431a963b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002516081-snapshot-self-test-54659-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/4002516081-snapshot-self-test-54659-0/report.lisp"
   :SHA256 "663aa3d8f8aa57ae19ded11f55e6fe0971cec0ad77af0e9e60a4e270ede400a0")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002516082-reader-self-test-54662-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/4002516082-reader-self-test-54662-0/report.lisp"
   :SHA256 "ac3592dc3824624122136dd09cfba3b4b55b60f56e0935a6d49a0b9333a401b7")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/command-archive-collector-self-test-75mdro/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/command-archive-collector-self-test-75mdro/self-test-report.lisp"
   :SHA256 "bf7be7b8cfef60fb37be291057037ba2ba72792dfa1961c07d1d044a43cf386b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-parallel-self-test-9IMMYW/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/evidence-parallel-self-test-9IMMYW/report.lisp"
   :SHA256 "52e8652940cde256e119a2994faee3267098e3ed864485f2882b655a00c85f32")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793527650-72714/boundaries.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/ci/selftest-1793527650-72714/boundaries.lisp"
   :SHA256 "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793527650-72714/conditions.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/ci/selftest-1793527650-72714/conditions.lisp"
   :SHA256 "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793527650-72714/data.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/ci/selftest-1793527650-72714/data.lisp"
   :SHA256 "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793527650-72714/measure.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/ci/selftest-1793527650-72714/measure.lisp"
   :SHA256 "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793527650-72714/publication.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/ci/selftest-1793527650-72714/publication.lisp"
   :SHA256 "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793527650-72714/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/ci/selftest-1793527650-72714/report.lisp"
   :SHA256 "3bf53e3748c34568e0fb83b9f6f7ed394be5c711a74ca8b7bdde88a45f49bc23")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793527650-72714/tests.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/ci/selftest-1793527650-72714/tests.lisp"
   :SHA256 "ba1c0e543638f0424a2c9f3c07cc641b5f0e776c7e036135293eebd50a169904")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793527650-72714/workflow.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/support/ci/selftest-1793527650-72714/workflow.lisp"
   :SHA256 "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"))
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/source-identity.lisp"
   :STATUS :OK :ORIGINAL-BYTES 172875 :STORED-BYTES 55411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "source-identity.lisp.gz" :UNCOMPRESSED-BYTES 172875 :UNCOMPRESSED-SHA256
    "ccef4399c5b119fb0fd78cd97b8d7ca3ebfd81123608b456a8e49ae0f3724b9a"
    :COMPRESSED-BYTES 55087 :COMPRESSED-SHA256
    "c14e8b6ecf786f56d92e015dd799c3f3f90045a2e01be3744d6cc9d7c3b9fb62"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/analysis-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 347612 :STORED-BYTES 111428 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 347612 :UNCOMPRESSED-SHA256
    "8477265f483134e9e81eeefc5066334d5e4e58696be0f86cb5cf2ef1cbfcbcc5"
    :COMPRESSED-BYTES 111112 :COMPRESSED-SHA256
    "cb0d0064fed46c3ac62fbdf4dfa600ea6d698aa29e90e221f297c7601e4656b2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/analyzer-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 346790 :STORED-BYTES 111098 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 346790 :UNCOMPRESSED-SHA256
    "8db265000471f0098aeeb4b8b656e2e36358ede7e19247b24c89cee4056cf6fa"
    :COMPRESSED-BYTES 110782 :COMPRESSED-SHA256
    "a72b1d72af62a35f58b5abe5269e85cb94d9de473ddcb0c9492a8b54b750b5d4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/archive-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 346787 :STORED-BYTES 111096 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 346787 :UNCOMPRESSED-SHA256
    "61fa3a82667587dffb4792c2a6580a0b85099f3229d9b9365eb1f14501e12fa3"
    :COMPRESSED-BYTES 110780 :COMPRESSED-SHA256
    "188308eb8fac622a34be74cda345f3c93892dcf7ce807ab0ff8fb68ce580bab5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-integrity-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 346780 :STORED-BYTES 111087 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 346780 :UNCOMPRESSED-SHA256
    "548832c0882dbae9e6864a1e8c3d6eb998a9f57d5b1ab1c10ba938cd2dbf9154"
    :COMPRESSED-BYTES 110771 :COMPRESSED-SHA256
    "379c05ad69a8f0c6150a1024113e6276a9928869c1347921c483fad6b5f875be"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-integrity-initial/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 346780 :STORED-BYTES 111086 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 346780 :UNCOMPRESSED-SHA256
    "307147375da97f8327230c695025641ba127ea1bfeb45e13788658b863613754"
    :COMPRESSED-BYTES 110770 :COMPRESSED-SHA256
    "9d935b34f876de696f16f83047ec16d1305654431f90544ceec2ba37ea65150e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZQVI-FLU-0/001-v1-server-610.stdout"
   :STATUS :OK :ORIGINAL-BYTES 2087 :STORED-BYTES 442 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stdout.gz" :UNCOMPRESSED-BYTES 2087 :UNCOMPRESSED-SHA256
    "c7527e12703fe23186800a962ca760a98af5a72c2b90deac929f2090f0b8aef9"
    :COMPRESSED-BYTES 118 :COMPRESSED-SHA256
    "b5b7211fba5b7be99fb8acdf3feea19b618cf8f804625e18ec493b37ba5d60bd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZQZI-GJG-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "fdcf1df387cb483973b83ad4f2c69702ba3c6b61f29b93888c504ec8599680ba"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "f86a292150913d80015c7f31dd8df647c7fe1fb9fcf5b02d1401841f7dc16b03"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZQZJ-GJG-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "95acc941c274f959bb8fa39a82d966a243e348f2a4b21cdee9c53db3d0a8691f"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "23d8e6c1818ff4496d4fb65f3365b9a3cc1bc11b99eeecd4682fa1397b8efec5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZQZK-GJG-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "a24bad138cb0ffef1ec4d107f87ce3dde8d2c2284c9fd68022038563441bda3c"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "85529de9910444247e491e628258121793bd3fba2a958f9af6e8ffd7cdf59652"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZQZM-GJG-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "045a1f226e05b08e26b02fd028bd08ae9cee7e4ba706b4b05fed8e3bef3666fb"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "e0177eff276dd7a6cc5ba70377bfed9b7bf0180b4d2865b3480736b6b284311d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZQZO-GJG-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "fdcf1df387cb483973b83ad4f2c69702ba3c6b61f29b93888c504ec8599680ba"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "f86a292150913d80015c7f31dd8df647c7fe1fb9fcf5b02d1401841f7dc16b03"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZQZQ-GJG-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "95acc941c274f959bb8fa39a82d966a243e348f2a4b21cdee9c53db3d0a8691f"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "23d8e6c1818ff4496d4fb65f3365b9a3cc1bc11b99eeecd4682fa1397b8efec5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZQZR-GJG-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "a24bad138cb0ffef1ec4d107f87ce3dde8d2c2284c9fd68022038563441bda3c"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "85529de9910444247e491e628258121793bd3fba2a958f9af6e8ffd7cdf59652"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZQZT-GJG-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "045a1f226e05b08e26b02fd028bd08ae9cee7e4ba706b4b05fed8e3bef3666fb"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "e0177eff276dd7a6cc5ba70377bfed9b7bf0180b4d2865b3480736b6b284311d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZQZV-GJG-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "fdcf1df387cb483973b83ad4f2c69702ba3c6b61f29b93888c504ec8599680ba"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "f86a292150913d80015c7f31dd8df647c7fe1fb9fcf5b02d1401841f7dc16b03"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZQZW-GJG-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "95acc941c274f959bb8fa39a82d966a243e348f2a4b21cdee9c53db3d0a8691f"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "23d8e6c1818ff4496d4fb65f3365b9a3cc1bc11b99eeecd4682fa1397b8efec5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZQZY-GJG-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "a24bad138cb0ffef1ec4d107f87ce3dde8d2c2284c9fd68022038563441bda3c"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "85529de9910444247e491e628258121793bd3fba2a958f9af6e8ffd7cdf59652"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZQZZ-GJG-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "045a1f226e05b08e26b02fd028bd08ae9cee7e4ba706b4b05fed8e3bef3666fb"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "e0177eff276dd7a6cc5ba70377bfed9b7bf0180b4d2865b3480736b6b284311d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZR02-GJG-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "fdcf1df387cb483973b83ad4f2c69702ba3c6b61f29b93888c504ec8599680ba"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "f86a292150913d80015c7f31dd8df647c7fe1fb9fcf5b02d1401841f7dc16b03"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZR03-GJG-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "95acc941c274f959bb8fa39a82d966a243e348f2a4b21cdee9c53db3d0a8691f"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "23d8e6c1818ff4496d4fb65f3365b9a3cc1bc11b99eeecd4682fa1397b8efec5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZR04-GJG-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "a24bad138cb0ffef1ec4d107f87ce3dde8d2c2284c9fd68022038563441bda3c"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "85529de9910444247e491e628258121793bd3fba2a958f9af6e8ffd7cdf59652"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline-logs/2.6.9/1U6ZR06-GJG-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "045a1f226e05b08e26b02fd028bd08ae9cee7e4ba706b4b05fed8e3bef3666fb"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "e0177eff276dd7a6cc5ba70377bfed9b7bf0180b4d2865b3480736b6b284311d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/baseline/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 376007 :STORED-BYTES 112431 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 376007 :UNCOMPRESSED-SHA256
    "c744caa32869c9e892661156bce4b79f7cfc14799389edc91bd02476454fd9d0"
    :COMPRESSED-BYTES 112115 :COMPRESSED-SHA256
    "deb8638d1749d867c35a64fa64d4d60784328ca689d215f399d0c79a6b1e8ebf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/benchmark-2.6.10/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 378475 :STORED-BYTES 113134 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 378475 :UNCOMPRESSED-SHA256
    "c613b47e21187d916bed2ac7da2d47d5d3b02a1ff7b19f5e6e4dfba0fa96979d"
    :COMPRESSED-BYTES 112818 :COMPRESSED-SHA256
    "02703d1fb4d4db4326df231553e26f3a5234023c2a8a21c75919af59c476e72c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/benchmark-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 346945 :STORED-BYTES 111093 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 346945 :UNCOMPRESSED-SHA256
    "4656d213fa077c75f894c6727a9cb62558bca571553419a4a48a7fc95f74c398"
    :COMPRESSED-BYTES 110777 :COMPRESSED-SHA256
    "334ff24cac0662dffae01a20ba9092532f2aa2d604b7c51e237a1684d2535742"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/benchmark/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 378451 :STORED-BYTES 113196 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 378451 :UNCOMPRESSED-SHA256
    "4ff578132f13b101ac61b8c248499c5f5ecb4360d29ae93a3971e7629bf9d013"
    :COMPRESSED-BYTES 112880 :COMPRESSED-SHA256
    "bf6c7633fc8764edb4f42edf2db36f275b729be6ba65c0dc1338e8ad44e99c8e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/ci-self-test-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 347428 :STORED-BYTES 111267 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 347428 :UNCOMPRESSED-SHA256
    "de4d2716c499919b89bae2f447725ae8f6889aaf6ef4222dbb1f240924f3b1aa"
    :COMPRESSED-BYTES 110951 :COMPRESSED-SHA256
    "b276b702c65846b08476870cb87dfca143f7c0430e1f5fc021477a5c7f815d7a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/current-source-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 346781 :STORED-BYTES 111083 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 346781 :UNCOMPRESSED-SHA256
    "751ec06801d75dcfcb52a1990f5617e10e404bd3f86dc2ad75306960d33e2779"
    :COMPRESSED-BYTES 110767 :COMPRESSED-SHA256
    "10b78143d3c7265fc5a325d53135197cfc3f9fcd15e43bc5b32da52c140d55fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/development-baseline-setenv/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 347902 :STORED-BYTES 111322 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 347902 :UNCOMPRESSED-SHA256
    "17fe4e36a65c5bf74351e7a903c72297b807c962a9e2b2d0d99679f8576b8ca3"
    :COMPRESSED-BYTES 111006 :COMPRESSED-SHA256
    "ce72845c529875fdafc88536076c352f626d0e6efe904f223fe0dbd7d339fabf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/development-baseline-stdout/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 352106 :STORED-BYTES 112103 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 352106 :UNCOMPRESSED-SHA256
    "2ab53258622faa6b82674c03c6b6ba6d5129eb9c45bfe4772779d9e9a997ed51"
    :COMPRESSED-BYTES 111787 :COMPRESSED-SHA256
    "9b49fb5c9842184e2c7f7c4e430bba8b4682d59c5b7c6e07883aaf57d7a65b6b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/development-deadline/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 370184 :STORED-BYTES 114528 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 370184 :UNCOMPRESSED-SHA256
    "84a9fe92905c6ea02f48c7d187a73978ecfe3f3a47725653f97279febaa0c3a9"
    :COMPRESSED-BYTES 114212 :COMPRESSED-SHA256
    "538a0724ad5f3cfaba0828e4271038e236267708ebdc8b7dab13938c23c88271"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/development-engine/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 352102 :STORED-BYTES 112711 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 352102 :UNCOMPRESSED-SHA256
    "6b215339c9b1531fa67fa7f84035b3b1bc361a0ad840604ca685765888e8a7bc"
    :COMPRESSED-BYTES 112395 :COMPRESSED-SHA256
    "b4d476f31b66fa320783f77374233593e775e051b85fec2a2f08a7c6c74315cf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/development-fixtures/1U6ZQVI-FLU-0/001-v1-server-610.stdout"
   :STATUS :OK :ORIGINAL-BYTES 2087 :STORED-BYTES 442 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stdout.gz" :UNCOMPRESSED-BYTES 2087 :UNCOMPRESSED-SHA256
    "c7527e12703fe23186800a962ca760a98af5a72c2b90deac929f2090f0b8aef9"
    :COMPRESSED-BYTES 118 :COMPRESSED-SHA256
    "b5b7211fba5b7be99fb8acdf3feea19b618cf8f804625e18ec493b37ba5d60bd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/development-ping-arguments/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 356999 :STORED-BYTES 114008 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 356999 :UNCOMPRESSED-SHA256
    "ab8a26944599b4307fa00f34f6d0aab483fd822b30cc8d5836ae72bb8c548aa9"
    :COMPRESSED-BYTES 113692 :COMPRESSED-SHA256
    "a3b3884583ef7c35b939fe6dc8d026f75aeb3c6f2670c2d9e6e286bac1aa5bd7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/development-ping-process-compile/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 357272 :STORED-BYTES 114069 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 357272 :UNCOMPRESSED-SHA256
    "855d278ed93e5fbe0e541585421e26195584014c57005486cc237c412370ae0d"
    :COMPRESSED-BYTES 113753 :COMPRESSED-SHA256
    "cf27ef2091129f31b645db9dc94e9ccc798399d4d7edf1fa380e4bd949cb36d7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/development-processes/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 369965 :STORED-BYTES 114463 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 369965 :UNCOMPRESSED-SHA256
    "4f89a3f3fa3940e5e5a290f337d8399518719defa884ef9e72fe22c50639e48c"
    :COMPRESSED-BYTES 114147 :COMPRESSED-SHA256
    "9eaacf6c1a65e44734b8cb7ed436769b17c56944cff916029089204098fd7e23"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/development-socket-name/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 367693 :STORED-BYTES 115097 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 367693 :UNCOMPRESSED-SHA256
    "cc719d12b60ef60f8007c14edd4bb95d6d8efd7fb94ca77c8b63e01c2247e7e6"
    :COMPRESSED-BYTES 114781 :COMPRESSED-SHA256
    "7ef1f6550bb9d40ee32d126f06fb976e19d8b38a2f047dea4dc4f393496f1618"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/diagnostic-analysis-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 347506 :STORED-BYTES 111294 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 347506 :UNCOMPRESSED-SHA256
    "b1ef81bd6e837be675ce1aa2b9cbae1b19b9c49be40214a56071be92e4a31a76"
    :COMPRESSED-BYTES 110978 :COMPRESSED-SHA256
    "1c8a76f3fdf69fe8fc14ac91da188ad78a2213955c12a2c4f3142bcfc4987421"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/diagnostic-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 354645 :STORED-BYTES 112095 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 354645 :UNCOMPRESSED-SHA256
    "48c6d78099bd9a67f5d82f13c0833e8bad7194fdecd270cb0a01b8d92bc6af82"
    :COMPRESSED-BYTES 111779 :COMPRESSED-SHA256
    "40617ce3584ec630a34a9a6d31dbf9b01710483ab49729e665e99d19995846a4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/diagnostic/final-logs/2.6.9/10-1U6ZUMN-3KY-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4791 :STORED-BYTES 820 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 4791 :UNCOMPRESSED-SHA256
    "02ac6dcf0653253647729adc1462c2ea5e4469a7e67d46a0511bf0424802984f"
    :COMPRESSED-BYTES 496 :COMPRESSED-SHA256
    "7deec4709a361bfeaa441c77e79c3918bb81da0c7df0cc7432eff1bfb25481a1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/diagnostic/final-logs/2.6.9/15-1U6ZUMP-3KY-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4791 :STORED-BYTES 829 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 4791 :UNCOMPRESSED-SHA256
    "648846e05f042bc795b65aa109f6161db589f90a08f91dd8a9e8ecf2f7d3f227"
    :COMPRESSED-BYTES 505 :COMPRESSED-SHA256
    "0ea779f15395e6f6fe012830af438b4341d59660f63b9667e25e8d18a4d0fa53"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/diagnostic/final-logs/2.6.9/20-1U6ZUMQ-3KY-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4791 :STORED-BYTES 823 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 4791 :UNCOMPRESSED-SHA256
    "01e9cbbdc3269aff154bb8668ea6dddc72b70e22f8d7eace0f76e2b99d413baf"
    :COMPRESSED-BYTES 499 :COMPRESSED-SHA256
    "9b6cb7dc05cfad2e7a4be405fedef728cdbd45e5313bcfa9f01b4ded29ca33ea"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/diagnostic/final-logs/2.6.9/5-1U6ZUMM-3KY-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4791 :STORED-BYTES 831 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 4791 :UNCOMPRESSED-SHA256
    "5a399d1d37297bf2dbadc568f026018b7476bd416b0947504d91289ccf645223"
    :COMPRESSED-BYTES 507 :COMPRESSED-SHA256
    "5271eb1ea935dc32bd3a886353516ebd2b1842e9a7f90bc0b2f1f64be35d0ee9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/documentation/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 352866 :STORED-BYTES 112452 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 352866 :UNCOMPRESSED-SHA256
    "c80b06c14b55013de84a79ee284e08e1602b68d2d7e7f672e78d55d318abdfd6"
    :COMPRESSED-BYTES 112136 :COMPRESSED-SHA256
    "73ce7d79f54c350de22ecb4b22f67b0b9f27fcf88ad5f40370073aedaab87dcd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/failed-fixture-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 346762 :STORED-BYTES 111097 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 346762 :UNCOMPRESSED-SHA256
    "cc7e5548235de5850e771325b04ed8d6270be62a2b9ab53a410bd2b01063d654"
    :COMPRESSED-BYTES 110781 :COMPRESSED-SHA256
    "bf60847a17b007fa9b611468adfb7345d17d8c02d74a14eab3f33e76c71d2c93"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 346936 :STORED-BYTES 111091 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 346936 :UNCOMPRESSED-SHA256
    "09b748095ff4983e5cfe16b0daba515789d23943eb4b0627057b0f5008c0b604"
    :COMPRESSED-BYTES 110775 :COMPRESSED-SHA256
    "66e451477332488f0f20c37cfd79ca868507f5ec47cea0849743fb45f6412f5f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-checks/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 346787 :STORED-BYTES 111108 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 346787 :UNCOMPRESSED-SHA256
    "abe0161b296649f455b534b7d2ae2aa533253da08e2255ce5d31744a073df958"
    :COMPRESSED-BYTES 110792 :COMPRESSED-SHA256
    "541f768174d185194f4830118700f264a45dae6579d132ba4a85358244cb0d2f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/10-1U6ZTT8-1PJ7-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "37f63f6815edfed2160e60e7c7f94b321906dbc0312b2730f90a6d256f03ed9d"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d646a88bbd3ba3d1edb1c9c47e70daf92d19096b2f8133169df927e0d4202fa6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/15-1U6ZTT9-1PJ7-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "6f922491e1bbca8bba0dabb456cc21931ec99e7e308b27aff111216538ec41a3"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d92524059fa5ef5a27984e919f7c04b850aeb0b3308853fbacbc2b20865c95f1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/20-1U6ZTTA-1PJ7-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "e63d4d2ce30f0dc9ea3f9313b00c3af9e66a6f3594dcd8c9f26fce501f45bf7e"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "0254de6610780e4e4330438e5742f255dd5a342beae37bd8389e7c51150ded8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/25-1U6ZTTC-1PJ7-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "fdcf1df387cb483973b83ad4f2c69702ba3c6b61f29b93888c504ec8599680ba"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "f86a292150913d80015c7f31dd8df647c7fe1fb9fcf5b02d1401841f7dc16b03"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/30-1U6ZTTD-1PJ7-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "37f63f6815edfed2160e60e7c7f94b321906dbc0312b2730f90a6d256f03ed9d"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d646a88bbd3ba3d1edb1c9c47e70daf92d19096b2f8133169df927e0d4202fa6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/35-1U6ZTTE-1PJ7-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "6f922491e1bbca8bba0dabb456cc21931ec99e7e308b27aff111216538ec41a3"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d92524059fa5ef5a27984e919f7c04b850aeb0b3308853fbacbc2b20865c95f1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/40-1U6ZTTF-1PJ7-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "e63d4d2ce30f0dc9ea3f9313b00c3af9e66a6f3594dcd8c9f26fce501f45bf7e"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "0254de6610780e4e4330438e5742f255dd5a342beae37bd8389e7c51150ded8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/45-1U6ZTTH-1PJ7-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "fdcf1df387cb483973b83ad4f2c69702ba3c6b61f29b93888c504ec8599680ba"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "f86a292150913d80015c7f31dd8df647c7fe1fb9fcf5b02d1401841f7dc16b03"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/5-1U6ZTT6-1PJ7-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "fdcf1df387cb483973b83ad4f2c69702ba3c6b61f29b93888c504ec8599680ba"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "f86a292150913d80015c7f31dd8df647c7fe1fb9fcf5b02d1401841f7dc16b03"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/50-1U6ZTTI-1PJ7-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "37f63f6815edfed2160e60e7c7f94b321906dbc0312b2730f90a6d256f03ed9d"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d646a88bbd3ba3d1edb1c9c47e70daf92d19096b2f8133169df927e0d4202fa6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/55-1U6ZTTJ-1PJ7-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "6f922491e1bbca8bba0dabb456cc21931ec99e7e308b27aff111216538ec41a3"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d92524059fa5ef5a27984e919f7c04b850aeb0b3308853fbacbc2b20865c95f1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/60-1U6ZTTK-1PJ7-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "e63d4d2ce30f0dc9ea3f9313b00c3af9e66a6f3594dcd8c9f26fce501f45bf7e"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "0254de6610780e4e4330438e5742f255dd5a342beae37bd8389e7c51150ded8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/65-1U6ZTTL-1PJ7-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "fdcf1df387cb483973b83ad4f2c69702ba3c6b61f29b93888c504ec8599680ba"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "f86a292150913d80015c7f31dd8df647c7fe1fb9fcf5b02d1401841f7dc16b03"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/70-1U6ZTTN-1PJ7-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "37f63f6815edfed2160e60e7c7f94b321906dbc0312b2730f90a6d256f03ed9d"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d646a88bbd3ba3d1edb1c9c47e70daf92d19096b2f8133169df927e0d4202fa6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/75-1U6ZTTO-1PJ7-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "6f922491e1bbca8bba0dabb456cc21931ec99e7e308b27aff111216538ec41a3"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d92524059fa5ef5a27984e919f7c04b850aeb0b3308853fbacbc2b20865c95f1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.10/80-1U6ZTTP-1PJ7-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "e63d4d2ce30f0dc9ea3f9313b00c3af9e66a6f3594dcd8c9f26fce501f45bf7e"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "0254de6610780e4e4330438e5742f255dd5a342beae37bd8389e7c51150ded8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/10-1U6ZTQU-1OHH-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "37f63f6815edfed2160e60e7c7f94b321906dbc0312b2730f90a6d256f03ed9d"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d646a88bbd3ba3d1edb1c9c47e70daf92d19096b2f8133169df927e0d4202fa6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/15-1U6ZTQW-1OHH-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "6f922491e1bbca8bba0dabb456cc21931ec99e7e308b27aff111216538ec41a3"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d92524059fa5ef5a27984e919f7c04b850aeb0b3308853fbacbc2b20865c95f1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/20-1U6ZTQX-1OHH-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "e63d4d2ce30f0dc9ea3f9313b00c3af9e66a6f3594dcd8c9f26fce501f45bf7e"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "0254de6610780e4e4330438e5742f255dd5a342beae37bd8389e7c51150ded8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/25-1U6ZTQZ-1OHH-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "fdcf1df387cb483973b83ad4f2c69702ba3c6b61f29b93888c504ec8599680ba"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "f86a292150913d80015c7f31dd8df647c7fe1fb9fcf5b02d1401841f7dc16b03"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/30-1U6ZTR1-1OHH-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "37f63f6815edfed2160e60e7c7f94b321906dbc0312b2730f90a6d256f03ed9d"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d646a88bbd3ba3d1edb1c9c47e70daf92d19096b2f8133169df927e0d4202fa6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/35-1U6ZTR4-1OHH-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "6f922491e1bbca8bba0dabb456cc21931ec99e7e308b27aff111216538ec41a3"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d92524059fa5ef5a27984e919f7c04b850aeb0b3308853fbacbc2b20865c95f1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/40-1U6ZTR7-1OHH-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "e63d4d2ce30f0dc9ea3f9313b00c3af9e66a6f3594dcd8c9f26fce501f45bf7e"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "0254de6610780e4e4330438e5742f255dd5a342beae37bd8389e7c51150ded8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/45-1U6ZTRA-1OHH-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "fdcf1df387cb483973b83ad4f2c69702ba3c6b61f29b93888c504ec8599680ba"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "f86a292150913d80015c7f31dd8df647c7fe1fb9fcf5b02d1401841f7dc16b03"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/5-1U6ZTQS-1OHH-0/001-v1-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "fdcf1df387cb483973b83ad4f2c69702ba3c6b61f29b93888c504ec8599680ba"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "f86a292150913d80015c7f31dd8df647c7fe1fb9fcf5b02d1401841f7dc16b03"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/50-1U6ZTRG-1OHH-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "37f63f6815edfed2160e60e7c7f94b321906dbc0312b2730f90a6d256f03ed9d"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d646a88bbd3ba3d1edb1c9c47e70daf92d19096b2f8133169df927e0d4202fa6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/55-1U6ZTRJ-1OHH-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "6f922491e1bbca8bba0dabb456cc21931ec99e7e308b27aff111216538ec41a3"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d92524059fa5ef5a27984e919f7c04b850aeb0b3308853fbacbc2b20865c95f1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/60-1U6ZTRM-1OHH-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "e63d4d2ce30f0dc9ea3f9313b00c3af9e66a6f3594dcd8c9f26fce501f45bf7e"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "0254de6610780e4e4330438e5742f255dd5a342beae37bd8389e7c51150ded8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/65-1U6ZTRO-1OHH-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "fdcf1df387cb483973b83ad4f2c69702ba3c6b61f29b93888c504ec8599680ba"
    :COMPRESSED-BYTES 88 :COMPRESSED-SHA256
    "f86a292150913d80015c7f31dd8df647c7fe1fb9fcf5b02d1401841f7dc16b03"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/70-1U6ZTRQ-1OHH-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "37f63f6815edfed2160e60e7c7f94b321906dbc0312b2730f90a6d256f03ed9d"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d646a88bbd3ba3d1edb1c9c47e70daf92d19096b2f8133169df927e0d4202fa6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/75-1U6ZTRS-1OHH-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "6f922491e1bbca8bba0dabb456cc21931ec99e7e308b27aff111216538ec41a3"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "d92524059fa5ef5a27984e919f7c04b850aeb0b3308853fbacbc2b20865c95f1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/final-logs/2.6.9/80-1U6ZTRT-1OHH-0/001-v2-server-610.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2040 :STORED-BYTES 412 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-610.stderr.gz" :UNCOMPRESSED-BYTES 2040 :UNCOMPRESSED-SHA256
    "e63d4d2ce30f0dc9ea3f9313b00c3af9e66a6f3594dcd8c9f26fce501f45bf7e"
    :COMPRESSED-BYTES 89 :COMPRESSED-SHA256
    "0254de6610780e4e4330438e5742f255dd5a342beae37bd8389e7c51150ded8d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/focused/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 370185 :STORED-BYTES 114521 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 370185 :UNCOMPRESSED-SHA256
    "0eddbca416774e2653cb863f550776d0fcc651629ea28b4319c6c184adbae2ba"
    :COMPRESSED-BYTES 114205 :COMPRESSED-SHA256
    "6ac42c5efb397f5b3fe463e79a5578256190e638048a25d0a545b436fe6eff0a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/identity-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 346782 :STORED-BYTES 111091 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 346782 :UNCOMPRESSED-SHA256
    "106c78da3271f3deb4458b3441ca576083435c5b72473af4519e90ac93233f74"
    :COMPRESSED-BYTES 110775 :COMPRESSED-SHA256
    "30e3d1822e446a2cdb97e23b08ae4a41bc93fa78124873fa90d453fe031bb46f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/identity-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 346780 :STORED-BYTES 111081 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 346780 :UNCOMPRESSED-SHA256
    "c845059dbdb8a6aa3255775c8cf299e1a1d7f31f75d283101a380ee0e791a226"
    :COMPRESSED-BYTES 110765 :COMPRESSED-SHA256
    "3f66314751632c8b465d4f4f2fc784d48ea26d364d13468a8598238df4c38a45"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/initial-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 346940 :STORED-BYTES 111093 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 346940 :UNCOMPRESSED-SHA256
    "b9771b6bd9712f11a4f4ad3e0ccda6ab036a8c37acd9a80573d16772982ee62c"
    :COMPRESSED-BYTES 110777 :COMPRESSED-SHA256
    "3dfff3d57f609b2d9ef6006280bab3626a78ffc60f35699e4b167a09946ace60"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/inspect-costs-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349156 :STORED-BYTES 111823 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349156 :UNCOMPRESSED-SHA256
    "138d97f3385b0c9abb43ae2ca84dc7d19c2d0d5e904c6f9ac438571305e37fd9"
    :COMPRESSED-BYTES 111507 :COMPRESSED-SHA256
    "a30cf02941245d8b3192490d34237e08514f1d80612b22cf682d68e825f05ac6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-conditional-group-commit/qualification-summary-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 346752 :STORED-BYTES 111076 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 346752 :UNCOMPRESSED-SHA256
    "b34ed918ce09157d03ca4d4e000f0507248c06e200679a1376cd5736568fe0c8"
    :COMPRESSED-BYTES 110760 :COMPRESSED-SHA256
    "0fcc768619d5ccb2b5851921224c008223f8991829e19728cf67a34e88d517f7")))
 :VERIFIED-FILES 164 :HASH-METHOD :STORED-BYTES-OR-VERIFIED-LOSSLESS-EXPANSION
 :LIMITS
 (:NEGATIVE-SELF-TEST-FIXTURE-TREES-EXCLUDED
  :NO-QUALIFICATION-INFERENCE-FROM-EXIT-CODE-ALONE))
