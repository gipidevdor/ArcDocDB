(:KIND :DISJOINT-TAIL-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "disjoint-close" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-final-archive" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-identity-final" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-closing-archive" :STATUS :FAILED :SOURCE-CONSISTENCY
   :STABLE))
 :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-close/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-close/conservazione.lisp"
   :SHA256 "024888b5754ae9f6966b46bda80b1cde0ae7479312ef7c8b7b098828850b3507"
   :BYTES 1160)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-close/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-close/report.lisp"
   :SHA256 "573724bc5804227bd4b52947fc0cdf78b5c9891862f86392072ce401061539b6"
   :BYTES 362903)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-final-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-final-archive/conservazione.lisp"
   :SHA256 "8f457a691737456068e73b5d1a7288d7ca427bc53d7439a4030e76ae765c7f68"
   :BYTES 1176)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-final-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-final-archive/report.lisp"
   :SHA256 "50978aac7a9aee48b9b80c9d998ed1db372102a3ba42052559a0752f227742bb"
   :BYTES 362218)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-identity-final/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-final/conservazione.lisp"
   :SHA256 "35b1c05342995feaa4eb5ea0ad8f0c40b0eb4cf793c98aa927ae670e521dd85d"
   :BYTES 1178)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-identity-final/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-final/report.lisp"
   :SHA256 "eca4a7515cf6328bbd3f21a8e8ca1b86457513b5074a90d3097de236424e64f6"
   :BYTES 362182)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-closing-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-closing-archive/conservazione.lisp"
   :SHA256 "b75808f44b1dba72bc563fa99d07db3b173575e9acb4bf42d3e1c360eef60ab2"
   :BYTES 1179)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-closing-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-closing-archive/report.lisp"
   :SHA256 "42626747890f72ff2e83c594b727762cd67402ea9f2948cc568b314e5d833b77"
   :BYTES 368278))
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-closing-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 368278 :STORED-BYTES 117625 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 368278 :UNCOMPRESSED-SHA256
    "42626747890f72ff2e83c594b727762cd67402ea9f2948cc568b314e5d833b77"
    :COMPRESSED-BYTES 117309 :COMPRESSED-SHA256
    "3f6f07f53ef9b5e941f0a122673cacea70e15d76be5bc5e5e40f3f32824d8682"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-final/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362182 :STORED-BYTES 116200 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362182 :UNCOMPRESSED-SHA256
    "eca4a7515cf6328bbd3f21a8e8ca1b86457513b5074a90d3097de236424e64f6"
    :COMPRESSED-BYTES 115884 :COMPRESSED-SHA256
    "080f9a5d5eea1508a45341a55f741694d49d6fa423e82f3b4e2c7640650ea3f5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-final-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362218 :STORED-BYTES 116205 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362218 :UNCOMPRESSED-SHA256
    "50978aac7a9aee48b9b80c9d998ed1db372102a3ba42052559a0752f227742bb"
    :COMPRESSED-BYTES 115889 :COMPRESSED-SHA256
    "6c415a2a3066365f7ab710b6950dd7fffec4177ad9722118770f91351fc873f9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-close/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362903 :STORED-BYTES 116600 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362903 :UNCOMPRESSED-SHA256
    "573724bc5804227bd4b52947fc0cdf78b5c9891862f86392072ce401061539b6"
    :COMPRESSED-BYTES 116284 :COMPRESSED-SHA256
    "54da50de3066956b0cf1311fed4fad36cffc01318d9f3d37395db315c4a4cb38")))
 :DRIVER-SHA256
 "d8dd473064d2d980202bff09b47c6175428d1f26bbf86634b61b0a16a3ca44bc")
