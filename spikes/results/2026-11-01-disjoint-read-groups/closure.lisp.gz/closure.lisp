(:KIND :DISJOINT-EVIDENCE-CLOSURE :STATUS :PASSED :UNIVERSAL-TIME 4002543007
 :VERIFIED-FILES 1167 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/source-identity.lisp"
   :STATUS :OK :ORIGINAL-BYTES 181284 :STORED-BYTES 58459 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "source-identity.lisp.gz" :UNCOMPRESSED-BYTES 181284 :UNCOMPRESSED-SHA256
    "f7d60d46ed0d8352818b99d4197cfa8ebf8ea3a3bb121e59798ff10e5110263b"
    :COMPRESSED-BYTES 58135 :COMPRESSED-SHA256
    "0c4a7d6fecba6f50ef9b91425c8af8893df8d30637b469d5b2b78c3c88f2fa8c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/initial-archive.lisp"
   :STATUS :OK :ORIGINAL-BYTES 37052 :STORED-BYTES 5570 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "initial-archive.lisp.gz" :UNCOMPRESSED-BYTES 37052 :UNCOMPRESSED-SHA256
    "ff730ba944f24f3d165dd7083f53e276c5ee4fcf1537f406ee27090e27221516"
    :COMPRESSED-BYTES 5248 :COMPRESSED-SHA256
    "1fefae5119af4e72a1f3276bd4df06132881ac25b3ea2d78ce12d149569b298a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/final-archive.lisp"
   :STATUS :OK :ORIGINAL-BYTES 397547 :STORED-BYTES 33955 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-archive.lisp.gz" :UNCOMPRESSED-BYTES 397547 :UNCOMPRESSED-SHA256
    "9243ab822a3b252a7bb47ab7403ca9ce16c1709b07aa810a3ec5f261ba1e54be"
    :COMPRESSED-BYTES 33633 :COMPRESSED-SHA256
    "2e5290e3be375d0a60a7373fb4aa2396ace3d4c6c33d9c0ecbab0900b7625320"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/comparison-candidate.lisp"
   :STATUS :OK :ORIGINAL-BYTES 58106 :STORED-BYTES 9368 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "comparison-candidate.lisp.gz" :UNCOMPRESSED-BYTES 58106
    :UNCOMPRESSED-SHA256
    "6288925fb9759c66909b0a4a7d294f04fb4037bce3b4f9dd72d5def426f15a27"
    :COMPRESSED-BYTES 9041 :COMPRESSED-SHA256
    "5efc8dcb64eee934908dc0431ad6fd89a17678f4d5ec590478bc15c20f98e6ec"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/comparison-candidate-repeat.lisp"
   :STATUS :OK :ORIGINAL-BYTES 58176 :STORED-BYTES 9437 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "comparison-candidate-repeat.lisp.gz" :UNCOMPRESSED-BYTES 58176
    :UNCOMPRESSED-SHA256
    "59662e52ce9b899933df1d12a2b859d677c858ff27b3b9ed5c2657555bbf326a"
    :COMPRESSED-BYTES 9102 :COMPRESSED-SHA256
    "268468b34a11e77456257b17e511fcda550c8589562f6d7cddd0cfe9b35852f0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10869 :STORED-BYTES 2406 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "candidate-calibration-analysis.lisp.gz" :UNCOMPRESSED-BYTES 10869
    :UNCOMPRESSED-SHA256
    "41c7dc6cadffc133c0b10dab4251ba9675a416ef2d3a934a8c69a85fe1c2c2c9"
    :COMPRESSED-BYTES 2068 :COMPRESSED-SHA256
    "cf7cb03797bd1ceb38b28d5f15e76bfaf72fd4be2092b68831f18d5136419ab0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10988 :STORED-BYTES 2357 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-calibration-analysis.lisp.gz" :UNCOMPRESSED-BYTES 10988
    :UNCOMPRESSED-SHA256
    "1984304c5d0ec031cdf5a4862400c2ceeca9bd150e327cb3eeaef79454cb6781"
    :COMPRESSED-BYTES 2020 :COMPRESSED-SHA256
    "7b83b2dd96d7620ab603f9496d845453a4edb3afb7adf6adb4e1396018630435"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-analysis.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28207 :STORED-BYTES 4989 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-analysis.lisp.gz" :UNCOMPRESSED-BYTES 28207 :UNCOMPRESSED-SHA256
    "e0750b9fa53ab29654b1baf07a489cac41e12f74aa6cc03feb33227684475b7d"
    :COMPRESSED-BYTES 4665 :COMPRESSED-SHA256
    "524390373ca5947b768cf7b5daaa611aca5b8ed885e93d6732dd00cd87a604b4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/server-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13862 :STORED-BYTES 3010 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-4.lisp.gz" :UNCOMPRESSED-BYTES 13862 :UNCOMPRESSED-SHA256
    "0931defc0f20cd98d420c98bd5b49965e7dad9d339d95223bd612405888f91f2"
    :COMPRESSED-BYTES 2695 :COMPRESSED-SHA256
    "91a980036d9f867b22fd85a9c1612e9776555be9d3897dc25227cbb7dae21f55"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/server-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5210 :STORED-BYTES 1342 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-3.lisp.gz" :UNCOMPRESSED-BYTES 5210 :UNCOMPRESSED-SHA256
    "cb7d02f39611351a04135db2271b56899cc040a186b0e849a2c2c5ea3b52f814"
    :COMPRESSED-BYTES 1028 :COMPRESSED-SHA256
    "78308b0f7e023cd2a95bd177b2a9233de772bc7b7323ae64bce2d8ea8f42be8f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/server-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13761 :STORED-BYTES 2922 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-2.lisp.gz" :UNCOMPRESSED-BYTES 13761 :UNCOMPRESSED-SHA256
    "bfd98506307a3b1295e02da5b3ffd49eb22ba85ea3ff3998dc132606ee497007"
    :COMPRESSED-BYTES 2607 :COMPRESSED-SHA256
    "88edc23bb127f01049d4579feb56a1931fa43c4a7804321e54b9117e70e10fdf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/server-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5214 :STORED-BYTES 1254 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-1.lisp.gz" :UNCOMPRESSED-BYTES 5214 :UNCOMPRESSED-SHA256
    "c7849bdb760f86971167fcab736743accc2b141ebeed0303204a081277a28c10"
    :COMPRESSED-BYTES 941 :COMPRESSED-SHA256
    "6de16450a002ffa8df2004e9f50f610151cae89b78566674da43e6d2f619b354"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/child-logs/004-latency-4.stderr"
   :STATUS :OK :ORIGINAL-BYTES 13728 :STORED-BYTES 2944 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "004-latency-4.stderr.gz" :UNCOMPRESSED-BYTES 13728 :UNCOMPRESSED-SHA256
    "3501e3ac3c54424cdacd46cc7b332ef6cb391c01ec7c984f7cf4487a568fc147"
    :COMPRESSED-BYTES 2622 :COMPRESSED-SHA256
    "17091c4a2a39b77e9f27bb2f63829bb08101b4992298a6026c1a513505bceaf4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/child-logs/003-latency-3.stderr"
   :STATUS :OK :ORIGINAL-BYTES 5076 :STORED-BYTES 1284 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "003-latency-3.stderr.gz" :UNCOMPRESSED-BYTES 5076 :UNCOMPRESSED-SHA256
    "215f7ea7b9c00f9051c1940ee824cfad980c488334ef156c341032606fc5e9ef"
    :COMPRESSED-BYTES 964 :COMPRESSED-SHA256
    "f06fe2b8248cfdfcb6543ac90242d77c1ca9b3a7025cf76ab2abd6ed3ecd236d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 13624 :STORED-BYTES 2855 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 13624 :UNCOMPRESSED-SHA256
    "550728f9a4a0f6b85ae9530189e26e8327ff72f6d04ad6f87ebc22728a9c64bc"
    :COMPRESSED-BYTES 2533 :COMPRESSED-SHA256
    "c500972c0b90fd797423c6dfd886cde21e3c408561e7cd576b165eee1bced98a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 5077 :STORED-BYTES 1191 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 5077 :UNCOMPRESSED-SHA256
    "5591fb2fe7d8c11727fc98fa796ff8f81f302f06029cfa978195d08182afb546"
    :COMPRESSED-BYTES 871 :COMPRESSED-SHA256
    "c098ee17632b4e0d3d8764a8c316d8b3525a4e906ce4c592a4773802be889d59"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/windows/4-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8308 :STORED-BYTES 3226 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-5.lisp.gz" :UNCOMPRESSED-BYTES 8308 :UNCOMPRESSED-SHA256
    "6416b2b03791a80aa5878b3ab549369814becda5d3fc99892a5f5c2858f87d83"
    :COMPRESSED-BYTES 2917 :COMPRESSED-SHA256
    "cfe5f3db6ca8a7492507665ce0ccb802c7d582f35a44675d45fbeaaa1ae4e0fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8162 :STORED-BYTES 3323 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 8162 :UNCOMPRESSED-SHA256
    "645464334d918aeacfd8514d9f93b70fdb075f763278da1c4b00b6a9e87ca9cc"
    :COMPRESSED-BYTES 3014 :COMPRESSED-SHA256
    "2d5c383fa8f2e3958e9381f1393b346a5ce437fbccbdc155a2a74f6061733ed9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8100 :STORED-BYTES 3286 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 8100 :UNCOMPRESSED-SHA256
    "324e9662067645dd9c24c4b93a4e5c6aa9e01842764a98cc5703d2f5e2595bc1"
    :COMPRESSED-BYTES 2977 :COMPRESSED-SHA256
    "074a335311dd6b63a990e536c8612df85e8a0bc0732d249ff6a1c868fe1a9fc5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8009 :STORED-BYTES 3268 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 8009 :UNCOMPRESSED-SHA256
    "3cfddae507a4d97a615c0e4f42dfebbc169e3135c89298d5444b4dcae4bccf08"
    :COMPRESSED-BYTES 2959 :COMPRESSED-SHA256
    "ddd25590a0a1b30078eac623367092464dcffbef4b4245fd8e28ad5934c6d1c7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7888 :STORED-BYTES 3294 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 7888 :UNCOMPRESSED-SHA256
    "2bd968ec76f653caf028831ecd197e844bcac6c91202159f3a9a3ea4a5716230"
    :COMPRESSED-BYTES 2985 :COMPRESSED-SHA256
    "ed404bb71635eacff528638eb9745164943d1322783f3a03453954c8ba6d235f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7795 :STORED-BYTES 3399 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 7795 :UNCOMPRESSED-SHA256
    "b1297b6f4fef786075910b86df0bfdf3e1b9aae77aa6f3180e76c453f67768ae"
    :COMPRESSED-BYTES 3090 :COMPRESSED-SHA256
    "566fd4e77df511cb833cb492c7f7f5f98ea979d8d519e55c77bc540bc4a86e1b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/windows/2-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8115 :STORED-BYTES 3256 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-5.lisp.gz" :UNCOMPRESSED-BYTES 8115 :UNCOMPRESSED-SHA256
    "dc6a90b9d91638afb5e72eeb9d9130bb663a619bbf9f6f1fa2fc110b6027366c"
    :COMPRESSED-BYTES 2947 :COMPRESSED-SHA256
    "957f9b170e3984539aab6462f4e2153b904e9b5d3b0952ce7a7c65a9b6d9921d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8084 :STORED-BYTES 3421 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 8084 :UNCOMPRESSED-SHA256
    "15114498966d07ea51a7760af3ec8453a0d646cf559cd1205e11f89be744bce1"
    :COMPRESSED-BYTES 3112 :COMPRESSED-SHA256
    "9a6a968037edf5528c91925e5fcd13481eba6e3af4f2690b507b8df4fda32a1a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8255 :STORED-BYTES 3215 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 8255 :UNCOMPRESSED-SHA256
    "6f85a97808250f446e53368e24109c369657c0af9146978cf78396637bc2756e"
    :COMPRESSED-BYTES 2906 :COMPRESSED-SHA256
    "36d618ba41450d6d219e4fc82074b47bf25e3a1f8209a33527ee0654f3e68686"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8272 :STORED-BYTES 3065 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 8272 :UNCOMPRESSED-SHA256
    "371c0125d3b682f6847496281c71cfb41082dc2655f4797170bf30f4dff7199d"
    :COMPRESSED-BYTES 2756 :COMPRESSED-SHA256
    "fe77a419c4c12ad9c5d6bbd3f79e7c8f7b6362a4359c0c02e0c4a1d46759c62b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7931 :STORED-BYTES 3165 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 7931 :UNCOMPRESSED-SHA256
    "8f3765e13e6be405cba639c7261724748be23ada563fef08aea7cbd8d6470c9b"
    :COMPRESSED-BYTES 2856 :COMPRESSED-SHA256
    "163fc4aa19a220f98e2541e29d48fac5c216ea22646be9f0574d3651658783e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline-calibration/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7828 :STORED-BYTES 3242 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 7828 :UNCOMPRESSED-SHA256
    "0f063c5400de9a842cded179533aa2b38955e2eb8a840af42ef6a8fed48dc121"
    :COMPRESSED-BYTES 2933 :COMPRESSED-SHA256
    "eaf18d1c47fd9dd9b5ff415dfc46810b9f84fa9e125eab4bbc29c0d7311427a6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/server-9.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14713 :STORED-BYTES 4528 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-9.lisp.gz" :UNCOMPRESSED-BYTES 14713 :UNCOMPRESSED-SHA256
    "adc6815085a8029029a709b87aa98c9c6290ca77f2cb4efa238b99b25d08b95e"
    :COMPRESSED-BYTES 4213 :COMPRESSED-SHA256
    "a20c53bde8ecd17e2110c7f954fb74f79333d335ca1056f56ff371bf76b96ae0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/server-8.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13769 :STORED-BYTES 4066 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-8.lisp.gz" :UNCOMPRESSED-BYTES 13769 :UNCOMPRESSED-SHA256
    "f0113b651517fc026056f59edc60b0354e0fffb46b4e7c476beca8fc3635f0d1"
    :COMPRESSED-BYTES 3751 :COMPRESSED-SHA256
    "9c8016797b3d3d64fc789cc6455a83cac088b6a12efd9d14bbbf0af2ee8a0950"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/server-7.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4425 :STORED-BYTES 1441 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-7.lisp.gz" :UNCOMPRESSED-BYTES 4425 :UNCOMPRESSED-SHA256
    "27dde2a9c6f736edc53773521e7566a80e7afcfed5cc4afb911b016b560d0a54"
    :COMPRESSED-BYTES 1127 :COMPRESSED-SHA256
    "4263c2fd391b3cb0aed7cc005a2b158648617abeaf34d60cd32fc85755ed5b68"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/server-6.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4739 :STORED-BYTES 1504 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-6.lisp.gz" :UNCOMPRESSED-BYTES 4739 :UNCOMPRESSED-SHA256
    "bafd1efda40c4b0fe5dbafa45579516636e5cacff06b5d7ca8eb14e8b1d8b3e6"
    :COMPRESSED-BYTES 1190 :COMPRESSED-SHA256
    "2418f5ff47e90bd760b3b3275b2b5f851d85ba1ad3be7ed2eeb863d9a54adea4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/server-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 13649 :STORED-BYTES 3907 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-4.lisp.gz" :UNCOMPRESSED-BYTES 13649 :UNCOMPRESSED-SHA256
    "d754397d973494a8c91896820ead1211b84ac6f5bce079d3b6aef9ede98700d0"
    :COMPRESSED-BYTES 3592 :COMPRESSED-SHA256
    "eb6da866472779ca5646f4af6b83b18ca874261ac2e834b90371ff6b221c88fc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/server-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4408 :STORED-BYTES 1335 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-3.lisp.gz" :UNCOMPRESSED-BYTES 4408 :UNCOMPRESSED-SHA256
    "2e954a1790c69d088c3a2bb3bf96a2a5fed44050a630a3567a2adeef9efecd2f"
    :COMPRESSED-BYTES 1021 :COMPRESSED-SHA256
    "abfbcdb49a4c80eeea9e116ac08d54f6e8dec0cbedea1ccf38f8abd7913d6560"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/server-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4744 :STORED-BYTES 1431 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-2.lisp.gz" :UNCOMPRESSED-BYTES 4744 :UNCOMPRESSED-SHA256
    "3b8f8d3e04ff75147db7ff848e6923a64172933941c53756915656c473da392b"
    :COMPRESSED-BYTES 1117 :COMPRESSED-SHA256
    "b736cd3033970ddeababb27b852e3771fa2b2c45386f791b7cbe8a2d170ca5fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/server-12.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17080 :STORED-BYTES 4961 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-12.lisp.gz" :UNCOMPRESSED-BYTES 17080 :UNCOMPRESSED-SHA256
    "8aabf17320be9598241dcfd49ca42f0feba540a2b6a7b5500666472cfd029321"
    :COMPRESSED-BYTES 4645 :COMPRESSED-SHA256
    "deae836a5545ba794081b351d952afb25215d4faabb17021b6dbf2833bea3dd1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/server-11.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17053 :STORED-BYTES 4457 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-11.lisp.gz" :UNCOMPRESSED-BYTES 17053 :UNCOMPRESSED-SHA256
    "9997bf61544fff18a35376a0e02eb1fbe6b1b13d1bbe48afe2d46745c1cfbc89"
    :COMPRESSED-BYTES 4141 :COMPRESSED-SHA256
    "6f1a5ef1d34eb9a2a58dfedf367a89dd66a3ba18ff2e5ce61aa866b455d20a67"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/server-10.lisp"
   :STATUS :OK :ORIGINAL-BYTES 14752 :STORED-BYTES 4670 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-10.lisp.gz" :UNCOMPRESSED-BYTES 14752 :UNCOMPRESSED-SHA256
    "bfc3895846b8d3b6e0a446b41700a5397a588a03698d247296f678a7a9888e18"
    :COMPRESSED-BYTES 4354 :COMPRESSED-SHA256
    "2db8658cc31f6b08878aeebf9c21dbbd846aed28e10da46f40c2313ccf9b2f17"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9533 :STORED-BYTES 2016 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 9533 :UNCOMPRESSED-SHA256
    "ee760ed5fc38972a803ef924783671b0a4617d181ddc11828d9c03ef64cafa15"
    :COMPRESSED-BYTES 1701 :COMPRESSED-SHA256
    "7481e3600f79bfa4e6cafecd7bad35f63e4fd7c4614b56d124996f96a5e26dd6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9332 :STORED-BYTES 1883 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 9332 :UNCOMPRESSED-SHA256
    "8560f8e18d7f3abbbb41c13d1beba73bd3220974f9e81104059162f9d0f960b6"
    :COMPRESSED-BYTES 1565 :COMPRESSED-SHA256
    "4a4f5b30761ae8785e868ad9bd383d00e4e8c8ad9504e03668493162941062bb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/child-logs/012-latency-12.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16944 :STORED-BYTES 4891 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "012-latency-12.stderr.gz" :UNCOMPRESSED-BYTES 16944 :UNCOMPRESSED-SHA256
    "1d6efea053491d4caf787a3ec0a278384be8bfb0dce2149e23de9f5d7bcd9d96"
    :COMPRESSED-BYTES 4568 :COMPRESSED-SHA256
    "5a130420d7e20911ca00125b74bed7c8e448c8242d8f9a49a9cc2bfaaa56e6e2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/child-logs/011-latency-11.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16914 :STORED-BYTES 4384 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "011-latency-11.stderr.gz" :UNCOMPRESSED-BYTES 16914 :UNCOMPRESSED-SHA256
    "60ce84c4d3ec0a309cec14f1246e503fd8438503165b0e52e5083f1acf1c4117"
    :COMPRESSED-BYTES 4061 :COMPRESSED-SHA256
    "9eb5889fe63e80b1c337902bb904881059d61fb7ac472b08efd8266a586a5409"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/child-logs/010-latency-10.stderr"
   :STATUS :OK :ORIGINAL-BYTES 14618 :STORED-BYTES 4599 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "010-latency-10.stderr.gz" :UNCOMPRESSED-BYTES 14618 :UNCOMPRESSED-SHA256
    "09dcfa398a823d2641ecd7610d10aeb648b7ee04fe9f1beaa8226b43af29b49e"
    :COMPRESSED-BYTES 4276 :COMPRESSED-SHA256
    "abbf3bd9f9259fd8eedb8e221f369cfb5d6798e476e5ad2940938beba90661df"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/child-logs/009-latency-9.stderr"
   :STATUS :OK :ORIGINAL-BYTES 14576 :STORED-BYTES 4455 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "009-latency-9.stderr.gz" :UNCOMPRESSED-BYTES 14576 :UNCOMPRESSED-SHA256
    "058eb19e4479f0de5807c2cbaef9c18fdad035bb3579d11d8352cb3132352e2a"
    :COMPRESSED-BYTES 4133 :COMPRESSED-SHA256
    "60db3dcb46ac9fcf73b56469ff0cda83240923e1ababbd32f1c9b649ca933857"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/child-logs/008-latency-8.stderr"
   :STATUS :OK :ORIGINAL-BYTES 13633 :STORED-BYTES 3997 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "008-latency-8.stderr.gz" :UNCOMPRESSED-BYTES 13633 :UNCOMPRESSED-SHA256
    "0c45903d626b0d14a2ea9ef51cf600a9d6b1d198d3c6cc6dc55f0977afbafa15"
    :COMPRESSED-BYTES 3675 :COMPRESSED-SHA256
    "f440722dd6a2087344cb9e93f6543829abf7b995b3f731019b6efdf03e5ace51"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/child-logs/007-latency-7.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4290 :STORED-BYTES 1382 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "007-latency-7.stderr.gz" :UNCOMPRESSED-BYTES 4290 :UNCOMPRESSED-SHA256
    "5d333638414a28f4d6a94758956e9ac4aaeee070695872b63e465b595ed4a0ae"
    :COMPRESSED-BYTES 1061 :COMPRESSED-SHA256
    "4a26eb20457f756597bbd9bc4bb54de57239ea1f14575aabc34a5ffbb0312163"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/child-logs/006-latency-6.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4603 :STORED-BYTES 1447 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "006-latency-6.stderr.gz" :UNCOMPRESSED-BYTES 4603 :UNCOMPRESSED-SHA256
    "c682d3c9754a9e7ec8828bab743da64297357b3733deadd28c9bc175ecef115a"
    :COMPRESSED-BYTES 1126 :COMPRESSED-SHA256
    "656ba7250d7d74476615db00d830c9d39fa95bb4dde8b7cd66d1b0192d2e2158"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/child-logs/005-latency-5.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2968 :STORED-BYTES 904 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "005-latency-5.stderr.gz" :UNCOMPRESSED-BYTES 2968 :UNCOMPRESSED-SHA256
    "932b71985b51e418d86cb04d2b14868a7ef000bccbbc07c5b34bc1082d878ec5"
    :COMPRESSED-BYTES 584 :COMPRESSED-SHA256
    "80f649a1e1ef9638374859afde28518c0079ba2192f8e31710f5e9b626e976d2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/child-logs/004-latency-4.stderr"
   :STATUS :OK :ORIGINAL-BYTES 13510 :STORED-BYTES 3835 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "004-latency-4.stderr.gz" :UNCOMPRESSED-BYTES 13510 :UNCOMPRESSED-SHA256
    "889e41696d96402345427d84d6ba2469d071430ffcb517f797b2d41ecbe58a87"
    :COMPRESSED-BYTES 3513 :COMPRESSED-SHA256
    "ac76f275cb63819ac270071a080a5651492908ccf4c539771b31d6afba023a97"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/child-logs/003-latency-3.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4270 :STORED-BYTES 1276 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "003-latency-3.stderr.gz" :UNCOMPRESSED-BYTES 4270 :UNCOMPRESSED-SHA256
    "72b54c068a73cff0b43658d6091bc0c9ee9a5c0dd3a9c2cd54d2514eed0358ea"
    :COMPRESSED-BYTES 956 :COMPRESSED-SHA256
    "09b4bff5760543c8cef210c00e6d772c7e198c3980f7043fbd1a4f399e129450"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4605 :STORED-BYTES 1372 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 4605 :UNCOMPRESSED-SHA256
    "263ec53ae099c9008d5e325318c58b6c3e072dd72198961f8989269196249766"
    :COMPRESSED-BYTES 1051 :COMPRESSED-SHA256
    "44ea714c2308a6f077ae2285cd54c024681cc9fa2f72a4cccd94736ff4a0cfe4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2982 :STORED-BYTES 851 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 2982 :UNCOMPRESSED-SHA256
    "845d3c026a37fe1b5e452821b19825950b24421b2af899063354ad559160cc37"
    :COMPRESSED-BYTES 531 :COMPRESSED-SHA256
    "5afa52028524d670b7cb9af11299da2fa990f6c52ee22cf938efa03050212bf2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/9-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8225 :STORED-BYTES 3343 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-4.lisp.gz" :UNCOMPRESSED-BYTES 8225 :UNCOMPRESSED-SHA256
    "9d2a38de87b07cd41c40c66d916faf61614b0af5a0d577c83950d8aa19237041"
    :COMPRESSED-BYTES 3034 :COMPRESSED-SHA256
    "a59f7ee903445a49a958ac71e3bf7d1db4ce3f34320b3a430a4bad3392c24022"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/9-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8285 :STORED-BYTES 3442 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-3.lisp.gz" :UNCOMPRESSED-BYTES 8285 :UNCOMPRESSED-SHA256
    "635ea0a12d3ac87d3da2d7fe416203ef6689f53365fda9f63e6b04f02c94f62d"
    :COMPRESSED-BYTES 3133 :COMPRESSED-SHA256
    "edbedf4d36c4a8378113815e9c3bb208109a039dfea21c4fd3705101342dc8b9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/9-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8118 :STORED-BYTES 3479 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-2.lisp.gz" :UNCOMPRESSED-BYTES 8118 :UNCOMPRESSED-SHA256
    "6711badb77b84176d0253d1a314ebdfafc51f46ebe230a3c15c9099f008cf6d6"
    :COMPRESSED-BYTES 3170 :COMPRESSED-SHA256
    "473ec1ac8f573b6595d8be08bfd4045251df211c5952789374238435c8cc32a4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/9-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7837 :STORED-BYTES 3429 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-1.lisp.gz" :UNCOMPRESSED-BYTES 7837 :UNCOMPRESSED-SHA256
    "ac11d7cd6c41e869d6345083e97141f71ae4e5a7989e2a1c1035482b569a3cb8"
    :COMPRESSED-BYTES 3120 :COMPRESSED-SHA256
    "ddc9f90b506515d484337fbf7570eab13526a091d67f307d59b8305d4ddbc31c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/9-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7800 :STORED-BYTES 3400 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-0.lisp.gz" :UNCOMPRESSED-BYTES 7800 :UNCOMPRESSED-SHA256
    "c8bb52e662a9445422aa56b72b0bf466f1ef26adf4ca5a1b84dd270434c02806"
    :COMPRESSED-BYTES 3091 :COMPRESSED-SHA256
    "4cf44b5d3347956ad564e337f5ebf8e9d26aaa70401e53aac269f6d5391462f0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8341 :STORED-BYTES 3318 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 8341 :UNCOMPRESSED-SHA256
    "2dc290600ad1e5285d0a926b2ec0ce4ecbe9878e6ea0a240eee3e758d5aab189"
    :COMPRESSED-BYTES 3009 :COMPRESSED-SHA256
    "0a960a496a8d8f83ce95b56af0148508e9e9f61710decd94719bbf96553176f4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8351 :STORED-BYTES 3241 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 8351 :UNCOMPRESSED-SHA256
    "e97d255060975c43092e50c912e6db881c88cbf1e7646559d0aa0274aaf12b6b"
    :COMPRESSED-BYTES 2932 :COMPRESSED-SHA256
    "b71c3804d7a6d5a2f782ff0f46b11dc8a781e11eb5629b74c124e177dd72294a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8167 :STORED-BYTES 3298 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 8167 :UNCOMPRESSED-SHA256
    "670f33c6f32971f4f325a9e2dc6f69e20f2278def8ca641ff36dc7d81c2a6e56"
    :COMPRESSED-BYTES 2989 :COMPRESSED-SHA256
    "33e01ebe3803420ca32cc8c68a32447e5b688fef82ec80e1ddf0084e8ea9ef1c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7853 :STORED-BYTES 3260 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 7853 :UNCOMPRESSED-SHA256
    "64a0f2ac8d6b55075e0de944d3e73441c84606c9f76e4b1d2cbcf0bed3012f28"
    :COMPRESSED-BYTES 2951 :COMPRESSED-SHA256
    "1d403641405785cb8a4ac1134485ac44ba360bb1929bc940282629b011231c71"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7832 :STORED-BYTES 3367 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 7832 :UNCOMPRESSED-SHA256
    "ceb7f556ae6e59b5fa63f26221b42c827d325a519b2ca7ed58fb4b74aa665053"
    :COMPRESSED-BYTES 3058 :COMPRESSED-SHA256
    "fc2eac84ddab5df94825521f525abeeac6b34c727d796d18d746928761e73ee3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/7-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6046 :STORED-BYTES 2200 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-4.lisp.gz" :UNCOMPRESSED-BYTES 6046 :UNCOMPRESSED-SHA256
    "8c66fc1d7887c4a012cd148751d7c869c0bd90198b56fb454ef897c7e7a1b7e4"
    :COMPRESSED-BYTES 1891 :COMPRESSED-SHA256
    "71a76089ee81af8c13438d99c54caa5463830357394f34fcc96f629e4564ce6b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/7-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6041 :STORED-BYTES 2185 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-3.lisp.gz" :UNCOMPRESSED-BYTES 6041 :UNCOMPRESSED-SHA256
    "720056d569b27debf54eaf40f24bf3bde5d0504734208bceaaa4194709f951c0"
    :COMPRESSED-BYTES 1876 :COMPRESSED-SHA256
    "99adf7e8fac4ab758fed9cdd9b8d30a167c42f1d0c68f048c291cf2f1a01af6c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/7-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6047 :STORED-BYTES 2182 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-2.lisp.gz" :UNCOMPRESSED-BYTES 6047 :UNCOMPRESSED-SHA256
    "ff2b30c497fcab3fe8a420a5e0639983a2f2d90536c31d743acfc86a1260ad3f"
    :COMPRESSED-BYTES 1873 :COMPRESSED-SHA256
    "e5e456726f09575bf7c74f923e2a88be71b02c38f435251508831f88962bf35a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/7-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6053 :STORED-BYTES 2187 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-1.lisp.gz" :UNCOMPRESSED-BYTES 6053 :UNCOMPRESSED-SHA256
    "56966ca1f6ca3fd47ef1f31f0680ded64b7b7db67cfbd2f4214f583eeb8f2a96"
    :COMPRESSED-BYTES 1878 :COMPRESSED-SHA256
    "3e9bc6dc0fe95845133f1ad080645cdca153023218ad05cd87720750535415bc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/7-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5997 :STORED-BYTES 2200 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-0.lisp.gz" :UNCOMPRESSED-BYTES 5997 :UNCOMPRESSED-SHA256
    "d6bb77f7e5c8598c42e132b1df7003efb47dc74bc4d9e2c7d88259060c69e940"
    :COMPRESSED-BYTES 1891 :COMPRESSED-SHA256
    "a279d81e5eb0b9b4ba13d3c6771d502035eb1dea40839088bbf7f943b7413822"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8278 :STORED-BYTES 3217 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 8278 :UNCOMPRESSED-SHA256
    "a466ead9504fa6658755c8558d41a4f88e3cf7628100cbddf3068e3510f538db"
    :COMPRESSED-BYTES 2908 :COMPRESSED-SHA256
    "cc5e16ea16ece1755cfda0c6f39f1149131c2a520138f6b83bba56706e4d35dd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8316 :STORED-BYTES 3208 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 8316 :UNCOMPRESSED-SHA256
    "c718c4a7ebb9efb890783d7a3fdf99cd5e82f9f7f34c611f8b323f5471af5624"
    :COMPRESSED-BYTES 2899 :COMPRESSED-SHA256
    "aa5e4ead6b5901ae32b60df504b32136630d79ef2731b5b8ce23f6b96028e267"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8162 :STORED-BYTES 3247 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 8162 :UNCOMPRESSED-SHA256
    "68d1e7a818ba4813d2e54de69511fc44aca066483446d39bdfd19310c81b8eac"
    :COMPRESSED-BYTES 2938 :COMPRESSED-SHA256
    "e324f1b951fde0567d36737873fdc935a441a609fe39176ad617da99af4a8045"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7906 :STORED-BYTES 3286 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 7906 :UNCOMPRESSED-SHA256
    "0cd28820c29e65f2442d7e4b2976a8abb6bf8186c0c96a415351e38f72ae6756"
    :COMPRESSED-BYTES 2977 :COMPRESSED-SHA256
    "539fdb382b1d69940ce215b66a3197b3d7d79e0a37525319abadb1b061b91e2a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7807 :STORED-BYTES 3351 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 7807 :UNCOMPRESSED-SHA256
    "e833f88df0ef675563bee6f5831d8d57d4748018e94c4d5424af210209b343c2"
    :COMPRESSED-BYTES 3042 :COMPRESSED-SHA256
    "bc165b3a6db5699e28e5f7cb5ee4e64b332c96c616c9ed366a825cfce9df6059"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/3-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6034 :STORED-BYTES 2148 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-4.lisp.gz" :UNCOMPRESSED-BYTES 6034 :UNCOMPRESSED-SHA256
    "ece79e1713db765270680e76ffa2840416c2c6025b538435046f1fea9bf81f0f"
    :COMPRESSED-BYTES 1839 :COMPRESSED-SHA256
    "fcec77223475d45413294bde59744b0101d00b5d8b2584c0686c7bb826d06426"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/3-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6010 :STORED-BYTES 2189 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-3.lisp.gz" :UNCOMPRESSED-BYTES 6010 :UNCOMPRESSED-SHA256
    "d30ecb6edebfa0fae9a627f96947ba9bb7e23886fde4801f29c1a15ed824c3f1"
    :COMPRESSED-BYTES 1880 :COMPRESSED-SHA256
    "a1ece53f57006868074e135bd6cbc79b09a8d4f9d25e76cf8c3ce7e1e7ff179b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/3-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6023 :STORED-BYTES 2207 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-2.lisp.gz" :UNCOMPRESSED-BYTES 6023 :UNCOMPRESSED-SHA256
    "064a653ec0969f50cd9c0c1a3e72f55ba463ffe46764e9e10436d367a51ddfff"
    :COMPRESSED-BYTES 1898 :COMPRESSED-SHA256
    "d955f4194134ede2ed5e90de73bc8ba2034f5f7e246361afaf579da57cc50c0d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/3-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6024 :STORED-BYTES 2158 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-1.lisp.gz" :UNCOMPRESSED-BYTES 6024 :UNCOMPRESSED-SHA256
    "4d82cb6c0941480f0befa7be9363b177fa0bfa683ea35ae7c7c33d53615ec6d0"
    :COMPRESSED-BYTES 1849 :COMPRESSED-SHA256
    "5f1276111c5118b7e81a2e9291b1d71c937a15726c00a1049896b52672b92bb5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/3-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5990 :STORED-BYTES 2141 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-0.lisp.gz" :UNCOMPRESSED-BYTES 5990 :UNCOMPRESSED-SHA256
    "8471a66695f2a22a0394d9f8ad5953fe7e30f5eba27d8fa127d3988dd419fc80"
    :COMPRESSED-BYTES 1832 :COMPRESSED-SHA256
    "277ce324a864290f9035c233616cc13e6cee3c52541790f48812536eef0cb540"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/12-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8185 :STORED-BYTES 3343 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-4.lisp.gz" :UNCOMPRESSED-BYTES 8185 :UNCOMPRESSED-SHA256
    "856415fb68f6c238ba5fa192497637959e209e2359bde583ff2fae9ac5dba39a"
    :COMPRESSED-BYTES 3033 :COMPRESSED-SHA256
    "cb949e742ccc27eed377bad51b4aab2754fff6231ed32bcaee2f89c56f53222e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/12-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8182 :STORED-BYTES 3340 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-3.lisp.gz" :UNCOMPRESSED-BYTES 8182 :UNCOMPRESSED-SHA256
    "8f611819e4c17e5e7c1dcebc111cc0cf0f4a21f61e37f773a658185887879f2d"
    :COMPRESSED-BYTES 3030 :COMPRESSED-SHA256
    "81a24ecb971768cfd88c49862a4d073d535d3a55f40c57cd76ade5b6a9eaae28"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/12-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7949 :STORED-BYTES 3293 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-2.lisp.gz" :UNCOMPRESSED-BYTES 7949 :UNCOMPRESSED-SHA256
    "ff2c91bc7c2d91596af664a22602ee243fce2ec7d33556a781c01c363a4bdcd8"
    :COMPRESSED-BYTES 2983 :COMPRESSED-SHA256
    "bfd351623b37fa814c91e4fca19bbc608c5db0ac72ea9a79456ce62627db140a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/12-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7802 :STORED-BYTES 3495 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-1.lisp.gz" :UNCOMPRESSED-BYTES 7802 :UNCOMPRESSED-SHA256
    "de027a1af3bdc5514c65f1202071792c53f40305e2974b429c557284336a0491"
    :COMPRESSED-BYTES 3185 :COMPRESSED-SHA256
    "44cf08efe9af8802eb8afb2ad7e5066cb593dd3f377544156fdf60c8070f882a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/12-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7775 :STORED-BYTES 3525 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-0.lisp.gz" :UNCOMPRESSED-BYTES 7775 :UNCOMPRESSED-SHA256
    "4a0ac901461fedf36919753a49bcb6dc31f2301be6f7ef10b4f2621315cd971b"
    :COMPRESSED-BYTES 3215 :COMPRESSED-SHA256
    "03f81be5a40c65fc5cc865ea65e22fdca9be229dead32ddc4ccce89fb9e08724"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/11-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8382 :STORED-BYTES 3304 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-4.lisp.gz" :UNCOMPRESSED-BYTES 8382 :UNCOMPRESSED-SHA256
    "627c47c8a7fced5c29c2d2b1623a062e10a5c70912a72e83e10cf0c62e2e7262"
    :COMPRESSED-BYTES 2994 :COMPRESSED-SHA256
    "571dea0e146bd2155c1b84b93c459e34b0d666a1511d25238295a30a2b56c2aa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/11-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8397 :STORED-BYTES 3301 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-3.lisp.gz" :UNCOMPRESSED-BYTES 8397 :UNCOMPRESSED-SHA256
    "53f010569528269eb679f750a553a7a47f9fd08b04451343ccaf1991cda681ef"
    :COMPRESSED-BYTES 2991 :COMPRESSED-SHA256
    "104c5b3520e960e132d24d3676091b64e36bde1c2eb9f76fc5c0f12989e972d0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/11-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8257 :STORED-BYTES 3297 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-2.lisp.gz" :UNCOMPRESSED-BYTES 8257 :UNCOMPRESSED-SHA256
    "ec79a87afbd5c11969642c35e21e2b5a23fe9577b3ecaf47eec5cec19747c2f0"
    :COMPRESSED-BYTES 2987 :COMPRESSED-SHA256
    "a1adbfbe24f325df9b66fdd4f999b73704cf4d5af724ff2631494505c886dbb8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/11-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8005 :STORED-BYTES 3282 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-1.lisp.gz" :UNCOMPRESSED-BYTES 8005 :UNCOMPRESSED-SHA256
    "2e00fac567772e10543263e0c834847476953f4f98632c7c69b19cad15caaa9b"
    :COMPRESSED-BYTES 2972 :COMPRESSED-SHA256
    "2131c154d7950e94bc86b30abce979f42465a6ae3dc12f6baf141d1c405fb34d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/11-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7924 :STORED-BYTES 3373 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-0.lisp.gz" :UNCOMPRESSED-BYTES 7924 :UNCOMPRESSED-SHA256
    "9d9c71d4c3d3f5e8ca737f69a32dca7b4f638d83bf7fcf0729594d089e5a038f"
    :COMPRESSED-BYTES 3063 :COMPRESSED-SHA256
    "b1596c057214063dba7aa6717edca1e733f68c31a232a4047c942b413fe95ee4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/10-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8254 :STORED-BYTES 3471 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-4.lisp.gz" :UNCOMPRESSED-BYTES 8254 :UNCOMPRESSED-SHA256
    "599f40e6097d6de5a5f22291f3aa92ba2efa521cd68c175dd51ef19547c47ea8"
    :COMPRESSED-BYTES 3161 :COMPRESSED-SHA256
    "7f9edfab6e67c8599060e348570a618399f896daea700c5c5f77c8a72f6f09f5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/10-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8305 :STORED-BYTES 3457 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-3.lisp.gz" :UNCOMPRESSED-BYTES 8305 :UNCOMPRESSED-SHA256
    "fd08720d668f68b5733f0b581db58b4e70de0e6aabaa65767eedb59e422bf3e8"
    :COMPRESSED-BYTES 3147 :COMPRESSED-SHA256
    "564e630355b3937814e4847bc4b7655a13091cd790ee58737c665b8832b0be62"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/10-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8118 :STORED-BYTES 3476 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-2.lisp.gz" :UNCOMPRESSED-BYTES 8118 :UNCOMPRESSED-SHA256
    "6d1593664c0232f165a1e58fe0e018414ab08934c0ff21bb5e63aa7cf7719698"
    :COMPRESSED-BYTES 3166 :COMPRESSED-SHA256
    "a48975f7188dc1921d6ee563f1025a32e06113129a41ec24f6671cb0716d33d8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/10-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7857 :STORED-BYTES 3461 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-1.lisp.gz" :UNCOMPRESSED-BYTES 7857 :UNCOMPRESSED-SHA256
    "14dad26bc211d023dacd1af05a6a3bd02a947c3e087d02bb2904d1035f3bcf8d"
    :COMPRESSED-BYTES 3151 :COMPRESSED-SHA256
    "936770056ac3e6ebb1bec6bad2621bb5b15b4997186cd7eceff9651fab90392e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/baseline/windows/10-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7786 :STORED-BYTES 3420 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-0.lisp.gz" :UNCOMPRESSED-BYTES 7786 :UNCOMPRESSED-SHA256
    "e71ddcb676886234139980199b5c04ec07ed2221f2605bba36a0b07e644bd3f1"
    :COMPRESSED-BYTES 3110 :COMPRESSED-SHA256
    "dd2bf906514670ac4bc9b5a4d2e7e7db2e09c28a31ae19242244c2a16d7ca4fa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/server-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8128 :STORED-BYTES 2119 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-4.lisp.gz" :UNCOMPRESSED-BYTES 8128 :UNCOMPRESSED-SHA256
    "a28ae8ca2ba7e4c6b46f10e218fb63f1939989529001dce3ef29371e6cb6d63b"
    :COMPRESSED-BYTES 1805 :COMPRESSED-SHA256
    "b0ffe73aa39229691a58ff9fae14af24b8e109167e94a849ee3716b2b7c92a03"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/server-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5210 :STORED-BYTES 1363 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-3.lisp.gz" :UNCOMPRESSED-BYTES 5210 :UNCOMPRESSED-SHA256
    "ad36043a07fc405c6e45fbda0d5fc0f179f09120cab0d0788d43d029a35c8b1f"
    :COMPRESSED-BYTES 1049 :COMPRESSED-SHA256
    "b44a219ef42772001fef4e52a2a1c6489ed68bb3409da33c77adcba9dc682731"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/server-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8181 :STORED-BYTES 1970 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-2.lisp.gz" :UNCOMPRESSED-BYTES 8181 :UNCOMPRESSED-SHA256
    "d06a490a5d7fdda4d0ff79dbc2dc7b2fcec0289276f21aebb3129eec26cabd7d"
    :COMPRESSED-BYTES 1656 :COMPRESSED-SHA256
    "5fa0fbfe65efa1c6eaa4fd7b06b057f6efdef9a3735f502b333e98100b1595d3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/server-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5211 :STORED-BYTES 1245 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-1.lisp.gz" :UNCOMPRESSED-BYTES 5211 :UNCOMPRESSED-SHA256
    "83ad2d6fbab82bc2ad2f5c566ec88d9151f4e18fcbb3b918594dee98155fb1ab"
    :COMPRESSED-BYTES 932 :COMPRESSED-SHA256
    "6df079e19ae83238c22efc5e57ab66a04e6f4c1ca7ba24b343fbb8e5b4831db0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/child-logs/004-latency-4.stderr"
   :STATUS :OK :ORIGINAL-BYTES 7994 :STORED-BYTES 2056 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "004-latency-4.stderr.gz" :UNCOMPRESSED-BYTES 7994 :UNCOMPRESSED-SHA256
    "b8028b3eceba6adb011ee5f6afa55dd55b62602daa4928798607605c80a3211b"
    :COMPRESSED-BYTES 1735 :COMPRESSED-SHA256
    "d4eaba56ecea3ef60791c9d38d8e400aa966c5af4cdc3426d2c56cc60fba9703"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/child-logs/003-latency-3.stderr"
   :STATUS :OK :ORIGINAL-BYTES 5076 :STORED-BYTES 1307 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "003-latency-3.stderr.gz" :UNCOMPRESSED-BYTES 5076 :UNCOMPRESSED-SHA256
    "889662ef86793c8506fc3ad69e2843e9e9394750a9dd86eb30b54b4e26139038"
    :COMPRESSED-BYTES 987 :COMPRESSED-SHA256
    "7c9280ee46962f513f4e3600680ae2f32b83412421c80a026eeb815ae3280720"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 8044 :STORED-BYTES 1908 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 8044 :UNCOMPRESSED-SHA256
    "76f2c47b404fef4a2a534d483832087f4cea4639dec20203767c83c20f96f7e4"
    :COMPRESSED-BYTES 1587 :COMPRESSED-SHA256
    "780cbf9859e396add2db3fc70857ff54f8d68983c09b6c03efc56751b1913753"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 5074 :STORED-BYTES 1183 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 5074 :UNCOMPRESSED-SHA256
    "d5b2d8a906a77d7d0d31a53a93582ac39f8ec07befd7ae3ff8b99f0d0b7e72d4"
    :COMPRESSED-BYTES 863 :COMPRESSED-SHA256
    "a00672d2767f41d11365528f487e73d42581c221ab919e6f0f8963f366c491f3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/windows/4-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7659 :STORED-BYTES 3318 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-5.lisp.gz" :UNCOMPRESSED-BYTES 7659 :UNCOMPRESSED-SHA256
    "cdb1226b059e8cc88f830137c1bc87cc33f875b222c2c49efda0ee07fa58c2cc"
    :COMPRESSED-BYTES 3009 :COMPRESSED-SHA256
    "2a24a43ccf877c44b622f06f9608b7f18c81aaa8837a2d3d4512bfcc8c1525f8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7658 :STORED-BYTES 3302 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 7658 :UNCOMPRESSED-SHA256
    "d11b8786f02a08f0001b430af9de6acb5345435ea46ce56ff9d481b5cfccfb37"
    :COMPRESSED-BYTES 2993 :COMPRESSED-SHA256
    "a9cbb1cf0f764e995ca411d34de72e3b423e065a6e0d9256f1a374f2f63d9b2c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7656 :STORED-BYTES 3272 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 7656 :UNCOMPRESSED-SHA256
    "1ac3aa64633471f6f2ee2b4fb5abf5030ebf4a0490d8373fd1cb6f07f74df3fe"
    :COMPRESSED-BYTES 2963 :COMPRESSED-SHA256
    "48c52430c01a8f9afdcbbe07438e675f6165e52325bbba67a5a00f118e884a10"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7522 :STORED-BYTES 3281 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 7522 :UNCOMPRESSED-SHA256
    "de2e52f1668d5d7fb8503e67e0a479a8c2d814c456fcab85b2838b3adabdc3e0"
    :COMPRESSED-BYTES 2972 :COMPRESSED-SHA256
    "34138b241b5d90907a8ed69bc5baecc58a28f2d1e111eeade2a9eda3edad9b4c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7270 :STORED-BYTES 3314 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 7270 :UNCOMPRESSED-SHA256
    "89ce38c88a54d6c7831ec533096902807af9655916255e5682f659c526394bd7"
    :COMPRESSED-BYTES 3005 :COMPRESSED-SHA256
    "b157253d17b65996b7dbc673de7842ec4a180d2f25b428dfaaee4e70e69d1018"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7220 :STORED-BYTES 3339 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 7220 :UNCOMPRESSED-SHA256
    "078874f8bf44188b423e111ca6101e1f4429dfcd18e43c8f4cf3836bde9589f5"
    :COMPRESSED-BYTES 3030 :COMPRESSED-SHA256
    "78052b2fcaf15251af8e598b67ddd66e7b9d08072d2e63c91f5a867c8eedd965"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/windows/2-5.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7657 :STORED-BYTES 2969 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-5.lisp.gz" :UNCOMPRESSED-BYTES 7657 :UNCOMPRESSED-SHA256
    "d26eb989b9124c452c9b4176dc7c6507b5b000168e361e4eca81819ac6ca3001"
    :COMPRESSED-BYTES 2660 :COMPRESSED-SHA256
    "f49a76dcffab5c8fb4b9286af09d14bdad974ddce5041c4a5c5763513ec9f65e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7667 :STORED-BYTES 3064 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 7667 :UNCOMPRESSED-SHA256
    "b5a42cd9685cd4916ddc44f20f7e8266d26c1947bd6b831b5f8bd7bfd9d76687"
    :COMPRESSED-BYTES 2755 :COMPRESSED-SHA256
    "735af78360ab2b9717a08268f980177f7404a167ed360f6bf67e5cdc8b4c22b2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7659 :STORED-BYTES 3007 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 7659 :UNCOMPRESSED-SHA256
    "521b3b2b412890e2d8ce54c7a80958038c0ebdae8ad46cbaa2c6be6f2351fa9d"
    :COMPRESSED-BYTES 2698 :COMPRESSED-SHA256
    "39f748ff80f88988844acd2509891658c99983f4beaef86738c791dec79851fb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7529 :STORED-BYTES 3012 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 7529 :UNCOMPRESSED-SHA256
    "0fc3ac067a756351202f9200ef0963b4567f2efc6bb990d104466bafe083655f"
    :COMPRESSED-BYTES 2703 :COMPRESSED-SHA256
    "54eeba8a8dbd3db19a521f0ec8a38aa3a0a1986368cc8987a122c6b71e948519"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7263 :STORED-BYTES 3249 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 7263 :UNCOMPRESSED-SHA256
    "bbd685f3c869e697ec2321ff07927a5cef4ad02ba11176bf4f020174a44d8379"
    :COMPRESSED-BYTES 2940 :COMPRESSED-SHA256
    "7a4e8836eb950fcdc046e52dd1a0c48d55f853d38a19249ca56851daaa9f3f9d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-calibration/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7242 :STORED-BYTES 3295 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 7242 :UNCOMPRESSED-SHA256
    "5bdab2187ef5fd3e184cee0f7df6d5d45c63ada206e784e867628ac5e6d75bd3"
    :COMPRESSED-BYTES 2986 :COMPRESSED-SHA256
    "24194164eff22137e7c67e5fc99c2b0efe6c24062d6f8f5a67da6abc9685e532"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/server-9.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8431 :STORED-BYTES 2725 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-9.lisp.gz" :UNCOMPRESSED-BYTES 8431 :UNCOMPRESSED-SHA256
    "a90d0940f733f173468fac9f04613aa8e62978bd46e2186fbb78f818ff8d9bfb"
    :COMPRESSED-BYTES 2411 :COMPRESSED-SHA256
    "4a1a846776066e9abd88096fe1b124f7ad1e05fa53211eff5d758b43f33dd046"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/server-8.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7621 :STORED-BYTES 2571 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-8.lisp.gz" :UNCOMPRESSED-BYTES 7621 :UNCOMPRESSED-SHA256
    "96a4f60a22c1c7f6f0cc4f3f3baa39f27a8ae41a6201895bf2a077cb141e7da4"
    :COMPRESSED-BYTES 2257 :COMPRESSED-SHA256
    "236d80b91b06f56fa9f0d103736ccdc62bf8566a096c0ab2a6f810beafe47881"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/server-7.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4424 :STORED-BYTES 1442 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-7.lisp.gz" :UNCOMPRESSED-BYTES 4424 :UNCOMPRESSED-SHA256
    "8090e50077c7db4dde47101933066b7c0c8cbb688a1a0e7ddd6184de6b21efc9"
    :COMPRESSED-BYTES 1128 :COMPRESSED-SHA256
    "69d41f6c8b3d9809ad04ade7aaf1d9e8b289663bea044d2323aa01780c22c8f8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/server-6.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4739 :STORED-BYTES 1494 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-6.lisp.gz" :UNCOMPRESSED-BYTES 4739 :UNCOMPRESSED-SHA256
    "ec3fa4f1ad3e4e0b944f475dbff1124b0c9e060398a8fe9d93874b2d0e423794"
    :COMPRESSED-BYTES 1180 :COMPRESSED-SHA256
    "ec13f2db24e2848e2849429d5a72ead8222982f973110fa9e820e4703b228ccd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/server-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7806 :STORED-BYTES 2431 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-4.lisp.gz" :UNCOMPRESSED-BYTES 7806 :UNCOMPRESSED-SHA256
    "818848c271334ac6a726b7811940b290eb661a148930e48c6b03d84746a19499"
    :COMPRESSED-BYTES 2117 :COMPRESSED-SHA256
    "7f286dbe36ef610472c60368f08d2c008f420479b1d186424544b04741948422"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/server-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4408 :STORED-BYTES 1334 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-3.lisp.gz" :UNCOMPRESSED-BYTES 4408 :UNCOMPRESSED-SHA256
    "2a7347d02c2b2838d9bd3d431d981827c2bb4a006bedc528a54c75fc077e9d60"
    :COMPRESSED-BYTES 1020 :COMPRESSED-SHA256
    "535cd0598425e7d2a7163c4ed8c2e1f0e26f256a7d6856d8738fb196ab4a483d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/server-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4745 :STORED-BYTES 1449 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-2.lisp.gz" :UNCOMPRESSED-BYTES 4745 :UNCOMPRESSED-SHA256
    "4dad2cbeb4c140f6dff18985f9899a2de96c1eb56b588d9e5f1b30ca5706466f"
    :COMPRESSED-BYTES 1135 :COMPRESSED-SHA256
    "83d17fed8ca57f6479b5cd3179778537f2654e5fc6c6fc0564e3da712e826a86"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/server-12.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17082 :STORED-BYTES 4806 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-12.lisp.gz" :UNCOMPRESSED-BYTES 17082 :UNCOMPRESSED-SHA256
    "2831d76d95eaf9b61b2bb6eb2d2bbf5d83bb1c08e754b6321e279cf2d9da0ae6"
    :COMPRESSED-BYTES 4490 :COMPRESSED-SHA256
    "585265137a531ed2a55de1cbd7fa3df148207c8b54f03db6121351444e4a8ab1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/server-11.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17053 :STORED-BYTES 4588 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-11.lisp.gz" :UNCOMPRESSED-BYTES 17053 :UNCOMPRESSED-SHA256
    "0b4fb39b75dcf482bc0c6353dbcc7b48a54b77d97087e419165133f71b6fba92"
    :COMPRESSED-BYTES 4272 :COMPRESSED-SHA256
    "d3d375ba59023e19ca1adaa0619076e906e4dea6eead6d0c7e6cac54c3973432"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/server-10.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9100 :STORED-BYTES 3126 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-10.lisp.gz" :UNCOMPRESSED-BYTES 9100 :UNCOMPRESSED-SHA256
    "76b61b3cf5c4ccbb121ea5e3239cdbcdad48978c2b19d563b86802256f7a9c33"
    :COMPRESSED-BYTES 2811 :COMPRESSED-SHA256
    "b1993d21a3b37a13b05ddf9baa0085330fb5ac63f85abc953ae8ab51526e4a0a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9730 :STORED-BYTES 2020 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 9730 :UNCOMPRESSED-SHA256
    "2073c1143d89fc59dc3ed885eaf01d44474ce5eced0bed353cea4fba06ac879b"
    :COMPRESSED-BYTES 1705 :COMPRESSED-SHA256
    "e95d340195d9f62742e13a2f979453dbe53fdc65d7e02b6c32d9796874fc503e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9520 :STORED-BYTES 1890 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 9520 :UNCOMPRESSED-SHA256
    "77c12b03fc70224ca30aa1e55c7c189fd2cf5dff87007f819e275b1c9db0fb92"
    :COMPRESSED-BYTES 1572 :COMPRESSED-SHA256
    "9681285dfbfb86462b8e5ee057a390a703751768a4f91b698c0e8946dff4ab4e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/child-logs/012-latency-12.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16946 :STORED-BYTES 4735 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "012-latency-12.stderr.gz" :UNCOMPRESSED-BYTES 16946 :UNCOMPRESSED-SHA256
    "ba00069d48c4883e2ba296b57e9e9e1fc9227d3763a5aaa083c6358c4b7bda73"
    :COMPRESSED-BYTES 4412 :COMPRESSED-SHA256
    "9a6c7d8c2cd0e2aa74a4a62afb7f396308e14ff8496351a8304388537935ae75"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/child-logs/011-latency-11.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16914 :STORED-BYTES 4517 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "011-latency-11.stderr.gz" :UNCOMPRESSED-BYTES 16914 :UNCOMPRESSED-SHA256
    "b04565bae0d4ca2837d5de7ba15a2bbed158746406abb1c21358b58617b3f500"
    :COMPRESSED-BYTES 4194 :COMPRESSED-SHA256
    "3c72b51d7f716e93e642d2f114b5e05d4c02cfe72caae85b86183de537528df0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/child-logs/010-latency-10.stderr"
   :STATUS :OK :ORIGINAL-BYTES 8966 :STORED-BYTES 3053 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "010-latency-10.stderr.gz" :UNCOMPRESSED-BYTES 8966 :UNCOMPRESSED-SHA256
    "62656c8b4c6af0634dcc4ad3e827904edf3dc916992b27647c487887023cae1b"
    :COMPRESSED-BYTES 2731 :COMPRESSED-SHA256
    "5c99b9375e9d083b9c3d4002568f7ad90685f0b396311980cb053cbdd12bef61"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/child-logs/009-latency-9.stderr"
   :STATUS :OK :ORIGINAL-BYTES 8294 :STORED-BYTES 2662 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "009-latency-9.stderr.gz" :UNCOMPRESSED-BYTES 8294 :UNCOMPRESSED-SHA256
    "ddec303b74c45e5ec6c85a2ae714d41a7a4bbe2d3508a32e5bbb817f5ec39eed"
    :COMPRESSED-BYTES 2341 :COMPRESSED-SHA256
    "684212be336c7f40045022d3de1ed5e77c2041ac06b8299650a294bb277087da"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/child-logs/008-latency-8.stderr"
   :STATUS :OK :ORIGINAL-BYTES 7485 :STORED-BYTES 2508 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "008-latency-8.stderr.gz" :UNCOMPRESSED-BYTES 7485 :UNCOMPRESSED-SHA256
    "9e6c7441b7b7b2bb01eac20adab72875e9270e540d114d5653a35a6f3b4c146d"
    :COMPRESSED-BYTES 2187 :COMPRESSED-SHA256
    "d6a4d01c86e048341abbdc79b26e70dc722e0b4bc7458de77552689c9f145a90"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/child-logs/007-latency-7.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4289 :STORED-BYTES 1385 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "007-latency-7.stderr.gz" :UNCOMPRESSED-BYTES 4289 :UNCOMPRESSED-SHA256
    "913de38af91cbf57c57ab78ed2cbf65d4b3dab6a8f58681346cc84c282345072"
    :COMPRESSED-BYTES 1064 :COMPRESSED-SHA256
    "e577da64312a1a16133babd734ddb176929db5726a1e146473459fe0e0a1a1b0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/child-logs/006-latency-6.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4603 :STORED-BYTES 1437 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "006-latency-6.stderr.gz" :UNCOMPRESSED-BYTES 4603 :UNCOMPRESSED-SHA256
    "b1b0e5f25ba9a41c780e8b43d3872641a9b5e1ee4bcbb65ad00c2d0c637ddd02"
    :COMPRESSED-BYTES 1116 :COMPRESSED-SHA256
    "bf233568753b37a0089500a29a162ae42a7a036c7f5e03e5743117b0a33ff689"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/child-logs/005-latency-5.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2969 :STORED-BYTES 898 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "005-latency-5.stderr.gz" :UNCOMPRESSED-BYTES 2969 :UNCOMPRESSED-SHA256
    "691f06d9a15f1dc46f18acb9ea56c9d0d42962f172744bd415b6949c6d9aa809"
    :COMPRESSED-BYTES 578 :COMPRESSED-SHA256
    "f4019668d34b3caf55312838c875baf49f7922ae0957ea10e1469b9b159f0910"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/child-logs/004-latency-4.stderr"
   :STATUS :OK :ORIGINAL-BYTES 7667 :STORED-BYTES 2368 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "004-latency-4.stderr.gz" :UNCOMPRESSED-BYTES 7667 :UNCOMPRESSED-SHA256
    "a9d1622c9e4d640a4188bae6346553d152fd957175897336627db141305864f0"
    :COMPRESSED-BYTES 2047 :COMPRESSED-SHA256
    "47b3fa6e6da50de9f15664aa3e95cdcf46c01b56af9248c71da588e060535fa4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/child-logs/003-latency-3.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4270 :STORED-BYTES 1276 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "003-latency-3.stderr.gz" :UNCOMPRESSED-BYTES 4270 :UNCOMPRESSED-SHA256
    "c3640d767bf3851233734ac6b8d7899b6557417c6135a6e8745d13e911cf5e67"
    :COMPRESSED-BYTES 956 :COMPRESSED-SHA256
    "a42e0b4e70b59d44f0ca5e7e382178f9034769b733a2794a86566241808527b0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4606 :STORED-BYTES 1389 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 4606 :UNCOMPRESSED-SHA256
    "8eb67e7c978f774862edc3bafed12685b94583f2bc11ea71b598d29c312dbca9"
    :COMPRESSED-BYTES 1068 :COMPRESSED-SHA256
    "a493c4e85fa5cc5d2fd2240b9ca383d439da669c2f520c1d56a7eb24803167cc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2982 :STORED-BYTES 846 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 2982 :UNCOMPRESSED-SHA256
    "8ff0959e43ba96c7b8a6f012944423ec3577b9ddafe8ed0e2de33a4e572430bb"
    :COMPRESSED-BYTES 526 :COMPRESSED-SHA256
    "2ba5c51e1e87e72e245742dcb77b0d4deabe6180c8732fb61e45948aa14f87bb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/9-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7700 :STORED-BYTES 3235 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-4.lisp.gz" :UNCOMPRESSED-BYTES 7700 :UNCOMPRESSED-SHA256
    "569cffaf7dcd7811529cb4142d9dd5bd5a758fcd435a9b0baddfd36e45441016"
    :COMPRESSED-BYTES 2926 :COMPRESSED-SHA256
    "c4afc684e4878286cee68c0cf13473b5fb1894719b95b5d41c785ff7ea618b2a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/9-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7694 :STORED-BYTES 3241 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-3.lisp.gz" :UNCOMPRESSED-BYTES 7694 :UNCOMPRESSED-SHA256
    "f508265c753b09780bcc4d9bf04794ff1b7142e4ecd45bdbfa3c60eee03630d1"
    :COMPRESSED-BYTES 2932 :COMPRESSED-SHA256
    "bec0f0ed38f69292303e5ca38030c55cbeca6d3d846f35a411cd519d3bf9f90c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/9-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7558 :STORED-BYTES 3183 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-2.lisp.gz" :UNCOMPRESSED-BYTES 7558 :UNCOMPRESSED-SHA256
    "c4085a5b8e99778c04d0007316c0ffc930ce26f94aa4859460c60ed7ddf4f8fa"
    :COMPRESSED-BYTES 2874 :COMPRESSED-SHA256
    "038e886cc2e4813aff721bc9628dce028663ef0699388d6d70bdff78c36a18c7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/9-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7311 :STORED-BYTES 3286 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-1.lisp.gz" :UNCOMPRESSED-BYTES 7311 :UNCOMPRESSED-SHA256
    "89542220da7b1cf7cb7aaf8548edae0f6240499778684593a3869132cdd3c302"
    :COMPRESSED-BYTES 2977 :COMPRESSED-SHA256
    "a080448146c0057b23ab3945f57e11777cc539469ebb263860809d28fecf0fa5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/9-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7262 :STORED-BYTES 3175 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-0.lisp.gz" :UNCOMPRESSED-BYTES 7262 :UNCOMPRESSED-SHA256
    "2a98c06a6d5fb8eb5ff5275a2592ac5213d91c9ff52adbc7d8f916cef122f8f6"
    :COMPRESSED-BYTES 2866 :COMPRESSED-SHA256
    "0bdea9701301b51a52a1b9b88034da4f2d62beeb7def8b15b82bcf87741970f1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7658 :STORED-BYTES 3299 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 7658 :UNCOMPRESSED-SHA256
    "c8e32d91945f1ae0e12b0daa43e895ea99315b8f2b14edc276a43071e24672b0"
    :COMPRESSED-BYTES 2990 :COMPRESSED-SHA256
    "aa2cace754fea3895f6b6576c530a682cd4b587657482e5f413934e3f0dc72df"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7660 :STORED-BYTES 3238 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 7660 :UNCOMPRESSED-SHA256
    "a0481d54f27b1332714b00498fb170ffc0ad6425e83de68df9185793071bb243"
    :COMPRESSED-BYTES 2929 :COMPRESSED-SHA256
    "06c87b76b4c12f7f1e7789a1c869a5c96c8ebb4af0a1ff575b01d98be6861fae"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7524 :STORED-BYTES 3235 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 7524 :UNCOMPRESSED-SHA256
    "415060100aa62db3755195c30f0b6abe166a0063ffb7a0acaf79b0f230779990"
    :COMPRESSED-BYTES 2926 :COMPRESSED-SHA256
    "e2280d67e3805a3de9e1bf6f72a5c3bdce47a1be9a90522e043d2e9c1b45479b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7258 :STORED-BYTES 3259 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 7258 :UNCOMPRESSED-SHA256
    "edd193cb8c031c3b6e0596718126e33bb80bb8637f51bafe2d97b7bbf3083eeb"
    :COMPRESSED-BYTES 2950 :COMPRESSED-SHA256
    "302838b52f71965e148abb783dfc2ef1b0defdcf9d114acf632ec0cf1327d606"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7222 :STORED-BYTES 3351 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 7222 :UNCOMPRESSED-SHA256
    "fcb1b6428678f6b6930d4e2b5ae1fa23a5f6416ed2325b672a6443b6c3cb9389"
    :COMPRESSED-BYTES 3042 :COMPRESSED-SHA256
    "17e033f0338bbc473b700525f3a919e9f9352ca3251c4766ba6449f50898198b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/7-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6026 :STORED-BYTES 2221 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-4.lisp.gz" :UNCOMPRESSED-BYTES 6026 :UNCOMPRESSED-SHA256
    "73359493f60f16b6ed334ae314c21dab854ba48d155421f94bfc4eea8eddb2cc"
    :COMPRESSED-BYTES 1912 :COMPRESSED-SHA256
    "e745e268a08e4a82a41242b8f35ef8f01369b5af3f4265efb98c9aa11f6f56ee"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/7-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6014 :STORED-BYTES 2181 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-3.lisp.gz" :UNCOMPRESSED-BYTES 6014 :UNCOMPRESSED-SHA256
    "6d3940523dd35087faf46b01d9b048813b893d414b4924ee6523fc5fd9948171"
    :COMPRESSED-BYTES 1872 :COMPRESSED-SHA256
    "c70407f5c10ca49dbb9737db7c3f972187264cfb96d6528df14357b46ad31493"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/7-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6017 :STORED-BYTES 2189 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-2.lisp.gz" :UNCOMPRESSED-BYTES 6017 :UNCOMPRESSED-SHA256
    "9132fda2504d3fd3361af612b6e6f0655fed8fafe2a89a5f12708b4c58bb811d"
    :COMPRESSED-BYTES 1880 :COMPRESSED-SHA256
    "b33c175ec2bb6f86ac97da9b68d44ecb4ebe9e269fabcbbb21512050990e8e7d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/7-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5994 :STORED-BYTES 2304 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-1.lisp.gz" :UNCOMPRESSED-BYTES 5994 :UNCOMPRESSED-SHA256
    "fa5f71c64c794693538b08c5fc50b1aa37bf83aca333394300240b9ead9c45e0"
    :COMPRESSED-BYTES 1995 :COMPRESSED-SHA256
    "4a9155ac6c5a422e0962ac02d91adda3509bf808ab64e78bd26584ba1649e58f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/7-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5946 :STORED-BYTES 2273 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-0.lisp.gz" :UNCOMPRESSED-BYTES 5946 :UNCOMPRESSED-SHA256
    "63e17646b18d31a274f847d05fb3fd9c9c6ed7067394371cc3309dae5e83f702"
    :COMPRESSED-BYTES 1964 :COMPRESSED-SHA256
    "d9310dd8688137650ab89a21302cc30272f512b411b80b18161af05bca649b06"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7671 :STORED-BYTES 3021 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 7671 :UNCOMPRESSED-SHA256
    "012011ccf4ce87014fbd4208d2dc7fcabe67ca34d7384b75553f9acad71440fb"
    :COMPRESSED-BYTES 2712 :COMPRESSED-SHA256
    "c96e293da94fc0b95e5fa4d60633f45acd16cbdea161ea85498d84baaa1ce803"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7663 :STORED-BYTES 2970 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 7663 :UNCOMPRESSED-SHA256
    "b5d9faedad444742bba026973c2bf28275ac8025720e6d9f0a1d7e2565f66204"
    :COMPRESSED-BYTES 2661 :COMPRESSED-SHA256
    "78db6ee40fa7dd4541cf85fb5849fa1921f62c266d5210beb04b8b1954923a53"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7540 :STORED-BYTES 3094 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 7540 :UNCOMPRESSED-SHA256
    "13108026b0a928e631ea682651016ee2ef87a53f38f351dfd6838a82fd08b5e2"
    :COMPRESSED-BYTES 2785 :COMPRESSED-SHA256
    "355a79ff9b62ac31ec3620ed54d7ee323f5ad6115206be7c0ae7689c560c2f91"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7266 :STORED-BYTES 3138 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 7266 :UNCOMPRESSED-SHA256
    "e901c5a186f26ac103ff9c442c32299e6fa44fbde456915bcc4dc1640d2262d5"
    :COMPRESSED-BYTES 2829 :COMPRESSED-SHA256
    "ef99098f9711beca51ba934b263cef85173ebdbc8b3e668373f9c28a64575ee5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7225 :STORED-BYTES 3173 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 7225 :UNCOMPRESSED-SHA256
    "9ac8c1d15f79020327537d678e75e03b22cc7ab68d609338929bc4492b9fe378"
    :COMPRESSED-BYTES 2864 :COMPRESSED-SHA256
    "2d174632447eb272466dbb4757e190ec650a3398b12c75168fc276ea83ff7a40"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/3-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6028 :STORED-BYTES 2102 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-4.lisp.gz" :UNCOMPRESSED-BYTES 6028 :UNCOMPRESSED-SHA256
    "0877b4a5e1120e6d9de7d2a5092e1b01795012d2c03c1688f8de46704c56b848"
    :COMPRESSED-BYTES 1793 :COMPRESSED-SHA256
    "a039c18bf2ef6d31a24035e3091c031b2d03a1b7a23d295ee4821a13bdffd2fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/3-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6027 :STORED-BYTES 2115 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-3.lisp.gz" :UNCOMPRESSED-BYTES 6027 :UNCOMPRESSED-SHA256
    "20dc1f3c78512970055a2efe280b498216d4960e42cd6a63e4ec24d83561ba6e"
    :COMPRESSED-BYTES 1806 :COMPRESSED-SHA256
    "6712ffb310ebcf3b7eb7924cb6c76368386b99eb12d11e7675c29cae3153565f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/3-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6018 :STORED-BYTES 2096 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-2.lisp.gz" :UNCOMPRESSED-BYTES 6018 :UNCOMPRESSED-SHA256
    "aeb34260c5d3aa06fb137642997996d2ae64f6ce034458c01176468cca0977f3"
    :COMPRESSED-BYTES 1787 :COMPRESSED-SHA256
    "3e90c7d2bede5aa17e7754d120c522fa58d924486f9202960bbc57501e2990c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/3-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6022 :STORED-BYTES 2164 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-1.lisp.gz" :UNCOMPRESSED-BYTES 6022 :UNCOMPRESSED-SHA256
    "f912f1d8ad0da34d5701659a903bbf93ec7e28bb2dba08bb07be7b574f35321b"
    :COMPRESSED-BYTES 1855 :COMPRESSED-SHA256
    "12aed0c424d4f91542468ab078cf8687d8284b57346485bfd0c0d80ffc4c222b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/3-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5988 :STORED-BYTES 2156 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-0.lisp.gz" :UNCOMPRESSED-BYTES 5988 :UNCOMPRESSED-SHA256
    "4aea6e944284f7c6391efc53bd59bff24d795b4280c3217bb65d2ae67394b82d"
    :COMPRESSED-BYTES 1847 :COMPRESSED-SHA256
    "1aacda9f8b11fb727a66d359e673832bd9586050cc78b90abbfed4d8428f964a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/12-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8421 :STORED-BYTES 3362 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-4.lisp.gz" :UNCOMPRESSED-BYTES 8421 :UNCOMPRESSED-SHA256
    "331b4112a010566d19952062fc56bc44b99554ba57ae63c2e0502bce89c742ce"
    :COMPRESSED-BYTES 3052 :COMPRESSED-SHA256
    "5a49c11b9e6fbf062f6665bde3c60ebb6367371692c315be1c162adc86ce1e7a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/12-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8417 :STORED-BYTES 3357 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-3.lisp.gz" :UNCOMPRESSED-BYTES 8417 :UNCOMPRESSED-SHA256
    "01e9e51676dbf3edc9423491a3e63cfc06cc93a0ff98fe0ac30bafc4aff059cc"
    :COMPRESSED-BYTES 3047 :COMPRESSED-SHA256
    "062d264e9cb8ad3e476ffdaef029cecdc251e6502728da3c250e2e792357ab8e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/12-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8291 :STORED-BYTES 3211 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-2.lisp.gz" :UNCOMPRESSED-BYTES 8291 :UNCOMPRESSED-SHA256
    "1f5579887f277554e46e9017179757c4aa5fb3da55e6d6dee4e968182c33cb02"
    :COMPRESSED-BYTES 2901 :COMPRESSED-SHA256
    "82a2cf3d1c41b388957bd1f173959a1e96a9254b0e29df3472e5c40092d2f456"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/12-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8016 :STORED-BYTES 3277 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-1.lisp.gz" :UNCOMPRESSED-BYTES 8016 :UNCOMPRESSED-SHA256
    "221662bf185b22d0ec156755247147bbc765730febea8097c2032addd867badc"
    :COMPRESSED-BYTES 2967 :COMPRESSED-SHA256
    "a48149f8aad3bc7238a085af72fce62bcf6ffdb9a05ae348dbbd83c262455fa8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/12-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7936 :STORED-BYTES 3405 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-0.lisp.gz" :UNCOMPRESSED-BYTES 7936 :UNCOMPRESSED-SHA256
    "7096673efbb8558a1ab865ea6156bb82710fe3dd34d82f744e9690ea5275ba5f"
    :COMPRESSED-BYTES 3095 :COMPRESSED-SHA256
    "806773c18084c39a790b86ce68666d50482f1802d8fd2700c12a6c4c37517c2e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/11-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8406 :STORED-BYTES 3344 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-4.lisp.gz" :UNCOMPRESSED-BYTES 8406 :UNCOMPRESSED-SHA256
    "296a1c6c4dc195500d6cf0dfe580c9f5607bc8173563835d38b973a6efd67b16"
    :COMPRESSED-BYTES 3034 :COMPRESSED-SHA256
    "d34f233a34cdaf2ce97f5b6a072c22c4b320360ad55c9df7549bee9f5d4d8050"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/11-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8401 :STORED-BYTES 3264 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-3.lisp.gz" :UNCOMPRESSED-BYTES 8401 :UNCOMPRESSED-SHA256
    "ff734b1c864fc4d959c4e2f9e04bf11c6368caf2cb1d3f95ac9332fda742a6fc"
    :COMPRESSED-BYTES 2954 :COMPRESSED-SHA256
    "bf7236e20666e4fdc106e9fff595e741a902957eb6408462801708f5e233a520"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/11-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8261 :STORED-BYTES 3366 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-2.lisp.gz" :UNCOMPRESSED-BYTES 8261 :UNCOMPRESSED-SHA256
    "0464143cb78f4807f1855b55e47582c5f19c33af31a08d44b86e26d2a81ceaf9"
    :COMPRESSED-BYTES 3056 :COMPRESSED-SHA256
    "57158d8ad1614bea972eddfce6eddcf3e1511b4ff0c3ec2b20b7c36665b11d2b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/11-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7928 :STORED-BYTES 3380 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-1.lisp.gz" :UNCOMPRESSED-BYTES 7928 :UNCOMPRESSED-SHA256
    "390d08733bfebba59dc34c5eeb6fee9e706c68a561eb45dac5a00fc627f6292b"
    :COMPRESSED-BYTES 3070 :COMPRESSED-SHA256
    "a3334c00f2916603951019000ed4298f8358ea5bdc97bedcdb54e2cd0ce32b25"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/11-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7837 :STORED-BYTES 3391 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-0.lisp.gz" :UNCOMPRESSED-BYTES 7837 :UNCOMPRESSED-SHA256
    "7c1d38d973686b5f14de29725f78739900fd9bf60c0baadc5d22e833d23a9497"
    :COMPRESSED-BYTES 3081 :COMPRESSED-SHA256
    "fae6c17ba4d7cc9dcd14c44252d0e4b61813e19591e3336f843ceeb485a03af0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/10-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7699 :STORED-BYTES 3372 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-4.lisp.gz" :UNCOMPRESSED-BYTES 7699 :UNCOMPRESSED-SHA256
    "fdf33747de76b2905ec60b7daba25d3d7e1d9be81ee567459cede2e29d27be99"
    :COMPRESSED-BYTES 3062 :COMPRESSED-SHA256
    "729c0e3b7d5017849f33b4a6a5764461f784a91ea69939d779ca35783531bab6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/10-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7705 :STORED-BYTES 3356 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-3.lisp.gz" :UNCOMPRESSED-BYTES 7705 :UNCOMPRESSED-SHA256
    "cd6849de9ddcfe993ae02de675eaf956b47becd4771438764b1d8cb79b61b888"
    :COMPRESSED-BYTES 3046 :COMPRESSED-SHA256
    "d6061f16fb453cd9b2e34aba4deb2f13ed912c6eccc38c45dcbaabda68bc996e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/10-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7548 :STORED-BYTES 3360 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-2.lisp.gz" :UNCOMPRESSED-BYTES 7548 :UNCOMPRESSED-SHA256
    "67ee7a993b57feed93f29e16d62b6ba687ec5efba07c2eaecc47da55f8a7d105"
    :COMPRESSED-BYTES 3050 :COMPRESSED-SHA256
    "5d6bc0b4ee3e998ce151ffc118b3534cd77718f5c68c2a182911c47d8da06339"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/10-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7300 :STORED-BYTES 3341 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-1.lisp.gz" :UNCOMPRESSED-BYTES 7300 :UNCOMPRESSED-SHA256
    "cbcd10db9a2fa3e9c3b46da8972323f0147ae1b82f00b921d78e69590de632b5"
    :COMPRESSED-BYTES 3031 :COMPRESSED-SHA256
    "7a577d5164cc6012651f987c368e7340dc5245f6bc4b0b91196945187dc18fef"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate-repeat/windows/10-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7253 :STORED-BYTES 3358 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-0.lisp.gz" :UNCOMPRESSED-BYTES 7253 :UNCOMPRESSED-SHA256
    "f7f651508aed58daefc1a0046722ab28ef125b0051e74bac30e37baec0818f7b"
    :COMPRESSED-BYTES 3048 :COMPRESSED-SHA256
    "5f356e55d4426fc950887a9c8c9338d62fad0b3a3dd7f43eb25859ac670f1198"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/server-9.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8156 :STORED-BYTES 2650 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-9.lisp.gz" :UNCOMPRESSED-BYTES 8156 :UNCOMPRESSED-SHA256
    "04ad32e7acdcf2c45e1a2fe4853129199d3432cab86748ed204b107d6c5ea10a"
    :COMPRESSED-BYTES 2336 :COMPRESSED-SHA256
    "8b19536c1f78d9530d279bdeeebdcf5aeef994334851324c9a54f8295a4fed0b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/server-8.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7402 :STORED-BYTES 2547 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-8.lisp.gz" :UNCOMPRESSED-BYTES 7402 :UNCOMPRESSED-SHA256
    "153e4f63c09daca719051e5f1da13a4e330c08d1a527e991ec59795f459d90d8"
    :COMPRESSED-BYTES 2233 :COMPRESSED-SHA256
    "5b8e69250dbd6b6865a93bc7269d2e14cbb49219f5726a3a35a29519bd6f28a8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/server-7.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4425 :STORED-BYTES 1437 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-7.lisp.gz" :UNCOMPRESSED-BYTES 4425 :UNCOMPRESSED-SHA256
    "4f7a3f775684de08307801729452c8f8133aa1e9d25d238fc1ce490720ac1de7"
    :COMPRESSED-BYTES 1123 :COMPRESSED-SHA256
    "b73987c71603845eb63927c39c59f3569637081d5903e3c662c67a5a94a049f7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/server-6.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4739 :STORED-BYTES 1490 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-6.lisp.gz" :UNCOMPRESSED-BYTES 4739 :UNCOMPRESSED-SHA256
    "9e8dc46d7c5d9c2fb239957382cedc32543791cb3269dbc368b5149f6f493a86"
    :COMPRESSED-BYTES 1176 :COMPRESSED-SHA256
    "a14adfd6c8607dbcb60b2873f41051b057e63ee94d10aeda149ff65c818f032a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/server-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7758 :STORED-BYTES 2419 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-4.lisp.gz" :UNCOMPRESSED-BYTES 7758 :UNCOMPRESSED-SHA256
    "581703a5469325fc4c2b01b19db02044fc23fb29eaed764618a15f8bf7d344d8"
    :COMPRESSED-BYTES 2105 :COMPRESSED-SHA256
    "67b8b694199d7ff3cf65e6c46a3a035da5cf4b265e0253d888f25fffa4be510c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/server-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4408 :STORED-BYTES 1331 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-3.lisp.gz" :UNCOMPRESSED-BYTES 4408 :UNCOMPRESSED-SHA256
    "5d7a58382bb980f520106ead1581095291456058d2fe0c097ab9f3f15e129230"
    :COMPRESSED-BYTES 1017 :COMPRESSED-SHA256
    "3374755d9322e2c8a48c956ad94c35089fd65d5570a2c6154bbed4426bfc637f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/server-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4745 :STORED-BYTES 1429 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-2.lisp.gz" :UNCOMPRESSED-BYTES 4745 :UNCOMPRESSED-SHA256
    "5000f129c0e2f926d0583d8efa3ed2776c135d2f2931880e27e0a6a16c152655"
    :COMPRESSED-BYTES 1115 :COMPRESSED-SHA256
    "ec0c769a13a20b51a140e5f6c70db89812892a35e2cba22e90363f1cba6caa46"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/server-12.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17079 :STORED-BYTES 4910 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-12.lisp.gz" :UNCOMPRESSED-BYTES 17079 :UNCOMPRESSED-SHA256
    "fe50c1dcd6a08d0ce1bd3e729f38655d761c936843822cb7727ff4fc5620e841"
    :COMPRESSED-BYTES 4594 :COMPRESSED-SHA256
    "f6810d1ee5b6e1b3f75e17c7402b88211ac6131b698c5f3f46b8df79e2c4b618"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/server-11.lisp"
   :STATUS :OK :ORIGINAL-BYTES 17053 :STORED-BYTES 4553 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-11.lisp.gz" :UNCOMPRESSED-BYTES 17053 :UNCOMPRESSED-SHA256
    "2d3096d22791ecf30230903e98f6f4b3746852ad34f0a04321825bd29a8a074d"
    :COMPRESSED-BYTES 4237 :COMPRESSED-SHA256
    "4aad144b29d6d7b91667c5389adddee999cd81208342dfb78efb223b984297a0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/server-10.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9066 :STORED-BYTES 3085 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server-10.lisp.gz" :UNCOMPRESSED-BYTES 9066 :UNCOMPRESSED-SHA256
    "933c5d82c173fdc86daa0c50fbddf316a9cd8a8b6e1967c0a7471fb7cbd1ad64"
    :COMPRESSED-BYTES 2770 :COMPRESSED-SHA256
    "f0b1c910f26a5ce873929e5b54c2f16139f53386620849e760d26f8589146608"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/completed.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9555 :STORED-BYTES 2012 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "completed.lisp.gz" :UNCOMPRESSED-BYTES 9555 :UNCOMPRESSED-SHA256
    "b268a86155221f04e7f3e05ab8e62cc872b1dab148d5b362b1abdbd0466c4bdd"
    :COMPRESSED-BYTES 1697 :COMPRESSED-SHA256
    "8c7ebff686e0fc16e612270c72abb61016e54fdd52d506d18c3326c16c4cf486"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/child-copies.lisp"
   :STATUS :OK :ORIGINAL-BYTES 9352 :STORED-BYTES 1881 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "child-copies.lisp.gz" :UNCOMPRESSED-BYTES 9352 :UNCOMPRESSED-SHA256
    "baa0dbf615370e75b7d31841e2d0e92d98db7d8547e85cb4d67b4f184bf0263a"
    :COMPRESSED-BYTES 1563 :COMPRESSED-SHA256
    "89522e5ef2c015585a669e984cef1389df84ab8171cf6c00d531981aad80061c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/child-logs/012-latency-12.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16943 :STORED-BYTES 4841 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "012-latency-12.stderr.gz" :UNCOMPRESSED-BYTES 16943 :UNCOMPRESSED-SHA256
    "312a8785840609c0caeac26c325ed43b187b414e56459ebe851ea2c1bb7d008d"
    :COMPRESSED-BYTES 4518 :COMPRESSED-SHA256
    "54009603bfa8cca9dc467895fde3f341c037dc9d5a1d0f5ee6087a7a44bb7668"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/child-logs/011-latency-11.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16914 :STORED-BYTES 4480 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "011-latency-11.stderr.gz" :UNCOMPRESSED-BYTES 16914 :UNCOMPRESSED-SHA256
    "2a0a614d7d726864e8749639cb432bc21d4ea400090a62fadf9cbe6de8d07132"
    :COMPRESSED-BYTES 4157 :COMPRESSED-SHA256
    "0f2d560d76c2f2b2dd7396b7b36f8874f8ebac48c4e02ee128222b847907cf53"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/child-logs/010-latency-10.stderr"
   :STATUS :OK :ORIGINAL-BYTES 8932 :STORED-BYTES 3017 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "010-latency-10.stderr.gz" :UNCOMPRESSED-BYTES 8932 :UNCOMPRESSED-SHA256
    "886df012c5f6b0fb8e5989306118f6997f5e7ad721db1560197ffbc315ec8b92"
    :COMPRESSED-BYTES 2695 :COMPRESSED-SHA256
    "9470633a59539dbd1c5606e09c4bdeb5b1734fb16e422cc9559f0decbff88948"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/child-logs/009-latency-9.stderr"
   :STATUS :OK :ORIGINAL-BYTES 8019 :STORED-BYTES 2586 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "009-latency-9.stderr.gz" :UNCOMPRESSED-BYTES 8019 :UNCOMPRESSED-SHA256
    "65c3605c8f5383ecbe8cbdef0444e776797a0bfc3801832d9107e95a8786be4b"
    :COMPRESSED-BYTES 2265 :COMPRESSED-SHA256
    "290526591f5a54b44e95068877bb96251efa64d044b1577febde9799b804c8bb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/child-logs/008-latency-8.stderr"
   :STATUS :OK :ORIGINAL-BYTES 7266 :STORED-BYTES 2482 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "008-latency-8.stderr.gz" :UNCOMPRESSED-BYTES 7266 :UNCOMPRESSED-SHA256
    "27a4b3c35a2462764669367778eaf7cdb791c2c6ad7a6093c2c1c50eacac3e34"
    :COMPRESSED-BYTES 2161 :COMPRESSED-SHA256
    "e9e56dfeef8c4b93ee5e6ff0d7dfef24fe2992353daa7661a6ab15f94b47eac0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/child-logs/007-latency-7.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4290 :STORED-BYTES 1380 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "007-latency-7.stderr.gz" :UNCOMPRESSED-BYTES 4290 :UNCOMPRESSED-SHA256
    "68f6c55aee6e35daef152a89769ce0c222669e4fe86bba515f43d8f684ae8af9"
    :COMPRESSED-BYTES 1059 :COMPRESSED-SHA256
    "1cf6bf9017cbe24b49cc40869eab8720aaf7073d667e683bf2073da0d0858a71"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/child-logs/006-latency-6.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4603 :STORED-BYTES 1431 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "006-latency-6.stderr.gz" :UNCOMPRESSED-BYTES 4603 :UNCOMPRESSED-SHA256
    "80aa922f274e80d6faa56443a673ba7ce0c2e9a5a93f4e97be7a207c9c5d5d59"
    :COMPRESSED-BYTES 1110 :COMPRESSED-SHA256
    "77064181cfd877e1b16fc9461091898e76d6226c518c06282c41a616a700d3a2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/child-logs/005-latency-5.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2969 :STORED-BYTES 908 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "005-latency-5.stderr.gz" :UNCOMPRESSED-BYTES 2969 :UNCOMPRESSED-SHA256
    "e9b36edb782ad28edb7b90cb2a69df973025debd8007f261a3e72d3ec5924e2b"
    :COMPRESSED-BYTES 588 :COMPRESSED-SHA256
    "37df715a77fec035a0f8708510d8036126bb336ff6d9cb82981d6a3be1834551"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/child-logs/004-latency-4.stderr"
   :STATUS :OK :ORIGINAL-BYTES 7619 :STORED-BYTES 2354 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "004-latency-4.stderr.gz" :UNCOMPRESSED-BYTES 7619 :UNCOMPRESSED-SHA256
    "7e19ba24c24f7ea4a6542616a7ad81884e803309cd0c5e8490f96d6a11b6ec7a"
    :COMPRESSED-BYTES 2033 :COMPRESSED-SHA256
    "a26db7b2dbbd8a324266a54a84956869bd51d86f2fed729c3489ad98e731b2f2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/child-logs/003-latency-3.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4270 :STORED-BYTES 1273 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "003-latency-3.stderr.gz" :UNCOMPRESSED-BYTES 4270 :UNCOMPRESSED-SHA256
    "0a263bbceb3fcc1becb82b57af8f08a61269520b2dce55499472756681429e77"
    :COMPRESSED-BYTES 953 :COMPRESSED-SHA256
    "c85265e4db663e13b61d95eb2bbf7ff6ec36ad7a6a908e1b08699578c2a1bb4b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4606 :STORED-BYTES 1370 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 4606 :UNCOMPRESSED-SHA256
    "3af57cabfee8fbdabc0f0118e528b8aa3813f8b8cde3000446fb5dec770347bc"
    :COMPRESSED-BYTES 1049 :COMPRESSED-SHA256
    "e88ef1fbad7fb282a989c997ba6ca7e4b6641c458eef7f4e4d340863511bc1e2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2983 :STORED-BYTES 847 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 2983 :UNCOMPRESSED-SHA256
    "d8ccd9a62d08c98ef9d2e68f168df9ebcd1b2f1fa56284f43db6843383ceb8b3"
    :COMPRESSED-BYTES 527 :COMPRESSED-SHA256
    "54f1f73f59da373e6e73f905c5150fffc2578f3aa1d841c04091f3568a5b2384"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/9-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7698 :STORED-BYTES 3282 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-4.lisp.gz" :UNCOMPRESSED-BYTES 7698 :UNCOMPRESSED-SHA256
    "39d769bfceaf23777a8cf994acb603644cce74842b2f9b8a31bb43e1ef0d4129"
    :COMPRESSED-BYTES 2973 :COMPRESSED-SHA256
    "73ff186b7981c045b3618e7f1d2297c6a12691805338c892f0bb1dc7731df093"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/9-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7700 :STORED-BYTES 3156 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-3.lisp.gz" :UNCOMPRESSED-BYTES 7700 :UNCOMPRESSED-SHA256
    "915893629ef34f77ffdd3d0217bea9ca4e9e11af9b27c8268ca2a3ae40120d40"
    :COMPRESSED-BYTES 2847 :COMPRESSED-SHA256
    "2d5a1c1db4ab96c364969c1a1289978965ba70029ee83958146d4816dfab5f9a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/9-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7557 :STORED-BYTES 3188 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-2.lisp.gz" :UNCOMPRESSED-BYTES 7557 :UNCOMPRESSED-SHA256
    "5aa522ab4129bdddd1356818248f58fd431426602e8aaad6307a61a09186e2a8"
    :COMPRESSED-BYTES 2879 :COMPRESSED-SHA256
    "e2218c2bcd090b216e3d097259db1f8a58bfeea4630bbf81105b198ebdd380db"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/9-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7310 :STORED-BYTES 3177 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-1.lisp.gz" :UNCOMPRESSED-BYTES 7310 :UNCOMPRESSED-SHA256
    "8374a9c3bfd97fdb27a21105844f41dd4363943a999ca9fa3034ca2ae32edc1c"
    :COMPRESSED-BYTES 2868 :COMPRESSED-SHA256
    "69bb5db70962618c9958ea211be275a183ea7222c459b962cdda3e518a2b697d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/9-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7270 :STORED-BYTES 3271 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "9-0.lisp.gz" :UNCOMPRESSED-BYTES 7270 :UNCOMPRESSED-SHA256
    "64206b1cdb06fb00cddd1aaa17e0f8801a8b3391b003506a598f0db8a0d8440b"
    :COMPRESSED-BYTES 2962 :COMPRESSED-SHA256
    "1fab8f00d6c5134754a0e6c335c49b3f5a07217f81f986bc95c7e8c9ef216e8f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/8-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7660 :STORED-BYTES 3287 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-4.lisp.gz" :UNCOMPRESSED-BYTES 7660 :UNCOMPRESSED-SHA256
    "d7773b3bcfc8aef3b3be9fdb4007575baa481b16e6592ff4e71a6683d279d8dc"
    :COMPRESSED-BYTES 2978 :COMPRESSED-SHA256
    "7060f4db8e0a022774e43a7e1b0fafb508e92bc7cc4eb6553212f897a3498891"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/8-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7660 :STORED-BYTES 3146 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-3.lisp.gz" :UNCOMPRESSED-BYTES 7660 :UNCOMPRESSED-SHA256
    "3eb213a458f39041391f242b9c77d5d7438426f2483078745c0205c1674e1915"
    :COMPRESSED-BYTES 2837 :COMPRESSED-SHA256
    "dfb51043579536e5552386e6a59fb25370d68b710393f74b8eef3f9014c93e80"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/8-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7530 :STORED-BYTES 3282 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-2.lisp.gz" :UNCOMPRESSED-BYTES 7530 :UNCOMPRESSED-SHA256
    "b99712781fe21a2fc0294cc2bc43efbf7c1e9c38c9920781df647e4f9043ac58"
    :COMPRESSED-BYTES 2973 :COMPRESSED-SHA256
    "bd27e0f09ec798c7a401998819160096de3ea0f4d9311a4129f4cafb674d523b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/8-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7258 :STORED-BYTES 3374 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-1.lisp.gz" :UNCOMPRESSED-BYTES 7258 :UNCOMPRESSED-SHA256
    "6a8548ee6e9029590f2cc9ea12e68549f7f658145d715ffcda0b417f69e31cfa"
    :COMPRESSED-BYTES 3065 :COMPRESSED-SHA256
    "0169bb486348e4b18c1ff33eef69adc7a695a47367de81ad1f6cd7633d12cfff"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/8-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7234 :STORED-BYTES 3328 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "8-0.lisp.gz" :UNCOMPRESSED-BYTES 7234 :UNCOMPRESSED-SHA256
    "7a5edb84fcb3bc54f5d7c14d9b7bf321e8d5c70d49d3c31cd395e05ddd9f342b"
    :COMPRESSED-BYTES 3019 :COMPRESSED-SHA256
    "1fd6aa6ef7c5c97d52cf25908a65a24ca9b95178394e6353dfb1e886ed8d4f30"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/7-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6028 :STORED-BYTES 2238 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-4.lisp.gz" :UNCOMPRESSED-BYTES 6028 :UNCOMPRESSED-SHA256
    "80d0d043daabc8b492292af48a91062b40b7642fa4b8217e39c90c44e829f47f"
    :COMPRESSED-BYTES 1929 :COMPRESSED-SHA256
    "a09c487be3b3b8c0128e92a8f3df9e888bb06c5363ed4252f008b2f213fcdaba"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/7-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6013 :STORED-BYTES 2222 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-3.lisp.gz" :UNCOMPRESSED-BYTES 6013 :UNCOMPRESSED-SHA256
    "f2562c047f033ed981f08a2876a5b173fb232ed4ccfc7deb27b70a0965ff4961"
    :COMPRESSED-BYTES 1913 :COMPRESSED-SHA256
    "18eaf6e4c7a9292d010e20faea9385ef885f5231dc7cf24f1e1baf8c540af6f0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/7-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6008 :STORED-BYTES 2176 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-2.lisp.gz" :UNCOMPRESSED-BYTES 6008 :UNCOMPRESSED-SHA256
    "42e60c603e3dffdb18ec9e941348c81647cd95eda84a3bdedfc8db8e07b1757a"
    :COMPRESSED-BYTES 1867 :COMPRESSED-SHA256
    "3a8c848c42c82918d129a61be9c3fd3cde89d9b6712a46115cae2f07886c980b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/7-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6033 :STORED-BYTES 2205 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-1.lisp.gz" :UNCOMPRESSED-BYTES 6033 :UNCOMPRESSED-SHA256
    "3f54367f53200339125650dd3ad064f114a6f712c3904647ac7ffa1baee78907"
    :COMPRESSED-BYTES 1896 :COMPRESSED-SHA256
    "85ed1376b69e57662f4d461e0e0aed7a3eb7a53b6109750ac10fa5b0ad9b15be"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/7-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5980 :STORED-BYTES 2217 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "7-0.lisp.gz" :UNCOMPRESSED-BYTES 5980 :UNCOMPRESSED-SHA256
    "6b654a5787a2ec4a8adb1383e7eb5745acc7a6ddc1890c16cd20e8dc6facbefa"
    :COMPRESSED-BYTES 1908 :COMPRESSED-SHA256
    "6caf04338b7225c5ce709489db2778b2df921913188fdc6d9f781758393d04d1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7661 :STORED-BYTES 3051 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 7661 :UNCOMPRESSED-SHA256
    "c8867d54801af5fa3982340cb1567e80e1f1dc53bd710c9eadee8c6736ef63ae"
    :COMPRESSED-BYTES 2742 :COMPRESSED-SHA256
    "98eecc78295fe2e786cd9018dc48fc1ef7218b102691eb62bc96987864a45cb6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7663 :STORED-BYTES 2984 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 7663 :UNCOMPRESSED-SHA256
    "d4b5a9fae6a37da6b5371a32d3d7254a3cbb391f335ab4de374aa0fba4acfdd1"
    :COMPRESSED-BYTES 2675 :COMPRESSED-SHA256
    "d160b820bbf8aa773e8dfa0bc32ab4cd755578d71f0549ece820b527886d09ab"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7526 :STORED-BYTES 2970 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 7526 :UNCOMPRESSED-SHA256
    "4681df8dc5ec4cd5a80440c1a6448155345cc30c6c1499dad7d4fbc1519d50b4"
    :COMPRESSED-BYTES 2661 :COMPRESSED-SHA256
    "cb40ced99f9a13ae4c7a3bb9387ff26e039f32eb67c3a84c51c91e5a22670281"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7261 :STORED-BYTES 3115 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 7261 :UNCOMPRESSED-SHA256
    "073463d64227a6f43804ca6924782ee6252edfcf5fc63075b837428fd8c3d68a"
    :COMPRESSED-BYTES 2806 :COMPRESSED-SHA256
    "06874285793beae99fddbdd43b084f21b538014a014df53f5037ca059cff26e3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7230 :STORED-BYTES 3268 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 7230 :UNCOMPRESSED-SHA256
    "c9eb8c74aa902dfd3c331b72ca4c254364046a229794ff3e2a3fae720155d88b"
    :COMPRESSED-BYTES 2959 :COMPRESSED-SHA256
    "ef2386f82ddee7c4c28ca85c8bcac1bcbf9ea71c8c0b6f447c37fe051f0fc02a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/3-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6029 :STORED-BYTES 2098 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-4.lisp.gz" :UNCOMPRESSED-BYTES 6029 :UNCOMPRESSED-SHA256
    "00fd9ca1b620331f9af6bb7aca437fbb03f8cca3f1645708ed75137ac41b0868"
    :COMPRESSED-BYTES 1789 :COMPRESSED-SHA256
    "6d0d895f88df4793b87c3802cff53961cc06c213a54caaff37a1ca664a814da1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/3-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6022 :STORED-BYTES 2136 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-3.lisp.gz" :UNCOMPRESSED-BYTES 6022 :UNCOMPRESSED-SHA256
    "c25de64cd22ee89a5c93156008ffb8206bde7ce04bed5206b3fd1fce9a578f86"
    :COMPRESSED-BYTES 1827 :COMPRESSED-SHA256
    "18afa29304dae17905524b6c163ea6ecc06ef70ef26fa3e1ab272039c9072cc0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/3-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6029 :STORED-BYTES 2170 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-2.lisp.gz" :UNCOMPRESSED-BYTES 6029 :UNCOMPRESSED-SHA256
    "1eea24850536a5ee35ae1dd2d1792332f6153dc19cf08d021f517bad33db7bfa"
    :COMPRESSED-BYTES 1861 :COMPRESSED-SHA256
    "6bb5916e2938135b81784063101d31ae45dad527a41dcc1b5d1d44c1dc3cf812"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/3-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6022 :STORED-BYTES 2148 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-1.lisp.gz" :UNCOMPRESSED-BYTES 6022 :UNCOMPRESSED-SHA256
    "cb3bf4bb00fb7127c9aebb2c945a05bf48de1650407262b663f209da060724ee"
    :COMPRESSED-BYTES 1839 :COMPRESSED-SHA256
    "5b9f47d474c7bf37453988e9a086ff3a41f322ceb0fbd6e70306d2eba90d7d35"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/3-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6007 :STORED-BYTES 2131 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "3-0.lisp.gz" :UNCOMPRESSED-BYTES 6007 :UNCOMPRESSED-SHA256
    "b61119f46c24bcec5a42fc8bff6f653f92e2e9dc441e795a29d9dcb54ce6da5f"
    :COMPRESSED-BYTES 1822 :COMPRESSED-SHA256
    "4b1b518a3d13f046fbfb0fa321d27e3c5dd73ec4c2703056bf1c3aaa455be2e8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/12-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8183 :STORED-BYTES 3262 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-4.lisp.gz" :UNCOMPRESSED-BYTES 8183 :UNCOMPRESSED-SHA256
    "4b3e126d4e472b54a4bd6befdb601623944c07454cce478f9ff8786df0767d1d"
    :COMPRESSED-BYTES 2952 :COMPRESSED-SHA256
    "ee9df78f6767e01c881d57945b4ac7ccc19e2f1b12963a0199f77721709d6856"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/12-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8184 :STORED-BYTES 3281 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-3.lisp.gz" :UNCOMPRESSED-BYTES 8184 :UNCOMPRESSED-SHA256
    "76d7adfb3796e581a23ffc3c35046d369caad95c0b57ed2c3771714c82494431"
    :COMPRESSED-BYTES 2971 :COMPRESSED-SHA256
    "6830d69eb20ba15b63c417db75443bb75aa0ecabab66287197eb1a39fea7e67d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/12-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7988 :STORED-BYTES 3286 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-2.lisp.gz" :UNCOMPRESSED-BYTES 7988 :UNCOMPRESSED-SHA256
    "22fae201421a39b494390ceedc4ea759ce0b14064901182ac0e822b9a3a737da"
    :COMPRESSED-BYTES 2976 :COMPRESSED-SHA256
    "fac91bd03cddbb0560fa0563ac34ee2f4681aa19c3e4558cc02956f9c9d96e1d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/12-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7804 :STORED-BYTES 3405 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-1.lisp.gz" :UNCOMPRESSED-BYTES 7804 :UNCOMPRESSED-SHA256
    "0e4c7df8257a4a785fd9d1762245e5e5a14ffc6d62d784dec1d8874166ed1d7a"
    :COMPRESSED-BYTES 3095 :COMPRESSED-SHA256
    "7bbafe27d447303908e28160c47623739058cd68b63bc06119b0415c1f489c0d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/12-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7771 :STORED-BYTES 3457 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "12-0.lisp.gz" :UNCOMPRESSED-BYTES 7771 :UNCOMPRESSED-SHA256
    "eff26fedfaa4d2b57265f034e1ebebaefece14c72367cfa7dcbf96ff4aaad4ad"
    :COMPRESSED-BYTES 3147 :COMPRESSED-SHA256
    "b901b649c7da634a06fcb9bc73942430a885efa6bb3ebbeaf3c7746e28229e64"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/11-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8404 :STORED-BYTES 3316 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-4.lisp.gz" :UNCOMPRESSED-BYTES 8404 :UNCOMPRESSED-SHA256
    "a3ecba963d2d346fd31d48293bdc87d2c43077da30635e2ebaac238ca5a4cfb0"
    :COMPRESSED-BYTES 3006 :COMPRESSED-SHA256
    "45e3240ba2410bcfaaa69bf69738b3e4c1fef85150c7812c6faf330974175cd5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/11-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8368 :STORED-BYTES 3280 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-3.lisp.gz" :UNCOMPRESSED-BYTES 8368 :UNCOMPRESSED-SHA256
    "c7df4dbcb9f7c69c2f5418c2575d070059c56f85287c7ee4eaf48d3283f6f074"
    :COMPRESSED-BYTES 2970 :COMPRESSED-SHA256
    "9e8e47ba782019236b1366cf3ef85d360cea18e5a02f2df82ee850748864e87b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/11-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8191 :STORED-BYTES 3379 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-2.lisp.gz" :UNCOMPRESSED-BYTES 8191 :UNCOMPRESSED-SHA256
    "1cb122640e7287e14805b90e3b446ac0c47b7fde484af85bdf13477de9fbeb2d"
    :COMPRESSED-BYTES 3069 :COMPRESSED-SHA256
    "2e9ff6e1663f3a44c1a791ec4967ab94222009f0858177a64b385fbb39d35fe5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/11-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7959 :STORED-BYTES 3371 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-1.lisp.gz" :UNCOMPRESSED-BYTES 7959 :UNCOMPRESSED-SHA256
    "78d400306475fcf51592307d23dd686330b69be2160364a0ab5fd2dd82f53484"
    :COMPRESSED-BYTES 3061 :COMPRESSED-SHA256
    "9d25c1ed509cb1cc745c1f0fbb5c5fbe7182bd02e0de65adf6bf9f60015c53eb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/11-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7870 :STORED-BYTES 3402 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "11-0.lisp.gz" :UNCOMPRESSED-BYTES 7870 :UNCOMPRESSED-SHA256
    "0cf4e36ba16c7d3639de31a3d9b3d3afc3aa9c060edc00d36d701fafea8e3612"
    :COMPRESSED-BYTES 3092 :COMPRESSED-SHA256
    "94e6bbcbd0145413c22114ba6d8fd5f78b42322cc362b92eaccaa595f2554889"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/10-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7705 :STORED-BYTES 3468 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-4.lisp.gz" :UNCOMPRESSED-BYTES 7705 :UNCOMPRESSED-SHA256
    "3ded03f87f80976758ee0dbb84fbee1abbca19d3ec93a894b932ba45335ca2d9"
    :COMPRESSED-BYTES 3158 :COMPRESSED-SHA256
    "7cce02e8e982de9cf784333b2afe7016a18b5b2193f84c13dd25ce238f8ccd17"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/10-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7691 :STORED-BYTES 3407 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-3.lisp.gz" :UNCOMPRESSED-BYTES 7691 :UNCOMPRESSED-SHA256
    "80ee6ad12a9e3893268f863793d939ebd86c06bd4424740b6d1aecca371a5eef"
    :COMPRESSED-BYTES 3097 :COMPRESSED-SHA256
    "9ecb8ea10795efc4c18197f513ca67c96dac514ef6ba87721acc386c629406e7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/10-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7551 :STORED-BYTES 3406 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-2.lisp.gz" :UNCOMPRESSED-BYTES 7551 :UNCOMPRESSED-SHA256
    "6a5c115aa15ede10facfc8ba1dbc214888561d32973d4e1c476a9d5ade81042b"
    :COMPRESSED-BYTES 3096 :COMPRESSED-SHA256
    "7316d70e6b3e81e8124ca7fd977fe6e8ae5af631664b119ede53a56e03f27b31"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/10-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7298 :STORED-BYTES 3374 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-1.lisp.gz" :UNCOMPRESSED-BYTES 7298 :UNCOMPRESSED-SHA256
    "94d7eb13bdb341150c27802ef1960b8b4c76549c3c433919e09ce3cb5bd508bb"
    :COMPRESSED-BYTES 3064 :COMPRESSED-SHA256
    "5202a56ffc6fc3e69e7703215941176cae61a3f9b7d9a71ac4a721646b56baa4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/candidate/windows/10-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 7267 :STORED-BYTES 3337 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "10-0.lisp.gz" :UNCOMPRESSED-BYTES 7267 :UNCOMPRESSED-SHA256
    "e7899dbf5eacac061d3bef60811133999f7de04fa4800add406b9d90b597fff1"
    :COMPRESSED-BYTES 3027 :COMPRESSED-SHA256
    "e54b53589c9546f630c016a56e440cb516a496d829d2b0e46975c2f5294cd8f5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/4002542322-command-75050-0/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362836 :STORED-BYTES 116385 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362836 :UNCOMPRESSED-SHA256
    "3c04f69231f5a1b212ce4508b4e640211821b51c433bad2d50e5febd1f56e67e"
    :COMPRESSED-BYTES 116069 :COMPRESSED-SHA256
    "d7a991e7377e770d4ae9920719743227bcfc232f2a512066218e1041452784c8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-allocation/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362099 :STORED-BYTES 116245 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362099 :UNCOMPRESSED-SHA256
    "ce6eb7dab7c4a0eb44cc38d69e093343eb219e596ac7695d0a4943d40f43fe34"
    :COMPRESSED-BYTES 115929 :COMPRESSED-SHA256
    "e7ac35f7c1d8e848da53a41102b1d3a1f5f020a46b4e4d8a9544b850599faf9d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-analysis-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 360791 :STORED-BYTES 115814 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 360791 :UNCOMPRESSED-SHA256
    "59cf23608c8d2ad07921dd088550fec0756bbcbe796f0e516d77ea7e9d95729f"
    :COMPRESSED-BYTES 115498 :COMPRESSED-SHA256
    "5753a45bf855d61cbd653d819ec3a83cb365976424e756c93a0e1eb2c3fa5dd9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-archive-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362026 :STORED-BYTES 116195 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362026 :UNCOMPRESSED-SHA256
    "ee7eb69e5add13221781b47de1d96efd27ae5a8a9c5b8f1c45b0cfa29ab50cfa"
    :COMPRESSED-BYTES 115879 :COMPRESSED-SHA256
    "e1b121a7af00daed35c2c42c5057c2edaee2c82f428b67876486dcb28b005871"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 361902 :STORED-BYTES 116078 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 361902 :UNCOMPRESSED-SHA256
    "33347eae424931a8220cab128c0a84199cce6c75d96fb9d13354cb1dac4bd73d"
    :COMPRESSED-BYTES 115762 :COMPRESSED-SHA256
    "db1190bc97bf422d41c515519e52ec744c32b6cb79b261aa253bc484421dcfe4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-calibration-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 361181 :STORED-BYTES 115947 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 361181 :UNCOMPRESSED-SHA256
    "ec71b75e73308403cc2729d453356b7351e2119d9174f9afe644914b74732779"
    :COMPRESSED-BYTES 115631 :COMPRESSED-SHA256
    "91abca9747a63174c306f8985e6bcaf11638979d4dfc8cca3dad0001717e7f73"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-calibration/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 365867 :STORED-BYTES 116609 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 365867 :UNCOMPRESSED-SHA256
    "dad6367bbbf2b9569116afd3a195ae020cb363249a8062f00aeb43bb52d4ccf4"
    :COMPRESSED-BYTES 116293 :COMPRESSED-SHA256
    "7b1bfa3f51b81114e6336b22e37512226c7bf407cb19cda88731c3e276c5f999"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 375313 :STORED-BYTES 117003 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 375313 :UNCOMPRESSED-SHA256
    "3ff923a06aa75b7e382cf2e241da8ec7f433c29cdd1f1af9d2b7f77c95af5998"
    :COMPRESSED-BYTES 116687 :COMPRESSED-SHA256
    "a0b74c0ee86d83d7f66a04096b69833df4388a977c205ee78fdb2c8aa1768796"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362619 :STORED-BYTES 116352 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362619 :UNCOMPRESSED-SHA256
    "de7ead0dfaf469876b7b2dc86f7f30ea290fc400fb6692537459c026400cca98"
    :COMPRESSED-BYTES 116036 :COMPRESSED-SHA256
    "984c1a4b1cad321de4d631b7c5e1ac3125bf25d35a49986dd24a73e0bd566093"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-calibration-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362302 :STORED-BYTES 116298 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362302 :UNCOMPRESSED-SHA256
    "241475a485bbca2de09f4790c85fa2b93143a4cea297b4ba57b85bb2af201af8"
    :COMPRESSED-BYTES 115982 :COMPRESSED-SHA256
    "2f86c6b313ada5cad892896c567136e9dbb59fe0297583db8c603fbde187d6dc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-calibration/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 366991 :STORED-BYTES 116958 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 366991 :UNCOMPRESSED-SHA256
    "65d586a91b7dd61c3b86f4e8a92cc6cc00244d202b80e53257ebf8330c265eaf"
    :COMPRESSED-BYTES 116642 :COMPRESSED-SHA256
    "42d56bc1ae23c0a9194aa9e98cdf6480e992b2fc7aa4c804466a597d6560dbc6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-repeat-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362730 :STORED-BYTES 116377 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362730 :UNCOMPRESSED-SHA256
    "447ce451eaf1afc24f86c74bff6e31b38b3993dddc0720d0f9f84f6351ba4ec3"
    :COMPRESSED-BYTES 116061 :COMPRESSED-SHA256
    "eb21a3e0176fb1e3d7a56eda3fd0fd07a0135217c8bfe077107e71c9b13045ea"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-repeat/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 376443 :STORED-BYTES 117359 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 376443 :UNCOMPRESSED-SHA256
    "196ab3d0f5d81059cc5004cdadc233ac200e4f6b6c362c0658a217578495e36b"
    :COMPRESSED-BYTES 117043 :COMPRESSED-SHA256
    "abe456be95dc884baf25338904252daf4d6273efb7d85efbfe90cae9ad058a26"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 376437 :STORED-BYTES 117357 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 376437 :UNCOMPRESSED-SHA256
    "4a2b71ca8ec5e6392cd36b5914a82fc3cb2774dabeb1c77a9559270a1482abd6"
    :COMPRESSED-BYTES 117041 :COMPRESSED-SHA256
    "ac64bc1003ae4393c9d0105887af4331730785fc98fc1b66d3455fd19e15053d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-checks-2.6.9/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 435061 :STORED-BYTES 128388 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 435061 :UNCOMPRESSED-SHA256
    "e36f517b20d01fa140659c40579349d9871ccfc00f487c421349a649d608769b"
    :COMPRESSED-BYTES 128072 :COMPRESSED-SHA256
    "9fea3c40020a742caa271250e305bc87bdc7a48053f09fb0938cea9b0f4d7d8f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-cleanup-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362057 :STORED-BYTES 116224 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362057 :UNCOMPRESSED-SHA256
    "85842bcc48a7582f3c4d18c8448f3566ee573a5458874f5f9457c870fe7da6c7"
    :COMPRESSED-BYTES 115908 :COMPRESSED-SHA256
    "32c1dcd41239b358e20bb274e48b1e305413a19dbbf5d119479c818ff2e8a03c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-close-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362012 :STORED-BYTES 116178 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362012 :UNCOMPRESSED-SHA256
    "7e485a9e45fda21e93c94583081b0953d82b68661f982f1601f5a7e5acf8e74b"
    :COMPRESSED-BYTES 115862 :COMPRESSED-SHA256
    "77033204afd5432c6b0803e274b853684317a4abe90be535dac54a9fa247cfd2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-docs-setup/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362285 :STORED-BYTES 116245 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362285 :UNCOMPRESSED-SHA256
    "c14c9031483f7833ea6c62e255945a97e1b5f0c97772e15bc9bc4b927e383ae3"
    :COMPRESSED-BYTES 115929 :COMPRESSED-SHA256
    "b52e2afc7130113c140aba2ceea0e3f80df7da6e5efc43b91df4da7022b64fc9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-documentation/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 367512 :STORED-BYTES 117504 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 367512 :UNCOMPRESSED-SHA256
    "ab76122ead9700c6100ba78dc1a23669a29c0bb326a139ca8e1b7a93a77b7b88"
    :COMPRESSED-BYTES 117188 :COMPRESSED-SHA256
    "4a8828ea65453dd73b5af68d47790f9e3d0603b3f41123d3dd20565949f43bd8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-01/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 369108 :STORED-BYTES 117904 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 369108 :UNCOMPRESSED-SHA256
    "ff474665d6b760b5d5e20c423025d0813f7f98298b9770427da4b43fab5ef753"
    :COMPRESSED-BYTES 117588 :COMPRESSED-SHA256
    "cac051670e237578822602c99d9e1d1a531c4c6e95bb806d65d6b6e759d81e2f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 369072 :STORED-BYTES 117848 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 369072 :UNCOMPRESSED-SHA256
    "ddd6631130a33448e4ddf1fe187be143b301b482a832cadb922aa5076f8aeee0"
    :COMPRESSED-BYTES 117532 :COMPRESSED-SHA256
    "c787a926068bc974f8706af91f4c2215cea7fd681155d391bf7d132eda7ee256"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-03/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 369114 :STORED-BYTES 117844 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 369114 :UNCOMPRESSED-SHA256
    "f90b61e72d007a11e4c44279b1e390f9fa81d9ca6eb89bf10ce2f56535b7ab97"
    :COMPRESSED-BYTES 117528 :COMPRESSED-SHA256
    "13898c73094484d3fe46cc64d4bdc05d2b029989f898d64c2d77bd299959ecfc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-04/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 369570 :STORED-BYTES 117986 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 369570 :UNCOMPRESSED-SHA256
    "72647ebd31b5943ae4d9ec55c030b0fd5ccfd36e799c6bb150c48f37673b1289"
    :COMPRESSED-BYTES 117670 :COMPRESSED-SHA256
    "a612c724efad3739d1d460973918773ac84033c600e59f6c745f9bab2b00a7c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-05/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 361863 :STORED-BYTES 116146 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 361863 :UNCOMPRESSED-SHA256
    "ecbe99a316530cae7a0d8d7471b0ba98a597aa3ea0107cd3ebfae04fb3c8ada2"
    :COMPRESSED-BYTES 115830 :COMPRESSED-SHA256
    "baa2245bd9ddaffbe895636ded2fdfce7629fec88ba3b9fd582b504b5a6c4026"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-self-test-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362729 :STORED-BYTES 116543 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362729 :UNCOMPRESSED-SHA256
    "a14f3fe797a27d8e33f28207173a6a218e7891abf10953b8455f83c57869a2c1"
    :COMPRESSED-BYTES 116227 :COMPRESSED-SHA256
    "0545d64f004c82eb8b24e16a1afa18ea474d08d4aa9338b88f5dba81fd1be678"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-self-test-03/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362208 :STORED-BYTES 116224 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362208 :UNCOMPRESSED-SHA256
    "a4c0e79146df61f1e36adb3be510388fd0920c99417209c0a9a192837e4cd1e8"
    :COMPRESSED-BYTES 115908 :COMPRESSED-SHA256
    "984fe3addbd866790c9f83e8c3a10d6595fe4ba64bddb1f42871123073974d71"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362014 :STORED-BYTES 116175 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362014 :UNCOMPRESSED-SHA256
    "49bc998a13e04202cb3717c85645cb919a335befa9d26b7dd6089e97b55c015b"
    :COMPRESSED-BYTES 115859 :COMPRESSED-SHA256
    "622ed4f65660bf05e21e81673c508216c2087c7b3dbc9daa56e4c81e3941e50a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-initial-archive/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362049 :STORED-BYTES 116180 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362049 :UNCOMPRESSED-SHA256
    "79bb27e7f62e69917942ff13683012366480de928c47cfba1c887f58b8f96738"
    :COMPRESSED-BYTES 115864 :COMPRESSED-SHA256
    "d82850449c6ca01a2ed3baa9764af126cf5f23ebf217160cb2e274e45b37afb1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-process-01/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 369317 :STORED-BYTES 117899 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 369317 :UNCOMPRESSED-SHA256
    "41093caf2916e22807516a5e8baaf8d252897c6048959b59673767934b59f358"
    :COMPRESSED-BYTES 117583 :COMPRESSED-SHA256
    "67db4ee79239d6abc3480d2ee3758e56b85ffde5b9acbf43f6e55705cd9aa91f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-process-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 390903 :STORED-BYTES 117942 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 390903 :UNCOMPRESSED-SHA256
    "f403888bfb2a1200c7d8e6cebdcabd193e7be3392d23e8ddd41b6f58431ce6cd"
    :COMPRESSED-BYTES 117626 :COMPRESSED-SHA256
    "be45e97a206efa72316bb20a353889f189c8cb274428b996fbb0b635339cd0b5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-read-analysis/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362174 :STORED-BYTES 116263 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362174 :UNCOMPRESSED-SHA256
    "d0bbb820ecc55bb5eb25867a2c7d7e6c1d57bcf1682046a7a76f482108e80892"
    :COMPRESSED-BYTES 115947 :COMPRESSED-SHA256
    "82a2eb8382cc8e572aabdb197803b8c9e5f393b233151573572ac87adfac5a0f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-read-control/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 366994 :STORED-BYTES 116969 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 366994 :UNCOMPRESSED-SHA256
    "80111b5c383213a00131225c88fa4dcfe026ab21bf8ae886968f5e0c7f1e12f2"
    :COMPRESSED-BYTES 116653 :COMPRESSED-SHA256
    "334b56981057db5a249c99082fc0017326b88f4ed135841621d269dd01631e91"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-smoke-01/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 380378 :STORED-BYTES 118352 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 380378 :UNCOMPRESSED-SHA256
    "7d7294ceba1f192bd820f9d5552cb1df78178b183efe9d08153b791ecffc0d0c"
    :COMPRESSED-BYTES 118036 :COMPRESSED-SHA256
    "d4903b51ff4575d152a253fea9329daecd21aa4e91f4ef837388f91d1dcff8ed"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-smoke-02/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 363472 :STORED-BYTES 116516 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 363472 :UNCOMPRESSED-SHA256
    "201d8b396b8d078e0e487f71a4599b97fe876bbefbf43df0fae110e867baff04"
    :COMPRESSED-BYTES 116200 :COMPRESSED-SHA256
    "864c43da0eb5ec7b3ae7a5305119f5d78e1449fbc0098973904b9ccdcf3c859b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-statistics/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 362482 :STORED-BYTES 116263 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 362482 :UNCOMPRESSED-SHA256
    "8ae1b3cef5560359ce7f20c37ee94e27b6509d37ce3d6c40fc9b6c1f5dd7d481"
    :COMPRESSED-BYTES 115947 :COMPRESSED-SHA256
    "6f86b9ffb4996b082c680e3bc1f576b8780b75459f1e97ad07507082861ecdc7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-unix-final-2.6.10/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 570171 :STORED-BYTES 126792 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 570171 :UNCOMPRESSED-SHA256
    "78cd72a22cb39fec989a6ed77ef69ed7433c729ccb43af734125d2917cd89add"
    :COMPRESSED-BYTES 126476 :COMPRESSED-SHA256
    "33fddd65e4953d900db8250ef97f05922a4b25641c2c3f88a92270889a9a134a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-unix-final-2.6.9/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 570143 :STORED-BYTES 126745 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 570143 :UNCOMPRESSED-SHA256
    "6e05b6764bc3036cbf9e45f1d84a83c18f730443257ea7fc7038fdf472f9507b"
    :COMPRESSED-BYTES 126429 :COMPRESSED-SHA256
    "20b5e3bc059dc3a10cefc1d0e3b4e0aa7cc3859296e07e0facc80f7d71ca8423"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1902 :STORED-BYTES 945 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 1902 :UNCOMPRESSED-SHA256
    "16b20df12fbcb2394fd90d9dd0e40781ed6be944233f52e66dcf446477b4cae9"
    :COMPRESSED-BYTES 625 :COMPRESSED-SHA256
    "3ac3a866c9cb5710b22470154c28a098b9e6f4de71b99149aa4340f85c00bda5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1375 :STORED-BYTES 789 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 1375 :UNCOMPRESSED-SHA256
    "c45ddcf28ad1e18f09df9a02210b1f9ce4c542fa929692a5e74d13708e4074d1"
    :COMPRESSED-BYTES 469 :COMPRESSED-SHA256
    "8aa719dfde86648a1599ba429868e6b18ba8aabc97778641ec3795288a0600ad"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-1/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 76168 :STORED-BYTES 2671 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 76168 :UNCOMPRESSED-SHA256
    "b5a9db25f4699308de34a2f17f565303b0ee8b5953d88d90fd038c5294f25d96"
    :COMPRESSED-BYTES 2349 :COMPRESSED-SHA256
    "219132e315dee6106c09f3007742186436b093ae652e690b081974013808be37"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/0000000000000004.seg"
   :STATUS :OK :ORIGINAL-BYTES 43552 :STORED-BYTES 1781 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000004.seg.gz" :UNCOMPRESSED-BYTES 43552 :UNCOMPRESSED-SHA256
    "863218cf143f6e92666670b9a5393969b89a24b1a232e92125958f8b34564a3c"
    :COMPRESSED-BYTES 1459 :COMPRESSED-SHA256
    "9a49b12682d779adb6f91221cc1bf0bbf0d3a71668b431a36b39c009cca8f9ee"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/0000000000000003.seg"
   :STATUS :OK :ORIGINAL-BYTES 130528 :STORED-BYTES 4431 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000003.seg.gz" :UNCOMPRESSED-BYTES 130528 :UNCOMPRESSED-SHA256
    "8c000329a73bea09ba14417ea07d2eaa16ea86a857482a5daf417ee0dd645aac"
    :COMPRESSED-BYTES 4108 :COMPRESSED-SHA256
    "6b1ff2b13ced40d324af508368be5afcc7357ebb092f82cdae0defa39aaa3a76"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 130528 :STORED-BYTES 4444 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 130528 :UNCOMPRESSED-SHA256
    "ca314aa85bd3fab227d05b7a2866864e6f2b289702a7bd0248f209cf7eb165d9"
    :COMPRESSED-BYTES 4121 :COMPRESSED-SHA256
    "83192cf13a0a216171227ad8a9fcb8108b5cf14e0792c7d2b7e12047f67b32bb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v1/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 404464 :STORED-BYTES 46257 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 404464 :UNCOMPRESSED-SHA256
    "a5e9baa1b949f3a8c7665739dac792a070ec1c8d9a4575e4e887a62cad10bd60"
    :COMPRESSED-BYTES 45933 :COMPRESSED-SHA256
    "dee78ab6ea74b0f1f3e65cab15a4661d360159f19d6bae3a991017c5af6d758b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v2/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 404464 :STORED-BYTES 46256 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 404464 :UNCOMPRESSED-SHA256
    "a084b17dfa89cbe86069fd71c0edd21fdf0a75133b7b6cc832f27f837710ff22"
    :COMPRESSED-BYTES 45932 :COMPRESSED-SHA256
    "171c51016cdf891acd6e591820d55e36d021b62b80010af60f6122e6aba156a7"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v1/0000000000000007.seg"
   :STATUS :OK :ORIGINAL-BYTES 5048128 :STORED-BYTES 10509 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000007.seg.gz" :UNCOMPRESSED-BYTES 5048128 :UNCOMPRESSED-SHA256
    "325d2c075fa7ce9a4dbf290c592aea67293d3d1abdef8330d0f2dc61d93868fa"
    :COMPRESSED-BYTES 10184 :COMPRESSED-SHA256
    "ae20d82a74fb4f7b19384bff905050151ecf88bdf2aabedde837fc261140e636"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v1/0000000000000006.seg"
   :STATUS :OK :ORIGINAL-BYTES 240224 :STORED-BYTES 757 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000006.seg.gz" :UNCOMPRESSED-BYTES 240224 :UNCOMPRESSED-SHA256
    "7c1a8c4838460be425917c34ab2a543de79bd8ae3cf95d51bd5b1989b8a3430b"
    :COMPRESSED-BYTES 435 :COMPRESSED-SHA256
    "8ed9871c3ff3c586cbb6bccf76c4df03bf7fc94f36de7dc8a9bcaf2085205488"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v2/0000000000000007.seg"
   :STATUS :OK :ORIGINAL-BYTES 5048128 :STORED-BYTES 10511 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000007.seg.gz" :UNCOMPRESSED-BYTES 5048128 :UNCOMPRESSED-SHA256
    "3dad5c58849fe12d5987a0a018e23ceb063bf962f5c135cc6605c566079edf41"
    :COMPRESSED-BYTES 10186 :COMPRESSED-SHA256
    "43647357304f9df702c52084f8096a607ffd307a984025a32946fdbe0a34e5fa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v2/0000000000000006.seg"
   :STATUS :OK :ORIGINAL-BYTES 240224 :STORED-BYTES 758 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000006.seg.gz" :UNCOMPRESSED-BYTES 240224 :UNCOMPRESSED-SHA256
    "845dac2039e651d0b55d01ae9a724885e3dc447d1a15b5458915f0a17b946820"
    :COMPRESSED-BYTES 436 :COMPRESSED-SHA256
    "3778b0e575ee304b7bf7ae79315c13f65d1632b39b6bb45210169ee03d3b9145"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v1/primary-0000000000000001.idx.tmp"
   :STATUS :OK :ORIGINAL-BYTES 12288 :STORED-BYTES 543 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "primary-0000000000000001.idx.tmp.gz" :UNCOMPRESSED-BYTES 12288
    :UNCOMPRESSED-SHA256
    "06ebc7a57d40549f0f590755d67bae9070f3c44b7743342fa4786c78f82836a7"
    :COMPRESSED-BYTES 209 :COMPRESSED-SHA256
    "7e2492edd48ee9cd8faf1a33c29f541c91d35793a3f72f035a145b85e7820d5b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v2/primary-0000000000000001.idx.tmp"
   :STATUS :OK :ORIGINAL-BYTES 12288 :STORED-BYTES 544 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "primary-0000000000000001.idx.tmp.gz" :UNCOMPRESSED-BYTES 12288
    :UNCOMPRESSED-SHA256
    "b4325b670b51749a6ed43db7e8a039e1d2ed649fea2bdd600ade53883a3116d5"
    :COMPRESSED-BYTES 210 :COMPRESSED-SHA256
    "68a24363ff0ada985687b7590fc4390e40dbd364692c54ea4842ce9e24ce72fe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v1/primary-0000000000000001.idx.tmp"
   :STATUS :OK :ORIGINAL-BYTES 12288 :STORED-BYTES 543 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "primary-0000000000000001.idx.tmp.gz" :UNCOMPRESSED-BYTES 12288
    :UNCOMPRESSED-SHA256
    "10992888c8a22c9877a5a8d62ba530c962a857e955493990ab36617f42d0a6f3"
    :COMPRESSED-BYTES 209 :COMPRESSED-SHA256
    "840001b90077d2ae477ce8a00ed9eb8530f58f4d5a6f4090b61250dfbcb41fed"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v2/primary-0000000000000001.idx.tmp"
   :STATUS :OK :ORIGINAL-BYTES 12288 :STORED-BYTES 544 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "primary-0000000000000001.idx.tmp.gz" :UNCOMPRESSED-BYTES 12288
    :UNCOMPRESSED-SHA256
    "732b00003e1dcbc3c8e5d5861e5e45d0ba42d9c74e3bf6323dcb1b5797c1ea4b"
    :COMPRESSED-BYTES 210 :COMPRESSED-SHA256
    "becbd333780bc9a6c66c95ef481e9bcbc294fd21d1859097c703fcd424b2908c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-loss-v1/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 2760 :STORED-BYTES 700 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 2760 :UNCOMPRESSED-SHA256
    "4278f5b688e3491ad71617a9fb27f2b326ce4082a3b0f9ffc7ef036539d0dc84"
    :COMPRESSED-BYTES 380 :COMPRESSED-SHA256
    "57e3417bda197d8589d809ce4fe8c5c3aaf10328c2f721f6c3eccf497ccf2001"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-loss-v2/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 2760 :STORED-BYTES 700 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 2760 :UNCOMPRESSED-SHA256
    "520b8470393fcef3a8b8be9f5b52cc8c5f540263dcf7698d7193140e9300f241"
    :COMPRESSED-BYTES 380 :COMPRESSED-SHA256
    "24e5199ffd9cf22729e7fcd8f2362cc5729455db5ac6a0c958b25c3619020778"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-v1/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 2760 :STORED-BYTES 700 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 2760 :UNCOMPRESSED-SHA256
    "4278f5b688e3491ad71617a9fb27f2b326ce4082a3b0f9ffc7ef036539d0dc84"
    :COMPRESSED-BYTES 380 :COMPRESSED-SHA256
    "57e3417bda197d8589d809ce4fe8c5c3aaf10328c2f721f6c3eccf497ccf2001"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-v2/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 2760 :STORED-BYTES 700 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 2760 :UNCOMPRESSED-SHA256
    "520b8470393fcef3a8b8be9f5b52cc8c5f540263dcf7698d7193140e9300f241"
    :COMPRESSED-BYTES 380 :COMPRESSED-SHA256
    "24e5199ffd9cf22729e7fcd8f2362cc5729455db5ac6a0c958b25c3619020778"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/group-v1/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 2760 :STORED-BYTES 700 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 2760 :UNCOMPRESSED-SHA256
    "4278f5b688e3491ad71617a9fb27f2b326ce4082a3b0f9ffc7ef036539d0dc84"
    :COMPRESSED-BYTES 380 :COMPRESSED-SHA256
    "57e3417bda197d8589d809ce4fe8c5c3aaf10328c2f721f6c3eccf497ccf2001"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/group-v2/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 2760 :STORED-BYTES 700 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 2760 :UNCOMPRESSED-SHA256
    "520b8470393fcef3a8b8be9f5b52cc8c5f540263dcf7698d7193140e9300f241"
    :COMPRESSED-BYTES 380 :COMPRESSED-SHA256
    "24e5199ffd9cf22729e7fcd8f2362cc5729455db5ac6a0c958b25c3619020778"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v1/0000000000000003.seg"
   :STATUS :OK :ORIGINAL-BYTES 121070 :STORED-BYTES 695 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000003.seg.gz" :UNCOMPRESSED-BYTES 121070 :UNCOMPRESSED-SHA256
    "792e9e012ce74e09e1ec9a891233a6f7808e22267b85736f979b68e2748b4425"
    :COMPRESSED-BYTES 373 :COMPRESSED-SHA256
    "065d1ddec58bfb868cb860638005c2cb345cecb20e8198da117300e5a7d5007e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v1/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 3095 :STORED-BYTES 744 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 3095 :UNCOMPRESSED-SHA256
    "446cfbd5931320e13418a73ebdd7fd14b917e28ed16fed13ac0b01e1004fa60f"
    :COMPRESSED-BYTES 424 :COMPRESSED-SHA256
    "b3941d9a88c0427b5c344b5f1c8b18e4fc4f3fd4b781d80a21aff1d57e24b6f9"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v2/0000000000000003.seg"
   :STATUS :OK :ORIGINAL-BYTES 121070 :STORED-BYTES 694 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000003.seg.gz" :UNCOMPRESSED-BYTES 121070 :UNCOMPRESSED-SHA256
    "7b3215edea08ea721c53b318f75b11385bb7bba5c12a6e4361d8f8841dd6030f"
    :COMPRESSED-BYTES 372 :COMPRESSED-SHA256
    "e09508a6d042e22ac7cca2257bc25808a7396670355e4b7fe1e5fd263ea6aa1a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v2/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 3095 :STORED-BYTES 744 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 3095 :UNCOMPRESSED-SHA256
    "c4988b775f4cb47f608577a3476474aa5740cb7bf5100149d083a79e74137c7a"
    :COMPRESSED-BYTES 424 :COMPRESSED-SHA256
    "22b617f131e2cb473364d1c772f66bd29e60688c4b39847a4a5218d376234a94"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-loss-v1/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 3095 :STORED-BYTES 756 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 3095 :UNCOMPRESSED-SHA256
    "5c538b69aabca7636b857fa96dc954696ab69d2cab90ed1461e531d9cdf0c7ba"
    :COMPRESSED-BYTES 436 :COMPRESSED-SHA256
    "b62a684a5ad1928c50c793b63f0575d8ff76ab5b83bb8ab865d6841c575d6f1e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-loss-v2/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 3095 :STORED-BYTES 756 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 3095 :UNCOMPRESSED-SHA256
    "83b83cf7427dc8a952dd17bb12f0b2360a87ea06ef024729d2f3642de4779981"
    :COMPRESSED-BYTES 436 :COMPRESSED-SHA256
    "547c40377ece9d17f4add54ebb3ce93072a9c9b04a06c97317facd34c4a1ed1d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v1/0000000000000003.seg"
   :STATUS :OK :ORIGINAL-BYTES 1262080 :STORED-BYTES 2933 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000003.seg.gz" :UNCOMPRESSED-BYTES 1262080 :UNCOMPRESSED-SHA256
    "b0646d6b02818e85fea4d3be9cf355c78b8a7ddb7cb3772390a14a6a20c9b6e2"
    :COMPRESSED-BYTES 2609 :COMPRESSED-SHA256
    "d846c68e30124fe7fafd604379dee42f8509e70dd0886736c5d4d7ef6b01ff81"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v1/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 16766848 :STORED-BYTES 33445 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 16766848 :UNCOMPRESSED-SHA256
    "481c0818bcf96deaa63c845760eb94c250f46e878db142d22769b0beedb89104"
    :COMPRESSED-BYTES 33119 :COMPRESSED-SHA256
    "38427c134943f5e19127e20c0af85c40d54137ea7ffd90cd04ce656c367e0a49"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v2/0000000000000003.seg"
   :STATUS :OK :ORIGINAL-BYTES 1262080 :STORED-BYTES 2932 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000003.seg.gz" :UNCOMPRESSED-BYTES 1262080 :UNCOMPRESSED-SHA256
    "41748eb5ed15c058672dbf918096a67c754967b6543d59bb4ba72a5c95b7ab26"
    :COMPRESSED-BYTES 2608 :COMPRESSED-SHA256
    "a36bc309a660a458e2336faa54a977e8ec4b34a5d86b5f50b35a9a85ebe61e83"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v2/0000000000000002.seg"
   :STATUS :OK :ORIGINAL-BYTES 16766848 :STORED-BYTES 33447 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "0000000000000002.seg.gz" :UNCOMPRESSED-BYTES 16766848 :UNCOMPRESSED-SHA256
    "adea129953b2658e178767019f5045aab9ae67281578e7f405b922b7345ae72b"
    :COMPRESSED-BYTES 33121 :COMPRESSED-SHA256
    "3d4d10a2a6be28657804df2218eb3d605bdfe4cf843abca977e664bff5ee672a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/focused-01-variant/disjoint-read.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10608 :STORED-BYTES 2748 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "disjoint-read.lisp.gz" :UNCOMPRESSED-BYTES 10608 :UNCOMPRESSED-SHA256
    "a5397336151a54de0f8cc9dc0d0979f8a7d8f47c07c6ecb53fec3b5cc8e3e144"
    :COMPRESSED-BYTES 2428 :COMPRESSED-SHA256
    "c0930ac21524ee42cbf77c7ceb2f6eec5d402b7729c38abfa2ec4b07d65fa478"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/focused-02-variant/disjoint-read.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10531 :STORED-BYTES 2728 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "disjoint-read.lisp.gz" :UNCOMPRESSED-BYTES 10531 :UNCOMPRESSED-SHA256
    "cccae66ea7fd0fe644974fd9221e1454820f22e2a862e2aee4783dbb4d5fd32f"
    :COMPRESSED-BYTES 2408 :COMPRESSED-SHA256
    "f8b06fb7e0074f03f81efe5680b700539453bb1a7b4f865fbf6fec1860f04c70"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/focused-03-variant/disjoint-read.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10582 :STORED-BYTES 2732 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "disjoint-read.lisp.gz" :UNCOMPRESSED-BYTES 10582 :UNCOMPRESSED-SHA256
    "abb817344c4323cf6da0e10da12f5d6dfdc941be65a81a51bb68ea1beb453da5"
    :COMPRESSED-BYTES 2412 :COMPRESSED-SHA256
    "68418c54b35e836c2bc57b8b1170cc7f0bd5653f80e5005e2056970fec968f54"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/focused-04-variant/disjoint-read.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10667 :STORED-BYTES 2753 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "disjoint-read.lisp.gz" :UNCOMPRESSED-BYTES 10667 :UNCOMPRESSED-SHA256
    "7bd06409b6676860ac90747946fa3a4fc618dbe977cda861b88f4eb175b96ecc"
    :COMPRESSED-BYTES 2433 :COMPRESSED-SHA256
    "b5196f1fe77e281f4ec4e00cfbd24ef1758b5c4ae542686a526a36ab38eafb59"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/identity-02-variant/verify.lisp"
   :STATUS :OK :ORIGINAL-BYTES 8564 :STORED-BYTES 2985 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "verify.lisp.gz" :UNCOMPRESSED-BYTES 8564 :UNCOMPRESSED-SHA256
    "c2420ef87cafbb153b380b9675941adf062b304d5839535259699581a6f284fc"
    :COMPRESSED-BYTES 2673 :COMPRESSED-SHA256
    "741556cbbdb9473a425777852390065622048645cc947e7297f70d90ceb2b5b2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/process-01-variant/disjoint-read-processes.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5351 :STORED-BYTES 2024 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "disjoint-read-processes.lisp.gz" :UNCOMPRESSED-BYTES 5351
    :UNCOMPRESSED-SHA256
    "174cbf1d68eedc3bfb26954458503d4f290e24fa260c474420f1c7c08995cdc5"
    :COMPRESSED-BYTES 1694 :COMPRESSED-SHA256
    "9f9d35766dbb95d08df951915795b3e27be0d8cbc6433ffd8ab51a5e736d492c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/child-logs/004-latency-4.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2650 :STORED-BYTES 794 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "004-latency-4.stderr.gz" :UNCOMPRESSED-BYTES 2650 :UNCOMPRESSED-SHA256
    "9ceea0abbf293ffa1ae367d1b4436fd4cc9cceb3874d4e0766745f7bbf166b62"
    :COMPRESSED-BYTES 474 :COMPRESSED-SHA256
    "aa5a986c25efe0cfe62f10b48792809a2d5f74465b216448d4847244c287ce65"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/child-logs/003-latency-3.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2575 :STORED-BYTES 740 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "003-latency-3.stderr.gz" :UNCOMPRESSED-BYTES 2575 :UNCOMPRESSED-SHA256
    "cf76466bc34850d86c3d2f1c779a96aef6626ab44bad907af5992e895165ae1e"
    :COMPRESSED-BYTES 420 :COMPRESSED-SHA256
    "434dd580f8961ac48563d694996bd668fd1b11b63af4bdd266514a409eca21ee"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2630 :STORED-BYTES 740 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 2630 :UNCOMPRESSED-SHA256
    "10de1a9b8b7b21a96085e4b4ac71ee247c2c4ab75c3a543dab1284934aa6484e"
    :COMPRESSED-BYTES 420 :COMPRESSED-SHA256
    "b3b64250f4f7982df7d466d2d6927d8175254f0e8d410924541b9b50b5fc28a0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2596 :STORED-BYTES 718 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 2596 :UNCOMPRESSED-SHA256
    "7d9f9bf53bd2b0eeff55297b02547ce8a67c7e6cdddba3f9dcba0a5ecbc0690a"
    :COMPRESSED-BYTES 398 :COMPRESSED-SHA256
    "f2539b37e716c179b3beb18f1f3829cb1e0c5be4356a2157cbf48c38e37adff4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/windows/4-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20047 :STORED-BYTES 3606 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-4.lisp.gz" :UNCOMPRESSED-BYTES 20047 :UNCOMPRESSED-SHA256
    "5b1d6c95d9f99994015ac5bf9fd65504fa98b69208b177514be852da37b294b1"
    :COMPRESSED-BYTES 3296 :COMPRESSED-SHA256
    "eb58c10c546fafbeb86f8a0d12868ef9fcd848b56391bc3468e5967222876024"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/windows/4-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20051 :STORED-BYTES 3547 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-3.lisp.gz" :UNCOMPRESSED-BYTES 20051 :UNCOMPRESSED-SHA256
    "5b721461391eadcfd2f88bf5cf24e3813f62ebfb92ace5bf9471d85f7dd7f7f0"
    :COMPRESSED-BYTES 3237 :COMPRESSED-SHA256
    "3b804c85ef165e3c8c985f65c7c1ac95f6b07b7514b4bab8e437243688790ec3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/windows/4-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20050 :STORED-BYTES 3678 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-2.lisp.gz" :UNCOMPRESSED-BYTES 20050 :UNCOMPRESSED-SHA256
    "17c5c34884e9367dd40aa3ef7e52381c31d32764b861cdbb76de26a5bdffa6f1"
    :COMPRESSED-BYTES 3368 :COMPRESSED-SHA256
    "1389fce5b0d0186a09c608da654e725c842af4390e9625bf2fa078ddfea0b8ac"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/windows/4-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20053 :STORED-BYTES 3587 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-1.lisp.gz" :UNCOMPRESSED-BYTES 20053 :UNCOMPRESSED-SHA256
    "4c6948d3336326934abbcc8e935c5c7e002dd78d8da7428ee7dca4b07e1d406f"
    :COMPRESSED-BYTES 3277 :COMPRESSED-SHA256
    "69a0463c932de0cbbca32017ddbf7ddecf33b39f81f0a0770660c7d5a89956b3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/windows/4-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20066 :STORED-BYTES 4221 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "4-0.lisp.gz" :UNCOMPRESSED-BYTES 20066 :UNCOMPRESSED-SHA256
    "b8b21a5430056cf44ac7399e99845842e616590a443f863167e208a05be02fc2"
    :COMPRESSED-BYTES 3911 :COMPRESSED-SHA256
    "2f30e459baf80e670c85f70dbf75db525e46ae846e347df14b7ed808513d1ead"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/windows/2-4.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20062 :STORED-BYTES 3653 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-4.lisp.gz" :UNCOMPRESSED-BYTES 20062 :UNCOMPRESSED-SHA256
    "2cab62c23f99505abca1fb582488db618d979e8cce8179698e804a3b232d64df"
    :COMPRESSED-BYTES 3343 :COMPRESSED-SHA256
    "a81d9fdecefacb6f4aeaf51874567c01090638d9661c23bb95b2899c4cca57e0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/windows/2-3.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20150 :STORED-BYTES 4635 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-3.lisp.gz" :UNCOMPRESSED-BYTES 20150 :UNCOMPRESSED-SHA256
    "596be2a2da17b78ea0ba615bb19a0d116f37e06008837d0b22ca53eb56ec47df"
    :COMPRESSED-BYTES 4325 :COMPRESSED-SHA256
    "a08ca96a469fb2ab75bf9da2a627d1be40b663a1502cbb9ce56d4bcdef1be9e0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/windows/2-2.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20055 :STORED-BYTES 3577 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-2.lisp.gz" :UNCOMPRESSED-BYTES 20055 :UNCOMPRESSED-SHA256
    "868f95e7c2f99fbdd2ae46fa421cc62a383acf7687a5f3ac084fa7d88fa0f77e"
    :COMPRESSED-BYTES 3267 :COMPRESSED-SHA256
    "21d1e054462a864435b02d19df475467191ad88fce377360abaa27ed27ee02ad"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/windows/2-1.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20058 :STORED-BYTES 3506 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-1.lisp.gz" :UNCOMPRESSED-BYTES 20058 :UNCOMPRESSED-SHA256
    "18070914f943d81dfc43447b7c1d44fc45399a265b6b5d178a5a82078297d4f2"
    :COMPRESSED-BYTES 3196 :COMPRESSED-SHA256
    "e22cb446a59303be04d377d43b2f6b8509b79916a7f961af71a1fee2f02959a6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/read-control/windows/2-0.lisp"
   :STATUS :OK :ORIGINAL-BYTES 20053 :STORED-BYTES 4198 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "2-0.lisp.gz" :UNCOMPRESSED-BYTES 20053 :UNCOMPRESSED-SHA256
    "e5ae81d209e2f7aa8c91761fb410ded2ff76407cdaaf7d9bd770bb76de485b14"
    :COMPRESSED-BYTES 3888 :COMPRESSED-SHA256
    "0200fec40db8d7b69ba61402569bf7057236b8cdacdda87a4c1cc8eb0384bff8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/smoke-01/server.lisp"
   :STATUS :OK :ORIGINAL-BYTES 4912 :STORED-BYTES 2114 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "server.lisp.gz" :UNCOMPRESSED-BYTES 4912 :UNCOMPRESSED-SHA256
    "ada63befc646cf95f5554b342065b0732b1fb2551d272c475dfa2ccab178f2c5"
    :COMPRESSED-BYTES 1802 :COMPRESSED-SHA256
    "36eb6e6ba310221235006c2a4202e51c942dad5fa75ee7a9d3b4b47e65c1c971"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/smoke-01/bench.lisp"
   :STATUS :OK :ORIGINAL-BYTES 5346 :STORED-BYTES 1992 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "bench.lisp.gz" :UNCOMPRESSED-BYTES 5346 :UNCOMPRESSED-SHA256
    "e2c4b38ab77490b190e13e30f2219152a336562b9ab1de32a82d6a0cbc584f58"
    :COMPRESSED-BYTES 1681 :COMPRESSED-SHA256
    "e2db27027adf72affe1e44c28711e3851bf4d8c273364cb866af441b801d34aa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/smoke-01/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1902 :STORED-BYTES 945 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 1902 :UNCOMPRESSED-SHA256
    "16b20df12fbcb2394fd90d9dd0e40781ed6be944233f52e66dcf446477b4cae9"
    :COMPRESSED-BYTES 625 :COMPRESSED-SHA256
    "3ac3a866c9cb5710b22470154c28a098b9e6f4de71b99149aa4340f85c00bda5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/smoke-01/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1375 :STORED-BYTES 789 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 1375 :UNCOMPRESSED-SHA256
    "c45ddcf28ad1e18f09df9a02210b1f9ce4c542fa929692a5e74d13708e4074d1"
    :COMPRESSED-BYTES 469 :COMPRESSED-SHA256
    "8aa719dfde86648a1599ba429868e6b18ba8aabc97778641ec3795288a0600ad"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/smoke-02/child-logs/002-latency-2.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1895 :STORED-BYTES 946 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "002-latency-2.stderr.gz" :UNCOMPRESSED-BYTES 1895 :UNCOMPRESSED-SHA256
    "97eec4d8da04d5da732928b0088cd881b2b8cc6ebe232a90779dc094a7504960"
    :COMPRESSED-BYTES 626 :COMPRESSED-SHA256
    "12bd865da1ce00f68db44f8e67646424b3a6dc43b23dffe4ff78ce3ab2903a3d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/smoke-02/child-logs/001-latency-1.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1375 :STORED-BYTES 789 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-latency-1.stderr.gz" :UNCOMPRESSED-BYTES 1375 :UNCOMPRESSED-SHA256
    "22e1d56804880375201ddfff85f847e337b7e5cbbd095152b2caaefed6c20c49"
    :COMPRESSED-BYTES 469 :COMPRESSED-SHA256
    "e7fd1b32f2d82abdc27cac5e9a23954b8df8a13189be9465f291f0a2abfeccc1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-11.lisp"
   :STATUS :OK :ORIGINAL-BYTES 74130 :STORED-BYTES 8351 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-11.lisp.gz" :UNCOMPRESSED-BYTES 74130 :UNCOMPRESSED-SHA256
    "3212dc157c7e780b7e1ae229f7afca6140a5fa1964931341b44fc6eb2af8127e"
    :COMPRESSED-BYTES 8038 :COMPRESSED-SHA256
    "420a7c510fc3b8e894a7b37bc8e398da3c579fa4f8fc0d5a82cf75a83868f1a6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-10.lisp"
   :STATUS :OK :ORIGINAL-BYTES 22977 :STORED-BYTES 4612 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-10.lisp.gz" :UNCOMPRESSED-BYTES 22977 :UNCOMPRESSED-SHA256
    "19f4963cba8a658fa799b5877060b0a5d1ad22e22d38386161a115a27dc11a62"
    :COMPRESSED-BYTES 4299 :COMPRESSED-SHA256
    "3dfaa1bd28399e7d119aa85083c77092daa1ee410ec383fc7ba421b904b88567"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-08.lisp"
   :STATUS :OK :ORIGINAL-BYTES 331092 :STORED-BYTES 45767 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-08.lisp.gz" :UNCOMPRESSED-BYTES 331092 :UNCOMPRESSED-SHA256
    "824e92a6a239ff02b9c0b13279f40cb5c904c9b4d9d0f3e9f88a518f9fc22756"
    :COMPRESSED-BYTES 45452 :COMPRESSED-SHA256
    "b3493b03ba1de88762800d02e3b682c0ccc74d04ea589733687370a57101f423"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-06.lisp"
   :STATUS :OK :ORIGINAL-BYTES 24108 :STORED-BYTES 4497 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-06.lisp.gz" :UNCOMPRESSED-BYTES 24108 :UNCOMPRESSED-SHA256
    "c4710a58e67eba1a301350d785a85b2565c77af73cab11a71da22dc30ba0e2f6"
    :COMPRESSED-BYTES 4184 :COMPRESSED-SHA256
    "90857a4bd21b0614ef4b342902e806bf19656e320160eeabd411b1e92267deb6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-05.lisp"
   :STATUS :OK :ORIGINAL-BYTES 10141 :STORED-BYTES 2309 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-05.lisp.gz" :UNCOMPRESSED-BYTES 10141 :UNCOMPRESSED-SHA256
    "31e79dfb16bbaa7d8fd0f19f33f0cd11b7ade202ddf9a3d7c526099f8c75556e"
    :COMPRESSED-BYTES 1996 :COMPRESSED-SHA256
    "219724090ae7c271af60477855f2f962d26eb768a7347f2139c4937034a3a3a1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-04.lisp"
   :STATUS :OK :ORIGINAL-BYTES 6752 :STORED-BYTES 1923 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-04.lisp.gz" :UNCOMPRESSED-BYTES 6752 :UNCOMPRESSED-SHA256
    "288250f2e366c43d9a7f7826d0d8d2774e25c72793b6a03b1fca3308461b0266"
    :COMPRESSED-BYTES 1611 :COMPRESSED-SHA256
    "028f120bdba6dfff976c0b65f689ce9b9fa204ef9857e0e3d2bb7a57d3722d14"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-01.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27228 :STORED-BYTES 3193 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "SPK-01.lisp.gz" :UNCOMPRESSED-BYTES 27228 :UNCOMPRESSED-SHA256
    "e7116601daf8c007c24b5f53e1edf10420dccd90988a7fab02019f88588fb253"
    :COMPRESSED-BYTES 2880 :COMPRESSED-SHA256
    "390a7ec26458c4b0447fa59ef4103cec5da1d9b982d0fc14ac39205aaefcc9c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/ci/selftest-1793553521-75049/workflow.lisp"
   :STATUS :OK :ORIGINAL-BYTES 27784 :STORED-BYTES 3698 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "workflow.lisp.gz" :UNCOMPRESSED-BYTES 27784 :UNCOMPRESSED-SHA256
    "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"
    :COMPRESSED-BYTES 3383 :COMPRESSED-SHA256
    "65ef5865e2a8bcb699e2b198c990c96183d7e9da6772156178630f8e76782735"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/command-archive-collector-self-test-huOI7O/self-test-report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 28790 :STORED-BYTES 3537 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "self-test-report.lisp.gz" :UNCOMPRESSED-BYTES 28790 :UNCOMPRESSED-SHA256
    "d4e9296dd414ca229adf8e1804b64ed9d7bb07311176c45d3ec31ad973473225"
    :COMPRESSED-BYTES 3214 :COMPRESSED-SHA256
    "636508f0c3381702a2a6663d06d0ef1788769fc08d8ae00917d068e1285c1105")))
 :DRIVER-SHA256
 "5537f5929134d3b249c21ba8fad6b6c12367d60d2dae15eabe474283a00334c1" :LIMITS
 (:OWN-RESULT-ROOT-ONLY :RAW-BYTE-HASHES :VERIFIED-LOSSLESS-EXPANSION
  :SPECIAL-IPC-NODE-METADATA-ONLY :NO-NEGATIVE-FIXTURE-QUALIFICATION))
