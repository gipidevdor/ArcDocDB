(:KIND :DISJOINT-COMMAND-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "4002542322-command-75050-0" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-allocation" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-analysis-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-archive-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-baseline" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-baseline-analysis" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-baseline-calibration" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "disjoint-baseline-calibration-analysis" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-candidate" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-candidate-analysis" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-candidate-calibration" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "disjoint-candidate-calibration-analysis" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-candidate-repeat" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-candidate-repeat-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "disjoint-checks-2.6.9" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-cleanup-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-close-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-docs-setup" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-documentation" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-focused-01" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-focused-02" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-focused-03" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-focused-04" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-focused-05" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-full-2.6.9" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-identity-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-identity-self-test-02" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "disjoint-identity-self-test-03" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "disjoint-initial-archive" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-process-01" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-process-02" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-read-analysis" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-read-control" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-smoke-01" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-smoke-02" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-statistics" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-strict-2.6.10" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-unix-final-2.6.10" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-unix-final-2.6.9" :STATUS :OK :SOURCE-CONSISTENCY :STABLE))
 :FAILED-FIXTURE-ROOTS
 ("/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/"
  "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/"
  "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/")
 :SPECIAL-NODES
 ((:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/disjoint-runtime/v1-810.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569781374
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-runtime/v1-80.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569921755
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-runtime/v2-80.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569922728
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/compaction-runtime/v1-94.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569922997
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/compaction-runtime/v2-94.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569923924
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-runtime/v1-210.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569924105
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-runtime/v2-210.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569924136
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/group-runtime/v1-100.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569924032
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/group-runtime/v2-100.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569924063
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-group-runtime/v1-310.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569924251
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-group-runtime/v2-310.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569924301
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-runtime/v1-90.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569922925
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-runtime/v2-90.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569922959
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/runtime/v1-1.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569916464
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/runtime/v1-2.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569917060
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/runtime/v2-1.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569918223
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/runtime/v2-2.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569918605
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-loss-runtime/v2-420.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569924492
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-runtime/v1-410.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569924402
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-runtime/v2-410.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569924435
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES))
 :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793553521-75049/workflow.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/ci/selftest-1793553521-75049/workflow.lisp"
   :SHA256 "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"
   :BYTES 27784)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793553521-75049/tests.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/ci/selftest-1793553521-75049/tests.lisp"
   :SHA256 "72d8ca8f69a6df2de0109bffa94908d4d6e32d4b899bad224a91d9e25814a51c"
   :BYTES 2463)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793553521-75049/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/ci/selftest-1793553521-75049/report.lisp"
   :SHA256 "1ae97ae4103f11530749a8627e2ba2cc908579dc933ba091a1eafd94a48a5125"
   :BYTES 632)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793553521-75049/publication.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/ci/selftest-1793553521-75049/publication.lisp"
   :SHA256 "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc"
   :BYTES 1181)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793553521-75049/measure.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/ci/selftest-1793553521-75049/measure.lisp"
   :SHA256 "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c"
   :BYTES 2041)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793553521-75049/data.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/ci/selftest-1793553521-75049/data.lisp"
   :SHA256 "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2"
   :BYTES 3214)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793553521-75049/conditions.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/ci/selftest-1793553521-75049/conditions.lisp"
   :SHA256 "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f"
   :BYTES 663)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793553521-75049/boundaries.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/ci/selftest-1793553521-75049/boundaries.lisp"
   :SHA256 "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23"
   :BYTES 976)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/command-archive-collector-self-test-huOI7O/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/command-archive-collector-self-test-huOI7O/self-test-report.lisp"
   :SHA256 "d4e9296dd414ca229adf8e1804b64ed9d7bb07311176c45d3ec31ad973473225"
   :BYTES 28790)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002541969-command-64454-0/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002541969-command-64454-0/self-test-report.lisp"
   :SHA256 "7e47f646dc8ee821fcd8e3536a898b414e928bb78b4cbfd416d95f7b431a963b"
   :BYTES 157)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542322-command-75050-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/4002542322-command-75050-0/conservazione.lisp"
   :SHA256 "9a83b6536bc12c53b7bcd3d53f72aa67308f7ecdb0f97ba2e780dc68dc859593"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542322-command-75050-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/4002542322-command-75050-0/report.lisp"
   :SHA256 "3c04f69231f5a1b212ce4508b4e640211821b51c433bad2d50e5febd1f56e67e"
   :BYTES 362836)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-allocation/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-allocation/conservazione.lisp"
   :SHA256 "9cb94f11ef95c6c5760b0181c1b7a3db7f235868f8b116de6f7e8ea5bb2e5556"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-allocation/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-allocation/report.lisp"
   :SHA256 "ce6eb7dab7c4a0eb44cc38d69e093343eb219e596ac7695d0a4943d40f43fe34"
   :BYTES 362099)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-analysis-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-analysis-self-test/conservazione.lisp"
   :SHA256 "0b61c8a2bc78c198894211ecb96249af38801364700084ca6ce253f62ddd793a"
   :BYTES 1186)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-analysis-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-analysis-self-test/report.lisp"
   :SHA256 "59cf23608c8d2ad07921dd088550fec0756bbcbe796f0e516d77ea7e9d95729f"
   :BYTES 360791)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-archive-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-archive-self-test/conservazione.lisp"
   :SHA256 "5835fcac67460beff39ec2e72ed9011b1639a54848e3393367baa69435ae9a0c"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-archive-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-archive-self-test/report.lisp"
   :SHA256 "ee7eb69e5add13221781b47de1d96efd27ae5a8a9c5b8f1c45b0cfa29ab50cfa"
   :BYTES 362026)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-analysis/conservazione.lisp"
   :SHA256 "2e74ccf22849e27d1da8bb5353e04884d14e9d4ae7e7a7759ff3c95e33961114"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-analysis/report.lisp"
   :SHA256 "33347eae424931a8220cab128c0a84199cce6c75d96fb9d13354cb1dac4bd73d"
   :BYTES 361902)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline-calibration-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-calibration-analysis/conservazione.lisp"
   :SHA256 "85584e44477e640e410da5f278ff719bb91439d701cfb684f9ca5fb58940e073"
   :BYTES 1208)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline-calibration-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-calibration-analysis/report.lisp"
   :SHA256 "ec71b75e73308403cc2729d453356b7351e2119d9174f9afe644914b74732779"
   :BYTES 361181)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline-calibration/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-calibration/conservazione.lisp"
   :SHA256 "5123c3e3dc6a72a3e53291f688d7e07d306ea2393ea5a9b360c06c29240c0974"
   :BYTES 1190)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline-calibration/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-calibration/report.lisp"
   :SHA256 "dad6367bbbf2b9569116afd3a195ae020cb363249a8062f00aeb43bb52d4ccf4"
   :BYTES 365867)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline/conservazione.lisp"
   :SHA256 "2e35b3f75103edd0c2c9f06117360be097ca69fe5b6454431d8bf5207d220235"
   :BYTES 1166)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline/report.lisp"
   :SHA256 "3ff923a06aa75b7e382cf2e241da8ec7f433c29cdd1f1af9d2b7f77c95af5998"
   :BYTES 375313)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-analysis/conservazione.lisp"
   :SHA256 "979d603c20a6fc95b2f6e58e176c3dac50a090fb1ca8ed9bea203a5cb5f0300d"
   :BYTES 1186)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-analysis/report.lisp"
   :SHA256 "de7ead0dfaf469876b7b2dc86f7f30ea290fc400fb6692537459c026400cca98"
   :BYTES 362619)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-calibration-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-calibration-analysis/conservazione.lisp"
   :SHA256 "42d196de71de93c90daa126c02f7c5be4138849d5e4c25d6d2b1981ede02b8ad"
   :BYTES 1210)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-calibration-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-calibration-analysis/report.lisp"
   :SHA256 "241475a485bbca2de09f4790c85fa2b93143a4cea297b4ba57b85bb2af201af8"
   :BYTES 362302)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-calibration/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-calibration/conservazione.lisp"
   :SHA256 "34e551d4a4073ffc907bd55f8be0aa223c017b05bf3173177b2c333fd5c5c15c"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-calibration/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-calibration/report.lisp"
   :SHA256 "65d586a91b7dd61c3b86f4e8a92cc6cc00244d202b80e53257ebf8330c265eaf"
   :BYTES 366991)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-repeat-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-repeat-analysis/conservazione.lisp"
   :SHA256 "381deb5161588d4508db2d8747ce03586a58f077ca607e83dca570a8e653829f"
   :BYTES 1200)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-repeat-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-repeat-analysis/report.lisp"
   :SHA256 "447ce451eaf1afc24f86c74bff6e31b38b3993dddc0720d0f9f84f6351ba4ec3"
   :BYTES 362730)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-repeat/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-repeat/conservazione.lisp"
   :SHA256 "ebbd10a22fa0c04500d92f6409d711e088a169d24c2a9910e1686e4115eef0b1"
   :BYTES 1182)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-repeat/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-repeat/report.lisp"
   :SHA256 "196ab3d0f5d81059cc5004cdadc233ac200e4f6b6c362c0658a217578495e36b"
   :BYTES 376443)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate/conservazione.lisp"
   :SHA256 "499840b15b5707e064e3580c9087b3f129006b57ef13ec6b561f02ab1e759530"
   :BYTES 1168)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate/report.lisp"
   :SHA256 "4a2b71ca8ec5e6392cd36b5914a82fc3cb2774dabeb1c77a9559270a1482abd6"
   :BYTES 376437)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-checks-2.6.9/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-checks-2.6.9/conservazione.lisp"
   :SHA256 "2d5ee23bfcda1626dc72337484645dbd845a9c6d007ad9f68ddd4017678623df"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-checks-2.6.9/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-checks-2.6.9/report.lisp"
   :SHA256 "e36f517b20d01fa140659c40579349d9871ccfc00f487c421349a649d608769b"
   :BYTES 435061)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-cleanup-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-cleanup-self-test/conservazione.lisp"
   :SHA256 "597b247c138cdf0eabb7215e4247e210eb8e83e3e6919e5452e09fde9e5305e9"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-cleanup-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-cleanup-self-test/report.lisp"
   :SHA256 "85842bcc48a7582f3c4d18c8448f3566ee573a5458874f5f9457c870fe7da6c7"
   :BYTES 362057)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-close-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-close-self-test/conservazione.lisp"
   :SHA256 "7da8d09dce1f993b6bf3bfcd06226492b89b023df71377652aea496711cee982"
   :BYTES 1180)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-close-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-close-self-test/report.lisp"
   :SHA256 "7e485a9e45fda21e93c94583081b0953d82b68661f982f1601f5a7e5acf8e74b"
   :BYTES 362012)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-docs-setup/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-docs-setup/conservazione.lisp"
   :SHA256 "104e3316c1dd9bad22b419ca2afc213a261657d24a3194328289ffd1054592df"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-docs-setup/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-docs-setup/report.lisp"
   :SHA256 "c14c9031483f7833ea6c62e255945a97e1b5f0c97772e15bc9bc4b927e383ae3"
   :BYTES 362285)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-documentation/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-documentation/conservazione.lisp"
   :SHA256 "3b721cdbe18c0638abc39041d38962b1ded13bb24337e1622da359e1ce80030a"
   :BYTES 1176)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-documentation/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-documentation/report.lisp"
   :SHA256 "ab76122ead9700c6100ba78dc1a23669a29c0bb326a139ca8e1b7a93a77b7b88"
   :BYTES 367512)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-01/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-01/conservazione.lisp"
   :SHA256 "150ea5f5bbf6abf439d7c2f35c48a9f8b6bd89dcf08545f4cd4c598088cf268d"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-01/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-01/report.lisp"
   :SHA256 "ff474665d6b760b5d5e20c423025d0813f7f98298b9770427da4b43fab5ef753"
   :BYTES 369108)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-02/conservazione.lisp"
   :SHA256 "2238e7d9ab9759b04f1ccc9cf69c86665e909d6a40c5d0689462efc5985ff711"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-02/report.lisp"
   :SHA256 "ddd6631130a33448e4ddf1fe187be143b301b482a832cadb922aa5076f8aeee0"
   :BYTES 369072)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-03/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-03/conservazione.lisp"
   :SHA256 "3973c33b17636830cacb9a8ee2221a5dd18a51046f6c9948e1ba623f90c05bc4"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-03/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-03/report.lisp"
   :SHA256 "f90b61e72d007a11e4c44279b1e390f9fa81d9ca6eb89bf10ce2f56535b7ab97"
   :BYTES 369114)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-04/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-04/conservazione.lisp"
   :SHA256 "b632ef7d94cf124a4ba34cb2f300a4c85edf6b0ce6073022ec9e78c558466697"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-04/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-04/report.lisp"
   :SHA256 "72647ebd31b5943ae4d9ec55c030b0fd5ccfd36e799c6bb150c48f37673b1289"
   :BYTES 369570)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-05/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-05/conservazione.lisp"
   :SHA256 "6ee22026471d50420949180a1cb7fad2d33f88a1759a14f8108bc1292579c4ce"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-05/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-05/report.lisp"
   :SHA256 "ecbe99a316530cae7a0d8d7471b0ba98a597aa3ea0107cd3ebfae04fb3c8ada2"
   :BYTES 361863)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-full-2.6.9/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-full-2.6.9/conservazione.lisp"
   :SHA256 "0ed47d1e63cd270515d39d3d506fb5e076491a50a81625b9be25ed8d3477f60d"
   :BYTES 1754)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-full-2.6.9/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-full-2.6.9/report.lisp"
   :SHA256 "bc331597696bb43d294cf0f436a0a7a386a3177b925e93754b2a6059ed4cfad3"
   :BYTES 317)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-full-2.6.9/report.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-full-2.6.9/report.lisp.gz"
   :SHA256 "b656f56c1531c9bcaa934d67a0df3779988aa9eb1eb453f25c2c0bf915f55c7c"
   :BYTES 380096)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-identity-self-test-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-self-test-02/conservazione.lisp"
   :SHA256 "2ac2d302d08862d820505fc6047906ccb26fcae9f95d7fe515d50991916b4dda"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-identity-self-test-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-self-test-02/report.lisp"
   :SHA256 "a14f3fe797a27d8e33f28207173a6a218e7891abf10953b8455f83c57869a2c1"
   :BYTES 362729)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-identity-self-test-03/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-self-test-03/conservazione.lisp"
   :SHA256 "bf8c6489f0b1099fc9416a581362fd0eb32d211f9b3b7ec6752d19fe541b9bd4"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-identity-self-test-03/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-self-test-03/report.lisp"
   :SHA256 "a4c0e79146df61f1e36adb3be510388fd0920c99417209c0a9a192837e4cd1e8"
   :BYTES 362208)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-identity-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-self-test/conservazione.lisp"
   :SHA256 "4965113bc70f64d10caf576c28622cd08a6ccc84bfb9684b9d00c8cf990a2d52"
   :BYTES 1186)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-identity-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-self-test/report.lisp"
   :SHA256 "49bc998a13e04202cb3717c85645cb919a335befa9d26b7dd6089e97b55c015b"
   :BYTES 362014)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-initial-archive/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-initial-archive/conservazione.lisp"
   :SHA256 "31a90b245a603a57546884caeeb1f880bc52519fac985d6e2ccf74b4ab02ea50"
   :BYTES 1180)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-initial-archive/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-initial-archive/report.lisp"
   :SHA256 "79bb27e7f62e69917942ff13683012366480de928c47cfba1c887f58b8f96738"
   :BYTES 362049)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-process-01/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-process-01/conservazione.lisp"
   :SHA256 "60a6f9a1f1690f8645ab3428eeab406b4ac65450b00cc9d308c9179448805f90"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-process-01/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-process-01/report.lisp"
   :SHA256 "41093caf2916e22807516a5e8baaf8d252897c6048959b59673767934b59f358"
   :BYTES 369317)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-process-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-process-02/conservazione.lisp"
   :SHA256 "8a1e3a85e56fe1e3ed703844628353e066e2a0f33f8b07011115e72bca32d3c0"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-process-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-process-02/report.lisp"
   :SHA256 "f403888bfb2a1200c7d8e6cebdcabd193e7be3392d23e8ddd41b6f58431ce6cd"
   :BYTES 390903)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-read-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-read-analysis/conservazione.lisp"
   :SHA256 "203eed426fc329e141c350891b53f2e0fbb01d3b198962abdabc3d909b4d105f"
   :BYTES 1176)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-read-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-read-analysis/report.lisp"
   :SHA256 "d0bbb820ecc55bb5eb25867a2c7d7e6c1d57bcf1682046a7a76f482108e80892"
   :BYTES 362174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-read-control/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-read-control/conservazione.lisp"
   :SHA256 "607310b7017081b0ee9fbd321310c0660c303f7f7e8392af41dc97f6f625b144"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-read-control/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-read-control/report.lisp"
   :SHA256 "80111b5c383213a00131225c88fa4dcfe026ab21bf8ae886968f5e0c7f1e12f2"
   :BYTES 366994)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-smoke-01/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-smoke-01/conservazione.lisp"
   :SHA256 "74661dfa31f9ad4252a4fb50fbab57709f354a995a8a7f7ea60b9ef97e686153"
   :BYTES 1166)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-smoke-01/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-smoke-01/report.lisp"
   :SHA256 "7d7294ceba1f192bd820f9d5552cb1df78178b183efe9d08153b791ecffc0d0c"
   :BYTES 380378)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-smoke-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-smoke-02/conservazione.lisp"
   :SHA256 "de03518a3654fe8eff730ddb42ac9f45e90924113b3a4fb25d888ff1a078f089"
   :BYTES 1166)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-smoke-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-smoke-02/report.lisp"
   :SHA256 "201d8b396b8d078e0e487f71a4599b97fe876bbefbf43df0fae110e867baff04"
   :BYTES 363472)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-statistics/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-statistics/conservazione.lisp"
   :SHA256 "4bfd6e318ceba5430be060b2a841b117d84cc6715bb413f98af297af9828de8b"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-statistics/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-statistics/report.lisp"
   :SHA256 "8ae1b3cef5560359ce7f20c37ee94e27b6509d37ce3d6c40fc9b6c1f5dd7d481"
   :BYTES 362482)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-strict-2.6.10/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-strict-2.6.10/conservazione.lisp"
   :SHA256 "b4c8934bf2295bf71c09a0306a775c7151f5e53d74154700702e67adb9868538"
   :BYTES 1764)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-strict-2.6.10/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-strict-2.6.10/report.lisp"
   :SHA256 "b55250a66995bc1f61e61fe1d8053bfe0da24c317570b6d0d0b06d54b6b9884d"
   :BYTES 317)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-strict-2.6.10/report.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-strict-2.6.10/report.lisp.gz"
   :SHA256 "b3ec3664587ac60b3a6383192b357728d36ace2fe6e5427562de59b459d89b64"
   :BYTES 374736)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-unix-final-2.6.10/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-unix-final-2.6.10/conservazione.lisp"
   :SHA256 "ec52df1cf86e0e9ec09a9e753acaa634ccd1c3f073489e36e4ea4425e9e17a06"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-unix-final-2.6.10/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-unix-final-2.6.10/report.lisp"
   :SHA256 "78cd72a22cb39fec989a6ed77ef69ed7433c729ccb43af734125d2917cd89add"
   :BYTES 570171)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-unix-final-2.6.9/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-unix-final-2.6.9/conservazione.lisp"
   :SHA256 "54342784e1163024d5fef5bf0c994916566b2fceae3e722cab6ac89d99c2f0e9"
   :BYTES 1182)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-unix-final-2.6.9/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-unix-final-2.6.9/report.lisp"
   :SHA256 "6e05b6764bc3036cbf9e45f1d84a83c18f730443257ea7fc7038fdf472f9507b"
   :BYTES 570143)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/SPK-01.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-01.lisp"
   :SHA256 "e7116601daf8c007c24b5f53e1edf10420dccd90988a7fab02019f88588fb253"
   :BYTES 27228)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/SPK-02.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-02.lisp"
   :SHA256 "472207387acb78a8945e66f935b445d6a90e6c084ed153b08fae28d2e857c36c"
   :BYTES 1607)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/SPK-03.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-03.lisp"
   :SHA256 "cc0e5bcef56515804885d3ac453edc590c6f147fb0fbb4e18f05a4d4f0ce85ec"
   :BYTES 3664)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/SPK-04.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-04.lisp"
   :SHA256 "288250f2e366c43d9a7f7826d0d8d2774e25c72793b6a03b1fca3308461b0266"
   :BYTES 6752)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/SPK-05.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-05.lisp"
   :SHA256 "31e79dfb16bbaa7d8fd0f19f33f0cd11b7ade202ddf9a3d7c526099f8c75556e"
   :BYTES 10141)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/SPK-06.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-06.lisp"
   :SHA256 "c4710a58e67eba1a301350d785a85b2565c77af73cab11a71da22dc30ba0e2f6"
   :BYTES 24108)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/SPK-07.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-07.lisp"
   :SHA256 "17fb6db9fd665a8c2f63cac9188d1f633d253630a39e8112804ad2ec4f459862"
   :BYTES 318)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/SPK-07.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-07.lisp.gz"
   :SHA256 "f0c0d85762e7ac849fc812b3d5102da8effc43218ea2f5559fc06f2907eb5c61"
   :BYTES 411735)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/SPK-08.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-08.lisp"
   :SHA256 "824e92a6a239ff02b9c0b13279f40cb5c904c9b4d9d0f3e9f88a518f9fc22756"
   :BYTES 331092)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/SPK-09.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-09.lisp"
   :SHA256 "930eb336e1b9d40879d702b4d7261d53a51e9b219e94634bc8b9b6527094bbbb"
   :BYTES 2472)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/SPK-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-10.lisp"
   :SHA256 "19f4963cba8a658fa799b5877060b0a5d1ad22e22d38386161a115a27dc11a62"
   :BYTES 22977)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/SPK-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/SPK-11.lisp"
   :SHA256 "3212dc157c7e780b7e1ae229f7afca6140a5fa1964931341b44fc6eb2af8127e"
   :BYTES 74130)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/conservazione.lisp"
   :SHA256 "ae676a85bbe0f8ddf81399f668517068e7d8e9fa77444a378472b39f66df8af0"
   :BYTES 2352)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/report.lisp"
   :SHA256 "46f47a9968355d786ef4955eaf9176f1290df42b5b6f61fc26c92ba926867c37"
   :BYTES 318)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002542271-check-74106-0/report.lisp.gz"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/4002542271-check-74106-0/report.lisp.gz"
   :SHA256 "0b2019d5e4ee5e2db461c7cc23eab24d2ee08851a391021914b18d9b819ca49d"
   :BYTES 484183)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-19CWR6/0/scan-15.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-19CWR6/0/scan-15.lisp"
   :SHA256 "a0d36446a8ad4547139ec3cb171707443bd3b570f7ce94a423b333d33fce495a"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-19CWR6/0/scan-15.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-19CWR6/0/scan-15.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-19CWR6/0/scan-15.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-19CWR6/0/scan-15.stdout.log"
   :SHA256 "be21a5e93ebfa7a56e75e107375fe7585b3ca1084b549108af2d709b2721ddd5"
   :BYTES 4380)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-19CWR6/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-19CWR6/0/session.pid"
   :SHA256 "1593ae7ab927963a0b85e7029efeaeb9d7b6f9417b25da5e497e471aa404cd72"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-19CWR6/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-19CWR6/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-19CWR6/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-19CWR6/0/stdout.lisp"
   :SHA256 "d03293a4fbf6ad7d8ccba2178d79ced2ae75dc058c160d83ea3b9809ab8577da"
   :BYTES 295)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6ThQDB/0/scan-29.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6ThQDB/0/scan-29.lisp"
   :SHA256 "ca4b113faeb18823342d6bb4eba31d6fed1e62b35e5c9eb77bd2d348f9898ca0"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6ThQDB/0/scan-29.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6ThQDB/0/scan-29.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6ThQDB/0/scan-29.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6ThQDB/0/scan-29.stdout.log"
   :SHA256 "8603fff33da1b4942806a4a0e73f65cdf75962735948a76813de18f02ac1a650"
   :BYTES 4302)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6ThQDB/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6ThQDB/0/session.pid"
   :SHA256 "5c02381bd5d6985235581af1143f5d5fe0fbdc0925a8a824e39ac4293a478415"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6ThQDB/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6ThQDB/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6ThQDB/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6ThQDB/0/stdout.lisp"
   :SHA256 "e10dc33fa1068130d1c9738bd9c75a287d1dda23e478a72b5d6b239a3905f5ee"
   :BYTES 514)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/0/scan-21.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/0/scan-21.lisp"
   :SHA256 "ac8d5720c9bbcabaae6e1cf968eb345239575e74a053a57beea67289fbde010c"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/0/scan-21.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/0/scan-21.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/0/scan-21.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/0/scan-21.stdout.log"
   :SHA256 "28227a4d702af5e7eb56c0d993038f506008c970107f0a508feb4a0d6ea65d34"
   :BYTES 4392)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/0/session.pid"
   :SHA256 "7f1b840a39adb87fa0b5630d26a1c708c65ca3e314c3327dc96fc3bd80af76c4"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/0/stdout.lisp"
   :SHA256 "24be11fbc2d8f982171b574ace1e264b3da9b1c24cb1f3511822d10a0f31a124"
   :BYTES 750)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/1/scan-23.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/1/scan-23.lisp"
   :SHA256 "9d6eed936a8f02ceca0fcc5c868a4a15842542babd204c933a7d7ad31a1fc1ca"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/1/scan-23.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/1/scan-23.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/1/scan-23.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/1/scan-23.stdout.log"
   :SHA256 "b371297591a9e14b60b9e8dc6e0c3be9e2fd135ddd021041d97dec3a55408798"
   :BYTES 4374)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/1/session.pid"
   :SHA256 "e387294dc7f3947b50504ad2db2080280ffc3defd0ea3ddb37bd7538bed64f15"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/1/stdout.lisp"
   :SHA256 "c249c66009a6bfa909384943adb7711db08e3edfa37268c3a7ba811b9a1b9703"
   :BYTES 752)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/2/scan-22.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/2/scan-22.lisp"
   :SHA256 "44d0173f940bef2c4b4b1ef50da7483722084fab037d14fe17455d75d02211f6"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/2/scan-22.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/2/scan-22.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/2/scan-22.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/2/scan-22.stdout.log"
   :SHA256 "42a257e15777ae16c1278eb52f8a69aae0a0a2494dd083acdaa7b06b44d1c603"
   :BYTES 4374)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/2/session.pid"
   :SHA256 "eb32bf14616cf63f9821c4899ff2f2dacda05f504793049de1103c5edd77646c"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/2/stdout.lisp"
   :SHA256 "af9f1ac6fe34c647210ba8e9bb7dd19b6fff419f7b8b9c290940cd65ea24046d"
   :BYTES 286)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/3/scan-24.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/3/scan-24.lisp"
   :SHA256 "6299b6eff17c6f2cdd5e3bfe54ba9e89ff96d6a503f4da0313de801abca5b4bd"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/3/scan-24.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/3/scan-24.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/3/scan-24.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/3/scan-24.stdout.log"
   :SHA256 "2179d783235d2ed8d26e7d7012571608d156d15c367a8b525d33786733036400"
   :BYTES 4374)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/3/session.pid"
   :SHA256 "8a33fa5486025113a9f639959d115ecdadce80473c49bee1b49246b49a513edd"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-6yRv7H/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-6yRv7H/3/stdout.lisp"
   :SHA256 "903d77a85e53119b1b734f5a1abc4def1d4330e16014481559af37528dbc3547"
   :BYTES 286)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/0/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/0/scan-1.lisp"
   :SHA256 "9773ffbd4441a9fd2a4586921924fae1b4d3dd93fd85506835e8cd4e3654aaa2"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/0/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/0/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/0/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/0/scan-1.stdout.log"
   :SHA256 "1185aaa72d49daab28585df5350f0238bc1667f37b5c3a401f7303422ce8bb89"
   :BYTES 4320)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/0/session.pid"
   :SHA256 "7a4e6462276a85f5c1e8189aea78809ac1355471ff5b06afd945844ffa1d7068"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/0/stdout.lisp"
   :SHA256 "c9f1b09c56ac92de11e05b28d856d324e28db4ae5a46c8369797e71c600a0777"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/1/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/1/scan-2.lisp"
   :SHA256 "e79e90cd87751be52a0095622babd625233612e8fd445174beb4c8d4d327b8cf"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/1/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/1/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/1/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/1/scan-2.stdout.log"
   :SHA256 "2775d4bab34509154bb53fd43babe2cd953181a0afca813c8550159476d69d6b"
   :BYTES 4326)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/1/session.pid"
   :SHA256 "1090a1e62e61765b49c5d68a0f0ef53568313e872a972e630107d142d102e000"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/1/stdout.lisp"
   :SHA256 "ee9900379833f7d4928675e3138c8b021fff0be8c892adc332cb75e91d992361"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/2/scan-3.lisp"
   :SHA256 "0bfed26934610a6efd074f9e1b08a05b67e5fe1866d56ccfe469e03dedb0078b"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/2/scan-3.stdout.log"
   :SHA256 "c864ad0940e1eeb6a865a0cf01bfd9582267f400598b8549f06d61406c7de69b"
   :BYTES 4326)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/2/session.pid"
   :SHA256 "e62b4f5c1db9ac27102809033689d2c89d401188f421879bea326072e1649654"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/2/stdout.lisp"
   :SHA256 "602bea92086ebebf2686a386130e400818f3bba3a29fb862dd8dca40b22b3faf"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/3/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/3/scan-4.lisp"
   :SHA256 "53a68eaf49691f78601df9b8addbfa7d7ee9d20f6de31c69f2fccdbb07185598"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/3/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/3/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/3/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/3/scan-4.stdout.log"
   :SHA256 "e53738db204083f830fb46bd3e1876e65bcbec6381c654f3617e4545e024901c"
   :BYTES 4314)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/3/session.pid"
   :SHA256 "babeef912d61eb95967388c7ba55b7fa14d021128a92586624f1bb5a8229d943"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-7n8E9I/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-7n8E9I/3/stdout.lisp"
   :SHA256 "dbebc0d6405728cc6e496e6249a2ac2835b0276bf877c886856e27020f4fc081"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8sK8ZB/0/scan-12.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-8sK8ZB/0/scan-12.lisp"
   :SHA256 "3ca24c5d02fb26fde8c40339be5841021272de82c26332252898d632d9a377ab"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8sK8ZB/0/scan-12.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-8sK8ZB/0/scan-12.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8sK8ZB/0/scan-12.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-8sK8ZB/0/scan-12.stdout.log"
   :SHA256 "1184f779664484abf5ebf31c24daf09320cee5aa5f95bce6846511cc6d481236"
   :BYTES 4320)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8sK8ZB/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-8sK8ZB/0/session.pid"
   :SHA256 "6be2dcb1a493fceb698493c71a306cb9cb792568b4c01a76a3bf8802df967a9b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8sK8ZB/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-8sK8ZB/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-8sK8ZB/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-8sK8ZB/0/stdout.lisp"
   :SHA256 "e771d7eae8b61a16c1d18854bbb37f24408338d213c6d3460b490158243c6a62"
   :BYTES 308)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-9yxOop/0/scan-25.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-9yxOop/0/scan-25.lisp"
   :SHA256 "288293b2a70d9e381a246aee0c7003e3721d80c17623558963044fbc59da9f2c"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-9yxOop/0/scan-25.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-9yxOop/0/scan-25.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-9yxOop/0/scan-25.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-9yxOop/0/scan-25.stdout.log"
   :SHA256 "83259c87451a7fd1f8238dcefabcf172e604f1be2aaa9cbc313422d81f34895f"
   :BYTES 4326)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-9yxOop/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-9yxOop/0/session.pid"
   :SHA256 "411b8fdf92bad82b31892902f7c5e92f0bd46d1f1d4b16f985ddec15429b23a9"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-9yxOop/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-9yxOop/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-9yxOop/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-9yxOop/0/stdout.lisp"
   :SHA256 "48f1ddd540c86b8635321704385e9019d463bcbc0d7b2786f7b4874449c0c08f"
   :BYTES 563)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-B3GjHo/0/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-B3GjHo/0/scan-9.lisp"
   :SHA256 "c1d7e495cd03784793401f57e103b8135e361ad4d4e40201456af91e213109c6"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-B3GjHo/0/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-B3GjHo/0/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-B3GjHo/0/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-B3GjHo/0/scan-9.stdout.log"
   :SHA256 "2ccbea66d8c516ccd4562f6e79c892ed62208640f2f57c4868cfa833f86c039b"
   :BYTES 4296)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-B3GjHo/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-B3GjHo/0/session.pid"
   :SHA256 "02e2f094cdc2651485e8ab0e6b106683cc702628703cad5c6d53afa63988b816"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-B3GjHo/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-B3GjHo/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-B3GjHo/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-B3GjHo/0/stdout.lisp"
   :SHA256 "8acd2c5a0d0fb2116693c436de726fc6b4f6340bd0908ddd57bbf107bed31e3e"
   :BYTES 293)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BtV7qE/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-BtV7qE/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BtV7qE/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-BtV7qE/0/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BtV7qE/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-BtV7qE/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BtV7qE/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-BtV7qE/1/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BtV7qE/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-BtV7qE/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BtV7qE/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-BtV7qE/2/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BtV7qE/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-BtV7qE/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-BtV7qE/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-BtV7qE/3/stdout.lisp"
   :SHA256 "dd14a1553d51947a5bf7c1326637850b0797423a64fe0f82cfca8c7cdda8e0f0"
   :BYTES 91)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Cr32gW/0/scan-39.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Cr32gW/0/scan-39.lisp"
   :SHA256 "bbaac7c4115feca01c17776e3f1eaacc0fac63df3e093029797178965f721958"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Cr32gW/0/scan-39.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Cr32gW/0/scan-39.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Cr32gW/0/scan-39.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Cr32gW/0/scan-39.stdout.log"
   :SHA256 "ddd7da8164ddfd3aa237cb0ec56260c6282e15996d4a925f98d63d86a162b9cc"
   :BYTES 4272)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Cr32gW/0/scan-40.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Cr32gW/0/scan-40.lisp"
   :SHA256 "7b4abbd8f0fde732d10fcf126084378a788060f651f21f1f936b3344c76a3878"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Cr32gW/0/scan-40.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Cr32gW/0/scan-40.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Cr32gW/0/scan-40.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Cr32gW/0/scan-40.stdout.log"
   :SHA256 "219e0559c365c73c29b5ca951c7e4a001897eb9934c5ea7e0f0c972dc4034c3b"
   :BYTES 4248)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Cr32gW/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Cr32gW/0/session.pid"
   :SHA256 "eb22bacc07b92b15405e75552d48ecb2dec75a2b5abd454968c3e6eeb1f5184a"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Cr32gW/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Cr32gW/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Cr32gW/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Cr32gW/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-D1T1sj/0/scan-20.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-D1T1sj/0/scan-20.lisp"
   :SHA256 "9fb37ae206e0eb4c9acd9dd1c7c95cbe6ca155b925e920978a70356bc475816f"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-D1T1sj/0/scan-20.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-D1T1sj/0/scan-20.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-D1T1sj/0/scan-20.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-D1T1sj/0/scan-20.stdout.log"
   :SHA256 "866ed528255973ce977d08e629abfc1a9cce22154e5db0e4e47f194698365886"
   :BYTES 4332)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-D1T1sj/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-D1T1sj/0/session.pid"
   :SHA256 "e0ca09ef0105a0fcf22bb8a5bc255c7bfdc9574a1ad0b03df5dbb35644dcf733"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-D1T1sj/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-D1T1sj/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-D1T1sj/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-D1T1sj/0/stdout.lisp"
   :SHA256 "10074f2b1980910fd5550e38bec5bc5e3e3c66e4a372d7300f66a19f94b86edc"
   :BYTES 472)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GjnbWP/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-GjnbWP/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GjnbWP/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-GjnbWP/0/stdout.lisp"
   :SHA256 "8a9b488fc6a8c6f5868e459cdb74735df09e39ca1a8bc35c4de4645a87cb33d0"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GjnbWP/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-GjnbWP/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GjnbWP/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-GjnbWP/1/stdout.lisp"
   :SHA256 "dd8bee89592425a69aa8f60ff7e2a53b8096a2b56904580e340c71580351cfd1"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GjnbWP/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-GjnbWP/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GjnbWP/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-GjnbWP/2/stdout.lisp"
   :SHA256 "03d79d617a85f2779fec3d9fb5f312e13d8823bb5bb328199b69293a510337a5"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GjnbWP/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-GjnbWP/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-GjnbWP/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-GjnbWP/3/stdout.lisp"
   :SHA256 "306806d7135cbab595e4d0fa3f11b55c7252219f118944192d2f779b51d2a951"
   :BYTES 328)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-IaVvhF/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-IaVvhF/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-IaVvhF/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-IaVvhF/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-IaVvhF/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-IaVvhF/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-IaVvhF/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-IaVvhF/1/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-IaVvhF/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-IaVvhF/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-IaVvhF/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-IaVvhF/2/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-IaVvhF/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-IaVvhF/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-IaVvhF/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-IaVvhF/3/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/0/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/0/scan-1.lisp"
   :SHA256 "0188cd3eba351725054f5b48301237946756e7d3b085e22480096a048f02cd78"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/0/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/0/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/0/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/0/scan-1.stdout.log"
   :SHA256 "2ef44926c8a78edc859adafff4d571fe117800950c137c1e5ded8abb4e1d0122"
   :BYTES 4320)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/0/session.pid"
   :SHA256 "c1296e0501b6535ed5467fdbbf25e7e432c18727f843c990060053d15e5a690b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/0/stdout.lisp"
   :SHA256 "c9f1b09c56ac92de11e05b28d856d324e28db4ae5a46c8369797e71c600a0777"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/1/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/1/scan-3.lisp"
   :SHA256 "af808dcdf7416b285559653745326e04008dbad53ea121327c26a1d686c41364"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/1/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/1/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/1/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/1/scan-3.stdout.log"
   :SHA256 "a6b3ebc6caef6dfdb2044cdc3263ba7f803ef71b5c51862066554ceb4ee82bb5"
   :BYTES 4314)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/1/session.pid"
   :SHA256 "8013981762b9427d929101e9ea703731e75484d60f1397300a334e82a102202f"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/1/stdout.lisp"
   :SHA256 "ee9900379833f7d4928675e3138c8b021fff0be8c892adc332cb75e91d992361"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/2/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/2/scan-2.lisp"
   :SHA256 "d121a16d495b16b72fd3ae5d44989c67f63c79a4a9efaa211e9a7451498c03cd"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/2/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/2/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/2/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/2/scan-2.stdout.log"
   :SHA256 "d8f131686d4b05a91b625ca7e7460a6ebc9f0ecbbc1af2bf00cc1ef2fb5afbf0"
   :BYTES 4320)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/2/session.pid"
   :SHA256 "6cbf8d096df8e8ed17565fb4cdfc585f1c0dc8786f07a85ee8d3253807232900"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/2/stdout.lisp"
   :SHA256 "602bea92086ebebf2686a386130e400818f3bba3a29fb862dd8dca40b22b3faf"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/3/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/3/scan-4.lisp"
   :SHA256 "170b46f8ac30948f41f7ce0fd6d5e708f854ea3b4fe709c874649022b134ed7e"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/3/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/3/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/3/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/3/scan-4.stdout.log"
   :SHA256 "8b3c0fb91d5db25a457bac39d735dbcce14b0fa691a36b77e38197d074b02100"
   :BYTES 4314)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/3/session.pid"
   :SHA256 "db3ac96a9478328a0ecbd242de1e4dd56a205c442b9d456126989030906eea85"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JELszB/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-JELszB/3/stdout.lisp"
   :SHA256 "dbebc0d6405728cc6e496e6249a2ac2835b0276bf877c886856e27020f4fc081"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PC5z1d/0/scan-41.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-PC5z1d/0/scan-41.lisp"
   :SHA256 "186e8e74d6384015026402e0de494049c0cd01f5ed4e3bd56d76e386eb914a3d"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PC5z1d/0/scan-41.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-PC5z1d/0/scan-41.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PC5z1d/0/scan-41.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-PC5z1d/0/scan-41.stdout.log"
   :SHA256 "50c792644b96fe925ded30a661d05ebfdc83fc8c5e8f54f1491d71663db461f0"
   :BYTES 4278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PC5z1d/0/scan-42.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-PC5z1d/0/scan-42.lisp"
   :SHA256 "002844c402abc1f376105f74b12cc2cae3abf5d789cbaa4a24d2e5fd24ceb70b"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PC5z1d/0/scan-42.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-PC5z1d/0/scan-42.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PC5z1d/0/scan-42.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-PC5z1d/0/scan-42.stdout.log"
   :SHA256 "0445d5f0a92981f447b29b8866809c5eedaa1fb096b50834d15d1cffbb2a3c45"
   :BYTES 4302)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PC5z1d/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-PC5z1d/0/session.pid"
   :SHA256 "8df1c22d4a134c7f102870c65a83a7a08457f7ee8353eff576c81fea54e24950"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PC5z1d/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-PC5z1d/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-PC5z1d/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-PC5z1d/0/stdout.lisp"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RcfxGZ/0/scan-17.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-RcfxGZ/0/scan-17.lisp"
   :SHA256 "e396a2e57c3bb03cd6f5d8c87b7584cb39e4aedbfff822f946e61fa0956eec45"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RcfxGZ/0/scan-17.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-RcfxGZ/0/scan-17.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RcfxGZ/0/scan-17.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-RcfxGZ/0/scan-17.stdout.log"
   :SHA256 "1d211d0fded7fb7d11beb2b5bb26dbe673f11a7491ac3d56abbbdea86e3cb579"
   :BYTES 4350)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RcfxGZ/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-RcfxGZ/0/session.pid"
   :SHA256 "3107683553929ef51f9ec0637b2b7d7239f9da4d586dbc528527862e375e123b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RcfxGZ/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-RcfxGZ/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-RcfxGZ/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-RcfxGZ/0/stdout.lisp"
   :SHA256 "1860997d7a02b63921bb9f713f4c238c1391e97657e2f943e5ddcbd69ad45330"
   :BYTES 454)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TuaAJh/0/scan-26.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-TuaAJh/0/scan-26.lisp"
   :SHA256 "a6f9223d33b71a6ea69de1e702265bba7d149a44dfabb738379ef20aaf694f80"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TuaAJh/0/scan-26.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-TuaAJh/0/scan-26.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TuaAJh/0/scan-26.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-TuaAJh/0/scan-26.stdout.log"
   :SHA256 "a42efd1e758519702e121403aeb79483df7d7c8c5ac0171c3dade379493b09a6"
   :BYTES 4368)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TuaAJh/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-TuaAJh/0/session.pid"
   :SHA256 "b8b4075b88bfa60f70e9294fee0001f421e973edd9f86765a7f035c3fb0ac644"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TuaAJh/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-TuaAJh/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-TuaAJh/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-TuaAJh/0/stdout.lisp"
   :SHA256 "82c04e3037a89c485e817d3bfc27927becfa114f65524acd77f613581cd231be"
   :BYTES 498)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/0/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/0/scan-4.lisp"
   :SHA256 "537b4363502021f7b61cf901349c5cdf54401401d838e5c0bd856e4e21cc5ccf"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/0/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/0/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/0/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/0/scan-4.stdout.log"
   :SHA256 "eb888850f328f556d44defc978cff159492ef00fbb22ff501bc42edf884900e3"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/0/session.pid"
   :SHA256 "989015854d398fb10187f6743fd3e02a2a03da9d2cc47709a880734235971d9a"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/0/stdout.lisp"
   :SHA256 "3c3e1d0db8c3c9caca1995916027d78492d2f580d5e50cdf94d4e59281dd4aed"
   :BYTES 220)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/1/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/1/scan-1.lisp"
   :SHA256 "5bddf1a8a4cceca9c9418a0e1ac16b183b3f0102b741c774ec30f21333017607"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/1/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/1/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/1/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/1/scan-1.stdout.log"
   :SHA256 "b5c09140bfb33fca3e5a0aeeb55cac8d2c3477e09b44ed805a6941f26839bef0"
   :BYTES 4080)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/1/session.pid"
   :SHA256 "516dcce4ac170957a9cc38ca21b1ad0e0a0a09a309823878f72073fbacd25604"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/1/stdout.lisp"
   :SHA256 "1408b0f66ab661b8673cd350d40e192493dba517be5a2705d382c63c8438d28d"
   :BYTES 239)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/10/scan-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/10/scan-11.lisp"
   :SHA256 "ad4309445aec1cdb6a3d596c9c03ddf52a484e8847f958728290ac2517f278af"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/10/scan-11.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/10/scan-11.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/10/scan-11.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/10/scan-11.stdout.log"
   :SHA256 "9ef85a2cb39c539ccb9c71d3d4d1a404207cc6bf487a8de3da1b7d9b30036a09"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/10/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/10/session.pid"
   :SHA256 "107195866f84a4e90e959543607a1e049bd07a6c83ae8b0af59276143a16429f"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/10/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/10/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/10/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/10/stdout.lisp"
   :SHA256 "b41750084e5f40f0277ebeb497e481080e7fe941baa7d744125d2c371e440c85"
   :BYTES 240)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/11/scan-12.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/11/scan-12.lisp"
   :SHA256 "985dae60214b76235fd4e02c4d0126dcec5f3ef7afa3a772856c339384447644"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/11/scan-12.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/11/scan-12.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/11/scan-12.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/11/scan-12.stdout.log"
   :SHA256 "f85b91c6992e397f73f0476b674f48813320ba2a45acd5c1f2a66f6007b67aab"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/11/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/11/session.pid"
   :SHA256 "e7f96f2fb54d1eaf231e3d12f3f4aeed21489cb1f544312acad7573bb3a14eee"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/11/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/11/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/11/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/11/stdout.lisp"
   :SHA256 "e73c108e307445a6e4194c203f4b1ccd50a0f8bcf263d48fe3f388de1923c5b4"
   :BYTES 230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/12/scan-13.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/12/scan-13.lisp"
   :SHA256 "9b33795d16707ccb6a911ad150a93143459c0686f781c02b86ba272e7b68494c"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/12/scan-13.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/12/scan-13.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/12/scan-13.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/12/scan-13.stdout.log"
   :SHA256 "ae41fabadb71ec85613bdcfae951e7576800a653134e26f55f87b4bc6b4364d3"
   :BYTES 4050)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/12/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/12/session.pid"
   :SHA256 "c1de7f90ca46118b6a92810222aa6cc73a6ef96527105bf889f467b13ddbe0a6"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/12/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/12/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/12/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/12/stdout.lisp"
   :SHA256 "a502520708b2fd9a0b2abcd2f7fc2c040042c9249c3a9966193a4cc08b941c3b"
   :BYTES 240)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/13/scan-14.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/13/scan-14.lisp"
   :SHA256 "238e8f86caecec3b8b7a2772414b953e8b1a157bc1d8bee063bf31eb63e22636"
   :BYTES 398)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/13/scan-14.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/13/scan-14.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/13/scan-14.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/13/scan-14.stdout.log"
   :SHA256 "33c7ad2d87a1817c8e2bd19643708934b98d9789e8c8accf395c13301852fbb9"
   :BYTES 4044)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/13/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/13/session.pid"
   :SHA256 "a738fc0289b181aa8b339e61365ac346f20db60932f1ee29aa75d1c24fefb61b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/13/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/13/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/13/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/13/stdout.lisp"
   :SHA256 "4e98678e376e4a4625750ede03b73fcc8e9408333e83c8de7972982f0e35eddf"
   :BYTES 230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/2/scan-3.lisp"
   :SHA256 "405990708e3f7fd1b9b22a9741813340595964767b020fdae5094181c1fb239d"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/2/scan-3.stdout.log"
   :SHA256 "0002cca6501f77206e9287242fd70875f3be13eef94294bf90ecae1436551916"
   :BYTES 4062)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/2/session.pid"
   :SHA256 "fc43f86bd8ae648d98eea4a200230b425627543b814d038db25bc2391a66bfb3"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/2/stdout.lisp"
   :SHA256 "2e7fca2d9e2fc0d9537df579c78b038ae3c1477cd817cd40fffacbc4cda80597"
   :BYTES 229)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/3/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/3/scan-2.lisp"
   :SHA256 "db09e7516ece3904006f9a9da89cfedb441dd1cc32ff76fe5f6d0322e86f1c1f"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/3/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/3/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/3/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/3/scan-2.stdout.log"
   :SHA256 "d481349450734836052bb67efb5cd97e9f25323a5c3d2259d385163933adaac1"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/3/session.pid"
   :SHA256 "c9b33f08a483ab64fe267e03ff24d6488f6825b4cf1da55f849f298dc2af07a5"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/3/stdout.lisp"
   :SHA256 "25564bda945c2105101cc7d392d13240d14238d1a27e9acf8da5f5ae0875158d"
   :BYTES 232)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/4/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/4/scan-5.lisp"
   :SHA256 "40bf9c41027fac6350da41d070c978a3db1c4eb3f160ebf6af9663d8af9c25a9"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/4/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/4/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/4/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/4/scan-5.stdout.log"
   :SHA256 "7695f688c5c0617271587045c29cd004ef9e698e2944bf7f868fb9bb08117a81"
   :BYTES 4068)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/4/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/4/session.pid"
   :SHA256 "a8920e15d2d8107be25a97b03b4b65005b69a575f487ffab19257aaef6ba6bff"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/4/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/4/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/4/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/4/stdout.lisp"
   :SHA256 "2be099c08baa117e6464bba3c631874220ab09ec3b9d2dfa3fa3a54fb50eb69f"
   :BYTES 235)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/5/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/5/scan-6.lisp"
   :SHA256 "b8a32a08c11765be7f92ba9d15d7471af77e1dcd9aba2a85bfcab843c188a778"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/5/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/5/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/5/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/5/scan-6.stdout.log"
   :SHA256 "7912bcde84aad5f2ce5cb37af478c5cbb9df57b22b5c7fed74dff1d976a575e4"
   :BYTES 4056)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/5/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/5/session.pid"
   :SHA256 "b636063928dcf749391045d64ad22c90b38fcc00453d5ccd7e60c234e0226dbd"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/5/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/5/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/5/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/5/stdout.lisp"
   :SHA256 "c020b7cfad97537e62a5b046c84a727494a77429c7ba3d0b3c88699d692fadea"
   :BYTES 234)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/6/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/6/scan-7.lisp"
   :SHA256 "9908da1fe60c691da5d1d6e3f799b18d2e40a7401453e02b286e908f418b7e35"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/6/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/6/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/6/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/6/scan-7.stdout.log"
   :SHA256 "b5d3a599b421780c5976c073a257dccad5580818d0ab2484cc66047ca05d0339"
   :BYTES 4062)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/6/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/6/session.pid"
   :SHA256 "d5daa550b52c3235a6a16f2efb638e512bee111897dc91585c01553f2393f749"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/6/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/6/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/6/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/6/stdout.lisp"
   :SHA256 "632ff70d8e777211e68c9c6aa18fbbacd544790316335340e811020c0820425a"
   :BYTES 235)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/7/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/7/scan-8.lisp"
   :SHA256 "ffaf595679660f64cff7f0d2193e086d1dd031f7895fdbfbf49a41c0a4e7e710"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/7/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/7/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/7/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/7/scan-8.stdout.log"
   :SHA256 "6479e51533e4f76eb6e6767b3fede4de859130f54f48e6183a2c7df3df400155"
   :BYTES 4062)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/7/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/7/session.pid"
   :SHA256 "10ca5191d0920031e416089ed26f715cee0daf0447c094dd5ffbbc263fd095f7"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/7/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/7/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/7/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/7/stdout.lisp"
   :SHA256 "ba7fcea75bc2864a21f3b940483384447375da9144341dee0b2be1a13f199598"
   :BYTES 226)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/8/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/8/scan-9.lisp"
   :SHA256 "7a97eb0e27673265656a3031cfddeb6cac12f4a1e617bd4c1417e23ae523f259"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/8/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/8/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/8/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/8/scan-9.stdout.log"
   :SHA256 "9340d20e6822aa405b794a00328406e09498c26cfe4c9ede0ce2412cdc5a5e75"
   :BYTES 4062)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/8/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/8/session.pid"
   :SHA256 "eba4a60f71611609fedc66247b4f1e8cd6881a93929e6c1dda6321f68617d53b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/8/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/8/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/8/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/8/stdout.lisp"
   :SHA256 "31ea0941716566ef078790085e72650d0e0e931bcea03088f090c3f9e6fb9c66"
   :BYTES 239)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/9/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/9/scan-10.lisp"
   :SHA256 "c1c48f44cf9f2314da1438d501932f979b26b9e7b24d1fc7cd18a6066d4737e4"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/9/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/9/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/9/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/9/scan-10.stdout.log"
   :SHA256 "70211e632da2db4609d3fabf1cbe65502e12f53736e72605d3500d01ab277ce4"
   :BYTES 4062)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/9/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/9/session.pid"
   :SHA256 "344638b95844f48830f780c566e980425aa69be0174c7ef99cd197f4227f30c5"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/9/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/9/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-Ukq2Pc/9/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-Ukq2Pc/9/stdout.lisp"
   :SHA256 "15ed29b95978e446d17cd9f520516673c21d11b1ceb647a83107d088cbc75fb4"
   :BYTES 229)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/0/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/0/scan-5.lisp"
   :SHA256 "70762daa3c9e6ee583c335139d763dd0594348204c633ce7483cf70fae402746"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/0/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/0/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/0/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/0/scan-5.stdout.log"
   :SHA256 "9b577ee597e8cc7f5cab0e4a9e1a014c88a45e4bb0678f95892308a9f7b3edc6"
   :BYTES 4326)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/0/session.pid"
   :SHA256 "98ff2870bd1b1ddee6486155955490cf0b70df79f0b4529e96a038c526996ccf"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/0/stdout.lisp"
   :SHA256 "c9f1b09c56ac92de11e05b28d856d324e28db4ae5a46c8369797e71c600a0777"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/1/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/1/scan-6.lisp"
   :SHA256 "a8cab9d3f54cae5348e47eba932c07093b3500e394f02e6d90b7037197ccf42f"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/1/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/1/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/1/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/1/scan-6.stdout.log"
   :SHA256 "b1fe1eebbbaa00dd4d606f90793aaeb3a37f7c09564b0a706cbfd6dc765339f9"
   :BYTES 4320)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/1/session.pid"
   :SHA256 "7f06d31f8c33dffc1037701e35ed8e6c79ef85a27a9bc90020850a74cc4a7f5a"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/1/stdout.lisp"
   :SHA256 "ee9900379833f7d4928675e3138c8b021fff0be8c892adc332cb75e91d992361"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/2/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/2/scan-8.lisp"
   :SHA256 "d85ee420ec572104e3d3a81bf2da7ec51e81608e4d67c351d94dae50331f0390"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/2/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/2/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/2/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/2/scan-8.stdout.log"
   :SHA256 "f69bf4f74c73cc2c18ad8db1a37eda581e1efa5ec18f218423188dca38ecc99a"
   :BYTES 4308)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/2/session.pid"
   :SHA256 "6fb10a7bf0f6b38987660c95beff58c7f718a7d85afcf27c75b10b9af43ae51b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/2/stdout.lisp"
   :SHA256 "602bea92086ebebf2686a386130e400818f3bba3a29fb862dd8dca40b22b3faf"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/3/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/3/scan-7.lisp"
   :SHA256 "9c2dc9af4f20d8c6bb657ba9d7d566ab86551b30857563ab7ecd3510d042857b"
   :BYTES 394)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/3/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/3/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/3/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/3/scan-7.stdout.log"
   :SHA256 "5b4e97134c57dff28944eca6d7b3b215c414e2358b3226b3cbbc00af1ec40b00"
   :BYTES 4302)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/3/session.pid"
   :SHA256 "3a87ae3885d162bd452ce55630375567ce48b825add3f39438ac31935a04fb7b"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-W1vsyj/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-W1vsyj/3/stdout.lisp"
   :SHA256 "dbebc0d6405728cc6e496e6249a2ac2835b0276bf877c886856e27020f4fc081"
   :BYTES 280)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WNrw6z/0/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-WNrw6z/0/scan-10.lisp"
   :SHA256 "c78dd2bb90b8b2af1d4d88d4094e6e8527e912683117d96f45724a49a4025fcc"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WNrw6z/0/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-WNrw6z/0/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WNrw6z/0/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-WNrw6z/0/scan-10.stdout.log"
   :SHA256 "c57b669cfb788733325ca5eaf199eec8e47b8c5ed2cceacfcefd8308d1cb63e3"
   :BYTES 4302)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WNrw6z/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-WNrw6z/0/session.pid"
   :SHA256 "7388ce8b33f77a514317abcb33e6db4fc3854e1c2671f83d650061b1f939a119"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WNrw6z/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-WNrw6z/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-WNrw6z/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-WNrw6z/0/stdout.lisp"
   :SHA256 "8825deaade6a0e5395f9998b30c5f81b4a84da8d16c3ea4d85dd7ec1ca2af95c"
   :BYTES 295)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YJSFjl/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-YJSFjl/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YJSFjl/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-YJSFjl/0/stdout.lisp"
   :SHA256 "28fcfe32dee6d5829efb8a2f6f176d56938bd64a2d697c0e7084ef82f5eb551c"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YJSFjl/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-YJSFjl/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YJSFjl/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-YJSFjl/1/stdout.lisp"
   :SHA256 "a4f8beefe6c381555fb8c95887814f06e1ac219cac7ce3c05736b2cdec9e8e17"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YJSFjl/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-YJSFjl/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YJSFjl/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-YJSFjl/2/stdout.lisp"
   :SHA256 "6740b17b309dc9d4360df19db80fb5fc13badd072465d8cd6e98624116107256"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YJSFjl/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-YJSFjl/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-YJSFjl/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-YJSFjl/3/stdout.lisp"
   :SHA256 "f4b00833f4c24f70cdc0ff494b68b02707039ddf0c50cec09aede25dc7da75c1"
   :BYTES 330)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aCVDy4/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-aCVDy4/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aCVDy4/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-aCVDy4/0/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aCVDy4/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-aCVDy4/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aCVDy4/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-aCVDy4/1/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aCVDy4/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-aCVDy4/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aCVDy4/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-aCVDy4/2/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aCVDy4/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-aCVDy4/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-aCVDy4/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-aCVDy4/3/stdout.lisp"
   :SHA256 "08ae2f361210b40f912c145f2f09a1a0e7d50ec51207a6e51a261e7654c87058"
   :BYTES 12)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/0/scan-35.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/0/scan-35.lisp"
   :SHA256 "140c0e0889735286564b7f9d22894388452e1b8812c99327c519c99f15709043"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/0/scan-35.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/0/scan-35.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/0/scan-35.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/0/scan-35.stdout.log"
   :SHA256 "48c9a7d6c9098e6d0bceee8ba0236801c8ba2f90f765accf686818628a1676b4"
   :BYTES 4242)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/0/session.pid"
   :SHA256 "66d55cb6d930c54b446832c937549e1fdf6a7e63e7ed9c9a8c85d27cf51b7e56"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/0/stdout.lisp"
   :SHA256 "2d5839be5fa429ac28ad723a2ae2f326c4ab2425f6d06c2e09e6e5a0765048ce"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/1/scan-38.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/1/scan-38.lisp"
   :SHA256 "6b9a77d5ba014f92409cc7483fb0463da783e7802606c7b0f39e44a0351b5e52"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/1/scan-38.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/1/scan-38.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/1/scan-38.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/1/scan-38.stdout.log"
   :SHA256 "9af88659a4d2ba90c09c8cb8df65e7b98eb2d681d8a80458cc284b9fbe04b983"
   :BYTES 4248)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/1/session.pid"
   :SHA256 "dca159980e72b401c53584871d53b989400b861d86f6a32258d59fc416c13ee7"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/1/stdout.lisp"
   :SHA256 "64a3962ca6dbcc698de1e5c4f607cd47a1c616de41e586bb2023a91130dd15a3"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/2/scan-37.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/2/scan-37.lisp"
   :SHA256 "1e2f546e0e5c29af6ebda61c9fc7a375ab19526080f0b1f5bcfc6489f7bd386b"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/2/scan-37.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/2/scan-37.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/2/scan-37.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/2/scan-37.stdout.log"
   :SHA256 "ce1462d3338178f79b312524377f37458b6469525f91a112f4aae3130550f53b"
   :BYTES 4248)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/2/session.pid"
   :SHA256 "804233f2ea170d3bb55fe653d973d263eb1b35374b71dd4196a9bd958aa2b3a2"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/2/stdout.lisp"
   :SHA256 "25e8eaa2e8f0312379916d4b337382fb60ba7e763937c4846fe933a7857ea2f7"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/3/scan-36.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/3/scan-36.lisp"
   :SHA256 "81ec3d76bdd4779ac69914807a9b9c798cbc31944528bee49bca05d009395a86"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/3/scan-36.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/3/scan-36.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/3/scan-36.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/3/scan-36.stdout.log"
   :SHA256 "32c2637235ea8d3b79ebe1600ebd14c6af5dcc6f52771e574ce3ce31fcb919f7"
   :BYTES 4248)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/3/session.pid"
   :SHA256 "577cf01a73bda43edbc8e3efc652949669161a5180178d493429ded80d47184d"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eQ17Tu/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eQ17Tu/3/stdout.lisp"
   :SHA256 "965478cf54b0a344666025f7108faa96052453f2f3bf7baa908703f06ebe45f6"
   :BYTES 279)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/0/scan-31.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/0/scan-31.lisp"
   :SHA256 "b72bc61af0a0243c86a2d94ecb8800b8e352f2b7a94a5ce49b737f9d7968a478"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/0/scan-31.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/0/scan-31.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/0/scan-31.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/0/scan-31.stdout.log"
   :SHA256 "ebaa0e4f198cdaa981fd0deadfc46c997ba03dd27fc7c1c19a0a239963e56742"
   :BYTES 4212)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/0/session.pid"
   :SHA256 "7bc46487c62fd7c2d20d2744ff3c91f30ee87d8b72ff2a400bb6ec70c4565acf"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/0/stdout.lisp"
   :SHA256 "7e34153db7ba0dcae0610903e30cae477eb2de6227b1d7d402d2fac264a98ccd"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/1/scan-32.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/1/scan-32.lisp"
   :SHA256 "dcb4081b0febd7245a0a69bc01c5b9f55a536aada0f92993bbb5dbab3d789746"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/1/scan-32.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/1/scan-32.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/1/scan-32.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/1/scan-32.stdout.log"
   :SHA256 "5fa2d9b8c69deb4ced59f03f43342a0bb84fce55f58e39e9ab7a1118a24e307e"
   :BYTES 4212)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/1/session.pid"
   :SHA256 "8bd9e7d06bcbdaf0120f86dc2ca4ae4dd6d5b3509f4c1ddd8ea9301727905bd2"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/1/stdout.lisp"
   :SHA256 "8bf60c15ead3e0cbd4ce41cfc3c038fccce3d7af63137d06e5c32749813f1ccd"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/2/scan-34.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/2/scan-34.lisp"
   :SHA256 "9209d152927c06bf206df1157b772e4201e59cc25f4b083bd000a1af6176430f"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/2/scan-34.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/2/scan-34.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/2/scan-34.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/2/scan-34.stdout.log"
   :SHA256 "0caaffc42969d3491febaa345917dc92703217d25c457ce4cf1c636b3b42c3c2"
   :BYTES 4230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/2/session.pid"
   :SHA256 "a76a4b8be4734811d20981506adce95ee967958a2531c3d7312687505862dfc9"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/2/stdout.lisp"
   :SHA256 "d42b43203c2bbb358a84e1ff57ded172fce0f81c1b16347dd1e7e357d260dc82"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/3/scan-33.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/3/scan-33.lisp"
   :SHA256 "ae75b154e691d09909714c90fe9d5d9c4f7df769794bc80d7c8051ea3345d7f5"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/3/scan-33.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/3/scan-33.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/3/scan-33.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/3/scan-33.stdout.log"
   :SHA256 "b753407964f399e271dc2fa5c09436dd6850cf787b711e1346ed6bb89841dec0"
   :BYTES 4230)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/3/session.pid"
   :SHA256 "db295d594ce48392243a0e969eb58c59f1421c65f8ea50ba98ead194bc4640b8"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-eaCchB/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-eaCchB/3/stdout.lisp"
   :SHA256 "8fca7ec0477189733ea612ac4d9b70352c21f436791df7d97b238613223529de"
   :BYTES 278)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-g76HXB/0/scan-28.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-g76HXB/0/scan-28.lisp"
   :SHA256 "0d61406c76d8e81162c0d17ae6b99a72e08249449fb5753acb4bb1cc2558d70c"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-g76HXB/0/scan-28.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-g76HXB/0/scan-28.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-g76HXB/0/scan-28.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-g76HXB/0/scan-28.stdout.log"
   :SHA256 "e9853c1f17f3b5f7420739e5ba3e3e2173c7a4888b61ac1563b01836ef18e060"
   :BYTES 4320)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-g76HXB/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-g76HXB/0/session.pid"
   :SHA256 "405ef4b059573e451d9e8413adbfc5908a93be96bd1e55933b6de992d35e51f5"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-g76HXB/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-g76HXB/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-g76HXB/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-g76HXB/0/stdout.lisp"
   :SHA256 "aee84fad37c443999c1115859100cf81c23f93eb75a53dbfd33d173b77b4b503"
   :BYTES 277)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gaQeC8/0/scan-30.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-gaQeC8/0/scan-30.lisp"
   :SHA256 "75cd6a6887acc73efbd361c0dcd7ffe6ecdd4f0947e0a49df4575c0864da8715"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gaQeC8/0/scan-30.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-gaQeC8/0/scan-30.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gaQeC8/0/scan-30.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-gaQeC8/0/scan-30.stdout.log"
   :SHA256 "c86abb3ae34898966a804dd46124f5a6315204dee7c5d6372fb44f8a2e26602a"
   :BYTES 4260)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gaQeC8/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-gaQeC8/0/session.pid"
   :SHA256 "b6945b36ef1728e818b3a041e3a126eb968d60b86223f9334f646a1db9258236"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gaQeC8/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-gaQeC8/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-gaQeC8/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-gaQeC8/0/stdout.lisp"
   :SHA256 "9cb794153ddd105bf6841875a0b098f10fcfad548b11e2131c659516bb780ca5"
   :BYTES 927)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hA3Yui/0/scan-16.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-hA3Yui/0/scan-16.lisp"
   :SHA256 "ee927328b134e31b12cec1936fb4fcf3500c9ea2963aa18afaee39b2ff94e726"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hA3Yui/0/scan-16.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-hA3Yui/0/scan-16.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hA3Yui/0/scan-16.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-hA3Yui/0/scan-16.stdout.log"
   :SHA256 "3a9b8796755bb57c5681a7f7e888ff4f685992579cdf1f0f4e89f2b318ed6fe1"
   :BYTES 4380)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hA3Yui/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-hA3Yui/0/session.pid"
   :SHA256 "495b422ee8883ffa25f49805fd5e5b6713045ca34ed819e693d0bc4c0040049f"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hA3Yui/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-hA3Yui/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-hA3Yui/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-hA3Yui/0/stdout.lisp"
   :SHA256 "a1e3050a83779fa5b618106b6e6c52dfa5b78d7d4807e98508c5ad898fb5d8ca"
   :BYTES 452)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-n7WtWp/0/scan-19.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-n7WtWp/0/scan-19.lisp"
   :SHA256 "a488f54e0c06a0369b98db00446d1dbaebb5f230623c095901897f201757b496"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-n7WtWp/0/scan-19.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-n7WtWp/0/scan-19.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-n7WtWp/0/scan-19.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-n7WtWp/0/scan-19.stdout.log"
   :SHA256 "e952ad754489ae7ee2b234387fb17a627909ebc9a01bf7a0b410989ac8866fa0"
   :BYTES 4356)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-n7WtWp/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-n7WtWp/0/session.pid"
   :SHA256 "46e83ae478a13cae69b8282a128a73d7266012ea8c7549740fe654722802347a"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-n7WtWp/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-n7WtWp/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-n7WtWp/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-n7WtWp/0/stdout.lisp"
   :SHA256 "2adf7dd4d8d1e62aeaf2e73d7558f30da6a81705e015a71e8214795cb7dd85bd"
   :BYTES 697)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-nPKbb4/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-nPKbb4/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-nPKbb4/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-nPKbb4/0/stdout.lisp"
   :SHA256 "023a8c5b06226339e75e7f6db203b89a0261ed4c11958c2aada8a63bb2a440b3"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-nPKbb4/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-nPKbb4/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-nPKbb4/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-nPKbb4/1/stdout.lisp"
   :SHA256 "023a8c5b06226339e75e7f6db203b89a0261ed4c11958c2aada8a63bb2a440b3"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-nPKbb4/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-nPKbb4/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-nPKbb4/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-nPKbb4/2/stdout.lisp"
   :SHA256 "023a8c5b06226339e75e7f6db203b89a0261ed4c11958c2aada8a63bb2a440b3"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-nPKbb4/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-nPKbb4/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-nPKbb4/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-nPKbb4/3/stdout.lisp"
   :SHA256 "023a8c5b06226339e75e7f6db203b89a0261ed4c11958c2aada8a63bb2a440b3"
   :BYTES 268)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-oCropQ/0/scan-11.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-oCropQ/0/scan-11.lisp"
   :SHA256 "3c056ff5c8f41e7f4c23425f29715909c93786c0d0e1f7fc48bd1d9c9f6d63da"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-oCropQ/0/scan-11.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-oCropQ/0/scan-11.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-oCropQ/0/scan-11.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-oCropQ/0/scan-11.stdout.log"
   :SHA256 "68938b01cdafa0be869ef1e22fbd429f7b0631d05c257b66fa42fda840fedf97"
   :BYTES 4308)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-oCropQ/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-oCropQ/0/session.pid"
   :SHA256 "9d2dfbf0304af84487ed11e7c5bbdbdc9048afb7d158740ae839c300e2800980"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-oCropQ/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-oCropQ/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-oCropQ/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-oCropQ/0/stdout.lisp"
   :SHA256 "c15e4b34fdf890069bf1e22bc4d3d6495bbb343d90f5ce5bc277d7fa8ab8cdf9"
   :BYTES 296)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-oLoqlR/0/scan-13.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-oLoqlR/0/scan-13.lisp"
   :SHA256 "983aad22d7366b306bc92680c77736c15440e5cc3e33fb6f681fc3986dacfe12"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-oLoqlR/0/scan-13.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-oLoqlR/0/scan-13.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-oLoqlR/0/scan-13.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-oLoqlR/0/scan-13.stdout.log"
   :SHA256 "10af5c436f9833bd12d1041e1a7c0f086f8aee1cf1e9f84cd744e2aca2d9963d"
   :BYTES 4380)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-oLoqlR/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-oLoqlR/0/session.pid"
   :SHA256 "71a4586d1886c2f3de9cb4e9972dce7106c8b9ddddd77809bcd6680024bfb472"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-oLoqlR/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-oLoqlR/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-oLoqlR/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-oLoqlR/0/stdout.lisp"
   :SHA256 "591d468b66fbbe7c1600c8253ba29d52fca5a90c43d5e0b7baa8a2ce9be9b85b"
   :BYTES 307)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pA1QyJ/0/scan-18.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-pA1QyJ/0/scan-18.lisp"
   :SHA256 "d4d9821c7ccc059dbf72b203d61463a841dfae0c36b6c814c60c2069d9294f92"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pA1QyJ/0/scan-18.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-pA1QyJ/0/scan-18.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pA1QyJ/0/scan-18.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-pA1QyJ/0/scan-18.stdout.log"
   :SHA256 "fc202b65140918fa89b33c40c622018ac91bbe797b01d9163279fce620d95832"
   :BYTES 4326)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pA1QyJ/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-pA1QyJ/0/session.pid"
   :SHA256 "00d1d40fbdaec606fc49d2e57d33bf6b15c4df0754b366fc2dc4409c8b05b317"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pA1QyJ/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-pA1QyJ/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-pA1QyJ/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-pA1QyJ/0/stdout.lisp"
   :SHA256 "a25d7413f5a5ccbbf47353a009bacd0b15cba0ba53b7141a08c09bd68da30c76"
   :BYTES 474)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ucFljU/0/scan-27.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-ucFljU/0/scan-27.lisp"
   :SHA256 "20de9a7d0502951033f7bc7dc662c7d9914a43d3aa84aacb0eaece2737d2ff8d"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ucFljU/0/scan-27.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-ucFljU/0/scan-27.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ucFljU/0/scan-27.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-ucFljU/0/scan-27.stdout.log"
   :SHA256 "afd2e9d25a49eb9025ee4b7cde742f8f476645447d510100fc4e857137477d59"
   :BYTES 4344)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ucFljU/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-ucFljU/0/session.pid"
   :SHA256 "975b49ba43f72fe0e8877a0653989b44eec275f3091f3a16140d413edcc21ee9"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ucFljU/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-ucFljU/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-ucFljU/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-ucFljU/0/stdout.lisp"
   :SHA256 "aee84fad37c443999c1115859100cf81c23f93eb75a53dbfd33d173b77b4b503"
   :BYTES 277)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-v7nsHd/0/scan-14.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-v7nsHd/0/scan-14.lisp"
   :SHA256 "fdf7452c8bbc0fd0859cd3387c16bd85187153b798bd496b8e51a6071746762c"
   :BYTES 396)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-v7nsHd/0/scan-14.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-v7nsHd/0/scan-14.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-v7nsHd/0/scan-14.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-v7nsHd/0/scan-14.stdout.log"
   :SHA256 "151b4867153b1be219b10788d7640fbc90c45fb59e8be3a9e9dcc12703ace01b"
   :BYTES 4380)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-v7nsHd/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-v7nsHd/0/session.pid"
   :SHA256 "c1ed5ce883d91467de9f6afbefacb74a4618229cbd50fe45067f0ee9902ab816"
   :BYTES 6)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-v7nsHd/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-v7nsHd/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-v7nsHd/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/support/evidence-check-v7nsHd/0/stdout.lisp"
   :SHA256 "d4fbaa13a458e1ebca8c422b027435d265f18e1f72e9da1aee0329c6828b2918"
   :BYTES 308)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/001-latency-1.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/001-latency-1.stderr"
   :SHA256 "c45ddcf28ad1e18f09df9a02210b1f9ce4c542fa929692a5e74d13708e4074d1"
   :BYTES 1375)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/001-latency-1.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/001-latency-1.stdout"
   :SHA256 "b5e444ea1015119926ee6d279bc08b75c1b248239644e5872209000b9e4b694d"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/002-latency-2.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/002-latency-2.stderr"
   :SHA256 "16b20df12fbcb2394fd90d9dd0e40781ed6be944233f52e66dcf446477b4cae9"
   :BYTES 1902)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/002-latency-2.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/002-latency-2.stdout"
   :SHA256 "2ccac43831999c8ee8bddf66c02551c742c4f4703af3a26857edc9d917116845"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-1/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-1/0000000000000002.seg"
   :SHA256 "b5a9db25f4699308de34a2f17f565303b0ee8b5953d88d90fd038c5294f25d96"
   :BYTES 76168)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-1/control.log"
   :SHA256 "3d7935a7e53cf252c93104ccd83add69ddb63f44643d8da3e3a18855ef6722fc"
   :BYTES 188)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-1/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/0000000000000002.seg"
   :SHA256 "ca314aa85bd3fab227d05b7a2866864e6f2b289702a7bd0248f209cf7eb165d9"
   :BYTES 130528)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-2/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/0000000000000003.seg"
   :SHA256 "8c000329a73bea09ba14417ea07d2eaa16ea86a857482a5daf417ee0dd645aac"
   :BYTES 130528)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-2/0000000000000004.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/0000000000000004.seg"
   :SHA256 "863218cf143f6e92666670b9a5393969b89a24b1a232e92125958f8b34564a3c"
   :BYTES 43552)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/control.log"
   :SHA256 "50da8b7f43427f11a3048009ede49b5842ec62fc11507e25029fb6ef7c4bd43b"
   :BYTES 228)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/001-v1-server-810.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/001-v1-server-810.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/001-v1-server-810.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/001-v1-server-810.stdout"
   :SHA256 "6fc2140b1989e9c429f58e469755722439c79e2cb04c03162a578fde7d01e4b8"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/002-v1-server-811.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/002-v1-server-811.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/002-v1-server-811.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/002-v1-server-811.stdout"
   :SHA256 "e5fa5803dad19a540f95227acd3cb5586a0dfd062e28e1a3003bbb6838002e98"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/0000000000000002.seg"
   :SHA256 "c3b721df62aea43ea8823272fdd1c5079d21b17b14d942693bfd4dc5983542ba"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/0000000000000003.seg"
   :SHA256 "5a28e66df70af63011d80749d5e81dec7d675abdaf8795cc8223eb7a0fe55133"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/control.log"
   :SHA256 "cccd23f9a41bae7486b9ad950c62a42b63c5cef33250df4e5c5d12c6a6cb5b42"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/001-v1-server-1.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/001-v1-server-1.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/001-v1-server-1.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/001-v1-server-1.stdout"
   :SHA256 "beee9c67c85fba5fac1b8d0168ef1dee0b3e0979fc8ef6458948d819221b3461"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/002-ping.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/002-ping.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/002-ping.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/002-ping.stdout"
   :SHA256 "3460f415a8d2fce8d3844e17ceea1ce0834d44a958264b19cfd6bd823c5282e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/003-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/003-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/003-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/003-put.stdout"
   :SHA256 "77af5054c07fc8a0a2a2de4e179d73b7f75300fa4b29298e88ede615c093dede"
   :BYTES 45)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/004-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/004-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/004-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/004-get.stdout"
   :SHA256 "4d60f496e63d995da633d16612b8d003819cc55788b7f104db1c2af0fcbdf056"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/005-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/005-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/005-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/005-put.stdout"
   :SHA256 "da6b57c3d0553c2e829233affcafebdba31748aaf4b8d5e2006f1ba4b8e0df36"
   :BYTES 45)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/006-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/006-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/006-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/006-get.stdout"
   :SHA256 "169ac83965eb6e05b2e7b1c6d42e09e293aa72a2645d243659fd88598e2674a7"
   :BYTES 62)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/007-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/007-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/007-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/007-put.stdout"
   :SHA256 "5b0e60bd7550b24b5fac90c58d021752c05196911ec86b9d269b2a6fa7ec629b"
   :BYTES 45)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/008-delete.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/008-delete.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/008-delete.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/008-delete.stdout"
   :SHA256 "08aa74021b94d0d43c59c8f138eb27e1eff875bb131f577840c8605c1b715ee6"
   :BYTES 48)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/009-ping.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/009-ping.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/009-ping.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/009-ping.stdout"
   :SHA256 "3460f415a8d2fce8d3844e17ceea1ce0834d44a958264b19cfd6bd823c5282e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/010-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/010-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/010-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/010-get.stdout"
   :SHA256 "d23c9678e8e212a91fd7654773db2ae6bedee23e43bf2b8f75df7fab3a3d1cb5"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/011-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/011-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/011-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/011-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/012-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/012-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/012-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/012-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/013-v1-server-2.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/013-v1-server-2.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/013-v1-server-2.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/013-v1-server-2.stdout"
   :SHA256 "4b68f53e5d2e996963d577430acf52df3ce1e2cb7654724dceb3fca0ea974bbc"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/014-ping.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/014-ping.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/014-ping.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/014-ping.stdout"
   :SHA256 "3460f415a8d2fce8d3844e17ceea1ce0834d44a958264b19cfd6bd823c5282e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/015-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/015-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/015-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/015-get.stdout"
   :SHA256 "d23c9678e8e212a91fd7654773db2ae6bedee23e43bf2b8f75df7fab3a3d1cb5"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/016-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/016-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/016-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/016-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/017-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/017-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/017-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/017-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/018-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/018-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/018-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/018-put.stdout"
   :SHA256 "0d09bd2341c3e0f02c5ab21e30b660b3b3d603f1a64b4f7d588706b0f5e49a0f"
   :BYTES 45)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/019-delete.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/019-delete.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/019-delete.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/019-delete.stdout"
   :SHA256 "c7400c7682baf156f04efbedaf85a845b6f2cd82498c809c469e184667b3c671"
   :BYTES 48)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/020-ping.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/020-ping.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/020-ping.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/020-ping.stdout"
   :SHA256 "3460f415a8d2fce8d3844e17ceea1ce0834d44a958264b19cfd6bd823c5282e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/021-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/021-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/021-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/021-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/022-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/022-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/022-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/022-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/023-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/023-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/023-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/023-get.stdout"
   :SHA256 "126c51985cc9cac45e3942b061ab424ba3c5fe83b57c6813c8a0943df7f29d7e"
   :BYTES 68)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/024-v1-server-3.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/024-v1-server-3.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/024-v1-server-3.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/024-v1-server-3.stdout"
   :SHA256 "b8276da7d68107ed69e55ec954e8b501d636848c9bf45570c9ef8f90727b8450"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/025-ping.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/025-ping.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/025-ping.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/025-ping.stdout"
   :SHA256 "3460f415a8d2fce8d3844e17ceea1ce0834d44a958264b19cfd6bd823c5282e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/026-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/026-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/026-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/026-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/027-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/027-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/027-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/027-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/028-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/028-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/028-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/028-get.stdout"
   :SHA256 "126c51985cc9cac45e3942b061ab424ba3c5fe83b57c6813c8a0943df7f29d7e"
   :BYTES 68)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/029-ping.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/029-ping.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/029-ping.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/029-ping.stdout"
   :SHA256 "3460f415a8d2fce8d3844e17ceea1ce0834d44a958264b19cfd6bd823c5282e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/030-v1-collision.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/030-v1-collision.stderr"
   :SHA256 "e420ebfedbd85586bbf0d60af6df6cea7f2f1323fd02b5036484bf09534b1070"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/030-v1-collision.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/030-v1-collision.stdout"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/031-v1-engine-not-ready.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/031-v1-engine-not-ready.stderr"
   :SHA256 "4b813dd075a9849106371d323ff4d0b7512f14e2d5d5fe07c9fa66897dc5bdfe"
   :BYTES 77)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/031-v1-engine-not-ready.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/031-v1-engine-not-ready.stdout"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/032-v1-stored-cbor-not-ready.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/032-v1-stored-cbor-not-ready.stderr"
   :SHA256 "779b8aec4171014bd3d92367b58789e53c59ff47eafcbec0a0c56bd80025ce50"
   :BYTES 80)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/032-v1-stored-cbor-not-ready.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/032-v1-stored-cbor-not-ready.stdout"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/033-v1-server-4.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/033-v1-server-4.stderr"
   :SHA256 "e5d61b4903fca8c346d32d1b1c181e37b46e12a1b203aae5a49a4e01554b38a8"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/033-v1-server-4.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/033-v1-server-4.stdout"
   :SHA256 "906cb52169ddcfa206d04c854de32839f8aaf93556a7ff7ad1e0e26734047191"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/034-put-lost-ack.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/034-put-lost-ack.stderr"
   :SHA256 "e7dd60ec74dc5cc161c7ff54806d83aa4cc6ddc7c9a322972e00333b98d4f794"
   :BYTES 67)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/034-put-lost-ack.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/034-put-lost-ack.stdout"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/035-v1-server-5.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/035-v1-server-5.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/035-v1-server-5.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/035-v1-server-5.stdout"
   :SHA256 "e7eb6466d9348d6c4502b399b3aa6559cdd07d0e7ef7fd418fe9278868d013a7"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/036-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/036-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/036-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/036-get.stdout"
   :SHA256 "4d60f496e63d995da633d16612b8d003819cc55788b7f104db1c2af0fcbdf056"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/037-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/037-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/037-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/037-put.stdout"
   :SHA256 "da6b57c3d0553c2e829233affcafebdba31748aaf4b8d5e2006f1ba4b8e0df36"
   :BYTES 45)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/038-v2-server-1.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/038-v2-server-1.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/038-v2-server-1.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/038-v2-server-1.stdout"
   :SHA256 "fb0a64a59c4e72eabff12863bf4443de0d17c253878a30e329efcfe2a65d6e98"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/039-ping.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/039-ping.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/039-ping.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/039-ping.stdout"
   :SHA256 "3460f415a8d2fce8d3844e17ceea1ce0834d44a958264b19cfd6bd823c5282e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/040-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/040-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/040-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/040-put.stdout"
   :SHA256 "77af5054c07fc8a0a2a2de4e179d73b7f75300fa4b29298e88ede615c093dede"
   :BYTES 45)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/041-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/041-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/041-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/041-get.stdout"
   :SHA256 "4d60f496e63d995da633d16612b8d003819cc55788b7f104db1c2af0fcbdf056"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/042-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/042-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/042-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/042-put.stdout"
   :SHA256 "da6b57c3d0553c2e829233affcafebdba31748aaf4b8d5e2006f1ba4b8e0df36"
   :BYTES 45)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/043-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/043-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/043-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/043-get.stdout"
   :SHA256 "169ac83965eb6e05b2e7b1c6d42e09e293aa72a2645d243659fd88598e2674a7"
   :BYTES 62)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/044-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/044-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/044-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/044-put.stdout"
   :SHA256 "5b0e60bd7550b24b5fac90c58d021752c05196911ec86b9d269b2a6fa7ec629b"
   :BYTES 45)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/045-delete.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/045-delete.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/045-delete.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/045-delete.stdout"
   :SHA256 "08aa74021b94d0d43c59c8f138eb27e1eff875bb131f577840c8605c1b715ee6"
   :BYTES 48)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/046-ping.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/046-ping.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/046-ping.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/046-ping.stdout"
   :SHA256 "3460f415a8d2fce8d3844e17ceea1ce0834d44a958264b19cfd6bd823c5282e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/047-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/047-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/047-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/047-get.stdout"
   :SHA256 "d23c9678e8e212a91fd7654773db2ae6bedee23e43bf2b8f75df7fab3a3d1cb5"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/048-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/048-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/048-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/048-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/049-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/049-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/049-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/049-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/050-v2-server-2.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/050-v2-server-2.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/050-v2-server-2.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/050-v2-server-2.stdout"
   :SHA256 "dd14b41bc62c2bbee520519b713d7a9a1eedd1961c074f37c3e0d66ebe24cd60"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/051-ping.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/051-ping.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/051-ping.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/051-ping.stdout"
   :SHA256 "3460f415a8d2fce8d3844e17ceea1ce0834d44a958264b19cfd6bd823c5282e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/052-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/052-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/052-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/052-get.stdout"
   :SHA256 "d23c9678e8e212a91fd7654773db2ae6bedee23e43bf2b8f75df7fab3a3d1cb5"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/053-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/053-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/053-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/053-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/054-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/054-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/054-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/054-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/055-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/055-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/055-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/055-put.stdout"
   :SHA256 "0d09bd2341c3e0f02c5ab21e30b660b3b3d603f1a64b4f7d588706b0f5e49a0f"
   :BYTES 45)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/056-delete.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/056-delete.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/056-delete.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/056-delete.stdout"
   :SHA256 "c7400c7682baf156f04efbedaf85a845b6f2cd82498c809c469e184667b3c671"
   :BYTES 48)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/057-ping.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/057-ping.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/057-ping.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/057-ping.stdout"
   :SHA256 "3460f415a8d2fce8d3844e17ceea1ce0834d44a958264b19cfd6bd823c5282e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/058-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/058-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/058-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/058-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/059-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/059-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/059-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/059-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/060-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/060-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/060-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/060-get.stdout"
   :SHA256 "126c51985cc9cac45e3942b061ab424ba3c5fe83b57c6813c8a0943df7f29d7e"
   :BYTES 68)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/061-v2-server-3.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/061-v2-server-3.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/061-v2-server-3.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/061-v2-server-3.stdout"
   :SHA256 "fd9ff002e70e71181fd7b17f60c170c1fd005bd3c68fa76d21626a430f05bdaa"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/062-ping.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/062-ping.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/062-ping.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/062-ping.stdout"
   :SHA256 "3460f415a8d2fce8d3844e17ceea1ce0834d44a958264b19cfd6bd823c5282e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/063-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/063-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/063-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/063-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/064-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/064-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/064-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/064-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/065-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/065-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/065-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/065-get.stdout"
   :SHA256 "126c51985cc9cac45e3942b061ab424ba3c5fe83b57c6813c8a0943df7f29d7e"
   :BYTES 68)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/066-ping.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/066-ping.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/066-ping.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/066-ping.stdout"
   :SHA256 "3460f415a8d2fce8d3844e17ceea1ce0834d44a958264b19cfd6bd823c5282e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/067-v2-collision.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/067-v2-collision.stderr"
   :SHA256 "e420ebfedbd85586bbf0d60af6df6cea7f2f1323fd02b5036484bf09534b1070"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/067-v2-collision.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/067-v2-collision.stdout"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/068-v2-engine-not-ready.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/068-v2-engine-not-ready.stderr"
   :SHA256 "4b813dd075a9849106371d323ff4d0b7512f14e2d5d5fe07c9fa66897dc5bdfe"
   :BYTES 77)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/068-v2-engine-not-ready.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/068-v2-engine-not-ready.stdout"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/069-v2-stored-cbor-not-ready.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/069-v2-stored-cbor-not-ready.stderr"
   :SHA256 "779b8aec4171014bd3d92367b58789e53c59ff47eafcbec0a0c56bd80025ce50"
   :BYTES 80)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/069-v2-stored-cbor-not-ready.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/069-v2-stored-cbor-not-ready.stdout"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/070-v2-server-4.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/070-v2-server-4.stderr"
   :SHA256 "e5d61b4903fca8c346d32d1b1c181e37b46e12a1b203aae5a49a4e01554b38a8"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/070-v2-server-4.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/070-v2-server-4.stdout"
   :SHA256 "61dbe20b1572e9944d117da85c429544c2e567eac2dc99b3919e8f269e50ee90"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/071-put-lost-ack.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/071-put-lost-ack.stderr"
   :SHA256 "e7dd60ec74dc5cc161c7ff54806d83aa4cc6ddc7c9a322972e00333b98d4f794"
   :BYTES 67)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/071-put-lost-ack.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/071-put-lost-ack.stdout"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/072-v2-server-5.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/072-v2-server-5.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/072-v2-server-5.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/072-v2-server-5.stdout"
   :SHA256 "aa72a12eb633fbdf6435a75bb5f5bfa1b5869d2226b6685429aacbcbe5efa34e"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/073-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/073-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/073-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/073-get.stdout"
   :SHA256 "4d60f496e63d995da633d16612b8d003819cc55788b7f104db1c2af0fcbdf056"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/074-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/074-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/074-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/074-put.stdout"
   :SHA256 "da6b57c3d0553c2e829233affcafebdba31748aaf4b8d5e2006f1ba4b8e0df36"
   :BYTES 45)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/075-v1-server-70.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/075-v1-server-70.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/075-v1-server-70.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/075-v1-server-70.stdout"
   :SHA256 "b5fd8032612a155b4f259cefeb1949f0763e453941f8d2c9189630306d07df84"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/076-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/076-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/076-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/076-get.stdout"
   :SHA256 "4d60f496e63d995da633d16612b8d003819cc55788b7f104db1c2af0fcbdf056"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/077-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/077-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/077-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/077-put.stdout"
   :SHA256 "da6b57c3d0553c2e829233affcafebdba31748aaf4b8d5e2006f1ba4b8e0df36"
   :BYTES 45)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/078-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/078-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/078-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/078-get.stdout"
   :SHA256 "d23c9678e8e212a91fd7654773db2ae6bedee23e43bf2b8f75df7fab3a3d1cb5"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/079-v1-server-71.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/079-v1-server-71.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/079-v1-server-71.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/079-v1-server-71.stdout"
   :SHA256 "8d9dcfc379e496086a3056286cb8729f737bdddb89aebaa5b2a8fd71b3b583a2"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/080-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/080-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/080-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/080-get.stdout"
   :SHA256 "d23c9678e8e212a91fd7654773db2ae6bedee23e43bf2b8f75df7fab3a3d1cb5"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/081-delete.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/081-delete.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/081-delete.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/081-delete.stdout"
   :SHA256 "d99493575720a5140ee43315de6775d7011ccc759557995bcae3afe8e77bcd0a"
   :BYTES 48)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/082-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/082-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/082-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/082-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/083-v2-server-70.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/083-v2-server-70.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/083-v2-server-70.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/083-v2-server-70.stdout"
   :SHA256 "354f7abae6bed5f218c4927ddf5c53fba5043b20cbcac63214133d46c0d8a1ee"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/084-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/084-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/084-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/084-get.stdout"
   :SHA256 "4d60f496e63d995da633d16612b8d003819cc55788b7f104db1c2af0fcbdf056"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/085-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/085-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/085-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/085-put.stdout"
   :SHA256 "da6b57c3d0553c2e829233affcafebdba31748aaf4b8d5e2006f1ba4b8e0df36"
   :BYTES 45)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/086-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/086-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/086-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/086-get.stdout"
   :SHA256 "d23c9678e8e212a91fd7654773db2ae6bedee23e43bf2b8f75df7fab3a3d1cb5"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/087-v2-server-71.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/087-v2-server-71.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/087-v2-server-71.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/087-v2-server-71.stdout"
   :SHA256 "d3d132ac2a23d8323be947141ddd9f2e4ef616b84318ade49ebf5446cd66c673"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/088-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/088-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/088-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/088-get.stdout"
   :SHA256 "d23c9678e8e212a91fd7654773db2ae6bedee23e43bf2b8f75df7fab3a3d1cb5"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/089-delete.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/089-delete.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/089-delete.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/089-delete.stdout"
   :SHA256 "d99493575720a5140ee43315de6775d7011ccc759557995bcae3afe8e77bcd0a"
   :BYTES 48)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/090-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/090-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/090-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/090-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/091-discovery-corrupt-v1.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/091-discovery-corrupt-v1.stderr"
   :SHA256 "3871fcee27316dd0fbd2a6fb31a87d3b088d77ae4ca9e09361bbc4d6cc34cbde"
   :BYTES 69)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/091-discovery-corrupt-v1.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/091-discovery-corrupt-v1.stdout"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/092-v1-server-72.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/092-v1-server-72.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/092-v1-server-72.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/092-v1-server-72.stdout"
   :SHA256 "882d4b0b16a3af3bf176c3657b341e13dcdd4cbb48b3c68b80fe737a1bab7e19"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/093-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/093-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/093-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/093-get.stdout"
   :SHA256 "4d60f496e63d995da633d16612b8d003819cc55788b7f104db1c2af0fcbdf056"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/094-discovery-corrupt-v2.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/094-discovery-corrupt-v2.stderr"
   :SHA256 "3871fcee27316dd0fbd2a6fb31a87d3b088d77ae4ca9e09361bbc4d6cc34cbde"
   :BYTES 69)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/094-discovery-corrupt-v2.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/094-discovery-corrupt-v2.stdout"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/095-v2-server-72.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/095-v2-server-72.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/095-v2-server-72.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/095-v2-server-72.stdout"
   :SHA256 "9d66080daca773ac6745f83c5222e85dfb19d12de7e48f93d1d6c2d8a9a298a1"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/096-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/096-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/096-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/096-get.stdout"
   :SHA256 "4d60f496e63d995da633d16612b8d003819cc55788b7f104db1c2af0fcbdf056"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/097-v1-server-80.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/097-v1-server-80.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/097-v1-server-80.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/097-v1-server-80.stdout"
   :SHA256 "4e2cc384db029200e2cffb9fd54bce44178d5f0df2f8e4ef1eeaed2dd9fa5e3f"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/098-v1-server-81.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/098-v1-server-81.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/098-v1-server-81.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/098-v1-server-81.stdout"
   :SHA256 "7eb35bac41664b23df6d82a8838b9e77864f3d7c9d5c331a59e85a78334af8ca"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/099-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/099-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/099-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/099-put.stdout"
   :SHA256 "e983108f7bdf691b1d4da3337fcc79c3ecd1a72ee959291a92c04c789e4b4fdc"
   :BYTES 48)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/100-delete.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/100-delete.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/100-delete.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/100-delete.stdout"
   :SHA256 "f4dc392ee9082ee1163778a1c05ffe03715b11a3c4e276667b2fa931442663e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/101-v1-server-82.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/101-v1-server-82.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/101-v1-server-82.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/101-v1-server-82.stdout"
   :SHA256 "d2fb035eaedf1c8583a9fe19fcc939d33c7d2e42b640c9175f90ade6a5d843e8"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/102-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/102-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/102-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/102-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/103-v2-server-80.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/103-v2-server-80.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/103-v2-server-80.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/103-v2-server-80.stdout"
   :SHA256 "a65cb6775ee8219ecd28b660da25a347c49f1fd1de86a93248079698fb402a9f"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/104-v2-server-81.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/104-v2-server-81.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/104-v2-server-81.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/104-v2-server-81.stdout"
   :SHA256 "c052f6fa2c9296199209f2a86f98ecfbd2be4088e2a8f8cafcbc8be76126483f"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/105-put.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/105-put.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/105-put.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/105-put.stdout"
   :SHA256 "e983108f7bdf691b1d4da3337fcc79c3ecd1a72ee959291a92c04c789e4b4fdc"
   :BYTES 48)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/106-delete.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/106-delete.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/106-delete.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/106-delete.stdout"
   :SHA256 "f4dc392ee9082ee1163778a1c05ffe03715b11a3c4e276667b2fa931442663e1"
   :BYTES 51)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/107-v2-server-82.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/107-v2-server-82.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/107-v2-server-82.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/107-v2-server-82.stdout"
   :SHA256 "00298de719163eb871e0a8e994ee313e742897cc22eeda2400635597758bcfd5"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/108-get.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/108-get.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/108-get.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/108-get.stdout"
   :SHA256 "5f2f5d584016e97b60e1a66eb0221b9a8a4f1be097aa3f5e00b8004f3bf4e13c"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/109-v1-server-90.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/109-v1-server-90.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/109-v1-server-90.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/109-v1-server-90.stdout"
   :SHA256 "c19fb177571fd7580551e7683eaa5794dda88c0cbbbea63b17d6522e10792ffa"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/110-v1-server-91.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/110-v1-server-91.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/110-v1-server-91.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/110-v1-server-91.stdout"
   :SHA256 "4a47515ccfafccf1feba84e50cc4742b0fbff5d7e921800798a4a3e262488878"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/111-v2-server-90.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/111-v2-server-90.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/111-v2-server-90.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/111-v2-server-90.stdout"
   :SHA256 "c3414dec17591b7a5c479776a0ed5bccec4097da988349f4da8664b1e024419c"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/112-v2-server-91.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/112-v2-server-91.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/112-v2-server-91.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/112-v2-server-91.stdout"
   :SHA256 "690ee678502e958d1bcd57f0d83686289a9fb8ef101d4a7782a561bd7e3640bb"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/113-v1-server-94.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/113-v1-server-94.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/113-v1-server-94.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/113-v1-server-94.stdout"
   :SHA256 "f02c140f4d9f0f183d3162ea4fb14ea5b2e2bcce7e320b3490d3b2e6ad07c066"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/114-v1-server-95.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/114-v1-server-95.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/114-v1-server-95.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/114-v1-server-95.stdout"
   :SHA256 "85516f149859bd9f1a273efc533b65de01572f6d9abaaca905ecf6b10316cba2"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/115-v2-server-94.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/115-v2-server-94.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/115-v2-server-94.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/115-v2-server-94.stdout"
   :SHA256 "2b1b06cde4a486bb9d37c182c0f7ab46c1f358e4019e257fa1b357af36bf3c22"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/116-v2-server-95.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/116-v2-server-95.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/116-v2-server-95.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/116-v2-server-95.stdout"
   :SHA256 "515647220c1e2367b26d8e655d235b2c4ada8556ca06c1a9e656ead383ee7c9d"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/117-v1-server-100.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/117-v1-server-100.stderr"
   :SHA256 "58f4e7511bcff0d61d5f712bffffa9bab4afce20d37f61b6fac67aadfd12fbe1"
   :BYTES 14)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/117-v1-server-100.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/117-v1-server-100.stdout"
   :SHA256 "b4307c0bb75e8a19940d094ba5cca20f46dcd7c17cba97bbb730a7260ca2ec2c"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/118-v1-server-101.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/118-v1-server-101.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/118-v1-server-101.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/118-v1-server-101.stdout"
   :SHA256 "77526b34ce10decc004d7b7f9e43ddba9a1873b834e7ef194dfc0d149eb35db3"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/119-v2-server-100.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/119-v2-server-100.stderr"
   :SHA256 "58f4e7511bcff0d61d5f712bffffa9bab4afce20d37f61b6fac67aadfd12fbe1"
   :BYTES 14)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/119-v2-server-100.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/119-v2-server-100.stdout"
   :SHA256 "1839e598d8112bd2c7b7c526ae75a5d2574b6fa6c48a9a64c07c63573cccb249"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/120-v2-server-101.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/120-v2-server-101.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/120-v2-server-101.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/120-v2-server-101.stdout"
   :SHA256 "6b5a2e99077dd63dabea5076f154cbbe89e3e8c61f130b1c5a70af2bbfa89951"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/121-v1-server-210.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/121-v1-server-210.stderr"
   :SHA256 "58f4e7511bcff0d61d5f712bffffa9bab4afce20d37f61b6fac67aadfd12fbe1"
   :BYTES 14)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/121-v1-server-210.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/121-v1-server-210.stdout"
   :SHA256 "1baf99e566a903efc6bbdcc723bce7b14d8f4aa17480c021dfd3f7a2aa021965"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/122-v1-server-211.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/122-v1-server-211.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/122-v1-server-211.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/122-v1-server-211.stdout"
   :SHA256 "cb424db614a2be42b8d7e74e57d031f8aeac0b2745a7fe63a55f71c7589d51e0"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/123-v2-server-210.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/123-v2-server-210.stderr"
   :SHA256 "58f4e7511bcff0d61d5f712bffffa9bab4afce20d37f61b6fac67aadfd12fbe1"
   :BYTES 14)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/123-v2-server-210.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/123-v2-server-210.stdout"
   :SHA256 "01d033f6f681c04ebfefbd8778869669920fe3b68ba82fda9a5835b9a63b26eb"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/124-v2-server-211.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/124-v2-server-211.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/124-v2-server-211.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/124-v2-server-211.stdout"
   :SHA256 "28a842d915f6ade54f61743d5e9b56819d6ed041ad1d1f24837d754e4d4a3714"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/125-v1-server-220.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/125-v1-server-220.stderr"
   :SHA256 "e5d61b4903fca8c346d32d1b1c181e37b46e12a1b203aae5a49a4e01554b38a8"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/125-v1-server-220.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/125-v1-server-220.stdout"
   :SHA256 "fa2e645d7b0469adff652c50f7701f5bdfd1f8a9ff35c908c1d32717a3f8cd2c"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/126-v1-server-221.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/126-v1-server-221.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/126-v1-server-221.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/126-v1-server-221.stdout"
   :SHA256 "93ae76079e5342fb52e30c447c69b9e2f347f37c64ad5237edb626afc178f83a"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/127-v2-server-220.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/127-v2-server-220.stderr"
   :SHA256 "e5d61b4903fca8c346d32d1b1c181e37b46e12a1b203aae5a49a4e01554b38a8"
   :BYTES 63)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/127-v2-server-220.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/127-v2-server-220.stdout"
   :SHA256 "b69ba9d3434357d0567e2454686a36b40136d9e2480cc839b388d738adc04177"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/128-v2-server-221.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/128-v2-server-221.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/128-v2-server-221.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/128-v2-server-221.stdout"
   :SHA256 "429b0a75789a81be75dfc5ce504a15c19d877f657b6d243a2b3972e3de3e77b2"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/129-v1-server-310.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/129-v1-server-310.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/129-v1-server-310.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/129-v1-server-310.stdout"
   :SHA256 "31f0fd056df8fbd235a901c809663f36b036d00cf545d1e2d06bb4beb06eee4f"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/130-v1-server-311.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/130-v1-server-311.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/130-v1-server-311.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/130-v1-server-311.stdout"
   :SHA256 "d48b202b531a698897540e9a94ab329448b3dc7b47978dfeea333caf801c9d5f"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/131-v2-server-310.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/131-v2-server-310.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/131-v2-server-310.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/131-v2-server-310.stdout"
   :SHA256 "92c37ede503854955481dabc36bbb6ae55782f3c3a1dd21772c85267bc79e4cb"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/132-v2-server-311.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/132-v2-server-311.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/132-v2-server-311.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/132-v2-server-311.stdout"
   :SHA256 "a545784d269a3dcccf7c4205c8133320b34b5cd94f64aa6a5dcc4177bc416ee3"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/133-v1-server-320.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/133-v1-server-320.stderr"
   :SHA256 "217a5285843ac2a438755ea018e524290bf5046502c233bd1ef945233ab659f4"
   :BYTES 28)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/133-v1-server-320.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/133-v1-server-320.stdout"
   :SHA256 "31011ec6276887515a8e321713df1803fc103714a834cc04fadd61eb7b0a6ca2"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/134-v2-server-320.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/134-v2-server-320.stderr"
   :SHA256 "217a5285843ac2a438755ea018e524290bf5046502c233bd1ef945233ab659f4"
   :BYTES 28)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/134-v2-server-320.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/134-v2-server-320.stdout"
   :SHA256 "b25e9472de2889877a9cb03e0054120d41b2884d4d4d30f926e4cc0c1667d79f"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/135-v2-server-330.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/135-v2-server-330.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/135-v2-server-330.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/135-v2-server-330.stdout"
   :SHA256 "ce89703f048551a4691fad0f405a24bd2937680c83678c8f2ce2bb9b4dc18d18"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/136-v1-server-410.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/136-v1-server-410.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/136-v1-server-410.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/136-v1-server-410.stdout"
   :SHA256 "06636fa2d3324fc83dd5266f84dccf304c79f2226405ceb26dba7ee3b5bd78ea"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/137-v1-server-411.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/137-v1-server-411.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/137-v1-server-411.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/137-v1-server-411.stdout"
   :SHA256 "4ecec1d2cd6d19368f3bbc6cb430e8394b27db7ebed7e5897d569463aab7231b"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/138-v2-server-410.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/138-v2-server-410.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/138-v2-server-410.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/138-v2-server-410.stdout"
   :SHA256 "63e2d999c103731156ac956c8eff6a63551b2d797f69721c0007cf2bfe5f44b9"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/139-v2-server-411.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/139-v2-server-411.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/139-v2-server-411.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/139-v2-server-411.stdout"
   :SHA256 "cb826b5d5f725df44d56775c8a740cdac96987e4b0329243be1adad1e6a5e948"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/140-v1-server-420.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/140-v1-server-420.stderr"
   :SHA256 "5c37959120eaa80abe3cd05acc9327201ee8d4cfd93c0d44582e508ad45d33b7"
   :BYTES 29)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/140-v1-server-420.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/140-v1-server-420.stdout"
   :SHA256 "710b298bd3ef86149e15e6de80257f41ab25b7be5a0aecd2071cf4bb7517b515"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/141-v2-server-420.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/141-v2-server-420.stderr"
   :SHA256 "5c37959120eaa80abe3cd05acc9327201ee8d4cfd93c0d44582e508ad45d33b7"
   :BYTES 29)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/141-v2-server-420.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/141-v2-server-420.stdout"
   :SHA256 "cd9b65f985d70cd8068a1c504807e023730ead6427a307cb8e12beee650a850f"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/v1-control-before-fi.bin"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/v1-control-before-fi.bin"
   :SHA256 "04b9dc20402ee2ba96baaf35c9c5e2f1a29b62f2c0933ccc13d61a2bca100066"
   :BYTES 228)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/v2-control-before-fi.bin"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/v2-control-before-fi.bin"
   :SHA256 "63a88ac68f18b53dc19ec930807a3a68d71152eccb583b5d9e420f4fb0c77101"
   :BYTES 228)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-v1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v1/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-v1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v1/0000000000000002.seg"
   :SHA256 "a5e9baa1b949f3a8c7665739dac792a070ec1c8d9a4575e4e887a62cad10bd60"
   :BYTES 404464)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-v1/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v1/0000000000000003.seg"
   :SHA256 "84ce6fa12725807490b00036a2d16c2494d2ac0e5584bb9b14006b40c56344be"
   :BYTES 258)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-v1/0000000000000004.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v1/0000000000000004.seg"
   :SHA256 "76f7d6f39f3c0f3e63bc7f2bc1900ac62c9c082f7ab0654a978b365164679de9"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-v1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v1/control.log"
   :SHA256 "8b4c82f013ae77748def60596f97d77daf4c0843c1017ff1d33141f8386901bd"
   :BYTES 228)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-v1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v1/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-v2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-v2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v2/0000000000000002.seg"
   :SHA256 "a084b17dfa89cbe86069fd71c0edd21fdf0a75133b7b6cc832f27f837710ff22"
   :BYTES 404464)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-v2/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v2/0000000000000003.seg"
   :SHA256 "ad7236ad7e8b93cb0c4f99b172d36a6f17f9ee2ec76c214499e232ff63b70ebd"
   :BYTES 258)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-v2/0000000000000004.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v2/0000000000000004.seg"
   :SHA256 "5ca589f3f1b34119098218a237efcb02c24acbe6d54654d79551f560704d62ad"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-v2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v2/control.log"
   :SHA256 "4ccae5b9271210c12501cdf61b11cb29a37ae9e125c0270d1a71c113eb68a459"
   :BYTES 228)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/auto-v2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/auto-v2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/compaction-v1/0000000000000006.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v1/0000000000000006.seg"
   :SHA256 "7c1a8c4838460be425917c34ab2a543de79bd8ae3cf95d51bd5b1989b8a3430b"
   :BYTES 240224)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/compaction-v1/0000000000000007.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v1/0000000000000007.seg"
   :SHA256 "325d2c075fa7ce9a4dbf290c592aea67293d3d1abdef8330d0f2dc61d93868fa"
   :BYTES 5048128)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/compaction-v1/0000000000000008.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v1/0000000000000008.seg"
   :SHA256 "b2f2a999559af8e2799893519512b947943e02f7b4fbf7ab1e6d9bf96bf6f8fc"
   :BYTES 258)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/compaction-v1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v1/control.log"
   :SHA256 "99f3ff3e19ec51920247e7b54b7047391cfcd37b7e8533044ebbd95136a97704"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/compaction-v1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v1/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/compaction-v2/0000000000000006.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v2/0000000000000006.seg"
   :SHA256 "845dac2039e651d0b55d01ae9a724885e3dc447d1a15b5458915f0a17b946820"
   :BYTES 240224)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/compaction-v2/0000000000000007.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v2/0000000000000007.seg"
   :SHA256 "3dad5c58849fe12d5987a0a018e23ceb063bf962f5c135cc6605c566079edf41"
   :BYTES 5048128)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/compaction-v2/0000000000000008.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v2/0000000000000008.seg"
   :SHA256 "f553ae9db51909b62899b9f89188c0bd41bb0275bc245e2fbde5a61251f60b6a"
   :BYTES 258)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/compaction-v2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v2/control.log"
   :SHA256 "8b9e18c57fcbe18a89f8caef1af505ac7ad31419b3a316fde7a977b065755b4b"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/compaction-v2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/compaction-v2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1-bad-cbor/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1-bad-cbor/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1-bad-cbor/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1-bad-cbor/0000000000000002.seg"
   :SHA256 "1d408d5f42fe2e924f3dafb64670ba328f35188230ed09aee1800bdf10af06a5"
   :BYTES 161)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1-bad-cbor/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1-bad-cbor/control.log"
   :SHA256 "08b485d704c64ac3848144659199ab4057742bbfb4d93f48a8b9f56f6f3b0150"
   :BYTES 188)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1-bad-cbor/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1-bad-cbor/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1-lost-ack/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1-lost-ack/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1-lost-ack/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1-lost-ack/0000000000000002.seg"
   :SHA256 "9b18d7e55d0a7313729f8853794d66a084ea905e7421172b8df3468c8c16c97b"
   :BYTES 162)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1-lost-ack/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1-lost-ack/0000000000000003.seg"
   :SHA256 "2749a69a09587154c52d7b8c14b21101c65f76b1559ff9d16c7516d69c552237"
   :BYTES 161)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1-lost-ack/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1-lost-ack/control.log"
   :SHA256 "3310bf528719bdd17508ba5692aa4675688ecb5fb17543a6df116189c325a248"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1-lost-ack/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1-lost-ack/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1/0000000000000002.seg"
   :SHA256 "b965797ee3f6a3fceab8c15af9359195feb0e08c1bb5e0dd70e63d2098774a90"
   :BYTES 453)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1/0000000000000003.seg"
   :SHA256 "8c5cdd188363a6f7e73d67282793e7301830c9117b566f11eb4669c887c98569"
   :BYTES 260)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1/0000000000000004.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1/0000000000000004.seg"
   :SHA256 "76f7d6f39f3c0f3e63bc7f2bc1900ac62c9c082f7ab0654a978b365164679de9"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1/control.log"
   :SHA256 "222ec91849f1928dad5d012e2b829d2ad7f4813812b0ce2391abb9ade429cb1b"
   :BYTES 228)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v1/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2-bad-cbor/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2-bad-cbor/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2-bad-cbor/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2-bad-cbor/0000000000000002.seg"
   :SHA256 "1bb7ba1a759bb1d8b88500be6c62e95289a24cfe031f00bbcc1171a0502daf53"
   :BYTES 161)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2-bad-cbor/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2-bad-cbor/control.log"
   :SHA256 "3d7935a7e53cf252c93104ccd83add69ddb63f44643d8da3e3a18855ef6722fc"
   :BYTES 188)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2-bad-cbor/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2-bad-cbor/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2-lost-ack/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2-lost-ack/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2-lost-ack/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2-lost-ack/0000000000000002.seg"
   :SHA256 "2df52d6e541545b175c879dd1130a9746a72274549adc0e04775df0aca482e30"
   :BYTES 162)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2-lost-ack/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2-lost-ack/0000000000000003.seg"
   :SHA256 "41b88164395295a3de7a61e5cb62fa6796410c7ce852d85d63e18ed66d0c538d"
   :BYTES 161)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2-lost-ack/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2-lost-ack/control.log"
   :SHA256 "a0118cdbbf2856263c01032fc307e374553f5b48670b1bdf3d48dc5191621eb8"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2-lost-ack/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2-lost-ack/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2/0000000000000002.seg"
   :SHA256 "07d2b2e049c35657c0d72025cb532ac4264d6acec9a54a45c734ed46d011a8e7"
   :BYTES 453)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2/0000000000000003.seg"
   :SHA256 "cec40d8bdd186a2352f1d2c088945cf5b6a33a52889cdd38d31d6cbb38240e2d"
   :BYTES 260)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2/0000000000000004.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2/0000000000000004.seg"
   :SHA256 "5ca589f3f1b34119098218a237efcb02c24acbe6d54654d79551f560704d62ad"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2/control.log"
   :SHA256 "41b5fbcd223bc1ed9ca26056b0517580a8b282ad31286f7cc1535385723d9d2d"
   :BYTES 228)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/data-v2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/data-v2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v1/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v1/0000000000000002.seg"
   :SHA256 "9b18d7e55d0a7313729f8853794d66a084ea905e7421172b8df3468c8c16c97b"
   :BYTES 162)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v1/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v1/0000000000000003.seg"
   :SHA256 "e651cd72eca0d652e83fd089c6ee68f9e0aeb14a566581fe200aa7f44094a4cb"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v1/0000000000000004.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v1/0000000000000004.seg"
   :SHA256 "76f7d6f39f3c0f3e63bc7f2bc1900ac62c9c082f7ab0654a978b365164679de9"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v1/control.log"
   :SHA256 "2ec0103e0abf7d4dac76b5088f870c4da11486c3e68dd99d4bc558325bcfd6e1"
   :BYTES 228)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v1/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v1/primary-0000000000000001.idx.tmp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v1/primary-0000000000000001.idx.tmp"
   :SHA256 "06ebc7a57d40549f0f590755d67bae9070f3c44b7743342fa4786c78f82836a7"
   :BYTES 12288)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v2/0000000000000002.seg"
   :SHA256 "2df52d6e541545b175c879dd1130a9746a72274549adc0e04775df0aca482e30"
   :BYTES 162)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v2/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v2/0000000000000003.seg"
   :SHA256 "286a69b286476a8b2ae98d8a478f9f9f3a62f469e978d7ac4f8af895ed8f9149"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v2/0000000000000004.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v2/0000000000000004.seg"
   :SHA256 "5ca589f3f1b34119098218a237efcb02c24acbe6d54654d79551f560704d62ad"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v2/control.log"
   :SHA256 "ba73eea032db4ad2877f62b0f3caba65291eb023bb00ee6bc04b2e47f8ed96ab"
   :BYTES 228)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-corrupt-v2/primary-0000000000000001.idx.tmp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-corrupt-v2/primary-0000000000000001.idx.tmp"
   :SHA256 "b4325b670b51749a6ed43db7e8a039e1d2ed649fea2bdd600ade53883a3116d5"
   :BYTES 12288)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v1/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v1/0000000000000002.seg"
   :SHA256 "9b18d7e55d0a7313729f8853794d66a084ea905e7421172b8df3468c8c16c97b"
   :BYTES 162)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v1/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v1/0000000000000003.seg"
   :SHA256 "e651cd72eca0d652e83fd089c6ee68f9e0aeb14a566581fe200aa7f44094a4cb"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v1/0000000000000004.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v1/0000000000000004.seg"
   :SHA256 "f5b33ad006681f1656ceeb830e787b1cff3498e6997237661c1d83517f110644"
   :BYTES 162)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v1/0000000000000005.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v1/0000000000000005.seg"
   :SHA256 "2f9f79db390fde6e9e844735fdd9241bd5d33a877d32df64dd4e5168ca5d1371"
   :BYTES 160)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v1/control.log"
   :SHA256 "ab0a70ff2538f55b947cc90d852418d08f7ed49a19686565e9caff2324047823"
   :BYTES 248)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v1/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v1/primary-0000000000000001.idx.tmp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v1/primary-0000000000000001.idx.tmp"
   :SHA256 "10992888c8a22c9877a5a8d62ba530c962a857e955493990ab36617f42d0a6f3"
   :BYTES 12288)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v2/0000000000000002.seg"
   :SHA256 "2df52d6e541545b175c879dd1130a9746a72274549adc0e04775df0aca482e30"
   :BYTES 162)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v2/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v2/0000000000000003.seg"
   :SHA256 "286a69b286476a8b2ae98d8a478f9f9f3a62f469e978d7ac4f8af895ed8f9149"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v2/0000000000000004.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v2/0000000000000004.seg"
   :SHA256 "f64d6fe997a50f21f7d6309d061ba5311cfdbe604b2398b9328d7e8821a88668"
   :BYTES 162)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v2/0000000000000005.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v2/0000000000000005.seg"
   :SHA256 "35709d7a3cf9e002f8a85318c1e705e4a6c2e3c0d47b30444c5deff1efa6ae77"
   :BYTES 160)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v2/control.log"
   :SHA256 "a75cb4b1547f675d3928e033e7ee1694cfb5876dea7819e1637a8476a0cc69ce"
   :BYTES 248)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/discovery-v2/primary-0000000000000001.idx.tmp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/discovery-v2/primary-0000000000000001.idx.tmp"
   :SHA256 "732b00003e1dcbc3c8e5d5861e5e45d0ba42d9c74e3bf6323dcb1b5797c1ea4b"
   :BYTES 12288)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-loss-v1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-loss-v1/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-loss-v1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-loss-v1/0000000000000002.seg"
   :SHA256 "4278f5b688e3491ad71617a9fb27f2b326ce4082a3b0f9ffc7ef036539d0dc84"
   :BYTES 2760)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-loss-v1/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-loss-v1/0000000000000003.seg"
   :SHA256 "916489364ed68a1cab58e1f29a3be8522e5395491eff0c57cc07fe39f5bd970c"
   :BYTES 399)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-loss-v1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-loss-v1/control.log"
   :SHA256 "da7d14b58679b974abeff5ded1e722c0c1fa04337e5de9d170a30c7185a85906"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-loss-v1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-loss-v1/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-loss-v2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-loss-v2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-loss-v2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-loss-v2/0000000000000002.seg"
   :SHA256 "520b8470393fcef3a8b8be9f5b52cc8c5f540263dcf7698d7193140e9300f241"
   :BYTES 2760)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-loss-v2/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-loss-v2/0000000000000003.seg"
   :SHA256 "27626fa4d2c08510db11c695e2b28a7bf48c5f510ab4260290b6dee241e9e96e"
   :BYTES 399)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-loss-v2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-loss-v2/control.log"
   :SHA256 "a0119732ca2fbb9a3e9ae4f79bdce1db6e79d5ddea013239e854cba099c90365"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-loss-v2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-loss-v2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-v1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-v1/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-v1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-v1/0000000000000002.seg"
   :SHA256 "4278f5b688e3491ad71617a9fb27f2b326ce4082a3b0f9ffc7ef036539d0dc84"
   :BYTES 2760)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-v1/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-v1/0000000000000003.seg"
   :SHA256 "916489364ed68a1cab58e1f29a3be8522e5395491eff0c57cc07fe39f5bd970c"
   :BYTES 399)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-v1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-v1/control.log"
   :SHA256 "da7d14b58679b974abeff5ded1e722c0c1fa04337e5de9d170a30c7185a85906"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-v1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-v1/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-v2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-v2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-v2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-v2/0000000000000002.seg"
   :SHA256 "520b8470393fcef3a8b8be9f5b52cc8c5f540263dcf7698d7193140e9300f241"
   :BYTES 2760)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-v2/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-v2/0000000000000003.seg"
   :SHA256 "27626fa4d2c08510db11c695e2b28a7bf48c5f510ab4260290b6dee241e9e96e"
   :BYTES 399)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-v2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-v2/control.log"
   :SHA256 "a0119732ca2fbb9a3e9ae4f79bdce1db6e79d5ddea013239e854cba099c90365"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/explicit-v2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/explicit-v2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/group-v1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/group-v1/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/group-v1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/group-v1/0000000000000002.seg"
   :SHA256 "4278f5b688e3491ad71617a9fb27f2b326ce4082a3b0f9ffc7ef036539d0dc84"
   :BYTES 2760)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/group-v1/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/group-v1/0000000000000003.seg"
   :SHA256 "a1d2209e22173214ac9d018dfdceab18daf4f5d722916a3d661d39c3cf7e6574"
   :BYTES 401)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/group-v1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/group-v1/control.log"
   :SHA256 "da7d14b58679b974abeff5ded1e722c0c1fa04337e5de9d170a30c7185a85906"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/group-v1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/group-v1/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/group-v2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/group-v2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/group-v2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/group-v2/0000000000000002.seg"
   :SHA256 "520b8470393fcef3a8b8be9f5b52cc8c5f540263dcf7698d7193140e9300f241"
   :BYTES 2760)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/group-v2/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/group-v2/0000000000000003.seg"
   :SHA256 "6d7b0ba17a26d62b31efff9bb5b7a850d19f105a0fc5f06dc534a043fda63750"
   :BYTES 401)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/group-v2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/group-v2/control.log"
   :SHA256 "a0119732ca2fbb9a3e9ae4f79bdce1db6e79d5ddea013239e854cba099c90365"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/group-v2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/group-v2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-frame-data/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-frame-data/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-frame-data/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-frame-data/0000000000000002.seg"
   :SHA256 "9f7c94cd9627ad497523c57c9902a1699c626af17236765216998c449c77798e"
   :BYTES 401)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-frame-data/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-frame-data/control.log"
   :SHA256 "3d7935a7e53cf252c93104ccd83add69ddb63f44643d8da3e3a18855ef6722fc"
   :BYTES 188)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-frame-data/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-frame-data/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-group-v1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v1/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-group-v1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v1/0000000000000002.seg"
   :SHA256 "446cfbd5931320e13418a73ebdd7fd14b917e28ed16fed13ac0b01e1004fa60f"
   :BYTES 3095)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-group-v1/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v1/0000000000000003.seg"
   :SHA256 "792e9e012ce74e09e1ec9a891233a6f7808e22267b85736f979b68e2748b4425"
   :BYTES 121070)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-group-v1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v1/control.log"
   :SHA256 "1ab0fa06a00f05047be02f14502268293fa2ac31b2d6a04cfb480dfe397d1455"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-group-v1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v1/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-group-v2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-group-v2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v2/0000000000000002.seg"
   :SHA256 "c4988b775f4cb47f608577a3476474aa5740cb7bf5100149d083a79e74137c7a"
   :BYTES 3095)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-group-v2/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v2/0000000000000003.seg"
   :SHA256 "7b3215edea08ea721c53b318f75b11385bb7bba5c12a6e4361d8f8841dd6030f"
   :BYTES 121070)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-group-v2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v2/control.log"
   :SHA256 "d0bcd4ff2706737329d41aa7c40af245f8b35c1287d59e2d1fb02c797aa93c3d"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-group-v2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-group-v2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-loss-v1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-loss-v1/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-loss-v1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-loss-v1/0000000000000002.seg"
   :SHA256 "5c538b69aabca7636b857fa96dc954696ab69d2cab90ed1461e531d9cdf0c7ba"
   :BYTES 3095)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-loss-v1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-loss-v1/control.log"
   :SHA256 "08b485d704c64ac3848144659199ab4057742bbfb4d93f48a8b9f56f6f3b0150"
   :BYTES 188)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-loss-v1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-loss-v1/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-loss-v2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-loss-v2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-loss-v2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-loss-v2/0000000000000002.seg"
   :SHA256 "83b83cf7427dc8a952dd17bb12f0b2360a87ea06ef024729d2f3642de4779981"
   :BYTES 3095)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-loss-v2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-loss-v2/control.log"
   :SHA256 "3d7935a7e53cf252c93104ccd83add69ddb63f44643d8da3e3a18855ef6722fc"
   :BYTES 188)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/read-loss-v2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/read-loss-v2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-v1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v1/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-v1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v1/0000000000000002.seg"
   :SHA256 "481c0818bcf96deaa63c845760eb94c250f46e878db142d22769b0beedb89104"
   :BYTES 16766848)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-v1/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v1/0000000000000003.seg"
   :SHA256 "b0646d6b02818e85fea4d3be9cf355c78b8a7ddb7cb3772390a14a6a20c9b6e2"
   :BYTES 1262080)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-v1/0000000000000004.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v1/0000000000000004.seg"
   :SHA256 "14ca0fe3926cb6ece321eb7572d30331fab61dca27bc9051f65e6fa23314193f"
   :BYTES 258)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-v1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v1/control.log"
   :SHA256 "c0b7df28513a4aa0c71cfad35f9eab679905bcd508aef040af3f0bea6907eda9"
   :BYTES 228)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-v1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v1/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-v2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-v2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v2/0000000000000002.seg"
   :SHA256 "adea129953b2658e178767019f5045aab9ae67281578e7f405b922b7345ae72b"
   :BYTES 16766848)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-v2/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v2/0000000000000003.seg"
   :SHA256 "41748eb5ed15c058672dbf918096a67c754967b6543d59bb4ba72a5c95b7ab26"
   :BYTES 1262080)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-v2/0000000000000004.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v2/0000000000000004.seg"
   :SHA256 "0dacf7bd3bf995b763e2f534c52a57e2dc259a00953ea16eaacb6bcdff7e1b68"
   :BYTES 258)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-v2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v2/control.log"
   :SHA256 "f3286f96470b2489a6b97d5c45f066b1c43ee4799366d8f3657f0ac9590793b7"
   :BYTES 228)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/rotation-v2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/rotation-v2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/runtime/v1-collision.sock"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/runtime/v1-collision.sock"
   :SHA256 "fa71f35fd518d94194e45be56c205a60c5d64317ac5ba9665e4272ab874f8939"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/runtime/v2-collision.sock"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/runtime/v2-collision.sock"
   :SHA256 "fa71f35fd518d94194e45be56c205a60c5d64317ac5ba9665e4272ab874f8939"
   :BYTES 5)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-loss-v1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-loss-v1/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-loss-v1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-loss-v1/0000000000000002.seg"
   :SHA256 "8e6f6a8605867347339a4d5a051f516a24ad99806dbaed4934968b71a50894ff"
   :BYTES 260)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-loss-v1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-loss-v1/control.log"
   :SHA256 "08b485d704c64ac3848144659199ab4057742bbfb4d93f48a8b9f56f6f3b0150"
   :BYTES 188)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-loss-v1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-loss-v1/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-loss-v2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-loss-v2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-loss-v2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-loss-v2/0000000000000002.seg"
   :SHA256 "2df52d6e541545b175c879dd1130a9746a72274549adc0e04775df0aca482e30"
   :BYTES 162)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-loss-v2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-loss-v2/control.log"
   :SHA256 "3d7935a7e53cf252c93104ccd83add69ddb63f44643d8da3e3a18855ef6722fc"
   :BYTES 188)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-loss-v2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-loss-v2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-v1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-v1/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-v1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-v1/0000000000000002.seg"
   :SHA256 "88dd9b86b283fa8adf6ae38372136fde23b49f4db478a936e81f204abd7eed13"
   :BYTES 453)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-v1/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-v1/0000000000000003.seg"
   :SHA256 "3d85b6f6073a3379a109db68cade6a30b24d16173c45e5015e95f6e259f74730"
   :BYTES 160)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-v1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-v1/control.log"
   :SHA256 "1453d6ac03a0b87e3e1746a66772095d681dbd81c16a53bbef97af5832a75708"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-v1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-v1/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-v2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-v2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-v2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-v2/0000000000000002.seg"
   :SHA256 "827d66d6d3d9d2bdc41cf750bffd48794496146149e69f47a1b3408b818a9ed5"
   :BYTES 453)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-v2/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-v2/0000000000000003.seg"
   :SHA256 "e6c3858679817ef879916f4b05e6018bc983b2e50d9cc31ccb5731acfccca0f6"
   :BYTES 160)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-v2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-v2/control.log"
   :SHA256 "f0dc2225245c697522e6765edf2019aadd1a45dce1c317f749aafa507f2191ae"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70CUV-AG3-0/version-v2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70CUV-AG3-0/version-v2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64))
 :LIMITS (:NEGATIVE-NESTED-SELF-TEST-FIXTURES-EXCLUDED))
