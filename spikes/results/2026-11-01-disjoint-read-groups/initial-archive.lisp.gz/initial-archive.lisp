(:KIND :DISJOINT-COMMAND-ARCHIVE :STATUS :PASSED :COMMANDS
 ((:NAME "disjoint-allocation" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-analysis-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-archive-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-baseline" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-baseline-analysis" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-baseline-calibration" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "disjoint-baseline-calibration-analysis" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-candidate" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-candidate-analysis" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-candidate-calibration" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "disjoint-candidate-calibration-analysis" :STATUS :OK
   :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-candidate-repeat" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-candidate-repeat-analysis" :STATUS :OK :SOURCE-CONSISTENCY
   :STABLE)
  (:NAME "disjoint-cleanup-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-close-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-docs-setup" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-documentation" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-focused-01" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-focused-02" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-focused-03" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-focused-04" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-focused-05" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-identity-self-test" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-process-01" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-process-02" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-read-analysis" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-read-control" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-smoke-01" :STATUS :FAILED :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-smoke-02" :STATUS :OK :SOURCE-CONSISTENCY :STABLE)
  (:NAME "disjoint-statistics" :STATUS :OK :SOURCE-CONSISTENCY :STABLE))
 :FAILED-FIXTURE-ROOTS
 ("/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/"
  "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/")
 :SPECIAL-NODES
 ((:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/disjoint-runtime/v1-810.sock"
   :KIND :ORPHAN-SOCKET :MODE 49536 :UID 501 :DEVICE 16777232 :INODE 1569781374
   :LIMITS :IPC-NODE-HAS-NO-REPLAYABLE-FILE-BYTES))
 :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-allocation/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-allocation/conservazione.lisp"
   :SHA256 "9cb94f11ef95c6c5760b0181c1b7a3db7f235868f8b116de6f7e8ea5bb2e5556"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-allocation/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-allocation/report.lisp"
   :SHA256 "ce6eb7dab7c4a0eb44cc38d69e093343eb219e596ac7695d0a4943d40f43fe34"
   :BYTES 362099)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-analysis-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-analysis-self-test/conservazione.lisp"
   :SHA256 "0b61c8a2bc78c198894211ecb96249af38801364700084ca6ce253f62ddd793a"
   :BYTES 1186)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-analysis-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-analysis-self-test/report.lisp"
   :SHA256 "59cf23608c8d2ad07921dd088550fec0756bbcbe796f0e516d77ea7e9d95729f"
   :BYTES 360791)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-archive-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-archive-self-test/conservazione.lisp"
   :SHA256 "5835fcac67460beff39ec2e72ed9011b1639a54848e3393367baa69435ae9a0c"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-archive-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-archive-self-test/report.lisp"
   :SHA256 "ee7eb69e5add13221781b47de1d96efd27ae5a8a9c5b8f1c45b0cfa29ab50cfa"
   :BYTES 362026)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-analysis/conservazione.lisp"
   :SHA256 "2e74ccf22849e27d1da8bb5353e04884d14e9d4ae7e7a7759ff3c95e33961114"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-analysis/report.lisp"
   :SHA256 "33347eae424931a8220cab128c0a84199cce6c75d96fb9d13354cb1dac4bd73d"
   :BYTES 361902)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline-calibration-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-calibration-analysis/conservazione.lisp"
   :SHA256 "85584e44477e640e410da5f278ff719bb91439d701cfb684f9ca5fb58940e073"
   :BYTES 1208)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline-calibration-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-calibration-analysis/report.lisp"
   :SHA256 "ec71b75e73308403cc2729d453356b7351e2119d9174f9afe644914b74732779"
   :BYTES 361181)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline-calibration/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-calibration/conservazione.lisp"
   :SHA256 "5123c3e3dc6a72a3e53291f688d7e07d306ea2393ea5a9b360c06c29240c0974"
   :BYTES 1190)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline-calibration/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline-calibration/report.lisp"
   :SHA256 "dad6367bbbf2b9569116afd3a195ae020cb363249a8062f00aeb43bb52d4ccf4"
   :BYTES 365867)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline/conservazione.lisp"
   :SHA256 "2e35b3f75103edd0c2c9f06117360be097ca69fe5b6454431d8bf5207d220235"
   :BYTES 1166)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-baseline/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-baseline/report.lisp"
   :SHA256 "3ff923a06aa75b7e382cf2e241da8ec7f433c29cdd1f1af9d2b7f77c95af5998"
   :BYTES 375313)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-analysis/conservazione.lisp"
   :SHA256 "979d603c20a6fc95b2f6e58e176c3dac50a090fb1ca8ed9bea203a5cb5f0300d"
   :BYTES 1186)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-analysis/report.lisp"
   :SHA256 "de7ead0dfaf469876b7b2dc86f7f30ea290fc400fb6692537459c026400cca98"
   :BYTES 362619)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-calibration-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-calibration-analysis/conservazione.lisp"
   :SHA256 "42d196de71de93c90daa126c02f7c5be4138849d5e4c25d6d2b1981ede02b8ad"
   :BYTES 1210)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-calibration-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-calibration-analysis/report.lisp"
   :SHA256 "241475a485bbca2de09f4790c85fa2b93143a4cea297b4ba57b85bb2af201af8"
   :BYTES 362302)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-calibration/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-calibration/conservazione.lisp"
   :SHA256 "34e551d4a4073ffc907bd55f8be0aa223c017b05bf3173177b2c333fd5c5c15c"
   :BYTES 1192)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-calibration/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-calibration/report.lisp"
   :SHA256 "65d586a91b7dd61c3b86f4e8a92cc6cc00244d202b80e53257ebf8330c265eaf"
   :BYTES 366991)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-repeat-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-repeat-analysis/conservazione.lisp"
   :SHA256 "381deb5161588d4508db2d8747ce03586a58f077ca607e83dca570a8e653829f"
   :BYTES 1200)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-repeat-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-repeat-analysis/report.lisp"
   :SHA256 "447ce451eaf1afc24f86c74bff6e31b38b3993dddc0720d0f9f84f6351ba4ec3"
   :BYTES 362730)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-repeat/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-repeat/conservazione.lisp"
   :SHA256 "ebbd10a22fa0c04500d92f6409d711e088a169d24c2a9910e1686e4115eef0b1"
   :BYTES 1182)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate-repeat/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate-repeat/report.lisp"
   :SHA256 "196ab3d0f5d81059cc5004cdadc233ac200e4f6b6c362c0658a217578495e36b"
   :BYTES 376443)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate/conservazione.lisp"
   :SHA256 "499840b15b5707e064e3580c9087b3f129006b57ef13ec6b561f02ab1e759530"
   :BYTES 1168)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-candidate/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-candidate/report.lisp"
   :SHA256 "4a2b71ca8ec5e6392cd36b5914a82fc3cb2774dabeb1c77a9559270a1482abd6"
   :BYTES 376437)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-cleanup-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-cleanup-self-test/conservazione.lisp"
   :SHA256 "597b247c138cdf0eabb7215e4247e210eb8e83e3e6919e5452e09fde9e5305e9"
   :BYTES 1184)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-cleanup-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-cleanup-self-test/report.lisp"
   :SHA256 "85842bcc48a7582f3c4d18c8448f3566ee573a5458874f5f9457c870fe7da6c7"
   :BYTES 362057)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-close-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-close-self-test/conservazione.lisp"
   :SHA256 "7da8d09dce1f993b6bf3bfcd06226492b89b023df71377652aea496711cee982"
   :BYTES 1180)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-close-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-close-self-test/report.lisp"
   :SHA256 "7e485a9e45fda21e93c94583081b0953d82b68661f982f1601f5a7e5acf8e74b"
   :BYTES 362012)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-docs-setup/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-docs-setup/conservazione.lisp"
   :SHA256 "104e3316c1dd9bad22b419ca2afc213a261657d24a3194328289ffd1054592df"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-docs-setup/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-docs-setup/report.lisp"
   :SHA256 "c14c9031483f7833ea6c62e255945a97e1b5f0c97772e15bc9bc4b927e383ae3"
   :BYTES 362285)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-documentation/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-documentation/conservazione.lisp"
   :SHA256 "3b721cdbe18c0638abc39041d38962b1ded13bb24337e1622da359e1ce80030a"
   :BYTES 1176)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-documentation/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-documentation/report.lisp"
   :SHA256 "ab76122ead9700c6100ba78dc1a23669a29c0bb326a139ca8e1b7a93a77b7b88"
   :BYTES 367512)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-01/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-01/conservazione.lisp"
   :SHA256 "150ea5f5bbf6abf439d7c2f35c48a9f8b6bd89dcf08545f4cd4c598088cf268d"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-01/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-01/report.lisp"
   :SHA256 "ff474665d6b760b5d5e20c423025d0813f7f98298b9770427da4b43fab5ef753"
   :BYTES 369108)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-02/conservazione.lisp"
   :SHA256 "2238e7d9ab9759b04f1ccc9cf69c86665e909d6a40c5d0689462efc5985ff711"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-02/report.lisp"
   :SHA256 "ddd6631130a33448e4ddf1fe187be143b301b482a832cadb922aa5076f8aeee0"
   :BYTES 369072)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-03/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-03/conservazione.lisp"
   :SHA256 "3973c33b17636830cacb9a8ee2221a5dd18a51046f6c9948e1ba623f90c05bc4"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-03/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-03/report.lisp"
   :SHA256 "f90b61e72d007a11e4c44279b1e390f9fa81d9ca6eb89bf10ce2f56535b7ab97"
   :BYTES 369114)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-04/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-04/conservazione.lisp"
   :SHA256 "b632ef7d94cf124a4ba34cb2f300a4c85edf6b0ce6073022ec9e78c558466697"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-04/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-04/report.lisp"
   :SHA256 "72647ebd31b5943ae4d9ec55c030b0fd5ccfd36e799c6bb150c48f37673b1289"
   :BYTES 369570)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-05/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-05/conservazione.lisp"
   :SHA256 "6ee22026471d50420949180a1cb7fad2d33f88a1759a14f8108bc1292579c4ce"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-focused-05/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-focused-05/report.lisp"
   :SHA256 "ecbe99a316530cae7a0d8d7471b0ba98a597aa3ea0107cd3ebfae04fb3c8ada2"
   :BYTES 361863)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-identity-self-test/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-self-test/conservazione.lisp"
   :SHA256 "4965113bc70f64d10caf576c28622cd08a6ccc84bfb9684b9d00c8cf990a2d52"
   :BYTES 1186)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-identity-self-test/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-identity-self-test/report.lisp"
   :SHA256 "49bc998a13e04202cb3717c85645cb919a335befa9d26b7dd6089e97b55c015b"
   :BYTES 362014)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-process-01/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-process-01/conservazione.lisp"
   :SHA256 "60a6f9a1f1690f8645ab3428eeab406b4ac65450b00cc9d308c9179448805f90"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-process-01/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-process-01/report.lisp"
   :SHA256 "41093caf2916e22807516a5e8baaf8d252897c6048959b59673767934b59f358"
   :BYTES 369317)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-process-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-process-02/conservazione.lisp"
   :SHA256 "8a1e3a85e56fe1e3ed703844628353e066e2a0f33f8b07011115e72bca32d3c0"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-process-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-process-02/report.lisp"
   :SHA256 "f403888bfb2a1200c7d8e6cebdcabd193e7be3392d23e8ddd41b6f58431ce6cd"
   :BYTES 390903)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-read-analysis/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-read-analysis/conservazione.lisp"
   :SHA256 "203eed426fc329e141c350891b53f2e0fbb01d3b198962abdabc3d909b4d105f"
   :BYTES 1176)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-read-analysis/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-read-analysis/report.lisp"
   :SHA256 "d0bbb820ecc55bb5eb25867a2c7d7e6c1d57bcf1682046a7a76f482108e80892"
   :BYTES 362174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-read-control/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-read-control/conservazione.lisp"
   :SHA256 "607310b7017081b0ee9fbd321310c0660c303f7f7e8392af41dc97f6f625b144"
   :BYTES 1174)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-read-control/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-read-control/report.lisp"
   :SHA256 "80111b5c383213a00131225c88fa4dcfe026ab21bf8ae886968f5e0c7f1e12f2"
   :BYTES 366994)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-smoke-01/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-smoke-01/conservazione.lisp"
   :SHA256 "74661dfa31f9ad4252a4fb50fbab57709f354a995a8a7f7ea60b9ef97e686153"
   :BYTES 1166)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-smoke-01/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-smoke-01/report.lisp"
   :SHA256 "7d7294ceba1f192bd820f9d5552cb1df78178b183efe9d08153b791ecffc0d0c"
   :BYTES 380378)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-smoke-02/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-smoke-02/conservazione.lisp"
   :SHA256 "de03518a3654fe8eff730ddb42ac9f45e90924113b3a4fb25d888ff1a078f089"
   :BYTES 1166)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-smoke-02/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-smoke-02/report.lisp"
   :SHA256 "201d8b396b8d078e0e487f71a4599b97fe876bbefbf43df0fae110e867baff04"
   :BYTES 363472)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-statistics/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-statistics/conservazione.lisp"
   :SHA256 "4bfd6e318ceba5430be060b2a841b117d84cc6715bb413f98af297af9828de8b"
   :BYTES 1170)
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/disjoint-statistics/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/commands/disjoint-statistics/report.lisp"
   :SHA256 "8ae1b3cef5560359ce7f20c37ee94e27b6509d37ce3d6c40fc9b6c1f5dd7d481"
   :BYTES 362482)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/001-latency-1.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/001-latency-1.stderr"
   :SHA256 "c45ddcf28ad1e18f09df9a02210b1f9ce4c542fa929692a5e74d13708e4074d1"
   :BYTES 1375)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/001-latency-1.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/001-latency-1.stdout"
   :SHA256 "b5e444ea1015119926ee6d279bc08b75c1b248239644e5872209000b9e4b694d"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/002-latency-2.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/002-latency-2.stderr"
   :SHA256 "16b20df12fbcb2394fd90d9dd0e40781ed6be944233f52e66dcf446477b4cae9"
   :BYTES 1902)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/002-latency-2.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/002-latency-2.stdout"
   :SHA256 "2ccac43831999c8ee8bddf66c02551c742c4f4703af3a26857edc9d917116845"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-1/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-1/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-1/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-1/0000000000000002.seg"
   :SHA256 "b5a9db25f4699308de34a2f17f565303b0ee8b5953d88d90fd038c5294f25d96"
   :BYTES 76168)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-1/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-1/control.log"
   :SHA256 "3d7935a7e53cf252c93104ccd83add69ddb63f44643d8da3e3a18855ef6722fc"
   :BYTES 188)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-1/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-1/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-2/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/0000000000000001.seg"
   :SHA256 "ba5b3512b70135f8b6b93237f8deb5991826c64ab54c40c0bcbee52d4fa529d7"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-2/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/0000000000000002.seg"
   :SHA256 "ca314aa85bd3fab227d05b7a2866864e6f2b289702a7bd0248f209cf7eb165d9"
   :BYTES 130528)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-2/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/0000000000000003.seg"
   :SHA256 "8c000329a73bea09ba14417ea07d2eaa16ea86a857482a5daf417ee0dd645aac"
   :BYTES 130528)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-2/0000000000000004.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/0000000000000004.seg"
   :SHA256 "863218cf143f6e92666670b9a5393969b89a24b1a232e92125958f8b34564a3c"
   :BYTES 43552)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-2/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/control.log"
   :SHA256 "50da8b7f43427f11a3048009ede49b5842ec62fc11507e25029fb6ef7c4bd43b"
   :BYTES 228)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70ABK-7WD-0/data-2/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70ABK-7WD-0/data-2/multiserie.log"
   :SHA256 "58a46d05c6ee7e47f934bd3155d6bbc32d605a4129ae7af874c78b054ebc7fa2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/001-v1-server-810.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/001-v1-server-810.stderr"
   :SHA256 "dba0bfc434fab2a2ef4d0b5b348ec59c58486c949055a5a5642602398348e254"
   :BYTES 18)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/001-v1-server-810.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/001-v1-server-810.stdout"
   :SHA256 "6fc2140b1989e9c429f58e469755722439c79e2cb04c03162a578fde7d01e4b8"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/002-v1-server-811.stderr"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/002-v1-server-811.stderr"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
   :BYTES 0)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/002-v1-server-811.stdout"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/002-v1-server-811.stdout"
   :SHA256 "e5fa5803dad19a540f95227acd3cb5586a0dfd062e28e1a3003bbb6838002e98"
   :BYTES 47)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/0000000000000001.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/0000000000000001.seg"
   :SHA256 "a6d4181b3841731f703df0aed2fa4aedaf809475b21b10f452aef67938c49ef2"
   :BYTES 64)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/0000000000000002.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/0000000000000002.seg"
   :SHA256 "c3b721df62aea43ea8823272fdd1c5079d21b17b14d942693bfd4dc5983542ba"
   :BYTES 736)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/0000000000000003.seg"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/0000000000000003.seg"
   :SHA256 "5a28e66df70af63011d80749d5e81dec7d675abdaf8795cc8223eb7a0fe55133"
   :BYTES 400)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/control.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/control.log"
   :SHA256 "cccd23f9a41bae7486b9ad950c62a42b63c5cef33250df4e5c5d12c6a6cb5b42"
   :BYTES 208)
  (:SOURCE
   "/Users/gpicchiarelli/.arcdocdb-p3-tests/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/multiserie.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-disjoint-read-groups/failed-fixtures/1U70BOW-9O0-0/disjoint-v1-RESIDENT-NONE/multiserie.log"
   :SHA256 "ce476214c95fd3d099e541324c753244c6aa7cc3ff9d2abc9556c7009cbdf789"
   :BYTES 64))
 :LIMITS (:NEGATIVE-NESTED-SELF-TEST-FIXTURES-EXCLUDED))
