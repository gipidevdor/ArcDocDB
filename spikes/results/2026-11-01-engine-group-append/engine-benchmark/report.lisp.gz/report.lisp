(:SOURCE-CONSISTENCY :STABLE :SOURCE-BLOBS-AFTER
 ((:PATH ".gitattributes" :GIT-BLOB "d22cbb201cb1d3384baa7e8422aa9d6ee8aea1f9")
  (:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "4ed9445eb02f439a3c781878622809125ed924e6")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "711b96fd6fb677d15473213023c40c35affb47c0")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "ea5cf67447809b2e413026d50e2f61609cb9e438")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "80da41aac60230141d5d2d0819c9b6c2c3b3ce91")
  (:PATH ".github/ci-toolchain.lock.lisp" :GIT-BLOB
   "c01b06c5b208014ab30bb000dc10acfc9e72cc89")
  (:PATH ".github/workflows/ci-results.yml" :GIT-BLOB
   "d5029660830b7dbef56d6648bbf0a9bbaa400c56")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "49fc8ba897e94dc36c31d973e6e12efeab51b715")
  (:PATH ".github/workflows/docs.yml" :GIT-BLOB
   "6eef2de086d133233892870f80f5771f90ab1676")
  (:PATH ".gitignore" :GIT-BLOB "a3a191b534821cfe86f062a09dbc2cb19ba153bf")
  (:PATH "CHANGELOG.md" :GIT-BLOB "ad9b4ccceca8735e6b078ce90f31af4b7cdb194c")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bc7dba35611947cb7c1e9fb898e294b00f9f2de1")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "20743e1dd5a32d14e0af066e27987eaa16c94964")
  (:PATH "README.md" :GIT-BLOB "9e6430d753813af59152d82a3959a45d70abfa94")
  (:PATH "SECURITY.md" :GIT-BLOB "331a1316c300159882e3a30f9f2c8575a8e586a9")
  (:PATH "THIRD-PARTY-NOTICES.txt" :GIT-BLOB
   "0c5bc85db048fb8970c3cc42fb128337eff77e39")
  (:PATH "arcdocdb.asd" :GIT-BLOB "2daba94b7941b8466700289a45f764ee4f1d1db3")
  (:PATH "assets/README.md" :GIT-BLOB
   "c30d58ba88d9dd9f146df6f03aeedbdea3df5c72")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "a024e50336c5d93b7619048432219020d84eb688")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "0bb1c4dcc1aef96287b5edf18db288467e37f9c1")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "data/unicode/18.0.0/CaseFolding.txt" :GIT-BLOB
   "9ee0a2dd654f6fa520cd932be19ac5c00ffacded")
  (:PATH "data/unicode/18.0.0/DerivedNormalizationProps.txt" :GIT-BLOB
   "32227e8f297e96f98954281d99c38839a7834d7c")
  (:PATH "data/unicode/18.0.0/LICENSE.txt" :GIT-BLOB
   "56da58912807030b451a4700687d5bd02c72d6ed")
  (:PATH "data/unicode/18.0.0/NormalizationTest.txt" :GIT-BLOB
   "730c1a013ac78f6a63118e670c72556d4f112eab")
  (:PATH "data/unicode/18.0.0/README.md" :GIT-BLOB
   "06ab2a1368779a5535c48e90a7e2fb77e44080c9")
  (:PATH "data/unicode/18.0.0/ReadMe.txt" :GIT-BLOB
   "aa18f7175c4a46df644c7c6435ad95a8ad3cd724")
  (:PATH "data/unicode/18.0.0/UnicodeData.txt" :GIT-BLOB
   "ebccf021c4fcf31c2ecbb9bd7da3f5eb7ed44851")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakProperty.txt" :GIT-BLOB
   "313ae91aad579445a1e06556a1d7a2edd0c782a2")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakTest.txt" :GIT-BLOB
   "8d734a2690b9f06018e02b0b4f165acc4d0d2853")
  (:PATH "data/unicode/18.0.0/emoji/emoji-data.txt" :GIT-BLOB
   "7a383f0dcfd6ad65a2b7b5e90f701e38485f151f")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "a677288d5fd65a8de671c8cb513fef7c9cb013d5")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "0f68efcd275602bc60b1ee3a2a104f8a49bc6b80")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "1445703c53c2f1b82ced7dd78f34ad4ab8aae7d1")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "3c1c28fb8949660be6391180be187f55d14d5bb6")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "4c0ad12a7532b5d518b0581301f28a3601228d94")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "fce97d7d8c70a6c8f5425cd47ade5a2db5892a11")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "d3973b8d3cca6c9df25ab1c2e76c305bdc28c51b")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "85c9f51f242e4e5c3239edb58eea0a3ae0013011")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "5e10ff0c486bc5e08163bcd5df5bd5736de102f0")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "8720f145cca1d03da5446c5398ad4417a6243a18")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "30462b46bdd4dffdc7a8217adb6ec89571bf8b89")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "c05d0f0f5f69c9ddd9a85769c4bb11cc5a921c75")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "4ccdd9d66495ccff8d47d70ab80b04fa3bc601ca")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "b6a6a520f82271f96513a10457ad400c3f86f2bd")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "b75830dd78d106f8db76e65c08d4e8f3b2a488e4")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "d102ba1c248c77c71c437e46675cd5fc913fcdc5")
  (:PATH "docs/README.md" :GIT-BLOB "db925522d2e683e87137b5f3bca8d234cfe435bc")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "641a7c9e540ff2ec1136bcaa53c6558691578577")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "85d24f91157ac79e6af8c3ac908ca03921913922")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "9baef4c50046aca7c2d9740896af96a9dc5974f3")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "c949015de0fa3a2c25e597b523cb9a00409549b7")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "dd5d59a612a804976a08a475b0cce0de5daba1e3")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "49c294e438f29b383bc825210ba12f070f24a7a1")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "b56195d0f7f43e7bdb91a3af0d1a33f161b8d36e")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "26cb290c6bed61bf397cf4f9dbad7ca81d97e8b0")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "289e40fc2198e9295b90cddd5444d061cccdacfc")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "570458150a9f118174d72cbf90b0b13400237997")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "86c3d28f5a8ecdcf0dbbff34e5eeddf69bea5c48")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "3a490fbb3a23a5de59e08a86b5d656e559ec3696")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "c6b0803782b4595bce94f73f37bfb3de06ef58e3")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "811067eb4311ef4ed3c3b5450325345c04d444e4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "c863c2471e2f6e2b6bb0cb79f9c303dda902f572")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "5117c423e298e8aee4e02b2daea95cdfa6747784")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "813ecfb7741a73bbe4065c0914eab22495bbca3e")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "c5fc54a10372cec9bbf1fd3cbb436a6e835cd079")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "08a71d783f74d8dc0c02db312902f4256668d49d")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "085506a53a59d44f70b63f9f550df428a1f7c564")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "6399188b2711a8860f5895fb92dfabb34fa2dafa")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "13e62eb82f21f3b5490511d47823439541edba33")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "7785da60ce293bc328817518fbf2be3f9ab9a7b8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "57f594b6143b04e40bc3fea9394ebe938ca799ee")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "6b41728bd67274b11b1fde42cfb6ac2b71b0340b")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "0ec3e4cb8daeb741d6be9428099f1da284b0f895")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "50cded21f18bd019fc190b08edb348945d05829f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "e0e408989c0d8b1a8594a31a9f4cda888232b8c7")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "51ecdb8e1af48f87cd2e53d8c3c334b4a4dd7062")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "8589ad553a5b18f96e5dbab682a024f90b671c2e")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "138cf9abbe606df8f544a669069ed94844c9960f")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "c6ee53cf623ad6294ab2ab7e46ee16a3304dfdda")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "0af09ca66b38c35361d30ddbd028a0cb7fcac4e8")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "98cad23c9c529f3f83ccf02dc9bd1a4cb1e6f318")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "2d7ba68f4a56fa80700825d44f2b4335b4d342f4")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "5150eca7a1e85c342e20519179c0560e19c816c4")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "3aa06135165157067c6eaf64d8317a43d32086f6")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "b352146cf5138b099155a819a2c0c19780a31af7")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "05cc183bb8bd0b7b468a7225065c4dc75dd6cd33")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "452553489ad4b466a118e5ec3f08a79223ba7f69")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "7323f9c4e7d6a41ee0e8edbc7c21f6c40fae7258")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c12ccb4a82f5e97c40c2e2df05f085c28f9356af")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "c5ccb103deb265db77ca14be9e4fb60ebb7395f3")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "d0ce5bcc0bbfbf2fa92187bbd09d0ff320d54e69")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "a52656154964c4588477288a15fb10284ac888a4")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "d23b7ee9ef2e3e178a663dbfb004ccc8fed2c542")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2c0669b7a0226ff342e15158899a06d75a30abbc")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "5ba95841ff8f467ed496f51101ddd832dca4fab1")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "2787435e8647b4c1702b7fb4f35f40cd64197fa0")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "18cf324a65ccb0d7684d357bbb8eeb6aeed6a11a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "6754d79f26141153b55bbe1bcaa4a82825f95700")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "fd7e70d402194978a3ffdad705318afb0431f04e")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "2c3d966a83d6f5c1ba122e38ee510b5277a1e89e")
  (:PATH "docs/adr/0053-ricerca-full-text-indici-invertiti.md" :GIT-BLOB
   "ed37b13d26276ccec88bc4eb7e9259bc8ea270a0")
  (:PATH "docs/adr/0054-contratto-e-formato-full-text.md" :GIT-BLOB
   "239a1b5bbb0be77e0a60cb3f0360d8f4906d0b46")
  (:PATH "docs/adr/0055-interfaccia-locale-unix-socket.md" :GIT-BLOB
   "3a1a8acc98918b9eff3f9c319da1d089bd55bf1b")
  (:PATH "docs/adr/0056-sessione-locale-m16.md" :GIT-BLOB
   "09aa317be40281eb6dfeedfb16c27bf4ee227782")
  (:PATH "docs/adr/0057-selezione-automatica-indice.md" :GIT-BLOB
   "dd056fe207e34cc13582ef67686f5cef50da0d52")
  (:PATH "docs/adr/0058-pagine-indice-primario.md" :GIT-BLOB
   "aace2fae9377ecc39befa24f30a71fa3544aa82f")
  (:PATH "docs/adr/0059-crc32c-arm64-sbcl.md" :GIT-BLOB
   "8abf118f525ac8e4bfb3657e7b9c2389825e3734")
  (:PATH "docs/adr/0060-crc32c-caricamento-portabile.md" :GIT-BLOB
   "e525cdb37bc853b13c077a139869132a6c8a3296")
  (:PATH "docs/adr/0061-conservazione-esterna-delle-prove.md" :GIT-BLOB
   "f72ff61077518b492f247dde021f8ae8d5749777")
  (:PATH "docs/adr/0062-cronologia-git-due-commit.md" :GIT-BLOB
   "d17a19b8086aeb412bb8622fe8dc5301fd3265d0")
  (:PATH "docs/adr/0063-immagini-sigillate-indice-primario.md" :GIT-BLOB
   "6bf24e2c250857907d5d36e6ea7f2d93cf2dcf63")
  (:PATH "docs/adr/0064-adozione-indice-paginato-m1.md" :GIT-BLOB
   "8b4f945e8e06c194b517c1563c2a78fe1ddbd609")
  (:PATH "docs/adr/0065-costruzione-immagini-dal-motore.md" :GIT-BLOB
   "09314a89fa7875d648062095cfd24081055e34f5")
  (:PATH "docs/adr/0066-attivazione-seriale-immagini-m1.md" :GIT-BLOB
   "ca6fd5d38685053ceb12922973a932f72fce5fd8")
  (:PATH "docs/adr/0067-delta-seriale-indice-m1.md" :GIT-BLOB
   "03ea9916428820920370aaeef7c422b0478d3b4e")
  (:PATH "docs/adr/0068-rinnovo-seriale-immagini-m1.md" :GIT-BLOB
   "2240c84c7e57c86d33df08772b173cc9d0d11aba")
  (:PATH "docs/adr/0069-manutenzione-a-soglie-delta-m1.md" :GIT-BLOB
   "7433e9b73ae1548f198181002505a8aabec65ceb")
  (:PATH "docs/adr/0070-scoperta-readonly-immagini-m1.md" :GIT-BLOB
   "f4a496e4556b220282b4a962a57a723ad2ccbf50")
  (:PATH "docs/adr/0071-delta-location-indice-m1.md" :GIT-BLOB
   "5f06b390d2223e5e5e85f38f5de73cf1ad668f5f")
  (:PATH "docs/adr/0072-rinnovo-automatico-delta-m1.md" :GIT-BLOB
   "99ae69d3d9fa5d6d69f9cb5efede395fe33ae408")
  (:PATH "docs/adr/0073-indice-automatico-operativo-m1.md" :GIT-BLOB
   "8f7677e90411d564c161e07d5f46fe774e32384e")
  (:PATH "docs/adr/0074-crc32c-sbcl-2.6.10.md" :GIT-BLOB
   "0d32b3a9bfe16d3755cc163e1ec2ec09394ca598")
  (:PATH "docs/adr/0075-codex-documentation-toolchain.md" :GIT-BLOB
   "60f2fca9be7d793cffd1f13dc43a80365df700a5")
  (:PATH "docs/adr/0076-rotazione-live-m1.md" :GIT-BLOB
   "1da6f99e64dbce919e88440c8a4662d9abc9ba82")
  (:PATH "docs/adr/0077-source-derived-code-reference.md" :GIT-BLOB
   "100230816ee9e513dfc78ba3c57c992bef61eec5")
  (:PATH "docs/adr/0078-compattazione-prefix-m1.md" :GIT-BLOB
   "89e9e72b6eb4aaf2a0fd494de6a72a33810a52b0")
  (:PATH "docs/adr/0079-cache-record-m1.md" :GIT-BLOB
   "114135347b465d247f7e05b091858c9791f88382")
  (:PATH "docs/adr/0080-group-commit-m1.md" :GIT-BLOB
   "86b89a39cfe8faa863e350dade7d77f9540364fb")
  (:PATH "docs/adr/0081-active-append-metadata.md" :GIT-BLOB
   "19b160c27564b5682637adc98ed39e1b47255f2d")
  (:PATH "docs/adr/0082-bounded-group-append.md" :GIT-BLOB
   "9d0be5661c2df788d2f3c1f2d1f03330011eb78e")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "65c127420a3f961862707dd4632d4fff071b25da")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "da6af58f171fe105407b444a400905f554110ec9")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "09805b5022bf9b338522c4078feae7334825c50a")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "2b878e6c0b9ea5576635f16b1d9e7433c956458f")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "0b92053bbe5abc8b74a59472a0ddaad7be9ba399")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "35ce8a542e4e77ba28c497e4a33358f308708bd0")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "5729dba5379c1eaf1366302e6243fa5219f60cd0")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "2325e50c80180c368d7e13c9181bb6e6fd8ff831")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "5f74a1692a934ddc9425d91ff0cadbf842c95bb2")
  (:PATH "docs/code-reference.md" :GIT-BLOB
   "ce9a8a5a9a8ef8d58833bb239199bbd2e1f6019a")
  (:PATH "docs/editorial-policy.md" :GIT-BLOB
   "23c70f794c8640f050be6eda8d1f75fbeeb13540")
  (:PATH "docs/editorial-review.md" :GIT-BLOB
   "9264d1e4e9b0189d3b3f5a5f3c8cebe5f5d728ec")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "d83cff978b0e2c61bfbf1308e4fdcdbd38fb4ebf")
  (:PATH "docs/formato-indice-full-text.md" :GIT-BLOB
   "be3b1b6661023f58d985a26c07c15216cb099a66")
  (:PATH "docs/full-text.md" :GIT-BLOB
   "29a9ee662cd39c103edaaf046bc8b68731bd8df4")
  (:PATH "docs/github-pages.md" :GIT-BLOB
   "1d624b0c03aa60ee582ce4c98c83b38272c0dc75")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "8c460a969441f5be9d94766fff808f15d6d33f36")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "0c946fd449c68453ea89231234ec67431189414d")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "2c4a6338cd88734319a7420684682d8a0e48fb6d")
  (:PATH "docs/implementazione/active-recovery-metodo.md" :GIT-BLOB
   "5724560732e14d6d374483aa71ca0f7802541df5")
  (:PATH "docs/implementazione/active-recuperato-metodo.md" :GIT-BLOB
   "32524af882ad0a043f6d939994c9a6a11769fef9")
  (:PATH "docs/implementazione/active-recuperato-verifica.md" :GIT-BLOB
   "23af8d8e23577a92d5c0e74884061cb56639d55d")
  (:PATH "docs/implementazione/active-recuperato.md" :GIT-BLOB
   "0b685aa69fd7c078994b5d1feaa4b5b93c1cafc8")
  (:PATH "docs/implementazione/adozione-closed-runtime.md" :GIT-BLOB
   "21630d85433210b2f061c422c931ef0f14ad0b61")
  (:PATH "docs/implementazione/adozione-controller-runtime.md" :GIT-BLOB
   "f2f7826b7eb58b681d334e29834ddd1cf09fed06")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "797a1998753834a3204075954c9cfe81a0f064d4")
  (:PATH "docs/implementazione/archivio-csn-revisione.md" :GIT-BLOB
   "c886079a0ad9f47ae864fbb63084960f897e55fa")
  (:PATH "docs/implementazione/archivio-csn-verifica.md" :GIT-BLOB
   "873f06c415107bac58d781df316e5b484222316a")
  (:PATH "docs/implementazione/associazione-file.md" :GIT-BLOB
   "02e39a32261a5a901ca45e15dcc7505819a969e0")
  (:PATH "docs/implementazione/attivazione-indice-m1.md" :GIT-BLOB
   "cd609a5e9645be680b23798e0bda841d8507d772")
  (:PATH "docs/implementazione/cache-pagine.md" :GIT-BLOB
   "1eaeb517c655d918d307d46423e4aee54f39290b")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "3dbae0d9e595f509621e6bf6dd3380a5ed844f1d")
  (:PATH "docs/implementazione/cbor-array-decisioni.md" :GIT-BLOB
   "948258bd302c1820210e439862d432d8c5554e9e")
  (:PATH "docs/implementazione/cbor-array-lettura.md" :GIT-BLOB
   "c419ecc31f9e905f4d053fd4473c8b605415dc4d")
  (:PATH "docs/implementazione/cbor-array-metodo.md" :GIT-BLOB
   "a5e53c22e391f72573f89c01f58ae28fa1c40376")
  (:PATH "docs/implementazione/cbor-array-revisione.md" :GIT-BLOB
   "f992654650b2fb08a59058b337fef63f901bf75c")
  (:PATH "docs/implementazione/cbor-array-risultati.md" :GIT-BLOB
   "e4c253fcfbe86fd2dfce2bd3354614a67f4b97f5")
  (:PATH "docs/implementazione/cbor-array.md" :GIT-BLOB
   "0f8fa2876a7366cd62bd1b8669251e2107b19b7d")
  (:PATH "docs/implementazione/cbor-float-scrittura-copertura.md" :GIT-BLOB
   "c1f596a69e83504ff3fd2c7cf569f234e1c6554b")
  (:PATH "docs/implementazione/cbor-float-scrittura-dati.md" :GIT-BLOB
   "618a4fdc1d5fbb230414931295ff0f7ef9367c84")
  (:PATH "docs/implementazione/cbor-float-scrittura-decisioni.md" :GIT-BLOB
   "cd76b3d2b02c6c021849b2b85d1a403d76e38f78")
  (:PATH "docs/implementazione/cbor-float-scrittura-lettura.md" :GIT-BLOB
   "11a065b51085a23f42df7ca75e315cbee0328e70")
  (:PATH "docs/implementazione/cbor-float-scrittura-metodo.md" :GIT-BLOB
   "6c046bb92cc291fb00914da89e0eefb705b4ae65")
  (:PATH "docs/implementazione/cbor-float-scrittura-revisione.md" :GIT-BLOB
   "870474964d88a8b4099bf00cc31c0b2bc542f94a")
  (:PATH "docs/implementazione/cbor-float-scrittura-risultati.md" :GIT-BLOB
   "84faa8d4bbf5150c4b9df17879b5dd0b39a286d4")
  (:PATH "docs/implementazione/cbor-float-scrittura.md" :GIT-BLOB
   "c14c7bbaebcd803c24f62adcda19259b16f00e52")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c7fe2a7bad385932a72141de4ae46f04bbd8ce18")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "dd7621ec9feea82adec89e00ed232b22d8aead35")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "4984c8c845da1437c212f47a7a345979df1c5acc")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "ba09a11d806999c55e0cb75f5b638d1fe2cb0476")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "29f9c13299d7b2fbcea64db535c0ec3fd4456f73")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "fb04b79a27ae65e2097c21ace50ee70f26bb0e8a")
  (:PATH "docs/implementazione/cbor-item-decisioni.md" :GIT-BLOB
   "800cefe6cf8f8a8000dad71d3807df7e7efdd210")
  (:PATH "docs/implementazione/cbor-item-lettura.md" :GIT-BLOB
   "57bcf4f8d1c40334c68d53ad2b4a2092e769d8d1")
  (:PATH "docs/implementazione/cbor-item-metodo.md" :GIT-BLOB
   "05b4a0d45c993c6bfebb0555098334f40db82f33")
  (:PATH "docs/implementazione/cbor-item-revisione.md" :GIT-BLOB
   "de0ef7bc19fe539d4aef7cdc1c1f5345b8002a94")
  (:PATH "docs/implementazione/cbor-item-risultati.md" :GIT-BLOB
   "8b02e00a9d43febf09b846d1bf6a01ebee2b3005")
  (:PATH "docs/implementazione/cbor-item.md" :GIT-BLOB
   "8548c091f11308380d4ac4e01ff884644b470281")
  (:PATH "docs/implementazione/cbor-map-decisioni.md" :GIT-BLOB
   "f44e789f6d2bf153580332fb136e46cb9e57194a")
  (:PATH "docs/implementazione/cbor-map-lettura.md" :GIT-BLOB
   "23a1f7f9653522ebf02619977dc2d74ed275f891")
  (:PATH "docs/implementazione/cbor-map-metodo.md" :GIT-BLOB
   "50ad5d1f64b5dbd37f4285306c5430789e0c581e")
  (:PATH "docs/implementazione/cbor-map-revisione.md" :GIT-BLOB
   "4f9c6c7a2e2eed16e73bbb314f5936182d371420")
  (:PATH "docs/implementazione/cbor-map-risultati.md" :GIT-BLOB
   "5322d5cdd93ea61e00830138091c72eadd5effe9")
  (:PATH "docs/implementazione/cbor-map.md" :GIT-BLOB
   "3f4f8e64c19f21958bcc913a1ee701cc55a18f06")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "998d3f4d69a4915bd3d5ac13381d89b15a22afaf")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "1c7b8bc426f5054aa88e7b2cf8ce1d0c339e112b")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "d34c7e0e8b9347228e9c3121358824f106d1e663")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "8beb9758140566348297f59d8a85a1c6816c70ae")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "464af7d4e2264a4c7e0336b2219a0e886cd04c2b")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "a0a4beb749f27b8fdd721492a338ff29acd18420")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "3ac17f24029e9c242146cd994a7b2b907ef8177d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "1a2a1bc130b5e3f343f110bd9ccca2de3486a19b")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "ef1defbeb7d0f2f52a289e03fa52b7922bd8fff2")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "980896a21ef91e13e4c3a4d414d72115eb27fee1")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "a0533ae26074d23c19b098bcf11d7f3959c3b609")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "c3bd5167d49e4e2bc59bff90b6e62e3435ed43b6")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "556fddff139cb8660db889b3b1cb39046972c01f")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "d0bb1a35f08dc97dcb4e03e70e521707c8a8d29c")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "05a927871e8257d31d40c727f88858cc10f3f5b3")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "7b606f5d5c44abd25a7cea635c2e3086f7b08d7a")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "0c3f81227199b06df304e9e3bcbc6c98660bacc8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "54852d32fb4a642db32067148adbf6d9fb22a066")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "ab773c5d9261846c39c09f6cf06566344acd4ff9")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "a3e52d83ef8dab364c1e290a003fbcac3e4703b5")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "943ce8b93716e53b1048dbb672ecb01ecf2ecf2c")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "3bc420d5c29b2005395fdbf72ba1fe12fa0feb20")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "12ed41add43b64cf9a0cf317dab6a09a0f6a8f5e")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "7299368dd4c077d8e620e6a3f6b91dde5cde96c3")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "ee75788591cf776a011eddef4384ce6c9b0c1cf8")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "b5e504a3508da8c72295f9fa7a18ba44a482b547")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e5b9990f00978da272fac6353b4706e9cdb3e80e")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "46f011d10fbd376c7387ffe48a9730a3a2620b05")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "d33e32c7e570f1958c8af75a789ea3a6583e4289")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "032c6c20aa5e116d2c1fa4214a0701e40620b966")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "77e0e458eb0cfbeb0796d176ff54805fcec9fc13")
  (:PATH "docs/implementazione/cbor-stringa-lettura-decisioni.md" :GIT-BLOB
   "a307a12444fd16df6ad92dcdf8717f02e76ac7a8")
  (:PATH "docs/implementazione/cbor-stringa-lettura-metodo.md" :GIT-BLOB
   "3378a194f4eded0fc1316be064956d77b3132fb3")
  (:PATH "docs/implementazione/cbor-stringa-lettura-prima-revisione.md"
   :GIT-BLOB "6fb1e3c3cd8a7512958b54095940826c30980eed")
  (:PATH "docs/implementazione/cbor-stringa-lettura-risultati.md" :GIT-BLOB
   "b50555a7cf2b592b5c36b2d094d7500225581f06")
  (:PATH "docs/implementazione/cbor-stringa-lettura-seconda-revisione.md"
   :GIT-BLOB "ebfc3d0bbdd1a19a295c55770a6d505ddbd4aa84")
  (:PATH "docs/implementazione/cbor-stringa-lettura.md" :GIT-BLOB
   "9eecb30c6b1887b9a0a5f5aabe3516916c3ba025")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "82f1683ba3774d33e82fd23e118790e401c11085")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "ff78a1940b29beef1c4e685e2084767c948f9da0")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "280b19d5e97d5487ba6be4f59da8b015063074bf")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "7ac03f1075bd778be47916ef9eef72e5bcdc90ff")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "08f016eb4a073cf59dbb3c5c9b23791d4a1285ef")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "c17e8ed2fb902df4c971d0300c1c7842dd46a764")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "16b04b9a5451b880ea2449104f65e261ba7f6c7d")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "66c94d76bdb2c46714ea86774489f31580ac63c9")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "d64b31030580f02466562e86efae7cc27451d0a2")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "16ffa1f24020338735660b5b008fb3e00c498ea4")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "39fa55a82334440ea17d53dbefe050d53db6a716")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "5e801a7632e7ce46f56e79cad2073b3e155eae99")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "c77993b00f09e89d21d2ab2eb319964e9e2fa819")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "2221900158acbbd5cdaa39d3301b08501c071e97")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "e29635a7ce3cd150ea0801c4610ddd03af941c8c")
  (:PATH "docs/implementazione/cbor-tag-decisioni.md" :GIT-BLOB
   "f0329ac5196815f633bf7abc82c97730cee832a5")
  (:PATH "docs/implementazione/cbor-tag-lettura.md" :GIT-BLOB
   "49146a982d1297edaf0c31daca7c5eb6150a6ea7")
  (:PATH "docs/implementazione/cbor-tag-metodo.md" :GIT-BLOB
   "ffa487840cb2e0964e7fa7a7cd55d57fbeed3de4")
  (:PATH "docs/implementazione/cbor-tag-revisione.md" :GIT-BLOB
   "b61c84f5f4a70f3009748536709d37c2609d89cd")
  (:PATH "docs/implementazione/cbor-tag-risultati.md" :GIT-BLOB
   "a78c3f04408c306f2cddcc617274f2335b17fc81")
  (:PATH "docs/implementazione/cbor-tag.md" :GIT-BLOB
   "a67789164c1ca9ab5be6435322ae77606314831f")
  (:PATH "docs/implementazione/checkpoint-control.md" :GIT-BLOB
   "2e2d90188ad3b3bec79f9a2c90e9f2cff58f3c42")
  (:PATH "docs/implementazione/checkpoint-recovery.md" :GIT-BLOB
   "fd1444d3e09f58457eb3babe639bc93634e32aa3")
  (:PATH "docs/implementazione/ci-provenienza-pr.md" :GIT-BLOB
   "cfe42a5fe0ebb52b0c1217926a15078d8baf4cea")
  (:PATH "docs/implementazione/ci-statistiche.md" :GIT-BLOB
   "6d6d3ad1d0381ab4bf946a6c1e7561f5266ad494")
  (:PATH "docs/implementazione/ci-wire-processi.md" :GIT-BLOB
   "537159570d4bdc8e7dbcddb5be3dd9e2d57c26eb")
  (:PATH "docs/implementazione/closed-recuperato-revisione.md" :GIT-BLOB
   "38373f1de3d42b5e9056e60d30f215083a80c845")
  (:PATH "docs/implementazione/closed-recuperato-verifica.md" :GIT-BLOB
   "1c4b3e4f0e6c3d3c4519dcdd56c7a2ca8ca2d47d")
  (:PATH "docs/implementazione/closed-recuperato.md" :GIT-BLOB
   "3675c4a21cd14e15f136f1bdcd6e0c64f28564bc")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "07c702f3b926311b7af6950382459286f20c9d05")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "7c9473c0d5149a7cefab4ef33076c7f44bfe9f30")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "2dd9f8ab7dbdc2df6a41874a63aa62f45fa11ba8")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "714da56672b38ed721a71f7d81986f66ca3915e6")
  (:PATH "docs/implementazione/control-recuperato.md" :GIT-BLOB
   "050723cbdec05ccf343e6cf651023dbba053fa60")
  (:PATH "docs/implementazione/control-transizione-metodo.md" :GIT-BLOB
   "4af36a8e4c9c409cccb82beacd9a7243057c2b76")
  (:PATH "docs/implementazione/control-verifica-metodo.md" :GIT-BLOB
   "8ffecd3625f0d1c3b4cf5786e17354cd170a127f")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4e75306fe31c84d552c342f4294894121d647097")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "4c8e017a2fc5e52b4a26d3f90c50d2e89f90e5f1")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "a294f643c70035056ce585a186fe4fb0ad1f01f3")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "6a48c794b8d8619e762c0c33108175d26dab2235")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "e3bc4006b2c53306af00f16d8967e002be5be7f2")
  (:PATH "docs/implementazione/controllore-pool-decisioni.md" :GIT-BLOB
   "e45a4a1609e6ad2c4a8c507a3b6474b34329fc7e")
  (:PATH "docs/implementazione/controllore-pool-metodo.md" :GIT-BLOB
   "9452ebefc6280a045c051c394e3ab55a9b5b7b90")
  (:PATH "docs/implementazione/controllore-pool-revisione-2.md" :GIT-BLOB
   "f4b54f7f20f0dbc620c95098dfe8f7d11e00eb84")
  (:PATH "docs/implementazione/controllore-pool-revisione.md" :GIT-BLOB
   "8331ccdab4e1957b7eaa4ff7404ab2ed263fa924")
  (:PATH "docs/implementazione/controllore-pool-risultati.md" :GIT-BLOB
   "e0738c5de4ceb793d70419ac8fece82e1de2359d")
  (:PATH "docs/implementazione/controllore-pool.md" :GIT-BLOB
   "32a0876c84705abfb03a324d93c0e09997e8caaf")
  (:PATH "docs/implementazione/costruzione-indice-m1.md" :GIT-BLOB
   "954e5c11aac01cdcdbbe1300ab7ad5904a31186f")
  (:PATH "docs/implementazione/costruzione-indice-paginato.md" :GIT-BLOB
   "6f4a25f0f4a8c5c5ef123b587f34313cf18493ae")
  (:PATH "docs/implementazione/crc32c-arm64-metodo.md" :GIT-BLOB
   "fd0a6f8b0203eb527434d5c85b5a21bffaa83842")
  (:PATH "docs/implementazione/crc32c-arm64.md" :GIT-BLOB
   "9d44dfe4836c393debf1e2fedd781ba8d64ac854")
  (:PATH "docs/implementazione/crc32c-piattaforme.md" :GIT-BLOB
   "c48393540f18a1982fa9523d82684488f2d0e9ed")
  (:PATH "docs/implementazione/crc32c-unroll32.md" :GIT-BLOB
   "f9b81bfbbfe41d6f0433df1275b14e0ddb277521")
  (:PATH "docs/implementazione/csn-archivio-recovery.md" :GIT-BLOB
   "0501c6e7d687db9aa0196637ea4ceb5032d398b9")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "f3c71d7a014741290c658cd958ca5d5b6e5076a7")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "6809b9ff79f77032c94c726a67913fd86ed590f4")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "87df34a5915fead7f06bff837dfa0b904f9eb664")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "ac014f8282cf46645dd18f92f16bff17ac1da0b4")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "3d69beb591d794d62111bb695cf87fc6c4726e2c")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "7979e6edd61ac9300d6560b493a61948a4fd0d92")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "62df2e33eb3daa289da2fd2d544db1e367495b76")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "2ab09dc900d919686bd211a1fc0c9e233d6d8bbe")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "26b8a34a0c455ffa1244cd8930718ad68067983d")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "475fcdde02949a8500168f29ab43891d70fe7fa9")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "7e01085ba74008ba3f3715415c7196de10efe61f")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "a2f17134ae38a241a5610af3f00051f0e1c6bca5")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "04724b6857c83e623ba245bef65c657f416bbced")
  (:PATH "docs/implementazione/decisioni-recuperate-revisione.md" :GIT-BLOB
   "e8ec567a22d4a0b7f365d7649622e9a3405e69e4")
  (:PATH "docs/implementazione/decisioni-recuperate-verifica.md" :GIT-BLOB
   "efae51de3ab17894525f9803c2caa2dab2caa737")
  (:PATH "docs/implementazione/decisioni-recuperate.md" :GIT-BLOB
   "877dab2bc85bec554965e906163a950fa7f42dbb")
  (:PATH "docs/implementazione/delta-indice-m1.md" :GIT-BLOB
   "74b4d0337972db90f897380d1acf29cf56b5387d")
  (:PATH "docs/implementazione/delta-location-m1-metodo.md" :GIT-BLOB
   "546cbb2eb9169663e412972c9ffa3dfdd7a44eb7")
  (:PATH "docs/implementazione/delta-location-m1.md" :GIT-BLOB
   "dd39d0fa56ef87edaac933052523fb1092af9891")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "23c6bd3464be1c5de0e85dd1ceef49cb072e2610")
  (:PATH "docs/implementazione/evidenze-parallele.md" :GIT-BLOB
   "c1cf798f1d7aa870e6fc08666fb089bd0078f1b2")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "9ce191f9a921d27dd12773f67b2ea9dc2b724c11")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "5988fea2f0c49b45d4da2152cd2f213f7d4a3bbe")
  (:PATH "docs/implementazione/fonti-recovery-metodo.md" :GIT-BLOB
   "71889d31dc82e1ce9cb80228debcd2aaae265ca3")
  (:PATH "docs/implementazione/fonti-recovery.md" :GIT-BLOB
   "b613cfd01ebf4f093fd8d5b4f6ea14c2c43b1156")
  (:PATH "docs/implementazione/full-text-codec-decisioni.md" :GIT-BLOB
   "d84b4a8ea730f7eb6a08f7578322a9cbab97cc27")
  (:PATH "docs/implementazione/full-text-codec.md" :GIT-BLOB
   "dd648030eb25834fe6d66bf6fb61fad777ef7906")
  (:PATH "docs/implementazione/full-text-decisioni.md" :GIT-BLOB
   "891a19e59ded15ce976428e647431e6087fcda8b")
  (:PATH "docs/implementazione/full-text-documenti-decisioni.md" :GIT-BLOB
   "6df6ad62e11ea8977a258a6e11e774488c131e97")
  (:PATH "docs/implementazione/full-text-documenti.md" :GIT-BLOB
   "813e65fa97477a4d4451c483e137540af95cd667")
  (:PATH "docs/implementazione/full-text-put-metodo.md" :GIT-BLOB
   "2526a07b957970e7abc7f6baae970c2162d9b68e")
  (:PATH "docs/implementazione/full-text-put.md" :GIT-BLOB
   "a480bcb65e37731737a70f16554ca9e5e8cf8ee0")
  (:PATH "docs/implementazione/full-text-riferimenti-metodo.md" :GIT-BLOB
   "0cb603ba80950501cb439b61b4645274188ec75d")
  (:PATH "docs/implementazione/full-text-riferimenti.md" :GIT-BLOB
   "d363ee6d5e8e55f35668fbb129c2cf1f626a6d16")
  (:PATH "docs/implementazione/full-text-righe-metodo.md" :GIT-BLOB
   "2f576876ff695c0b662b91f8deea5b3793c3bc5b")
  (:PATH "docs/implementazione/full-text-righe.md" :GIT-BLOB
   "c6b643c4cf20d6b4378f7bfe7f05132cd4ba1d10")
  (:PATH "docs/implementazione/full-text-riserve-metodo.md" :GIT-BLOB
   "17663cca4a20e28e53be920eaa83792b520354a4")
  (:PATH "docs/implementazione/full-text-riserve.md" :GIT-BLOB
   "154f11b6ffc05e72273d3ab4a0b7a5d3867ad3a7")
  (:PATH "docs/implementazione/full-text.md" :GIT-BLOB
   "10317557bc507e5b786a0564626bc3109e851c46")
  (:PATH "docs/implementazione/get-active-metodo.md" :GIT-BLOB
   "de07ae6a11977904595cd321e2fdfb229cb0bbc0")
  (:PATH "docs/implementazione/get-active-preflight-metodo.md" :GIT-BLOB
   "2557776ad0c8c99e3c479ebfd557b6c912dd503d")
  (:PATH "docs/implementazione/get-active-preflight-verifica.md" :GIT-BLOB
   "2616f8e780fbc697519bc3517591c54197bd37f5")
  (:PATH "docs/implementazione/get-active-verifica.md" :GIT-BLOB
   "f46fdd16bd2ff24d0caa1426706db284b6e9f583")
  (:PATH "docs/implementazione/get-active-vuoto.md" :GIT-BLOB
   "2616e0c8ea4cf50baefe1d17c46277a3c11b1e51")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "b290db7acff4b04c7769062bff44c91f643765cc")
  (:PATH "docs/implementazione/get-costi-metodo.md" :GIT-BLOB
   "fb1926959f835883b7d88a5dda7bdea7f30998b8")
  (:PATH "docs/implementazione/get-costi-risultati.md" :GIT-BLOB
   "655b8a35ae16b285e8c5da3ee0249d47a7629c57")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "56133e69f5a305d3d7ed173361a60d11dc8083a1")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "242e710cf037c17f94ce2c6213210b87e1cd5108")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "017acf3977bd60a59c7cc3c093c084dc5742d8d6")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "d25a0d6bb499867c8e74865f76064205c70a904a")
  (:PATH "docs/implementazione/get-fonti-serie-metodo.md" :GIT-BLOB
   "0b3f2db806973acd21c7b0cb4fe203656db06baf")
  (:PATH "docs/implementazione/get-fonti-serie-revisione.md" :GIT-BLOB
   "91c14197cca8cfa11f46b4f5e2ef5cc03e269507")
  (:PATH "docs/implementazione/get-fonti-serie.md" :GIT-BLOB
   "ef7f5f3ae5748673a74ca960d3c5bb1c6e1dd44d")
  (:PATH "docs/implementazione/get-lifetime.md" :GIT-BLOB
   "3c83a87b6b59b2432c54145ff6d8e5144c7864be")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "953b28082bc52d2925a43c6e78ef19e9cd7710b6")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "adad30953d4d419ccd39475545619fb9e32b1392")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "a85bb276b698a7c20da89fb2fb23e19aef2bf5e0")
  (:PATH "docs/implementazione/get-resolver-metodo.md" :GIT-BLOB
   "fe7942c088ae3aa68d0e15e04c9f46faf05622ac")
  (:PATH "docs/implementazione/get-resolver-verifica.md" :GIT-BLOB
   "67b906cd6e8b8569f97a766b66deebd57f4be501")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "753deeb7ec87fcfdc7c8c1275368fa947827ac37")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "5d14690cdad3e3517bcd32522fd9b26f10475eac")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "4515dcc663abeaa09a60ea4c8b3bd6df1baad2d9")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "9a6c1470083bbd595277d9a9f3b430ff0c5f85d6")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "b8204499bb41f33cea556a86eab9551f8709de40")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "695650c8c40cd1cbe9ad38eed29698b7b71ba97f")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "78a7da074a3daca5f05793f03b88fc4ce45321aa")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "c1a36112a2dbf6afef54a654c262389ba9037ba2")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "83b6d477b9d16697c2002989891657ba95ee4e6a")
  (:PATH "docs/implementazione/id-directory-recovery.md" :GIT-BLOB
   "6ea173a4f8c1210432f00d11e6ce6aae4ad1174b")
  (:PATH "docs/implementazione/id-segmento-recovery.md" :GIT-BLOB
   "f2fa99ae8a932406bb74666fa401e0aa9b2655a0")
  (:PATH "docs/implementazione/immagini-indice-paginato.md" :GIT-BLOB
   "8e88cc05ab5ee90c1a1c98d9b20859b652a97bf3")
  (:PATH "docs/implementazione/indice-automatico-completamento-metodo.md"
   :GIT-BLOB "c354d887b3102978bf827b1959e323b7d9b18b27")
  (:PATH "docs/implementazione/indice-automatico-operativo.md" :GIT-BLOB
   "e70a739bfd63091d2ba9cec5c6fd6aa821e4d669")
  (:PATH "docs/implementazione/indice-automatico-risultati.md" :GIT-BLOB
   "d8823f505faa11809cea64f9f3c90675b0198fb0")
  (:PATH "docs/implementazione/indice-automatico.md" :GIT-BLOB
   "614b528773e7b34f955143e0afea744d431e2e1e")
  (:PATH "docs/implementazione/indice-da-recovery.md" :GIT-BLOB
   "486481170704785730c471af7dfd1a5816243a04")
  (:PATH "docs/implementazione/indice-paginato-m1.md" :GIT-BLOB
   "fe476e799ce3ec29caebbecb1a112a2e04bbe2f7")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "4e34fc8e0ffc4413a921b5538edd63693281b70e")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "439aa57177f9323735aaf1e8c4677cdf17e29ad7")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "3935af00f6b06ca6fbca8ab7a8c977eab164322c")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "32dd19680071319c88e9a91a0132260e921573d2")
  (:PATH "docs/implementazione/inizializzazione-active.md" :GIT-BLOB
   "d4c99e5ce4fb98ef862944a7cc41c08205cf60f7")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "56795353bfac9ce5c3ebc0b69f704890d306c194")
  (:PATH "docs/implementazione/inventario-directory-metodo.md" :GIT-BLOB
   "1c6d345a7b2d02c2687f08474a7805e79160b615")
  (:PATH "docs/implementazione/inventario-directory-revisione.md" :GIT-BLOB
   "42511becdd73740fd1ea37f271dc7d4482ddeb74")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "caab01e598ef66377c6da22dbcec17db820b8b91")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "7fcabec950c4e85735ab5bd7960cba65d0b1b494")
  (:PATH "docs/implementazione/io-apertura-relativa-metodo.md" :GIT-BLOB
   "fa44089871f66bddf1309fa5d75b4678eef58902")
  (:PATH "docs/implementazione/io-apertura-relativa-revisione.md" :GIT-BLOB
   "8b13ab5dd4831710adfa606e5edf659e31c8a714")
  (:PATH "docs/implementazione/io-apertura-relativa.md" :GIT-BLOB
   "975eed05b2318ed9b85f4d6f860c2431248f1db7")
  (:PATH "docs/implementazione/io-completamento.md" :GIT-BLOB
   "b5982e35ea000c4c9dcc91021374849d6670638b")
  (:PATH "docs/implementazione/io-creazione-relativa-metodo.md" :GIT-BLOB
   "84b9f6ac1bf934fb7c34e178542cce9dae62fdc6")
  (:PATH "docs/implementazione/io-creazione-relativa-revisione.md" :GIT-BLOB
   "6ad24b936952f03d7a70827f10314ac7f0ad1dfb")
  (:PATH "docs/implementazione/io-creazione-relativa.md" :GIT-BLOB
   "0a0d30b8c6cf826cb906b7d7d26bc8c4c68b3b8d")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "d6eb46b50c73b0150eddbc34cc93f127e82163dc")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "92c01fe2ab85af78f2f3cbf68cdaababa61f5ed9")
  (:PATH "docs/implementazione/io-pubblicazione-metodo.md" :GIT-BLOB
   "bdf72add9058e53ae707719af4ead4d18f462946")
  (:PATH "docs/implementazione/io-pubblicazione.md" :GIT-BLOB
   "f56f5f2f22e43b665a472d8560143b9430ea9ded")
  (:PATH "docs/implementazione/io-rinomina.md" :GIT-BLOB
   "d699c8433a309044b041ec1e2a0713ddb7d6f120")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "3db1a3257313b7040dd2b1222f4de77166de75da")
  (:PATH "docs/implementazione/lettura-indice-paginato.md" :GIT-BLOB
   "ce43161a04c6068b3ddce5b8eee94f35e46c5872")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "1fa26d055d5ee76d3a9bc6f6e6e31a3af3c0e0f1")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "91b0ee252ceff9071c62a573b7b499b8e36e1964")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "4b69dba2809dc40a4d039a6106dd02e560c8e26c")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "20b9246ebddba96db237e5ebcbf2529afbd26a91")
  (:PATH "docs/implementazione/manutenzione-indice-m1.md" :GIT-BLOB
   "bcf08f6c98961ee5660483cd627244c1243f2a99")
  (:PATH "docs/implementazione/merge-main-2026-10-23.md" :GIT-BLOB
   "cb672d06673d639a152ef3bea52b73f258513473")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "332563a00301c759a56fa56efeb0c733f5d8acb5")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "daca7cad14916fbc0b10743a6898bfba4f6c47ad")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "2789dc59d0173d4e0af289cfac129ab12d1bec00")
  (:PATH "docs/implementazione/moduli.md" :GIT-BLOB
   "971b841de90347b255a3e22aaf4e7682fbe25e2d")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "48ffbd9f476751940bbae8713788bd1d812a6002")
  (:PATH "docs/implementazione/pagine-indice-risultati.md" :GIT-BLOB
   "e8889ba9c0d836e73050037bd49faa9ae016a5a6")
  (:PATH "docs/implementazione/pagine-indice.md" :GIT-BLOB
   "34c6c7dec3f852d8dc6245a6c05a7f26ef2d09a5")
  (:PATH "docs/implementazione/pool-begin-metodo.md" :GIT-BLOB
   "8d10cde6f53e6e75cd936fa109121d0caab09d5f")
  (:PATH "docs/implementazione/pool-begin-revisione.md" :GIT-BLOB
   "95657e20c25dd27baddab5c04a2053170af45b96")
  (:PATH "docs/implementazione/pool-begin-risultati.md" :GIT-BLOB
   "c4049dcf13b516abf81bbea4d32aff64cb425c7f")
  (:PATH "docs/implementazione/pool-begin.md" :GIT-BLOB
   "06bd817d57eb415225973e0981778132621cf230")
  (:PATH "docs/implementazione/pool-catena-metodo.md" :GIT-BLOB
   "758327137a15f0f1ef344d51370add33a3a2c6cd")
  (:PATH "docs/implementazione/pool-catena-risultati.md" :GIT-BLOB
   "8bf6c0fe47438107778c68195e6f98ccb42b0b9c")
  (:PATH "docs/implementazione/pool-dispatch-metodo.md" :GIT-BLOB
   "eb6709befc9bdb0d67b04fd5c4c4f98a01ab94de")
  (:PATH "docs/implementazione/pool-dispatch-revisione.md" :GIT-BLOB
   "abda6bf2dbaa1fc5fdc6e55cc22bb0ee931513f2")
  (:PATH "docs/implementazione/pool-dispatch-risultati.md" :GIT-BLOB
   "ab68af4bc1ab1552d74c694ce96c1e1c4222920f")
  (:PATH "docs/implementazione/pool-dispatch.md" :GIT-BLOB
   "a540afacd7952495cc3300e0bced676639c55337")
  (:PATH "docs/implementazione/pool-prepara-metodo.md" :GIT-BLOB
   "4da00d6f92b7f949ec8acafbd3a97dd56bbbb367")
  (:PATH "docs/implementazione/pool-prepara-revisione.md" :GIT-BLOB
   "2c5e9f14f01fedcb7e3dc7a3b4ade9b8bfdcc9b6")
  (:PATH "docs/implementazione/pool-prepara-risultati.md" :GIT-BLOB
   "8c5a986a075da0555e225369bb08b72e4994558b")
  (:PATH "docs/implementazione/pool-prepara.md" :GIT-BLOB
   "84dcb4f1603e43af42c335d58a1d67ebe6347ae0")
  (:PATH "docs/implementazione/pool-recycle-metodo.md" :GIT-BLOB
   "2c811c8f11f65e5142e23c6d8e306b44e412d1e0")
  (:PATH "docs/implementazione/pool-recycle-revisione.md" :GIT-BLOB
   "100e57b2835ce7bc6b5dc68912cf99ae1e637c30")
  (:PATH "docs/implementazione/pool-recycle-risultati.md" :GIT-BLOB
   "4a192b8293368b041956bf12a8e266bd08d86cb5")
  (:PATH "docs/implementazione/pool-recycle.md" :GIT-BLOB
   "40dcde9abd1d21cf1d0d56cecc3b66c641b607b8")
  (:PATH "docs/implementazione/pool-step-metodo.md" :GIT-BLOB
   "e44a4958a4c0a67213243b112bc7362f0573e914")
  (:PATH "docs/implementazione/pool-step-revisione.md" :GIT-BLOB
   "66ab0543f271b9a5c96cb6aa2247be4d6925fd59")
  (:PATH "docs/implementazione/pool-step-risultati.md" :GIT-BLOB
   "470c7dc02213e5d01719829413da36ec08cc5d4c")
  (:PATH "docs/implementazione/pool-step.md" :GIT-BLOB
   "09a4edba6f17bed9682708707ecbe188b2b8e101")
  (:PATH "docs/implementazione/pool-worker-claim-metodo.md" :GIT-BLOB
   "b1b933f896ebb4b2c54a2a714a4c4291c431662d")
  (:PATH "docs/implementazione/pool-worker-claim-revisione.md" :GIT-BLOB
   "18aef79552d243af35866c3d2955e2d11761935d")
  (:PATH "docs/implementazione/pool-worker-claim-risultati.md" :GIT-BLOB
   "f0ce19f06da992cf25de5b3dd396258b7197105c")
  (:PATH "docs/implementazione/pool-worker-claim.md" :GIT-BLOB
   "5a69ddd2dad8066ee9d03792f8548abb9225222f")
  (:PATH "docs/implementazione/pool-worker-lifecycle-metodo.md" :GIT-BLOB
   "d32a1e07253c9138b176912091366712ff3037a4")
  (:PATH "docs/implementazione/pool-worker-lifecycle-revisione.md" :GIT-BLOB
   "9638731f43392e0a33b7f4ed84b19d6c46d1b0fa")
  (:PATH "docs/implementazione/pool-worker-lifecycle-risultati.md" :GIT-BLOB
   "d26d034ded38c3feb056a5a272e5147d790b36f6")
  (:PATH "docs/implementazione/pool-worker-lifecycle.md" :GIT-BLOB
   "5a1af3956ec7cb503cfe7b561acc66e3b32029ad")
  (:PATH "docs/implementazione/prestazioni-local-m1.md" :GIT-BLOB
   "d09055552b7b9fa8d15cd552465dc1025defa2d6")
  (:PATH "docs/implementazione/production-engine-bootstrap-metodo.md" :GIT-BLOB
   "92ea9255903acb119f72d1a61affda35f94a9358")
  (:PATH "docs/implementazione/production-engine-bootstrap.md" :GIT-BLOB
   "f0ee1cad927d984d0f7768e6756cf98ff61dae85")
  (:PATH "docs/implementazione/production-unix-m1.md" :GIT-BLOB
   "7a8cd83317053d2131783e3faf7c75b2deb8f002")
  (:PATH "docs/implementazione/prova-verticale.md" :GIT-BLOB
   "3b9642adce018f1bba63fca6cfaad10924f0351f")
  (:PATH "docs/implementazione/pubblicazione-control.md" :GIT-BLOB
   "8dee23aebeb7bd74de78153bff357b6810162ca0")
  (:PATH "docs/implementazione/raccolta-comandi-risultati.md" :GIT-BLOB
   "0e8a853a5618a1906dd4adbb7c9b18840959d03e")
  (:PATH "docs/implementazione/raccolta-comandi.md" :GIT-BLOB
   "69a9ac538805c31b2857a55f2d5b5c32c0a71b38")
  (:PATH "docs/implementazione/recovery-archivio.md" :GIT-BLOB
   "728fcfa388c5032d170b4f1924b6d614857baee7")
  (:PATH "docs/implementazione/recovery-csn.md" :GIT-BLOB
   "0a3b62e567853df795b710c8e080e3e4319d5153")
  (:PATH "docs/implementazione/recovery-serie.md" :GIT-BLOB
   "fb61bc33d840d815c72dcb3eb4c74c909708d42c")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "09620fc2b2248bec312b075e411f6864a5ebf16f")
  (:PATH "docs/implementazione/replay-closed.md" :GIT-BLOB
   "bb4499a07188b2887c5960e3eba59c951d80a159")
  (:PATH "docs/implementazione/rinnovo-automatico-m1-metodo.md" :GIT-BLOB
   "061f7030b0c9486754cea7333ee3838cf5f00e59")
  (:PATH "docs/implementazione/rinnovo-automatico-m1.md" :GIT-BLOB
   "29fbd690f61f74593e280c1be93b64d74b2609cd")
  (:PATH "docs/implementazione/rinnovo-indice-m1.md" :GIT-BLOB
   "048fb5e263d00771553c8de699ebe0e585c9c780")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "d7b9c49b07bae6f01a5562d15a2cdabcbb979878")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "2709d9ad98b8dd8028b36f0163ba09bf2f49ae14")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "fa341fd666506b060c4d1253773dd87859014238")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "569fb428d702f4a60440c10cb0d9a1a360670fd1")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "ac6b5e1ea180807849dc24481de16eb79e4999af")
  (:PATH "docs/implementazione/runtime-archivio-revisione.md" :GIT-BLOB
   "bba7a3fa2b7e2139ea24ec86cc97fb4b02909aff")
  (:PATH "docs/implementazione/runtime-archivio.md" :GIT-BLOB
   "f8efbf185c6e21920a72d7982f396f5f6e4360d8")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "54739f1b4f681ee51b684fd5f1706028a8922b11")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "24f4832f44e05b4958ee59a8b9b899228f5afa6d")
  (:PATH "docs/implementazione/scoperta-indice-local-m1.md" :GIT-BLOB
   "c6a2000090f8bf5b356b49804799739acccd1344")
  (:PATH "docs/implementazione/scoperta-indice-m1.md" :GIT-BLOB
   "4f05d679dfd56ea2922507433e26c876de136b00")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "40197f19d765e646a0e3ce558386997294130ab1")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "16a6ec600581f9c958650a8578117ad7d7d79584")
  (:PATH "docs/implementazione/selezione-versioni-recovery.md" :GIT-BLOB
   "47d2caa2887778182456420705e0228179305769")
  (:PATH "docs/implementazione/sessione-locale.md" :GIT-BLOB
   "2ecf722d1f5009738a021d2b451e71bfcf0a6c2a")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "3badf8773cc33d0a772b9bde5741af120be1db29")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "52ce3f078d06cad8ffac89ea2baa6ad830c0df34")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "d0ce2c9951518f30ccec2391bc8d9e3e508eaa19")
  (:PATH "docs/implementazione/stabilizzazione-archivio-metodo.md" :GIT-BLOB
   "e29923b3ea68b49f0d100baa7b41f221663d26f9")
  (:PATH "docs/implementazione/stabilizzazione-archivio.md" :GIT-BLOB
   "51adacc370255a8a7d7bb9cb32d5efd9d98cc21f")
  (:PATH "docs/implementazione/stabilizzazione-esclusiva-metodo.md" :GIT-BLOB
   "862b15afa8262596760a2b84e08ba266369e101a")
  (:PATH "docs/implementazione/stabilizzazione-nomi-recovery.md" :GIT-BLOB
   "19c7b3f57ea810a35ebe212071e06e27f61c3a21")
  (:PATH "docs/implementazione/stabilizzazione-serie-metodo.md" :GIT-BLOB
   "89673b60a8a5690b772ef365b2194470238efd14")
  (:PATH "docs/implementazione/stabilizzazione-serie.md" :GIT-BLOB
   "960b956f4841ce0d3a6e38612feee69f2666ab37")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "ec3c6b8f92c54a84bc98d5ac21e58758152de542")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "a60c8e7ee23f78e8a53a516e2c161fc0827ff699")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "e7cf6d0c9962ed26216d07d63d052d45bb9f03e7")
  (:PATH "docs/implementazione/verificatore-offline-m1.md" :GIT-BLOB
   "acb6d215ca675bd8fb4108a1fc93d4009cc9b69e")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "1a94e0e95ab7446193da420d97bedc24a721d387")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "8ab0ba990681d1b185ab87aad114593c0abb305a")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "f08e66f8b7925a5bcec55f2edf1380fc66d6c0a2")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "353a2d053b16ec57b6572aed1f17d1b49d8a232f")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "15c437c7c71674f8fc1cd5a72b3162f4f1715eba")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "e20c5c59567d8ce4800dc19e8dc5fdc2f7f0606f")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "f4edff819e12b287df3cf5f00ecd3550e930f9e0")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "1c4fb7c470a4cfbc6509ccb1c6f793e8bf74208c")
  (:PATH "docs/implementazione/worker-cbor-interleaving.md" :GIT-BLOB
   "02c902149e07d4ac4dfc6f6170799eb34574f09a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "ab3e69cc7051d3ce33f9b4d94cd0e2b20b49807c")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "2c5bcfdaa1783a21adba6911300d0baf7d12f339")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "8fcb335ad6bc807d58ab2ec9033f948421737de5")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "8fa6801e99ffb1abca08a0861883ace20672bd2c")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "63c27916925bec8cfbc39c0c9d558eb444e6dad2")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "f35b46574ff72f1ddac7498c601be30c990d859e")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "ebea51d87dc4f0c750be5834f48d66aac19c7e2d")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "9cd61461e8bfad2d757011db0307229f1517a0d2")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "865c639e5d48a0a77133b6fbe033d78113f703ac")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "1dd65b133120e4f660ed14e674caa8d9af55cfc9")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "4812ec2f65bf772695877b5760a2528fb69a70ef")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "debe8bfd28a95306a16004ca1ccb20ff2bf85fd6")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "7a1ffa13a41b58db26e43bb4090a5d7b6732e512")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "f0ab347bf7c6974b7968e96b9615238b2b14713d")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "b3d19a3668170d14b2ee8a1cec101a27334a8d41")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "14bca7f6cd2c9976cbfdbe3a24a146bc46a34d79")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "f0fd5c63f1adaf9e08e3a7f03dd3fa62bc10aea5")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "c96e7d84ba793911aca73e1deafe6da49509b879")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "8543024839bb87730a16489183b141a010d48cfc")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "234ef34a0065f902f68cdc9432513444a303731c")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ae34240b8fcb8fecbda5492828281de203dc5327")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "07bc53c1a476b0f93bf860fa18c97573d96c656f")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "e120e67c134bd2b9ddbbf55259f5195a3ef4989c")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "85cdbcee3cc2985f6935c6508b71ae9eccf58c99")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "a7329d98d65dd7a94773a87d27f7e3d3871469bf")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "370e2848280af70fbee9085f4c5f1fb44b110889")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "3a9260af22a77d11d636a787613bd50668ffc1cd")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "1600a7f92e73a45f44214bfb2074d0c5cf6decec")
  (:PATH "docs/legal/README.md" :GIT-BLOB
   "149c30dbb116c197f5046d245f765803ed6112f4")
  (:PATH "docs/legal/accessibility.md" :GIT-BLOB
   "f0075a299d3f10c36f250343da01908f39bfc447")
  (:PATH "docs/legal/distribution.md" :GIT-BLOB
   "60ae06a99a28b346e28a28dba81925e38b762192")
  (:PATH "docs/legal/privacy.md" :GIT-BLOB
   "668c2ffde82f4149697d070851e5fdbf281937b0")
  (:PATH "docs/legal/review-2026-10-31.md" :GIT-BLOB
   "8e4053b788081e583340d3531e8c618eba2ef312")
  (:PATH "docs/legal/third-party.md" :GIT-BLOB
   "308d64af3e3901e8c8ea6209ec772f65bd55796e")
  (:PATH "docs/limiti.md" :GIT-BLOB "18a03d0c1262b4ddaddf5ff1cb3dd1777f216c3c")
  (:PATH "docs/lisp-api.md" :GIT-BLOB
   "a53a254f4225afdd5d59dffc7aebeb158b40bec3")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "f639c868ec4145ce4d712345973822ada77abb6a")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "6c2425c43abbc961ab2845fca2e3ea069b39eb81")
  (:PATH "docs/riferimenti.md" :GIT-BLOB
   "9addadca061376e75319617301e590e010ab8467")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "6b24c490e7a4e90e7d0d751c0796f89a23849c39")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "113bbeaa93a2032b3a642d626836c1d5f5d16c4f")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "df1e19c126d44b07fecbf153fcafa2c9af44e861")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "aef527376c8e9d22207168aa935b6acb10b2b528")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "1ae3fc90e1a01aa296c51d3f25c6d65c1bcdb5da")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "b7ef23de41612f981d34a97641e52902a1840a50")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "33f78a2faae61cd73459658d3ba2a88e2ecafe81")
  (:PATH "docs/valutazione/caso-duso-nntp.md" :GIT-BLOB
   "b6a035e1d66b869f40a42e07f2021a42d7de2859")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "972ca495cf51f54d16f3c33ca31fe890b6db7806")
  (:PATH "docs/valutazione/cronologia.md" :GIT-BLOB
   "be43f507343a1c75d71d9e4ada287a9c2fc0de12")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "32026027782790da44884b029c4bae89d5f4e1fd")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "32e72f3b579ee02d5a5e0e897a7618434b02e60d")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "2eeb123c80d9f061d21d2f1a31c57613d7707506")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "a01e78e3fd9dbfe2705fa6fda631d9c387b3bc91")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "c3173768fe23a50691d7106bddbc8c46bb8cd040")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "ed0b8c472645dd6e31178034268a7e60a34e09be")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "603665f1033eb1a62f8b9a4115250a16cf39b429")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "dca0a8b0aa20c8d038dcbc11023182fd552de10f")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "45bf66ebba21b28f569e6f12344277dce7245cd9")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "11d712a7a3432a89299a2f5d7f23736d596d7e40")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "f3eecb3e77252633aac4a62f1100a77b64ca91e0")
  (:PATH "examples/local-roundtrip.lisp" :GIT-BLOB
   "f814d10935f22272e5a440e92e7c8109dda16be8")
  (:PATH "legal/algorithms/xxHash-v0.8.3-NOTICES.txt" :GIT-BLOB
   "1ac346f5f0bff517073cca31f1509f39a5818d55")
  (:PATH "legal/notice-files.lisp" :GIT-BLOB
   "30a68c858f462c6ef601c270ac48603374b149d9")
  (:PATH "legal/runtime/SBCL-2.6.9-COPYING.txt" :GIT-BLOB
   "4220b33974e7fc04036b2b5600cb3ca88ce2c4c3")
  (:PATH "spikes/README.md" :GIT-BLOB
   "f835fdd46c43312889de749d525290e541e891f3")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "c2c2487c33cadbec5444b81073eb9e417a16c42f")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "03a90c690b4673695f0380f81f0cf68e4da8eda4")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "049ff2032103d3d6a6a8049fa9d803d6f82beeaf")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "cd79005b8100b79cbbca35a5677125af54f5e854")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "b388bbb2a067537c8b03b046d63ed6fd5201fa58")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "be57e2f216618fb65d5dde48e8d29938d377a009")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "6452906fa525035cf6abe7967f05778aeaf17f76")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "014f488b7b50a9439b36f49afd6b6f0f11295d84")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "badf96cfb95709afc9174e40b521ac75c6adac8c")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "1a46426b6521ca207a747cd0d2a7fed0ad4ecfd1")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "0061c53057783cc076b2dcb9596e91017e473c47")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "7edbb7459ca78fb41cb812d82ce1dc1c68176ea6")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "18246e75e94db5f4517e96e827469d6a006b30d2")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "0597672e814ccc60c541439e838b7e4eb491788a")
  (:PATH "spikes/SPK-07-protocols/metodo-page-lifetime.md" :GIT-BLOB
   "fba367b24467642a6e544ff86e099b143a73a925")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "6c0034a70670b4249cd2b525c9fca3e140dbd94e")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "517286df830984ba4a6ff39b03175e445afd65d7")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "163e4c3222c4e5771660e6463367ec6b1bc914af")
  (:PATH "spikes/SPK-07-protocols/page-lifetime.lisp" :GIT-BLOB
   "c032387167188be066737f75583738843b12c883")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "1ec5a1db56a76daacbc7488d8b7940aa0e16eca0")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "95ab6095de30d013dbf5c426f7b6c0a99d5663e6")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "9daf0b57d92db583544653384217105121c8627d")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "4712fb08742000724dbbf5c1f7fac4505ca6ad4c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/comparison.lisp" :GIT-BLOB
   "b8b8ebfa609d6bfe9b710833f22cdff693ef46bd")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/crc32c-unroll32.lisp" :GIT-BLOB
   "6dbbe7218c7b5185329f099a8c1407e0f48d8648")
  (:PATH "spikes/SPK-08-generated-code/crc32c.lisp" :GIT-BLOB
   "72bccfafe9c5cb0fd5dc6392534c5be404774a64")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "680b5d9c4e112747e903e124e07cab8adbf97da9")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c-unroll32.md" :GIT-BLOB
   "d722f4f0145cca93b8cb46aa0572538df99a12e0")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c.md" :GIT-BLOB
   "fbbb491611d807c1022c50236fe29c8d7accb2c0")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "4a57493b511201112c533418f1846acdf96f35c8")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "1bbf37c97bcc7d527c3d5aa90cbb9217b807f3ee")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c-unroll32.lisp" :GIT-BLOB
   "79033530456f565b3b14e25b56146039b5356860")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c.lisp" :GIT-BLOB
   "a45f0c3e862c2174b64ac63d4ca97ae3ddf21569")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "7c797afe4a6060782ce58f0cfc06f539006d117a")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "2ed0e101d31cef0967820fc70155ddd4561140fa")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "740e01ad7ddd2dc170e50454befe9a63b9eff276")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "1e54780546d2bcdd623f7fa6c2faaf127bf15dae")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69ac8ef15f356257dae151e035689d8124e9a9eb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "95928362ab8fbde280a5f74be905ae2ca58729ab")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "df0869dea4916cdb5b671a79ffa812369d043773")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "spikes/SPK-11-unix-socket/README.md" :GIT-BLOB
   "47d0cf7d3d5b5541e38cb47814dbb1f0197ffbdc")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "spikes/SPK-11-unix-socket/core.lisp" :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/native-io-method.md" :GIT-BLOB
   "a90da59a3ecad08654d619a56c2ced177db88a40")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-method.md" :GIT-BLOB
   "ebd5dce74e96860ace17a05cf7e14f940adb126f")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/core-code-review.lisp" :GIT-BLOB
   "894a03026e1d4c55f8bde65ba79d64e2775d1826")
  (:PATH "spikes/evidence/README.md" :GIT-BLOB
   "d0dd48506d19490ae1c864f86f4606845241a15d")
  (:PATH "spikes/evidence/history.lisp" :GIT-BLOB
   "f210350eb462c1f3d45f24217f004775496b0eaa")
  (:PATH "spikes/evidence/snapshot.lisp" :GIT-BLOB
   "9ea68544e9490d6598d6361ae0bac6e27a69ce4e")
  (:PATH "spikes/verify-m1-check.lisp" :GIT-BLOB
   "5ec3e4bf45087fec1fd8f878f746dfec63bbb1ab")
  (:PATH "src/active/package.lisp" :GIT-BLOB
   "fbd3a32b30808508424c007ece26c9f3ea9ad0a9")
  (:PATH "src/active/preflight.lisp" :GIT-BLOB
   "9a7da536a7286f5996bf1720db7f9b9dbf20abff")
  (:PATH "src/active/prepare.lisp" :GIT-BLOB
   "e6739a357bdce50ca6bfda7dcd147ce8ffb790fd")
  (:PATH "src/active/source.lisp" :GIT-BLOB
   "27316c9e39b54ff4b2f6b4fe491ab7e67197a950")
  (:PATH "src/active/types.lisp" :GIT-BLOB
   "fc4c2d3ac0839aab37b91d4e017cdaf18bc5041e")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "b0230656edbe3dea63568e74a97e5193cab7c54a")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "a1db79505e00f465b0f0debacbcbd8aad60c5b75")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9725836f0c142b5e292fea4d073f5fbc52b99825")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "84b090e318216a832ab684fc5a936c68e465c169")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "93ecc29914d02b4b6066896de8c2590906ca91bc")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "03bdfeeef2e2639030d3509bd6905364c55f345a")
  (:PATH "src/codec/cbor-array-input.lisp" :GIT-BLOB
   "1b028f9e5f945266f1144b664bf206e89f603863")
  (:PATH "src/codec/cbor-array-write.lisp" :GIT-BLOB
   "625b61e204f7485e1015d109426810ef9d92827c")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-float-narrow.lisp" :GIT-BLOB
   "a2424c60204a55c7ec315de4446e41e243a1afca")
  (:PATH "src/codec/cbor-float-write.lisp" :GIT-BLOB
   "5a44cea28eb51016ce5155ebdf5750b93d15a1b3")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-item-read.lisp" :GIT-BLOB
   "e95db7d9f407e9e0039dc8892e4af8065490d99d")
  (:PATH "src/codec/cbor-map-input.lisp" :GIT-BLOB
   "87c9fd9dd6eb1f3ee1b79bdf2957801762601d97")
  (:PATH "src/codec/cbor-map-write.lisp" :GIT-BLOB
   "84887090a1fa543da817bd096528b576f3d58d9e")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "d9c686fef43c16c5cbf85672b2480a3d0340edfc")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-string-read.lisp" :GIT-BLOB
   "446498b0f3b0f014471312eeb01b3d9a254b6535")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a9028c0b30a22367baad2711346a5517089b1940")
  (:PATH "src/codec/cbor-tag-input.lisp" :GIT-BLOB
   "760e81952f8eb3210465a6cea5c0b89c3f15c5a4")
  (:PATH "src/codec/cbor-tag-write.lisp" :GIT-BLOB
   "4680d759cf12aaa61df5823cb86e71ed7379914c")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "159033291735d23258b340f8da17ad6bd001ccbf")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/control/build.lisp" :GIT-BLOB
   "d5aca4f9ade3c126e88709f1ada1a9e39132b6a1")
  (:PATH "src/control/dependency.lisp" :GIT-BLOB
   "144f908c5cafddc397dd8a1cab04cd641d93a32c")
  (:PATH "src/control/package.lisp" :GIT-BLOB
   "e56a6bb83abe9441350baa46573d74c6d55edf4e")
  (:PATH "src/control/preflight.lisp" :GIT-BLOB
   "850a8f3bedb592dad251e36d7e95ad9fa993979d")
  (:PATH "src/control/prepare.lisp" :GIT-BLOB
   "51cdc2f60ef3da074e98f5bbabd1bb1b4ffbd6ed")
  (:PATH "src/control/publication-read.lisp" :GIT-BLOB
   "a5ebb2f8fafe283f3816d48e633ef8471bfbf4ba")
  (:PATH "src/control/publication.lisp" :GIT-BLOB
   "c8c482c65af3a94bea9acc38b3b93f04933c93b1")
  (:PATH "src/control/recovery-publication.lisp" :GIT-BLOB
   "b01545b6647f5dbac8097dcab394260fb7f9d3cd")
  (:PATH "src/control/recovery-read.lisp" :GIT-BLOB
   "430665c20905e5f7d67245e2d7503bb0f9e0c11f")
  (:PATH "src/control/recovery-types.lisp" :GIT-BLOB
   "2ac4f985eec224f17cea5658cd9d42f4aed99cce")
  (:PATH "src/control/transfer.lisp" :GIT-BLOB
   "69bb7c2e27817201c5533fa4d6099a26750a38b7")
  (:PATH "src/control/types.lisp" :GIT-BLOB
   "7eaa6e2298ac264b7d64c1f7a78de8d1fab8ce09")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "c2ff554d80181b48d8ba414e9d2c6a84080cb413")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "c46fd76164808980af1d8b639890b3cc0ce8fb79")
  (:PATH "src/dispatch/begin.lisp" :GIT-BLOB
   "bb45bcad39e438aa082e92d01358d1059cc5fd20")
  (:PATH "src/dispatch/build.lisp" :GIT-BLOB
   "9d1c974830e92918b572af978e8a2b4acae257b6")
  (:PATH "src/dispatch/claim.lisp" :GIT-BLOB
   "a9d55f610fbd14b5bff7f9d6c2a6c8abb7ba405c")
  (:PATH "src/dispatch/package.lisp" :GIT-BLOB
   "db21c798588ff4a88be5b69b5fbe72bc84811a46")
  (:PATH "src/dispatch/recycle.lisp" :GIT-BLOB
   "57955f63a0cfc4efc3f7f742fd479c032dcec5b2")
  (:PATH "src/dispatch/start.lisp" :GIT-BLOB
   "4d519c9fba0c085d5789c2883c8d04079e3933ea")
  (:PATH "src/dispatch/step.lisp" :GIT-BLOB
   "36c8c1e84c7329f4a0b24186e09a40b2ce2d2b61")
  (:PATH "src/dispatch/types.lisp" :GIT-BLOB
   "6f3b3841a3158cac6daf70cc8a1ae3984f52566c")
  (:PATH "src/engine/adopt.lisp" :GIT-BLOB
   "e91cde14fcff879a1858b28c6063e5188dca4da0")
  (:PATH "src/engine/compaction-control.lisp" :GIT-BLOB
   "02cbb0127a3e9519ed0dc90730f077ade17fb5dd")
  (:PATH "src/engine/compaction-install.lisp" :GIT-BLOB
   "167777a12cf87a02b36a73c5609d098d9d8d1b46")
  (:PATH "src/engine/compaction-plan.lisp" :GIT-BLOB
   "d255c8440ee3abb0c190801e7c5b2e1a4872b47e")
  (:PATH "src/engine/compaction-reclaim.lisp" :GIT-BLOB
   "00076045f47b9b8a5a4a0aeee449a3a0cc5e2047")
  (:PATH "src/engine/compaction-relocate.lisp" :GIT-BLOB
   "3f316d79bf63b30bb5fa0cbac38927cf2a6e540d")
  (:PATH "src/engine/compaction-scan.lisp" :GIT-BLOB
   "942e0b2ba2be30a2e94efa1c80564dd7159e322a")
  (:PATH "src/engine/compaction-types.lisp" :GIT-BLOB
   "ee6f36958a147af9cdabdfee2ebe77752476da74")
  (:PATH "src/engine/compaction-verify.lisp" :GIT-BLOB
   "57628bb40f5be4c42b4366e81a0662f7f98c0137")
  (:PATH "src/engine/compaction-write.lisp" :GIT-BLOB
   "41cc966628e64d765c8a8f9d132321451025a3bd")
  (:PATH "src/engine/compaction.lisp" :GIT-BLOB
   "1eac672cf412fc36ae6fbfe5d8b4e7b93dcf480e")
  (:PATH "src/engine/config.lisp" :GIT-BLOB
   "354198f7b04489a46d0a67018d181a4c8668a42e")
  (:PATH "src/engine/delta-location.lisp" :GIT-BLOB
   "367601a853f8d2dd155b1dc0002b86d1b4bcdd5b")
  (:PATH "src/engine/delta-types.lisp" :GIT-BLOB
   "539f08cdb3736546b2b1556f81050d6c5d09ece9")
  (:PATH "src/engine/delta.lisp" :GIT-BLOB
   "b865dc6c8be351c3e89fcddbce61a4e0d7a2dd5d")
  (:PATH "src/engine/files.lisp" :GIT-BLOB
   "eda0f6adb8eb34225b6775b8ef666224e753deda")
  (:PATH "src/engine/image-activation.lisp" :GIT-BLOB
   "51ef93215340364bc2c881f3e7efa6a47aac6aa8")
  (:PATH "src/engine/image-auto-types.lisp" :GIT-BLOB
   "8879e3aa9b00d18cb138da9ca6d04028816502af")
  (:PATH "src/engine/image-auto-write.lisp" :GIT-BLOB
   "ac1ad97829a4b076b6f223e9e010c55752bf3066")
  (:PATH "src/engine/image-auto.lisp" :GIT-BLOB
   "0449392da3326308f5697fc231d24d329a691db8")
  (:PATH "src/engine/image-build-io.lisp" :GIT-BLOB
   "fbd185cd56d4d980575c4d0fec5597b715074f61")
  (:PATH "src/engine/image-build-plan.lisp" :GIT-BLOB
   "ccd01ee41d0d7a103680785731c5271a54f6f2df")
  (:PATH "src/engine/image-build-read.lisp" :GIT-BLOB
   "b11e63f292b93ddaee8b0c645d525a175a1906b0")
  (:PATH "src/engine/image-build-tree.lisp" :GIT-BLOB
   "d9a657c2fbdbb294e34fe8ba40c4fe8c8df11f03")
  (:PATH "src/engine/image-build-types.lisp" :GIT-BLOB
   "d2aacfe57703a7a99354657e4823a641d6eabb43")
  (:PATH "src/engine/image-build.lisp" :GIT-BLOB
   "a4c8ad027a796610299f457399f566ac0ca4284d")
  (:PATH "src/engine/image-config.lisp" :GIT-BLOB
   "47becee77666bb573500cc1d23735e627e65411b")
  (:PATH "src/engine/image-discovery-config.lisp" :GIT-BLOB
   "66c7f2c7f7eb87e0147d858c11787ffdd06b14bb")
  (:PATH "src/engine/image-discovery.lisp" :GIT-BLOB
   "aa41ecbc41a335a25fd3f62761147be516ebce6c")
  (:PATH "src/engine/image-maintenance-config.lisp" :GIT-BLOB
   "cbd5f1cdde00a60ee8cd952898c06e205c8edf1c")
  (:PATH "src/engine/image-maintenance.lisp" :GIT-BLOB
   "44bdff3e98ff1176b51b1bbc20bb8f54b94f5f3d")
  (:PATH "src/engine/image-recovery.lisp" :GIT-BLOB
   "f42286cf6d43cd486d9c4a79f764c99c35e2aa37")
  (:PATH "src/engine/image-renewal.lisp" :GIT-BLOB
   "0e6c21fcdec1d316551417b024e1ba5bda472abc")
  (:PATH "src/engine/image-source.lisp" :GIT-BLOB
   "8b7c7ecdebbf07ada9b68037976be5af53a6a106")
  (:PATH "src/engine/index-auto-api.lisp" :GIT-BLOB
   "1241871a3195c1c42b890e08373803a816809817")
  (:PATH "src/engine/index-auto-apply.lisp" :GIT-BLOB
   "7062c70c0f6322cda8de3f089bab2a216dae3d44")
  (:PATH "src/engine/index-auto-files.lisp" :GIT-BLOB
   "2c79ded6eb822d4f238f31cd7756bcdc79d5be7d")
  (:PATH "src/engine/index-auto-memory.lisp" :GIT-BLOB
   "8199f78030cc2d21af63d223c7d9cb99cb22b4fb")
  (:PATH "src/engine/index-auto-migrate.lisp" :GIT-BLOB
   "52e44cd130f7dc77bf6fa0be130dfc4827b4ec59")
  (:PATH "src/engine/index-auto-resolver.lisp" :GIT-BLOB
   "82554d4e3b9382c60bbdb0cf2986a4e75af1dafa")
  (:PATH "src/engine/index-auto-types.lisp" :GIT-BLOB
   "7d848c894841cdcf2abf615cd8140568a264351c")
  (:PATH "src/engine/index.lisp" :GIT-BLOB
   "650e3e008a6e489ebc3972366724edab5a3189c0")
  (:PATH "src/engine/initialize.lisp" :GIT-BLOB
   "8c39b866a402a30b1aa1ef7409e675f367e4ec97")
  (:PATH "src/engine/lifecycle.lisp" :GIT-BLOB
   "717898da19e3288ee03ac782959c23d32c9b8170")
  (:PATH "src/engine/package.lisp" :GIT-BLOB
   "b92f6f86fa3c2b744a281af0f48a45b07d9fd29c")
  (:PATH "src/engine/preflight.lisp" :GIT-BLOB
   "272b6ffeb63fa9536bade7a0fd48764340128e4c")
  (:PATH "src/engine/read.lisp" :GIT-BLOB
   "658f1224eabea55171889037f09cbd030c9836c9")
  (:PATH "src/engine/record-cache.lisp" :GIT-BLOB
   "6d00296bffb12094dafd46a4ac898c9a20f81dfa")
  (:PATH "src/engine/recovery.lisp" :GIT-BLOB
   "05b64c0a49c59c209af8bac92f6823c193a92122")
  (:PATH "src/engine/rotation.lisp" :GIT-BLOB
   "db73c93ab163dc4cf2699cb6c357cfa3591be092")
  (:PATH "src/engine/startup.lisp" :GIT-BLOB
   "5245c459ca92fa0f69ff1810befc748fbb303f7f")
  (:PATH "src/engine/types.lisp" :GIT-BLOB
   "b3c3d38211888a9f971eaf78370ad4f93250ee79")
  (:PATH "src/engine/write-group-build.lisp" :GIT-BLOB
   "20a777cd92be4b8f91dad208132945c42309496c")
  (:PATH "src/engine/write-group-commit.lisp" :GIT-BLOB
   "18a21f787b8bdb1f41dd4f1ee3e215253cd62c0c")
  (:PATH "src/engine/write-group-index.lisp" :GIT-BLOB
   "b28196235d2b2853edbe75fcb5d024c0e7ea1b11")
  (:PATH "src/engine/write-group-legacy.lisp" :GIT-BLOB
   "a0c17966476bfa9d5a008bec9b6071c91070040f")
  (:PATH "src/engine/write-group-plan.lisp" :GIT-BLOB
   "d126d7176bef13a8dc19bac5836581cb65dfbd35")
  (:PATH "src/engine/write-group-types.lisp" :GIT-BLOB
   "2f1e78aef52cbdb0aabc663873b832eb31713bba")
  (:PATH "src/engine/write-group.lisp" :GIT-BLOB
   "bacee8da25a18c7736921c10357a344394eb5ed8")
  (:PATH "src/engine/write.lisp" :GIT-BLOB
   "3b83c17a8bf510c110648b4257fe9b8df43b6bf5")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "93dbc244d3e8a86e64254b31e2954102f65ab149")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "0fc4c81f23e27dabfe52485a3976ec3eb390eb4c")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "e0d503d2ad85689ac6162636857f4e44f2b5c7f9")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "474ddacfc871629aad94b6d59b87de7cd4349475")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "838611d288696767dc539b155fcfefe3feec79e2")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "bbed8c36a799b57baebe6350dd96c3a968dd05e7")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "b27df62179c9f43132c445c82f0c2bf4ee78f366")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "5d4e27472170bfffa85a6e8aac0760236e7fefb6")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "f79bbd85269d50eb929816276353b2fbb85f92c9")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "a36b9bc921e8d58f9cf3a10a8426eb388e710226")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "c066712083a07bc574481ae3a3cdcc996c9303a8")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "3c970d0cbd3866d837c07bd03d7e4e0fae24f21f")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "c048d0e7321d26e5ec3ec4eb7d3bd79b4714aef5")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "7170e6de30721bcb89cb94b56e9d3c579a1269be")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8be80a716738875d5e6fe056c5f3c81d2ffad2e5")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "5560532f4cae67478c11adc65e632cfe3da10ad7")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/crc32c-native.lisp" :GIT-BLOB
   "2e80dc72cce0064a460b8ee78970acae71a9da35")
  (:PATH "src/foundation/crc32c-vops.lisp" :GIT-BLOB
   "0677d1d29c7fc16dbd8bda529cffa5f1076327a8")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "3dee5a43950d683f83deffaa6f329d6dcbc6cfc2")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "6fca7bd583990cf07093243c95f399d294b74d45")
  (:PATH "src/fulltext-admission/build.lisp" :GIT-BLOB
   "ba813f4178d646f412363e8b3f86f7309878a4a1")
  (:PATH "src/fulltext-admission/copy.lisp" :GIT-BLOB
   "43488c42525991544b355bfc061c2c753e866c88")
  (:PATH "src/fulltext-admission/guards.lisp" :GIT-BLOB
   "c4734194dc53a5f98397bd0b35079c5739f95a41")
  (:PATH "src/fulltext-admission/lifecycle.lisp" :GIT-BLOB
   "088b775f74cf633ecb3b84a0c0b9445209cc4b93")
  (:PATH "src/fulltext-admission/package.lisp" :GIT-BLOB
   "74d06aa6d0d0b263b806f678b23cec40b5db3ef1")
  (:PATH "src/fulltext-admission/preflight.lisp" :GIT-BLOB
   "eeff3e04503f0dac81da9816112f2da68e384dc2")
  (:PATH "src/fulltext-admission/query.lisp" :GIT-BLOB
   "a8aac3c938ada73cb2b18abfaf44d7bc1ff4cfa5")
  (:PATH "src/fulltext-admission/reserve.lisp" :GIT-BLOB
   "374c03ecf29417aad8e760dd432ff3e5a6383e4c")
  (:PATH "src/fulltext-admission/row-update.lisp" :GIT-BLOB
   "1d77f5d5c6e1ddb8ab08136d7d7afaf1f79a7f79")
  (:PATH "src/fulltext-admission/rows.lisp" :GIT-BLOB
   "f1c6dc8236477b5de6b2f0e5db4bab8a02fcbe95")
  (:PATH "src/fulltext-admission/types.lisp" :GIT-BLOB
   "b4766a5b561c1a1f3e53bfc9485f72b128dfb1d1")
  (:PATH "src/fulltext-put/append.lisp" :GIT-BLOB
   "df244937278aebfabba27f14555b36476e6d9858")
  (:PATH "src/fulltext-put/binding.lisp" :GIT-BLOB
   "c47d939287b3be63ec090d24bd64903556b2b86a")
  (:PATH "src/fulltext-put/build.lisp" :GIT-BLOB
   "1f4113fb6ce043099672cf72c995b976c9543cea")
  (:PATH "src/fulltext-put/package.lisp" :GIT-BLOB
   "0ffd3fb459d14ef6da0ab6789930b8ee54b78fe5")
  (:PATH "src/fulltext-put/physical-header.lisp" :GIT-BLOB
   "8fbb48b2ceb0ccb9c73b9344e14fbb025174b7e4")
  (:PATH "src/fulltext-put/physical.lisp" :GIT-BLOB
   "f7a1a29690b384cdd8bf791e62ac2d98deb7495b")
  (:PATH "src/fulltext-put/prepare.lisp" :GIT-BLOB
   "5a6929f64ba29f63efa2717a79fb79c93206b74c")
  (:PATH "src/fulltext-put/reserve.lisp" :GIT-BLOB
   "81642e379bb158bed9bec2f0fa9c70190a637567")
  (:PATH "src/fulltext-put/row-reference.lisp" :GIT-BLOB
   "b24f1dc1bd7ea08b7efe05e954cd30190f8a1aa1")
  (:PATH "src/fulltext-put/start.lisp" :GIT-BLOB
   "8c6677841d374a7bfc1834a83ccf610eecce0890")
  (:PATH "src/fulltext-put/types.lisp" :GIT-BLOB
   "c0bb31863f4f17894f85f69df42d5476d988f9da")
  (:PATH "src/fulltext/analysis-emit.lisp" :GIT-BLOB
   "17bcef98c46d7a035d2945be0c7407ed178e3da7")
  (:PATH "src/fulltext/analysis-nfc.lisp" :GIT-BLOB
   "e3e34d111a4cbab7a860d995e0658e154f1a4031")
  (:PATH "src/fulltext/analysis-package.lisp" :GIT-BLOB
   "5729cfba660c391cf9dee6fc3d5e6ccbddcd2552")
  (:PATH "src/fulltext/analysis-properties.lisp" :GIT-BLOB
   "320a03b22e01f755184d3d8b6aa1a61b009ce538")
  (:PATH "src/fulltext/analysis-space.lisp" :GIT-BLOB
   "7ab493596664f1488b369fc0b14b083e9eee31af")
  (:PATH "src/fulltext/analysis-word-context.lisp" :GIT-BLOB
   "023c1d7676f5f1325e7b112ba38a132a010f36e8")
  (:PATH "src/fulltext/analysis-word-rules.lisp" :GIT-BLOB
   "0278fccb36c8320d8b0b11b26e067773b8435e1a")
  (:PATH "src/fulltext/analysis.lisp" :GIT-BLOB
   "496c3196aa6efc23695486f15253f9275b58c1c6")
  (:PATH "src/fulltext/codec-input.lisp" :GIT-BLOB
   "ff8ede224c154fa075b7f1eb53cacecbcc7d73c3")
  (:PATH "src/fulltext/codec-package.lisp" :GIT-BLOB
   "fcd63be08134216e7a0d79c68ba6fc1120415689")
  (:PATH "src/fulltext/codec-plan.lisp" :GIT-BLOB
   "b614382a5beec3c0ccc3134f0e2abffc0fb44e87")
  (:PATH "src/fulltext/codec-query.lisp" :GIT-BLOB
   "1047b265bf2140ea5d14ea55987f1bdfae2f6e0c")
  (:PATH "src/fulltext/codec-read-base.lisp" :GIT-BLOB
   "5a24b81342a564255563e9309efcc9f043aa33a4")
  (:PATH "src/fulltext/codec-read-dict.lisp" :GIT-BLOB
   "5958a63148c0942343fa93fce59a59d614850bb2")
  (:PATH "src/fulltext/codec-read-lengths.lisp" :GIT-BLOB
   "91b77b0ef9cc16fb29c437130453ca97c19de60f")
  (:PATH "src/fulltext/codec-read-postings.lisp" :GIT-BLOB
   "46fc1a96ed8bd3e616392ac6c891a678b4e8f33a")
  (:PATH "src/fulltext/codec-read-term.lisp" :GIT-BLOB
   "bf77c4c7d7f7faeaa68077cc1dfbb8349ff6eeb7")
  (:PATH "src/fulltext/codec-run.lisp" :GIT-BLOB
   "fbe693aa1579466dc55fc03fe88a1bb04d7c097f")
  (:PATH "src/fulltext/codec-space.lisp" :GIT-BLOB
   "48e907be585f73c58fd7fa4e89a0b5cdfbfef309")
  (:PATH "src/fulltext/codec-view.lisp" :GIT-BLOB
   "49a4547d0153a45281e2bd2188891f2c5517523d")
  (:PATH "src/fulltext/codec-write-entries.lisp" :GIT-BLOB
   "035e0c6d0826d7be8e5308c3dbabf9f4b6b94b50")
  (:PATH "src/fulltext/codec-write.lisp" :GIT-BLOB
   "64731ed8f9fc9f1246a62c659b18fa85ae2a0f3e")
  (:PATH "src/fulltext/descriptor.lisp" :GIT-BLOB
   "d53475000e9a1f3f3ab97f29780b526b39c43e58")
  (:PATH "src/fulltext/document-analysis.lisp" :GIT-BLOB
   "5f4635b04bf39a7673c4071ac423f3c23b595c57")
  (:PATH "src/fulltext/document-bound.lisp" :GIT-BLOB
   "6eb42da6fa77f01a38b92559b1eccc32f1313d43")
  (:PATH "src/fulltext/document-config-input.lisp" :GIT-BLOB
   "f9522d52f03c808c9e31903ac6393ba113c487f0")
  (:PATH "src/fulltext/document-config.lisp" :GIT-BLOB
   "4d28290bec4b6bca2f8a79338323fa1e4b2ed617")
  (:PATH "src/fulltext/document-package.lisp" :GIT-BLOB
   "c699e405a2ce6c5a18cc27842352f8ad43647e4b")
  (:PATH "src/fulltext/document-paths.lisp" :GIT-BLOB
   "dc31d23d3316043885526af964aab860fe4a6f45")
  (:PATH "src/fulltext/document-scan.lisp" :GIT-BLOB
   "62df7660d399fe08ccb948a21fe6ceb0bbca507b")
  (:PATH "src/fulltext/document-space.lisp" :GIT-BLOB
   "ab484dddcbd81d464e8739e4aa28a1be667accc1")
  (:PATH "src/fulltext/document-start.lisp" :GIT-BLOB
   "d59279a55290ed8b35e722dd9ee47cef68502a1a")
  (:PATH "src/fulltext/document.lisp" :GIT-BLOB
   "447a0f0d27d1e197483f839e7a03d75bce92585d")
  (:PATH "src/fulltext/format-constants.lisp" :GIT-BLOB
   "cc040653f809c725a063eee35fff6e2f9570b675")
  (:PATH "src/fulltext/format-input.lisp" :GIT-BLOB
   "891ad11bf97386317a7a56d6e81c7d425745dfdb")
  (:PATH "src/fulltext/format-package.lisp" :GIT-BLOB
   "1f72e2d40467a20422c5bfaa2564bb5b84fedf29")
  (:PATH "src/fulltext/format-read.lisp" :GIT-BLOB
   "323807f0a973049dd290dd7dad4d2266301e6e57")
  (:PATH "src/fulltext/format-write.lisp" :GIT-BLOB
   "2b89b266d96de0264d92b164b4d59e4e27079f82")
  (:PATH "src/fulltext/index-build.lisp" :GIT-BLOB
   "54ae060c29f1345430a44b2b378c8cb43039dcdc")
  (:PATH "src/fulltext/index-lookup.lisp" :GIT-BLOB
   "9ef394661c96beef9e4cbf3f2e8e5812ec6828c6")
  (:PATH "src/fulltext/index-package.lisp" :GIT-BLOB
   "20bfb93adc06f0782e20fe842f4805b2249d440a")
  (:PATH "src/fulltext/index-sort.lisp" :GIT-BLOB
   "369d3de6ee0ecee94aadfe6ebbce619b84e8147b")
  (:PATH "src/fulltext/index-step.lisp" :GIT-BLOB
   "9206fd68138b97057494978f7713618063510654")
  (:PATH "src/fulltext/meta-fields.lisp" :GIT-BLOB
   "afaeeadd5831bac5804c57a9b67428a3e3c2eaa0")
  (:PATH "src/fulltext/meta-read.lisp" :GIT-BLOB
   "9a4f5a543e68b9c585126096feadaa754f10c6d7")
  (:PATH "src/fulltext/unicode-tables.lisp" :GIT-BLOB
   "a0b079ee4bfba2d1a6ca83b4bb9c555462b75b3c")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "4ebfa97211671287aa2c972a8923654c2390d0f9")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "8dcddeb0536c1104af92c722ffbfab2059601c74")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "a957b1f91e495637b700756736a96baafd233abe")
  (:PATH "src/get-directory/sources-read.lisp" :GIT-BLOB
   "fbb8b26fcfd9de939bf4f3c61d5fd0c5c335754c")
  (:PATH "src/get-directory/sources-types.lisp" :GIT-BLOB
   "ce426ea6409d588e0ca6add8e6c95a1c594e0c89")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "564cdaea8cb9aae672cbbd4328ea7e76b4430f4a")
  (:PATH "src/get-resolver/active-arena-read.lisp" :GIT-BLOB
   "b70b14e779d6c841bd52ca53a599822b77dcdc32")
  (:PATH "src/get-resolver/active-arena-write.lisp" :GIT-BLOB
   "2f893bf07fc9a7d36761a54cf2bbd03300d5a945")
  (:PATH "src/get-resolver/active-arena.lisp" :GIT-BLOB
   "8195220c0d648304d57dac090ab0da03f7812fe9")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "136d22104439f016932e90d45622553f070c1724")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "3a3dae662d06b1e2b6bc936b227894d2f0396b6d")
  (:PATH "src/get-resolver/active-init.lisp" :GIT-BLOB
   "89d45e100f395e65aeca93e7d317073cfb5ffdc3")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "93a32b00aef08a29b4ae7d638eaf16cc68a284ff")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "430b3ba6b063931e60c477a22ce3c50fa1898750")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "6e481f4d41ba4d20649978f806df1685b7afa8fb")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "9634424bab5ea2fe66d950f30e7d51b1baa3a395")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "d6854c7ec8b7125b33391a27760be11cd01c89db")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "33d7b898b5f5a7b20c8112484191c14df44b770e")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1a5479dc776fd56b3c6871dd2984a620bf43f991")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "b747d3a4b6517d7574225dc26cab8703747f0e05")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "c0f1a6b32a1725b6e9ae05e00e130a3e0097be78")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "7f2f8b496d65b70d83eee58c19b5b679b5d632ba")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "77b07c57b7e57505ff35724dc36a90cb554679ee")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "76ac8e35c01b887cec70ccd78d29d87690557eae")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "2a393aae53a7b13b567dc5a44b5d0d1da83714f3")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "01233e1565f301c96ce6ee3bb33a50f10cb2e937")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "7a3600dfe26168cc956e1ef62d07221a6d51a61f")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "fe1475f001e9b5719980f7e7507f735edc7e208a")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "4dd3840c525e54acc7d1577b45aadff217a77c4b")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "f1a5060bb6071bec929476a9151fba0ec68e1604")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "db2d060ad9f747deaa7f5016d09eb8ff0299d36e")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "9827cb4af0343e4241d2fed6e3c62830455f8749")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index-disk/api.lisp" :GIT-BLOB
   "daeaeeaef31f8cd903ad02f6cd60193611714643")
  (:PATH "src/index-disk/balance.lisp" :GIT-BLOB
   "c1189c5fcb2a3389004a0b2d19357c4f93e9e026")
  (:PATH "src/index-disk/build.lisp" :GIT-BLOB
   "85d0f397ea8062235c537806caa21fe03d790589")
  (:PATH "src/index-disk/cache.lisp" :GIT-BLOB
   "e61013c7d4d60aa0711024615dcdf42476c69ecb")
  (:PATH "src/index-disk/copy.lisp" :GIT-BLOB
   "b26cdc656f9112ab344983c5a7f473e97442c8e3")
  (:PATH "src/index-disk/mutate.lisp" :GIT-BLOB
   "ac7a72b3d506de92ec80bbb9653904188b98d8f8")
  (:PATH "src/index-disk/package.lisp" :GIT-BLOB
   "23536e507f5fee4b20554184835addebab23ba3e")
  (:PATH "src/index-disk/read.lisp" :GIT-BLOB
   "20599afde6adbb9cd9decdc852f0de469a5d72e5")
  (:PATH "src/index-disk/relocate.lisp" :GIT-BLOB
   "34399623c2c31e68c16d069f57d1b7e6b9bd4ab2")
  (:PATH "src/index-disk/types.lisp" :GIT-BLOB
   "df13ba528aa6bba71981c44b8fbf14c69fa4551e")
  (:PATH "src/index-disk/visit.lisp" :GIT-BLOB
   "ec8ae71e8f2d27b7e2a49cefbeb2c86e7367bbe2")
  (:PATH "src/index-disk/write.lisp" :GIT-BLOB
   "7b6e37218626e782f22cc2903328c40f23d52fac")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "64be10d7b2dc85c6dd6c31becefbb6ee3ae74d21")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "ec86f5be5b5d465d5e32dc3c492cbc0c90daaba5")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "6dc9775423900dd855c71c06079cdc5e69411c5b")
  (:PATH "src/index/image-codec.lisp" :GIT-BLOB
   "e3b96642767e7e0d116481f41e279274646c2b12")
  (:PATH "src/index/image-constants.lisp" :GIT-BLOB
   "6c123802b75884937c2e9bcd7cfe4e214173ab9e")
  (:PATH "src/index/image-publication.lisp" :GIT-BLOB
   "7733d528d07acc24ec9f8c00c6767c2e3b09975e")
  (:PATH "src/index/image-recovery.lisp" :GIT-BLOB
   "ea1a681932b0fa2a1a7a3f44238816657505e55c")
  (:PATH "src/index/image-seal.lisp" :GIT-BLOB
   "f788cc87a9f2f963210d5bb54310f359df78adba")
  (:PATH "src/index/image-types.lisp" :GIT-BLOB
   "69315a89f5b007ebfbb838bc87dde37221fa69c8")
  (:PATH "src/index/image-verify-edges.lisp" :GIT-BLOB
   "2bdfd22b88408ff57efe6dc6e8c61fb5bb4f2fa1")
  (:PATH "src/index/image-verify-entry.lisp" :GIT-BLOB
   "6d240011e6b3f2c8795537bdead86763cd5a0dd5")
  (:PATH "src/index/image-verify-key.lisp" :GIT-BLOB
   "c7bde57d3d327f32321c29d358cb84eb90f1eadc")
  (:PATH "src/index/image-verify-types.lisp" :GIT-BLOB
   "a7f39bfa563402bb113c3430c5229926c0354ff9")
  (:PATH "src/index/mode-package.lisp" :GIT-BLOB
   "53da3230da115c0d702cc762d3f2ab69e6af253e")
  (:PATH "src/index/mode-policy.lisp" :GIT-BLOB
   "2acdfd94b5a0e5bfc04135cf9f39b4a72ef93482")
  (:PATH "src/index/mode-types.lisp" :GIT-BLOB
   "9e42e46cfa22a400da7635e45ab7c8192e25204c")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/page-body.lisp" :GIT-BLOB
   "c4143fd0c6350883ff10db74c2f8b9c7320b7600")
  (:PATH "src/index/page-bucket.lisp" :GIT-BLOB
   "f6f9c5b2076c8f3c1ae9dd1c23bdab00cbd69005")
  (:PATH "src/index/page-build-config.lisp" :GIT-BLOB
   "8d34342f4e34d3edacf6edb07a3059b8cd199d62")
  (:PATH "src/index/page-build-emit.lisp" :GIT-BLOB
   "479818ed5d901eee9ecfee456e39b66d4f02c620")
  (:PATH "src/index/page-build-plan.lisp" :GIT-BLOB
   "86bf82eb3913ca8dad0f7e1dbe1e9016da5b18a9")
  (:PATH "src/index/page-build-proof.lisp" :GIT-BLOB
   "f86fd7f850a9f1559e9af7fdf445971e07020eff")
  (:PATH "src/index/page-build-types.lisp" :GIT-BLOB
   "4fb20f67faa960088aadf112246f84a98f58117a")
  (:PATH "src/index/page-build.lisp" :GIT-BLOB
   "b632710d7d32cac680b10a9312bd9c4878024fd0")
  (:PATH "src/index/page-cache-types.lisp" :GIT-BLOB
   "bbea574ced62361daf59b1d03fb6f06cdb840991")
  (:PATH "src/index/page-cache.lisp" :GIT-BLOB
   "e66d3fa17f78dde39eff02eb8993a7c68f9ba9f5")
  (:PATH "src/index/page-constants.lisp" :GIT-BLOB
   "de904d211f301a087b3d1d53fa47a8054ccf2eb7")
  (:PATH "src/index/page-lookup-key.lisp" :GIT-BLOB
   "9e2e8f43e9a787b7a9223d57dcbab979dbbc233e")
  (:PATH "src/index/page-lookup-types.lisp" :GIT-BLOB
   "9abfe5a3024425124a8e9cc3b0a7087ad5cad1ff")
  (:PATH "src/index/page-lookup.lisp" :GIT-BLOB
   "9dde416acf27111c21e3f439dd2c948d27517eb7")
  (:PATH "src/index/page-package.lisp" :GIT-BLOB
   "d3f1ff0b939b5a4a1e2df7f22fb04077886220ea")
  (:PATH "src/index/page-read.lisp" :GIT-BLOB
   "0386ec4059fbb6a01d34a137e5bf5a6f44a6f589")
  (:PATH "src/index/page-types.lisp" :GIT-BLOB
   "74a9db44b348db25a046c9250f092a0e03f82ca0")
  (:PATH "src/index/page-validation.lisp" :GIT-BLOB
   "a45eb2aa3d449c9500a95950709cb6019fb8f76b")
  (:PATH "src/index/page-write.lisp" :GIT-BLOB
   "6206be6610c55d48389763a3205ff80ebd79a6d8")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "27c03d2d3e8bfb6b93088bb55bd6e615350261d0")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "83fe7ca83cad1b84f41a579d56bb02ee0bac881e")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "86debb0798063a5e05be0a96f125dece7edd0f0a")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "5afb91ab551d915d29f6630573a17328839cc616")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "099d59bb9acc155380a3baaa3a10816e0902d8ca")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "d054587f29d5108d65704fe8b5b6794178923902")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "7cc651a3e3de17decfe71f3ee9b826dfa7b3ca2f")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "fde846254989ef432159c1ffcfc25fb3f950dbcc")
  (:PATH "src/index/primary-restore.lisp" :GIT-BLOB
   "252bd2cb57700c33fd4ec94749ea6f0b80ae6817")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "179de5b6f466cfcb72c719c49a0e885b5bcf6a12")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "621a82743aceafa1653340330e413bc902c58ebb")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "0187f4d9603d23a6ddb0a76d282af9c811080534")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "589e1557b2906a15c6c874f126968669206ceed9")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "bebb4f103854e0b3dbfc248cae5b82cdeafb0b57")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "ad43248f2f9ec4978a07df5bb696c49a1c055ea7")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "6a55454412edc8466e9c7972f9c81d9a3c945697")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "d42c883908d8a8c9c467342b8977498f38dcf33b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "83bec7e5e8d66f78d9b127c5310b2058b3c3fed6")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "ab3fd8e8abe4fd803038cf11e13c3fef75a8144b")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "0e8ca5847c6683a89cdd47e3476665b1bd46e6da")
  (:PATH "src/io/cpu-build.lisp" :GIT-BLOB
   "0dd046093289729dbc7817a3eeb7dff004f0e9fa")
  (:PATH "src/io/cpu-features.lisp" :GIT-BLOB
   "80653c6c8871127b3d76cc631d47ba0e711b6e5d")
  (:PATH "src/io/cpu-package.lisp" :GIT-BLOB
   "baf8aa6f2ef5231eb6462bca65d83ac1886d09e5")
  (:PATH "src/io/create-relative.lisp" :GIT-BLOB
   "eb4a8c292b30a3083cd256eda697b05737553022")
  (:PATH "src/io/derived-remove.lisp" :GIT-BLOB
   "a0631348bc17fc4e5c1638522be73ae87fa53a97")
  (:PATH "src/io/directory-lock.lisp" :GIT-BLOB
   "f0135b3b43625d9535db6196507b55154d36f852")
  (:PATH "src/io/directory.lisp" :GIT-BLOB
   "8b3fb30b5fa092a5f88ce55cbcf5ebfa6bddf993")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "9b04b83cf53f493aaf75d1c19a6d5f9f4ee0971f")
  (:PATH "src/io/identity-types.lisp" :GIT-BLOB
   "d53f8c4793af7e98dcab62ee5c94571dd8d520a2")
  (:PATH "src/io/identity.lisp" :GIT-BLOB
   "0cb49ca63800c1fc25bee5bf94c2811969511a07")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "9ea7d77f1bccbb7051123ac2e5793d38b770ffbf")
  (:PATH "src/io/namespace.lisp" :GIT-BLOB
   "1f73f6bf5c4b8f12064b515008d6c8f9076518ce")
  (:PATH "src/io/native-create-relative.lisp" :GIT-BLOB
   "9d715484a72332fb056b8102d2277140128b2f59")
  (:PATH "src/io/native-directory.lisp" :GIT-BLOB
   "95ea1018b8693a89e0967f9a7a6dea95542d6005")
  (:PATH "src/io/native-namespace.lisp" :GIT-BLOB
   "599c21713f3d82b6bc9faac71e42a45da0e6cd90")
  (:PATH "src/io/native-open-relative.lisp" :GIT-BLOB
   "d924a8a202ab02406cdae147cfa0cb742a0917e6")
  (:PATH "src/io/native-publish.lisp" :GIT-BLOB
   "d62f716c3965b838e0cdb7a629c78bdf845bbdc2")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "37f1e1782e0e3580447aa0ef56cb0942cfbd0e66")
  (:PATH "src/io/open-relative.lisp" :GIT-BLOB
   "e712b098ddbd883b77382c60b1b511427e8c4db7")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "c0be7a664e6642b7dcc6362d6194090fa9a8290e")
  (:PATH "src/io/publish.lisp" :GIT-BLOB
   "cb759a6c4c6d4b9300c1bb9e1e7b7d781f629f65")
  (:PATH "src/io/readiness.lisp" :GIT-BLOB
   "8ae8de38729e3866227360cc1cf6022c9220490b")
  (:PATH "src/io/rename.lisp" :GIT-BLOB
   "38a7d50880a012266e59eb915edafe64f2047e4e")
  (:PATH "src/io/segment-remove.lisp" :GIT-BLOB
   "8530ef67554d751b20d1004a9af49f20b8fc1861")
  (:PATH "src/io/stabilize-preflight.lisp" :GIT-BLOB
   "290915923be47b7739c3f44560a62f9819c7a26e")
  (:PATH "src/io/stabilize.lisp" :GIT-BLOB
   "504c9dca2fece31bc79f8788f7524d7397a1fee2")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "b66a02dbc2eda6d43388a0946ae46b795efb2a76")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "8e7b3506c6f1da4493bba4817d8b1f6c57585aaf")
  (:PATH "src/local/cli.lisp" :GIT-BLOB
   "801ea182eab95273f82e3b5687605dfbf31aef75")
  (:PATH "src/local/client.lisp" :GIT-BLOB
   "e7f09f4789f50fb79aeef0722c9461f0915cb084")
  (:PATH "src/local/dispatch.lisp" :GIT-BLOB
   "f461a82e35b1abe75601b8b73170401d9d522806")
  (:PATH "src/local/native.lisp" :GIT-BLOB
   "380f655e5da39eaff4daeef4c6eaf63217762a48")
  (:PATH "src/local/package.lisp" :GIT-BLOB
   "74489fef066b33ac706cb0dd8c757d440e0bfebf")
  (:PATH "src/local/readiness.lisp" :GIT-BLOB
   "bbc9fce59ab612aa4dd003d90a854506c7b047f1")
  (:PATH "src/local/server.lisp" :GIT-BLOB
   "aa2ff6565fa073d586f5a69ae949b9f0bc39f09d")
  (:PATH "src/local/state.lisp" :GIT-BLOB
   "e3b7dafaa7f4cbae331ffd2f43edc38ca636d7c9")
  (:PATH "src/local/wire.lisp" :GIT-BLOB
   "60a5c872e2da0baa0fee22fd4909b66342c2c387")
  (:PATH "src/local/write-group.lisp" :GIT-BLOB
   "196d2f1c7f00a460c6032a8562402e1bfe6f72a3")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "fdeac572e64c3591208a87872b8aa9d520c3bde7")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "74ebd63accc8216dfe5a1794c0e430bb9bccd29e")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "a05a5732511ffca3591110f617e3a19be819b47b")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "158b5a6d1eb171d07bd4f67addc2f4be5495d54b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "06a0af0e813b9c22ce98d523d42c031c79ca3734")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "95f5a8c59ff1fef05bcd3fd220d6a14d9c332d61")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "e5130ba55ee942238a5a98ecc51e07725e1c9655")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "2de7b390c89ab19f8be03767ecb07af8fe1e4fb1")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "172a43f86726ec68af730700c99098d66500ad66")
  (:PATH "src/recovery-active/build.lisp" :GIT-BLOB
   "0fa0e554f7e3aa6990d861dec7cbf8408db28068")
  (:PATH "src/recovery-active/closure.lisp" :GIT-BLOB
   "326b2070076e6e9a8d8ee66567d05b5c19329467")
  (:PATH "src/recovery-active/csn.lisp" :GIT-BLOB
   "42b1279ccd9910816bd8d0887b60bcfe9b6e252a")
  (:PATH "src/recovery-active/frames.lisp" :GIT-BLOB
   "3d01c07ff8118b92e5de7b31ca72b19db5ec72ff")
  (:PATH "src/recovery-active/package.lisp" :GIT-BLOB
   "474cd54f2a31f4ded95fd723b4170bee8addece4")
  (:PATH "src/recovery-active/publication.lisp" :GIT-BLOB
   "38542ec938fd3409d73d7531e90fc6474ef42fad")
  (:PATH "src/recovery-active/query.lisp" :GIT-BLOB
   "e2a5aea0f5a97670cc20a583ed312c89df1c7187")
  (:PATH "src/recovery-active/read.lisp" :GIT-BLOB
   "f801950d67755cd15804ef43f1461d435eda54a6")
  (:PATH "src/recovery-active/resolve.lisp" :GIT-BLOB
   "66f4ada585e085a8403d4cdbc9a3dfee31754bce")
  (:PATH "src/recovery-active/types.lisp" :GIT-BLOB
   "069ca4b815c98d82695dd7eb9337a83c5f35b98b")
  (:PATH "src/recovery-archive-csn/build.lisp" :GIT-BLOB
   "ea5a6abf3d6b0817cfa99db490e9e5df57cb200a")
  (:PATH "src/recovery-archive-csn/package.lisp" :GIT-BLOB
   "bacf4fc95e38a8d0416110c6b87b506d561a7e59")
  (:PATH "src/recovery-archive-csn/preflight.lisp" :GIT-BLOB
   "a7a20c65ba54da28dd88c941736fb374065d580f")
  (:PATH "src/recovery-archive-csn/query.lisp" :GIT-BLOB
   "28f8acd47abad20efb95ec0ea8bd765bfa10baff")
  (:PATH "src/recovery-archive-csn/series.lisp" :GIT-BLOB
   "f8eb49763d533cd34cdf05593d2416a63c5f1d0c")
  (:PATH "src/recovery-archive-csn/types.lisp" :GIT-BLOB
   "d30bb8cb36fd1c64a720073fd3f4b4921e507cad")
  (:PATH "src/recovery-archive/active.lisp" :GIT-BLOB
   "5eb16b6f93d24ac3c6f06af8ed3c005328b457a5")
  (:PATH "src/recovery-archive/build.lisp" :GIT-BLOB
   "81a581f63c21154b8a55f2f429ec28ee32a659b3")
  (:PATH "src/recovery-archive/package.lisp" :GIT-BLOB
   "82c707853b1a5b2b6d657e120c7e0ecb82404134")
  (:PATH "src/recovery-archive/query.lisp" :GIT-BLOB
   "8ae65f7a41d2b4a395d6e6a1829d334dfbe88878")
  (:PATH "src/recovery-archive/read.lisp" :GIT-BLOB
   "07ee8571028ca0ec5f754ec9f8478077650ee48d")
  (:PATH "src/recovery-archive/types.lisp" :GIT-BLOB
   "80d29b79c185d0007d0b0e4baa913ed18ec0524c")
  (:PATH "src/recovery-bootstrap/build.lisp" :GIT-BLOB
   "60d549030aa9d16b823fcb98398f14cd3786f73b")
  (:PATH "src/recovery-bootstrap/package.lisp" :GIT-BLOB
   "29ce39efa53a72cd766810b81a08c9a2f86afc91")
  (:PATH "src/recovery-bootstrap/preflight.lisp" :GIT-BLOB
   "601685cad9fd3829ea36672e86b94952f3fe4493")
  (:PATH "src/recovery-bootstrap/shape.lisp" :GIT-BLOB
   "56e6694b910c05854961e920deeb0da390d4a428")
  (:PATH "src/recovery-bootstrap/stabilize-preflight.lisp" :GIT-BLOB
   "5c05f4f7b52c72cce8f3a086a64c4d190e7de36e")
  (:PATH "src/recovery-bootstrap/stabilize-shape.lisp" :GIT-BLOB
   "649080985356be430b25c841c7d345e9d24cb543")
  (:PATH "src/recovery-bootstrap/stabilize.lisp" :GIT-BLOB
   "2ef2dda4858003135215d7d36f816f4929d214a3")
  (:PATH "src/recovery-checkpoint/build.lisp" :GIT-BLOB
   "c274d47f45d845a6e16049e2a573e8d9d76fbc3a")
  (:PATH "src/recovery-checkpoint/order.lisp" :GIT-BLOB
   "a265f08779f2abc94be058454cf75643c33272ca")
  (:PATH "src/recovery-checkpoint/package.lisp" :GIT-BLOB
   "7b191ecff3dbac6b5f690ad221c68b4762a9f0aa")
  (:PATH "src/recovery-checkpoint/preflight.lisp" :GIT-BLOB
   "61e245a5495de984a94fef573f88d11245e86b71")
  (:PATH "src/recovery-checkpoint/sections.lisp" :GIT-BLOB
   "eb05b6c58fe3131fbd597dff5655e4a476b55092")
  (:PATH "src/recovery-closed/build.lisp" :GIT-BLOB
   "bab6c80812e70ffb31a59f29ffaaa6f90678cea1")
  (:PATH "src/recovery-closed/csn-serie.lisp" :GIT-BLOB
   "078d9bbd66289b667c4273053f706a3a2af120e6")
  (:PATH "src/recovery-closed/csn.lisp" :GIT-BLOB
   "41144f854694ff9338e0067d2f59b3312119c5b2")
  (:PATH "src/recovery-closed/package.lisp" :GIT-BLOB
   "49ac245e2430e719b1d417b91b0ffcd53555e47d")
  (:PATH "src/recovery-closed/publication.lisp" :GIT-BLOB
   "fc512bece4fead39a0c75c943cc5d10bbfb810b4")
  (:PATH "src/recovery-closed/read.lisp" :GIT-BLOB
   "08bcf5a490ceba1ae7a94258f1c0bd9ca148cdaa")
  (:PATH "src/recovery-closed/resolve.lisp" :GIT-BLOB
   "2f107b18e7060dc54e902dbe0363d836285ace5f")
  (:PATH "src/recovery-closed/types.lisp" :GIT-BLOB
   "a403121cd1459db7eb753981a402152615541caa")
  (:PATH "src/recovery-closed/verify.lisp" :GIT-BLOB
   "bac75f2ed61947826ca194cf57f8d2feb003f7fc")
  (:PATH "src/recovery-replay/package.lisp" :GIT-BLOB
   "8639d959e29e9f36270a94831eace49f6535a863")
  (:PATH "src/recovery-replay/read.lisp" :GIT-BLOB
   "05eade0aed1e83cf2df5f5e2bab563d31c95081a")
  (:PATH "src/recovery-replay/resolve.lisp" :GIT-BLOB
   "85eb7133fe1463016604e6a6c9ca26dea7bb5633")
  (:PATH "src/recovery-replay/visit.lisp" :GIT-BLOB
   "0c94187caae5986c8481cf1a8e8bc060db2a7b53")
  (:PATH "src/recovery-selection/frame.lisp" :GIT-BLOB
   "101813cb3536365ac914f10e926f424dec18647e")
  (:PATH "src/recovery-selection/index-preflight.lisp" :GIT-BLOB
   "c3d336e63fbb2b5d972a314a86edd123f050aa7b")
  (:PATH "src/recovery-selection/index.lisp" :GIT-BLOB
   "b4b3488404b09fd1df4f351910043b333c1f355e")
  (:PATH "src/recovery-selection/key.lisp" :GIT-BLOB
   "f751a1ed921903353ab48e52e9fa24d374202ed1")
  (:PATH "src/recovery-selection/package.lisp" :GIT-BLOB
   "9dd583b4bf868183f7555b1e4f7c29f2a13c244c")
  (:PATH "src/recovery-selection/read.lisp" :GIT-BLOB
   "04903a7aa14fe3c332bad4255ff62f87d2e69b77")
  (:PATH "src/recovery-selection/select.lisp" :GIT-BLOB
   "dc4345cbad0fd4223eb50ed2d0ed6bcccb8ec709")
  (:PATH "src/recovery-selection/types.lisp" :GIT-BLOB
   "85930de29d2bc071ea7bbb8677d9aa0ac4e1310e")
  (:PATH "src/recovery-series/build.lisp" :GIT-BLOB
   "41324774ac594767e6931c141858270d2a2125ad")
  (:PATH "src/recovery-series/entry.lisp" :GIT-BLOB
   "a37b7c87eff82670540beb78aa78cb40fab88455")
  (:PATH "src/recovery-series/package.lisp" :GIT-BLOB
   "51f3d64796df1a2180cb977adb8a094e7c7fd94b")
  (:PATH "src/recovery-series/preflight.lisp" :GIT-BLOB
   "0daff10989f88386221d11ff4123384a67092075")
  (:PATH "src/recovery-series/read.lisp" :GIT-BLOB
   "d7ec011280d40883408a816425210f60f4ae4561")
  (:PATH "src/recovery-series/stabilize-preflight.lisp" :GIT-BLOB
   "4e6d9e8047e76ce2fa5324ebca9456d29bd69c2f")
  (:PATH "src/recovery-series/stabilize-set-preflight.lisp" :GIT-BLOB
   "81cc2dcf0e684ccc710e51b221b84c10f057db8f")
  (:PATH "src/recovery-series/stabilize-set.lisp" :GIT-BLOB
   "7fe9646c0721b02d48f8ee99cf3f2e5fa020d4c5")
  (:PATH "src/recovery-series/stabilize.lisp" :GIT-BLOB
   "1fe16c3863409635d882ebce5a9f5abc03ad5ecc")
  (:PATH "src/recovery-series/types.lisp" :GIT-BLOB
   "eb8d4a347b96aca4e5277435fe1361ed794f39b6")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "d7ac44761869f57e333497212510416fd1e794c9")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "58a3e620a8def39d2b24cd210d9283184c247ed2")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "b30dd16f31dcb00316d6983c7cfc5cb2948ce0ee")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "54b5092b76b1c609ee195c44bd9206c1800542c4")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "c7bd0b41e7a84ef73829aeaef3a113f12e7a6031")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "c2fab3b7b2cec568adfe88f0037fc216f83765c9")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "2059363677925a732eb1c70fc1ed1be94d715ea9")
  (:PATH "src/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "7b7f3c4c1bbcd252583249b650f82ab968409e24")
  (:PATH "src/recovery/inventory-directory.lisp" :GIT-BLOB
   "4f253cf7dbe6dad5814749ff53d40759ab882d73")
  (:PATH "src/recovery/inventory-id.lisp" :GIT-BLOB
   "c6dabcd733010fe6966aa1d27656b0760744e55d")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47bc32082a709eb46a5fdb5a5b3011d2c4377f80")
  (:PATH "src/recovery/inventory-sources-build.lisp" :GIT-BLOB
   "149e9ca5fc1bf3ed1f473beb075d5c35b6099886")
  (:PATH "src/recovery/inventory-sources-query.lisp" :GIT-BLOB
   "9742c023b3347d38f678c7a1752a9cc37b665996")
  (:PATH "src/recovery/inventory-sources-types.lisp" :GIT-BLOB
   "b52908d02b1cda451190be58333ef9c9508fddf9")
  (:PATH "src/recovery/inventory-sources.lisp" :GIT-BLOB
   "3619190b49dcbaa32ef4dd2111995df5beace5c5")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "1cbb826a8999579a98e51b9c0ecd1cd6a6ff9661")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "1a98289ea132f2b68309efb3a7552f99a514796e")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "801976598bd390814c4ddfaf00377ee38369405c")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "2ddd4fb6d4c1717a25c369c6a7252f9f80769221")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "9754b563a1d0fbfcda0f306e94b1b6d0257dfb0e")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "43af5d7e8cf2c8465492531133ea9647f614e613")
  (:PATH "src/recovery/manifest-transition.lisp" :GIT-BLOB
   "c871c345eb51367427adbb9bda778a6857a97510")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "40c49f4692e11b4c7f9f55b93bae69210adbdcbb")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "eb0e60664ad7abeefde7a4fc81fa7b3fa38ac57f")
  (:PATH "src/runtime/active.lisp" :GIT-BLOB
   "d7889b0103e18eb47878a88c760cae38de48b3fa")
  (:PATH "src/runtime/build.lisp" :GIT-BLOB
   "4fbf71ebd764f7d90977d027372437e113fdeed3")
  (:PATH "src/runtime/closed-preflight.lisp" :GIT-BLOB
   "5e10ae83ae0e4cd3adbbdae389629a0a854182a2")
  (:PATH "src/runtime/closed-transfer.lisp" :GIT-BLOB
   "3db2e73c10bf24d3931cbf993f240aac45e88e0f")
  (:PATH "src/runtime/closed.lisp" :GIT-BLOB
   "b06f0ae33a9c084c5101cfa5170e358bd4f7fe55")
  (:PATH "src/runtime/package.lisp" :GIT-BLOB
   "5eb61dac53e09bdaf493680967ab65938b6b8f63")
  (:PATH "src/runtime/preflight.lisp" :GIT-BLOB
   "7babef89ceacca9a7c8fac7068b54f653a4a3c58")
  (:PATH "src/runtime/query.lisp" :GIT-BLOB
   "34a7a4ebe5d0baeb93acca991f02a38b0cad2204")
  (:PATH "src/runtime/types.lisp" :GIT-BLOB
   "19fe3cc6004382550ea7939c5bf100d1fcc92607")
  (:PATH "src/scheduler/build.lisp" :GIT-BLOB
   "a55b8e7089ba3880ffa69cee4adb13dc0543069c")
  (:PATH "src/scheduler/lifecycle-build.lisp" :GIT-BLOB
   "7dfa330d606ef9c4dbceeb83845a32e75eb62fe6")
  (:PATH "src/scheduler/lifecycle-read.lisp" :GIT-BLOB
   "3b7ece551dae47957d9350c49285617d60b6ee3f")
  (:PATH "src/scheduler/lifecycle-types.lisp" :GIT-BLOB
   "5a03c1176d6bc019bcd230b0fd665cc48d555395")
  (:PATH "src/scheduler/lifecycle-update.lisp" :GIT-BLOB
   "47d323541ba45f5fb507ebcdb2eae9dd701533a2")
  (:PATH "src/scheduler/lifecycle-worker.lisp" :GIT-BLOB
   "8ae274af549a3464fd5f03d64e3c10ac73145630")
  (:PATH "src/scheduler/package.lisp" :GIT-BLOB
   "cadff5f2e29e7c5b625b95f9387faf29aad02178")
  (:PATH "src/scheduler/policy.lisp" :GIT-BLOB
   "37ed8717cf05ca8f03c06204641f47af18858a7b")
  (:PATH "src/scheduler/pool-claim.lisp" :GIT-BLOB
   "9ba00e2b77cbca2189e947e00b435fb81145668e")
  (:PATH "src/scheduler/read.lisp" :GIT-BLOB
   "ea882e41d231cc0dbafc9eac66bdd1f935433f00")
  (:PATH "src/scheduler/types.lisp" :GIT-BLOB
   "6fcd3d494dc339f8061a64fcce4133b9c86708b3")
  (:PATH "src/scheduler/update.lisp" :GIT-BLOB
   "eb0ad7a3abf119d733ae571d98695980ca4fe694")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "b1aeaa0032d7418cd3c9a7dcbc35add751fb17ce")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "5b189fb0ff0e54abaf72adcb05e5da58ebecb741")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "f81c0946f3e173fa6bf87c24e7c51999afc46363")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "6fd26253982dba01e9eef2702c5f4ede6ba70659")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "95cf61b5df1cdd57975f64a05f890528568046b1")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "79cc08666f83630adba9cab148bb71c2f6d46253")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "f21cae5c4f5cfd94d5d4b6a437ac2ede15750b5d")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "4d09a75d977a0eed0819e7c7d61737d245514b00")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "dee5f67f723edb5ba47b78e68baeee49eb56015c")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "18a29843546af6fc28fa36742a175fc3e6f19e1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "3b6335d3c665f5fe66771242c4d43db3de10b333")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "16700994fa5959633b21d4c7eb21483cd489f0c4")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "2a15783bbd1f5fdd1adb0ae4a045449970f46650")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "d7c667389bf8ad8ec4a04ce2b1bc9ec90e64a54d")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "fd552f6657ade1482eeada765c0880b6afe8a73f")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "6643873870526ee603a5c5b554a91650e5be0e6f")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "028c7b1111e43c0749479067451894b38479a7ec")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "10af1f2b835f387f7c5c69011b712c37bce142f9")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0548df3e81bff3332c67897fc70d7aece4c822ea")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "0e6f1849a77fd2de1109e3576f174f13e2eca665")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "05cb8e127c9384da1c40d21c7566f5d57b705ecf")
  (:PATH "src/verify/order.lisp" :GIT-BLOB
   "d563554aeaddb02585f4e4ad03b739dea5387669")
  (:PATH "src/verify/package.lisp" :GIT-BLOB
   "c98aae86e4bbd9642c2d5481503bf944c88e7811")
  (:PATH "src/verify/read.lisp" :GIT-BLOB
   "913463f4e6529cda367092c7aefe85e8471416c7")
  (:PATH "src/verify/report.lisp" :GIT-BLOB
   "5771c02a6384a61711735571ee64e219bdbc145c")
  (:PATH "src/verify/resources.lisp" :GIT-BLOB
   "48232232f028b479a5839420a42253416f7edffe")
  (:PATH "src/verify/types.lisp" :GIT-BLOB
   "ed2a9617dce5a03c691bc2826a5996f8a3161e2a")
  (:PATH "src/wal/append.lisp" :GIT-BLOB
   "769b86afb5de6d2f706a015e049ea04b63031f79")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "65b17519d6d6e5d9e104bc37b2c4eb4d3b93f132")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "51110c6784e99fc94ddf5a2344e0d85262c297d5")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "ae53e978652629ff407be47d3abe04176626dbb4")
  (:PATH "src/wal/frame.lisp" :GIT-BLOB
   "2f2f1af60a399d9263f15ce4565502da1c70f173")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "17858cffba82609484a6f4a32d082d14ceec1c4b")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "e0ea179069a7b297c7c26f6c294c7d4aea3db671")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "d9f682a05cf5adb22850728a839228f02744c5f2")
  (:PATH "tests/cache/README.md" :GIT-BLOB
   "3836e59b86c5a731e772fbf0a6cca376b14806af")
  (:PATH "tests/cache/guards.lisp" :GIT-BLOB
   "af881fd91c3820ab19d1daa2d56f1fe57257d08f")
  (:PATH "tests/cache/support.lisp" :GIT-BLOB
   "fd829e7352ba878e73df30d979e9558ff6ccba14")
  (:PATH "tests/cache/threads.lisp" :GIT-BLOB
   "ca03c59f0fada09cae8c452fed6490de32d4a3a6")
  (:PATH "tests/ci-catalog.lisp" :GIT-BLOB
   "f99940cde88fc16095679156dd2ca561edab453c")
  (:PATH "tests/codec/cbor-array-write-support.lisp" :GIT-BLOB
   "2a47078354c45a5775f48f6dd8f5d784da7de202")
  (:PATH "tests/codec/cbor-array-write-threads.lisp" :GIT-BLOB
   "43bac6c9604140af2594d85b76c14c3101b6925b")
  (:PATH "tests/codec/cbor-array-write.lisp" :GIT-BLOB
   "b13f58264f3cd97e1947ee52936732a7fcebe672")
  (:PATH "tests/codec/cbor-float-write-support.lisp" :GIT-BLOB
   "5416b62340ae8f3332915f8891529d95549a5fba")
  (:PATH "tests/codec/cbor-float-write-threads.lisp" :GIT-BLOB
   "3b0840150945cd4f118516b1d6d61524fa6856fa")
  (:PATH "tests/codec/cbor-float-write.lisp" :GIT-BLOB
   "747cd8a72445a3ea638cd1910bc9faa63f4cdc33")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-item-read-support.lisp" :GIT-BLOB
   "0326100362a1c4b24d2c7e511e45357f09a56d33")
  (:PATH "tests/codec/cbor-item-read-threads.lisp" :GIT-BLOB
   "a0da65545ed80ede0a967cadbb337731f6fe1ce9")
  (:PATH "tests/codec/cbor-item-read.lisp" :GIT-BLOB
   "b2cbdcb4255c51d9da4fe73b28939c1cb923fefe")
  (:PATH "tests/codec/cbor-map-write-support.lisp" :GIT-BLOB
   "113bfc4529199f69dea1862baec0aa7403c6fa97")
  (:PATH "tests/codec/cbor-map-write-threads.lisp" :GIT-BLOB
   "892d30fd1c7a8f12430c6caa6f43ee872574eb09")
  (:PATH "tests/codec/cbor-map-write.lisp" :GIT-BLOB
   "6ad0e9b5a48ba9c32c46d720f2f7f1821368d6c8")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "532c3f1d5898083364f17f9fc9cbf0da7b798bda")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "d88b573a98689b5e1c0cbade8f8a7ac69470554f")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "0989d7f8e43ec7213df856b842b1e9149df96d9f")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "186f1772335ce33e4e3d1d933bf4d4e91fe0763f")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-read-support.lisp" :GIT-BLOB
   "cfd55cd47d782673113e67af625c1360195a345c")
  (:PATH "tests/codec/cbor-string-read-threads.lisp" :GIT-BLOB
   "c3686d6e47ad56e53db556747ee2d49cea527df5")
  (:PATH "tests/codec/cbor-string-read.lisp" :GIT-BLOB
   "8437bdcaa4cf308dbf4614e748cdab4be2ae6d62")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "66b5d03695f522cca8013ccdad3ede690cc63412")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "16cc32f2c51d28f75a64b93ead642340f88e9c05")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "595d51a96ee3767c13797910ea324061a4788617")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-tag-write-support.lisp" :GIT-BLOB
   "e6e1e91e5ed95019e20b11d2dc0e408911acb46e")
  (:PATH "tests/codec/cbor-tag-write-threads.lisp" :GIT-BLOB
   "1c731f7ed83f703e3d2a8a4c57e6c702ef127887")
  (:PATH "tests/codec/cbor-tag-write.lisp" :GIT-BLOB
   "df97950ec8d24157bb6566c7995262f7beea7742")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "0f66cc1f8b493598d436b1d62d7211f4196fb430")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "7717054be474eba254f3f645fc62ec4ef65a511c")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "0c1a6d9fbe44a95b951a7e1a9aad90f65cef961b")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/control/native.lisp" :GIT-BLOB
   "2107cb66de45ded987c7fb1392155ff6afebbed6")
  (:PATH "tests/control/publication.lisp" :GIT-BLOB
   "f987c9317990ce977ecadb747268b39d2612eba1")
  (:PATH "tests/control/recovery-guards.lisp" :GIT-BLOB
   "b2e877dfcc35468cfafd95f398f33d1415692c1f")
  (:PATH "tests/control/recovery-publication.lisp" :GIT-BLOB
   "cd99169af8aecf204ce9cd2e6e1f2a9fbb081f68")
  (:PATH "tests/control/recovery-read.lisp" :GIT-BLOB
   "21f33af3220a237d7a8dc2ff3a98bfd4c41fa201")
  (:PATH "tests/control/support.lisp" :GIT-BLOB
   "053d81269526d2e7c78181fbe2f8e58ac3f878f3")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/engine/active-arena.lisp" :GIT-BLOB
   "bc3374fac887f4d210b7f3ed661ee38cb22f402e")
  (:PATH "tests/engine/compaction.lisp" :GIT-BLOB
   "4e46ba4400a7af10db08d35e191be80204237234")
  (:PATH "tests/engine/delta-location.lisp" :GIT-BLOB
   "3ab2c0e5c6d45ed746de955c72192327c525c71c")
  (:PATH "tests/engine/delta.lisp" :GIT-BLOB
   "5160313851bdfa637e80b76095679b9e965f22a7")
  (:PATH "tests/engine/group-append.lisp" :GIT-BLOB
   "39881bdf066184487a19e1d82c3cf834e731257d")
  (:PATH "tests/engine/image-activation.lisp" :GIT-BLOB
   "bb8b9470cae4854efd1336bc5a289d7305faed54")
  (:PATH "tests/engine/image-auto.lisp" :GIT-BLOB
   "19215e89154e8f65ba0e83e21b04d3d069c93a69")
  (:PATH "tests/engine/image-build.lisp" :GIT-BLOB
   "8543c508064d8198957a25f93e6da3c343d6c26a")
  (:PATH "tests/engine/image-discovery.lisp" :GIT-BLOB
   "50891fbd9ded0ece20969b466f24f1f591bd1439")
  (:PATH "tests/engine/image-maintenance.lisp" :GIT-BLOB
   "3b28dcea4388823fe8999b1fd67edb7a0da5343d")
  (:PATH "tests/engine/image-renewal.lisp" :GIT-BLOB
   "01e55612ec38f31fe281c0f1707bf1aa50aa1345")
  (:PATH "tests/engine/images.lisp" :GIT-BLOB
   "7ea979d2249807380c4532acc52e2ad299dcc0ad")
  (:PATH "tests/engine/index-auto-disk.lisp" :GIT-BLOB
   "57efb3be2095d695461717b131b95f2b6c1131f7")
  (:PATH "tests/engine/index-automatic.lisp" :GIT-BLOB
   "d2f9514760932005ab95e12f037606cf0dd94fde")
  (:PATH "tests/engine/lifecycle.lisp" :GIT-BLOB
   "55f8a525a7fb68846724b869d15eee8238924fe3")
  (:PATH "tests/engine/processes.lisp" :GIT-BLOB
   "ec6545a30fd1d4405ceb31c6c05b1c0ceb999711")
  (:PATH "tests/engine/record-cache.lisp" :GIT-BLOB
   "7dc3029e1048aedb7aab3bfb2649a69731e01734")
  (:PATH "tests/engine/rotation.lisp" :GIT-BLOB
   "f0de9a0e81ab82a161ba5e19a0706aae803e63e5")
  (:PATH "tests/engine/support.lisp" :GIT-BLOB
   "4f050bd297add4aff17a15bb24b3f499785018fd")
  (:PATH "tests/engine/write-group.lisp" :GIT-BLOB
   "debeeb853848ef25d28ce1293b2af3648b4b02dc")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "b1e71783b65b85e6253f733098c3153d41c4971c")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ca77be5b92c1cec98860dd5f59b278e9dcaf8ae4")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/fulltext/admission-concurrency.lisp" :GIT-BLOB
   "fbc2b0294a9369c4812bf206f001399be2af0ff3")
  (:PATH "tests/fulltext/admission-guards.lisp" :GIT-BLOB
   "b3475774a8a7f31269ea0e1b33bb659e230f67c7")
  (:PATH "tests/fulltext/admission-lifecycle.lisp" :GIT-BLOB
   "175c3e3bd33b163bc7593066ade68eb426e8e757")
  (:PATH "tests/fulltext/admission-resources.lisp" :GIT-BLOB
   "29ac6bf4b0b392579997b79c10142b2f491a5eb7")
  (:PATH "tests/fulltext/admission-rows-support.lisp" :GIT-BLOB
   "1713cd556e5e37525af25a15b4f5b36474967d88")
  (:PATH "tests/fulltext/admission-rows.lisp" :GIT-BLOB
   "6e2d6c65c8046ad7dee030a4e95330f3ce3993dd")
  (:PATH "tests/fulltext/admission-support.lisp" :GIT-BLOB
   "1eaef196dc555b086cd53584731041bfb97cda59")
  (:PATH "tests/fulltext/admission.lisp" :GIT-BLOB
   "74ed0e49ce0c839cb5e74d854704d21cb8dbbf68")
  (:PATH "tests/fulltext/allocation-threads.lisp" :GIT-BLOB
   "870a308baeed93e1aabb6dc9a88db443592439c0")
  (:PATH "tests/fulltext/analysis-conformance.lisp" :GIT-BLOB
   "ad704e6457ad7873b3eb2feea241da5129962c8f")
  (:PATH "tests/fulltext/analysis-support.lisp" :GIT-BLOB
   "805f7e60fd3f6aa25b4c53680e5251188e57868e")
  (:PATH "tests/fulltext/analysis.lisp" :GIT-BLOB
   "4d529aef551bd365f0c12eb3dffbb7b2960fae56")
  (:PATH "tests/fulltext/codec-corruption.lisp" :GIT-BLOB
   "c62dd05be34d1f653eed8565cc0b40b950bdb97f")
  (:PATH "tests/fulltext/codec-differential.lisp" :GIT-BLOB
   "91b651930dd7f9da36fd317453686d272e0d2c40")
  (:PATH "tests/fulltext/codec-guards.lisp" :GIT-BLOB
   "9f6b8e823ae25c43b767141e0193b908ca0e763a")
  (:PATH "tests/fulltext/codec-support.lisp" :GIT-BLOB
   "890e176db757eed9e2680f5b247a12922709d4b9")
  (:PATH "tests/fulltext/codec.lisp" :GIT-BLOB
   "50b924b1c0e9127da33413f1100bf04ef2ee500d")
  (:PATH "tests/fulltext/document-differential.lisp" :GIT-BLOB
   "78466a8bc1213d0794155535eb28a990a45a38aa")
  (:PATH "tests/fulltext/document-guards.lisp" :GIT-BLOB
   "608f322bd4ac149abb9ffbb352595b5c94d3d217")
  (:PATH "tests/fulltext/document-support.lisp" :GIT-BLOB
   "57d59f345c6cbe8dba253acce7993409b5bbed94")
  (:PATH "tests/fulltext/document.lisp" :GIT-BLOB
   "ab305e31ece6bf7fd20ac5b7ea119b01c57e7c92")
  (:PATH "tests/fulltext/format-guards.lisp" :GIT-BLOB
   "9a23048572dfa5eee314221ced3425a1ea46c28a")
  (:PATH "tests/fulltext/format-support.lisp" :GIT-BLOB
   "d03bd892800d593a3550bdc709d43c357041bfab")
  (:PATH "tests/fulltext/format-threads.lisp" :GIT-BLOB
   "b8e8eb4491b59c721071396ce656eb09186f988d")
  (:PATH "tests/fulltext/format.lisp" :GIT-BLOB
   "b7cb19b82d4e50d457c603b8708693adf27785f0")
  (:PATH "tests/fulltext/index.lisp" :GIT-BLOB
   "0673c32fe456a9cb77cf4aa5cc4e071a888cccf2")
  (:PATH "tests/fulltext/minimum-v2.hex" :GIT-BLOB
   "c4db496b0e5b920665d1c80bea204f6227da1f0e")
  (:PATH "tests/fulltext/put-concurrency.lisp" :GIT-BLOB
   "613b2e5a89d505701583aa9c68e6273f4163d2e7")
  (:PATH "tests/fulltext/put-guards.lisp" :GIT-BLOB
   "6b531c1b143860a46e84d5c77da982f54fbd413b")
  (:PATH "tests/fulltext/put-lifecycle.lisp" :GIT-BLOB
   "8cba90b629299c8494194a73ef8b819f554ca557")
  (:PATH "tests/fulltext/put-physical-guards.lisp" :GIT-BLOB
   "bd293d0ef1d5596e85859cb85e41639b3a0fd70e")
  (:PATH "tests/fulltext/put-physical-native.lisp" :GIT-BLOB
   "635118c4287ab13b4b98e34d04dc307b97497827")
  (:PATH "tests/fulltext/put-physical-support.lisp" :GIT-BLOB
   "1e81cc2af12f24515debc953d4f7884b07a2e197")
  (:PATH "tests/fulltext/put-physical.lisp" :GIT-BLOB
   "f8d1fa41090aaa40c2146ec9280bff08d968fdce")
  (:PATH "tests/fulltext/put-rows.lisp" :GIT-BLOB
   "0ee39c61cdbb6742eb36d65677030d44c96ad98e")
  (:PATH "tests/fulltext/put-support.lisp" :GIT-BLOB
   "2a3c9b543587b1a9c5402a16f82cfc1c671a6160")
  (:PATH "tests/fulltext/put.lisp" :GIT-BLOB
   "83f9503ec4bd1a6610443bb8eea991e6069c6565")
  (:PATH "tests/get-active/append.lisp" :GIT-BLOB
   "0779a03e322f321a930393c5667e11252b84eff5")
  (:PATH "tests/get-active/construction.lisp" :GIT-BLOB
   "ec2831edef2e452597ce867b026eb73c84fc5214")
  (:PATH "tests/get-active/directory.lisp" :GIT-BLOB
   "48c9a60e58536170a610844e853eae6f91beeff1")
  (:PATH "tests/get-active/preflight.lisp" :GIT-BLOB
   "7f41c04257e0bab10a2ffbc091b02d660029c4df")
  (:PATH "tests/get-active/read.lisp" :GIT-BLOB
   "0ab8c2b2b639a51b0217876a896d9468f41e22de")
  (:PATH "tests/get-active/support.lisp" :GIT-BLOB
   "b0a6f9bda4866f82471ec73120182caa786f7d11")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "ced6f8b39836c1c2ff264822ddaf05d0653bfff6")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/lifetime-support.lisp" :GIT-BLOB
   "cd514970e84f8654318dcc23a6b1ef24323be8a9")
  (:PATH "tests/get-directory/lifetime.lisp" :GIT-BLOB
   "c57261d2de469318402d5bf79f5ab5d27108bb46")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/series-read.lisp" :GIT-BLOB
   "b500bb83170622b6d96edbd363ebc85240064c18")
  (:PATH "tests/get-directory/series-support.lisp" :GIT-BLOB
   "ead990e110b588bb4df35ea17d3816db3b79cee5")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "a5b09ee5120bedc4e946366239dd5e6c978b27d2")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "9e03608bef23c0aa5a69dce8c7dfd09ed818a377")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get-resolver/construction.lisp" :GIT-BLOB
   "322c63ee6576304ca1ab19e28b902b680bc2acae")
  (:PATH "tests/get-resolver/read.lisp" :GIT-BLOB
   "a1788d1aab3f76b9dc29095676ec42f3a1f936a8")
  (:PATH "tests/get-resolver/sort.lisp" :GIT-BLOB
   "442ce9eef4fac8f593a9d94ed08a76b830773563")
  (:PATH "tests/get-resolver/support.lisp" :GIT-BLOB
   "11d5cf0efe8ee4f5606707cc7eca175442a50190")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/image-processes.lisp" :GIT-BLOB
   "11c9ba829c73bb71f54be52710ac699b40b47f60")
  (:PATH "tests/index/image-tests.lisp" :GIT-BLOB
   "3ea1eb66179db5125b2b5137372c70c9d953e95f")
  (:PATH "tests/index/mode-policy.lisp" :GIT-BLOB
   "4513fb320a9f1ced973820d8a9c58ee9a0d73ea6")
  (:PATH "tests/index/mode-support.lisp" :GIT-BLOB
   "14d4c82bd54795844d14ac1d7f1b7ced320c4233")
  (:PATH "tests/index/page-build.lisp" :GIT-BLOB
   "bd600c74e28d32328559e9b9f268b4afa3481a55")
  (:PATH "tests/index/page-cache.lisp" :GIT-BLOB
   "aaace9b80ff3c6ce2ab52a3644be8c56eef4ebfd")
  (:PATH "tests/index/page-chains.lisp" :GIT-BLOB
   "265a85cd6aff51dd8a5ceae50f60ff7b8d63660e")
  (:PATH "tests/index/page-corruption.lisp" :GIT-BLOB
   "880775f39ed5c6352c0ae448b7a830ea63b03a85")
  (:PATH "tests/index/page-fixtures.lisp" :GIT-BLOB
   "0ed84fd77dc21375773651e4bb42e56a2c0a5e43")
  (:PATH "tests/index/page-lookup-support.lisp" :GIT-BLOB
   "8800a152c6f0eefa572fda9e17ee9e5e1ff77023")
  (:PATH "tests/index/page-lookup.lisp" :GIT-BLOB
   "290b471927fc1647a000099d8f3f8b57b878c843")
  (:PATH "tests/index/page-support.lisp" :GIT-BLOB
   "920c631d2763260aec7bcb02d3172d8be1d4b21f")
  (:PATH "tests/index/page-tests.lisp" :GIT-BLOB
   "a18f0315e5480a356504f1f541bffc1ad3484fc6")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "d21142f34f3687c35f39c86d962f2c8ffd52c330")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/create-relative-native.lisp" :GIT-BLOB
   "fd5e819e2197869a93259857aacfa68bfe9e9a44")
  (:PATH "tests/io/create-relative-support.lisp" :GIT-BLOB
   "8382ffb8f04b6d2fc3e4adb89f995c9c37b0e445")
  (:PATH "tests/io/create-relative.lisp" :GIT-BLOB
   "7fb4c3665ca1b8f6de2dedd2827cfc150dcddf02")
  (:PATH "tests/io/directory-lock.lisp" :GIT-BLOB
   "4cefd15616f4ac2312a669b1242929d2706eb540")
  (:PATH "tests/io/flush-failure.lisp" :GIT-BLOB
   "76a80588d99b441e8c57a97f9a10d4d9d6c7b59b")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/open-relative-native.lisp" :GIT-BLOB
   "cdb197bf2760de70e7ec49af76e2954a18006997")
  (:PATH "tests/io/open-relative-support.lisp" :GIT-BLOB
   "4256567b2a10423a41540298317c8ef80e6b5af0")
  (:PATH "tests/io/open-relative.lisp" :GIT-BLOB
   "4bec9451a13db1437e081bda2858d4cb8b1e5de1")
  (:PATH "tests/io/readiness.lisp" :GIT-BLOB
   "1a7ce2205d7278a080395a3f4287540e11d3bea4")
  (:PATH "tests/io/rename-native.lisp" :GIT-BLOB
   "99f79041529d20d0ea774b01e3ed82fc5a274cdd")
  (:PATH "tests/io/rename.lisp" :GIT-BLOB
   "e83443eec6187d53118795c4f6ee797112f27ea2")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer-failure.lisp" :GIT-BLOB
   "c87c80fb9c82062bf4d4179d67f710ff10b4f051")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/local/native.lisp" :GIT-BLOB
   "b8891b57aa6229995b7c6ee5581d9cde650e3c93")
  (:PATH "tests/local/processes.lisp" :GIT-BLOB
   "937434fd8d56bd4e4a1961d7ee17d8673c4acbb9")
  (:PATH "tests/local/server.lisp" :GIT-BLOB
   "049822aa7abc1acf525920011be267d49320a0cf")
  (:PATH "tests/local/wire.lisp" :GIT-BLOB
   "349d7df061b5871658ad3fa6a14601bd58f1fa2c")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery-active-checkpoint/guards.lisp" :GIT-BLOB
   "cae7d70c2a5598bb5c3e1256ef4bb8b391656f6f")
  (:PATH "tests/recovery-active-checkpoint/publication.lisp" :GIT-BLOB
   "a996bc5f82f16fe12a74d9bee5962f8d8629f53a")
  (:PATH "tests/recovery-active-checkpoint/semantics.lisp" :GIT-BLOB
   "a4b80a1a678cdc4537ee9d989f178124829e70cb")
  (:PATH "tests/recovery-active-checkpoint/support.lisp" :GIT-BLOB
   "998ab160b939c93797fc90206a9b50f2cf55e452")
  (:PATH "tests/recovery-active/publication.lisp" :GIT-BLOB
   "8a3c4ba88dd7010c65a464d231ebdab2c8c27e67")
  (:PATH "tests/recovery-active/read.lisp" :GIT-BLOB
   "63f52ee0e0ab244ed278562a5d7fbc752b7617e7")
  (:PATH "tests/recovery-active/semantics.lisp" :GIT-BLOB
   "1d3c935a1169904c900461b67adb96f4dfd96b94")
  (:PATH "tests/recovery-active/support.lisp" :GIT-BLOB
   "5ebf9d06ae855b07875aadc10e2a8ac01ba56036")
  (:PATH "tests/recovery-archive-csn/guards.lisp" :GIT-BLOB
   "a6d91274479da64fa689ca370ff495cc96ae0e51")
  (:PATH "tests/recovery-archive-csn/native.lisp" :GIT-BLOB
   "d66af858c855e39c984f1ff8534e6de3c7c7fc88")
  (:PATH "tests/recovery-archive-csn/plan.lisp" :GIT-BLOB
   "b740c77023c500208ff742e02c4d5aebcd44db70")
  (:PATH "tests/recovery-archive-csn/set.lisp" :GIT-BLOB
   "d163bf160241d2225ac3282c1d925aa65e249ab3")
  (:PATH "tests/recovery-archive-csn/support.lisp" :GIT-BLOB
   "0c458a3f6f8aa062c2cc8831834c29159e09762d")
  (:PATH "tests/recovery-archive/active.lisp" :GIT-BLOB
   "ccbaaa3294880905584ad42c0601201fa3a3dc36")
  (:PATH "tests/recovery-archive/guards.lisp" :GIT-BLOB
   "8afea2a3df30099c07badd7d9c0bcf627a5f9a9d")
  (:PATH "tests/recovery-archive/native.lisp" :GIT-BLOB
   "ae8df9ced72f9142ade184ec78bdc576e05593e1")
  (:PATH "tests/recovery-archive/query.lisp" :GIT-BLOB
   "b0a56949ec13ec7c80466ac8b3cecc79c0fc6d63")
  (:PATH "tests/recovery-archive/read.lisp" :GIT-BLOB
   "22d1042700435e2c15e3f610f9ada9c4a8d8d4ed")
  (:PATH "tests/recovery-archive/support.lisp" :GIT-BLOB
   "0cbefaed0f74c8e34e4cea9a359c58f9196f22ad")
  (:PATH "tests/recovery-closed/csn.lisp" :GIT-BLOB
   "754611c3818a0aac26b189392d4024a251439d0c")
  (:PATH "tests/recovery-closed/guards.lisp" :GIT-BLOB
   "344857641ef2206d4d5a800fbb93b834a9f13c4d")
  (:PATH "tests/recovery-closed/publication.lisp" :GIT-BLOB
   "72f179d28936100b91d1847eeb8a24c696552619")
  (:PATH "tests/recovery-closed/read.lisp" :GIT-BLOB
   "0e401337f36768cd63206cbb7b6adf91eeeeb1ef")
  (:PATH "tests/recovery-closed/semantics.lisp" :GIT-BLOB
   "a931be1523c72d49e955aa7708bec6bd3b273be0")
  (:PATH "tests/recovery-closed/support.lisp" :GIT-BLOB
   "15bafc01c04fe1763d9a6580f6ad0bbb1917f40c")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "e6f289d77025dce439787287abc6a4dde0ac69f5")
  (:PATH "tests/recovery/inventory-directory-native.lisp" :GIT-BLOB
   "8f89629becea88fdc74c920a59676412c3a7b976")
  (:PATH "tests/recovery/inventory-directory-support.lisp" :GIT-BLOB
   "c316b3647e7ea5391d687917fe802907f2273bb4")
  (:PATH "tests/recovery/inventory-directory.lisp" :GIT-BLOB
   "ead38feadd94f49276596d0abf989f29d13af497")
  (:PATH "tests/recovery/inventory-id.lisp" :GIT-BLOB
   "1f05c46bfc887984c476bd7673d2b2dde998c44d")
  (:PATH "tests/recovery/inventory-sources-native.lisp" :GIT-BLOB
   "86144ee3fe19ef0f2a54c9760ed193860881ced4")
  (:PATH "tests/recovery/inventory-sources-support.lisp" :GIT-BLOB
   "36b79c4091825c32ffc3aa32a146ee5121881ebc")
  (:PATH "tests/recovery/inventory-sources.lisp" :GIT-BLOB
   "3ffd5a9fb098ab4aeb091a6823fcec68d22c19aa")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest-transition.lisp" :GIT-BLOB
   "cdde7b60edddd974153ee670d859a94993afa367")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/runtime/adoption.lisp" :GIT-BLOB
   "8fbee7f08a25445b66895ae2e329a217070f67f4")
  (:PATH "tests/runtime/bootstrap.lisp" :GIT-BLOB
   "1398120574f95ebaec3c7431a74a35e0ced01652")
  (:PATH "tests/runtime/guards.lisp" :GIT-BLOB
   "a097cc38e13a1ef7369a2ed996d042718cf7312c")
  (:PATH "tests/runtime/native.lisp" :GIT-BLOB
   "e92ba03fb8184a6c95c44269a26a831b714974a1")
  (:PATH "tests/runtime/support.lisp" :GIT-BLOB
   "7d4dc59eab68672512aed0f4ae578436e669fe2e")
  (:PATH "tests/runtime/threads.lisp" :GIT-BLOB
   "2454593a231d5d6bb9ef4318eb06567ce3192d24")
  (:PATH "tests/scheduler/controller.lisp" :GIT-BLOB
   "8e14282e1f42f3b247a5c578d8a683ddc6147381")
  (:PATH "tests/scheduler/dispatch.lisp" :GIT-BLOB
   "6a493f0022ac8c9b6117c2a62df49fa596194c7b")
  (:PATH "tests/scheduler/lifecycle.lisp" :GIT-BLOB
   "874391809401f42a4db81fe544306165f99ceb5d")
  (:PATH "tests/scheduler/pool-begin.lisp" :GIT-BLOB
   "13a239cf97403806a73242abbd5b545440a17645")
  (:PATH "tests/scheduler/pool-chain-support.lisp" :GIT-BLOB
   "a1ea8258495b9a717e1e0ef164133f6b7140f8a5")
  (:PATH "tests/scheduler/pool-chain.lisp" :GIT-BLOB
   "86675c17ea47eff262cb03cdb41e50bcdb82b78e")
  (:PATH "tests/scheduler/pool-claim.lisp" :GIT-BLOB
   "f636ee873deb2cd5347a50c9aec4a6afa16d13c5")
  (:PATH "tests/scheduler/pool-recycle.lisp" :GIT-BLOB
   "3c779589cd7df6ae1146c2ca50b70320093bbf4a")
  (:PATH "tests/scheduler/pool-start.lisp" :GIT-BLOB
   "ec19bb409799e7956e40c34cc9264d02033cfb22")
  (:PATH "tests/scheduler/pool-step.lisp" :GIT-BLOB
   "d0ff803608990744408749722210e812f6268782")
  (:PATH "tests/scheduler/support.lisp" :GIT-BLOB
   "f2301a1adf44c33284aaa1171acd90c5828b0396")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "ef3d4671b3df48b932c1666f8b58fdca4eecbc77")
  (:PATH "tests/series/log-binding.lisp" :GIT-BLOB
   "c116a9169058ddd9e384fda5f52bb5787977e20e")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "257c6f8cf28bdd8408a3363041d621497f4a5f67")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "c3eb1ce7870b81944c23efac9b8cb7f8f4888ba9")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/verify/canonical.lisp" :GIT-BLOB
   "66f603183d98b01acf07228f19bf3025e48254d7")
  (:PATH "tests/verify/cli.lisp" :GIT-BLOB
   "93078b49e212420f81f52083a7b717a163b7727f")
  (:PATH "tests/verify/guards.lisp" :GIT-BLOB
   "d2511620da049cd377a4847e74b82f7200fbebcd")
  (:PATH "tests/verify/observer.lisp" :GIT-BLOB
   "ecc44b603fba3142bc5a069d3d2be22e8e76a55a")
  (:PATH "tests/verify/order.lisp" :GIT-BLOB
   "1e61ba11c977de74cadbe950bc68fe6d3fb11170")
  (:PATH "tests/verify/processes.lisp" :GIT-BLOB
   "feb165176cc6c6661b30453513c21f981cb58113")
  (:PATH "tests/verify/support.lisp" :GIT-BLOB
   "668b4909687394df5b41f27fd0636f22027ca1ab")
  (:PATH "tests/vertical/method.md" :GIT-BLOB
   "3e60572557391e2c772d3b44491ae18eecb352bf")
  (:PATH "tests/vertical/processes.lisp" :GIT-BLOB
   "059fbd2bb702e76e986b97edfbe4d3784599d583")
  (:PATH "tests/vertical/resume.lisp" :GIT-BLOB
   "6f80a0d0fec9f725beca54d06d961932bd815043")
  (:PATH "tests/vertical/scenarios.lisp" :GIT-BLOB
   "fcbc7878d56720604f0e86a916d2e42c0f28cffd")
  (:PATH "tests/vertical/support.lisp" :GIT-BLOB
   "37c2e8d1da68eb425cdd11548f8699c888afd7bf")
  (:PATH "tests/wal/append.lisp" :GIT-BLOB
   "2e0d75a68d6ca657634c22fcb5632d1cf5fa8a1a")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/arcdocdb-verify.lisp" :GIT-BLOB
   "5aed85033d701c64e2c4698fae58dcb947dc80e8")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-float-write-audit.lisp" :GIT-BLOB
   "485544868eeadff247968b86c2d5da9b3b610295")
  (:PATH "tools/cbor-float-write-bench.lisp" :GIT-BLOB
   "d992c9f8cf6ff0d748fcb77f871fb77969480bca")
  (:PATH "tools/cbor-float-write-mutation.lisp" :GIT-BLOB
   "5d0d6bd46b0286f153ee9c482734c659959396e2")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-read-driver.lisp" :GIT-BLOB
   "a6b65bd233dba2a2eec941d96a75b9db948d19f8")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-parallel-tests.lisp" :GIT-BLOB
   "a49a03a64a137e66c07c98f981327fc42d9cb508")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "e3df9f52590ce2de86ad75b872c859b81bbcc518")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "1f63d49150e6b7b23c1df2a9c25c3d2288861b8a")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "253fea1c65c6aacb77fa56f2ab05cce086a1856d")
  (:PATH "tools/ci.lisp" :GIT-BLOB "c0b6255982f4299b883992f5829baaebcd2aaa36")
  (:PATH "tools/ci/archive.lisp" :GIT-BLOB
   "03712985b7cf1493a7009a35965cadf6c9902292")
  (:PATH "tools/ci/conditions-self-test.lisp" :GIT-BLOB
   "99f857163fa38683871790731b6f72448cf92ffb")
  (:PATH "tools/ci/coverage.lisp" :GIT-BLOB
   "233ae46d6ab9fab6a74046140323eecc64243174")
  (:PATH "tools/ci/data-self-test.lisp" :GIT-BLOB
   "b5d6a8f505604e3c45d228582933af38713cc01a")
  (:PATH "tools/ci/data.lisp" :GIT-BLOB
   "8cec68fa2e6e5d7e4484a53cde13964b875f9222")
  (:PATH "tools/ci/github.lisp" :GIT-BLOB
   "a2ca20ed9c586b104f59091d174028b3454d6a10")
  (:PATH "tools/ci/identity.lisp" :GIT-BLOB
   "abf3cc722957379e1408d629b81a2d1916a0788b")
  (:PATH "tools/ci/measure-self-test.lisp" :GIT-BLOB
   "18959f2608b1be4ef1b77b0a7d3b1a67735c16d4")
  (:PATH "tools/ci/measure.lisp" :GIT-BLOB
   "7e16fd5b80a7bbce27a0c856a6abd001ff4814ed")
  (:PATH "tools/ci/producer.lisp" :GIT-BLOB
   "a7fab0bcc8dc6a33ed37acb0d391ec1a73674493")
  (:PATH "tools/ci/publish-self-test.lisp" :GIT-BLOB
   "400b9ba4c1c3fd0e6bd158f3f89bcc58e802c595")
  (:PATH "tools/ci/publish.lisp" :GIT-BLOB
   "d8a212faaa5bba7df102377a70e6cd9d75d7810c")
  (:PATH "tools/ci/self-test.lisp" :GIT-BLOB
   "8b2cfa7eab4f728c70a4f0f6e4a81da3259a9e38")
  (:PATH "tools/ci/support.lisp" :GIT-BLOB
   "b5fe7c565ed0f885b666d8dba836bec4a7ba4c65")
  (:PATH "tools/ci/test-self-test.lisp" :GIT-BLOB
   "518ac77485351807b4b72c0cc7e030821ec81ab0")
  (:PATH "tools/ci/tests.lisp" :GIT-BLOB
   "9c81cf6aec5f89896d9e4ccdcd59ccf1d3c65c6f")
  (:PATH "tools/ci/workflow-self-test.lisp" :GIT-BLOB
   "f0278d9bc21245d6890e52011414627376bca5de")
  (:PATH "tools/collect-command-archive-tests.lisp" :GIT-BLOB
   "49da390b7e170acc9ffdafa78285f215aec75f44")
  (:PATH "tools/collect-command-archive.lisp" :GIT-BLOB
   "d2eb1bd8a62b0fd98ec023243b2a768c19988dc7")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/control-checkpoint-bench.lisp" :GIT-BLOB
   "f631bbb7096359592fde0ae2b4462c2d2067d5a1")
  (:PATH "tools/control-transition-bench.lisp" :GIT-BLOB
   "40fd5a04dc62cced8e688ed30f59e0d810716a43")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/engine-crash.lisp" :GIT-BLOB
   "04c4796c05bdcecf6d8fc83d3ee1eafcf969fed9")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "abd8e62e937c60e9ac68c3ccce904111388bff09")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "f520ecdb46cc94e07d774d39cb73beed380aa867")
  (:PATH "tools/fulltext-codec-fixture.lisp" :GIT-BLOB
   "f6756e030cdde7beaab41a6b38516950f1663c9e")
  (:PATH "tools/fulltext-persistence.lisp" :GIT-BLOB
   "ab0dbf4ec2e5335721818cc03711b92d7d62111d")
  (:PATH "tools/fulltext-qualification.lisp" :GIT-BLOB
   "d649e9cafa96bcb4351bbced5de04bb10352ab85")
  (:PATH "tools/fulltext-unicode-tables.lisp" :GIT-BLOB
   "ba86b196441a40e662f6052e189074eef08b75d5")
  (:PATH "tools/get-active-init-bench.lisp" :GIT-BLOB
   "c62f2bf8ba96c3e80cdd50ba067e4c4df3e5e957")
  (:PATH "tools/get-active-init-mutation.lisp" :GIT-BLOB
   "b2cd809d99d049757156ddf0141997e3b67903b4")
  (:PATH "tools/get-cost-bench.lisp" :GIT-BLOB
   "696d56846ce992f186da2b468f8de55063532b02")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "45897c0afa972a437bbb595493b87dd0c8ed9710")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/get-resolver-coverage.lisp" :GIT-BLOB
   "5ab21d923b68e35adbc177ecd352bb33340f0c07")
  (:PATH "tools/get-series-bench.lisp" :GIT-BLOB
   "2950d4fcb7fc93fbfc7d78c860f0ac43ed984f35")
  (:PATH "tools/get-series-capture.lisp" :GIT-BLOB
   "9c42e23d381751e8140f186f969c6c2ef8d606cf")
  (:PATH "tools/get-series-mutation.lisp" :GIT-BLOB
   "3d3e887ba8e1d90612e561dfffb3d71c486e813b")
  (:PATH "tools/get-throughput-bench.lisp" :GIT-BLOB
   "6554b119583602b9d06b3ff7b2bb9c8104130d79")
  (:PATH "tools/index-image-crash.lisp" :GIT-BLOB
   "01f7cec3a08a55fcf51b4c743e588ad53a0023ae")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/io-completion-mutation.lisp" :GIT-BLOB
   "7fd59fd86e2d477a6b6ee0f7a2142f8ea6b073c6")
  (:PATH "tools/io-rename-bench.lisp" :GIT-BLOB
   "988d259af126212adc2be8fb9ca9acd8755fdce0")
  (:PATH "tools/io-rename-mutation.lisp" :GIT-BLOB
   "dfc691c88e9ab940a065703a223a1c414454b0f2")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/legal-notices.lisp" :GIT-BLOB
   "f120b9660591fd3eda904c9cf0722bddae3f05a0")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "adf3ca235874a2b950e57ea61a719c4c90e9dda8")
  (:PATH "tools/local-client.lisp" :GIT-BLOB
   "1ab2f474ad7db04a3fc8cc6dd7e84a2441498d20")
  (:PATH "tools/local-fault-server.lisp" :GIT-BLOB
   "92cd3d6164c6000c181374e3b917bbf1bb83aaa6")
  (:PATH "tools/local-group-server.lisp" :GIT-BLOB
   "924184dbc27702cbf84cf13b0cdb6e0d62a00bb5")
  (:PATH "tools/local-server.lisp" :GIT-BLOB
   "517652d80ad2d4fbbe85be42fa110d4c902d8cf8")
  (:PATH "tools/local-tests.lisp" :GIT-BLOB
   "02aace929b7f5e2fd790c02d1557628ea17d7afc")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/measure-pool-begin.lisp" :GIT-BLOB
   "e3094d9f35efdaa647751f19a7acda00c36d515a")
  (:PATH "tools/measure-pool-claim.lisp" :GIT-BLOB
   "712a4a5393b69539f02cd625223918e404b331d3")
  (:PATH "tools/measure-pool-dispatch.lisp" :GIT-BLOB
   "bddb449176d3b7b6ae946e841a0ca3202e6c28ef")
  (:PATH "tools/measure-pool-lifecycle.lisp" :GIT-BLOB
   "3a229eecc3c158cec9af8fad6abd5fc2d980e2dd")
  (:PATH "tools/measure-pool-recycle.lisp" :GIT-BLOB
   "cb20f6d271889a9801106daf230ee934aaa7bf81")
  (:PATH "tools/measure-pool-start.lisp" :GIT-BLOB
   "e6be453833925b89cdc49303b99a23374f3b2689")
  (:PATH "tools/measure-pool-step.lisp" :GIT-BLOB
   "cdcb410e27475282d157b0d64a4656ea6ad069a1")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/pages/bootstrap.lisp" :GIT-BLOB
   "a9cf9ea45672b576b76acf1e4773c2c2949bc2ca")
  (:PATH "tools/pages/build.lisp" :GIT-BLOB
   "e319acad4fe5bf1f9cd14b65772775c95ab632fe")
  (:PATH "tools/pages/check.lisp" :GIT-BLOB
   "b0524f02c494e61f4edf08aa2802ba1a3d16cd66")
  (:PATH "tools/pages/code-reference.lisp" :GIT-BLOB
   "16bf45ca14cc936283e32700698e696f4a36a09c")
  (:PATH "tools/pages/code-source.lisp" :GIT-BLOB
   "8ba99903d3afdae918fd8966410fbbaf7438066f")
  (:PATH "tools/pages/code-tests.lisp" :GIT-BLOB
   "1f1349e749863b14d9690a33dda48537d96434e3")
  (:PATH "tools/pages/dependencies.lock.lisp" :GIT-BLOB
   "f0f339aabf9998e7f910f8904744549766426ec6")
  (:PATH "tools/pages/editorial.lisp" :GIT-BLOB
   "f5a43b2ba1a876c3643ad4b3b64b43096c193b49")
  (:PATH "tools/pages/generate.lisp" :GIT-BLOB
   "56ee4dcf36cc76e82b3997357630eca1083dadff")
  (:PATH "tools/pages/markdown.lisp" :GIT-BLOB
   "a6ce370b0cbbeb2869c88112b69ee7aa38e7effa")
  (:PATH "tools/pages/model.lisp" :GIT-BLOB
   "bed6a6fb53b8efb13020bcf5cc5d1ec27aa31436")
  (:PATH "tools/pages/publication.lisp" :GIT-BLOB
   "8154535b76733cbdd33b3217744481635860a5a0")
  (:PATH "tools/pages/runtime-check.lisp" :GIT-BLOB
   "f9ab88e954f1b07f9c59594f55e67e909ee5f2e3")
  (:PATH "tools/pages/site.css" :GIT-BLOB
   "8069a0942d7ce79b272d8011c4f6c6002aae07e1")
  (:PATH "tools/pages/site.js" :GIT-BLOB
   "06770c92736cc6bd2b3e0c9638ec09f5c0dcc1c3")
  (:PATH "tools/pages/tests.lisp" :GIT-BLOB
   "d05b62748b36cefed5977d1a445c18e1d70b8e62")
  (:PATH "tools/pages/theme.lisp" :GIT-BLOB
   "547ef0acc0e6070c7fcd53385b0efed1aec5f82d")
  (:PATH "tools/pages/third-party-notices.lisp" :GIT-BLOB
   "907abf85677565bb547a4b7f0e7c6311b3bfa3ce")
  (:PATH "tools/pages/third-party-notices.txt" :GIT-BLOB
   "68ebcf8172dcbbf0865767f5194abb97911a83ef")
  (:PATH "tools/pool-controller-bench.lisp" :GIT-BLOB
   "cf6f31dd9c7a8d7f4e7cc1f19c4b9c5a48af6d55")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "068090ec38864b2b55877918aec57375312ee8db")
  (:PATH "tools/recovery-active-bench.lisp" :GIT-BLOB
   "9c11d5654a6168c27c64abcc8f852673c5974515")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/vertical-crash.lisp" :GIT-BLOB
   "8f920374d5b1049f5bac1e8dfb441099575de6cd")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :WALL-SECONDS 67.665695d0 :FINISHED-AT-UNIVERSAL-TIME 4002496520
 :SCHEMA-VERSION 1 :KIND :COMMAND-VERIFICATION :ENVIRONMENT
 (:LISP #A((4) BASE-CHAR . "SBCL") :VERSION #A((5) BASE-CHAR . "2.6.9") :OS
  #A((6) BASE-CHAR . "Darwin") :OS-VERSION #A((6) BASE-CHAR . "27.2.0")
  :MACHINE #A((5) BASE-CHAR . "ARM64") :CPU "Apple M4" :MEMORY-BYTES
  17179869184 :LOGICAL-CPUS 10 :EXTERNAL-LOAD-STATUS :UNCONTROLLED
  :LOAD-AVERAGE "{ 1.69 1.88 2.03 }" :COMMIT
  "8a808a3c098cd7766b5aa53013de414fd8998ca1" :WORKING-TREE "M CHANGELOG.md
 M arcdocdb.asd
 M docs/adr/README.md
 M docs/implementazione/README.md
 M docs/implementazione/production-engine-bootstrap.md
 M docs/implementazione/wal.md
 M docs/tracciabilita/matrice.md
 M src/engine/write-group-commit.lisp
 M src/wal/executor.lisp
 M tests/engine/write-group.lisp
?? docs/adr/0082-bounded-group-append.md
?? spikes/results/2026-11-01-engine-group-append/
?? src/wal/append.lisp
?? tests/engine/group-append.lisp
?? tests/wal/append.lisp"
  :CWD
  #A((74) BASE-CHAR
     . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/")
  :DATE-UNIVERSAL-TIME 4002496453)
 :COMMAND
 (#A((22) BASE-CHAR . "/opt/homebrew/bin/sbcl") #A((8) BASE-CHAR . "--script")
  #A((56) BASE-CHAR
     . "spikes/results/2026-11-01-engine-group-append/bench.lisp")
  #A((5) BASE-CHAR . "--run"))
 :STATUS :OK :STARTED-AT-UNIVERSAL-TIME 4002496453 :SOURCE-BLOBS-BEFORE
 ((:PATH ".gitattributes" :GIT-BLOB "d22cbb201cb1d3384baa7e8422aa9d6ee8aea1f9")
  (:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "4ed9445eb02f439a3c781878622809125ed924e6")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "711b96fd6fb677d15473213023c40c35affb47c0")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "ea5cf67447809b2e413026d50e2f61609cb9e438")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "80da41aac60230141d5d2d0819c9b6c2c3b3ce91")
  (:PATH ".github/ci-toolchain.lock.lisp" :GIT-BLOB
   "c01b06c5b208014ab30bb000dc10acfc9e72cc89")
  (:PATH ".github/workflows/ci-results.yml" :GIT-BLOB
   "d5029660830b7dbef56d6648bbf0a9bbaa400c56")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "49fc8ba897e94dc36c31d973e6e12efeab51b715")
  (:PATH ".github/workflows/docs.yml" :GIT-BLOB
   "6eef2de086d133233892870f80f5771f90ab1676")
  (:PATH ".gitignore" :GIT-BLOB "a3a191b534821cfe86f062a09dbc2cb19ba153bf")
  (:PATH "CHANGELOG.md" :GIT-BLOB "ad9b4ccceca8735e6b078ce90f31af4b7cdb194c")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bc7dba35611947cb7c1e9fb898e294b00f9f2de1")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "20743e1dd5a32d14e0af066e27987eaa16c94964")
  (:PATH "README.md" :GIT-BLOB "9e6430d753813af59152d82a3959a45d70abfa94")
  (:PATH "SECURITY.md" :GIT-BLOB "331a1316c300159882e3a30f9f2c8575a8e586a9")
  (:PATH "THIRD-PARTY-NOTICES.txt" :GIT-BLOB
   "0c5bc85db048fb8970c3cc42fb128337eff77e39")
  (:PATH "arcdocdb.asd" :GIT-BLOB "2daba94b7941b8466700289a45f764ee4f1d1db3")
  (:PATH "assets/README.md" :GIT-BLOB
   "c30d58ba88d9dd9f146df6f03aeedbdea3df5c72")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "a024e50336c5d93b7619048432219020d84eb688")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "0bb1c4dcc1aef96287b5edf18db288467e37f9c1")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "data/unicode/18.0.0/CaseFolding.txt" :GIT-BLOB
   "9ee0a2dd654f6fa520cd932be19ac5c00ffacded")
  (:PATH "data/unicode/18.0.0/DerivedNormalizationProps.txt" :GIT-BLOB
   "32227e8f297e96f98954281d99c38839a7834d7c")
  (:PATH "data/unicode/18.0.0/LICENSE.txt" :GIT-BLOB
   "56da58912807030b451a4700687d5bd02c72d6ed")
  (:PATH "data/unicode/18.0.0/NormalizationTest.txt" :GIT-BLOB
   "730c1a013ac78f6a63118e670c72556d4f112eab")
  (:PATH "data/unicode/18.0.0/README.md" :GIT-BLOB
   "06ab2a1368779a5535c48e90a7e2fb77e44080c9")
  (:PATH "data/unicode/18.0.0/ReadMe.txt" :GIT-BLOB
   "aa18f7175c4a46df644c7c6435ad95a8ad3cd724")
  (:PATH "data/unicode/18.0.0/UnicodeData.txt" :GIT-BLOB
   "ebccf021c4fcf31c2ecbb9bd7da3f5eb7ed44851")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakProperty.txt" :GIT-BLOB
   "313ae91aad579445a1e06556a1d7a2edd0c782a2")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakTest.txt" :GIT-BLOB
   "8d734a2690b9f06018e02b0b4f165acc4d0d2853")
  (:PATH "data/unicode/18.0.0/emoji/emoji-data.txt" :GIT-BLOB
   "7a383f0dcfd6ad65a2b7b5e90f701e38485f151f")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "a677288d5fd65a8de671c8cb513fef7c9cb013d5")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "0f68efcd275602bc60b1ee3a2a104f8a49bc6b80")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "1445703c53c2f1b82ced7dd78f34ad4ab8aae7d1")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "3c1c28fb8949660be6391180be187f55d14d5bb6")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "4c0ad12a7532b5d518b0581301f28a3601228d94")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "fce97d7d8c70a6c8f5425cd47ade5a2db5892a11")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "d3973b8d3cca6c9df25ab1c2e76c305bdc28c51b")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "85c9f51f242e4e5c3239edb58eea0a3ae0013011")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "5e10ff0c486bc5e08163bcd5df5bd5736de102f0")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "8720f145cca1d03da5446c5398ad4417a6243a18")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "30462b46bdd4dffdc7a8217adb6ec89571bf8b89")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "c05d0f0f5f69c9ddd9a85769c4bb11cc5a921c75")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "4ccdd9d66495ccff8d47d70ab80b04fa3bc601ca")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "b6a6a520f82271f96513a10457ad400c3f86f2bd")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "b75830dd78d106f8db76e65c08d4e8f3b2a488e4")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "d102ba1c248c77c71c437e46675cd5fc913fcdc5")
  (:PATH "docs/README.md" :GIT-BLOB "db925522d2e683e87137b5f3bca8d234cfe435bc")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "641a7c9e540ff2ec1136bcaa53c6558691578577")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "85d24f91157ac79e6af8c3ac908ca03921913922")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "9baef4c50046aca7c2d9740896af96a9dc5974f3")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "c949015de0fa3a2c25e597b523cb9a00409549b7")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "dd5d59a612a804976a08a475b0cce0de5daba1e3")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "49c294e438f29b383bc825210ba12f070f24a7a1")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "b56195d0f7f43e7bdb91a3af0d1a33f161b8d36e")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "26cb290c6bed61bf397cf4f9dbad7ca81d97e8b0")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "289e40fc2198e9295b90cddd5444d061cccdacfc")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "570458150a9f118174d72cbf90b0b13400237997")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "86c3d28f5a8ecdcf0dbbff34e5eeddf69bea5c48")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "3a490fbb3a23a5de59e08a86b5d656e559ec3696")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "c6b0803782b4595bce94f73f37bfb3de06ef58e3")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "811067eb4311ef4ed3c3b5450325345c04d444e4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "c863c2471e2f6e2b6bb0cb79f9c303dda902f572")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "5117c423e298e8aee4e02b2daea95cdfa6747784")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "813ecfb7741a73bbe4065c0914eab22495bbca3e")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "c5fc54a10372cec9bbf1fd3cbb436a6e835cd079")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "08a71d783f74d8dc0c02db312902f4256668d49d")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "085506a53a59d44f70b63f9f550df428a1f7c564")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "6399188b2711a8860f5895fb92dfabb34fa2dafa")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "13e62eb82f21f3b5490511d47823439541edba33")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "7785da60ce293bc328817518fbf2be3f9ab9a7b8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "57f594b6143b04e40bc3fea9394ebe938ca799ee")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "6b41728bd67274b11b1fde42cfb6ac2b71b0340b")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "0ec3e4cb8daeb741d6be9428099f1da284b0f895")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "50cded21f18bd019fc190b08edb348945d05829f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "e0e408989c0d8b1a8594a31a9f4cda888232b8c7")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "51ecdb8e1af48f87cd2e53d8c3c334b4a4dd7062")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "8589ad553a5b18f96e5dbab682a024f90b671c2e")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "138cf9abbe606df8f544a669069ed94844c9960f")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "c6ee53cf623ad6294ab2ab7e46ee16a3304dfdda")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "0af09ca66b38c35361d30ddbd028a0cb7fcac4e8")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "98cad23c9c529f3f83ccf02dc9bd1a4cb1e6f318")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "2d7ba68f4a56fa80700825d44f2b4335b4d342f4")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "5150eca7a1e85c342e20519179c0560e19c816c4")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "3aa06135165157067c6eaf64d8317a43d32086f6")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "b352146cf5138b099155a819a2c0c19780a31af7")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "05cc183bb8bd0b7b468a7225065c4dc75dd6cd33")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "452553489ad4b466a118e5ec3f08a79223ba7f69")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "7323f9c4e7d6a41ee0e8edbc7c21f6c40fae7258")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c12ccb4a82f5e97c40c2e2df05f085c28f9356af")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "c5ccb103deb265db77ca14be9e4fb60ebb7395f3")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "d0ce5bcc0bbfbf2fa92187bbd09d0ff320d54e69")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "a52656154964c4588477288a15fb10284ac888a4")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "d23b7ee9ef2e3e178a663dbfb004ccc8fed2c542")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2c0669b7a0226ff342e15158899a06d75a30abbc")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "5ba95841ff8f467ed496f51101ddd832dca4fab1")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "2787435e8647b4c1702b7fb4f35f40cd64197fa0")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "18cf324a65ccb0d7684d357bbb8eeb6aeed6a11a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "6754d79f26141153b55bbe1bcaa4a82825f95700")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "fd7e70d402194978a3ffdad705318afb0431f04e")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "2c3d966a83d6f5c1ba122e38ee510b5277a1e89e")
  (:PATH "docs/adr/0053-ricerca-full-text-indici-invertiti.md" :GIT-BLOB
   "ed37b13d26276ccec88bc4eb7e9259bc8ea270a0")
  (:PATH "docs/adr/0054-contratto-e-formato-full-text.md" :GIT-BLOB
   "239a1b5bbb0be77e0a60cb3f0360d8f4906d0b46")
  (:PATH "docs/adr/0055-interfaccia-locale-unix-socket.md" :GIT-BLOB
   "3a1a8acc98918b9eff3f9c319da1d089bd55bf1b")
  (:PATH "docs/adr/0056-sessione-locale-m16.md" :GIT-BLOB
   "09aa317be40281eb6dfeedfb16c27bf4ee227782")
  (:PATH "docs/adr/0057-selezione-automatica-indice.md" :GIT-BLOB
   "dd056fe207e34cc13582ef67686f5cef50da0d52")
  (:PATH "docs/adr/0058-pagine-indice-primario.md" :GIT-BLOB
   "aace2fae9377ecc39befa24f30a71fa3544aa82f")
  (:PATH "docs/adr/0059-crc32c-arm64-sbcl.md" :GIT-BLOB
   "8abf118f525ac8e4bfb3657e7b9c2389825e3734")
  (:PATH "docs/adr/0060-crc32c-caricamento-portabile.md" :GIT-BLOB
   "e525cdb37bc853b13c077a139869132a6c8a3296")
  (:PATH "docs/adr/0061-conservazione-esterna-delle-prove.md" :GIT-BLOB
   "f72ff61077518b492f247dde021f8ae8d5749777")
  (:PATH "docs/adr/0062-cronologia-git-due-commit.md" :GIT-BLOB
   "d17a19b8086aeb412bb8622fe8dc5301fd3265d0")
  (:PATH "docs/adr/0063-immagini-sigillate-indice-primario.md" :GIT-BLOB
   "6bf24e2c250857907d5d36e6ea7f2d93cf2dcf63")
  (:PATH "docs/adr/0064-adozione-indice-paginato-m1.md" :GIT-BLOB
   "8b4f945e8e06c194b517c1563c2a78fe1ddbd609")
  (:PATH "docs/adr/0065-costruzione-immagini-dal-motore.md" :GIT-BLOB
   "09314a89fa7875d648062095cfd24081055e34f5")
  (:PATH "docs/adr/0066-attivazione-seriale-immagini-m1.md" :GIT-BLOB
   "ca6fd5d38685053ceb12922973a932f72fce5fd8")
  (:PATH "docs/adr/0067-delta-seriale-indice-m1.md" :GIT-BLOB
   "03ea9916428820920370aaeef7c422b0478d3b4e")
  (:PATH "docs/adr/0068-rinnovo-seriale-immagini-m1.md" :GIT-BLOB
   "2240c84c7e57c86d33df08772b173cc9d0d11aba")
  (:PATH "docs/adr/0069-manutenzione-a-soglie-delta-m1.md" :GIT-BLOB
   "7433e9b73ae1548f198181002505a8aabec65ceb")
  (:PATH "docs/adr/0070-scoperta-readonly-immagini-m1.md" :GIT-BLOB
   "f4a496e4556b220282b4a962a57a723ad2ccbf50")
  (:PATH "docs/adr/0071-delta-location-indice-m1.md" :GIT-BLOB
   "5f06b390d2223e5e5e85f38f5de73cf1ad668f5f")
  (:PATH "docs/adr/0072-rinnovo-automatico-delta-m1.md" :GIT-BLOB
   "99ae69d3d9fa5d6d69f9cb5efede395fe33ae408")
  (:PATH "docs/adr/0073-indice-automatico-operativo-m1.md" :GIT-BLOB
   "8f7677e90411d564c161e07d5f46fe774e32384e")
  (:PATH "docs/adr/0074-crc32c-sbcl-2.6.10.md" :GIT-BLOB
   "0d32b3a9bfe16d3755cc163e1ec2ec09394ca598")
  (:PATH "docs/adr/0075-codex-documentation-toolchain.md" :GIT-BLOB
   "60f2fca9be7d793cffd1f13dc43a80365df700a5")
  (:PATH "docs/adr/0076-rotazione-live-m1.md" :GIT-BLOB
   "1da6f99e64dbce919e88440c8a4662d9abc9ba82")
  (:PATH "docs/adr/0077-source-derived-code-reference.md" :GIT-BLOB
   "100230816ee9e513dfc78ba3c57c992bef61eec5")
  (:PATH "docs/adr/0078-compattazione-prefix-m1.md" :GIT-BLOB
   "89e9e72b6eb4aaf2a0fd494de6a72a33810a52b0")
  (:PATH "docs/adr/0079-cache-record-m1.md" :GIT-BLOB
   "114135347b465d247f7e05b091858c9791f88382")
  (:PATH "docs/adr/0080-group-commit-m1.md" :GIT-BLOB
   "86b89a39cfe8faa863e350dade7d77f9540364fb")
  (:PATH "docs/adr/0081-active-append-metadata.md" :GIT-BLOB
   "19b160c27564b5682637adc98ed39e1b47255f2d")
  (:PATH "docs/adr/0082-bounded-group-append.md" :GIT-BLOB
   "9d0be5661c2df788d2f3c1f2d1f03330011eb78e")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "65c127420a3f961862707dd4632d4fff071b25da")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "da6af58f171fe105407b444a400905f554110ec9")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "09805b5022bf9b338522c4078feae7334825c50a")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "2b878e6c0b9ea5576635f16b1d9e7433c956458f")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "0b92053bbe5abc8b74a59472a0ddaad7be9ba399")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "35ce8a542e4e77ba28c497e4a33358f308708bd0")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "5729dba5379c1eaf1366302e6243fa5219f60cd0")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "2325e50c80180c368d7e13c9181bb6e6fd8ff831")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "5f74a1692a934ddc9425d91ff0cadbf842c95bb2")
  (:PATH "docs/code-reference.md" :GIT-BLOB
   "ce9a8a5a9a8ef8d58833bb239199bbd2e1f6019a")
  (:PATH "docs/editorial-policy.md" :GIT-BLOB
   "23c70f794c8640f050be6eda8d1f75fbeeb13540")
  (:PATH "docs/editorial-review.md" :GIT-BLOB
   "9264d1e4e9b0189d3b3f5a5f3c8cebe5f5d728ec")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "d83cff978b0e2c61bfbf1308e4fdcdbd38fb4ebf")
  (:PATH "docs/formato-indice-full-text.md" :GIT-BLOB
   "be3b1b6661023f58d985a26c07c15216cb099a66")
  (:PATH "docs/full-text.md" :GIT-BLOB
   "29a9ee662cd39c103edaaf046bc8b68731bd8df4")
  (:PATH "docs/github-pages.md" :GIT-BLOB
   "1d624b0c03aa60ee582ce4c98c83b38272c0dc75")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "8c460a969441f5be9d94766fff808f15d6d33f36")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "0c946fd449c68453ea89231234ec67431189414d")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "2c4a6338cd88734319a7420684682d8a0e48fb6d")
  (:PATH "docs/implementazione/active-recovery-metodo.md" :GIT-BLOB
   "5724560732e14d6d374483aa71ca0f7802541df5")
  (:PATH "docs/implementazione/active-recuperato-metodo.md" :GIT-BLOB
   "32524af882ad0a043f6d939994c9a6a11769fef9")
  (:PATH "docs/implementazione/active-recuperato-verifica.md" :GIT-BLOB
   "23af8d8e23577a92d5c0e74884061cb56639d55d")
  (:PATH "docs/implementazione/active-recuperato.md" :GIT-BLOB
   "0b685aa69fd7c078994b5d1feaa4b5b93c1cafc8")
  (:PATH "docs/implementazione/adozione-closed-runtime.md" :GIT-BLOB
   "21630d85433210b2f061c422c931ef0f14ad0b61")
  (:PATH "docs/implementazione/adozione-controller-runtime.md" :GIT-BLOB
   "f2f7826b7eb58b681d334e29834ddd1cf09fed06")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "797a1998753834a3204075954c9cfe81a0f064d4")
  (:PATH "docs/implementazione/archivio-csn-revisione.md" :GIT-BLOB
   "c886079a0ad9f47ae864fbb63084960f897e55fa")
  (:PATH "docs/implementazione/archivio-csn-verifica.md" :GIT-BLOB
   "873f06c415107bac58d781df316e5b484222316a")
  (:PATH "docs/implementazione/associazione-file.md" :GIT-BLOB
   "02e39a32261a5a901ca45e15dcc7505819a969e0")
  (:PATH "docs/implementazione/attivazione-indice-m1.md" :GIT-BLOB
   "cd609a5e9645be680b23798e0bda841d8507d772")
  (:PATH "docs/implementazione/cache-pagine.md" :GIT-BLOB
   "1eaeb517c655d918d307d46423e4aee54f39290b")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "3dbae0d9e595f509621e6bf6dd3380a5ed844f1d")
  (:PATH "docs/implementazione/cbor-array-decisioni.md" :GIT-BLOB
   "948258bd302c1820210e439862d432d8c5554e9e")
  (:PATH "docs/implementazione/cbor-array-lettura.md" :GIT-BLOB
   "c419ecc31f9e905f4d053fd4473c8b605415dc4d")
  (:PATH "docs/implementazione/cbor-array-metodo.md" :GIT-BLOB
   "a5e53c22e391f72573f89c01f58ae28fa1c40376")
  (:PATH "docs/implementazione/cbor-array-revisione.md" :GIT-BLOB
   "f992654650b2fb08a59058b337fef63f901bf75c")
  (:PATH "docs/implementazione/cbor-array-risultati.md" :GIT-BLOB
   "e4c253fcfbe86fd2dfce2bd3354614a67f4b97f5")
  (:PATH "docs/implementazione/cbor-array.md" :GIT-BLOB
   "0f8fa2876a7366cd62bd1b8669251e2107b19b7d")
  (:PATH "docs/implementazione/cbor-float-scrittura-copertura.md" :GIT-BLOB
   "c1f596a69e83504ff3fd2c7cf569f234e1c6554b")
  (:PATH "docs/implementazione/cbor-float-scrittura-dati.md" :GIT-BLOB
   "618a4fdc1d5fbb230414931295ff0f7ef9367c84")
  (:PATH "docs/implementazione/cbor-float-scrittura-decisioni.md" :GIT-BLOB
   "cd76b3d2b02c6c021849b2b85d1a403d76e38f78")
  (:PATH "docs/implementazione/cbor-float-scrittura-lettura.md" :GIT-BLOB
   "11a065b51085a23f42df7ca75e315cbee0328e70")
  (:PATH "docs/implementazione/cbor-float-scrittura-metodo.md" :GIT-BLOB
   "6c046bb92cc291fb00914da89e0eefb705b4ae65")
  (:PATH "docs/implementazione/cbor-float-scrittura-revisione.md" :GIT-BLOB
   "870474964d88a8b4099bf00cc31c0b2bc542f94a")
  (:PATH "docs/implementazione/cbor-float-scrittura-risultati.md" :GIT-BLOB
   "84faa8d4bbf5150c4b9df17879b5dd0b39a286d4")
  (:PATH "docs/implementazione/cbor-float-scrittura.md" :GIT-BLOB
   "c14c7bbaebcd803c24f62adcda19259b16f00e52")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c7fe2a7bad385932a72141de4ae46f04bbd8ce18")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "dd7621ec9feea82adec89e00ed232b22d8aead35")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "4984c8c845da1437c212f47a7a345979df1c5acc")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "ba09a11d806999c55e0cb75f5b638d1fe2cb0476")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "29f9c13299d7b2fbcea64db535c0ec3fd4456f73")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "fb04b79a27ae65e2097c21ace50ee70f26bb0e8a")
  (:PATH "docs/implementazione/cbor-item-decisioni.md" :GIT-BLOB
   "800cefe6cf8f8a8000dad71d3807df7e7efdd210")
  (:PATH "docs/implementazione/cbor-item-lettura.md" :GIT-BLOB
   "57bcf4f8d1c40334c68d53ad2b4a2092e769d8d1")
  (:PATH "docs/implementazione/cbor-item-metodo.md" :GIT-BLOB
   "05b4a0d45c993c6bfebb0555098334f40db82f33")
  (:PATH "docs/implementazione/cbor-item-revisione.md" :GIT-BLOB
   "de0ef7bc19fe539d4aef7cdc1c1f5345b8002a94")
  (:PATH "docs/implementazione/cbor-item-risultati.md" :GIT-BLOB
   "8b02e00a9d43febf09b846d1bf6a01ebee2b3005")
  (:PATH "docs/implementazione/cbor-item.md" :GIT-BLOB
   "8548c091f11308380d4ac4e01ff884644b470281")
  (:PATH "docs/implementazione/cbor-map-decisioni.md" :GIT-BLOB
   "f44e789f6d2bf153580332fb136e46cb9e57194a")
  (:PATH "docs/implementazione/cbor-map-lettura.md" :GIT-BLOB
   "23a1f7f9653522ebf02619977dc2d74ed275f891")
  (:PATH "docs/implementazione/cbor-map-metodo.md" :GIT-BLOB
   "50ad5d1f64b5dbd37f4285306c5430789e0c581e")
  (:PATH "docs/implementazione/cbor-map-revisione.md" :GIT-BLOB
   "4f9c6c7a2e2eed16e73bbb314f5936182d371420")
  (:PATH "docs/implementazione/cbor-map-risultati.md" :GIT-BLOB
   "5322d5cdd93ea61e00830138091c72eadd5effe9")
  (:PATH "docs/implementazione/cbor-map.md" :GIT-BLOB
   "3f4f8e64c19f21958bcc913a1ee701cc55a18f06")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "998d3f4d69a4915bd3d5ac13381d89b15a22afaf")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "1c7b8bc426f5054aa88e7b2cf8ce1d0c339e112b")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "d34c7e0e8b9347228e9c3121358824f106d1e663")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "8beb9758140566348297f59d8a85a1c6816c70ae")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "464af7d4e2264a4c7e0336b2219a0e886cd04c2b")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "a0a4beb749f27b8fdd721492a338ff29acd18420")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "3ac17f24029e9c242146cd994a7b2b907ef8177d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "1a2a1bc130b5e3f343f110bd9ccca2de3486a19b")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "ef1defbeb7d0f2f52a289e03fa52b7922bd8fff2")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "980896a21ef91e13e4c3a4d414d72115eb27fee1")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "a0533ae26074d23c19b098bcf11d7f3959c3b609")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "c3bd5167d49e4e2bc59bff90b6e62e3435ed43b6")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "556fddff139cb8660db889b3b1cb39046972c01f")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "d0bb1a35f08dc97dcb4e03e70e521707c8a8d29c")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "05a927871e8257d31d40c727f88858cc10f3f5b3")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "7b606f5d5c44abd25a7cea635c2e3086f7b08d7a")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "0c3f81227199b06df304e9e3bcbc6c98660bacc8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "54852d32fb4a642db32067148adbf6d9fb22a066")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "ab773c5d9261846c39c09f6cf06566344acd4ff9")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "a3e52d83ef8dab364c1e290a003fbcac3e4703b5")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "943ce8b93716e53b1048dbb672ecb01ecf2ecf2c")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "3bc420d5c29b2005395fdbf72ba1fe12fa0feb20")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "12ed41add43b64cf9a0cf317dab6a09a0f6a8f5e")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "7299368dd4c077d8e620e6a3f6b91dde5cde96c3")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "ee75788591cf776a011eddef4384ce6c9b0c1cf8")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "b5e504a3508da8c72295f9fa7a18ba44a482b547")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e5b9990f00978da272fac6353b4706e9cdb3e80e")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "46f011d10fbd376c7387ffe48a9730a3a2620b05")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "d33e32c7e570f1958c8af75a789ea3a6583e4289")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "032c6c20aa5e116d2c1fa4214a0701e40620b966")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "77e0e458eb0cfbeb0796d176ff54805fcec9fc13")
  (:PATH "docs/implementazione/cbor-stringa-lettura-decisioni.md" :GIT-BLOB
   "a307a12444fd16df6ad92dcdf8717f02e76ac7a8")
  (:PATH "docs/implementazione/cbor-stringa-lettura-metodo.md" :GIT-BLOB
   "3378a194f4eded0fc1316be064956d77b3132fb3")
  (:PATH "docs/implementazione/cbor-stringa-lettura-prima-revisione.md"
   :GIT-BLOB "6fb1e3c3cd8a7512958b54095940826c30980eed")
  (:PATH "docs/implementazione/cbor-stringa-lettura-risultati.md" :GIT-BLOB
   "b50555a7cf2b592b5c36b2d094d7500225581f06")
  (:PATH "docs/implementazione/cbor-stringa-lettura-seconda-revisione.md"
   :GIT-BLOB "ebfc3d0bbdd1a19a295c55770a6d505ddbd4aa84")
  (:PATH "docs/implementazione/cbor-stringa-lettura.md" :GIT-BLOB
   "9eecb30c6b1887b9a0a5f5aabe3516916c3ba025")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "82f1683ba3774d33e82fd23e118790e401c11085")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "ff78a1940b29beef1c4e685e2084767c948f9da0")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "280b19d5e97d5487ba6be4f59da8b015063074bf")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "7ac03f1075bd778be47916ef9eef72e5bcdc90ff")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "08f016eb4a073cf59dbb3c5c9b23791d4a1285ef")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "c17e8ed2fb902df4c971d0300c1c7842dd46a764")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "16b04b9a5451b880ea2449104f65e261ba7f6c7d")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "66c94d76bdb2c46714ea86774489f31580ac63c9")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "d64b31030580f02466562e86efae7cc27451d0a2")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "16ffa1f24020338735660b5b008fb3e00c498ea4")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "39fa55a82334440ea17d53dbefe050d53db6a716")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "5e801a7632e7ce46f56e79cad2073b3e155eae99")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "c77993b00f09e89d21d2ab2eb319964e9e2fa819")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "2221900158acbbd5cdaa39d3301b08501c071e97")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "e29635a7ce3cd150ea0801c4610ddd03af941c8c")
  (:PATH "docs/implementazione/cbor-tag-decisioni.md" :GIT-BLOB
   "f0329ac5196815f633bf7abc82c97730cee832a5")
  (:PATH "docs/implementazione/cbor-tag-lettura.md" :GIT-BLOB
   "49146a982d1297edaf0c31daca7c5eb6150a6ea7")
  (:PATH "docs/implementazione/cbor-tag-metodo.md" :GIT-BLOB
   "ffa487840cb2e0964e7fa7a7cd55d57fbeed3de4")
  (:PATH "docs/implementazione/cbor-tag-revisione.md" :GIT-BLOB
   "b61c84f5f4a70f3009748536709d37c2609d89cd")
  (:PATH "docs/implementazione/cbor-tag-risultati.md" :GIT-BLOB
   "a78c3f04408c306f2cddcc617274f2335b17fc81")
  (:PATH "docs/implementazione/cbor-tag.md" :GIT-BLOB
   "a67789164c1ca9ab5be6435322ae77606314831f")
  (:PATH "docs/implementazione/checkpoint-control.md" :GIT-BLOB
   "2e2d90188ad3b3bec79f9a2c90e9f2cff58f3c42")
  (:PATH "docs/implementazione/checkpoint-recovery.md" :GIT-BLOB
   "fd1444d3e09f58457eb3babe639bc93634e32aa3")
  (:PATH "docs/implementazione/ci-provenienza-pr.md" :GIT-BLOB
   "cfe42a5fe0ebb52b0c1217926a15078d8baf4cea")
  (:PATH "docs/implementazione/ci-statistiche.md" :GIT-BLOB
   "6d6d3ad1d0381ab4bf946a6c1e7561f5266ad494")
  (:PATH "docs/implementazione/ci-wire-processi.md" :GIT-BLOB
   "537159570d4bdc8e7dbcddb5be3dd9e2d57c26eb")
  (:PATH "docs/implementazione/closed-recuperato-revisione.md" :GIT-BLOB
   "38373f1de3d42b5e9056e60d30f215083a80c845")
  (:PATH "docs/implementazione/closed-recuperato-verifica.md" :GIT-BLOB
   "1c4b3e4f0e6c3d3c4519dcdd56c7a2ca8ca2d47d")
  (:PATH "docs/implementazione/closed-recuperato.md" :GIT-BLOB
   "3675c4a21cd14e15f136f1bdcd6e0c64f28564bc")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "07c702f3b926311b7af6950382459286f20c9d05")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "7c9473c0d5149a7cefab4ef33076c7f44bfe9f30")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "2dd9f8ab7dbdc2df6a41874a63aa62f45fa11ba8")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "714da56672b38ed721a71f7d81986f66ca3915e6")
  (:PATH "docs/implementazione/control-recuperato.md" :GIT-BLOB
   "050723cbdec05ccf343e6cf651023dbba053fa60")
  (:PATH "docs/implementazione/control-transizione-metodo.md" :GIT-BLOB
   "4af36a8e4c9c409cccb82beacd9a7243057c2b76")
  (:PATH "docs/implementazione/control-verifica-metodo.md" :GIT-BLOB
   "8ffecd3625f0d1c3b4cf5786e17354cd170a127f")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4e75306fe31c84d552c342f4294894121d647097")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "4c8e017a2fc5e52b4a26d3f90c50d2e89f90e5f1")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "a294f643c70035056ce585a186fe4fb0ad1f01f3")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "6a48c794b8d8619e762c0c33108175d26dab2235")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "e3bc4006b2c53306af00f16d8967e002be5be7f2")
  (:PATH "docs/implementazione/controllore-pool-decisioni.md" :GIT-BLOB
   "e45a4a1609e6ad2c4a8c507a3b6474b34329fc7e")
  (:PATH "docs/implementazione/controllore-pool-metodo.md" :GIT-BLOB
   "9452ebefc6280a045c051c394e3ab55a9b5b7b90")
  (:PATH "docs/implementazione/controllore-pool-revisione-2.md" :GIT-BLOB
   "f4b54f7f20f0dbc620c95098dfe8f7d11e00eb84")
  (:PATH "docs/implementazione/controllore-pool-revisione.md" :GIT-BLOB
   "8331ccdab4e1957b7eaa4ff7404ab2ed263fa924")
  (:PATH "docs/implementazione/controllore-pool-risultati.md" :GIT-BLOB
   "e0738c5de4ceb793d70419ac8fece82e1de2359d")
  (:PATH "docs/implementazione/controllore-pool.md" :GIT-BLOB
   "32a0876c84705abfb03a324d93c0e09997e8caaf")
  (:PATH "docs/implementazione/costruzione-indice-m1.md" :GIT-BLOB
   "954e5c11aac01cdcdbbe1300ab7ad5904a31186f")
  (:PATH "docs/implementazione/costruzione-indice-paginato.md" :GIT-BLOB
   "6f4a25f0f4a8c5c5ef123b587f34313cf18493ae")
  (:PATH "docs/implementazione/crc32c-arm64-metodo.md" :GIT-BLOB
   "fd0a6f8b0203eb527434d5c85b5a21bffaa83842")
  (:PATH "docs/implementazione/crc32c-arm64.md" :GIT-BLOB
   "9d44dfe4836c393debf1e2fedd781ba8d64ac854")
  (:PATH "docs/implementazione/crc32c-piattaforme.md" :GIT-BLOB
   "c48393540f18a1982fa9523d82684488f2d0e9ed")
  (:PATH "docs/implementazione/crc32c-unroll32.md" :GIT-BLOB
   "f9b81bfbbfe41d6f0433df1275b14e0ddb277521")
  (:PATH "docs/implementazione/csn-archivio-recovery.md" :GIT-BLOB
   "0501c6e7d687db9aa0196637ea4ceb5032d398b9")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "f3c71d7a014741290c658cd958ca5d5b6e5076a7")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "6809b9ff79f77032c94c726a67913fd86ed590f4")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "87df34a5915fead7f06bff837dfa0b904f9eb664")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "ac014f8282cf46645dd18f92f16bff17ac1da0b4")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "3d69beb591d794d62111bb695cf87fc6c4726e2c")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "7979e6edd61ac9300d6560b493a61948a4fd0d92")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "62df2e33eb3daa289da2fd2d544db1e367495b76")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "2ab09dc900d919686bd211a1fc0c9e233d6d8bbe")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "26b8a34a0c455ffa1244cd8930718ad68067983d")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "475fcdde02949a8500168f29ab43891d70fe7fa9")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "7e01085ba74008ba3f3715415c7196de10efe61f")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "a2f17134ae38a241a5610af3f00051f0e1c6bca5")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "04724b6857c83e623ba245bef65c657f416bbced")
  (:PATH "docs/implementazione/decisioni-recuperate-revisione.md" :GIT-BLOB
   "e8ec567a22d4a0b7f365d7649622e9a3405e69e4")
  (:PATH "docs/implementazione/decisioni-recuperate-verifica.md" :GIT-BLOB
   "efae51de3ab17894525f9803c2caa2dab2caa737")
  (:PATH "docs/implementazione/decisioni-recuperate.md" :GIT-BLOB
   "877dab2bc85bec554965e906163a950fa7f42dbb")
  (:PATH "docs/implementazione/delta-indice-m1.md" :GIT-BLOB
   "74b4d0337972db90f897380d1acf29cf56b5387d")
  (:PATH "docs/implementazione/delta-location-m1-metodo.md" :GIT-BLOB
   "546cbb2eb9169663e412972c9ffa3dfdd7a44eb7")
  (:PATH "docs/implementazione/delta-location-m1.md" :GIT-BLOB
   "dd39d0fa56ef87edaac933052523fb1092af9891")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "23c6bd3464be1c5de0e85dd1ceef49cb072e2610")
  (:PATH "docs/implementazione/evidenze-parallele.md" :GIT-BLOB
   "c1cf798f1d7aa870e6fc08666fb089bd0078f1b2")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "9ce191f9a921d27dd12773f67b2ea9dc2b724c11")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "5988fea2f0c49b45d4da2152cd2f213f7d4a3bbe")
  (:PATH "docs/implementazione/fonti-recovery-metodo.md" :GIT-BLOB
   "71889d31dc82e1ce9cb80228debcd2aaae265ca3")
  (:PATH "docs/implementazione/fonti-recovery.md" :GIT-BLOB
   "b613cfd01ebf4f093fd8d5b4f6ea14c2c43b1156")
  (:PATH "docs/implementazione/full-text-codec-decisioni.md" :GIT-BLOB
   "d84b4a8ea730f7eb6a08f7578322a9cbab97cc27")
  (:PATH "docs/implementazione/full-text-codec.md" :GIT-BLOB
   "dd648030eb25834fe6d66bf6fb61fad777ef7906")
  (:PATH "docs/implementazione/full-text-decisioni.md" :GIT-BLOB
   "891a19e59ded15ce976428e647431e6087fcda8b")
  (:PATH "docs/implementazione/full-text-documenti-decisioni.md" :GIT-BLOB
   "6df6ad62e11ea8977a258a6e11e774488c131e97")
  (:PATH "docs/implementazione/full-text-documenti.md" :GIT-BLOB
   "813e65fa97477a4d4451c483e137540af95cd667")
  (:PATH "docs/implementazione/full-text-put-metodo.md" :GIT-BLOB
   "2526a07b957970e7abc7f6baae970c2162d9b68e")
  (:PATH "docs/implementazione/full-text-put.md" :GIT-BLOB
   "a480bcb65e37731737a70f16554ca9e5e8cf8ee0")
  (:PATH "docs/implementazione/full-text-riferimenti-metodo.md" :GIT-BLOB
   "0cb603ba80950501cb439b61b4645274188ec75d")
  (:PATH "docs/implementazione/full-text-riferimenti.md" :GIT-BLOB
   "d363ee6d5e8e55f35668fbb129c2cf1f626a6d16")
  (:PATH "docs/implementazione/full-text-righe-metodo.md" :GIT-BLOB
   "2f576876ff695c0b662b91f8deea5b3793c3bc5b")
  (:PATH "docs/implementazione/full-text-righe.md" :GIT-BLOB
   "c6b643c4cf20d6b4378f7bfe7f05132cd4ba1d10")
  (:PATH "docs/implementazione/full-text-riserve-metodo.md" :GIT-BLOB
   "17663cca4a20e28e53be920eaa83792b520354a4")
  (:PATH "docs/implementazione/full-text-riserve.md" :GIT-BLOB
   "154f11b6ffc05e72273d3ab4a0b7a5d3867ad3a7")
  (:PATH "docs/implementazione/full-text.md" :GIT-BLOB
   "10317557bc507e5b786a0564626bc3109e851c46")
  (:PATH "docs/implementazione/get-active-metodo.md" :GIT-BLOB
   "de07ae6a11977904595cd321e2fdfb229cb0bbc0")
  (:PATH "docs/implementazione/get-active-preflight-metodo.md" :GIT-BLOB
   "2557776ad0c8c99e3c479ebfd557b6c912dd503d")
  (:PATH "docs/implementazione/get-active-preflight-verifica.md" :GIT-BLOB
   "2616f8e780fbc697519bc3517591c54197bd37f5")
  (:PATH "docs/implementazione/get-active-verifica.md" :GIT-BLOB
   "f46fdd16bd2ff24d0caa1426706db284b6e9f583")
  (:PATH "docs/implementazione/get-active-vuoto.md" :GIT-BLOB
   "2616e0c8ea4cf50baefe1d17c46277a3c11b1e51")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "b290db7acff4b04c7769062bff44c91f643765cc")
  (:PATH "docs/implementazione/get-costi-metodo.md" :GIT-BLOB
   "fb1926959f835883b7d88a5dda7bdea7f30998b8")
  (:PATH "docs/implementazione/get-costi-risultati.md" :GIT-BLOB
   "655b8a35ae16b285e8c5da3ee0249d47a7629c57")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "56133e69f5a305d3d7ed173361a60d11dc8083a1")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "242e710cf037c17f94ce2c6213210b87e1cd5108")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "017acf3977bd60a59c7cc3c093c084dc5742d8d6")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "d25a0d6bb499867c8e74865f76064205c70a904a")
  (:PATH "docs/implementazione/get-fonti-serie-metodo.md" :GIT-BLOB
   "0b3f2db806973acd21c7b0cb4fe203656db06baf")
  (:PATH "docs/implementazione/get-fonti-serie-revisione.md" :GIT-BLOB
   "91c14197cca8cfa11f46b4f5e2ef5cc03e269507")
  (:PATH "docs/implementazione/get-fonti-serie.md" :GIT-BLOB
   "ef7f5f3ae5748673a74ca960d3c5bb1c6e1dd44d")
  (:PATH "docs/implementazione/get-lifetime.md" :GIT-BLOB
   "3c83a87b6b59b2432c54145ff6d8e5144c7864be")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "953b28082bc52d2925a43c6e78ef19e9cd7710b6")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "adad30953d4d419ccd39475545619fb9e32b1392")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "a85bb276b698a7c20da89fb2fb23e19aef2bf5e0")
  (:PATH "docs/implementazione/get-resolver-metodo.md" :GIT-BLOB
   "fe7942c088ae3aa68d0e15e04c9f46faf05622ac")
  (:PATH "docs/implementazione/get-resolver-verifica.md" :GIT-BLOB
   "67b906cd6e8b8569f97a766b66deebd57f4be501")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "753deeb7ec87fcfdc7c8c1275368fa947827ac37")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "5d14690cdad3e3517bcd32522fd9b26f10475eac")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "4515dcc663abeaa09a60ea4c8b3bd6df1baad2d9")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "9a6c1470083bbd595277d9a9f3b430ff0c5f85d6")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "b8204499bb41f33cea556a86eab9551f8709de40")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "695650c8c40cd1cbe9ad38eed29698b7b71ba97f")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "78a7da074a3daca5f05793f03b88fc4ce45321aa")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "c1a36112a2dbf6afef54a654c262389ba9037ba2")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "83b6d477b9d16697c2002989891657ba95ee4e6a")
  (:PATH "docs/implementazione/id-directory-recovery.md" :GIT-BLOB
   "6ea173a4f8c1210432f00d11e6ce6aae4ad1174b")
  (:PATH "docs/implementazione/id-segmento-recovery.md" :GIT-BLOB
   "f2fa99ae8a932406bb74666fa401e0aa9b2655a0")
  (:PATH "docs/implementazione/immagini-indice-paginato.md" :GIT-BLOB
   "8e88cc05ab5ee90c1a1c98d9b20859b652a97bf3")
  (:PATH "docs/implementazione/indice-automatico-completamento-metodo.md"
   :GIT-BLOB "c354d887b3102978bf827b1959e323b7d9b18b27")
  (:PATH "docs/implementazione/indice-automatico-operativo.md" :GIT-BLOB
   "e70a739bfd63091d2ba9cec5c6fd6aa821e4d669")
  (:PATH "docs/implementazione/indice-automatico-risultati.md" :GIT-BLOB
   "d8823f505faa11809cea64f9f3c90675b0198fb0")
  (:PATH "docs/implementazione/indice-automatico.md" :GIT-BLOB
   "614b528773e7b34f955143e0afea744d431e2e1e")
  (:PATH "docs/implementazione/indice-da-recovery.md" :GIT-BLOB
   "486481170704785730c471af7dfd1a5816243a04")
  (:PATH "docs/implementazione/indice-paginato-m1.md" :GIT-BLOB
   "fe476e799ce3ec29caebbecb1a112a2e04bbe2f7")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "4e34fc8e0ffc4413a921b5538edd63693281b70e")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "439aa57177f9323735aaf1e8c4677cdf17e29ad7")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "3935af00f6b06ca6fbca8ab7a8c977eab164322c")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "32dd19680071319c88e9a91a0132260e921573d2")
  (:PATH "docs/implementazione/inizializzazione-active.md" :GIT-BLOB
   "d4c99e5ce4fb98ef862944a7cc41c08205cf60f7")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "56795353bfac9ce5c3ebc0b69f704890d306c194")
  (:PATH "docs/implementazione/inventario-directory-metodo.md" :GIT-BLOB
   "1c6d345a7b2d02c2687f08474a7805e79160b615")
  (:PATH "docs/implementazione/inventario-directory-revisione.md" :GIT-BLOB
   "42511becdd73740fd1ea37f271dc7d4482ddeb74")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "caab01e598ef66377c6da22dbcec17db820b8b91")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "7fcabec950c4e85735ab5bd7960cba65d0b1b494")
  (:PATH "docs/implementazione/io-apertura-relativa-metodo.md" :GIT-BLOB
   "fa44089871f66bddf1309fa5d75b4678eef58902")
  (:PATH "docs/implementazione/io-apertura-relativa-revisione.md" :GIT-BLOB
   "8b13ab5dd4831710adfa606e5edf659e31c8a714")
  (:PATH "docs/implementazione/io-apertura-relativa.md" :GIT-BLOB
   "975eed05b2318ed9b85f4d6f860c2431248f1db7")
  (:PATH "docs/implementazione/io-completamento.md" :GIT-BLOB
   "b5982e35ea000c4c9dcc91021374849d6670638b")
  (:PATH "docs/implementazione/io-creazione-relativa-metodo.md" :GIT-BLOB
   "84b9f6ac1bf934fb7c34e178542cce9dae62fdc6")
  (:PATH "docs/implementazione/io-creazione-relativa-revisione.md" :GIT-BLOB
   "6ad24b936952f03d7a70827f10314ac7f0ad1dfb")
  (:PATH "docs/implementazione/io-creazione-relativa.md" :GIT-BLOB
   "0a0d30b8c6cf826cb906b7d7d26bc8c4c68b3b8d")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "d6eb46b50c73b0150eddbc34cc93f127e82163dc")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "92c01fe2ab85af78f2f3cbf68cdaababa61f5ed9")
  (:PATH "docs/implementazione/io-pubblicazione-metodo.md" :GIT-BLOB
   "bdf72add9058e53ae707719af4ead4d18f462946")
  (:PATH "docs/implementazione/io-pubblicazione.md" :GIT-BLOB
   "f56f5f2f22e43b665a472d8560143b9430ea9ded")
  (:PATH "docs/implementazione/io-rinomina.md" :GIT-BLOB
   "d699c8433a309044b041ec1e2a0713ddb7d6f120")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "3db1a3257313b7040dd2b1222f4de77166de75da")
  (:PATH "docs/implementazione/lettura-indice-paginato.md" :GIT-BLOB
   "ce43161a04c6068b3ddce5b8eee94f35e46c5872")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "1fa26d055d5ee76d3a9bc6f6e6e31a3af3c0e0f1")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "91b0ee252ceff9071c62a573b7b499b8e36e1964")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "4b69dba2809dc40a4d039a6106dd02e560c8e26c")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "20b9246ebddba96db237e5ebcbf2529afbd26a91")
  (:PATH "docs/implementazione/manutenzione-indice-m1.md" :GIT-BLOB
   "bcf08f6c98961ee5660483cd627244c1243f2a99")
  (:PATH "docs/implementazione/merge-main-2026-10-23.md" :GIT-BLOB
   "cb672d06673d639a152ef3bea52b73f258513473")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "332563a00301c759a56fa56efeb0c733f5d8acb5")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "daca7cad14916fbc0b10743a6898bfba4f6c47ad")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "2789dc59d0173d4e0af289cfac129ab12d1bec00")
  (:PATH "docs/implementazione/moduli.md" :GIT-BLOB
   "971b841de90347b255a3e22aaf4e7682fbe25e2d")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "48ffbd9f476751940bbae8713788bd1d812a6002")
  (:PATH "docs/implementazione/pagine-indice-risultati.md" :GIT-BLOB
   "e8889ba9c0d836e73050037bd49faa9ae016a5a6")
  (:PATH "docs/implementazione/pagine-indice.md" :GIT-BLOB
   "34c6c7dec3f852d8dc6245a6c05a7f26ef2d09a5")
  (:PATH "docs/implementazione/pool-begin-metodo.md" :GIT-BLOB
   "8d10cde6f53e6e75cd936fa109121d0caab09d5f")
  (:PATH "docs/implementazione/pool-begin-revisione.md" :GIT-BLOB
   "95657e20c25dd27baddab5c04a2053170af45b96")
  (:PATH "docs/implementazione/pool-begin-risultati.md" :GIT-BLOB
   "c4049dcf13b516abf81bbea4d32aff64cb425c7f")
  (:PATH "docs/implementazione/pool-begin.md" :GIT-BLOB
   "06bd817d57eb415225973e0981778132621cf230")
  (:PATH "docs/implementazione/pool-catena-metodo.md" :GIT-BLOB
   "758327137a15f0f1ef344d51370add33a3a2c6cd")
  (:PATH "docs/implementazione/pool-catena-risultati.md" :GIT-BLOB
   "8bf6c0fe47438107778c68195e6f98ccb42b0b9c")
  (:PATH "docs/implementazione/pool-dispatch-metodo.md" :GIT-BLOB
   "eb6709befc9bdb0d67b04fd5c4c4f98a01ab94de")
  (:PATH "docs/implementazione/pool-dispatch-revisione.md" :GIT-BLOB
   "abda6bf2dbaa1fc5fdc6e55cc22bb0ee931513f2")
  (:PATH "docs/implementazione/pool-dispatch-risultati.md" :GIT-BLOB
   "ab68af4bc1ab1552d74c694ce96c1e1c4222920f")
  (:PATH "docs/implementazione/pool-dispatch.md" :GIT-BLOB
   "a540afacd7952495cc3300e0bced676639c55337")
  (:PATH "docs/implementazione/pool-prepara-metodo.md" :GIT-BLOB
   "4da00d6f92b7f949ec8acafbd3a97dd56bbbb367")
  (:PATH "docs/implementazione/pool-prepara-revisione.md" :GIT-BLOB
   "2c5e9f14f01fedcb7e3dc7a3b4ade9b8bfdcc9b6")
  (:PATH "docs/implementazione/pool-prepara-risultati.md" :GIT-BLOB
   "8c5a986a075da0555e225369bb08b72e4994558b")
  (:PATH "docs/implementazione/pool-prepara.md" :GIT-BLOB
   "84dcb4f1603e43af42c335d58a1d67ebe6347ae0")
  (:PATH "docs/implementazione/pool-recycle-metodo.md" :GIT-BLOB
   "2c811c8f11f65e5142e23c6d8e306b44e412d1e0")
  (:PATH "docs/implementazione/pool-recycle-revisione.md" :GIT-BLOB
   "100e57b2835ce7bc6b5dc68912cf99ae1e637c30")
  (:PATH "docs/implementazione/pool-recycle-risultati.md" :GIT-BLOB
   "4a192b8293368b041956bf12a8e266bd08d86cb5")
  (:PATH "docs/implementazione/pool-recycle.md" :GIT-BLOB
   "40dcde9abd1d21cf1d0d56cecc3b66c641b607b8")
  (:PATH "docs/implementazione/pool-step-metodo.md" :GIT-BLOB
   "e44a4958a4c0a67213243b112bc7362f0573e914")
  (:PATH "docs/implementazione/pool-step-revisione.md" :GIT-BLOB
   "66ab0543f271b9a5c96cb6aa2247be4d6925fd59")
  (:PATH "docs/implementazione/pool-step-risultati.md" :GIT-BLOB
   "470c7dc02213e5d01719829413da36ec08cc5d4c")
  (:PATH "docs/implementazione/pool-step.md" :GIT-BLOB
   "09a4edba6f17bed9682708707ecbe188b2b8e101")
  (:PATH "docs/implementazione/pool-worker-claim-metodo.md" :GIT-BLOB
   "b1b933f896ebb4b2c54a2a714a4c4291c431662d")
  (:PATH "docs/implementazione/pool-worker-claim-revisione.md" :GIT-BLOB
   "18aef79552d243af35866c3d2955e2d11761935d")
  (:PATH "docs/implementazione/pool-worker-claim-risultati.md" :GIT-BLOB
   "f0ce19f06da992cf25de5b3dd396258b7197105c")
  (:PATH "docs/implementazione/pool-worker-claim.md" :GIT-BLOB
   "5a69ddd2dad8066ee9d03792f8548abb9225222f")
  (:PATH "docs/implementazione/pool-worker-lifecycle-metodo.md" :GIT-BLOB
   "d32a1e07253c9138b176912091366712ff3037a4")
  (:PATH "docs/implementazione/pool-worker-lifecycle-revisione.md" :GIT-BLOB
   "9638731f43392e0a33b7f4ed84b19d6c46d1b0fa")
  (:PATH "docs/implementazione/pool-worker-lifecycle-risultati.md" :GIT-BLOB
   "d26d034ded38c3feb056a5a272e5147d790b36f6")
  (:PATH "docs/implementazione/pool-worker-lifecycle.md" :GIT-BLOB
   "5a1af3956ec7cb503cfe7b561acc66e3b32029ad")
  (:PATH "docs/implementazione/prestazioni-local-m1.md" :GIT-BLOB
   "d09055552b7b9fa8d15cd552465dc1025defa2d6")
  (:PATH "docs/implementazione/production-engine-bootstrap-metodo.md" :GIT-BLOB
   "92ea9255903acb119f72d1a61affda35f94a9358")
  (:PATH "docs/implementazione/production-engine-bootstrap.md" :GIT-BLOB
   "f0ee1cad927d984d0f7768e6756cf98ff61dae85")
  (:PATH "docs/implementazione/production-unix-m1.md" :GIT-BLOB
   "7a8cd83317053d2131783e3faf7c75b2deb8f002")
  (:PATH "docs/implementazione/prova-verticale.md" :GIT-BLOB
   "3b9642adce018f1bba63fca6cfaad10924f0351f")
  (:PATH "docs/implementazione/pubblicazione-control.md" :GIT-BLOB
   "8dee23aebeb7bd74de78153bff357b6810162ca0")
  (:PATH "docs/implementazione/raccolta-comandi-risultati.md" :GIT-BLOB
   "0e8a853a5618a1906dd4adbb7c9b18840959d03e")
  (:PATH "docs/implementazione/raccolta-comandi.md" :GIT-BLOB
   "69a9ac538805c31b2857a55f2d5b5c32c0a71b38")
  (:PATH "docs/implementazione/recovery-archivio.md" :GIT-BLOB
   "728fcfa388c5032d170b4f1924b6d614857baee7")
  (:PATH "docs/implementazione/recovery-csn.md" :GIT-BLOB
   "0a3b62e567853df795b710c8e080e3e4319d5153")
  (:PATH "docs/implementazione/recovery-serie.md" :GIT-BLOB
   "fb61bc33d840d815c72dcb3eb4c74c909708d42c")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "09620fc2b2248bec312b075e411f6864a5ebf16f")
  (:PATH "docs/implementazione/replay-closed.md" :GIT-BLOB
   "bb4499a07188b2887c5960e3eba59c951d80a159")
  (:PATH "docs/implementazione/rinnovo-automatico-m1-metodo.md" :GIT-BLOB
   "061f7030b0c9486754cea7333ee3838cf5f00e59")
  (:PATH "docs/implementazione/rinnovo-automatico-m1.md" :GIT-BLOB
   "29fbd690f61f74593e280c1be93b64d74b2609cd")
  (:PATH "docs/implementazione/rinnovo-indice-m1.md" :GIT-BLOB
   "048fb5e263d00771553c8de699ebe0e585c9c780")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "d7b9c49b07bae6f01a5562d15a2cdabcbb979878")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "2709d9ad98b8dd8028b36f0163ba09bf2f49ae14")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "fa341fd666506b060c4d1253773dd87859014238")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "569fb428d702f4a60440c10cb0d9a1a360670fd1")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "ac6b5e1ea180807849dc24481de16eb79e4999af")
  (:PATH "docs/implementazione/runtime-archivio-revisione.md" :GIT-BLOB
   "bba7a3fa2b7e2139ea24ec86cc97fb4b02909aff")
  (:PATH "docs/implementazione/runtime-archivio.md" :GIT-BLOB
   "f8efbf185c6e21920a72d7982f396f5f6e4360d8")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "54739f1b4f681ee51b684fd5f1706028a8922b11")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "24f4832f44e05b4958ee59a8b9b899228f5afa6d")
  (:PATH "docs/implementazione/scoperta-indice-local-m1.md" :GIT-BLOB
   "c6a2000090f8bf5b356b49804799739acccd1344")
  (:PATH "docs/implementazione/scoperta-indice-m1.md" :GIT-BLOB
   "4f05d679dfd56ea2922507433e26c876de136b00")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "40197f19d765e646a0e3ce558386997294130ab1")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "16a6ec600581f9c958650a8578117ad7d7d79584")
  (:PATH "docs/implementazione/selezione-versioni-recovery.md" :GIT-BLOB
   "47d2caa2887778182456420705e0228179305769")
  (:PATH "docs/implementazione/sessione-locale.md" :GIT-BLOB
   "2ecf722d1f5009738a021d2b451e71bfcf0a6c2a")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "3badf8773cc33d0a772b9bde5741af120be1db29")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "52ce3f078d06cad8ffac89ea2baa6ad830c0df34")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "d0ce2c9951518f30ccec2391bc8d9e3e508eaa19")
  (:PATH "docs/implementazione/stabilizzazione-archivio-metodo.md" :GIT-BLOB
   "e29923b3ea68b49f0d100baa7b41f221663d26f9")
  (:PATH "docs/implementazione/stabilizzazione-archivio.md" :GIT-BLOB
   "51adacc370255a8a7d7bb9cb32d5efd9d98cc21f")
  (:PATH "docs/implementazione/stabilizzazione-esclusiva-metodo.md" :GIT-BLOB
   "862b15afa8262596760a2b84e08ba266369e101a")
  (:PATH "docs/implementazione/stabilizzazione-nomi-recovery.md" :GIT-BLOB
   "19c7b3f57ea810a35ebe212071e06e27f61c3a21")
  (:PATH "docs/implementazione/stabilizzazione-serie-metodo.md" :GIT-BLOB
   "89673b60a8a5690b772ef365b2194470238efd14")
  (:PATH "docs/implementazione/stabilizzazione-serie.md" :GIT-BLOB
   "960b956f4841ce0d3a6e38612feee69f2666ab37")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "ec3c6b8f92c54a84bc98d5ac21e58758152de542")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "a60c8e7ee23f78e8a53a516e2c161fc0827ff699")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "e7cf6d0c9962ed26216d07d63d052d45bb9f03e7")
  (:PATH "docs/implementazione/verificatore-offline-m1.md" :GIT-BLOB
   "acb6d215ca675bd8fb4108a1fc93d4009cc9b69e")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "1a94e0e95ab7446193da420d97bedc24a721d387")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "8ab0ba990681d1b185ab87aad114593c0abb305a")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "f08e66f8b7925a5bcec55f2edf1380fc66d6c0a2")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "353a2d053b16ec57b6572aed1f17d1b49d8a232f")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "15c437c7c71674f8fc1cd5a72b3162f4f1715eba")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "e20c5c59567d8ce4800dc19e8dc5fdc2f7f0606f")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "f4edff819e12b287df3cf5f00ecd3550e930f9e0")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "1c4fb7c470a4cfbc6509ccb1c6f793e8bf74208c")
  (:PATH "docs/implementazione/worker-cbor-interleaving.md" :GIT-BLOB
   "02c902149e07d4ac4dfc6f6170799eb34574f09a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "ab3e69cc7051d3ce33f9b4d94cd0e2b20b49807c")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "2c5bcfdaa1783a21adba6911300d0baf7d12f339")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "8fcb335ad6bc807d58ab2ec9033f948421737de5")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "8fa6801e99ffb1abca08a0861883ace20672bd2c")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "63c27916925bec8cfbc39c0c9d558eb444e6dad2")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "f35b46574ff72f1ddac7498c601be30c990d859e")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "ebea51d87dc4f0c750be5834f48d66aac19c7e2d")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "9cd61461e8bfad2d757011db0307229f1517a0d2")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "865c639e5d48a0a77133b6fbe033d78113f703ac")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "1dd65b133120e4f660ed14e674caa8d9af55cfc9")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "4812ec2f65bf772695877b5760a2528fb69a70ef")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "debe8bfd28a95306a16004ca1ccb20ff2bf85fd6")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "7a1ffa13a41b58db26e43bb4090a5d7b6732e512")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "f0ab347bf7c6974b7968e96b9615238b2b14713d")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "b3d19a3668170d14b2ee8a1cec101a27334a8d41")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "14bca7f6cd2c9976cbfdbe3a24a146bc46a34d79")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "f0fd5c63f1adaf9e08e3a7f03dd3fa62bc10aea5")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "c96e7d84ba793911aca73e1deafe6da49509b879")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "8543024839bb87730a16489183b141a010d48cfc")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "234ef34a0065f902f68cdc9432513444a303731c")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ae34240b8fcb8fecbda5492828281de203dc5327")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "07bc53c1a476b0f93bf860fa18c97573d96c656f")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "e120e67c134bd2b9ddbbf55259f5195a3ef4989c")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "85cdbcee3cc2985f6935c6508b71ae9eccf58c99")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "a7329d98d65dd7a94773a87d27f7e3d3871469bf")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "370e2848280af70fbee9085f4c5f1fb44b110889")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "3a9260af22a77d11d636a787613bd50668ffc1cd")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "1600a7f92e73a45f44214bfb2074d0c5cf6decec")
  (:PATH "docs/legal/README.md" :GIT-BLOB
   "149c30dbb116c197f5046d245f765803ed6112f4")
  (:PATH "docs/legal/accessibility.md" :GIT-BLOB
   "f0075a299d3f10c36f250343da01908f39bfc447")
  (:PATH "docs/legal/distribution.md" :GIT-BLOB
   "60ae06a99a28b346e28a28dba81925e38b762192")
  (:PATH "docs/legal/privacy.md" :GIT-BLOB
   "668c2ffde82f4149697d070851e5fdbf281937b0")
  (:PATH "docs/legal/review-2026-10-31.md" :GIT-BLOB
   "8e4053b788081e583340d3531e8c618eba2ef312")
  (:PATH "docs/legal/third-party.md" :GIT-BLOB
   "308d64af3e3901e8c8ea6209ec772f65bd55796e")
  (:PATH "docs/limiti.md" :GIT-BLOB "18a03d0c1262b4ddaddf5ff1cb3dd1777f216c3c")
  (:PATH "docs/lisp-api.md" :GIT-BLOB
   "a53a254f4225afdd5d59dffc7aebeb158b40bec3")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "f639c868ec4145ce4d712345973822ada77abb6a")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "6c2425c43abbc961ab2845fca2e3ea069b39eb81")
  (:PATH "docs/riferimenti.md" :GIT-BLOB
   "9addadca061376e75319617301e590e010ab8467")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "6b24c490e7a4e90e7d0d751c0796f89a23849c39")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "113bbeaa93a2032b3a642d626836c1d5f5d16c4f")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "df1e19c126d44b07fecbf153fcafa2c9af44e861")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "aef527376c8e9d22207168aa935b6acb10b2b528")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "1ae3fc90e1a01aa296c51d3f25c6d65c1bcdb5da")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "b7ef23de41612f981d34a97641e52902a1840a50")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "33f78a2faae61cd73459658d3ba2a88e2ecafe81")
  (:PATH "docs/valutazione/caso-duso-nntp.md" :GIT-BLOB
   "b6a035e1d66b869f40a42e07f2021a42d7de2859")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "972ca495cf51f54d16f3c33ca31fe890b6db7806")
  (:PATH "docs/valutazione/cronologia.md" :GIT-BLOB
   "be43f507343a1c75d71d9e4ada287a9c2fc0de12")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "32026027782790da44884b029c4bae89d5f4e1fd")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "32e72f3b579ee02d5a5e0e897a7618434b02e60d")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "2eeb123c80d9f061d21d2f1a31c57613d7707506")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "a01e78e3fd9dbfe2705fa6fda631d9c387b3bc91")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "c3173768fe23a50691d7106bddbc8c46bb8cd040")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "ed0b8c472645dd6e31178034268a7e60a34e09be")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "603665f1033eb1a62f8b9a4115250a16cf39b429")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "dca0a8b0aa20c8d038dcbc11023182fd552de10f")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "45bf66ebba21b28f569e6f12344277dce7245cd9")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "11d712a7a3432a89299a2f5d7f23736d596d7e40")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "f3eecb3e77252633aac4a62f1100a77b64ca91e0")
  (:PATH "examples/local-roundtrip.lisp" :GIT-BLOB
   "f814d10935f22272e5a440e92e7c8109dda16be8")
  (:PATH "legal/algorithms/xxHash-v0.8.3-NOTICES.txt" :GIT-BLOB
   "1ac346f5f0bff517073cca31f1509f39a5818d55")
  (:PATH "legal/notice-files.lisp" :GIT-BLOB
   "30a68c858f462c6ef601c270ac48603374b149d9")
  (:PATH "legal/runtime/SBCL-2.6.9-COPYING.txt" :GIT-BLOB
   "4220b33974e7fc04036b2b5600cb3ca88ce2c4c3")
  (:PATH "spikes/README.md" :GIT-BLOB
   "f835fdd46c43312889de749d525290e541e891f3")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "c2c2487c33cadbec5444b81073eb9e417a16c42f")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "03a90c690b4673695f0380f81f0cf68e4da8eda4")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "049ff2032103d3d6a6a8049fa9d803d6f82beeaf")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "cd79005b8100b79cbbca35a5677125af54f5e854")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "b388bbb2a067537c8b03b046d63ed6fd5201fa58")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "be57e2f216618fb65d5dde48e8d29938d377a009")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "6452906fa525035cf6abe7967f05778aeaf17f76")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "014f488b7b50a9439b36f49afd6b6f0f11295d84")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "badf96cfb95709afc9174e40b521ac75c6adac8c")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "1a46426b6521ca207a747cd0d2a7fed0ad4ecfd1")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "0061c53057783cc076b2dcb9596e91017e473c47")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "7edbb7459ca78fb41cb812d82ce1dc1c68176ea6")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "18246e75e94db5f4517e96e827469d6a006b30d2")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "0597672e814ccc60c541439e838b7e4eb491788a")
  (:PATH "spikes/SPK-07-protocols/metodo-page-lifetime.md" :GIT-BLOB
   "fba367b24467642a6e544ff86e099b143a73a925")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "6c0034a70670b4249cd2b525c9fca3e140dbd94e")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "517286df830984ba4a6ff39b03175e445afd65d7")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "163e4c3222c4e5771660e6463367ec6b1bc914af")
  (:PATH "spikes/SPK-07-protocols/page-lifetime.lisp" :GIT-BLOB
   "c032387167188be066737f75583738843b12c883")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "1ec5a1db56a76daacbc7488d8b7940aa0e16eca0")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "95ab6095de30d013dbf5c426f7b6c0a99d5663e6")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "9daf0b57d92db583544653384217105121c8627d")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "4712fb08742000724dbbf5c1f7fac4505ca6ad4c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/comparison.lisp" :GIT-BLOB
   "b8b8ebfa609d6bfe9b710833f22cdff693ef46bd")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/crc32c-unroll32.lisp" :GIT-BLOB
   "6dbbe7218c7b5185329f099a8c1407e0f48d8648")
  (:PATH "spikes/SPK-08-generated-code/crc32c.lisp" :GIT-BLOB
   "72bccfafe9c5cb0fd5dc6392534c5be404774a64")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "680b5d9c4e112747e903e124e07cab8adbf97da9")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c-unroll32.md" :GIT-BLOB
   "d722f4f0145cca93b8cb46aa0572538df99a12e0")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c.md" :GIT-BLOB
   "fbbb491611d807c1022c50236fe29c8d7accb2c0")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "4a57493b511201112c533418f1846acdf96f35c8")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "1bbf37c97bcc7d527c3d5aa90cbb9217b807f3ee")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c-unroll32.lisp" :GIT-BLOB
   "79033530456f565b3b14e25b56146039b5356860")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c.lisp" :GIT-BLOB
   "a45f0c3e862c2174b64ac63d4ca97ae3ddf21569")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "7c797afe4a6060782ce58f0cfc06f539006d117a")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "2ed0e101d31cef0967820fc70155ddd4561140fa")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "740e01ad7ddd2dc170e50454befe9a63b9eff276")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "1e54780546d2bcdd623f7fa6c2faaf127bf15dae")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69ac8ef15f356257dae151e035689d8124e9a9eb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "95928362ab8fbde280a5f74be905ae2ca58729ab")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "df0869dea4916cdb5b671a79ffa812369d043773")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "spikes/SPK-11-unix-socket/README.md" :GIT-BLOB
   "47d0cf7d3d5b5541e38cb47814dbb1f0197ffbdc")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "spikes/SPK-11-unix-socket/core.lisp" :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/native-io-method.md" :GIT-BLOB
   "a90da59a3ecad08654d619a56c2ced177db88a40")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-method.md" :GIT-BLOB
   "ebd5dce74e96860ace17a05cf7e14f940adb126f")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/core-code-review.lisp" :GIT-BLOB
   "894a03026e1d4c55f8bde65ba79d64e2775d1826")
  (:PATH "spikes/evidence/README.md" :GIT-BLOB
   "d0dd48506d19490ae1c864f86f4606845241a15d")
  (:PATH "spikes/evidence/history.lisp" :GIT-BLOB
   "f210350eb462c1f3d45f24217f004775496b0eaa")
  (:PATH "spikes/evidence/snapshot.lisp" :GIT-BLOB
   "9ea68544e9490d6598d6361ae0bac6e27a69ce4e")
  (:PATH "spikes/verify-m1-check.lisp" :GIT-BLOB
   "5ec3e4bf45087fec1fd8f878f746dfec63bbb1ab")
  (:PATH "src/active/package.lisp" :GIT-BLOB
   "fbd3a32b30808508424c007ece26c9f3ea9ad0a9")
  (:PATH "src/active/preflight.lisp" :GIT-BLOB
   "9a7da536a7286f5996bf1720db7f9b9dbf20abff")
  (:PATH "src/active/prepare.lisp" :GIT-BLOB
   "e6739a357bdce50ca6bfda7dcd147ce8ffb790fd")
  (:PATH "src/active/source.lisp" :GIT-BLOB
   "27316c9e39b54ff4b2f6b4fe491ab7e67197a950")
  (:PATH "src/active/types.lisp" :GIT-BLOB
   "fc4c2d3ac0839aab37b91d4e017cdaf18bc5041e")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "b0230656edbe3dea63568e74a97e5193cab7c54a")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "a1db79505e00f465b0f0debacbcbd8aad60c5b75")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9725836f0c142b5e292fea4d073f5fbc52b99825")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "84b090e318216a832ab684fc5a936c68e465c169")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "93ecc29914d02b4b6066896de8c2590906ca91bc")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "03bdfeeef2e2639030d3509bd6905364c55f345a")
  (:PATH "src/codec/cbor-array-input.lisp" :GIT-BLOB
   "1b028f9e5f945266f1144b664bf206e89f603863")
  (:PATH "src/codec/cbor-array-write.lisp" :GIT-BLOB
   "625b61e204f7485e1015d109426810ef9d92827c")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-float-narrow.lisp" :GIT-BLOB
   "a2424c60204a55c7ec315de4446e41e243a1afca")
  (:PATH "src/codec/cbor-float-write.lisp" :GIT-BLOB
   "5a44cea28eb51016ce5155ebdf5750b93d15a1b3")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-item-read.lisp" :GIT-BLOB
   "e95db7d9f407e9e0039dc8892e4af8065490d99d")
  (:PATH "src/codec/cbor-map-input.lisp" :GIT-BLOB
   "87c9fd9dd6eb1f3ee1b79bdf2957801762601d97")
  (:PATH "src/codec/cbor-map-write.lisp" :GIT-BLOB
   "84887090a1fa543da817bd096528b576f3d58d9e")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "d9c686fef43c16c5cbf85672b2480a3d0340edfc")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-string-read.lisp" :GIT-BLOB
   "446498b0f3b0f014471312eeb01b3d9a254b6535")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a9028c0b30a22367baad2711346a5517089b1940")
  (:PATH "src/codec/cbor-tag-input.lisp" :GIT-BLOB
   "760e81952f8eb3210465a6cea5c0b89c3f15c5a4")
  (:PATH "src/codec/cbor-tag-write.lisp" :GIT-BLOB
   "4680d759cf12aaa61df5823cb86e71ed7379914c")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "159033291735d23258b340f8da17ad6bd001ccbf")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/control/build.lisp" :GIT-BLOB
   "d5aca4f9ade3c126e88709f1ada1a9e39132b6a1")
  (:PATH "src/control/dependency.lisp" :GIT-BLOB
   "144f908c5cafddc397dd8a1cab04cd641d93a32c")
  (:PATH "src/control/package.lisp" :GIT-BLOB
   "e56a6bb83abe9441350baa46573d74c6d55edf4e")
  (:PATH "src/control/preflight.lisp" :GIT-BLOB
   "850a8f3bedb592dad251e36d7e95ad9fa993979d")
  (:PATH "src/control/prepare.lisp" :GIT-BLOB
   "51cdc2f60ef3da074e98f5bbabd1bb1b4ffbd6ed")
  (:PATH "src/control/publication-read.lisp" :GIT-BLOB
   "a5ebb2f8fafe283f3816d48e633ef8471bfbf4ba")
  (:PATH "src/control/publication.lisp" :GIT-BLOB
   "c8c482c65af3a94bea9acc38b3b93f04933c93b1")
  (:PATH "src/control/recovery-publication.lisp" :GIT-BLOB
   "b01545b6647f5dbac8097dcab394260fb7f9d3cd")
  (:PATH "src/control/recovery-read.lisp" :GIT-BLOB
   "430665c20905e5f7d67245e2d7503bb0f9e0c11f")
  (:PATH "src/control/recovery-types.lisp" :GIT-BLOB
   "2ac4f985eec224f17cea5658cd9d42f4aed99cce")
  (:PATH "src/control/transfer.lisp" :GIT-BLOB
   "69bb7c2e27817201c5533fa4d6099a26750a38b7")
  (:PATH "src/control/types.lisp" :GIT-BLOB
   "7eaa6e2298ac264b7d64c1f7a78de8d1fab8ce09")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "c2ff554d80181b48d8ba414e9d2c6a84080cb413")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "c46fd76164808980af1d8b639890b3cc0ce8fb79")
  (:PATH "src/dispatch/begin.lisp" :GIT-BLOB
   "bb45bcad39e438aa082e92d01358d1059cc5fd20")
  (:PATH "src/dispatch/build.lisp" :GIT-BLOB
   "9d1c974830e92918b572af978e8a2b4acae257b6")
  (:PATH "src/dispatch/claim.lisp" :GIT-BLOB
   "a9d55f610fbd14b5bff7f9d6c2a6c8abb7ba405c")
  (:PATH "src/dispatch/package.lisp" :GIT-BLOB
   "db21c798588ff4a88be5b69b5fbe72bc84811a46")
  (:PATH "src/dispatch/recycle.lisp" :GIT-BLOB
   "57955f63a0cfc4efc3f7f742fd479c032dcec5b2")
  (:PATH "src/dispatch/start.lisp" :GIT-BLOB
   "4d519c9fba0c085d5789c2883c8d04079e3933ea")
  (:PATH "src/dispatch/step.lisp" :GIT-BLOB
   "36c8c1e84c7329f4a0b24186e09a40b2ce2d2b61")
  (:PATH "src/dispatch/types.lisp" :GIT-BLOB
   "6f3b3841a3158cac6daf70cc8a1ae3984f52566c")
  (:PATH "src/engine/adopt.lisp" :GIT-BLOB
   "e91cde14fcff879a1858b28c6063e5188dca4da0")
  (:PATH "src/engine/compaction-control.lisp" :GIT-BLOB
   "02cbb0127a3e9519ed0dc90730f077ade17fb5dd")
  (:PATH "src/engine/compaction-install.lisp" :GIT-BLOB
   "167777a12cf87a02b36a73c5609d098d9d8d1b46")
  (:PATH "src/engine/compaction-plan.lisp" :GIT-BLOB
   "d255c8440ee3abb0c190801e7c5b2e1a4872b47e")
  (:PATH "src/engine/compaction-reclaim.lisp" :GIT-BLOB
   "00076045f47b9b8a5a4a0aeee449a3a0cc5e2047")
  (:PATH "src/engine/compaction-relocate.lisp" :GIT-BLOB
   "3f316d79bf63b30bb5fa0cbac38927cf2a6e540d")
  (:PATH "src/engine/compaction-scan.lisp" :GIT-BLOB
   "942e0b2ba2be30a2e94efa1c80564dd7159e322a")
  (:PATH "src/engine/compaction-types.lisp" :GIT-BLOB
   "ee6f36958a147af9cdabdfee2ebe77752476da74")
  (:PATH "src/engine/compaction-verify.lisp" :GIT-BLOB
   "57628bb40f5be4c42b4366e81a0662f7f98c0137")
  (:PATH "src/engine/compaction-write.lisp" :GIT-BLOB
   "41cc966628e64d765c8a8f9d132321451025a3bd")
  (:PATH "src/engine/compaction.lisp" :GIT-BLOB
   "1eac672cf412fc36ae6fbfe5d8b4e7b93dcf480e")
  (:PATH "src/engine/config.lisp" :GIT-BLOB
   "354198f7b04489a46d0a67018d181a4c8668a42e")
  (:PATH "src/engine/delta-location.lisp" :GIT-BLOB
   "367601a853f8d2dd155b1dc0002b86d1b4bcdd5b")
  (:PATH "src/engine/delta-types.lisp" :GIT-BLOB
   "539f08cdb3736546b2b1556f81050d6c5d09ece9")
  (:PATH "src/engine/delta.lisp" :GIT-BLOB
   "b865dc6c8be351c3e89fcddbce61a4e0d7a2dd5d")
  (:PATH "src/engine/files.lisp" :GIT-BLOB
   "eda0f6adb8eb34225b6775b8ef666224e753deda")
  (:PATH "src/engine/image-activation.lisp" :GIT-BLOB
   "51ef93215340364bc2c881f3e7efa6a47aac6aa8")
  (:PATH "src/engine/image-auto-types.lisp" :GIT-BLOB
   "8879e3aa9b00d18cb138da9ca6d04028816502af")
  (:PATH "src/engine/image-auto-write.lisp" :GIT-BLOB
   "ac1ad97829a4b076b6f223e9e010c55752bf3066")
  (:PATH "src/engine/image-auto.lisp" :GIT-BLOB
   "0449392da3326308f5697fc231d24d329a691db8")
  (:PATH "src/engine/image-build-io.lisp" :GIT-BLOB
   "fbd185cd56d4d980575c4d0fec5597b715074f61")
  (:PATH "src/engine/image-build-plan.lisp" :GIT-BLOB
   "ccd01ee41d0d7a103680785731c5271a54f6f2df")
  (:PATH "src/engine/image-build-read.lisp" :GIT-BLOB
   "b11e63f292b93ddaee8b0c645d525a175a1906b0")
  (:PATH "src/engine/image-build-tree.lisp" :GIT-BLOB
   "d9a657c2fbdbb294e34fe8ba40c4fe8c8df11f03")
  (:PATH "src/engine/image-build-types.lisp" :GIT-BLOB
   "d2aacfe57703a7a99354657e4823a641d6eabb43")
  (:PATH "src/engine/image-build.lisp" :GIT-BLOB
   "a4c8ad027a796610299f457399f566ac0ca4284d")
  (:PATH "src/engine/image-config.lisp" :GIT-BLOB
   "47becee77666bb573500cc1d23735e627e65411b")
  (:PATH "src/engine/image-discovery-config.lisp" :GIT-BLOB
   "66c7f2c7f7eb87e0147d858c11787ffdd06b14bb")
  (:PATH "src/engine/image-discovery.lisp" :GIT-BLOB
   "aa41ecbc41a335a25fd3f62761147be516ebce6c")
  (:PATH "src/engine/image-maintenance-config.lisp" :GIT-BLOB
   "cbd5f1cdde00a60ee8cd952898c06e205c8edf1c")
  (:PATH "src/engine/image-maintenance.lisp" :GIT-BLOB
   "44bdff3e98ff1176b51b1bbc20bb8f54b94f5f3d")
  (:PATH "src/engine/image-recovery.lisp" :GIT-BLOB
   "f42286cf6d43cd486d9c4a79f764c99c35e2aa37")
  (:PATH "src/engine/image-renewal.lisp" :GIT-BLOB
   "0e6c21fcdec1d316551417b024e1ba5bda472abc")
  (:PATH "src/engine/image-source.lisp" :GIT-BLOB
   "8b7c7ecdebbf07ada9b68037976be5af53a6a106")
  (:PATH "src/engine/index-auto-api.lisp" :GIT-BLOB
   "1241871a3195c1c42b890e08373803a816809817")
  (:PATH "src/engine/index-auto-apply.lisp" :GIT-BLOB
   "7062c70c0f6322cda8de3f089bab2a216dae3d44")
  (:PATH "src/engine/index-auto-files.lisp" :GIT-BLOB
   "2c79ded6eb822d4f238f31cd7756bcdc79d5be7d")
  (:PATH "src/engine/index-auto-memory.lisp" :GIT-BLOB
   "8199f78030cc2d21af63d223c7d9cb99cb22b4fb")
  (:PATH "src/engine/index-auto-migrate.lisp" :GIT-BLOB
   "52e44cd130f7dc77bf6fa0be130dfc4827b4ec59")
  (:PATH "src/engine/index-auto-resolver.lisp" :GIT-BLOB
   "82554d4e3b9382c60bbdb0cf2986a4e75af1dafa")
  (:PATH "src/engine/index-auto-types.lisp" :GIT-BLOB
   "7d848c894841cdcf2abf615cd8140568a264351c")
  (:PATH "src/engine/index.lisp" :GIT-BLOB
   "650e3e008a6e489ebc3972366724edab5a3189c0")
  (:PATH "src/engine/initialize.lisp" :GIT-BLOB
   "8c39b866a402a30b1aa1ef7409e675f367e4ec97")
  (:PATH "src/engine/lifecycle.lisp" :GIT-BLOB
   "717898da19e3288ee03ac782959c23d32c9b8170")
  (:PATH "src/engine/package.lisp" :GIT-BLOB
   "b92f6f86fa3c2b744a281af0f48a45b07d9fd29c")
  (:PATH "src/engine/preflight.lisp" :GIT-BLOB
   "272b6ffeb63fa9536bade7a0fd48764340128e4c")
  (:PATH "src/engine/read.lisp" :GIT-BLOB
   "658f1224eabea55171889037f09cbd030c9836c9")
  (:PATH "src/engine/record-cache.lisp" :GIT-BLOB
   "6d00296bffb12094dafd46a4ac898c9a20f81dfa")
  (:PATH "src/engine/recovery.lisp" :GIT-BLOB
   "05b64c0a49c59c209af8bac92f6823c193a92122")
  (:PATH "src/engine/rotation.lisp" :GIT-BLOB
   "db73c93ab163dc4cf2699cb6c357cfa3591be092")
  (:PATH "src/engine/startup.lisp" :GIT-BLOB
   "5245c459ca92fa0f69ff1810befc748fbb303f7f")
  (:PATH "src/engine/types.lisp" :GIT-BLOB
   "b3c3d38211888a9f971eaf78370ad4f93250ee79")
  (:PATH "src/engine/write-group-build.lisp" :GIT-BLOB
   "20a777cd92be4b8f91dad208132945c42309496c")
  (:PATH "src/engine/write-group-commit.lisp" :GIT-BLOB
   "18a21f787b8bdb1f41dd4f1ee3e215253cd62c0c")
  (:PATH "src/engine/write-group-index.lisp" :GIT-BLOB
   "b28196235d2b2853edbe75fcb5d024c0e7ea1b11")
  (:PATH "src/engine/write-group-legacy.lisp" :GIT-BLOB
   "a0c17966476bfa9d5a008bec9b6071c91070040f")
  (:PATH "src/engine/write-group-plan.lisp" :GIT-BLOB
   "d126d7176bef13a8dc19bac5836581cb65dfbd35")
  (:PATH "src/engine/write-group-types.lisp" :GIT-BLOB
   "2f1e78aef52cbdb0aabc663873b832eb31713bba")
  (:PATH "src/engine/write-group.lisp" :GIT-BLOB
   "bacee8da25a18c7736921c10357a344394eb5ed8")
  (:PATH "src/engine/write.lisp" :GIT-BLOB
   "3b83c17a8bf510c110648b4257fe9b8df43b6bf5")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "93dbc244d3e8a86e64254b31e2954102f65ab149")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "0fc4c81f23e27dabfe52485a3976ec3eb390eb4c")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "e0d503d2ad85689ac6162636857f4e44f2b5c7f9")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "474ddacfc871629aad94b6d59b87de7cd4349475")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "838611d288696767dc539b155fcfefe3feec79e2")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "bbed8c36a799b57baebe6350dd96c3a968dd05e7")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "b27df62179c9f43132c445c82f0c2bf4ee78f366")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "5d4e27472170bfffa85a6e8aac0760236e7fefb6")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "f79bbd85269d50eb929816276353b2fbb85f92c9")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "a36b9bc921e8d58f9cf3a10a8426eb388e710226")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "c066712083a07bc574481ae3a3cdcc996c9303a8")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "3c970d0cbd3866d837c07bd03d7e4e0fae24f21f")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "c048d0e7321d26e5ec3ec4eb7d3bd79b4714aef5")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "7170e6de30721bcb89cb94b56e9d3c579a1269be")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8be80a716738875d5e6fe056c5f3c81d2ffad2e5")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "5560532f4cae67478c11adc65e632cfe3da10ad7")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/crc32c-native.lisp" :GIT-BLOB
   "2e80dc72cce0064a460b8ee78970acae71a9da35")
  (:PATH "src/foundation/crc32c-vops.lisp" :GIT-BLOB
   "0677d1d29c7fc16dbd8bda529cffa5f1076327a8")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "3dee5a43950d683f83deffaa6f329d6dcbc6cfc2")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "6fca7bd583990cf07093243c95f399d294b74d45")
  (:PATH "src/fulltext-admission/build.lisp" :GIT-BLOB
   "ba813f4178d646f412363e8b3f86f7309878a4a1")
  (:PATH "src/fulltext-admission/copy.lisp" :GIT-BLOB
   "43488c42525991544b355bfc061c2c753e866c88")
  (:PATH "src/fulltext-admission/guards.lisp" :GIT-BLOB
   "c4734194dc53a5f98397bd0b35079c5739f95a41")
  (:PATH "src/fulltext-admission/lifecycle.lisp" :GIT-BLOB
   "088b775f74cf633ecb3b84a0c0b9445209cc4b93")
  (:PATH "src/fulltext-admission/package.lisp" :GIT-BLOB
   "74d06aa6d0d0b263b806f678b23cec40b5db3ef1")
  (:PATH "src/fulltext-admission/preflight.lisp" :GIT-BLOB
   "eeff3e04503f0dac81da9816112f2da68e384dc2")
  (:PATH "src/fulltext-admission/query.lisp" :GIT-BLOB
   "a8aac3c938ada73cb2b18abfaf44d7bc1ff4cfa5")
  (:PATH "src/fulltext-admission/reserve.lisp" :GIT-BLOB
   "374c03ecf29417aad8e760dd432ff3e5a6383e4c")
  (:PATH "src/fulltext-admission/row-update.lisp" :GIT-BLOB
   "1d77f5d5c6e1ddb8ab08136d7d7afaf1f79a7f79")
  (:PATH "src/fulltext-admission/rows.lisp" :GIT-BLOB
   "f1c6dc8236477b5de6b2f0e5db4bab8a02fcbe95")
  (:PATH "src/fulltext-admission/types.lisp" :GIT-BLOB
   "b4766a5b561c1a1f3e53bfc9485f72b128dfb1d1")
  (:PATH "src/fulltext-put/append.lisp" :GIT-BLOB
   "df244937278aebfabba27f14555b36476e6d9858")
  (:PATH "src/fulltext-put/binding.lisp" :GIT-BLOB
   "c47d939287b3be63ec090d24bd64903556b2b86a")
  (:PATH "src/fulltext-put/build.lisp" :GIT-BLOB
   "1f4113fb6ce043099672cf72c995b976c9543cea")
  (:PATH "src/fulltext-put/package.lisp" :GIT-BLOB
   "0ffd3fb459d14ef6da0ab6789930b8ee54b78fe5")
  (:PATH "src/fulltext-put/physical-header.lisp" :GIT-BLOB
   "8fbb48b2ceb0ccb9c73b9344e14fbb025174b7e4")
  (:PATH "src/fulltext-put/physical.lisp" :GIT-BLOB
   "f7a1a29690b384cdd8bf791e62ac2d98deb7495b")
  (:PATH "src/fulltext-put/prepare.lisp" :GIT-BLOB
   "5a6929f64ba29f63efa2717a79fb79c93206b74c")
  (:PATH "src/fulltext-put/reserve.lisp" :GIT-BLOB
   "81642e379bb158bed9bec2f0fa9c70190a637567")
  (:PATH "src/fulltext-put/row-reference.lisp" :GIT-BLOB
   "b24f1dc1bd7ea08b7efe05e954cd30190f8a1aa1")
  (:PATH "src/fulltext-put/start.lisp" :GIT-BLOB
   "8c6677841d374a7bfc1834a83ccf610eecce0890")
  (:PATH "src/fulltext-put/types.lisp" :GIT-BLOB
   "c0bb31863f4f17894f85f69df42d5476d988f9da")
  (:PATH "src/fulltext/analysis-emit.lisp" :GIT-BLOB
   "17bcef98c46d7a035d2945be0c7407ed178e3da7")
  (:PATH "src/fulltext/analysis-nfc.lisp" :GIT-BLOB
   "e3e34d111a4cbab7a860d995e0658e154f1a4031")
  (:PATH "src/fulltext/analysis-package.lisp" :GIT-BLOB
   "5729cfba660c391cf9dee6fc3d5e6ccbddcd2552")
  (:PATH "src/fulltext/analysis-properties.lisp" :GIT-BLOB
   "320a03b22e01f755184d3d8b6aa1a61b009ce538")
  (:PATH "src/fulltext/analysis-space.lisp" :GIT-BLOB
   "7ab493596664f1488b369fc0b14b083e9eee31af")
  (:PATH "src/fulltext/analysis-word-context.lisp" :GIT-BLOB
   "023c1d7676f5f1325e7b112ba38a132a010f36e8")
  (:PATH "src/fulltext/analysis-word-rules.lisp" :GIT-BLOB
   "0278fccb36c8320d8b0b11b26e067773b8435e1a")
  (:PATH "src/fulltext/analysis.lisp" :GIT-BLOB
   "496c3196aa6efc23695486f15253f9275b58c1c6")
  (:PATH "src/fulltext/codec-input.lisp" :GIT-BLOB
   "ff8ede224c154fa075b7f1eb53cacecbcc7d73c3")
  (:PATH "src/fulltext/codec-package.lisp" :GIT-BLOB
   "fcd63be08134216e7a0d79c68ba6fc1120415689")
  (:PATH "src/fulltext/codec-plan.lisp" :GIT-BLOB
   "b614382a5beec3c0ccc3134f0e2abffc0fb44e87")
  (:PATH "src/fulltext/codec-query.lisp" :GIT-BLOB
   "1047b265bf2140ea5d14ea55987f1bdfae2f6e0c")
  (:PATH "src/fulltext/codec-read-base.lisp" :GIT-BLOB
   "5a24b81342a564255563e9309efcc9f043aa33a4")
  (:PATH "src/fulltext/codec-read-dict.lisp" :GIT-BLOB
   "5958a63148c0942343fa93fce59a59d614850bb2")
  (:PATH "src/fulltext/codec-read-lengths.lisp" :GIT-BLOB
   "91b77b0ef9cc16fb29c437130453ca97c19de60f")
  (:PATH "src/fulltext/codec-read-postings.lisp" :GIT-BLOB
   "46fc1a96ed8bd3e616392ac6c891a678b4e8f33a")
  (:PATH "src/fulltext/codec-read-term.lisp" :GIT-BLOB
   "bf77c4c7d7f7faeaa68077cc1dfbb8349ff6eeb7")
  (:PATH "src/fulltext/codec-run.lisp" :GIT-BLOB
   "fbe693aa1579466dc55fc03fe88a1bb04d7c097f")
  (:PATH "src/fulltext/codec-space.lisp" :GIT-BLOB
   "48e907be585f73c58fd7fa4e89a0b5cdfbfef309")
  (:PATH "src/fulltext/codec-view.lisp" :GIT-BLOB
   "49a4547d0153a45281e2bd2188891f2c5517523d")
  (:PATH "src/fulltext/codec-write-entries.lisp" :GIT-BLOB
   "035e0c6d0826d7be8e5308c3dbabf9f4b6b94b50")
  (:PATH "src/fulltext/codec-write.lisp" :GIT-BLOB
   "64731ed8f9fc9f1246a62c659b18fa85ae2a0f3e")
  (:PATH "src/fulltext/descriptor.lisp" :GIT-BLOB
   "d53475000e9a1f3f3ab97f29780b526b39c43e58")
  (:PATH "src/fulltext/document-analysis.lisp" :GIT-BLOB
   "5f4635b04bf39a7673c4071ac423f3c23b595c57")
  (:PATH "src/fulltext/document-bound.lisp" :GIT-BLOB
   "6eb42da6fa77f01a38b92559b1eccc32f1313d43")
  (:PATH "src/fulltext/document-config-input.lisp" :GIT-BLOB
   "f9522d52f03c808c9e31903ac6393ba113c487f0")
  (:PATH "src/fulltext/document-config.lisp" :GIT-BLOB
   "4d28290bec4b6bca2f8a79338323fa1e4b2ed617")
  (:PATH "src/fulltext/document-package.lisp" :GIT-BLOB
   "c699e405a2ce6c5a18cc27842352f8ad43647e4b")
  (:PATH "src/fulltext/document-paths.lisp" :GIT-BLOB
   "dc31d23d3316043885526af964aab860fe4a6f45")
  (:PATH "src/fulltext/document-scan.lisp" :GIT-BLOB
   "62df7660d399fe08ccb948a21fe6ceb0bbca507b")
  (:PATH "src/fulltext/document-space.lisp" :GIT-BLOB
   "ab484dddcbd81d464e8739e4aa28a1be667accc1")
  (:PATH "src/fulltext/document-start.lisp" :GIT-BLOB
   "d59279a55290ed8b35e722dd9ee47cef68502a1a")
  (:PATH "src/fulltext/document.lisp" :GIT-BLOB
   "447a0f0d27d1e197483f839e7a03d75bce92585d")
  (:PATH "src/fulltext/format-constants.lisp" :GIT-BLOB
   "cc040653f809c725a063eee35fff6e2f9570b675")
  (:PATH "src/fulltext/format-input.lisp" :GIT-BLOB
   "891ad11bf97386317a7a56d6e81c7d425745dfdb")
  (:PATH "src/fulltext/format-package.lisp" :GIT-BLOB
   "1f72e2d40467a20422c5bfaa2564bb5b84fedf29")
  (:PATH "src/fulltext/format-read.lisp" :GIT-BLOB
   "323807f0a973049dd290dd7dad4d2266301e6e57")
  (:PATH "src/fulltext/format-write.lisp" :GIT-BLOB
   "2b89b266d96de0264d92b164b4d59e4e27079f82")
  (:PATH "src/fulltext/index-build.lisp" :GIT-BLOB
   "54ae060c29f1345430a44b2b378c8cb43039dcdc")
  (:PATH "src/fulltext/index-lookup.lisp" :GIT-BLOB
   "9ef394661c96beef9e4cbf3f2e8e5812ec6828c6")
  (:PATH "src/fulltext/index-package.lisp" :GIT-BLOB
   "20bfb93adc06f0782e20fe842f4805b2249d440a")
  (:PATH "src/fulltext/index-sort.lisp" :GIT-BLOB
   "369d3de6ee0ecee94aadfe6ebbce619b84e8147b")
  (:PATH "src/fulltext/index-step.lisp" :GIT-BLOB
   "9206fd68138b97057494978f7713618063510654")
  (:PATH "src/fulltext/meta-fields.lisp" :GIT-BLOB
   "afaeeadd5831bac5804c57a9b67428a3e3c2eaa0")
  (:PATH "src/fulltext/meta-read.lisp" :GIT-BLOB
   "9a4f5a543e68b9c585126096feadaa754f10c6d7")
  (:PATH "src/fulltext/unicode-tables.lisp" :GIT-BLOB
   "a0b079ee4bfba2d1a6ca83b4bb9c555462b75b3c")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "4ebfa97211671287aa2c972a8923654c2390d0f9")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "8dcddeb0536c1104af92c722ffbfab2059601c74")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "a957b1f91e495637b700756736a96baafd233abe")
  (:PATH "src/get-directory/sources-read.lisp" :GIT-BLOB
   "fbb8b26fcfd9de939bf4f3c61d5fd0c5c335754c")
  (:PATH "src/get-directory/sources-types.lisp" :GIT-BLOB
   "ce426ea6409d588e0ca6add8e6c95a1c594e0c89")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "564cdaea8cb9aae672cbbd4328ea7e76b4430f4a")
  (:PATH "src/get-resolver/active-arena-read.lisp" :GIT-BLOB
   "b70b14e779d6c841bd52ca53a599822b77dcdc32")
  (:PATH "src/get-resolver/active-arena-write.lisp" :GIT-BLOB
   "2f893bf07fc9a7d36761a54cf2bbd03300d5a945")
  (:PATH "src/get-resolver/active-arena.lisp" :GIT-BLOB
   "8195220c0d648304d57dac090ab0da03f7812fe9")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "136d22104439f016932e90d45622553f070c1724")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "3a3dae662d06b1e2b6bc936b227894d2f0396b6d")
  (:PATH "src/get-resolver/active-init.lisp" :GIT-BLOB
   "89d45e100f395e65aeca93e7d317073cfb5ffdc3")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "93a32b00aef08a29b4ae7d638eaf16cc68a284ff")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "430b3ba6b063931e60c477a22ce3c50fa1898750")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "6e481f4d41ba4d20649978f806df1685b7afa8fb")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "9634424bab5ea2fe66d950f30e7d51b1baa3a395")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "d6854c7ec8b7125b33391a27760be11cd01c89db")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "33d7b898b5f5a7b20c8112484191c14df44b770e")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1a5479dc776fd56b3c6871dd2984a620bf43f991")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "b747d3a4b6517d7574225dc26cab8703747f0e05")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "c0f1a6b32a1725b6e9ae05e00e130a3e0097be78")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "7f2f8b496d65b70d83eee58c19b5b679b5d632ba")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "77b07c57b7e57505ff35724dc36a90cb554679ee")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "76ac8e35c01b887cec70ccd78d29d87690557eae")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "2a393aae53a7b13b567dc5a44b5d0d1da83714f3")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "01233e1565f301c96ce6ee3bb33a50f10cb2e937")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "7a3600dfe26168cc956e1ef62d07221a6d51a61f")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "fe1475f001e9b5719980f7e7507f735edc7e208a")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "4dd3840c525e54acc7d1577b45aadff217a77c4b")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "f1a5060bb6071bec929476a9151fba0ec68e1604")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "db2d060ad9f747deaa7f5016d09eb8ff0299d36e")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "9827cb4af0343e4241d2fed6e3c62830455f8749")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index-disk/api.lisp" :GIT-BLOB
   "daeaeeaef31f8cd903ad02f6cd60193611714643")
  (:PATH "src/index-disk/balance.lisp" :GIT-BLOB
   "c1189c5fcb2a3389004a0b2d19357c4f93e9e026")
  (:PATH "src/index-disk/build.lisp" :GIT-BLOB
   "85d0f397ea8062235c537806caa21fe03d790589")
  (:PATH "src/index-disk/cache.lisp" :GIT-BLOB
   "e61013c7d4d60aa0711024615dcdf42476c69ecb")
  (:PATH "src/index-disk/copy.lisp" :GIT-BLOB
   "b26cdc656f9112ab344983c5a7f473e97442c8e3")
  (:PATH "src/index-disk/mutate.lisp" :GIT-BLOB
   "ac7a72b3d506de92ec80bbb9653904188b98d8f8")
  (:PATH "src/index-disk/package.lisp" :GIT-BLOB
   "23536e507f5fee4b20554184835addebab23ba3e")
  (:PATH "src/index-disk/read.lisp" :GIT-BLOB
   "20599afde6adbb9cd9decdc852f0de469a5d72e5")
  (:PATH "src/index-disk/relocate.lisp" :GIT-BLOB
   "34399623c2c31e68c16d069f57d1b7e6b9bd4ab2")
  (:PATH "src/index-disk/types.lisp" :GIT-BLOB
   "df13ba528aa6bba71981c44b8fbf14c69fa4551e")
  (:PATH "src/index-disk/visit.lisp" :GIT-BLOB
   "ec8ae71e8f2d27b7e2a49cefbeb2c86e7367bbe2")
  (:PATH "src/index-disk/write.lisp" :GIT-BLOB
   "7b6e37218626e782f22cc2903328c40f23d52fac")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "64be10d7b2dc85c6dd6c31becefbb6ee3ae74d21")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "ec86f5be5b5d465d5e32dc3c492cbc0c90daaba5")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "6dc9775423900dd855c71c06079cdc5e69411c5b")
  (:PATH "src/index/image-codec.lisp" :GIT-BLOB
   "e3b96642767e7e0d116481f41e279274646c2b12")
  (:PATH "src/index/image-constants.lisp" :GIT-BLOB
   "6c123802b75884937c2e9bcd7cfe4e214173ab9e")
  (:PATH "src/index/image-publication.lisp" :GIT-BLOB
   "7733d528d07acc24ec9f8c00c6767c2e3b09975e")
  (:PATH "src/index/image-recovery.lisp" :GIT-BLOB
   "ea1a681932b0fa2a1a7a3f44238816657505e55c")
  (:PATH "src/index/image-seal.lisp" :GIT-BLOB
   "f788cc87a9f2f963210d5bb54310f359df78adba")
  (:PATH "src/index/image-types.lisp" :GIT-BLOB
   "69315a89f5b007ebfbb838bc87dde37221fa69c8")
  (:PATH "src/index/image-verify-edges.lisp" :GIT-BLOB
   "2bdfd22b88408ff57efe6dc6e8c61fb5bb4f2fa1")
  (:PATH "src/index/image-verify-entry.lisp" :GIT-BLOB
   "6d240011e6b3f2c8795537bdead86763cd5a0dd5")
  (:PATH "src/index/image-verify-key.lisp" :GIT-BLOB
   "c7bde57d3d327f32321c29d358cb84eb90f1eadc")
  (:PATH "src/index/image-verify-types.lisp" :GIT-BLOB
   "a7f39bfa563402bb113c3430c5229926c0354ff9")
  (:PATH "src/index/mode-package.lisp" :GIT-BLOB
   "53da3230da115c0d702cc762d3f2ab69e6af253e")
  (:PATH "src/index/mode-policy.lisp" :GIT-BLOB
   "2acdfd94b5a0e5bfc04135cf9f39b4a72ef93482")
  (:PATH "src/index/mode-types.lisp" :GIT-BLOB
   "9e42e46cfa22a400da7635e45ab7c8192e25204c")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/page-body.lisp" :GIT-BLOB
   "c4143fd0c6350883ff10db74c2f8b9c7320b7600")
  (:PATH "src/index/page-bucket.lisp" :GIT-BLOB
   "f6f9c5b2076c8f3c1ae9dd1c23bdab00cbd69005")
  (:PATH "src/index/page-build-config.lisp" :GIT-BLOB
   "8d34342f4e34d3edacf6edb07a3059b8cd199d62")
  (:PATH "src/index/page-build-emit.lisp" :GIT-BLOB
   "479818ed5d901eee9ecfee456e39b66d4f02c620")
  (:PATH "src/index/page-build-plan.lisp" :GIT-BLOB
   "86bf82eb3913ca8dad0f7e1dbe1e9016da5b18a9")
  (:PATH "src/index/page-build-proof.lisp" :GIT-BLOB
   "f86fd7f850a9f1559e9af7fdf445971e07020eff")
  (:PATH "src/index/page-build-types.lisp" :GIT-BLOB
   "4fb20f67faa960088aadf112246f84a98f58117a")
  (:PATH "src/index/page-build.lisp" :GIT-BLOB
   "b632710d7d32cac680b10a9312bd9c4878024fd0")
  (:PATH "src/index/page-cache-types.lisp" :GIT-BLOB
   "bbea574ced62361daf59b1d03fb6f06cdb840991")
  (:PATH "src/index/page-cache.lisp" :GIT-BLOB
   "e66d3fa17f78dde39eff02eb8993a7c68f9ba9f5")
  (:PATH "src/index/page-constants.lisp" :GIT-BLOB
   "de904d211f301a087b3d1d53fa47a8054ccf2eb7")
  (:PATH "src/index/page-lookup-key.lisp" :GIT-BLOB
   "9e2e8f43e9a787b7a9223d57dcbab979dbbc233e")
  (:PATH "src/index/page-lookup-types.lisp" :GIT-BLOB
   "9abfe5a3024425124a8e9cc3b0a7087ad5cad1ff")
  (:PATH "src/index/page-lookup.lisp" :GIT-BLOB
   "9dde416acf27111c21e3f439dd2c948d27517eb7")
  (:PATH "src/index/page-package.lisp" :GIT-BLOB
   "d3f1ff0b939b5a4a1e2df7f22fb04077886220ea")
  (:PATH "src/index/page-read.lisp" :GIT-BLOB
   "0386ec4059fbb6a01d34a137e5bf5a6f44a6f589")
  (:PATH "src/index/page-types.lisp" :GIT-BLOB
   "74a9db44b348db25a046c9250f092a0e03f82ca0")
  (:PATH "src/index/page-validation.lisp" :GIT-BLOB
   "a45eb2aa3d449c9500a95950709cb6019fb8f76b")
  (:PATH "src/index/page-write.lisp" :GIT-BLOB
   "6206be6610c55d48389763a3205ff80ebd79a6d8")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "27c03d2d3e8bfb6b93088bb55bd6e615350261d0")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "83fe7ca83cad1b84f41a579d56bb02ee0bac881e")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "86debb0798063a5e05be0a96f125dece7edd0f0a")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "5afb91ab551d915d29f6630573a17328839cc616")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "099d59bb9acc155380a3baaa3a10816e0902d8ca")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "d054587f29d5108d65704fe8b5b6794178923902")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "7cc651a3e3de17decfe71f3ee9b826dfa7b3ca2f")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "fde846254989ef432159c1ffcfc25fb3f950dbcc")
  (:PATH "src/index/primary-restore.lisp" :GIT-BLOB
   "252bd2cb57700c33fd4ec94749ea6f0b80ae6817")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "179de5b6f466cfcb72c719c49a0e885b5bcf6a12")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "621a82743aceafa1653340330e413bc902c58ebb")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "0187f4d9603d23a6ddb0a76d282af9c811080534")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "589e1557b2906a15c6c874f126968669206ceed9")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "bebb4f103854e0b3dbfc248cae5b82cdeafb0b57")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "ad43248f2f9ec4978a07df5bb696c49a1c055ea7")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "6a55454412edc8466e9c7972f9c81d9a3c945697")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "d42c883908d8a8c9c467342b8977498f38dcf33b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "83bec7e5e8d66f78d9b127c5310b2058b3c3fed6")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "ab3fd8e8abe4fd803038cf11e13c3fef75a8144b")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "0e8ca5847c6683a89cdd47e3476665b1bd46e6da")
  (:PATH "src/io/cpu-build.lisp" :GIT-BLOB
   "0dd046093289729dbc7817a3eeb7dff004f0e9fa")
  (:PATH "src/io/cpu-features.lisp" :GIT-BLOB
   "80653c6c8871127b3d76cc631d47ba0e711b6e5d")
  (:PATH "src/io/cpu-package.lisp" :GIT-BLOB
   "baf8aa6f2ef5231eb6462bca65d83ac1886d09e5")
  (:PATH "src/io/create-relative.lisp" :GIT-BLOB
   "eb4a8c292b30a3083cd256eda697b05737553022")
  (:PATH "src/io/derived-remove.lisp" :GIT-BLOB
   "a0631348bc17fc4e5c1638522be73ae87fa53a97")
  (:PATH "src/io/directory-lock.lisp" :GIT-BLOB
   "f0135b3b43625d9535db6196507b55154d36f852")
  (:PATH "src/io/directory.lisp" :GIT-BLOB
   "8b3fb30b5fa092a5f88ce55cbcf5ebfa6bddf993")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "9b04b83cf53f493aaf75d1c19a6d5f9f4ee0971f")
  (:PATH "src/io/identity-types.lisp" :GIT-BLOB
   "d53f8c4793af7e98dcab62ee5c94571dd8d520a2")
  (:PATH "src/io/identity.lisp" :GIT-BLOB
   "0cb49ca63800c1fc25bee5bf94c2811969511a07")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "9ea7d77f1bccbb7051123ac2e5793d38b770ffbf")
  (:PATH "src/io/namespace.lisp" :GIT-BLOB
   "1f73f6bf5c4b8f12064b515008d6c8f9076518ce")
  (:PATH "src/io/native-create-relative.lisp" :GIT-BLOB
   "9d715484a72332fb056b8102d2277140128b2f59")
  (:PATH "src/io/native-directory.lisp" :GIT-BLOB
   "95ea1018b8693a89e0967f9a7a6dea95542d6005")
  (:PATH "src/io/native-namespace.lisp" :GIT-BLOB
   "599c21713f3d82b6bc9faac71e42a45da0e6cd90")
  (:PATH "src/io/native-open-relative.lisp" :GIT-BLOB
   "d924a8a202ab02406cdae147cfa0cb742a0917e6")
  (:PATH "src/io/native-publish.lisp" :GIT-BLOB
   "d62f716c3965b838e0cdb7a629c78bdf845bbdc2")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "37f1e1782e0e3580447aa0ef56cb0942cfbd0e66")
  (:PATH "src/io/open-relative.lisp" :GIT-BLOB
   "e712b098ddbd883b77382c60b1b511427e8c4db7")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "c0be7a664e6642b7dcc6362d6194090fa9a8290e")
  (:PATH "src/io/publish.lisp" :GIT-BLOB
   "cb759a6c4c6d4b9300c1bb9e1e7b7d781f629f65")
  (:PATH "src/io/readiness.lisp" :GIT-BLOB
   "8ae8de38729e3866227360cc1cf6022c9220490b")
  (:PATH "src/io/rename.lisp" :GIT-BLOB
   "38a7d50880a012266e59eb915edafe64f2047e4e")
  (:PATH "src/io/segment-remove.lisp" :GIT-BLOB
   "8530ef67554d751b20d1004a9af49f20b8fc1861")
  (:PATH "src/io/stabilize-preflight.lisp" :GIT-BLOB
   "290915923be47b7739c3f44560a62f9819c7a26e")
  (:PATH "src/io/stabilize.lisp" :GIT-BLOB
   "504c9dca2fece31bc79f8788f7524d7397a1fee2")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "b66a02dbc2eda6d43388a0946ae46b795efb2a76")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "8e7b3506c6f1da4493bba4817d8b1f6c57585aaf")
  (:PATH "src/local/cli.lisp" :GIT-BLOB
   "801ea182eab95273f82e3b5687605dfbf31aef75")
  (:PATH "src/local/client.lisp" :GIT-BLOB
   "e7f09f4789f50fb79aeef0722c9461f0915cb084")
  (:PATH "src/local/dispatch.lisp" :GIT-BLOB
   "f461a82e35b1abe75601b8b73170401d9d522806")
  (:PATH "src/local/native.lisp" :GIT-BLOB
   "380f655e5da39eaff4daeef4c6eaf63217762a48")
  (:PATH "src/local/package.lisp" :GIT-BLOB
   "74489fef066b33ac706cb0dd8c757d440e0bfebf")
  (:PATH "src/local/readiness.lisp" :GIT-BLOB
   "bbc9fce59ab612aa4dd003d90a854506c7b047f1")
  (:PATH "src/local/server.lisp" :GIT-BLOB
   "aa2ff6565fa073d586f5a69ae949b9f0bc39f09d")
  (:PATH "src/local/state.lisp" :GIT-BLOB
   "e3b7dafaa7f4cbae331ffd2f43edc38ca636d7c9")
  (:PATH "src/local/wire.lisp" :GIT-BLOB
   "60a5c872e2da0baa0fee22fd4909b66342c2c387")
  (:PATH "src/local/write-group.lisp" :GIT-BLOB
   "196d2f1c7f00a460c6032a8562402e1bfe6f72a3")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "fdeac572e64c3591208a87872b8aa9d520c3bde7")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "74ebd63accc8216dfe5a1794c0e430bb9bccd29e")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "a05a5732511ffca3591110f617e3a19be819b47b")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "158b5a6d1eb171d07bd4f67addc2f4be5495d54b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "06a0af0e813b9c22ce98d523d42c031c79ca3734")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "95f5a8c59ff1fef05bcd3fd220d6a14d9c332d61")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "e5130ba55ee942238a5a98ecc51e07725e1c9655")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "2de7b390c89ab19f8be03767ecb07af8fe1e4fb1")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "172a43f86726ec68af730700c99098d66500ad66")
  (:PATH "src/recovery-active/build.lisp" :GIT-BLOB
   "0fa0e554f7e3aa6990d861dec7cbf8408db28068")
  (:PATH "src/recovery-active/closure.lisp" :GIT-BLOB
   "326b2070076e6e9a8d8ee66567d05b5c19329467")
  (:PATH "src/recovery-active/csn.lisp" :GIT-BLOB
   "42b1279ccd9910816bd8d0887b60bcfe9b6e252a")
  (:PATH "src/recovery-active/frames.lisp" :GIT-BLOB
   "3d01c07ff8118b92e5de7b31ca72b19db5ec72ff")
  (:PATH "src/recovery-active/package.lisp" :GIT-BLOB
   "474cd54f2a31f4ded95fd723b4170bee8addece4")
  (:PATH "src/recovery-active/publication.lisp" :GIT-BLOB
   "38542ec938fd3409d73d7531e90fc6474ef42fad")
  (:PATH "src/recovery-active/query.lisp" :GIT-BLOB
   "e2a5aea0f5a97670cc20a583ed312c89df1c7187")
  (:PATH "src/recovery-active/read.lisp" :GIT-BLOB
   "f801950d67755cd15804ef43f1461d435eda54a6")
  (:PATH "src/recovery-active/resolve.lisp" :GIT-BLOB
   "66f4ada585e085a8403d4cdbc9a3dfee31754bce")
  (:PATH "src/recovery-active/types.lisp" :GIT-BLOB
   "069ca4b815c98d82695dd7eb9337a83c5f35b98b")
  (:PATH "src/recovery-archive-csn/build.lisp" :GIT-BLOB
   "ea5a6abf3d6b0817cfa99db490e9e5df57cb200a")
  (:PATH "src/recovery-archive-csn/package.lisp" :GIT-BLOB
   "bacf4fc95e38a8d0416110c6b87b506d561a7e59")
  (:PATH "src/recovery-archive-csn/preflight.lisp" :GIT-BLOB
   "a7a20c65ba54da28dd88c941736fb374065d580f")
  (:PATH "src/recovery-archive-csn/query.lisp" :GIT-BLOB
   "28f8acd47abad20efb95ec0ea8bd765bfa10baff")
  (:PATH "src/recovery-archive-csn/series.lisp" :GIT-BLOB
   "f8eb49763d533cd34cdf05593d2416a63c5f1d0c")
  (:PATH "src/recovery-archive-csn/types.lisp" :GIT-BLOB
   "d30bb8cb36fd1c64a720073fd3f4b4921e507cad")
  (:PATH "src/recovery-archive/active.lisp" :GIT-BLOB
   "5eb16b6f93d24ac3c6f06af8ed3c005328b457a5")
  (:PATH "src/recovery-archive/build.lisp" :GIT-BLOB
   "81a581f63c21154b8a55f2f429ec28ee32a659b3")
  (:PATH "src/recovery-archive/package.lisp" :GIT-BLOB
   "82c707853b1a5b2b6d657e120c7e0ecb82404134")
  (:PATH "src/recovery-archive/query.lisp" :GIT-BLOB
   "8ae65f7a41d2b4a395d6e6a1829d334dfbe88878")
  (:PATH "src/recovery-archive/read.lisp" :GIT-BLOB
   "07ee8571028ca0ec5f754ec9f8478077650ee48d")
  (:PATH "src/recovery-archive/types.lisp" :GIT-BLOB
   "80d29b79c185d0007d0b0e4baa913ed18ec0524c")
  (:PATH "src/recovery-bootstrap/build.lisp" :GIT-BLOB
   "60d549030aa9d16b823fcb98398f14cd3786f73b")
  (:PATH "src/recovery-bootstrap/package.lisp" :GIT-BLOB
   "29ce39efa53a72cd766810b81a08c9a2f86afc91")
  (:PATH "src/recovery-bootstrap/preflight.lisp" :GIT-BLOB
   "601685cad9fd3829ea36672e86b94952f3fe4493")
  (:PATH "src/recovery-bootstrap/shape.lisp" :GIT-BLOB
   "56e6694b910c05854961e920deeb0da390d4a428")
  (:PATH "src/recovery-bootstrap/stabilize-preflight.lisp" :GIT-BLOB
   "5c05f4f7b52c72cce8f3a086a64c4d190e7de36e")
  (:PATH "src/recovery-bootstrap/stabilize-shape.lisp" :GIT-BLOB
   "649080985356be430b25c841c7d345e9d24cb543")
  (:PATH "src/recovery-bootstrap/stabilize.lisp" :GIT-BLOB
   "2ef2dda4858003135215d7d36f816f4929d214a3")
  (:PATH "src/recovery-checkpoint/build.lisp" :GIT-BLOB
   "c274d47f45d845a6e16049e2a573e8d9d76fbc3a")
  (:PATH "src/recovery-checkpoint/order.lisp" :GIT-BLOB
   "a265f08779f2abc94be058454cf75643c33272ca")
  (:PATH "src/recovery-checkpoint/package.lisp" :GIT-BLOB
   "7b191ecff3dbac6b5f690ad221c68b4762a9f0aa")
  (:PATH "src/recovery-checkpoint/preflight.lisp" :GIT-BLOB
   "61e245a5495de984a94fef573f88d11245e86b71")
  (:PATH "src/recovery-checkpoint/sections.lisp" :GIT-BLOB
   "eb05b6c58fe3131fbd597dff5655e4a476b55092")
  (:PATH "src/recovery-closed/build.lisp" :GIT-BLOB
   "bab6c80812e70ffb31a59f29ffaaa6f90678cea1")
  (:PATH "src/recovery-closed/csn-serie.lisp" :GIT-BLOB
   "078d9bbd66289b667c4273053f706a3a2af120e6")
  (:PATH "src/recovery-closed/csn.lisp" :GIT-BLOB
   "41144f854694ff9338e0067d2f59b3312119c5b2")
  (:PATH "src/recovery-closed/package.lisp" :GIT-BLOB
   "49ac245e2430e719b1d417b91b0ffcd53555e47d")
  (:PATH "src/recovery-closed/publication.lisp" :GIT-BLOB
   "fc512bece4fead39a0c75c943cc5d10bbfb810b4")
  (:PATH "src/recovery-closed/read.lisp" :GIT-BLOB
   "08bcf5a490ceba1ae7a94258f1c0bd9ca148cdaa")
  (:PATH "src/recovery-closed/resolve.lisp" :GIT-BLOB
   "2f107b18e7060dc54e902dbe0363d836285ace5f")
  (:PATH "src/recovery-closed/types.lisp" :GIT-BLOB
   "a403121cd1459db7eb753981a402152615541caa")
  (:PATH "src/recovery-closed/verify.lisp" :GIT-BLOB
   "bac75f2ed61947826ca194cf57f8d2feb003f7fc")
  (:PATH "src/recovery-replay/package.lisp" :GIT-BLOB
   "8639d959e29e9f36270a94831eace49f6535a863")
  (:PATH "src/recovery-replay/read.lisp" :GIT-BLOB
   "05eade0aed1e83cf2df5f5e2bab563d31c95081a")
  (:PATH "src/recovery-replay/resolve.lisp" :GIT-BLOB
   "85eb7133fe1463016604e6a6c9ca26dea7bb5633")
  (:PATH "src/recovery-replay/visit.lisp" :GIT-BLOB
   "0c94187caae5986c8481cf1a8e8bc060db2a7b53")
  (:PATH "src/recovery-selection/frame.lisp" :GIT-BLOB
   "101813cb3536365ac914f10e926f424dec18647e")
  (:PATH "src/recovery-selection/index-preflight.lisp" :GIT-BLOB
   "c3d336e63fbb2b5d972a314a86edd123f050aa7b")
  (:PATH "src/recovery-selection/index.lisp" :GIT-BLOB
   "b4b3488404b09fd1df4f351910043b333c1f355e")
  (:PATH "src/recovery-selection/key.lisp" :GIT-BLOB
   "f751a1ed921903353ab48e52e9fa24d374202ed1")
  (:PATH "src/recovery-selection/package.lisp" :GIT-BLOB
   "9dd583b4bf868183f7555b1e4f7c29f2a13c244c")
  (:PATH "src/recovery-selection/read.lisp" :GIT-BLOB
   "04903a7aa14fe3c332bad4255ff62f87d2e69b77")
  (:PATH "src/recovery-selection/select.lisp" :GIT-BLOB
   "dc4345cbad0fd4223eb50ed2d0ed6bcccb8ec709")
  (:PATH "src/recovery-selection/types.lisp" :GIT-BLOB
   "85930de29d2bc071ea7bbb8677d9aa0ac4e1310e")
  (:PATH "src/recovery-series/build.lisp" :GIT-BLOB
   "41324774ac594767e6931c141858270d2a2125ad")
  (:PATH "src/recovery-series/entry.lisp" :GIT-BLOB
   "a37b7c87eff82670540beb78aa78cb40fab88455")
  (:PATH "src/recovery-series/package.lisp" :GIT-BLOB
   "51f3d64796df1a2180cb977adb8a094e7c7fd94b")
  (:PATH "src/recovery-series/preflight.lisp" :GIT-BLOB
   "0daff10989f88386221d11ff4123384a67092075")
  (:PATH "src/recovery-series/read.lisp" :GIT-BLOB
   "d7ec011280d40883408a816425210f60f4ae4561")
  (:PATH "src/recovery-series/stabilize-preflight.lisp" :GIT-BLOB
   "4e6d9e8047e76ce2fa5324ebca9456d29bd69c2f")
  (:PATH "src/recovery-series/stabilize-set-preflight.lisp" :GIT-BLOB
   "81cc2dcf0e684ccc710e51b221b84c10f057db8f")
  (:PATH "src/recovery-series/stabilize-set.lisp" :GIT-BLOB
   "7fe9646c0721b02d48f8ee99cf3f2e5fa020d4c5")
  (:PATH "src/recovery-series/stabilize.lisp" :GIT-BLOB
   "1fe16c3863409635d882ebce5a9f5abc03ad5ecc")
  (:PATH "src/recovery-series/types.lisp" :GIT-BLOB
   "eb8d4a347b96aca4e5277435fe1361ed794f39b6")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "d7ac44761869f57e333497212510416fd1e794c9")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "58a3e620a8def39d2b24cd210d9283184c247ed2")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "b30dd16f31dcb00316d6983c7cfc5cb2948ce0ee")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "54b5092b76b1c609ee195c44bd9206c1800542c4")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "c7bd0b41e7a84ef73829aeaef3a113f12e7a6031")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "c2fab3b7b2cec568adfe88f0037fc216f83765c9")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "2059363677925a732eb1c70fc1ed1be94d715ea9")
  (:PATH "src/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "7b7f3c4c1bbcd252583249b650f82ab968409e24")
  (:PATH "src/recovery/inventory-directory.lisp" :GIT-BLOB
   "4f253cf7dbe6dad5814749ff53d40759ab882d73")
  (:PATH "src/recovery/inventory-id.lisp" :GIT-BLOB
   "c6dabcd733010fe6966aa1d27656b0760744e55d")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47bc32082a709eb46a5fdb5a5b3011d2c4377f80")
  (:PATH "src/recovery/inventory-sources-build.lisp" :GIT-BLOB
   "149e9ca5fc1bf3ed1f473beb075d5c35b6099886")
  (:PATH "src/recovery/inventory-sources-query.lisp" :GIT-BLOB
   "9742c023b3347d38f678c7a1752a9cc37b665996")
  (:PATH "src/recovery/inventory-sources-types.lisp" :GIT-BLOB
   "b52908d02b1cda451190be58333ef9c9508fddf9")
  (:PATH "src/recovery/inventory-sources.lisp" :GIT-BLOB
   "3619190b49dcbaa32ef4dd2111995df5beace5c5")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "1cbb826a8999579a98e51b9c0ecd1cd6a6ff9661")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "1a98289ea132f2b68309efb3a7552f99a514796e")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "801976598bd390814c4ddfaf00377ee38369405c")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "2ddd4fb6d4c1717a25c369c6a7252f9f80769221")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "9754b563a1d0fbfcda0f306e94b1b6d0257dfb0e")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "43af5d7e8cf2c8465492531133ea9647f614e613")
  (:PATH "src/recovery/manifest-transition.lisp" :GIT-BLOB
   "c871c345eb51367427adbb9bda778a6857a97510")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "40c49f4692e11b4c7f9f55b93bae69210adbdcbb")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "eb0e60664ad7abeefde7a4fc81fa7b3fa38ac57f")
  (:PATH "src/runtime/active.lisp" :GIT-BLOB
   "d7889b0103e18eb47878a88c760cae38de48b3fa")
  (:PATH "src/runtime/build.lisp" :GIT-BLOB
   "4fbf71ebd764f7d90977d027372437e113fdeed3")
  (:PATH "src/runtime/closed-preflight.lisp" :GIT-BLOB
   "5e10ae83ae0e4cd3adbbdae389629a0a854182a2")
  (:PATH "src/runtime/closed-transfer.lisp" :GIT-BLOB
   "3db2e73c10bf24d3931cbf993f240aac45e88e0f")
  (:PATH "src/runtime/closed.lisp" :GIT-BLOB
   "b06f0ae33a9c084c5101cfa5170e358bd4f7fe55")
  (:PATH "src/runtime/package.lisp" :GIT-BLOB
   "5eb61dac53e09bdaf493680967ab65938b6b8f63")
  (:PATH "src/runtime/preflight.lisp" :GIT-BLOB
   "7babef89ceacca9a7c8fac7068b54f653a4a3c58")
  (:PATH "src/runtime/query.lisp" :GIT-BLOB
   "34a7a4ebe5d0baeb93acca991f02a38b0cad2204")
  (:PATH "src/runtime/types.lisp" :GIT-BLOB
   "19fe3cc6004382550ea7939c5bf100d1fcc92607")
  (:PATH "src/scheduler/build.lisp" :GIT-BLOB
   "a55b8e7089ba3880ffa69cee4adb13dc0543069c")
  (:PATH "src/scheduler/lifecycle-build.lisp" :GIT-BLOB
   "7dfa330d606ef9c4dbceeb83845a32e75eb62fe6")
  (:PATH "src/scheduler/lifecycle-read.lisp" :GIT-BLOB
   "3b7ece551dae47957d9350c49285617d60b6ee3f")
  (:PATH "src/scheduler/lifecycle-types.lisp" :GIT-BLOB
   "5a03c1176d6bc019bcd230b0fd665cc48d555395")
  (:PATH "src/scheduler/lifecycle-update.lisp" :GIT-BLOB
   "47d323541ba45f5fb507ebcdb2eae9dd701533a2")
  (:PATH "src/scheduler/lifecycle-worker.lisp" :GIT-BLOB
   "8ae274af549a3464fd5f03d64e3c10ac73145630")
  (:PATH "src/scheduler/package.lisp" :GIT-BLOB
   "cadff5f2e29e7c5b625b95f9387faf29aad02178")
  (:PATH "src/scheduler/policy.lisp" :GIT-BLOB
   "37ed8717cf05ca8f03c06204641f47af18858a7b")
  (:PATH "src/scheduler/pool-claim.lisp" :GIT-BLOB
   "9ba00e2b77cbca2189e947e00b435fb81145668e")
  (:PATH "src/scheduler/read.lisp" :GIT-BLOB
   "ea882e41d231cc0dbafc9eac66bdd1f935433f00")
  (:PATH "src/scheduler/types.lisp" :GIT-BLOB
   "6fcd3d494dc339f8061a64fcce4133b9c86708b3")
  (:PATH "src/scheduler/update.lisp" :GIT-BLOB
   "eb0ad7a3abf119d733ae571d98695980ca4fe694")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "b1aeaa0032d7418cd3c9a7dcbc35add751fb17ce")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "5b189fb0ff0e54abaf72adcb05e5da58ebecb741")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "f81c0946f3e173fa6bf87c24e7c51999afc46363")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "6fd26253982dba01e9eef2702c5f4ede6ba70659")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "95cf61b5df1cdd57975f64a05f890528568046b1")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "79cc08666f83630adba9cab148bb71c2f6d46253")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "f21cae5c4f5cfd94d5d4b6a437ac2ede15750b5d")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "4d09a75d977a0eed0819e7c7d61737d245514b00")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "dee5f67f723edb5ba47b78e68baeee49eb56015c")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "18a29843546af6fc28fa36742a175fc3e6f19e1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "3b6335d3c665f5fe66771242c4d43db3de10b333")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "16700994fa5959633b21d4c7eb21483cd489f0c4")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "2a15783bbd1f5fdd1adb0ae4a045449970f46650")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "d7c667389bf8ad8ec4a04ce2b1bc9ec90e64a54d")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "fd552f6657ade1482eeada765c0880b6afe8a73f")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "6643873870526ee603a5c5b554a91650e5be0e6f")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "028c7b1111e43c0749479067451894b38479a7ec")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "10af1f2b835f387f7c5c69011b712c37bce142f9")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0548df3e81bff3332c67897fc70d7aece4c822ea")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "0e6f1849a77fd2de1109e3576f174f13e2eca665")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "05cb8e127c9384da1c40d21c7566f5d57b705ecf")
  (:PATH "src/verify/order.lisp" :GIT-BLOB
   "d563554aeaddb02585f4e4ad03b739dea5387669")
  (:PATH "src/verify/package.lisp" :GIT-BLOB
   "c98aae86e4bbd9642c2d5481503bf944c88e7811")
  (:PATH "src/verify/read.lisp" :GIT-BLOB
   "913463f4e6529cda367092c7aefe85e8471416c7")
  (:PATH "src/verify/report.lisp" :GIT-BLOB
   "5771c02a6384a61711735571ee64e219bdbc145c")
  (:PATH "src/verify/resources.lisp" :GIT-BLOB
   "48232232f028b479a5839420a42253416f7edffe")
  (:PATH "src/verify/types.lisp" :GIT-BLOB
   "ed2a9617dce5a03c691bc2826a5996f8a3161e2a")
  (:PATH "src/wal/append.lisp" :GIT-BLOB
   "769b86afb5de6d2f706a015e049ea04b63031f79")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "65b17519d6d6e5d9e104bc37b2c4eb4d3b93f132")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "51110c6784e99fc94ddf5a2344e0d85262c297d5")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "ae53e978652629ff407be47d3abe04176626dbb4")
  (:PATH "src/wal/frame.lisp" :GIT-BLOB
   "2f2f1af60a399d9263f15ce4565502da1c70f173")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "17858cffba82609484a6f4a32d082d14ceec1c4b")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "e0ea179069a7b297c7c26f6c294c7d4aea3db671")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "d9f682a05cf5adb22850728a839228f02744c5f2")
  (:PATH "tests/cache/README.md" :GIT-BLOB
   "3836e59b86c5a731e772fbf0a6cca376b14806af")
  (:PATH "tests/cache/guards.lisp" :GIT-BLOB
   "af881fd91c3820ab19d1daa2d56f1fe57257d08f")
  (:PATH "tests/cache/support.lisp" :GIT-BLOB
   "fd829e7352ba878e73df30d979e9558ff6ccba14")
  (:PATH "tests/cache/threads.lisp" :GIT-BLOB
   "ca03c59f0fada09cae8c452fed6490de32d4a3a6")
  (:PATH "tests/ci-catalog.lisp" :GIT-BLOB
   "f99940cde88fc16095679156dd2ca561edab453c")
  (:PATH "tests/codec/cbor-array-write-support.lisp" :GIT-BLOB
   "2a47078354c45a5775f48f6dd8f5d784da7de202")
  (:PATH "tests/codec/cbor-array-write-threads.lisp" :GIT-BLOB
   "43bac6c9604140af2594d85b76c14c3101b6925b")
  (:PATH "tests/codec/cbor-array-write.lisp" :GIT-BLOB
   "b13f58264f3cd97e1947ee52936732a7fcebe672")
  (:PATH "tests/codec/cbor-float-write-support.lisp" :GIT-BLOB
   "5416b62340ae8f3332915f8891529d95549a5fba")
  (:PATH "tests/codec/cbor-float-write-threads.lisp" :GIT-BLOB
   "3b0840150945cd4f118516b1d6d61524fa6856fa")
  (:PATH "tests/codec/cbor-float-write.lisp" :GIT-BLOB
   "747cd8a72445a3ea638cd1910bc9faa63f4cdc33")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-item-read-support.lisp" :GIT-BLOB
   "0326100362a1c4b24d2c7e511e45357f09a56d33")
  (:PATH "tests/codec/cbor-item-read-threads.lisp" :GIT-BLOB
   "a0da65545ed80ede0a967cadbb337731f6fe1ce9")
  (:PATH "tests/codec/cbor-item-read.lisp" :GIT-BLOB
   "b2cbdcb4255c51d9da4fe73b28939c1cb923fefe")
  (:PATH "tests/codec/cbor-map-write-support.lisp" :GIT-BLOB
   "113bfc4529199f69dea1862baec0aa7403c6fa97")
  (:PATH "tests/codec/cbor-map-write-threads.lisp" :GIT-BLOB
   "892d30fd1c7a8f12430c6caa6f43ee872574eb09")
  (:PATH "tests/codec/cbor-map-write.lisp" :GIT-BLOB
   "6ad0e9b5a48ba9c32c46d720f2f7f1821368d6c8")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "532c3f1d5898083364f17f9fc9cbf0da7b798bda")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "d88b573a98689b5e1c0cbade8f8a7ac69470554f")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "0989d7f8e43ec7213df856b842b1e9149df96d9f")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "186f1772335ce33e4e3d1d933bf4d4e91fe0763f")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-read-support.lisp" :GIT-BLOB
   "cfd55cd47d782673113e67af625c1360195a345c")
  (:PATH "tests/codec/cbor-string-read-threads.lisp" :GIT-BLOB
   "c3686d6e47ad56e53db556747ee2d49cea527df5")
  (:PATH "tests/codec/cbor-string-read.lisp" :GIT-BLOB
   "8437bdcaa4cf308dbf4614e748cdab4be2ae6d62")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "66b5d03695f522cca8013ccdad3ede690cc63412")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "16cc32f2c51d28f75a64b93ead642340f88e9c05")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "595d51a96ee3767c13797910ea324061a4788617")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-tag-write-support.lisp" :GIT-BLOB
   "e6e1e91e5ed95019e20b11d2dc0e408911acb46e")
  (:PATH "tests/codec/cbor-tag-write-threads.lisp" :GIT-BLOB
   "1c731f7ed83f703e3d2a8a4c57e6c702ef127887")
  (:PATH "tests/codec/cbor-tag-write.lisp" :GIT-BLOB
   "df97950ec8d24157bb6566c7995262f7beea7742")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "0f66cc1f8b493598d436b1d62d7211f4196fb430")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "7717054be474eba254f3f645fc62ec4ef65a511c")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "0c1a6d9fbe44a95b951a7e1a9aad90f65cef961b")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/control/native.lisp" :GIT-BLOB
   "2107cb66de45ded987c7fb1392155ff6afebbed6")
  (:PATH "tests/control/publication.lisp" :GIT-BLOB
   "f987c9317990ce977ecadb747268b39d2612eba1")
  (:PATH "tests/control/recovery-guards.lisp" :GIT-BLOB
   "b2e877dfcc35468cfafd95f398f33d1415692c1f")
  (:PATH "tests/control/recovery-publication.lisp" :GIT-BLOB
   "cd99169af8aecf204ce9cd2e6e1f2a9fbb081f68")
  (:PATH "tests/control/recovery-read.lisp" :GIT-BLOB
   "21f33af3220a237d7a8dc2ff3a98bfd4c41fa201")
  (:PATH "tests/control/support.lisp" :GIT-BLOB
   "053d81269526d2e7c78181fbe2f8e58ac3f878f3")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/engine/active-arena.lisp" :GIT-BLOB
   "bc3374fac887f4d210b7f3ed661ee38cb22f402e")
  (:PATH "tests/engine/compaction.lisp" :GIT-BLOB
   "4e46ba4400a7af10db08d35e191be80204237234")
  (:PATH "tests/engine/delta-location.lisp" :GIT-BLOB
   "3ab2c0e5c6d45ed746de955c72192327c525c71c")
  (:PATH "tests/engine/delta.lisp" :GIT-BLOB
   "5160313851bdfa637e80b76095679b9e965f22a7")
  (:PATH "tests/engine/group-append.lisp" :GIT-BLOB
   "39881bdf066184487a19e1d82c3cf834e731257d")
  (:PATH "tests/engine/image-activation.lisp" :GIT-BLOB
   "bb8b9470cae4854efd1336bc5a289d7305faed54")
  (:PATH "tests/engine/image-auto.lisp" :GIT-BLOB
   "19215e89154e8f65ba0e83e21b04d3d069c93a69")
  (:PATH "tests/engine/image-build.lisp" :GIT-BLOB
   "8543c508064d8198957a25f93e6da3c343d6c26a")
  (:PATH "tests/engine/image-discovery.lisp" :GIT-BLOB
   "50891fbd9ded0ece20969b466f24f1f591bd1439")
  (:PATH "tests/engine/image-maintenance.lisp" :GIT-BLOB
   "3b28dcea4388823fe8999b1fd67edb7a0da5343d")
  (:PATH "tests/engine/image-renewal.lisp" :GIT-BLOB
   "01e55612ec38f31fe281c0f1707bf1aa50aa1345")
  (:PATH "tests/engine/images.lisp" :GIT-BLOB
   "7ea979d2249807380c4532acc52e2ad299dcc0ad")
  (:PATH "tests/engine/index-auto-disk.lisp" :GIT-BLOB
   "57efb3be2095d695461717b131b95f2b6c1131f7")
  (:PATH "tests/engine/index-automatic.lisp" :GIT-BLOB
   "d2f9514760932005ab95e12f037606cf0dd94fde")
  (:PATH "tests/engine/lifecycle.lisp" :GIT-BLOB
   "55f8a525a7fb68846724b869d15eee8238924fe3")
  (:PATH "tests/engine/processes.lisp" :GIT-BLOB
   "ec6545a30fd1d4405ceb31c6c05b1c0ceb999711")
  (:PATH "tests/engine/record-cache.lisp" :GIT-BLOB
   "7dc3029e1048aedb7aab3bfb2649a69731e01734")
  (:PATH "tests/engine/rotation.lisp" :GIT-BLOB
   "f0de9a0e81ab82a161ba5e19a0706aae803e63e5")
  (:PATH "tests/engine/support.lisp" :GIT-BLOB
   "4f050bd297add4aff17a15bb24b3f499785018fd")
  (:PATH "tests/engine/write-group.lisp" :GIT-BLOB
   "debeeb853848ef25d28ce1293b2af3648b4b02dc")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "b1e71783b65b85e6253f733098c3153d41c4971c")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ca77be5b92c1cec98860dd5f59b278e9dcaf8ae4")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/fulltext/admission-concurrency.lisp" :GIT-BLOB
   "fbc2b0294a9369c4812bf206f001399be2af0ff3")
  (:PATH "tests/fulltext/admission-guards.lisp" :GIT-BLOB
   "b3475774a8a7f31269ea0e1b33bb659e230f67c7")
  (:PATH "tests/fulltext/admission-lifecycle.lisp" :GIT-BLOB
   "175c3e3bd33b163bc7593066ade68eb426e8e757")
  (:PATH "tests/fulltext/admission-resources.lisp" :GIT-BLOB
   "29ac6bf4b0b392579997b79c10142b2f491a5eb7")
  (:PATH "tests/fulltext/admission-rows-support.lisp" :GIT-BLOB
   "1713cd556e5e37525af25a15b4f5b36474967d88")
  (:PATH "tests/fulltext/admission-rows.lisp" :GIT-BLOB
   "6e2d6c65c8046ad7dee030a4e95330f3ce3993dd")
  (:PATH "tests/fulltext/admission-support.lisp" :GIT-BLOB
   "1eaef196dc555b086cd53584731041bfb97cda59")
  (:PATH "tests/fulltext/admission.lisp" :GIT-BLOB
   "74ed0e49ce0c839cb5e74d854704d21cb8dbbf68")
  (:PATH "tests/fulltext/allocation-threads.lisp" :GIT-BLOB
   "870a308baeed93e1aabb6dc9a88db443592439c0")
  (:PATH "tests/fulltext/analysis-conformance.lisp" :GIT-BLOB
   "ad704e6457ad7873b3eb2feea241da5129962c8f")
  (:PATH "tests/fulltext/analysis-support.lisp" :GIT-BLOB
   "805f7e60fd3f6aa25b4c53680e5251188e57868e")
  (:PATH "tests/fulltext/analysis.lisp" :GIT-BLOB
   "4d529aef551bd365f0c12eb3dffbb7b2960fae56")
  (:PATH "tests/fulltext/codec-corruption.lisp" :GIT-BLOB
   "c62dd05be34d1f653eed8565cc0b40b950bdb97f")
  (:PATH "tests/fulltext/codec-differential.lisp" :GIT-BLOB
   "91b651930dd7f9da36fd317453686d272e0d2c40")
  (:PATH "tests/fulltext/codec-guards.lisp" :GIT-BLOB
   "9f6b8e823ae25c43b767141e0193b908ca0e763a")
  (:PATH "tests/fulltext/codec-support.lisp" :GIT-BLOB
   "890e176db757eed9e2680f5b247a12922709d4b9")
  (:PATH "tests/fulltext/codec.lisp" :GIT-BLOB
   "50b924b1c0e9127da33413f1100bf04ef2ee500d")
  (:PATH "tests/fulltext/document-differential.lisp" :GIT-BLOB
   "78466a8bc1213d0794155535eb28a990a45a38aa")
  (:PATH "tests/fulltext/document-guards.lisp" :GIT-BLOB
   "608f322bd4ac149abb9ffbb352595b5c94d3d217")
  (:PATH "tests/fulltext/document-support.lisp" :GIT-BLOB
   "57d59f345c6cbe8dba253acce7993409b5bbed94")
  (:PATH "tests/fulltext/document.lisp" :GIT-BLOB
   "ab305e31ece6bf7fd20ac5b7ea119b01c57e7c92")
  (:PATH "tests/fulltext/format-guards.lisp" :GIT-BLOB
   "9a23048572dfa5eee314221ced3425a1ea46c28a")
  (:PATH "tests/fulltext/format-support.lisp" :GIT-BLOB
   "d03bd892800d593a3550bdc709d43c357041bfab")
  (:PATH "tests/fulltext/format-threads.lisp" :GIT-BLOB
   "b8e8eb4491b59c721071396ce656eb09186f988d")
  (:PATH "tests/fulltext/format.lisp" :GIT-BLOB
   "b7cb19b82d4e50d457c603b8708693adf27785f0")
  (:PATH "tests/fulltext/index.lisp" :GIT-BLOB
   "0673c32fe456a9cb77cf4aa5cc4e071a888cccf2")
  (:PATH "tests/fulltext/minimum-v2.hex" :GIT-BLOB
   "c4db496b0e5b920665d1c80bea204f6227da1f0e")
  (:PATH "tests/fulltext/put-concurrency.lisp" :GIT-BLOB
   "613b2e5a89d505701583aa9c68e6273f4163d2e7")
  (:PATH "tests/fulltext/put-guards.lisp" :GIT-BLOB
   "6b531c1b143860a46e84d5c77da982f54fbd413b")
  (:PATH "tests/fulltext/put-lifecycle.lisp" :GIT-BLOB
   "8cba90b629299c8494194a73ef8b819f554ca557")
  (:PATH "tests/fulltext/put-physical-guards.lisp" :GIT-BLOB
   "bd293d0ef1d5596e85859cb85e41639b3a0fd70e")
  (:PATH "tests/fulltext/put-physical-native.lisp" :GIT-BLOB
   "635118c4287ab13b4b98e34d04dc307b97497827")
  (:PATH "tests/fulltext/put-physical-support.lisp" :GIT-BLOB
   "1e81cc2af12f24515debc953d4f7884b07a2e197")
  (:PATH "tests/fulltext/put-physical.lisp" :GIT-BLOB
   "f8d1fa41090aaa40c2146ec9280bff08d968fdce")
  (:PATH "tests/fulltext/put-rows.lisp" :GIT-BLOB
   "0ee39c61cdbb6742eb36d65677030d44c96ad98e")
  (:PATH "tests/fulltext/put-support.lisp" :GIT-BLOB
   "2a3c9b543587b1a9c5402a16f82cfc1c671a6160")
  (:PATH "tests/fulltext/put.lisp" :GIT-BLOB
   "83f9503ec4bd1a6610443bb8eea991e6069c6565")
  (:PATH "tests/get-active/append.lisp" :GIT-BLOB
   "0779a03e322f321a930393c5667e11252b84eff5")
  (:PATH "tests/get-active/construction.lisp" :GIT-BLOB
   "ec2831edef2e452597ce867b026eb73c84fc5214")
  (:PATH "tests/get-active/directory.lisp" :GIT-BLOB
   "48c9a60e58536170a610844e853eae6f91beeff1")
  (:PATH "tests/get-active/preflight.lisp" :GIT-BLOB
   "7f41c04257e0bab10a2ffbc091b02d660029c4df")
  (:PATH "tests/get-active/read.lisp" :GIT-BLOB
   "0ab8c2b2b639a51b0217876a896d9468f41e22de")
  (:PATH "tests/get-active/support.lisp" :GIT-BLOB
   "b0a6f9bda4866f82471ec73120182caa786f7d11")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "ced6f8b39836c1c2ff264822ddaf05d0653bfff6")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/lifetime-support.lisp" :GIT-BLOB
   "cd514970e84f8654318dcc23a6b1ef24323be8a9")
  (:PATH "tests/get-directory/lifetime.lisp" :GIT-BLOB
   "c57261d2de469318402d5bf79f5ab5d27108bb46")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/series-read.lisp" :GIT-BLOB
   "b500bb83170622b6d96edbd363ebc85240064c18")
  (:PATH "tests/get-directory/series-support.lisp" :GIT-BLOB
   "ead990e110b588bb4df35ea17d3816db3b79cee5")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "a5b09ee5120bedc4e946366239dd5e6c978b27d2")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "9e03608bef23c0aa5a69dce8c7dfd09ed818a377")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get-resolver/construction.lisp" :GIT-BLOB
   "322c63ee6576304ca1ab19e28b902b680bc2acae")
  (:PATH "tests/get-resolver/read.lisp" :GIT-BLOB
   "a1788d1aab3f76b9dc29095676ec42f3a1f936a8")
  (:PATH "tests/get-resolver/sort.lisp" :GIT-BLOB
   "442ce9eef4fac8f593a9d94ed08a76b830773563")
  (:PATH "tests/get-resolver/support.lisp" :GIT-BLOB
   "11d5cf0efe8ee4f5606707cc7eca175442a50190")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/image-processes.lisp" :GIT-BLOB
   "11c9ba829c73bb71f54be52710ac699b40b47f60")
  (:PATH "tests/index/image-tests.lisp" :GIT-BLOB
   "3ea1eb66179db5125b2b5137372c70c9d953e95f")
  (:PATH "tests/index/mode-policy.lisp" :GIT-BLOB
   "4513fb320a9f1ced973820d8a9c58ee9a0d73ea6")
  (:PATH "tests/index/mode-support.lisp" :GIT-BLOB
   "14d4c82bd54795844d14ac1d7f1b7ced320c4233")
  (:PATH "tests/index/page-build.lisp" :GIT-BLOB
   "bd600c74e28d32328559e9b9f268b4afa3481a55")
  (:PATH "tests/index/page-cache.lisp" :GIT-BLOB
   "aaace9b80ff3c6ce2ab52a3644be8c56eef4ebfd")
  (:PATH "tests/index/page-chains.lisp" :GIT-BLOB
   "265a85cd6aff51dd8a5ceae50f60ff7b8d63660e")
  (:PATH "tests/index/page-corruption.lisp" :GIT-BLOB
   "880775f39ed5c6352c0ae448b7a830ea63b03a85")
  (:PATH "tests/index/page-fixtures.lisp" :GIT-BLOB
   "0ed84fd77dc21375773651e4bb42e56a2c0a5e43")
  (:PATH "tests/index/page-lookup-support.lisp" :GIT-BLOB
   "8800a152c6f0eefa572fda9e17ee9e5e1ff77023")
  (:PATH "tests/index/page-lookup.lisp" :GIT-BLOB
   "290b471927fc1647a000099d8f3f8b57b878c843")
  (:PATH "tests/index/page-support.lisp" :GIT-BLOB
   "920c631d2763260aec7bcb02d3172d8be1d4b21f")
  (:PATH "tests/index/page-tests.lisp" :GIT-BLOB
   "a18f0315e5480a356504f1f541bffc1ad3484fc6")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "d21142f34f3687c35f39c86d962f2c8ffd52c330")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/create-relative-native.lisp" :GIT-BLOB
   "fd5e819e2197869a93259857aacfa68bfe9e9a44")
  (:PATH "tests/io/create-relative-support.lisp" :GIT-BLOB
   "8382ffb8f04b6d2fc3e4adb89f995c9c37b0e445")
  (:PATH "tests/io/create-relative.lisp" :GIT-BLOB
   "7fb4c3665ca1b8f6de2dedd2827cfc150dcddf02")
  (:PATH "tests/io/directory-lock.lisp" :GIT-BLOB
   "4cefd15616f4ac2312a669b1242929d2706eb540")
  (:PATH "tests/io/flush-failure.lisp" :GIT-BLOB
   "76a80588d99b441e8c57a97f9a10d4d9d6c7b59b")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/open-relative-native.lisp" :GIT-BLOB
   "cdb197bf2760de70e7ec49af76e2954a18006997")
  (:PATH "tests/io/open-relative-support.lisp" :GIT-BLOB
   "4256567b2a10423a41540298317c8ef80e6b5af0")
  (:PATH "tests/io/open-relative.lisp" :GIT-BLOB
   "4bec9451a13db1437e081bda2858d4cb8b1e5de1")
  (:PATH "tests/io/readiness.lisp" :GIT-BLOB
   "1a7ce2205d7278a080395a3f4287540e11d3bea4")
  (:PATH "tests/io/rename-native.lisp" :GIT-BLOB
   "99f79041529d20d0ea774b01e3ed82fc5a274cdd")
  (:PATH "tests/io/rename.lisp" :GIT-BLOB
   "e83443eec6187d53118795c4f6ee797112f27ea2")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer-failure.lisp" :GIT-BLOB
   "c87c80fb9c82062bf4d4179d67f710ff10b4f051")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/local/native.lisp" :GIT-BLOB
   "b8891b57aa6229995b7c6ee5581d9cde650e3c93")
  (:PATH "tests/local/processes.lisp" :GIT-BLOB
   "937434fd8d56bd4e4a1961d7ee17d8673c4acbb9")
  (:PATH "tests/local/server.lisp" :GIT-BLOB
   "049822aa7abc1acf525920011be267d49320a0cf")
  (:PATH "tests/local/wire.lisp" :GIT-BLOB
   "349d7df061b5871658ad3fa6a14601bd58f1fa2c")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery-active-checkpoint/guards.lisp" :GIT-BLOB
   "cae7d70c2a5598bb5c3e1256ef4bb8b391656f6f")
  (:PATH "tests/recovery-active-checkpoint/publication.lisp" :GIT-BLOB
   "a996bc5f82f16fe12a74d9bee5962f8d8629f53a")
  (:PATH "tests/recovery-active-checkpoint/semantics.lisp" :GIT-BLOB
   "a4b80a1a678cdc4537ee9d989f178124829e70cb")
  (:PATH "tests/recovery-active-checkpoint/support.lisp" :GIT-BLOB
   "998ab160b939c93797fc90206a9b50f2cf55e452")
  (:PATH "tests/recovery-active/publication.lisp" :GIT-BLOB
   "8a3c4ba88dd7010c65a464d231ebdab2c8c27e67")
  (:PATH "tests/recovery-active/read.lisp" :GIT-BLOB
   "63f52ee0e0ab244ed278562a5d7fbc752b7617e7")
  (:PATH "tests/recovery-active/semantics.lisp" :GIT-BLOB
   "1d3c935a1169904c900461b67adb96f4dfd96b94")
  (:PATH "tests/recovery-active/support.lisp" :GIT-BLOB
   "5ebf9d06ae855b07875aadc10e2a8ac01ba56036")
  (:PATH "tests/recovery-archive-csn/guards.lisp" :GIT-BLOB
   "a6d91274479da64fa689ca370ff495cc96ae0e51")
  (:PATH "tests/recovery-archive-csn/native.lisp" :GIT-BLOB
   "d66af858c855e39c984f1ff8534e6de3c7c7fc88")
  (:PATH "tests/recovery-archive-csn/plan.lisp" :GIT-BLOB
   "b740c77023c500208ff742e02c4d5aebcd44db70")
  (:PATH "tests/recovery-archive-csn/set.lisp" :GIT-BLOB
   "d163bf160241d2225ac3282c1d925aa65e249ab3")
  (:PATH "tests/recovery-archive-csn/support.lisp" :GIT-BLOB
   "0c458a3f6f8aa062c2cc8831834c29159e09762d")
  (:PATH "tests/recovery-archive/active.lisp" :GIT-BLOB
   "ccbaaa3294880905584ad42c0601201fa3a3dc36")
  (:PATH "tests/recovery-archive/guards.lisp" :GIT-BLOB
   "8afea2a3df30099c07badd7d9c0bcf627a5f9a9d")
  (:PATH "tests/recovery-archive/native.lisp" :GIT-BLOB
   "ae8df9ced72f9142ade184ec78bdc576e05593e1")
  (:PATH "tests/recovery-archive/query.lisp" :GIT-BLOB
   "b0a56949ec13ec7c80466ac8b3cecc79c0fc6d63")
  (:PATH "tests/recovery-archive/read.lisp" :GIT-BLOB
   "22d1042700435e2c15e3f610f9ada9c4a8d8d4ed")
  (:PATH "tests/recovery-archive/support.lisp" :GIT-BLOB
   "0cbefaed0f74c8e34e4cea9a359c58f9196f22ad")
  (:PATH "tests/recovery-closed/csn.lisp" :GIT-BLOB
   "754611c3818a0aac26b189392d4024a251439d0c")
  (:PATH "tests/recovery-closed/guards.lisp" :GIT-BLOB
   "344857641ef2206d4d5a800fbb93b834a9f13c4d")
  (:PATH "tests/recovery-closed/publication.lisp" :GIT-BLOB
   "72f179d28936100b91d1847eeb8a24c696552619")
  (:PATH "tests/recovery-closed/read.lisp" :GIT-BLOB
   "0e401337f36768cd63206cbb7b6adf91eeeeb1ef")
  (:PATH "tests/recovery-closed/semantics.lisp" :GIT-BLOB
   "a931be1523c72d49e955aa7708bec6bd3b273be0")
  (:PATH "tests/recovery-closed/support.lisp" :GIT-BLOB
   "15bafc01c04fe1763d9a6580f6ad0bbb1917f40c")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "e6f289d77025dce439787287abc6a4dde0ac69f5")
  (:PATH "tests/recovery/inventory-directory-native.lisp" :GIT-BLOB
   "8f89629becea88fdc74c920a59676412c3a7b976")
  (:PATH "tests/recovery/inventory-directory-support.lisp" :GIT-BLOB
   "c316b3647e7ea5391d687917fe802907f2273bb4")
  (:PATH "tests/recovery/inventory-directory.lisp" :GIT-BLOB
   "ead38feadd94f49276596d0abf989f29d13af497")
  (:PATH "tests/recovery/inventory-id.lisp" :GIT-BLOB
   "1f05c46bfc887984c476bd7673d2b2dde998c44d")
  (:PATH "tests/recovery/inventory-sources-native.lisp" :GIT-BLOB
   "86144ee3fe19ef0f2a54c9760ed193860881ced4")
  (:PATH "tests/recovery/inventory-sources-support.lisp" :GIT-BLOB
   "36b79c4091825c32ffc3aa32a146ee5121881ebc")
  (:PATH "tests/recovery/inventory-sources.lisp" :GIT-BLOB
   "3ffd5a9fb098ab4aeb091a6823fcec68d22c19aa")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest-transition.lisp" :GIT-BLOB
   "cdde7b60edddd974153ee670d859a94993afa367")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/runtime/adoption.lisp" :GIT-BLOB
   "8fbee7f08a25445b66895ae2e329a217070f67f4")
  (:PATH "tests/runtime/bootstrap.lisp" :GIT-BLOB
   "1398120574f95ebaec3c7431a74a35e0ced01652")
  (:PATH "tests/runtime/guards.lisp" :GIT-BLOB
   "a097cc38e13a1ef7369a2ed996d042718cf7312c")
  (:PATH "tests/runtime/native.lisp" :GIT-BLOB
   "e92ba03fb8184a6c95c44269a26a831b714974a1")
  (:PATH "tests/runtime/support.lisp" :GIT-BLOB
   "7d4dc59eab68672512aed0f4ae578436e669fe2e")
  (:PATH "tests/runtime/threads.lisp" :GIT-BLOB
   "2454593a231d5d6bb9ef4318eb06567ce3192d24")
  (:PATH "tests/scheduler/controller.lisp" :GIT-BLOB
   "8e14282e1f42f3b247a5c578d8a683ddc6147381")
  (:PATH "tests/scheduler/dispatch.lisp" :GIT-BLOB
   "6a493f0022ac8c9b6117c2a62df49fa596194c7b")
  (:PATH "tests/scheduler/lifecycle.lisp" :GIT-BLOB
   "874391809401f42a4db81fe544306165f99ceb5d")
  (:PATH "tests/scheduler/pool-begin.lisp" :GIT-BLOB
   "13a239cf97403806a73242abbd5b545440a17645")
  (:PATH "tests/scheduler/pool-chain-support.lisp" :GIT-BLOB
   "a1ea8258495b9a717e1e0ef164133f6b7140f8a5")
  (:PATH "tests/scheduler/pool-chain.lisp" :GIT-BLOB
   "86675c17ea47eff262cb03cdb41e50bcdb82b78e")
  (:PATH "tests/scheduler/pool-claim.lisp" :GIT-BLOB
   "f636ee873deb2cd5347a50c9aec4a6afa16d13c5")
  (:PATH "tests/scheduler/pool-recycle.lisp" :GIT-BLOB
   "3c779589cd7df6ae1146c2ca50b70320093bbf4a")
  (:PATH "tests/scheduler/pool-start.lisp" :GIT-BLOB
   "ec19bb409799e7956e40c34cc9264d02033cfb22")
  (:PATH "tests/scheduler/pool-step.lisp" :GIT-BLOB
   "d0ff803608990744408749722210e812f6268782")
  (:PATH "tests/scheduler/support.lisp" :GIT-BLOB
   "f2301a1adf44c33284aaa1171acd90c5828b0396")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "ef3d4671b3df48b932c1666f8b58fdca4eecbc77")
  (:PATH "tests/series/log-binding.lisp" :GIT-BLOB
   "c116a9169058ddd9e384fda5f52bb5787977e20e")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "257c6f8cf28bdd8408a3363041d621497f4a5f67")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "c3eb1ce7870b81944c23efac9b8cb7f8f4888ba9")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/verify/canonical.lisp" :GIT-BLOB
   "66f603183d98b01acf07228f19bf3025e48254d7")
  (:PATH "tests/verify/cli.lisp" :GIT-BLOB
   "93078b49e212420f81f52083a7b717a163b7727f")
  (:PATH "tests/verify/guards.lisp" :GIT-BLOB
   "d2511620da049cd377a4847e74b82f7200fbebcd")
  (:PATH "tests/verify/observer.lisp" :GIT-BLOB
   "ecc44b603fba3142bc5a069d3d2be22e8e76a55a")
  (:PATH "tests/verify/order.lisp" :GIT-BLOB
   "1e61ba11c977de74cadbe950bc68fe6d3fb11170")
  (:PATH "tests/verify/processes.lisp" :GIT-BLOB
   "feb165176cc6c6661b30453513c21f981cb58113")
  (:PATH "tests/verify/support.lisp" :GIT-BLOB
   "668b4909687394df5b41f27fd0636f22027ca1ab")
  (:PATH "tests/vertical/method.md" :GIT-BLOB
   "3e60572557391e2c772d3b44491ae18eecb352bf")
  (:PATH "tests/vertical/processes.lisp" :GIT-BLOB
   "059fbd2bb702e76e986b97edfbe4d3784599d583")
  (:PATH "tests/vertical/resume.lisp" :GIT-BLOB
   "6f80a0d0fec9f725beca54d06d961932bd815043")
  (:PATH "tests/vertical/scenarios.lisp" :GIT-BLOB
   "fcbc7878d56720604f0e86a916d2e42c0f28cffd")
  (:PATH "tests/vertical/support.lisp" :GIT-BLOB
   "37c2e8d1da68eb425cdd11548f8699c888afd7bf")
  (:PATH "tests/wal/append.lisp" :GIT-BLOB
   "2e0d75a68d6ca657634c22fcb5632d1cf5fa8a1a")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/arcdocdb-verify.lisp" :GIT-BLOB
   "5aed85033d701c64e2c4698fae58dcb947dc80e8")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-float-write-audit.lisp" :GIT-BLOB
   "485544868eeadff247968b86c2d5da9b3b610295")
  (:PATH "tools/cbor-float-write-bench.lisp" :GIT-BLOB
   "d992c9f8cf6ff0d748fcb77f871fb77969480bca")
  (:PATH "tools/cbor-float-write-mutation.lisp" :GIT-BLOB
   "5d0d6bd46b0286f153ee9c482734c659959396e2")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-read-driver.lisp" :GIT-BLOB
   "a6b65bd233dba2a2eec941d96a75b9db948d19f8")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-parallel-tests.lisp" :GIT-BLOB
   "a49a03a64a137e66c07c98f981327fc42d9cb508")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "e3df9f52590ce2de86ad75b872c859b81bbcc518")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "1f63d49150e6b7b23c1df2a9c25c3d2288861b8a")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "253fea1c65c6aacb77fa56f2ab05cce086a1856d")
  (:PATH "tools/ci.lisp" :GIT-BLOB "c0b6255982f4299b883992f5829baaebcd2aaa36")
  (:PATH "tools/ci/archive.lisp" :GIT-BLOB
   "03712985b7cf1493a7009a35965cadf6c9902292")
  (:PATH "tools/ci/conditions-self-test.lisp" :GIT-BLOB
   "99f857163fa38683871790731b6f72448cf92ffb")
  (:PATH "tools/ci/coverage.lisp" :GIT-BLOB
   "233ae46d6ab9fab6a74046140323eecc64243174")
  (:PATH "tools/ci/data-self-test.lisp" :GIT-BLOB
   "b5d6a8f505604e3c45d228582933af38713cc01a")
  (:PATH "tools/ci/data.lisp" :GIT-BLOB
   "8cec68fa2e6e5d7e4484a53cde13964b875f9222")
  (:PATH "tools/ci/github.lisp" :GIT-BLOB
   "a2ca20ed9c586b104f59091d174028b3454d6a10")
  (:PATH "tools/ci/identity.lisp" :GIT-BLOB
   "abf3cc722957379e1408d629b81a2d1916a0788b")
  (:PATH "tools/ci/measure-self-test.lisp" :GIT-BLOB
   "18959f2608b1be4ef1b77b0a7d3b1a67735c16d4")
  (:PATH "tools/ci/measure.lisp" :GIT-BLOB
   "7e16fd5b80a7bbce27a0c856a6abd001ff4814ed")
  (:PATH "tools/ci/producer.lisp" :GIT-BLOB
   "a7fab0bcc8dc6a33ed37acb0d391ec1a73674493")
  (:PATH "tools/ci/publish-self-test.lisp" :GIT-BLOB
   "400b9ba4c1c3fd0e6bd158f3f89bcc58e802c595")
  (:PATH "tools/ci/publish.lisp" :GIT-BLOB
   "d8a212faaa5bba7df102377a70e6cd9d75d7810c")
  (:PATH "tools/ci/self-test.lisp" :GIT-BLOB
   "8b2cfa7eab4f728c70a4f0f6e4a81da3259a9e38")
  (:PATH "tools/ci/support.lisp" :GIT-BLOB
   "b5fe7c565ed0f885b666d8dba836bec4a7ba4c65")
  (:PATH "tools/ci/test-self-test.lisp" :GIT-BLOB
   "518ac77485351807b4b72c0cc7e030821ec81ab0")
  (:PATH "tools/ci/tests.lisp" :GIT-BLOB
   "9c81cf6aec5f89896d9e4ccdcd59ccf1d3c65c6f")
  (:PATH "tools/ci/workflow-self-test.lisp" :GIT-BLOB
   "f0278d9bc21245d6890e52011414627376bca5de")
  (:PATH "tools/collect-command-archive-tests.lisp" :GIT-BLOB
   "49da390b7e170acc9ffdafa78285f215aec75f44")
  (:PATH "tools/collect-command-archive.lisp" :GIT-BLOB
   "d2eb1bd8a62b0fd98ec023243b2a768c19988dc7")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/control-checkpoint-bench.lisp" :GIT-BLOB
   "f631bbb7096359592fde0ae2b4462c2d2067d5a1")
  (:PATH "tools/control-transition-bench.lisp" :GIT-BLOB
   "40fd5a04dc62cced8e688ed30f59e0d810716a43")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/engine-crash.lisp" :GIT-BLOB
   "04c4796c05bdcecf6d8fc83d3ee1eafcf969fed9")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "abd8e62e937c60e9ac68c3ccce904111388bff09")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "f520ecdb46cc94e07d774d39cb73beed380aa867")
  (:PATH "tools/fulltext-codec-fixture.lisp" :GIT-BLOB
   "f6756e030cdde7beaab41a6b38516950f1663c9e")
  (:PATH "tools/fulltext-persistence.lisp" :GIT-BLOB
   "ab0dbf4ec2e5335721818cc03711b92d7d62111d")
  (:PATH "tools/fulltext-qualification.lisp" :GIT-BLOB
   "d649e9cafa96bcb4351bbced5de04bb10352ab85")
  (:PATH "tools/fulltext-unicode-tables.lisp" :GIT-BLOB
   "ba86b196441a40e662f6052e189074eef08b75d5")
  (:PATH "tools/get-active-init-bench.lisp" :GIT-BLOB
   "c62f2bf8ba96c3e80cdd50ba067e4c4df3e5e957")
  (:PATH "tools/get-active-init-mutation.lisp" :GIT-BLOB
   "b2cd809d99d049757156ddf0141997e3b67903b4")
  (:PATH "tools/get-cost-bench.lisp" :GIT-BLOB
   "696d56846ce992f186da2b468f8de55063532b02")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "45897c0afa972a437bbb595493b87dd0c8ed9710")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/get-resolver-coverage.lisp" :GIT-BLOB
   "5ab21d923b68e35adbc177ecd352bb33340f0c07")
  (:PATH "tools/get-series-bench.lisp" :GIT-BLOB
   "2950d4fcb7fc93fbfc7d78c860f0ac43ed984f35")
  (:PATH "tools/get-series-capture.lisp" :GIT-BLOB
   "9c42e23d381751e8140f186f969c6c2ef8d606cf")
  (:PATH "tools/get-series-mutation.lisp" :GIT-BLOB
   "3d3e887ba8e1d90612e561dfffb3d71c486e813b")
  (:PATH "tools/get-throughput-bench.lisp" :GIT-BLOB
   "6554b119583602b9d06b3ff7b2bb9c8104130d79")
  (:PATH "tools/index-image-crash.lisp" :GIT-BLOB
   "01f7cec3a08a55fcf51b4c743e588ad53a0023ae")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/io-completion-mutation.lisp" :GIT-BLOB
   "7fd59fd86e2d477a6b6ee0f7a2142f8ea6b073c6")
  (:PATH "tools/io-rename-bench.lisp" :GIT-BLOB
   "988d259af126212adc2be8fb9ca9acd8755fdce0")
  (:PATH "tools/io-rename-mutation.lisp" :GIT-BLOB
   "dfc691c88e9ab940a065703a223a1c414454b0f2")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/legal-notices.lisp" :GIT-BLOB
   "f120b9660591fd3eda904c9cf0722bddae3f05a0")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "adf3ca235874a2b950e57ea61a719c4c90e9dda8")
  (:PATH "tools/local-client.lisp" :GIT-BLOB
   "1ab2f474ad7db04a3fc8cc6dd7e84a2441498d20")
  (:PATH "tools/local-fault-server.lisp" :GIT-BLOB
   "92cd3d6164c6000c181374e3b917bbf1bb83aaa6")
  (:PATH "tools/local-group-server.lisp" :GIT-BLOB
   "924184dbc27702cbf84cf13b0cdb6e0d62a00bb5")
  (:PATH "tools/local-server.lisp" :GIT-BLOB
   "517652d80ad2d4fbbe85be42fa110d4c902d8cf8")
  (:PATH "tools/local-tests.lisp" :GIT-BLOB
   "02aace929b7f5e2fd790c02d1557628ea17d7afc")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/measure-pool-begin.lisp" :GIT-BLOB
   "e3094d9f35efdaa647751f19a7acda00c36d515a")
  (:PATH "tools/measure-pool-claim.lisp" :GIT-BLOB
   "712a4a5393b69539f02cd625223918e404b331d3")
  (:PATH "tools/measure-pool-dispatch.lisp" :GIT-BLOB
   "bddb449176d3b7b6ae946e841a0ca3202e6c28ef")
  (:PATH "tools/measure-pool-lifecycle.lisp" :GIT-BLOB
   "3a229eecc3c158cec9af8fad6abd5fc2d980e2dd")
  (:PATH "tools/measure-pool-recycle.lisp" :GIT-BLOB
   "cb20f6d271889a9801106daf230ee934aaa7bf81")
  (:PATH "tools/measure-pool-start.lisp" :GIT-BLOB
   "e6be453833925b89cdc49303b99a23374f3b2689")
  (:PATH "tools/measure-pool-step.lisp" :GIT-BLOB
   "cdcb410e27475282d157b0d64a4656ea6ad069a1")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/pages/bootstrap.lisp" :GIT-BLOB
   "a9cf9ea45672b576b76acf1e4773c2c2949bc2ca")
  (:PATH "tools/pages/build.lisp" :GIT-BLOB
   "e319acad4fe5bf1f9cd14b65772775c95ab632fe")
  (:PATH "tools/pages/check.lisp" :GIT-BLOB
   "b0524f02c494e61f4edf08aa2802ba1a3d16cd66")
  (:PATH "tools/pages/code-reference.lisp" :GIT-BLOB
   "16bf45ca14cc936283e32700698e696f4a36a09c")
  (:PATH "tools/pages/code-source.lisp" :GIT-BLOB
   "8ba99903d3afdae918fd8966410fbbaf7438066f")
  (:PATH "tools/pages/code-tests.lisp" :GIT-BLOB
   "1f1349e749863b14d9690a33dda48537d96434e3")
  (:PATH "tools/pages/dependencies.lock.lisp" :GIT-BLOB
   "f0f339aabf9998e7f910f8904744549766426ec6")
  (:PATH "tools/pages/editorial.lisp" :GIT-BLOB
   "f5a43b2ba1a876c3643ad4b3b64b43096c193b49")
  (:PATH "tools/pages/generate.lisp" :GIT-BLOB
   "56ee4dcf36cc76e82b3997357630eca1083dadff")
  (:PATH "tools/pages/markdown.lisp" :GIT-BLOB
   "a6ce370b0cbbeb2869c88112b69ee7aa38e7effa")
  (:PATH "tools/pages/model.lisp" :GIT-BLOB
   "bed6a6fb53b8efb13020bcf5cc5d1ec27aa31436")
  (:PATH "tools/pages/publication.lisp" :GIT-BLOB
   "8154535b76733cbdd33b3217744481635860a5a0")
  (:PATH "tools/pages/runtime-check.lisp" :GIT-BLOB
   "f9ab88e954f1b07f9c59594f55e67e909ee5f2e3")
  (:PATH "tools/pages/site.css" :GIT-BLOB
   "8069a0942d7ce79b272d8011c4f6c6002aae07e1")
  (:PATH "tools/pages/site.js" :GIT-BLOB
   "06770c92736cc6bd2b3e0c9638ec09f5c0dcc1c3")
  (:PATH "tools/pages/tests.lisp" :GIT-BLOB
   "d05b62748b36cefed5977d1a445c18e1d70b8e62")
  (:PATH "tools/pages/theme.lisp" :GIT-BLOB
   "547ef0acc0e6070c7fcd53385b0efed1aec5f82d")
  (:PATH "tools/pages/third-party-notices.lisp" :GIT-BLOB
   "907abf85677565bb547a4b7f0e7c6311b3bfa3ce")
  (:PATH "tools/pages/third-party-notices.txt" :GIT-BLOB
   "68ebcf8172dcbbf0865767f5194abb97911a83ef")
  (:PATH "tools/pool-controller-bench.lisp" :GIT-BLOB
   "cf6f31dd9c7a8d7f4e7cc1f19c4b9c5a48af6d55")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "068090ec38864b2b55877918aec57375312ee8db")
  (:PATH "tools/recovery-active-bench.lisp" :GIT-BLOB
   "9c11d5654a6168c27c64abcc8f852673c5974515")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/vertical-crash.lisp" :GIT-BLOB
   "8f920374d5b1049f5bac1e8dfb441099575de6cd")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :STDOUT "(:KIND :BENCHMARK-DRIVER :SELF-TEST NIL :SHA256-OUTPUT
 \"d0e79d2cb35c90456cc3009365053a7782effe481be09c2ea5da5cfefbf34347  /Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-engine-group-append/bench.lisp
\")
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 0 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 477237 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4333 3947 3053 3907 3086 3019 3901 4027 2987 4004 3976 3101 3916 4025 3989
   3998 3997 3058 3017 3924 3102 3896 4012 3986 3985 4030 3993 3046 2986 3960
   3990 4017 3965 4034 4013 3978 4003 3990 3054 3952 4001 4000 3979 3080 3916
   4039 3994 3987 4020 3973 3982 3065 3947 3990 3986 4027 3053 3932 4011 3051
   3918 4002 4002 3064 3018 2975 3949 3987 4001 4007 3998 4015 3070 2982 3934
   3980 4038 4006 3956 3140 2934 3947 3041 3938 3993 4040 3964 3993 3100 3934
   3039 3923 4029 3999 4016 3980 4012 3992 3129 3004 3865 3980 3152 2950 3928
   3970 4008 4012 3050 3936 4006 3107 3873 4013 3074 3930 3061 3918 4023 4042
   3938 4042 3984 3965 3110 3892 3199 3812))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 1 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 480755 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3839 3987 3994 3989 4051 3952 3982 4006 4021 3968 4027 4026 3957 3997 3128
   3883 3087 4160 3789 3874 4058 4004 4005 3984 3078 3912 3075 3012 3893 4035
   4002 4016 3060 3932 3055 3927 4005 3997 3991 4005 3072 3920 3970 4036 3091
   3899 3997 3990 3989 4041 3993 3102 2937 3953 3994 4005 3076 3916 3998 3083
   3933 3997 3991 3996 3056 3021 3930 4025 3968 3973 3104 3977 3009 2992 3960
   3012 3986 3093 3878 4023 3994 3982 4002 3065 3916 4042 3988 3989 3057 3963
   3032 3973 3976 10703 4299 3984 4003 3986 4026 3055 3020 3937 3047 3928 3093
   3906 3072 3951 3960 3104 3968 3946 3062 2999 2996 3962 3047 3939 3037 3950
   3059 3965 3040 3931 3240 3775 3059 3923))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 2 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 470467 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3679 3814 3074 3917 4000 3983 4001 4013 3048 3926 4000 3103 2964 3934 3073
   3949 3032 3967 3106 3880 3052 3947 3027 3944 3089 3927 3036 3951 3069 3926
   3060 3928 3076 3949 3994 3987 4007 3985 3068 3956 4003 3029 3060 3872 3055
   3960 3046 3979 3155 3843 3115 3845 3066 3955 3062 3938 3095 5942 3042 3923
   4000 4033 4027 3932 4000 4010 4002 3988 4009 4011 3999 4197 3788 4014 3985
   3043 3957 3992 4012 3038 3940 4022 3994 3047 3962 3978 4002 3155 3891 3964
   3998 3048 3934 4024 3966 4064 3941 4007 4002 3054 3953 4008 3993 3021 3969
   3037 3976 3031 3961 3043 3947 3063 3966 3015 3952 3083 3942 3080 3901 3047
   3967 3076 3944 3031 3047 3893 4017 3988))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 3 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 472224 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4293 3442 3515 3009 3988 3966 4026 3017 3977 4005 4013 3040 3950 3998 4036
   2994 3955 4008 4049 2961 3984 4002 3957 3100 3928 3980 4021 3043 3938 4007
   3996 3999 4002 4001 4007 3986 3997 3990 4027 3029 3946 4013 3991 3063 3924
   4037 3980 3057 3962 3982 4009 3051 3928 3987 4042 3972 3994 4014 3969 4027
   4000 3981 4027 3042 3936 4011 3998 3042 3967 3051 2980 3143 3805 3072 3033
   2965 3945 3054 2969 3028 3962 3046 2986 3005 3940 3059 3018 2977 3944 4019
   3992 3968 4007 3084 2999 3002 3923 3992 3082 2989 3968 3965 4001 3059 3940
   4015 3974 3071 3945 3983 4022 3027 3971 3970 4037 3032 3966 3991 3978 4008
   4021 3978 3995 4036 3041 3068 3887 3991))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 4 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 449636 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4722 3961 3052 3937 4014 3034 3057 3904 3996 3061 2980 3937 3983 3082 2940
   3964 4027 3051 2997 3930 3978 3076 2993 4020 3960 3027 3029 3935 3974 3052
   3026 3930 3994 3053 3008 3937 3986 3112 2957 3935 4017 3042 2983 3955 4001
   3096 3007 3918 3973 3070 2989 3953 3978 3096 2960 3940 4020 3045 3030 3926
   4009 3062 2964 3991 3956 3047 3174 3775 4016 3061 2978 3977 3977 3035 3036
   3939 4002 3043 3004 3949 3984 3068 2952 3978 3999 3067 3029 3914 4007 3063
   2983 3936 4028 3042 2984 3949 4003 3058 3014 3929 4024 3048 2957 3953 4005
   3154 2948 3908 3997 3058 2993 3937 4012 3065 3003 3921 4004 3044 2992 3992
   3963 3066 2995 3945 3994 3043 3086 3872))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 0 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 236642 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3690 2925 3879 4033 3011 3009 3937 3975 3102 2996 3904 4011 3074 2995 3937
   4013 3036 3954 4006 4009 3981 3928 4080 3985 3997 3975 3992 4022 3970 4025
   4004 3970 4044 3055 3912 4021 3981 4001 3068 2996 3907 4022 3076 3011 3926
   3989 4008 3090 3893 3075 3010 3931 3984 4012 3993 3998 3126 3072 3797 4012
   3991 3990 4048 3148))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 1 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 248328 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4358 3941 3987 3080 3906 4021 3990 3096 3876 4046 4000 3090 3936 4000 3928
   3105 3938 3983 4039 3934 4024 4005 4014 3990 3975 4017 3981 4031 3988 3992
   4000 3989 4020 4005 4055 3956 3985 4025 4005 3993 3998 4001 4015 3986 3979
   4005 3167 3827 4002 4018 3050 3946 3988 3987 3091 3924 3991 3994 3104 3905
   4009 3996 3964 4047))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 2 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 239977 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4061 3053 3886 3997 3968 3123 3884 3106 3019 3885 4006 4017 3963 4001 4042
   3993 3973 4038 3985 3083 2961 3936 3983 3958 3117 3899 4018 3075 3905 4009
   4006 3075 3931 4003 4003 3995 4003 3987 3988 4025 3971 4031 3971 4016 3081
   3917 3996 4009 3107 3869 4012 4018 3979 4018 4028 3005 3042 2991 3911 3130
   3871 4001 3064 3950))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 3 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 245874 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4038 3837 3964 4005 4031 3973 4001 3998 4005 3996 4010 3979 3999 4021 3987
   3997 3977 4039 3984 4002 4030 3021 3974 3978 3976 4030 3990 4001 3983 4028
   3983 4009 4001 3961 4023 3968 4001 3076 3024 2979 3012 3946 9776 3293 2952
   3950 3072 2947 3998 3992 3061 3934 3111 3890 3067 3107 3836 3988 3024 3029
   3931 3963 3138 3962))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 4 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 240078 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4154 3993 3968 3070 3937 4008 3071 3915 3982 4036 3059 3947 3965 4011 3108
   3888 4008 3980 3054 3956 3951 4007 3112 3901 3985 4024 3065 3940 3976 4019
   3051 3931 4022 3982 3086 4049 3856 4035 3035 3920 4013 3995 3080 3910 4007
   4006 3110 3910 3971 4004 3137 3862 4012 4016 3023 3966 3996 4005 3050 3937
   4008 4008 3077 3897))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 0 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 124271 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4342 3955 4004 4014 3976 4012 4004 3977 3988 4024 3991 4017 3981 4028 3974
   4014 4028 3935 4030 3973 3987 3112 3906 3989 4021 3066 3948 3970 3996 3104
   2984 3907))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 1 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 122584 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4643 3973 3065 3924 3981 4006 3077 3938 3987 4059 4150 3813 3004 3954 4003
   4017 3067 3899 4011 3999 4010 3993 3987 3074 3940 3993 4000 3059 3940 4000
   4003 3999))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 2 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 120336 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4226 3010 3962 3974 3992 3136 3859 3986 4014 3985 3097 3927 3045 3941 3091
   3889 3107 3883 3092 3929 3985 4030 3998 4004 3977 4004 4003 3989 4010 4043
   3950 3191))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 3 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 119891 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4873 3968 4006 3049 3916 4014 3997 3066 3921 3084 3938 3994 3979 3090 3920
   4005 4044 2998 3961 3969 3073 3888 3198 3859 3060 3926 3984 4026 4015 3987
   4009 3060))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 4 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 120013 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4025 3012 3056 3866 3998 4004 4002 3993 3073 3942 3986 4014 4005 3969 3997
   4013 4009 3987 4017 3969 3095 3953 3970 3969 3091 3915 3991 4019 3046 3931
   3103 2984))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 0 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 59624 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4661 3920 4014 4015 3990 4006 3083 3929 3986 3058 3935 3062 3006 2999 3942
   4012))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 1 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 62836 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4807 3974 3949 4021 3995 4021 3994 4006 4004 3979 3163 3887 3972 3997 4056
   3002))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 2 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 61697 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3932 3115 4651 3077 3915 3990 4040 3973 3983 4014 4013 3980 4020 4000 3053
   3936))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 3 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 60305 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4374 3937 3113 3907 4007 4201 2871 2966 3937 3979 4020 4012 3057 3937 3988
   3995))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 4 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 60432 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4473 3042 3931 3990 3027 3968 3938 4063 3169 3810 4128 3904 3969 4019 3073
   3921))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 0 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 487093 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4197 3015 3936 4010 3994 3962 4030 4060 3053 3851 3138 3890 3989 3059 3985
   3950 3995 4055 3932 3119 2991 4041 2966 3892 3970 3080 3941 3960 4024 4019
   3985 3071 3007 3913 3089 3936 3988 3076 3913 3985 4001 4021 3995 3066 3080
   3852 3081 3917 3988 3117 3891 3999 3992 4011 4020 3968 3081 3932 3967 4024
   3985 4004 4003 4009 4007 3995 3981 4003 3132 3889 4001 3998 3979 4018 4197
   3808 3990 4000 3981 4011 3100 3896 3995 4016 3987 3995 4015 3999 4012 3981
   3989 4005 3097 3910 4018 3982 3997 4009 4005 3986 4005 3999 3977 4013 3097
   3899 4001 4006 3986 3999 4026 3985 4012 3982 4012 3986 3115 3898 3992 3090
   3894 4013 3061 3920 4001 3069 3943 4001))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 1 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 470916 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4899 3958 4041 3123 3822 4018 3124 3881 4005 3117 3836 4019 3990 3982 4024
   3067 3903 4032 3077 3883 4028 3115 3885 4001 3070 3892 4044 3087 3871 4006
   3081 3921 4004 3122 3859 4014 3999 3996 4003 3098 3905 4000 3097 3890 4022
   3983 4035 3958 4023 3970 4005 3111 3905 3996 3110 3887 4028 3082 3888 4002
   3997 3988 4007 4062 3029 3909 3123 3877 4006 3987 4039 3963 4004 4017 3984
   3082 3016 3911 3059 3936 4011 3089 3902 3965 4008 4013 4048 3047 2987 2996
   2992 3939 4006 3082 3890 4034 3969 4117 3902 3064 3020 3895 3094 3914 4015
   3069 3934 3994 3978 4008 3999 3094 3004 2994 3891 4030 3998 3063 2999 3014
   2973 3929 3093 2968 3022 3933 3098 2981))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 2 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 460056 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3244 3788 3121 3862 3141 3883 3973 3120 2999 3887 4031 3027 3013 3905 3979
   3147 2918 3984 4023 3046 3918 4483 5512 3984 4000 4006 3990 3043 3961 4001
   3995 3043 3959 3965 4009 3083 3912 10757 4293 3051 3918 4015 3049 3143 3784
   3062 3027 2998 3918 3081 2984 3000 3931 3072 3017 3921 3980 3095 3937 3978
   3998 3074 2988 3934 4003 3079 2997 3893 4019 3080 2996 3918 4043 3962 3198
   3830 3979 3988 3117 3886 3086 3914 3076 3915 3097 3936 3035 3955 3056 3934
   3080 3908 3091 3928 3085 3897 3067 3013 3039 3885 3283 2777 3009 3924 3079
   3012 2971 3949 3978 3083 3026 3896 4010 3068 3014 2991 3911 3104 4931 3070
   3896 3069 3000 2998 3924 4012 3084 2982))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 3 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 448301 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4391 3956 3050 3017 2989 3918 3054 3041 2995 3897 3108 2956 3017 3898 3018
   3986 3055 3941 3086 3925 3056 3947 3023 3962 3207 3799 3054 3947 3099 3885
   3130 3869 4006 4011 3078 3898 4010 3987 3094 2976 3947 3992 3052 3046 3886
   4025 3091 2973 3917 4010 3086 3086 3813 3083 3000 3003 2989 3995 3013 2993
   3007 3917 3069 3017 2982 3918 3071 3942 3059 3948 4020 3031 3022 3907 3070
   3945 3058 3931 3075 3921 3068 3966 3046 3909 4037 3980 3065 3932 3064 3924
   3081 3023 3917 3987 3082 2976 3949 3990 3075 2991 3945 4005 3996 3085 3915
   4002 3994 3048 3922 4023 3097 2980 3914 4007 3072 2991 3919 4018 3067 3918
   4011 4003 3063 3003 3909 4033 3059 3937))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 4 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 470699 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4676 3995 3094 3880 3987 4020 3055 3918 4010 4014 3053 3928 3980 3062 3039
   3906 3949 4065 3048 3903 4019 3984 3140 3872 4005 3989 4028 4082 3915 3981
   3967 4027 4010 3973 3092 3928 4008 3972 3107 3902 4003 4006 3101 3886 4012
   3988 5033 3976 3065 3945 3068 3095 3830 3996 3114 2957 3923 4008 3068 3011
   3925 3984 3142 2969 3897 3147 2918 3014 3924 3988 3132 2947 3935 3999 3071
   3056 3857 3999 3996 3076 3937 3072 3011 3016 3898 4002 3993 3049 3944 3989
   4015 3074 3917 4012 3990 3075 3928 3987 4013 3981 3063 3938 4060 3023 3927
   4004 3992 3087 3910 4132 3872 3059 3937 3989 4007 3051 3033 3008 3931 3065
   3910 4013 4014 3070 3909 4009 3987 3094))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 0 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 240590 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3845 3788 3993 3994 4020 3042 3927 4019 3068 3931 3978 4002 4024 3959 3127
   2993 3895 3080 3935 3990 3124 3860 4013 3996 4028 3977 3084 3914 4018 3110
   3885 3980 3101 3908 4001 4002 3996 3986 3185 3848 4014 3113 3854 3960 3109
   3909 4003 3995 4006 3991 3084 3912 4000 3137 3880 4000 3096 3901 4015 4072
   3897 3994 3987 4015))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 1 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 240549 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4661 3968 3992 3991 3993 4009 3988 3107 3894 4039 3948 3964 4041 3993 4031
   3979 3978 3998 4011 3091 3903 4002 5022 3966 4007 3987 4005 4013 3986 4004
   3024 3085 3901 3011 4000 3974 3012 4000 3987 4006 3984 4003 3013 3112 3885
   1894 4115 3987 1858 4142 4026 3973 4023 3985 1926 3166 3893 3111 3888 4040
   3069 3904 3984 3969))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 2 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 238088 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4129 3956 3111 3000 3896 3123 3894 4023 3127 3883 3998 3974 3990 3972 3151
   2975 3893 3073 3943 3994 3105 3877 4005 3999 4001 4022 3077 3896 3997 3116
   3932 3976 3069 3907 4007 3980 4013 4005 3088 3926 3985 3096 3893 4010 3092
   3891 4003 4003 4001 3997 3119 3875 4018 3090 3910 3990 3097 3913 3988 3104
   3906 4000 3975 4006))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 3 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 238578 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4686 3940 4006 3982 4000 4013 4219 2855 3920 3984 3969 4051 4001 3954 4009
   3994 4009 4010 3990 3065 3932 3995 3986 4018 3992 3989 4045 3960 3987 4008
   3108 3002 4036 2948 3906 4000 4008 4006 4013 3102 2981 3003 2999 3896 3104
   3016 3002 2991 3032 2938 3898 4009 3995 3125 3871 4022 3049 3037 3899 3992
   4005 4019 3984 3990))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 4 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 239364 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4336 3062 3925 3943 3110 3926 3984 4006 3985 3261 3749 3997 3099 3871 5010
   4005 3093 2994 3896 3977 3126 3915 3103 3881 3103 3901 3982 3156 2964 3883
   3107 3914 3967 4015 3107 3897 3085 3904 3107 3915 3996 3993 3090 3899 3110
   3908 3133 2922 3038 10757 4148 3094 3884 4011 3990 3102 3920 3985 3999 3088
   3917 3979 3146 2972))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 0 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 115384 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4322 3979 1684 4312 3073 2959 3959 4052 3936 2913 4102 1680 4295 4016 3067
   3938 3993 3048 2949 4000 4004 3980 4140 2998 3970 3908 3125 3988 3037 3828
   4116 4002))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 1 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 117770 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3834 3965 3004 4004 3994 3979 4022 3977 4022 3961 4062 3962 3082 2958 3935
   3108 3937 3983 3979 3079 2953 3964 3140 3962 3983 4026 4010 3954 4049 3974
   3077 1823))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 2 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 123137 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4156 3958 3033 3940 4023 3076 3961 3934 4016 4000 4031 4030 3930 3999 4011
   4012 3989 3994 4036 3970 4080 4016 3882 3072 3090 3857 3132 3992 3995 3894
   4018 4003))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 3 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 122332 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5451 3905 3997 4018 3840 4124 4034 3984 2985 2988 4029 3976 3066 3938 3873
   3164 3921 4046 3850 3138 3993 3082 3984 3953 3915 4078 3961 3092 3940 3952
   4054 3996))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 4 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 117896 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3958 2917 3117 3954 3969 3979 3985 3065 2959 4000 4000 3978 3977 4030 3069
   3922 3034 3972 4005 4168 3839 3982 4028 3996 3989 3994 3046 3971 3059 2956
   3968 3006))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 0 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 72921 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4002 4896 4100 3965 4961 4971 5034 4994 4957 4965 4055 4996 4029 5002 4943
   3044))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 1 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 72826 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4885 4062 4886 5000 4991 4974 4120 3916 4082 4920 4981 4042 4958 4029 3981
   4995))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 2 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 74871 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4893 4943 4050 4899 5034 4999 5001 4986 3983 4017 5008 4997 4038 4977 4991
   4049))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 3 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 68786 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4855 2314 4616 4015 3017 4952 4076 3950 4047 4933 5003 4976 4039 4035 4965
   4987))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 4 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 75131 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5232 4924 4983 4992 4995 4965 5051 4957 3110 4926 3991 5014 4044 3952 4985
   5005))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 0 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 481284 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4356 3107 2941 3027 3877 3991 3991 4027 3972 3063 3972 3052 3917 3983 4034
   3982 4010 3061 3945 3996 3997 4011 3986 4011 3100 2962 3917 3099 3924 3992
   5014 3987 3045 3961 3983 4004 3983 4002 4017 3993 3033 3967 4054 3953 3992
   3970 3076 3952 3950 3091 3966 3957 4006 4011 3988 3988 3103 3906 4009 4012
   4000 3045 3958 3049 3936 3989 3994 3991 4025 3057 3958 3994 3995 4036 3121
   3825 3173 3839 3996 3993 4013 3079 3896 3075 3940 4003 3114 3888 3106 3882
   4047 2996 3965 3994 3977 4017 3072 3920 4017 3961 4086 3074 3868 3987 4026
   4004 3972 4012 4007 3063 3947 4110 2938 3919 3085 3927 4007 3988 4013 3063
   3884 3131 3926 3995 3998 3981 4014 3002))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 1 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 479521 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4563 3910 3123 2959 3943 3982 3976 4012 4000 3118 3883 3072 3945 3110 3898
   3973 3963 4043 3956 3103 3915 3976 4064 3971 3988 4002 3997 3064 3958 3984
   3991 4009 3999 3996 3987 4007 3995 3091 3915 3090 3921 3999 3089 3893 3985
   3112 3885 3105 3919 4001 3028 3981 4000 3064 3911 4025 3965 4036 3985 3021
   3058 3915 4014 3982 4017 3053 3958 3980 4001 4004 4006 4009 3976 3998 4008
   3983 4012 3991 4010 3998 3017 3976 4009 3076 3902 3998 5025 3998 3981 4016
   3981 3096 3911 3076 2943 3989 3050 3943 3080 3916 3978 4014 4047 3958 3993
   3076 3014 3918 4003 4137 3864 3067 3927 4003 3059 3936 4020 3988 3987 3996
   4006 3037 3024 2999 3924 3073 2995 3004))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 2 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 453523 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4542 3016 3316 3615 4013 3024 3031 3008 3914 3077 2994 2980 3943 3035 3070
   2945 3946 3125 2958 3046 3874 4040 3955 2998 4015 3034 3026 3009 3910 3071
   2991 3001 3943 3081 2993 2991 3908 3120 2946 2981 3946 3066 3066 2998 3891
   3042 3013 2982 3951 3087 2930 3036 3956 3968 3097 2981 3946 3991 3060 2991
   3954 3995 3072 3000 3926 4002 3057 2996 3937 4015 3048 2996 3945 4011 3060
   2974 3955 3989 3062 3044 3917 3997 3993 3983 4012 3986 3063 3930 4018 3997
   3118 3866 4001 4003 3103 3893 4014 3995 3056 3955 3981 4004 3063 3927 4014
   3990 3055 3928 4016 4001 9837 4173 4008 3995 4151 3855 4000 3044 3012 2985
   3960 3040 3030 2989 3935 3016 3015 3018))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 3 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 441299 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4386 3029 3003 2994 3910 3079 3028 2916 3994 4009 3046 3950 3982 3980 5029
   3973 4003 4018 3046 3041 2975 3880 3096 3005 2983 3960 3053 2980 3003 3974
   3033 2997 3085 3830 3061 3022 2982 3943 3113 2938 3021 3915 3056 3020 2995
   3926 4047 3953 3066 3967 3026 3939 3065 2970 3023 3962 3047 2994 3016 3934
   3046 3022 3020 3912 3060 2985 3038 3916 3081 2970 3006 3937 3152 2905 3040
   3899 3071 3937 3993 4005 3039 3024 3924 4023 3043 3004 3979 3969 3047 3004
   3939 4002 3050 2998 3946 4008 3043 3075 3864 3998 3071 3005 3945 3986 3082
   2952 3979 3957 4027 3052 3932 3999 3082 3055 3874 4014 3058 2988 3957 3963
   3086 3015 3922 4002 3056 3012 3957 3966))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 4 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 448955 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3210 2888 3899 3998 3044 3001 3963 3961 3091 3009 3932 3983 3068 3092 3825
   4034 3005 3062 3943 3946 3102 3053 3865 4012 3092 2993 3915 3991 3033 3007
   4011 3961 3095 2958 3908 4004 3046 3007 3954 3996 3040 3045 3908 3980 3063
   3003 3949 4005 3063 2977 3952 4001 3045 3027 3931 3987 3059 3026 3936 4003
   3036 3006 3938 4004 3047 3013 3960 3946 3059 3019 4985 3983 3029 3034 3918
   3988 3071 3003 3950 4011 3044 2991 3930 4002 3062 3013 3946 3966 3094 2996
   3911 4030 3061 2958 3985 3997 3026 3033 3945 3981 3061 2976 3945 4195 2879
   2985 3942 3986 3079 2995 3939 3992 3090 2979 3952 4009 3026 3028 3946 3996
   3051 2998 3921 4009 3069 2991 3936 4005))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 0 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 239407 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3662 3761 3989 3996 3112 3886 4020 3993 3078 3890 4020 4004 3121 3882 4023
   3980 3068 3934 3084 3928 3972 4019 3982 4010 3077 3935 3998 3987 3995 3984
   4025 4002 4003 4036 3953 3951 4045 3995 3945 4061 3061 2992 3913 4015 3076
   2966 3945 4012 3071 2999 3926 3985 3101 3027 3912 3993 3101 2938 3935 4048
   3996 3978 4005 3988))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 1 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 247048 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5121 3978 4000 4017 3991 3949 4078 3949 4011 3980 3999 4011 3972 4010 3996
   3984 4011 4013 3082 2959 3927 4005 3091 2984 3944 4000 3057 2999 3921 3996
   3119 2972 3905 4021 3089 2987 3913 3996 4005 3994 3998 4005 3993 4011 3980
   4029 5006 3978 3998 4001 4018 3993 3978 4019 3971 3993 4021 4010 3997 4014
   3055 3917 3998 4001))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 2 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 246383 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3526 3794 3985 3998 3113 3889 3986 4012 3083 3909 3987 4017 4008 3986 4001
   4035 3080 3859 3994 3094 3906 3974 4040 3088 3904 4022 4034 3009 3924 4014
   3990 4014 3988 3990 4011 3998 4001 4012 3998 3969 4018 3993 4002 4005 3997
   4011 4034 3938 4016 3989 3988 4027 4003 3969 4039 3981 3993 3994 4005 3070
   3937 4009 3069 3025))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 3 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 240210 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4323 3955 3044 2983 3915 3995 3083 3038 3916 4005 3055 2996 3909 3993 3118
   2945 3976 4005 3998 3987 3962 4045 3969 4183 3845 4012 3955 4057 3979 3984
   4007 3970 4041 3994 4030 3938 3085 3907 4017 3045 2982 3961 4043 3002 3926
   4032 4001 3986 3127 3874 4001 3075 2965 3958 3996 3994 3151 3842 4005 4008
   4012 3952 4054 3977))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 4 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 215540 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4591 3953 3999 4033 3024 3016 3065 3863 3080 2993 3005 3926 3028 3035 3008
   3930 3003 3062 3002 3927 3072 3024 2936 3953 3042 3011 3017 3907 3084 3015
   2974 3925 3191 3832 3054 3936 3995 4023 4056 3947 3042 3021 2959 3970 3028
   3015 3008 3938 3041 3012 2998 3931 3057 3014 3004 3926 3044 3025 3022 3900
   3062 3000 3014 3942))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 0 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 119299 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3470 3781 3979 4020 3072 3901 4010 3983 3109 2967 3922 4041 3970 3070 3943
   3990 4025 3074 3908 3989 3966 4030 3962 3111 3918 3973 4022 3089 3903 3984
   4018 3088))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 1 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 131864 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4926 3978 3995 3996 3973 3089 2999 3915 3969 4054 10724 4447 2876 3943 3994
   4013 3037 3933 4001 4005 4014 3980 4028 3981 4007 3989 4014 3977 4008 4048
   3969 3975))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 2 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 120220 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3357 3827 3964 4021 3120 3852 4004 4009 3089 3902 4028 4007 3958 4021 4046
   3948 3944 4065 3994 3949 4002 3177 3860 3964 4033 3310 3697 3984 4020 3039
   3015 3005))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 3 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 122063 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4228 3883 3179 2931 3881 3985 3081 3009 3939 3988 3981 4024 3089 3945 3935
   4012 3080 3908 3972 4031 4048 3968 3993 3975 4010 3974 4045 3988 3987 3997
   4011 3974))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 4 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 119619 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4687 3144 3801 4008 3984 3084 3927 3990 3988 3985 3182 2917 3910 3991 5043
   3051 3938 3970 3094 2989 3005 3990 3938 4013 3049 3893 4043 4003 3055 3930
   4018 3982))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 0 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 58641 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4718 3936 4010 3990 3071 3922 3064 2978 3030 2964 3952 3995 4003 3079 3918
   4006))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 1 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 62826 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4024 3843 3972 3991 4023 3097 3888 3991 4007 4001 3994 4004 4001 3983 3993
   4006))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 2 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 57639 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4669 3975 3990 4050 3035 3016 3936 3023 3021 2999 3960 3964 3996 3159 2867
   3973))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 3 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 61000 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4078 3940 3068 3900 4010 4001 3990 3980 4042 3991 3986 3079 3012 3894 4041
   3984))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 4 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 61761 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4652 3017 3956 3963 4021 4004 3020 3964 3973 4018 4003 3989 3975 4045 4005
   3151))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 0 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 478431 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4449 3927 4015 3968 4023 3092 3931 3067 3018 3903 3070 3929 3994 4000 4015
   3962 3967 3106 3923 3090 2993 3926 3033 3966 3956 4023 4040 3979 3956 3123
   3904 3063 3043 3884 3068 3929 3999 3981 4034 3985 3997 3094 3903 3088 3027
   3908 3093 3899 3988 3978 4022 3996 3989 3100 4932 3974 3200 3797 3999 4021
   3985 3985 4010 3992 4008 3998 3174 3830 4003 3986 4003 4015 3975 4021 3086
   3912 4127 3031 3821 4011 3096 3911 3984 4005 3988 3999 3136 3886 3980 3117
   3886 4005 3087 3924 3983 4018 3977 4021 3100 3894 4005 3109 3874 4038 3971
   3978 4062 3969 3995 3995 3988 3112 2985 3914 3071 3942 3992 3085 3905 4014
   3979 4007 3993 3084 3002 3925 3121 2949))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 1 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 485933 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4811 3088 3850 3997 3944 4053 3997 4007 3086 3883 3071 3091 3831 3056 3946
   4003 3993 3998 3974 4024 3083 3916 3208 2868 3897 3113 3905 4011 3100 3877
   4009 3975 4032 3997 3061 3003 3934 3084 3930 3964 3096 3925 3991 3991 3989
   4014 3090 3030 3892 3072 3907 4008 3131 3861 4001 4019 3983 4013 3985 3097
   3921 3973 4030 3975 4007 4016 3980 4014 3989 3991 3992 3099 3921 3964 4047
   3977 4006 3995 4028 3969 4000 3996 3981 3110 3922 3967 4030 3986 3990 4012
   4007 3995 3974 4039 3967 3118 3896 3990 4039 3984 3993 4016 3980 4005 3985
   4012 3987 3123 3909 3964 5018 3979 4002 4018 3999 4003 3989 4001 4029 3045
   3930 3077 3906 3075 3925 3078 3928 3234))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 2 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 431526 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4522 3041 3904 4024 3183 2885 3930 3967 4001 3100 3022 2960 3948 3074 2965
   2944 3978 3079 3010 2953 3987 3046 2977 3952 3958 3097 3036 3012 2932 3045
   3016 2952 3032 2968 3022 3006 2963 3000 3053 2980 2970 3942 3983 3112 2970
   3011 3917 3065 3923 3054 3977 3081 3887 3079 3935 4025 4010 3972 3971 4026
   3063 3913 3086 3005 3899 3095 3007 2980 3934 3070 3044 2956 3921 4005 3062
   3017 3905 4021 3074 2955 3059 3912 3040 3033 2982 3907 3073 3035 2959 3947
   4055 3006 3011 3935 3993 3080 2995 3022 3004 2984 3900 4021 3061 2981 3027
   2979 3052 2956 3094 3027 3146 3698 3974 3988 3093 3025 3897 3997 3041 3071
   3876 3989 3084 3024 3907 4011 3094 2962))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 3 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 426340 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4358 3967 3030 3109 2893 2994 2978 3065 2911 3057 2989 3000 2985 3013 2965
   3054 2960 2986 3915 4005 3055 3038 3007 2972 3030 2994 3009 2983 2959 3040
   2992 3014 3909 3076 3009 3932 3963 3069 4944 3996 3075 2998 3036 3861 3079
   3027 2980 3955 3078 3906 3061 3936 3989 4029 10753 4228 3972 4022 3084 2982
   3935 3102 2985 3021 3901 3058 3025 3027 3875 3110 3892 4002 4017 3067 2978
   3015 3930 3045 3008 3112 3817 3082 3040 2928 3990 3058 2969 3932 4007 3070
   3025 2996 3004 2987 2992 2970 3030 3008 2948 3038 2975 3013 3065 2924 3022
   3954 3958 3067 3042 2956 2998 3030 2987 2987 3011 2979 3001 3013 3014 3036
   2953 2988 3950 3988 3068 2999 2982 3041))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 4 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 430941 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3082 2915 3022 2957 3095 2933 2966 3057 2951 3933 3103 2954 3939 3969 3104
   2998 2958 3039 3072 2906 3027 2973 2982 3031 2969 3087 2986 2904 3122 3826
   3993 3088 2990 3918 3105 2970 3007 3912 3072 3013 2978 3943 3070 3007 3033
   3874 3080 3944 3951 4055 3088 2952 3032 3907 3519 2561 2998 3910 3093 3006
   2991 3934 3069 3005 3916 4001 3053 3001 3027 2999 2990 2993 3018 2987 3133
   2889 2972 3016 3923 3059 3019 3903 3996 3094 2993 3946 3033 3004 3006 3931
   3071 2994 3003 3919 5059 3007 3009 3934 3037 3963 3991 3992 3082 3007 3923
   4010 3066 3030 4043 3884 3980 4004 3978 4017 4040 3034 3914 4025 3983 4000
   3994 3056 3937 4017 3987 3052 3927 3087))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 0 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 237121 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4163 4045 3882 4042 4003 3963 3224 3795 3995 3088 3939 3962 3114 3910 3963
   4018 4001 4001 3986 4009 4007 3983 4012 3073 3024 3891 3088 3933 3040 3040
   2963 3954 3075 4042 3878 3975 4039 3995 3958 3076 3963 3067 2981 3974 3067
   3870 4024 4001 4001 3981 4020 3003 3981 3112 2927 3932 3124 3895 3993 3997
   4143 3856 4010 3036))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 1 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 246122 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4189 3942 3059 3939 3953 4055 4006 3995 3959 4038 3988 3033 3949 4012 3108
   4098 3752 4039 3984 4013 3998 3980 4026 3013 3964 4011 3032 3973 3973 4018
   3987 3982 4032 3108 4883 3089 4075 4854 4993 2996 4999 3995 3989 4003 3994
   3035 4012 2987 3024 3941 3022 3980 3991 4018 3993 3993 4008 3029 3954 3991
   3113 3889 4006 4027))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 2 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 239412 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4436 3033 3964 3939 4024 3982 5010 4005 3091 3941 3936 4015 3996 3044 3926
   4015 4024 3947 4041 4001 3095 3894 4024 3956 4015 3038 3938 3076 3940 3992
   3062 3943 3130 3888 3987 3991 3995 3089 3921 3052 3947 4001 3088 3953 3060
   3893 3996 3997 4012 3077 3916 3060 3969 3973 3066 3932 3112 3914 3964 4001
   4005 3050 3984 3023))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 3 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 230714 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4812 3945 3043 3939 4739 4279 3984 4004 4018 1785 4189 1865 4180 3958 1480
   2533 3952 4005 4006 4012 3980 3023 3997 3012 3962 3992 3027 3984 4004 4029
   3979 3987 4014 3987 3986 3067 3003 3939 4021 3982 3983 3117 2996 2996 2997
   3898 3103 2973 3920 3985 4010 3087 3018 3898 4015 3079 3018 3902 4013 3070
   3134 3770 3117 3886))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 4 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 229995 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3207 3791 3985 3158 2972 3894 3043 3957 3116 3876 4001 3980 3131 3889 3097
   3884 4163 3838 3078 3028 2978 3879 3238 3785 3966 4049 3062 3917 3995 3096
   2986 3913 3098 2991 3932 3981 3044 3948 3985 4006 3131 3890 4005 3987 3229
   3786 3983 4022 3077 3057 2931 3906 3164 2918 3935 3095 2981 3004 3899 3018
   4979 4013 4988 4026))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 0 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 116795 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4829 3973 2996 3973 3988 3067 3937 3981 4014 3992 4030 3065 3891 4033 3058
   3923 3043 3982 3974 3059 3966 3992 3001 4005 3977 3074 2937 3998 1907 4076
   3973 3077))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 1 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 119694 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4732 3924 3107 3921 3992 3101 3954 3980 3093 3939 3966 3043 3972 3983 3088
   3927 3991 3026 3981 2995 3029 3976 3976 3107 3912 3962 3085 4948 3988 4015
   3990 3981))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 2 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 121177 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4237 3966 3996 4003 4004 3963 4014 3982 4023 3994 3267 4745 2995 3047 3934
   4010 3080 4953 3978 3005 3965 4007 4011 3961 4003 3080 3948 3001 3054 3946
   3081 3912))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 3 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 128963 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5062 3958 3019 3962 3992 3060 3927 4019 4011 3984 3974 3115 3909 3973 3055
   3961 4004 3070 3954 10822 3167 3992 2989 4011 3977 3983 3992 4019 3990 4018
   4000 3980))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 4 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 126645 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4615 3972 3964 3086 3933 3992 4020 3965 4007 3988 4067 3948 3995 4012 3984
   3996 3995 3999 4012 4028 3971 4024 3073 3949 3988 3009 6031 4931 3066 3942
   3991 3082))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 0 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 74751 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4838 5039 3994 4933 5002 7053 4918 4011 4035 4944 4042 4986 4965 4023 3996
   3966))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 1 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 73175 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5190 4925 4016 4995 4972 5014 4035 4969 4994 4075 3925 4993 3102 4920 4963
   4084))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 2 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 71855 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4918 4973 4065 4916 4979 2392 4652 4975 4018 4981 4982 3026 5012 4972 4014
   4976))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 3 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 73659 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4716 4942 5016 4956 5020 4995 3199 4798 4981 3079 4966 4971 4068 4946 4977
   4024))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 4 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 72808 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4875 4974 4083 4893 4963 4118 3923 4995 4079 4926 4972 3038 4974 4016 4979
   4995))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 0 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 485203 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4281 3929 3142 2931 3938 3963 4024 3998 4000 3983 3067 3058 3857 3112 3917
   3980 3093 3921 3978 4049 3978 3061 3950 3966 3084 3930 3980 3100 3928 3981
   4015 4006 4004 3983 4008 4004 3948 4041 4016 3065 2999 2992 4015 3899 4018
   2993 4025 4013 4028 4008 3909 4013 3092 3025 3918 3991 3991 3973 4050 3961
   4004 3058 3989 3952 4001 3981 4005 3099 2979 2978 3989 3964 4179 3812 4016
   3973 3095 4951 3116 3863 3987 4060 3054 3850 4026 4023 3977 4012 4006 3962
   4018 3996 3977 4030 4010 3971 4036 3993 4004 3970 4006 3989 4047 3976 3090
   3907 3083 3878 4046 3988 4011 4003 4005 4004 3049 3902 3980 4208 3891 2992
   3976 3046 3014 3888 4143 3862 4026 3991))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 1 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 482121 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3373 2868 3898 3978 4007 4005 3994 3981 3090 2993 3937 3995 3958 4044 3228
   3943 3822 3073 3915 3982 4006 4006 3088 3939 3989 3038 3975 3048 3955 3978
   3089 3937 3990 4079 3941 3976 3976 3995 3154 2942 3902 4014 3998 4018 3979
   4020 3135 3954 3913 4036 3977 3986 4012 4016 3096 3018 3872 3009 4003 3962
   3113 3886 3987 3076 4003 3923 4006 3990 4022 4020 3085 3923 3984 3979 4063
   3933 4026 3101 3902 3989 3080 3897 3998 3069 3930 3098 3918 3975 4043 3976
   3994 3983 3128 2982 3966 4093 3896 3966 3078 3876 4036 3057 3952 3986 4038
   3940 4057 3021 3039 3914 4005 3982 4048 3952 4046 3008 3947 4002 4015 3997
   4002 3977 4020 3968 4026 3971 3996 4016))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 2 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 501884 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3979 3906 4027 3980 4012 5020 3992 3985 3979 3994 4037 3956 4029 4000 4022
   4028 3976 3996 3964 3073 3930 4003 4088 3943 3979 3959 4050 3956 4018 4025
   3981 4000 4020 3962 4029 3962 4002 4035 3993 4000 4032 3945 4007 3998 4004
   3973 4082 3026 3924 3993 4010 3035 3961 4015 3996 3982 4003 3968 4062 3964
   3996 4023 4002 3999 4001 3965 4023 3981 4026 3976 4023 4002 4003 3977 3084
   3883 4014 3095 3917 4002 3089 2969 3958 3964 4004 4014 4059 3938 4022 3993
   3980 4013 4005 3968 4066 3979 3969 4007 4013 3951 4047 3984 3066 3930 4034
   3953 3129 3868 3107 3961 3978 3056 3959 3950 3986 3999 4018 3992 4015 3990
   4016 3997 3980 3967 4033 4005 4042 3949))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 3 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 498347 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4425 3936 4010 3945 4006 4060 3054 3909 3999 4019 3020 3084 3864 3982 3111
   3084 3851 4002 4003 3967 4032 4015 3969 4013 3148 3806 4046 3977 3056 3949
   4039 3949 3124 3901 3973 4026 4010 3990 3117 3884 4028 3053 3910 3990 4016
   3993 4023 3980 3068 3896 4043 3976 3067 3969 3976 3985 3070 3936 4198 3797
   3068 4969 3984 3975 3080 3922 3055 3939 4007 3999 3083 3929 4015 3985 3978
   3067 3977 3972 4038 3966 4016 3959 3052 3942 3996 4040 4021 3958 4032 3949
   4001 4008 3987 4018 4034 3984 4007 3982 4028 3938 3104 3921 3064 3932 4006
   3116 3898 3956 4007 4032 4146 3829 4025 3962 4025 3993 3976 4008 4078 3950
   4021 3977 3996 3972 4001 4020 10800 4187))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 4 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 513631 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4693 3935 4002 4004 3984 4013 3978 4015 3958 4031 4031 3938 4033 4004 4016
   3998 3988 3985 4107 3927 3964 3976 4043 4002 4001 3986 3953 4049 4016 3999
   4077 3900 4031 3980 4011 3956 4034 3999 4000 4016 4009 3973 4006 3973 3986
   4028 4001 4021 3987 3982 4035 3954 4003 4024 4000 3989 3983 4018 3994 3985
   3994 4032 4000 4010 4002 3979 3987 3976 4017 4009 4035 3971 4016 3988 3984
   4021 3979 4033 3989 4010 3971 4014 4033 3910 4027 4024 4012 3969 4033 3978
   4038 4000 3926 4045 3995 3997 3996 3996 4001 3990 3987 4010 4023 3970 4041
   3954 4034 3962 4024 3992 4039 3986 3984 3990 3983 3996 3997 5030 4008 3998
   4001 3967 4033 3959 4017 3991 4008 4004))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 0 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 235851 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4792 3000 3924 4000 3980 3075 3970 3962 4013 3048 3936 4005 3984 3080 3901
   4025 3996 3994 4022 3175 2912 3907 3978 3130 3892 3072 3931 3068 3912 4003
   4018 4000 4083 3912 3947 3180 3893 3002 3958 3117 3002 3903 3043 3985 3026
   3889 4140 3975 3986 3072 3902 4008 4023 3046 3951 3985 3998 3058 3943 3093
   2991 3889 3997 3135))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 1 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 235999 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4200 3737 4062 3014 3028 3907 3971 3098 3020 3892 4010 3081 2978 3923 4014
   3084 2995 3916 3111 3906 4017 4051 3025 3933 3981 3989 3045 3944 4014 4027
   3053 3906 4029 3987 3099 3967 3947 4056 3982 3998 4168 3951 3911 3085 3873
   3961 4034 4011 3999 3046 3078 3851 4026 3111 2939 3948 3977 3052 3028 3966
   3978 3963 4069 3954))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 2 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 245836 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4876 3901 3999 4015 3992 3986 3975 4047 3967 4006 4011 3973 4010 4010 3980
   3999 4010 4015 4000 4019 4056 3936 3067 3938 3096 2911 3947 4062 3963 5031
   2999 3069 3907 3962 3106 3931 4015 3986 4059 3974 3066 3929 3989 3126 3891
   3978 3983 4036 3988 3067 3935 4020 3997 3040 3020 3935 3995 3987 4031 3990
   3985 3087 3888 4040))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 3 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 238240 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4232 3105 3827 4024 3987 3074 3912 4039 3997 3045 3929 4020 3980 3051 3966
   3952 4039 3982 3138 3883 3064 3907 3080 3976 3042 3919 3067 3935 3058 3955
   3075 3936 3038 3914 3085 3953 3174 2877 3949 3001 4000 3993 3972 4029 3956
   4005 4029 4016 4031 3969 3071 3033 3900 3984 4075 3995 3965 3945 4023 4045
   3991 3962 4007 4039))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 4 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 255478 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4506 3949 3955 4018 3994 3985 4029 3989 4112 3921 3993 3962 4012 4003 3964
   4037 3967 4021 3964 4061 4048 3961 3973 4019 4018 3999 3976 4020 3983 3995
   4045 4059 3935 3979 6017 4023 4003 3992 3111 3886 3055 3020 3890 4045 3949
   4023 3965 4020 4022 3956 4229 3784 4011 3966 4021 4018 3966 4009 3999 4025
   3996 3972 3983 4037))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 0 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 121726 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4793 3979 3951 4019 3969 4091 3930 3983 3991 3104 3937 3035 3925 3088 3910
   3087 3911 3060 3935 3074 3941 3969 4030 3981 4019 3981 4007 4014 3996 4009
   3078 3922))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 1 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 119049 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4127 3965 3021 3951 3979 3986 3125 3908 3964 3986 4013 4010 3073 3937 3992
   4002 3080 3950 3979 4028 3974 3173 3783 3115 3938 3039 3958 3085 3909 3090
   3913 3985))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 2 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 124078 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4974 3912 4042 4002 3968 4011 4027 3987 3982 4031 4076 3943 3966 4022 3057
   3004 2978 3939 4018 3996 3985 4053 3997 4088 3967 3045 3986 3977 3933 4040
   3989 3070))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 3 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 117297 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4239 3967 3017 3963 3984 3972 4032 4001 3038 3941 3072 3921 4008 4022 3100
   3911 4053 3929 3143 2974 3057 2980 3818 4032 4017 3063 4074 3879 3971 3155
   3024 3933))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 4 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 121329 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4308 3961 3020 3970 3972 3995 3978 3990 4042 3994 3085 3913 3978 4017 3160
   3840 3987 3991 3068 3952 3057 3948 3998 3999 3064 3904 4019 4033 3054 3959
   3961 4106))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 0 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 67679 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4651 3939 3982 4017 3062 3929 3034 3992 3041 3024 3930 10694 4327 5115 3880
   3058))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 1 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 60974 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4936 3958 3971 3077 3911 4027 4000 3974 4019 4003 3049 3937 3079 3938 4027
   3061))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 2 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 59398 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4467 2994 3971 3047 3933 3979 3074 3011 3905 4013 3999 3106 3890 4031 3994
   3982))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 3 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 59397 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3569 4814 3973 3096 3918 3992 4020 3989 3982 3079 3943 3057 3039 3906 3342
   3673))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 4 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 59725 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3933 2968 3824 3999 3098 3014 3903 3984 3987 4029 4015 3976 3995 4005 3083
   3902))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 0 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 487808 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4873 3925 3103 3885 3112 3190 4694 4017 3993 4005 3986 3994 4026 6070 3061
   2992 3005 3866 4058 3039 4905 4963 3119 3934 3967 4004 4021 3986 3075 3037
   3902 3122 3859 4005 4015 3966 3995 4042 4003 3986 3093 2969 3913 3067 3927
   4015 4015 3985 4025 3971 4105 3893 3126 2987 3913 3998 3980 4186 2914 2979
   3929 4005 3984 3993 4021 3119 3864 3975 4000 4039 3091 2979 3930 3961 4020
   3968 4052 3123 3877 3974 3995 4005 3062 2992 4144 3799 4009 4009 3987 3094
   3884 3991 4012 4050 3086 2958 3924 4017 3973 3994 3991 5032 3967 4002 4025
   3985 3076 3000 3921 3995 4151 3869 4005 3060 3910 3971 4012 4079 3076 3870
   4035 3950 4019 3959 4004 4042 4003 3985))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 1 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 474180 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3256 3859 3094 3880 3999 4026 4011 4001 3974 4024 4081 3921 3095 3879 3091
   3894 3993 4003 4025 3974 3981 4029 4027 4017 3090 3882 3091 4042 3861 4043
   3991 3975 3996 3988 4011 3055 3020 3908 3096 3917 4010 3969 4016 3970 4016
   4013 4019 3992 3154 3861 3984 3997 4040 4057 3000 2989 3890 4008 4017 3971
   3118 3002 3918 3976 4023 3965 3068 3007 3903 4050 3981 3987 3163 2922 3934
   3977 4007 3998 3084 3012 3942 3970 3992 3976 4013 3116 3906 3999 3100 3918
   3073 2982 3893 4053 3096 3880 4018 3949 3110 3938 3093 3900 3998 3081 3919
   3959 4101 3925 4011 3140 2930 3983 4033 3941 3201 3749 3991 4047 4001 3950
   3134 3852 3100 3030 2955 3061 2962 2981))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 2 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 490480 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3818 2774 2985 3030 2934 3943 3069 3925 3099 2997 2967 3045 3060 2921 3015
   2911 3057 2996 2997 3926 3982 4017 4013 3962 4000 4040 4012 3961 4020 5126
   3881 3990 4000 3983 4024 3982 4005 4013 3998 4015 3996 3997 3990 3985 3984
   4116 3981 3933 4001 3994 3097 3862 3099 3938 3166 3827 3999 4010 3996 3969
   4031 4038 3963 3995 4045 3933 4013 3980 4043 3979 3988 4034 3987 3980 3998
   3070 3937 3995 4026 3977 4228 3810 4442 3512 4010 4001 4039 3975 3964 4008
   4002 3974 4016 4007 4010 4001 4009 3976 4000 3984 4019 4029 3966 3998 4021
   4090 3898 3066 3914 4063 3154 3814 3951 4033 4019 3961 4004 4025 4040 3950
   4034 4028 3934 3986 4012 4006 4030 3970))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 3 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 505279 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4338 3982 3942 3984 4040 4006 3995 4014 4079 3899 4008 3989 3991 3143 3038
   3806 4060 3070 3893 3981 4012 4003 4038 3966 4016 3986 4003 3962 4041 3990
   4015 3984 3997 4027 3065 3888 4006 4005 4012 3994 4011 3991 4015 3965 3996
   4026 4018 4003 3987 3984 4007 3965 4041 4016 3987 3986 3997 3989 4013 3967
   4010 4036 3985 3985 4034 3944 3296 3760 3973 3085 3943 3977 4157 3891 3951
   3968 4049 3990 3989 4023 3993 3973 4044 3957 4010 5012 3996 4004 3991 3969
   4031 3963 4003 4066 3968 3979 4043 3959 4011 3989 3992 3134 3899 3972 4012
   3993 4016 3968 4026 3981 4020 4007 4002 4021 3975 3952 4008 4050 3997 3974
   4026 3062 3904 3990 3996 4008 4004 3991))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 4 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 515202 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4263 3955 3993 3964 4015 4046 3983 3995 4066 3956 3984 3962 3984 4055 3986
   3989 4045 3983 3975 3980 3993 4029 4002 3989 4036 3117 3869 3970 4033 4003
   3976 4019 4058 3996 3952 3950 4014 4008 4016 3977 4036 3986 3989 3989 3997
   4026 4011 3973 4004 3995 3998 3966 4037 3984 4010 4001 4049 3040 3899 3979
   4026 4010 3995 3994 4010 4010 3963 3993 3996 4001 4034 10782 4237 3953 4040
   3961 3999 3067 3969 3963 4014 4008 3978 3981 4021 4044 3966 3147 3857 3964
   4025 3973 4005 4002 4031 3994 4024 3945 4033 3958 4013 4027 4125 3886 4006
   3989 3990 4018 3963 4001 4044 3963 4038 3954 3999 3985 4001 4009 4023 3997
   4008 3957 4037 3961 4003 4055 3972 3984))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 0 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 246756 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4765 3979 3943 3996 4025 3129 3028 3846 3972 3328 4670 4000 3166 3838 3146
   2933 3931 3954 4007 4052 3953 3120 3891 3992 3141 3881 3091 3902 3993 4017
   4002 4008 3975 4008 4017 4004 3981 3994 3119 3900 3993 4087 3914 4000 3999
   3964 4035 3996 3983 4068 3077 3916 3938 4027 3082 3969 3975 3978 4033 4041
   3962 4224 4747 4038))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 1 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 239297 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4196 3055 3903 4007 3051 3899 4012 4034 3973 4077 3904 4020 4002 3060 3885
   4048 3150 3893 3950 4012 4010 3945 4027 4074 3978 3094 3898 3078 3027 3877
   3068 3961 3989 3995 3987 4033 4009 3156 4812 3072 3064 3870 3076 3949 3983
   3977 4007 4026 4003 3064 3910 3064 3045 3853 3066 3983 3964 4031 3971 4029
   3993 3070 3927 3124))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 2 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 245399 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3645 4770 3050 3905 3973 4027 4009 3975 4038 3059 4004 3003 3052 3865 3066
   3929 3990 4023 3977 4025 3967 3116 3917 3153 2994 4873 3111 3899 3973 4011
   3042 3974 3987 4021 3968 3153 4854 3997 3103 3899 4000 3999 3982 4035 3990
   3950 4035 4030 3087 3945 3150 4791 4014 5017 3947 4077 3057 3845 4024 4035
   3992 3970 3990 4018))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 3 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 237623 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4616 3971 4017 3988 4008 3357 4649 3990 3998 4109 3900 3999 3059 3928 3998
   3060 3934 3140 2955 3028 3879 4006 4013 4037 3089 2994 3898 3084 3906 4051
   3957 4020 4000 3961 3990 4061 3993 3086 3897 3111 3864 3061 3048 3055 3857
   3074 3894 3118 3910 3126 3859 3141 3864 3983 4042 3082 3892 3082 3886 4064
   4008 3930 4018 4009))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 4 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 255825 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4849 3964 4003 3991 3962 4016 3197 3809 4020 4032 3940 3971 4039 3988 4031
   3982 3953 4040 4005 4001 4044 3983 3961 4059 4006 3994 3964 4025 3969 4005
   4013 4028 3966 3967 4022 4034 3977 3969 4025 4023 3967 4022 4012 3996 3997
   3998 3952 4069 3978 3972 4019 3999 3989 4005 4003 4017 3986 3990 3972 4088
   3957 3989 3998 3995))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 0 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 119950 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5039 4930 3999 3010 3042 3021 3907 4033 4025 3968 1908 3143 3950 3963 3095
   3941 3980 3001 4019 3985 4000 4025 3953 3064 3956 4013 1933 4215 3813 5057
   3960 3997))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 1 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 121029 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4172 4811 3994 2984 3987 4025 3997 4002 3978 4001 3985 4033 3001 3062 3926
   4178 4827 3961 4034 3066 3941 4018 3022 3931 3067 1983 3994 4019 3970 4109
   3905 3040))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 2 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 119780 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4873 3959 2014 3942 3260 3781 3953 3985 4020 3978 4024 3053 3914 4027 3028
   3981 2974 3087 3943 4109 3918 4004 3971 2974 4021 4027 3005 3987 3969 4022
   3997 3968))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 3 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 129409 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4298 4952 3991 3998 3969 4068 4943 4018 3979 4037 4089 3854 3114 1734 4217
   3954 4007 4230 3779 3000 3989 4026 3087 3006 4020 4013 5003 4972 4971 5072
   4910 4097))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 4 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 124555 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3475 5031 3022 3971 3047 2957 3950 3002 4013 3998 4009 3156 3842 4019 2996
   4003 3955 3080 3952 4002 4017 3988 3969 3008 4041 3165 3917 5007 4952 5209
   4803 4991))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 0 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 73873 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(2814 5051 4055 3991 4978 4089 4892 5007 4951 5067 4960 4068 4926 4996 5006
   5016))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 1 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 75698 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5094 4630 4961 4996 4030 4964 4082 4931 4982 4026 4993 4989 5012 4995 5015
   3995))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 2 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 77108 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4239 4908 4000 4926 5003 4984 4976 5032 4992 5020 4985 4051 4958 5014 4970
   5046))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 3 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 75389 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5420 4947 4948 5012 4045 4955 4022 4980 4987 4077 4918 4988 5026 4966 4052
   4038))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 1 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 4 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 73879 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4102 3811 4048 4941 4967 4056 4956 4984 5017 5000 5013 4032 4943 5051 4945
   4004))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 0 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 59517 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4617 3896 4013 3974 3124 3028 2953 3884 3308 3724 3954 3106 3916 3992 4014
   4007))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 1 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 59754 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4771 3954 3973 4007 3990 4019 3992 4010 4002 3042 3016 3922 3058 3152 3760
   3082))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 2 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 62044 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4107 3982 3968 3082 3923 4005 3967 4035 3973 4011 4018 3968 4038 3996 3048
   3918))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 3 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 60763 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4021 3770 3901 3989 3979 4023 4004 3979 4021 3997 3062 3954 3981 3034 3962
   3083))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 4 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 62676 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4733 3965 4018 3030 3941 4014 3972 4020 4002 3991 3996 3997 4013 3982 3080
   3917))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 0 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 123864 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4972 3931 4008 3972 4004 4027 3972 3998 3991 3105 3895 4011 4008 3052 3976
   3907 4040 3051 3948 4000 3990 4005 3983 3107 3920 3977 4020 3038 3950 5030
   3035 3928))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 1 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 121868 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4069 3769 3154 3848 3075 3942 3049 3925 3063 3952 3969 4017 3999 3978 4023
   4004 3995 4021 3957 4019 3991 4011 4006 3054 3953 3975 4010 3077 3917 4012
   4005 4026))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 2 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 121142 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5165 3033 3919 3985 4014 3047 3960 4002 3975 3998 3077 3927 3073 3947 3061
   3890 3102 3905 3153 3902 3931 4011 4015 4009 3975 4024 3970 4024 3972 3999
   4014 3052))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 3 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 118699 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4810 3942 3972 3086 3915 4001 4006 3068 3923 3110 3896 3985 3991 3100 3912
   4021 3991 4001 3992 3998 3099 2961 3023 3930 3046 3935 4008 3294 2778 3898
   4013 3985))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 4 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 122189 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4260 3988 3054 3925 3978 4003 3989 3991 4024 4003 3076 3927 3055 3925 3089
   3927 3094 3917 3091 3826 4040 4013 4003 4014 3960 4019 4054 3938 4005 4016
   3980 3992))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 0 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 238282 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3545 2852 3929 4023 3935 3125 3923 3979 3123 3037 3842 4039 3034 3017 3892
   4010 3042 3944 4021 3962 4006 4055 3964 3989 3999 3995 4006 3992 3984 4023
   4010 3978 3983 4033 4016 3977 3999 4050 3031 2978 3992 3994 3010 2976 3960
   3991 3103 3911 4002 4006 3072 3917 3073 3058 3871 3998 3070 3089 3895 3955
   3989 4013 3986 3982))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 1 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 244476 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4556 3955 3983 4006 3996 3967 4022 4003 4047 3954 3990 3958 4010 4047 3965
   4006 4012 3982 3073 3061 3875 3987 3070 3017 3894 4011 3074 2989 3946 3992
   3128 2942 3917 4002 3089 2988 3924 4036 3969 3973 4046 3967 4012 4112 3891
   3997 4001 3996 4004 3997 3992 3997 4012 3998 3993 3999 4003 4030 3967 3990
   3082 3007 3906 4028))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 2 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 236755 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3962 2931 3903 4003 3054 2994 3923 4012 3047 3064 3879 3978 3098 3098 3826
   3069 3004 3910 4023 3060 3913 4020 4002 3090 3894 4007 4015 3068 3921 4001
   4010 3056 3938 4001 3998 3094 3892 3957 4036 3969 4015 4022 3988 3085 3901
   3995 4015 3988 4016 3975 4005 4003 4001 4034 3961 3065 3921 3108 2967 3941
   3995 4003 3119 3884))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 3 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 232228 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4295 3088 2986 3894 3979 4022 3045 3947 4193 3824 3056 3921 3993 4005 3083
   3924 3974 3099 3966 3944 3079 3904 4014 3978 3108 3008 3916 3980 3194 4828
   3997 3971 3119 3033 3850 4141 2919 3079 3859 4027 3966 4021 3978 4018 3048
   3002 2998 3932 3055 3045 2959 3944 4016 3117 2912 3951 3993 4002 3089 3915
   3094 3909 3050 3952))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 4 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 226039 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3276 3780 3115 3902 3018 3992 3031 3929 3099 3905 3076 3957 3036 3938 3053
   3966 3054 3954 3050 3946 3044 3955 3020 3990 3006 3958 3067 3947 3009 3995
   3060 3919 3070 3943 3140 3852 2992 4031 3046 3923 3047 3934 4022 3977 3082
   3948 3970 3992 3062 3944 3079 3923 3067 3929 3067 3935 3049 3963 3028 3958
   3046 3963 3050 3943))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 0 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 481432 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4432 3020 2996 3044 2980 3905 3982 3988 3996 3121 2968 3078 3843 3998 4050
   3960 3981 3062 3932 4015 4019 3996 3968 3080 3061 2920 3935 4001 4011 3977
   4023 4001 3977 3104 3903 3989 3097 4053 3856 3091 2985 3932 3987 4045 3990
   3971 4000 3144 9673 3313 3855 3989 4029 3994 3995 3071 3942 3986 4011 3985
   4000 4014 3232 2820 3968 3011 3960 3993 4005 5018 3992 3043 3931 4003 4005
   4022 3978 3049 3932 4033 3047 3962 3968 4015 4025 3143 3830 3159 3819 3162
   3857 4000 3034 3091 3874 3995 3068 3944 3044 3948 4022 3962 4026 3058 3118
   3783 3171 3844 3103 3892 4007 3995 4003 3996 4007 4008 4010 3964 4023 3981
   4002 4009 3995 3126 2972 3913 3998 3082))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 1 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 478436 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4523 3962 3999 3997 3046 3952 3966 4035 3980 4018 3066 3924 4018 3986 3035
   3957 3078 3917 3074 3941 3973 3100 3952 3960 4008 4016 3984 3043 3956 3081
   3923 3993 3991 4011 4027 3928 3079 3948 3958 4046 3999 3060 2999 3919 3085
   3913 3990 4003 3068 3925 4017 3065 3937 3993 4010 3063 3954 3962 3994 4001
   4019 3999 3990 4005 3992 3064 3945 4003 4005 3967 3111 3917 3064 3005 2997
   3911 4034 3981 3976 4023 3043 3938 4003 4018 3965 3098 3025 3906 3075 3915
   3994 3999 3995 4018 3079 3034 2923 3965 3087 2959 3935 4018 3072 3924 4022
   3036 3009 3932 3983 4004 4011 3994 4020 3040 3936 4019 4006 3976 3996 4006
   4008 3059 3952 3989 3055 4969 3970 3989))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 2 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 448148 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3252 2969 3876 4038 3032 3028 3919 4033 3026 3007 3934 4006 3038 2993 3965
   3963 3108 2984 3942 4008 3060 3925 4008 4003 3022 3045 2990 3930 3051 3023
   2961 3975 3079 2971 3008 3920 3156 2930 3013 3904 3037 3107 2919 3912 3071
   3003 3033 3911 3098 3907 3055 3942 3971 4005 3066 3928 3085 3918 4025 3991
   3011 3984 3992 3985 3098 3918 4021 3960 3108 3911 3981 4008 3092 3892 4031
   3971 3061 3954 3995 4008 3058 3910 4049 3969 3057 3960 4003 3037 3036 3885
   4026 3058 3036 3893 3992 3073 2994 3949 4000 3044 3034 3931 3978 3055 3008
   3928 4010 3066 3025 3909 4002 3062 3006 3934 4005 3044 2997 3093 3858 3055
   3021 2989 3937 3048 3024 2973 3946 3062))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 3 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 439954 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3125 2950 3868 3075 2966 3017 3945 3057 2979 3043 3899 3104 3912 3034 3952
   4013 3987 3088 3898 3073 3965 3034 3981 2991 3982 3055 3938 3076 3916 3089
   3924 3049 3948 3053 3945 3080 3940 3036 3919 3064 3976 3030 3938 3991 4002
   3035 3959 4009 3976 3067 3001 3008 3922 3184 2890 3000 3923 3087 2990 3009
   3970 3006 3027 2976 3942 3077 2976 3008 3932 3021 3051 3078 3858 3085 3927
   3022 3963 3988 4001 3076 3965 3030 3933 3994 3055 3013 3932 3072 2991 2994
   3926 3085 2998 3005 3926 3027 3023 3019 3940 3048 3016 2984 3963 3065 3916
   3055 3956 3992 3994 3057 3943 3136 3842 3101 3882 3097 3934 3041 3968 3070
   3939 3032 3965 3015 3982 3027 3975 3033))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 4 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 451056 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4098 3008 3917 3048 3935 3066 3932 3070 3950 3045 3953 3078 3944 2998 3980
   3059 3934 3051 3967 3055 3933 3032 3932 3253 3830 2970 3989 3122 3875 3054
   3947 3014 4004 3068 3879 3075 3945 3018 3978 3024 3973 2975 4015 3047 3936
   3081 3908 3076 3956 3021 3978 3068 3960 3691 6284 3019 3950 3071 3929 3085
   3900 3085 3946 3017 3979 3055 3941 3052 3941 3051 3950 3034 3994 3034 3946
   3026 3962 3056 3935 3066 3948 3038 3953 3081 3917 3057 3949 3015 3980 3062
   3919 3062 3970 3048 3942 3048 3953 3057 3945 3054 3940 3063 3955 3034 3943
   3054 3941 3053 3971 3032 3961 3029 4024 3004 3976 3031 3963 3028 3940 3094
   3887 3105 3907 3041 3940 3033 3967 3071))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 0 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 73943 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4092 4876 4007 4975 5032 4226 4742 4988 4061 4925 5051 4032 4913 4034 4970
   5015))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 1 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 73615 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4628 4960 4983 5009 4986 4026 4057 4910 5009 4070 4924 4998 4053 3943 5021
   4031))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 2 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 72034 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5121 4954 4073 4910 4994 4081 4932 5007 2197 3853 4944 3005 4987 5020 4938
   5013))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 3 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 78523 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4573 4918 5000 3981 5011 4976 3031 5006 5002 4050 4934 10782 3289 4932 4992
   4041))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 4 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 72141 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5179 4941 4137 4877 5001 4086 4889 4017 3227 3782 4962 3131 4901 4994 5034
   4978))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 0 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 118424 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4479 3956 3062 3967 3981 3036 3957 3990 3046 3967 2979 3041 3983 3981 3070
   3929 3979 3039 3950 4047 3055 3920 4001 3074 3932 4002 3016 4013 3963 3987
   4033 3985))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 1 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 119974 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4991 3951 4021 4001 4016 2967 4038 3995 4162 3812 4013 4010 3042 3016 3929
   4006 3985 4007 2983 4027 4082 3903 3044 3961 3034 2984 4040 2921 4006 3988
   3065 3962))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 2 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 123746 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4825 3937 2993 3994 3077 2967 3957 3022 4003 3924 5070 4942 4000 3096 3942
   3975 4038 3013 3987 2979 4000 3988 3997 4027 3981 3996 4020 3954 4044 3972
   3993 4024))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 3 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 119230 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3438 4821 4004 2993 3979 4016 4000 3984 4006 3976 3995 4036 3012 3020 3980
   1910 4060 3979 3994 4006 4008 4004 3058 3963 2965 3076 3930 3107 3906 3980
   4020 3995))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 4 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 120682 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4752 3938 3070 3960 3028 2966 3985 3044 3943 4010 4013 3993 4011 3982 3045
   3954 4028 3046 3901 3998 4004 4001 2978 4022 4028 3953 3089 3933 3999 3991
   4995 3009))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 0 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 242677 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3950 4778 3104 3003 3882 3105 3889 3998 4016 3982 4018 3965 3123 3910 3089
   2991 3944 3052 3891 3999 4025 3989 4013 3976 3134 3864 3114 3929 3990 3064
   3913 4015 3982 4022 3969 4000 4027 3992 3081 3908 4007 3143 3860 4028 3955
   3964 4045 3994 3992 4000 3079 3930 3996 3087 3890 4016 4004 3993 3988 3131
   4875 3980 4027 3981))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 1 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 240134 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4180 4007 3965 3984 3116 3901 4014 3103 3891 3977 4039 3986 4009 3942 4022
   3992 3176 3812 4027 3113 3848 4025 3994 3993 4009 3987 4007 3998 3117 3879
   3037 3084 3929 2990 3960 4010 3978 4015 3996 3998 3117 3876 3078 3049 3880
   3053 3953 4004 3965 4026 4002 3987 3135 3889 3057 3048 3876 3032 3957 4023
   3992 3985 4006 4009))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 2 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 241732 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3958 4817 3086 2991 3889 3105 3908 3990 4044 4174 3804 3980 3085 3895 3079
   3027 3900 3106 3886 3966 4024 4020 3988 3980 3114 3899 3109 3884 4045 3045
   3916 4004 3985 3991 4007 3989 4044 3969 3096 3914 4008 3085 3895 4010 3975
   4027 3998 3988 4039 3982 3102 3881 4007 3119 3866 4002 3995 4009 3994 3118
   3900 3985 4124 3881))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 3 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 239854 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4969 3927 3998 4008 4013 4007 3974 4003 4013 3970 3999 3988 3984 4022 3992
   4034 3027 3939 3992 3084 3917 3985 4011 3995 4046 3943 4008 4015 3107 3899
   3079 3019 4893 3101 3879 4006 3998 4006 3999 4009 3079 3006 3914 3989 3141
   3852 3999 4010 3088 2994 3001 3897 5024 3057 3916 3101 3003 3000 3028 3885
   3994 3096 3011 3881))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 4 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 217637 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3043 2709 3001 3900 3030 3080 2988 3906 3063 3017 3016 2975 3009 3883 3138
   2970 3089 3842 3110 2996 3909 3037 3958 3067 3935 3970 3986 3100 3892 3076
   3237 3689 4020 3092 3905 3077 3893 3103 3004 3895 4030 3059 3906 3129 3863
   3097 3028 2978 3914 3100 2987 3911 3124 2948 3045 3884 3085 3898 3109 4068
   3866 3963 3052 3961))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 0 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 497511 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4603 3932 3992 3975 3088 3017 3915 3081 3937 3976 3990 4023 4000 4002 3998
   3964 3116 3019 3879 3111 3916 3991 4016 3978 3990 3983 4023 3998 3103 2990
   3898 3117 3899 3984 3138 3868 4010 4002 3991 3969 3181 2944 3894 3055 3933
   3983 3102 3910 3983 4034 3997 3973 3059 3042 3902 3995 3997 4015 4026 3978
   4005 3985 4004 4010 3985 3119 3875 4002 4000 4023 3998 3992 4027 4010 3998
   2088 3890 3981 3095 3893 4016 3954 4028 4018 3994 3989 3992 3994 4000 4002
   4008 3997 4024 3981 3998 3982 4020 4000 3990 4007 4017 3966 4006 4006 3993
   4009 3988 3993 4005 4006 4003 4008 3980 3990 4001 4015 4006 3985 4004 9786
   4273 3952 3073 3919 4109 3893 4013 4003))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 1 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 471472 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3723 3793 3988 3086 3920 4011 3082 3885 4010 3132 3877 3996 3112 3846 3989
   3113 3919 3997 3994 3997 4001 3966 4017 4005 3106 3905 4000 3983 3998 4002
   3997 4009 4036 3079 3877 4010 3069 3923 4016 3093 3880 4006 3150 3866 3995
   3106 3887 4001 3106 3880 4018 3084 3933 3974 3088 3904 4027 3117 3888 3966
   3117 3893 4024 3073 3904 4001 3112 3861 4042 3238 3743 3994 3131 3868 4021
   3057 3929 3085 3002 3922 4009 3076 3897 3988 3116 3886 4012 3074 3881 4008
   3122 3891 4053 3069 3880 4005 3079 3917 4023 3073 3905 3131 3013 2995 3876
   3078 3911 4007 3081 3909 3998 3089 3932 3993 3975 3992 4026 3972 4004 4026
   3055 3927 3094 3901 3287 3743 3051 3928))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 2 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 432876 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3106 3843 3058 3921 3062 3921 3995 3993 3089 3015 3908 3942 3140 2957 3928
   3994 3085 3139 3788 3964 3250 2818 3936 3109 3016 2957 3006 3930 3045 3031
   2994 3937 3033 3032 2969 3948 3088 3912 3073 3917 3976 3115 3004 3905 3104
   2966 2994 3951 3058 3008 2978 3941 3100 2992 3913 4001 3082 3935 3976 4009
   3058 3031 3900 3992 3108 2972 3914 4007 3107 2997 3896 4003 4001 3083 3910
   4008 3145 2936 3906 3146 2931 3025 3902 3057 3030 2973 3934 3057 3011 3937
   3990 3063 3945 3114 3876 3103 2988 2981 3950 3081 2969 3000 3934 3079 3022
   3147 3741 4016 3067 2991 3947 3080 2987 2997 2999 2970 3038 2993 2980 3171
   2831 3001 3025 2985 3944 3068 2987 3917))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 3 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 438257 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4287 3031 3002 3897 3052 3022 3026 2994 2953 3026 3010 3008 3003 3879 4014
   3078 3067 3831 3062 3014 2977 3000 3011 3008 2967 3051 2999 2982 3011 2982
   3006 3218 2775 3027 3900 3095 3026 2963 2964 3038 2980 2992 3018 3463 2527
   3012 2996 2976 3936 3066 2998 3949 3983 3092 2996 3906 4047 3053 2984 3912
   4018 3067 3050 3879 3996 3068 3950 3967 4014 4005 3078 3899 4014 3996 3070
   3928 4060 3942 3065 3928 4001 4006 3079 3927 3992 4006 3998 3108 3890 4015
   3085 2991 3884 4016 3088 3031 3921 3972 3998 3080 3887 4039 3981 3122 3896
   3104 3871 3074 3926 3081 3914 3134 3884 3070 3908 3061 3991 3032 3925 3087
   3892 4003 3095 2990 3915 4018 3047 3012))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :LEGACY :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 4 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 442618 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4682 3953 3104 2996 3901 4006 3148 2901 3977 4018 2987 3967 3059 3926 3054
   3953 3077 3898 3094 3878 3162 3863 3079 3925 3082 3941 3056 3917 4030 3036
   3017 3894 3100 2999 2989 3940 3063 3001 3919 4007 3056 3017 3925 4005 3071
   3010 3932 3992 3090 2935 3946 4019 3054 3011 3919 4003 3074 3015 3904 4023
   3992 3064 3920 3993 3075 3011 4121 3808 3088 2953 3925 4020 3079 2960 3970
   3990 3094 3911 4000 3994 3093 3918 3990 4005 3119 2953 2982 3954 3119 2958
   2987 3897 3065 3036 2988 3943 3084 3014 3899 4005 3053 3024 2982 2987 3017
   3005 2982 2987 3076 2967 2975 3074 3868 3067 3036 3875 4007 3111 2944 3957
   4000 3063 3010 3921 3985 3305 2776 3927))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 0 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 59206 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4308 3928 4002 3991 3099 2992 2964 3021 3006 3915 3987 4012 4011 3993 3996
   3976))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 1 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 61330 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4399 3930 4038 3973 4005 3990 3970 4026 4016 3055 3017 3893 3079 3915 4016
   4005))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 2 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 58705 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4777 3941 4012 3076 3897 4008 3088 3929 3983 3993 3067 3030 3085 2910 3904
   4001))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 3 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 62721 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4684 3978 3993 3984 3973 4047 3994 3990 4011 3958 4024 3998 4017 3977 3078
   3008))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 4 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 60753 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3963 2924 3004 2951 3936 3963 4002 4031 3967 4012 3980 4034 3977 4013 3969
   4022))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 0 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 123225 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4151 4007 3985 3958 3995 4031 3978 4012 4007 3090 3888 4020 4002 3076 3899
   4012 4029 3017 3906 4000 4075 3932 4032 3984 3978 4023 4027 3967 4045 3958
   3071 3058))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 1 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 125203 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3471 3740 3112 2962 9902 4031 3104 2919 3047 3951 3982 4006 3978 4195 3807
   4019 3981 4011 4011 3999 3107 3887 3996 3986 4016 3124 3873 3999 3992 3093
   3917 3982))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 2 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 124680 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4740 4187 3756 4005 4017 3974 4011 3991 4002 3049 3959 3988 5010 3984 3991
   4006 4072 3901 4030 3992 3989 3072 3950 3997 4021 3040 3886 4042 3980 3089
   3011 3926))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 3 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 121417 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3623 2845 3067 3865 3085 3012 2997 3917 3075 3933 4001 3982 4024 3966 4020
   4144 3851 3969 4030 3979 4034 3983 4007 4009 3979 4017 3988 3987 4035 3980
   4061 3944))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 4 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 117370 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4429 3941 3989 4011 3997 3966 4035 3988 3992 3081 3013 2996 2978 2997 3009
   3075 2923 2968 3019 3011 3933 3993 4020 3995 3976 4025 3959 4014 3975 4011
   4161 3880))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 0 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 238554 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4584 3044 3833 4053 3122 3858 4022 3998 3065 2973 3959 3985 3091 3925 3983
   3997 3091 3963 3044 3031 3871 3998 3997 3106 3968 3930 4025 3043 3956 3987
   4018 4030 3965 3996 3996 3978 3960 4030 4005 4014 3999 3046 3945 3971 4016
   3133 3863 4012 3988 3074 3944 3973 4025 3073 3911 4012 4002 3060 3923 3060
   3015 3905 4029 3064))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 1 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 241290 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3542 3816 3977 3075 3024 3887 3961 3224 2939 3875 4002 3075 2989 3917 4010
   3081 3027 3897 4039 3930 5009 4010 4001 3986 3985 3975 4028 3998 4053 3950
   4017 3961 3995 4033 3990 4000 4006 4016 3144 3845 3989 3980 3091 3928 3998
   4009 3054 3925 4017 3995 3082 3921 3992 4010 3090 3902 3993 4007 3090 3914
   3997 3082 3897 4016))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 2 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 238638 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4719 3018 3939 3986 4013 3063 3925 3982 4031 3037 3911 4030 3999 3019 3101
   3862 4009 3083 3042 2939 3948 3980 3995 4034 3064 2991 3941 3064 3888 3055
   3932 3109 3966 3064 3904 3054 3906 4017 3120 3888 3948 4042 3175 3814 4040
   3974 3977 4012 3992 3987 4027 3990 3994 4010 3992 3981 4019 4012 3996 3993
   4002 3970 3140 3895))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 3 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 238209 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4295 3942 3064 3909 4010 3989 3096 3923 3984 3997 3094 3899 3981 4035 3071
   3932 4043 3954 3993 3968 3110 3911 4005 4123 3864 4013 3968 4007 3101 3911
   3984 4014 3058 3928 3995 4015 3067 3919 3993 4021 4016 3965 3062 2985 3046
   3919 3050 2983 3944 4008 4165 3844 3031 3974 3982 3998 3161 3843 3087 3918
   3086 3925 3050 3959))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 4 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 226826 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3963 3896 3040 3966 3027 3920 3142 3898 3041 3955 3065 3937 5020 4018 3015
   3903 3094 3942 3071 3914 3079 3933 3025 3986 3035 3922 3084 3946 3039 3953
   3051 3938 3120 3877 3089 3910 3096 3915 3057 3913 3072 3953 3062 3915 3070
   3943 3042 3975 3040 3939 3039 3958 3071 3922 3042 3947 3120 3897 3041 3963
   3058 3940 3051 3938))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 0 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 473714 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4785 3959 3958 4016 4009 3982 3999 4014 4011 4005 3041 3008 3926 3073 3936
   4024 3091 2916 3972 3953 4020 4003 4001 4135 3848 3060 3023 3001 3934 3978
   4002 4015 3995 3048 3017 2984 3058 3880 3989 4024 3061 3926 4012 3998 3980
   3100 2995 3899 3091 3925 4018 3994 3994 3993 4019 3046 3977 3956 4028 3980
   3995 3049 3945 4009 4016 3944 4033 4008 4001 3021 3008 3033 2991 3945 3959
   4023 4060 3940 4002 4002 3050 3972 3967 4014 3976 4033 3040 3083 3851 4032
   3968 4022 3962 4026 3048 3021 3016 3903 3079 3933 3985 4000 4008 3990 4164
   3803 3111 2973 3036 2968 3012 3922 3993 4004 4025 3993 4035 2996 3963 3064
   2985 3018 3938 3105 3858 4041 4002 3995))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 1 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 487872 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3892 3963 3034 3057 2927 3946 4011 3983 4035 3975 4050 3047 3907 3986 3090
   3927 3997 4009 3065 3930 4056 3919 4009 4016 4136 3847 3061 3012 3021 3867
   4019 3995 4012 4019 3987 3984 4041 3966 3073 3919 4024 3998 3042 3942 3980
   4051 3948 4029 3086 2958 3003 3011 3922 4000 4017 3994 3972 4011 4014 4000
   3097 3907 3088 2979 11946 4019 3944 4013 4025 3961 3081 3928 3991 3048 3975
   3996 4005 3070 3906 4031 3973 3993 4017 4016 3975 3990 4003 4010 3100 2960
   3914 4018 4016 3969 4012 3079 2974 3952 4011 3042 3017 3943 3045 3938 3997
   4003 4001 3982 3122 3894 4026 3037 3936 3993 3989 4025 3993 3980 4014 3998
   3977 3995 4017 3068 3930 3995 3999 3063))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 2 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 460068 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4175 3947 3989 3169 3783 4014 4046 3048 3934 4007 3984 3067 3948 4054 3953
   3022 3984 3987 4033 2994 3982 4003 3029 3023 3928 4010 3066 2961 3952 4016
   3022 3041 3932 4032 3067 2958 3914 4030 3028 3008 3968 3943 3203 2890 4010
   3968 2980 3044 4103 4816 3042 3001 3036 3923 3031 3032 3931 3039 3952 3078
   3948 3041 3948 3040 3972 3036 3943 3037 3946 3034 3979 3068 3913 3066 3961
   3056 3938 3079 3915 4001 4023 3001 3976 3997 3993 3023 3058 3918 4019 3051
   2970 3955 4022 3051 2995 3936 3997 3038 3036 3917 4031 3037 2988 3948 4002
   3088 2945 3984 3980 3071 3941 3971 4017 3998 3050 3960 3985 3033 3992 3981
   4007 3089 3907 3986 4009 3071 3921 4000))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 3 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 429584 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4566 3006 3957 3983 3984 3070 3928 4016 4042 3003 3963 3989 4023 3048 3931
   4009 3034 3013 3974 3009 3019 2955 3970 3077 2959 3066 3913 3052 2980 3014
   3928 3019 3073 2973 3964 3018 2998 2990 3984 3038 3013 2972 3967 4002 3040
   2996 3930 4011 3025 3047 3929 3034 3023 2997 3945 3080 2969 3009 3946 3044
   3019 2980 3968 3053 2986 2999 3952 3048 3006 2987 3948 3046 3034 2965 3973
   3128 2905 3945 3994 3061 3005 3960 3023 2990 3015 4095 2886 3020 3017 3940
   3023 2997 3056 3942 3018 3002 3020 3924 3065 2976 3183 3805 3030 3009 3922
   4015 3043 3943 3048 3969 3049 2983 3026 3923 3053 2991 3056 3924 3020 3081
   2921 3972 3095 2907 3044 3950 3012 3067))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 4 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 447135 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3273 3814 3190 2885 3011 3897 3101 3005 2972 3929 3096 3002 3007 3881 3065
   3998 3979 4001 4008 4023 3954 3961 3079 2993 3983 3955 3048 3011 3910 4037
   3077 2986 3927 4007 3059 3008 3943 3976 3052 3031 3927 3986 3092 2969 3984
   3981 3040 3012 3951 3967 3088 2971 3951 4014 3052 2995 3935 4007 3028 3018
   3948 4000 3052 3038 3940 3964 3052 2997 3964 3990 3050 2998 3965 3985 3070
   2972 3945 4025 3036 2988 3954 4015 3038 3056 3938 4005 3005 2982 3944 4010
   3053 2977 3984 3993 3010 3051 3995 3944 3036 3024 3940 3973 3186 2870 4000
   3939 3066 2996 3941 3984 3080 2994 3951 3979 3107 2961 3937 4015 3043 2994
   3971 3998 3078 2980 3966 3992 3015 3028))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 0 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 73903 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4934 4931 4047 4054 4895 4025 4992 4991 4024 4976 5068 4942 5005 3995 4041
   4976))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 1 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 71173 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3919 4850 4981 5015 4092 4882 5019 5004 4997 4039 4039 4893 4086 3976 4947
   2427))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 2 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 71694 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4685 4937 5009 4054 3954 5010 4991 4976 4995 2299 3789 4922 4024 4958 5038
   4049))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 3 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 74345 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4408 4942 5029 4942 5038 4075 4893 5048 4024 4932 4998 3015 5004 4995 4035
   4965))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 4 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 76521 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5509 4943 4942 5057 4978 4991 5001 5025 4978 4032 4063 4884 4049 4980 4976
   4107))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 0 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 120418 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4460 3911 4022 3966 4025 3033 3933 4016 4011 3978 2997 4005 3996 4004 2984
   4018 4019 3979 3996 3983 3111 3893 3048 3007 3975 2979 3998 3985 3996 4018
   3984 3079))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 1 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 119371 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4471 4881 4016 3089 3935 3067 3919 4003 3006 4012 2981 3041 3959 3982 3989
   4024 3991 3064 3934 4002 3084 4092 2876 2995 3960 3988 4009 4022 4017 3957
   3044 3953))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 2 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 120435 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4511 3942 3058 3948 3985 3988 4006 4017 3968 4185 3807 4038 3982 3054 1883
   4061 3086 4878 4062 3042 3931 4001 3998 3989 4000 3039 3961 2964 3085 3934
   4017 4004))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 3 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 128640 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4719 3979 3968 3083 4940 3043 3947 3994 3049 3963 3998 3009 10732 4268 2996
   3985 2992 3064 3938 4011 3086 4906 3111 3843 4040 3962 4042 3995 4030 3966
   3990 3982))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 4 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 126697 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4774 3955 3028 2946 3988 4009 4011 3973 4036 4012 4008 3937 4021 4010 4019
   3978 3017 3984 3012 3037 3960 3040 3926 4006 3993 5002 4084 4914 4058 4926
   5024 3996))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 0 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 237113 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3358 3808 3053 3940 3986 3100 3894 3983 4027 3987 3992 3086 3026 3876 4018
   3988 3982 3116 2968 2990 3054 3905 3991 3092 3881 4022 3996 4005 3997 3985
   4031 3987 3106 3892 4000 3083 3908 4013 3086 2913 3988 4028 3967 4007 3073
   2941 3971 3996 4021 3962 4009 4015 3957 4032 4004 3060 3962 4015 3009 3982
   3988 3027 3966 3990))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 1 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 241848 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4879 4034 3985 3031 3983 3982 3054 3938 3044 2993 3962 4024 3978 3957 4021
   3073 3937 3968 4025 4009 3991 3041 3954 3997 3106 3885 3996 3979 4027 3972
   3052 3951 4034 3014 3955 4011 3982 4018 4159 3811 4036 3977 3055 3959 4037
   3011 3923 4001 4011 3995 3994 4014 4015 3958 3076 3960 3033 3012 3930 3044
   3982 3995 3979 4004))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 2 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 238164 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5219 2993 3965 3989 4000 3993 4009 3048 3971 4012 3039 3931 3953 3087 3935
   3989 3999 3989 4019 3079 3954 3980 3063 3934 4006 3030 3968 3987 3983 4026
   4015 3038 3938 3999 3104 3896 3033 3055 3918 3980 4029 3986 4001 3026 3965
   3984 3053 3969 3062 2967 3967 4010 3981 3979 4016 3074 3931 3998 3084 3903
   3135 2955 3927 4004))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 3 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 233724 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4769 3977 4042 3068 3885 4025 3064 3877 3115 2993 3926 3988 4010 3993 4014
   3085 3931 3970 3093 3897 3103 2947 3953 3964 3126 3910 3987 3981 4034 4121
   4838 4018 4000 3014 3991 4016 3977 3996 4013 3984 4001 3987 4023 3082 3009
   2935 3961 3099 3906 3079 3913 3149 3050 3816 3969 3129 3005 3026 2969 3010
   2957 3932 3105 3896))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 4 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 226383 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3651 3763 3983 3147 3004 3849 3088 3909 3063 3933 4042 3935 3136 4055 3812
   3072 2972 3934 3997 4016 3964 4048 4002 3060 3056 3864 3976 3114 3890 4009
   4013 3115 3011 3860 4019 3089 4910 3997 3993 3083 3006 3918 3995 3137 2961
   3903 3973 3111 3006 2999 2992 3918 3100 2972 3909 3103 2988 3010 3003 2991
   3904 3101 3013 3908))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 0 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 479380 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4433 3998 3978 4003 3108 2972 3917 3078 3926 3988 3078 3913 4046 3952 3116
   3911 3030 3061 3903 3062 3926 4007 4001 3986 4007 4027 3952 4036 3113 2988
   3890 3977 4042 3999 3988 3991 3986 4031 3650 6332 3086 2965 3982 3963 3985
   4002 3970 4004 4034 3972 3087 3896 4020 4014 3979 3085 3077 3857 4098 3901
   4001 3989 3064 3933 3975 3120 3914 3985 3999 3998 3114 3883 4043 3039 3937
   4008 3978 3986 3096 3917 4003 4013 3970 3114 2991 3171 3744 4006 3978 4002
   3105 3883 4033 3971 4018 3094 2978 3007 3921 3993 3999 4030 3056 3909 3999
   4015 3970 3114 2989 3007 3907 4014 4146 3844 3081 3895 4028 3990 4000 4003
   3092 2999 3904 3993 3983 4037 3086 3898))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 1 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 478667 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4679 3941 3983 4008 4032 3033 3922 3995 3106 3892 3112 4949 3923 4009 4010
   4000 4001 3067 3917 3968 3123 3902 3095 3894 4034 3969 4003 4011 3968 3294
   3749 3985 3077 3928 3084 3919 3988 3969 4037 3077 3884 3160 3884 3968 3164
   3842 3981 4015 4016 3962 4033 3980 3057 3066 3877 4004 3237 3781 3971 4014
   4029 3961 4004 4024 4014 3037 3924 3996 3119 3879 3982 4044 3989 3973 3155
   3874 3975 3134 3896 3993 3076 3914 3986 4031 4028 3929 3113 3897 4013 3076
   3909 4005 3106 3909 3986 4027 3981 3984 3113 3906 3981 3088 3924 4006 3119
   3868 3984 4019 4009 3989 3105 3891 4007 3102 3882 4006 4017 3982 3057 3957
   3059 3001 3933 3067 3009 2981 3948 3078))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 2 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 471986 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3192 2939 3918 3027 3964 3035 3951 4010 10794 3232 3941 3091 2984 2990 3899
   3199 2901 3015 3897 3077 3033 3892 4026 3130 3854 3100 3893 3090 3012 3903
   3988 3074 3009 3920 4001 3131 2965 3899 4009 3994 3103 3896 3963 4027 3078
   3936 3994 3082 2983 3929 4011 3086 2982 3924 3994 3069 3964 3975 3984 4002
   3083 3917 4006 3081 3913 4018 3981 5006 3979 4037 3976 3071 3930 4008 3993
   3091 3930 3992 4000 3052 3910 3108 2983 3156 3781 3049 3014 2995 3917 3094
   2970 3951 3972 3116 3919 3048 3964 3055 3936 3986 4002 3072 3926 3993 4015
   3065 3920 3993 4007 4000 4013 4009 3972 3038 3958 4008 4028 3975 3988 4008
   3993 4007 3988 4001 4002 4009 3096 3894))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 3 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 440487 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4489 4181 3764 3996 3987 3078 3007 3918 4032 3069 2980 3880 4027 3073 3005
   3897 3987 3096 2997 3941 3998 3025 3044 2966 3954 3070 2989 3000 3975 3037
   3128 2862 3921 3108 2989 2986 3916 4022 3048 3005 3944 3984 3145 2953 3920
   3997 3066 3026 3915 3979 3118 2951 3948 4001 3964 3094 3936 3045 3940 3105
   3878 3122 3887 3072 3936 3067 3913 3101 3955 3025 3929 3999 3985 3102 3903
   3092 3924 3068 3023 2985 3916 3080 3024 2985 3899 3101 3023 2961 3967 3949
   3084 3041 3861 3112 2954 3020 3940 3076 2999 3003 3914 3126 2953 3054 3869
   3086 3913 3994 4010 3063 3003 3008 3935 3062 3004 2996 3919 3085 3032 2976
   3923 3050 2998 4953 3979 3087 2964 3030))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :RESIDENT :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 4 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 463085 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4191 3040 2965 3000 3919 3074 3012 2973 3945 3988 3137 2939 3931 3979 3986
   3192 3815 3984 3103 2994 3944 3960 3070 3009 3980 3948 3074 3006 3927 3996
   3978 4015 4009 4000 3062 3928 3984 4013 3068 3926 4049 3959 3064 3940 3983
   4014 3113 3876 4005 4003 3068 3913 3080 3932 3070 3930 3083 3914 3073 3928
   3089 3901 3095 3891 3093 3931 4109 3886 3101 3905 3986 4016 3045 3949 4012
   3984 3096 3884 4020 3997 3105 3895 3995 3989 3073 3939 3085 3904 3076 3920
   3049 3960 3139 3847 3130 3879 3076 3937 3053 3943 4022 3966 3060 3956 3065
   3907 3113 3894 3084 3940 3063 3924 3067 3938 3088 3881 3123 3887 4024 3991
   3088 3891 4011 3995 3077 3912 4005 4006))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 0 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 63701 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4791 2992 3045 4880 5007 4988 3057 3924 3992 3993 3092 3918 4004 4024 3954
   4033))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 1 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 60448 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4528 3046 3875 3091 3009 3886 4001 4025 3012 3968 4006 3968 4010 4031 3959
   4027))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 2 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 60881 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5009 3928 3993 4040 3928 3097 3897 3117 3888 3983 4034 3967 3147 3889 3055
   3901))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 3 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 60703 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4815 3950 3029 3946 3983 4003 3975 4024 4010 3039 3947 3064 3931 3089 3915
   3980))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 8 :REPETITION 4 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 63786 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3833 4794 4013 4004 3969 4019 3179 4878 3935 4023 3986 3977 4216 3791 4019
   3145))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 0 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 121329 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3521 4738 3936 3137 3892 3982 4008 4001 3961 4035 4008 3974 4022 4005 3046
   3942 3987 4014 3079 3938 4008 4084 3922 3018 3081 3858 4043 3999 3063 3928
   3979 3109))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 1 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 119506 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4536 3987 3931 3110 3874 4009 3995 3106 3939 3144 3844 3032 3952 3078 3932
   3091 3906 3030 3958 3113 3867 4047 3253 4845 3963 4001 3128 3875 4009 4001
   3988 3949))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 2 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 121233 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5236 3933 3982 4027 3976 4011 3980 4014 3225 3761 4043 3098 3882 3957 4056
   3098 3880 3993 4001 3132 3929 3057 3968 4039 3963 3094 3925 4013 3987 3092
   2964 3905))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 3 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 123306 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4397 3921 3057 3955 3974 3979 3066 3974 3972 4005 4179 3831 3972 4009 3986
   4035 3983 3971 4026 4032 3023 3960 3973 3077 3031 3902 3998 5042 3010 3985
   3968 4011))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 4 :REPETITION 4 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 121155 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4086 3069 3868 4021 4008 3066 3921 3995 4019 4006 3045 3955 3989 4009 3027
   3981 3983 3996 3126 3908 4056 3953 3963 4021 3047 3988 3976 4006 3967 4028
   4029 3037))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 0 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 250242 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4171 3965 3975 4011 10778 4227 4006 3998 3986 3982 3095 3931 3972 4183 3827
   4014 3988 3971 3109 3949 3973 3981 3083 3940 4025 3958 3075 3945 4001 3986
   3109 4045 3870 3988 3024 4004 3977 3967 4023 3967 3199 3841 3964 4131 3097
   3803 4013 4042 3105 3863 4004 4019 3069 3887 4036 4010 3075 3892 3990 3134
   3889 3973 3992 3117))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 1 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 234202 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4177 3950 3966 3089 3912 3979 4055 3044 3921 4008 4000 3065 3937 3995 4010
   3049 3937 3077 3931 4003 4012 3041 3938 4149 3883 3027 3948 3987 3995 3241
   3801 4042 3937 3060 3008 3972 4024 3038 3006 3930 4035 3932 3097 3955 3974
   3961 3108 3961 3975 3969 3120 3911 3983 3067 3971 3089 2966 3012 3885 3179
   3902 3898 3136 2951))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 2 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 237313 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4321 3968 3985 4975 3968 3162 2975 3911 3984 3045 3958 3992 3131 3881 4012
   3994 3071 3009 3967 3972 3916 3183 3866 3989 3965 3125 3921 4012 3991 3080
   3980 4007 3966 3065 3945 4058 3989 3025 2986 3053 3900 3955 3094 4067 3910
   3965 3990 3105 3915 3985 3085 3018 3907 3959 3122 3019 3918 3935 3088 3949
   3991 3974 3983 4054))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 3 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 258196 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4163 3931 3986 4004 3963 4018 4024 3984 4035 3958 4001 4023 4237 4857 3073
   3923 3090 3767 6066 6024 5973 5978 3154 4000 3976 3983 4023 4044 4952 4976
   3969 4009 4056 2955 3038 3036 3906 3990 5997 3272 3710 4060 3998 3067 3951
   3946 3997 3100 5966 2970 3040 3973 4010 3975 4007 3983 4026 3941 4006 3126
   3896 4002 3063 3935))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 2 :REPETITION 4 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 252247 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4235 3027 2968 3957 4040 3941 4024 3984 4023 3977 3993 4037 3985 4002 4114
   3002 3054 3847 3954 4044 4028 3957 4005 3964 4009 4030 4001 4082 3953 3983
   3998 4053 3941 3979 3982 4056 3989 4027 3979 4006 4013 3960 4013 4013 3991
   3967 4127 3978 3992 3917 4015 3062 3955 3981 4041 4021 3952 3968 4009 5040
   3977 3991 3984 4023))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 0 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 480206 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3334 3828 3990 4001 3981 3093 3231 2762 2982 3902 4049 3990 4023 3974 3988
   3089 3928 4050 3915 4020 3079 3000 3936 3993 4004 3983 4000 4012 3968 4053
   3116 3844 4026 4005 3999 3046 3933 4013 3092 3920 3983 4013 3990 3984 3122
   2962 3001 3956 3984 3966 4023 3998 3083 3920 4000 4010 3984 3992 4017 4075
   3937 3973 4021 3978 4010 3976 4010 4021 3038 3926 4036 3973 4008 3975 4027
   3018 3102 3883 3060 3933 4010 3061 2993 3908 4006 4024 4015 4042 3957 3979
   3042 3042 3901 4030 4001 3984 3992 4016 3990 4042 3967 3992 4014 4001 3075
   2983 3007 3939 3964 4016 4007 3980 4054 3009 3005 2993 3916 4030 4018 3073
   3930 3059 3034 3897 3982 3992 4013 4058))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 1 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 492339 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3549 2861 3013 3922 4000 3997 4011 3982 4000 3052 3944 4000 4014 3994 4027
   3958 4040 3986 4023 3962 4026 4052 3010 3935 3982 3990 4023 3959 4028 3999
   3972 3114 3996 2990 3950 4507 4961 3857 3770 5411 4782 3699 4040 3959 3974
   4027 3101 2968 3919 3063 3953 3947 4019 4009 3106 3892 4153 3904 3975 4006
   3045 3911 4035 3077 4991 3906 4077 4025 3916 4360 4025 3697 4342 3150 3782
   2868 3312 4147 4818 3765 3753 3985 3980 3984 4001 3087 2975 3920 4022 3954
   4017 4053 3057 3911 4014 3971 4010 4000 3088 3924 3078 3889 4024 4004 4012
   3964 4011 3977 4202 3816 4007 3972 3120 3870 3046 3016 3929 3095 3955 4016
   3988 3976 4000 3954 4031 3998 4010 3993))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 2 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 495893 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3940 3941 4019 4000 3985 4005 3974 4000 4021 4001 3985 3079 3944 3965 4031
   3050 3006 3930 4105 3903 4012 3978 4016 3942 4044 4005 4018 3985 3971 4078
   3967 4012 3980 3971 4014 3995 4000 4000 4032 3953 4028 3980 4004 3083 3897
   4017 4013 4024 3969 4003 4020 3221 3754 4004 3065 3937 4016 3965 3057 3946
   4029 3991 3073 3949 3997 3969 3061 3922 4010 3985 3086 3983 3954 3980 4022
   3968 4008 4023 3077 3911 3094 9770 3309 3818 4019 4005 3076 3907 4000 3994
   3055 4976 3933 4041 3091 3941 3968 4003 3072 3909 3997 4077 4052 3940 3047
   3896 4005 3988 3997 4016 3046 4044 3927 3951 3142 3853 3997 4025 3130 3857
   4024 3976 3080 3936 3999 4002 3052 3938))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 3 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 498209 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4275 3930 3090 3926 3998 3972 4037 3950 4042 4000 3971 4009 4001 3997 3051
   3043 3902 4006 3973 4012 4035 3986 4091 3938 3933 4018 4012 3982 3990 3995
   4025 4006 4023 4046 3969 3956 4017 3986 4018 3989 3072 3022 3905 4012 3035
   3931 4023 4000 4008 3960 4040 3967 4007 3994 4018 4003 3993 3981 4001 3994
   4007 4010 3985 4042 3973 3986 4013 3956 3072 3924 4054 4008 3082 3924 3986
   3973 4002 4030 3998 3968 4034 3972 4009 4008 3992 3990 4031 3990 3940 4033
   3117 3886 4052 4034 3035 3889 4011 3155 3837 3977 3059 3010 3105 3919 3943
   3985 4053 3989 3968 3999 4004 3985 3993 3992 4006 3970 4005 4027 4011 3988
   4034 3958 4012 4011 3955 4028 3999 3997))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 2048
 :GROUP-SIZE 1 :REPETITION 4 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 513122 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4146 3978 3969 4002 4004 4000 3997 3997 3984 4003 4009 3997 4018 3979 4022
   4000 3997 4010 3988 5000 4014 4009 3988 4027 3944 4006 4034 3976 4003 3990
   4021 3976 4112 3909 3965 4049 3975 4116 3909 3941 4021 4019 3995 3967 4019
   4022 4006 4018 4005 3955 4020 3984 4022 3989 4021 4006 3973 3986 3989 4007
   3993 4006 4610 3506 3921 3980 3994 3985 4003 4014 4001 3996 4003 3977 4031
   4006 3976 3997 3998 3998 4022 3993 3992 3991 4009 3995 4004 4105 3891 3992
   4007 3959 4043 3997 4012 4022 3973 3976 4044 3958 3985 4034 3995 3988 4032
   3977 3989 4014 4004 3992 4020 3997 4118 3959 3982 3938 3969 4025 3981 4024
   4016 3963 4005 3968 3987 4044 4015 3986))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 0 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 73931 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3949 4886 5029 4996 5013 5000 4061 4972 4967 5133 3920 5019 4020 4910 4013
   4038))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 1 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 75946 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4961 4960 4940 5031 4996 4299 4697 5014 3965 5015 5013 4075 4998 5071 3947
   4955))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 2 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 75975 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4969 4953 4969 4990 5018 5217 4755 5014 4984 4116 3994 4945 3984 5034 4970
   4062))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 3 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 72932 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4964 3960 4987 5011 4981 4067 4120 4796 4036 4999 4994 2863 5104 5050 4035
   4956))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 8 :REPETITION 4 :OPERATIONS 128 :API-CALLS 16
 :CANONICAL-STRONG-FLUSHES 16 :WALL-TICKS 76241 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5271 4902 4992 4974 5016 4992 4993 5061 4932 5055 4030 4940 4067 3964 4983
   4062))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 0 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 118499 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4622 4954 3941 3099 4933 3982 4001 3109 3903 3983 3057 3913 4008 3086 3936
   3042 2962 4004 3980 4012 3006 4008 2030 3968 3984 3060 3960 3048 3028 3931
   3967 3974))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 1 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 123203 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(5275 4984 3990 3981 3954 3011 4014 2972 3088 3935 3944 4048 4001 3978 3042
   3989 3976 3046 3970 3982 3033 3977 4000 4046 4959 4115 2854 4018 4014 4024
   2969 4005))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 2 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 123514 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3404 4972 3914 3147 4905 3973 4031 3966 4002 4045 3981 4029 3977 3078 4916
   3181 2778 4064 2948 4031 4008 4010 3041 3939 4011 3033 3976 3077 3020 4008
   4968 5068))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 3 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 123694 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4682 4955 4089 4900 3984 2999 4002 1966 3260 4766 4011 4021 3979 4013 3036
   3976 3980 3051 5066 3957 2970 3994 3941 4044 3984 4033 2948 4040 3000 3995
   3986 4055))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 4 :REPETITION 4 :OPERATIONS 128 :API-CALLS 32
 :CANONICAL-STRONG-FLUSHES 32 :WALL-TICKS 131193 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4786 4983 4947 3081 3926 4015 3990 4054 3941 4105 3926 3975 3996 3002 3998
   3060 2989 3979 3969 4067 3977 3983 3033 5065 4980 4097 4914 4138 3883 5053
   4403 4864))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 0 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 277858 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4252 5410 3561 5777 4869 4273 5784 4109 5066 5223 5137 4663 4376 4501 4018
   4855 2927 4227 4448 4226 3899 4971 4356 4441 5326 3228 5041 4484 4477 4983
   3362 4672 5291 5406 4357 3927 2879 4010 3957 4093 2992 3022 3876 3104 3941
   3960 4029 4086 4961 4974 3086 4934 5206 4119 3635 4074 5035 4916 4151 3790
   4029 4035 5013 3998))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 1 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 273857 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3946 4891 3052 3001 3907 3970 4026 3984 3996 4999 3009 4011 4141 9697 4193
   3096 3891 3975 3984 4099 3010 2937 3969 4079 5074 4956 4058 4973 4942 4972
   4084 4092 4859 4942 5042 5047 4037 3969 5025 4936 3986 4936 3145 3958 4920
   3978 3267 3848 4889 4004 3208 4853 4000 4954 5074 3938 3064 3844 4101 4036
   4856 4090 4985 5011))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 2 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 265581 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4485 1979 3966 3970 1772 4219 4039 1891 4070 4011 2976 4019 4048 3039 3968
   3956 2949 4031 4076 2972 3969 4015 4115 3925 4013 2987 4072 5031 3904 4972
   3137 3955 4916 4956 4100 4981 4982 2983 4120 4920 3990 4957 4181 3891 4933
   5085 4946 4993 5017 4084 4869 4013 4069 4985 4114 3879 5025 4923 5011 5012
   5077 3942 4992 5064))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 3 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 250825 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(3934 4896 4053 2999 3917 3950 4044 4031 3969 3980 3252 3806 3968 3929 4052
   4025 3970 4001 3151 3870 3998 3988 4029 4064 4943 3986 4028 3991 3991 3974
   4025 4008 4014 2948 4067 3976 3986 3986 4062 3976 3990 3983 4000 4015 3080
   3858 4027 4038 3981 3994 3052 3935 4018 3971 4013 4042 3975 3986 4034 3997
   3974 4003 3105 3892))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 2 :REPETITION 4 :OPERATIONS 128 :API-CALLS 64
 :CANONICAL-STRONG-FLUSHES 64 :WALL-TICKS 250854 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4877 3957 3989 3998 3099 3887 3997 4026 3981 4109 3912 3965 4195 3770 4048
   3097 3893 3959 3994 4062 4008 4017 3958 4033 4002 3998 3998 4022 3972 3992
   3008 4031 3964 3977 4044 3978 4012 3972 4035 3972 4017 3094 3907 4002 3984
   3965 4006 3114 3959 3944 4001 4018 3988 3982 4085 3960 3992 3958 4021 3148
   3879 3953 3994 4037))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 0 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 480316 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4288 3915 3994 5005 3990 3085 3896 4034 4007 3970 4003 4001 4020 3096 3886
   4010 3975 3980 4009 4016 3153 3857 3990 4007 4023 3974 3995 3990 3988 4040
   3992 3974 3103 3929 4041 3941 4000 4009 4025 4049 3927 3108 3904 3054 3919
   4006 4040 4034 3057 2909 3981 3956 4021 4004 4055 3044 2992 3884 3139 3861
   4010 3108 3920 3984 4028 3946 4016 3055 3002 3932 3134 3866 4051 3056 3941
   3950 4005 4009 4007 3134 2946 3917 3123 3847 4058 3100 3889 3971 4008 3988
   3990 3084 2997 3938 3129 3857 4021 3063 3929 3981 4005 4001 4022 3069 3016
   3882 3122 3861 4031 3100 3903 4001 3998 3974 4052 3051 2991 3913 3119 3901
   4023 3041 3928 3962 4009 4018 3998 3126))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 1 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 476891 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4968 3929 3111 3874 4013 3111 3908 3973 4003 4089 3911 3115 3886 4064 3010
   3944 4008 3068 3905 3991 4005 4023 4150 2936 3928 3972 3184 3813 4023 3113
   3890 3970 4017 3982 4004 3085 3905 4028 3085 3888 4020 3090 3911 3954 3999
   4015 4065 3041 3918 3987 3115 3866 4009 3153 3870 3998 3989 3977 4038 4002
   3978 4016 3101 3891 3106 2971 3939 3945 4005 4033 4019 3066 3907 3991 3088
   3888 3137 2988 3905 3983 4006 4021 3980 3084 3934 3981 3128 3876 3108 2983
   3913 3973 4014 4018 4022 3021 3951 3978 3105 3886 3087 3038 3922 4156 3830
   4008 4017 3034 3906 4015 3084 3864 3173 2969 3921 3061 3913 3067 3047 3887
   4038 3954 4025 3974 4002 3996 4064 3945))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 2 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 522390 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4418 3960 3944 4014 4024 3978 4029 3137 3853 4047 3963 3961 4002 4012 4023
   4013 3950 4003 4032 3973 4176 3990 3862 3991 4014 3971 4004 3997 4000 4015
   3998 3975 3998 3989 4026 3973 3994 4028 4066 3108 3840 3956 3108 3905 3996
   3991 4038 3998 3979 3995 4303 3892 3985 4046 3808 3973 4158 4260 3720 4107
   3750 4110 4390 3688 3796 4592 4580 3838 4346 3609 3976 4254 3845 4011 3989
   5927 3132 3938 4011 3992 4181 3804 6054 3931 4006 3120 4127 3956 4102 6773
   3949 3958 4039 4613 4393 3995 6009 3967 6068 3922 3101 3898 3974 3330 3758
   3970 6072 3231 3684 6005 4009 5982 4017 3030 3053 3900 3983 3102 3301 4609
   4011 3158 3834 3964 4040 5006 5988 4002))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 3 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 517210 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4410 2872 3038 3877 3999 4006 4007 3990 4038 4051 3898 4019 3984 3975 4048
   3998 3991 4000 3984 4004 4023 3971 4033 3986 4015 10723 4286 3947 4001 4010
   4043 4064 3902 4010 3979 3987 4019 3988 4026 4000 3991 3995 4029 3941 4049
   3982 4031 3971 4000 3997 4103 3902 4002 4008 3993 3984 4151 3822 3979 4054
   3997 4005 4014 3958 3969 4041 4012 3963 3998 4020 4063 3948 4021 3964 4021
   3975 4016 3995 4036 3963 4006 4160 3844 3985 3997 4013 4023 3993 3988 3979
   4053 3933 4005 4012 4013 3991 4014 3969 4031 3973 3991 4026 3994 3987 4029
   3988 4153 3821 4010 4005 4083 3924 3996 3999 4019 3946 4041 3994 4001 3996
   4023 3976 4005 3991 3997 4002 4020 3992))
(:KIND :GROUP-ENGINE-SAMPLE :MODE :PAGED :VERSION 2 :VALUE-BYTES 60000
 :GROUP-SIZE 1 :REPETITION 4 :OPERATIONS 128 :API-CALLS 128
 :CANONICAL-STRONG-FLUSHES 128 :WALL-TICKS 492270 :TICKS-PER-SECOND 1000000
 :ALLOCATED-BYTES 0 :API-CALL-TICKS
 #(4354 3940 4016 3960 4017 4012 3997 3994 3999 3111 3916 3954 3994 3965 4051
   4005 3948 3199 3846 3955 4078 3185 3941 3858 4009 3044 3927 3999 4009 3067
   3944 3963 4008 3164 3913 3865 4077 2992 3966 4073 3935 3153 3860 4998 3951
   3137 3896 4008 4132 3951 3980 3955 3945 4100 3922 4007 4011 3986 3986 4036
   4038 3900 3167 3894 3970 4015 4007 3948 4041 3068 3911 4093 3981 3026 3970
   3964 4012 3083 3923 4029 3969 3077 3020 3947 3993 3178 3829 3932 3990 3174
   4516 4664 3683 3047 3997 3971 4022 3957 3987 4058 3024 3933 4032 4021 3962
   3944 4005 4075 3971 3954 4035 4039 3965 3965 3099 3914 4006 3993 4005 4026
   4044 2991 3976 3916 4093 3030 4085 3803))
(:KIND :GROUP-ENGINE-BENCHMARK :STATUS :PASSED :SELF-TEST NIL :PLATFORM
 (\"Darwin\" \"ARM64\" \"2.6.9\") :LIMITS
 (:SERIAL-M1 :EIGHT-HOT-KEYS :API-CALL-LATENCY-IS-NOT-PER-REQUEST-TAIL :NOT-RSS
  :NOT-POWER-LOSS))
"
 :STDERR "" :EXIT-CODE 0 :LIMITS
 (:COMMAND-OUTPUT-IS-RAW :WALL-TIME-INCLUDES-ENTIRE-COMMAND
  :NO-AUTOMATIC-REQUIREMENT-PROMOTION))
