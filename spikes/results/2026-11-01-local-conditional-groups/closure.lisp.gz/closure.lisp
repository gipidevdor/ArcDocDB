(:KIND :EXPLICIT-IF-EVIDENCE-CLOSURE :STATUS :PASSED :UNIVERSAL-TIME 4002524819
 :DRIVER-SHA256
 "d9cff57196e280987cd9d1ed335bb2af18b32b311efd945d631a875a4ca6d5bf"
 :INPUT-SHA256
 "4a19ac4b712e2632dd61cb92370ec2c928d9f4e16cf33ecaf03731a2d816a807" :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002521112-command-42856-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/initial-archive-command/conservazione.lisp"
   :SHA256 "2a60e37dc732c9bb6660acb6edf02f251bbb3d932942f5efa706257bde8ca4de")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002521112-command-42856-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/initial-archive-command/report.lisp"
   :SHA256 "0be1102a3e1a778c38c7722e5b08d2bd072c28f72c829c86d6580f484ba9ab5a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002521235-command-44074-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/archive-self-test/conservazione.lisp"
   :SHA256 "13371ed11bdc4323c45e2fe1b53244e5c6fed0115cc2731afdcb96f2a02e11c7")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002521235-command-44074-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/archive-self-test/report.lisp"
   :SHA256 "5eead9fb788b42da7307c73569b7862a89ed8365e7e046791129154b1e79ccd4")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002522526-command-64676-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-archive-command/conservazione.lisp"
   :SHA256 "256afaf038f374d2c77d5aea237c5da43965f743cd4860c755d3d835a293f37d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002522526-command-64676-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-archive-command/report.lisp"
   :SHA256 "be65b79116fad96f588098ce1f99bf19c66c90293458450b20971b6fc078325b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002522590-command-68226-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/qualification-summary-command/conservazione.lisp"
   :SHA256 "9fcd9e4654b46d583a8dab0e5d2e42db7d7946cd639f85d0ece3853255d7f9a8")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002522590-command-68226-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/qualification-summary-command/report.lisp"
   :SHA256 "676219e07962c89728a0cc6c411f5dce94c5f4d39b3b6b533d4e1fc4661e6fb8")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002522855-command-75771-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-analyzer-self-test/conservazione.lisp"
   :SHA256 "5b24e29c442bf45ed2ad6e2be671aafcc5ef82194698b809bacd675587b8705b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002522855-command-75771-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-analyzer-self-test/report.lisp"
   :SHA256 "1bb98109c270a36229730dbd0390c2d9b535eb838f576075ddc7379613504808")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002523135-command-79150-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/analysis-command/conservazione.lisp"
   :SHA256 "5a080472423d81df6c1d540705cfdc7fd0d9cc2765f0562db50d267a3408aff0")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002523135-command-79150-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/analysis-command/report.lisp"
   :SHA256 "dd331bc82dd4cbc59cb8d9140435396bac1bf46ba580153a46018fc2557dd89b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002523582-command-83390-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/benchmark-archive-command/conservazione.lisp"
   :SHA256 "a1070a785c5b670e8a72bd1c867c9234e04c1463e56a19a328ed0a9e3e26f3ae")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002523582-command-83390-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/benchmark-archive-command/report.lisp"
   :SHA256 "7418364b6cf265a45680f63be149beb1e365c7dbf6aa477c67f0a5266d24293a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002523661-command-83735-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-analysis-command/conservazione.lisp"
   :SHA256 "1f4ad4d67af298b4c9c2161eedbafd9822d353f2607a0f7cb0d62c39e49bfb31")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002523661-command-83735-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-analysis-command/report.lisp"
   :SHA256 "11b59e95ea0b44eb149232e84816f361ffada340c017f356e7a33663fa028f0f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002524041-command-85696-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-repeat-archive-command/conservazione.lisp"
   :SHA256 "ccb02e41edf45c4898f71a5a754a0a1e74c62e9253c4a6be1b5332dcd7644de7")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002524041-command-85696-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-repeat-archive-command/report.lisp"
   :SHA256 "d0838b59b6a87ac6a5e5d841a5463695bf14595b9a1f201bda8633e8c599fa22")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002524058-command-85766-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-repeat-analysis-command/conservazione.lisp"
   :SHA256 "53192b1c4d6b2359346b277f08bdb0c51cb765744c6ca7bc184acb3303c0e434")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002524058-command-85766-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-repeat-analysis-command/report.lisp"
   :SHA256 "afd14a5110566c8b158b7b7a08ff35f92885ca83d994db52683c67028b046a2d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002524143-command-86805-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/identity-command/conservazione.lisp"
   :SHA256 "049b5563c722b2b2ba6e573f74cc6a3e8a6d2ec9e2276fb286b9cb78fe77c210")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002524143-command-86805-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/identity-command/report.lisp"
   :SHA256 "31be6733921104bf213257ece0ca47df04029ef6432aaa3d38e94f28246ccd2f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002524480-command-90727-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/current-source-command/conservazione.lisp"
   :SHA256 "b11fa22c993ffaae7b78f0373195a453af86f8ea442caf09340a31763c0198c8")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002524480-command-90727-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/current-source-command/report.lisp"
   :SHA256 "6ce4a551e52a4329d569aed601aeeb5a01f2ab6b0cfa1d3e29e248fe42006976")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002524480-command-90729-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-checks/conservazione.lisp"
   :SHA256 "687bbf4c8d892b34b440a030f8b6512245608c15f5b58ea8647be52f246c2284")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002524480-command-90729-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-checks/report.lisp"
   :SHA256 "560f4e43b73f65a1fd59e94e17fc12397303a4bb747cbd6afb7cb17c960a22f2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/0/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/0/scan-4.lisp"
   :SHA256 "b943d5d0ed2e47f20f2cfecb6d10850b24dc4f93218fc3ea2b21991672f4e592")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/0/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/0/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/0/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/0/scan-4.stdout.log"
   :SHA256 "c4284bf41dbfdb800aa06a57ea1b09e5fe13265e84f4a5faf01cb0692e9128b0")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/0/session.pid"
   :SHA256 "6f32694f3136e1b5a0350a19181e2ba296f912a055aae69b2bb04ba252ad2942")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/0/stdout.lisp"
   :SHA256 "3c3e1d0db8c3c9caca1995916027d78492d2f580d5e50cdf94d4e59281dd4aed")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/1/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/1/scan-1.lisp"
   :SHA256 "960f8b4a8f6c108470f5d460664d549722e330d555f38793649dec3a94c8f3dc")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/1/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/1/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/1/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/1/scan-1.stdout.log"
   :SHA256 "153dad571ea0f3bd23f47f945fef97bf87cde623fe15b6d10a21f9537e115b6b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/1/session.pid"
   :SHA256 "49c39da6bd48b8613434f68809e795742132f2d9eb3e0e30e286abbade54d50e")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/1/stdout.lisp"
   :SHA256 "1408b0f66ab661b8673cd350d40e192493dba517be5a2705d382c63c8438d28d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/2/scan-3.lisp"
   :SHA256 "b5b160391f0deca75ae18202f796bac2f86b5efdce48175e140a311dd95bc02b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/2/scan-3.stdout.log"
   :SHA256 "056d66df3c2e53fa7be7d4d9cfc48c6e2d3c3d6494d870c082aebfb09952c995")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/2/session.pid"
   :SHA256 "454d912b9bd8175935f8aa3eaccace69aacf10f5068576f66ff01751facf4f9c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/2/stdout.lisp"
   :SHA256 "2e7fca2d9e2fc0d9537df579c78b038ae3c1477cd817cd40fffacbc4cda80597")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/3/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/3/scan-2.lisp"
   :SHA256 "c18fe449c44d1b53b4f13a7dbb4e94be56e1c82d6fa65e65e9bd6d17b00fac32")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/3/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/3/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/3/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/3/scan-2.stdout.log"
   :SHA256 "ac8410df032d936a7e0127593cd049326ac674f8efba5d2744daeac2247e2d09")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/3/session.pid"
   :SHA256 "e62e83add5bd84c1f11c298050eaafba6263a438fbdb0bb9408252fbbc85e968")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/3/stdout.lisp"
   :SHA256 "25564bda945c2105101cc7d392d13240d14238d1a27e9acf8da5f5ae0875158d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/4/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/4/scan-5.lisp"
   :SHA256 "cdee32ec9f2846257d5157a3f07e5dc12c302c6a98b750fc4cc85ef86616cd5a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/4/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/4/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/4/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/4/scan-5.stdout.log"
   :SHA256 "e6279678ddb64b65b3d0767776d02720120876d9e87b50d8dfa9accb87d960c5")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/4/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/4/session.pid"
   :SHA256 "3fb7e3a7ce3c14c0fb3ea4c16ed0a937795bd259fbf16c9e6f41a543d8fea2f9")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/4/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/4/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/4/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/4/stdout.lisp"
   :SHA256 "2be099c08baa117e6464bba3c631874220ab09ec3b9d2dfa3fa3a54fb50eb69f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/5/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/5/scan-6.lisp"
   :SHA256 "3059eb9979bfe93e49cc8380f1fbee8963098e34fff3418bb0a74537c46b21f2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/5/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/5/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/5/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/5/scan-6.stdout.log"
   :SHA256 "c682f912cb1b332a79756208cdcb31a4ce214778a730269d0f3252311cfbf8e6")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/5/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/5/session.pid"
   :SHA256 "1e77d5065ab8e6126ed89c5b4dbadbfa9ed871529098430d963cbced1e61e9be")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/5/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/5/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/5/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/5/stdout.lisp"
   :SHA256 "c020b7cfad97537e62a5b046c84a727494a77429c7ba3d0b3c88699d692fadea")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/6/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/6/scan-7.lisp"
   :SHA256 "bb316b6bf2c32f8bfb9e69cc9208b9796f519fb8b9a8f0db10d3b65dcbb74a49")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/6/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/6/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/6/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/6/scan-7.stdout.log"
   :SHA256 "b3a47fe71f4dd5d1651decf9c8adaa93cac175332e5558548e73da20786136df")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/6/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/6/session.pid"
   :SHA256 "52e3d3675c323600ac4ee45e2db9521445c996fd2f39411b0d2888b129b5a152")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/6/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/6/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/6/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/6/stdout.lisp"
   :SHA256 "632ff70d8e777211e68c9c6aa18fbbacd544790316335340e811020c0820425a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/7/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/7/scan-8.lisp"
   :SHA256 "f51b2cf9cd0293f80daf31e9b375f966b2e5ab4ab62b614ab0c514a6b99558a2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/7/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/7/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/7/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/7/scan-8.stdout.log"
   :SHA256 "0cc91fd9708e8c8cb569e458b3b8a7baccce497729820d9b7c3671b84b3545ac")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/7/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/7/session.pid"
   :SHA256 "52269311c1cc8f6c4ae122e7df3174b54377c8a9eb3ff7473ec068cb8af73017")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/7/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/7/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/7/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/7/stdout.lisp"
   :SHA256 "ba7fcea75bc2864a21f3b940483384447375da9144341dee0b2be1a13f199598")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/8/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/8/scan-9.lisp"
   :SHA256 "6a98158b302c5d5fa117f533f3b9d7b36ce5ab5c49727a1be3b44da03bc0d325")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/8/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/8/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/8/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/8/scan-9.stdout.log"
   :SHA256 "ab9b15e0414e3ff1ab7b2359443d06c7abafd710fe38b6964fbe295c6b4adac0")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/8/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/8/session.pid"
   :SHA256 "cd3f4dd62afa35739267e9300f49d27784e742608f8a21f7aedc788fa62c3550")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/8/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/8/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/8/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/8/stdout.lisp"
   :SHA256 "31ea0941716566ef078790085e72650d0e0e931bcea03088f090c3f9e6fb9c66")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/9/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/9/scan-10.lisp"
   :SHA256 "97f68204e3bfb67dfa3353460b5a2bc457df74a599281eff2759d013995e5b9d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/9/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/9/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/9/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/9/scan-10.stdout.log"
   :SHA256 "9878691efc86c79ee1f6189bed3e9222b5a248d06231125c3c92bf77c6421dde")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/9/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/9/session.pid"
   :SHA256 "85bcbbb909652199f454f217c36f2be573dcbb5186610a34f82606ec4bb3a294")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/9/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/9/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-mlDlwB/9/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-check-mlDlwB/9/stdout.lisp"
   :SHA256 "15ed29b95978e446d17cd9f520516673c21d11b1ceb647a83107d088cbc75fb4")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002522006-command-53241-0/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/4002522006-command-53241-0/self-test-report.lisp"
   :SHA256 "7e47f646dc8ee821fcd8e3536a898b414e928bb78b4cbfd416d95f7b431a963b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002522007-reader-self-test-53258-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/4002522007-reader-self-test-53258-0/report.lisp"
   :SHA256 "2ad5f4fda175d08a18d43ec6706c34e4ae65f938b00c0a24cbd39e3a3caea7d9")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002522007-snapshot-self-test-53255-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/4002522007-snapshot-self-test-53255-0/report.lisp"
   :SHA256 "c0c473473ca2e511bec64448fa65262d68c03619837cca74f36e0f19c4935eb9")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/command-archive-collector-self-test-M69wnh/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/command-archive-collector-self-test-M69wnh/self-test-report.lisp"
   :SHA256 "d4f191d29f8ee5a95bb3fb2b85925c612a2beae1d4985917d8ade599e8638143")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-parallel-self-test-QtGepe/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/evidence-parallel-self-test-QtGepe/report.lisp"
   :SHA256 "55a2d635c06efb69f45964688fd4633c0ff7ed9c9d74991d620a4b81194ceb63")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793533510-59948/boundaries.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/ci/selftest-1793533510-59948/boundaries.lisp"
   :SHA256 "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793533510-59948/conditions.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/ci/selftest-1793533510-59948/conditions.lisp"
   :SHA256 "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793533510-59948/data.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/ci/selftest-1793533510-59948/data.lisp"
   :SHA256 "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793533510-59948/measure.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/ci/selftest-1793533510-59948/measure.lisp"
   :SHA256 "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793533510-59948/publication.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/ci/selftest-1793533510-59948/publication.lisp"
   :SHA256 "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793533510-59948/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/ci/selftest-1793533510-59948/report.lisp"
   :SHA256 "3bf53e3748c34568e0fb83b9f6f7ed394be5c711a74ca8b7bdde88a45f49bc23")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793533510-59948/tests.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/ci/selftest-1793533510-59948/tests.lisp"
   :SHA256 "ba1c0e543638f0424a2c9f3c07cc641b5f0e776c7e036135293eebd50a169904")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793533510-59948/workflow.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/support/ci/selftest-1793533510-59948/workflow.lisp"
   :SHA256 "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"))
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/source-identity.lisp"
   :STATUS :OK :ORIGINAL-BYTES 174117 :STORED-BYTES 55717 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "source-identity.lisp.gz" :UNCOMPRESSED-BYTES 174117 :UNCOMPRESSED-SHA256
    "d46b8f879d79e44374123ca6679810fd56e597dea2bac33aeb740d5e8dade978"
    :COMPRESSED-BYTES 55393 :COMPRESSED-SHA256
    "bf9793ea52389e1b67fcebde509c1db7382fb4c9e11fb4601d9266311d266168"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/analysis-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349905 :STORED-BYTES 112008 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349905 :UNCOMPRESSED-SHA256
    "dd331bc82dd4cbc59cb8d9140435396bac1bf46ba580153a46018fc2557dd89b"
    :COMPRESSED-BYTES 111692 :COMPRESSED-SHA256
    "710acb8d555ea22e13ead69dfa28330be277b919bcd38047071c8f8392280696"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/analyzer-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349084 :STORED-BYTES 111690 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349084 :UNCOMPRESSED-SHA256
    "5384d2b261bf00eb3c6f9146d1fd77d493f5bf68d38d20f63dac21e879af2ea2"
    :COMPRESSED-BYTES 111374 :COMPRESSED-SHA256
    "24a06686d81b015714b4a7bb61a9a1b907cfd1f4af55715a7c7c05540f4a44d1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/archive-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349089 :STORED-BYTES 111691 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349089 :UNCOMPRESSED-SHA256
    "5eead9fb788b42da7307c73569b7862a89ed8365e7e046791129154b1e79ccd4"
    :COMPRESSED-BYTES 111375 :COMPRESSED-SHA256
    "ebc9008ee9b5734625fec37694f677a68afe5919475a9eb1d2abfbedcfae9084"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-integrity/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349076 :STORED-BYTES 111680 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349076 :UNCOMPRESSED-SHA256
    "5eda399476aa4ec238dfb2558f726bdb672769e560b6b997d78751c60d206d0b"
    :COMPRESSED-BYTES 111364 :COMPRESSED-SHA256
    "c0ef955ac14a62ff683e59d0267303e1d521169a3bf0d090ad1fa4f042e71983"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/10-1U6ZVQE-MKV-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4640 :STORED-BYTES 428 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 4640 :UNCOMPRESSED-SHA256
    "79fe523f42dbcb1f7ea027949e4e5fd992a6d529fca0f6fc2fc03739f0eae0fa"
    :COMPRESSED-BYTES 104 :COMPRESSED-SHA256
    "577e1a3645dd1dddfc9b84df68bc2699fbd09225a8709de8a8b83ee2ec8618e8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/15-1U6ZVQG-MKV-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 9280 :STORED-BYTES 445 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 9280 :UNCOMPRESSED-SHA256
    "a7ecb4beb06c7fa0e885c3d78fcdb50e2394c82d36cc4d24a8797aa2ca160e7f"
    :COMPRESSED-BYTES 121 :COMPRESSED-SHA256
    "2e665636ac1b5f9130d85939bfc8714d231b0c5d6d43668454d90f822b41d252"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/20-1U6ZVQI-MKV-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 18560 :STORED-BYTES 473 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 18560
    :UNCOMPRESSED-SHA256
    "33de2f021ec2f0119e83ca334566dbcccfe2e809e0caf9cfeb6d01c3145743da"
    :COMPRESSED-BYTES 148 :COMPRESSED-SHA256
    "31c7bb0bb6448de6bd423c44040433d4d749904d3d79ebc357b815fbef6377cf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/25-1U6ZVQK-MKV-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "9742cbda060a09df4a0fe9454948571886d882357bbad7b75cbf97681e50e46f"
    :COMPRESSED-BYTES 94 :COMPRESSED-SHA256
    "158ca6098d4e2dbd966ecd1ec3acca6c6367a0fb7b9bdf2de97174d9faef31e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/30-1U6ZVQM-MKV-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4640 :STORED-BYTES 428 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 4640 :UNCOMPRESSED-SHA256
    "79fe523f42dbcb1f7ea027949e4e5fd992a6d529fca0f6fc2fc03739f0eae0fa"
    :COMPRESSED-BYTES 104 :COMPRESSED-SHA256
    "577e1a3645dd1dddfc9b84df68bc2699fbd09225a8709de8a8b83ee2ec8618e8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/35-1U6ZVQN-MKV-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 9280 :STORED-BYTES 445 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 9280 :UNCOMPRESSED-SHA256
    "a7ecb4beb06c7fa0e885c3d78fcdb50e2394c82d36cc4d24a8797aa2ca160e7f"
    :COMPRESSED-BYTES 121 :COMPRESSED-SHA256
    "2e665636ac1b5f9130d85939bfc8714d231b0c5d6d43668454d90f822b41d252"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/40-1U6ZVQP-MKV-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 18560 :STORED-BYTES 473 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 18560
    :UNCOMPRESSED-SHA256
    "33de2f021ec2f0119e83ca334566dbcccfe2e809e0caf9cfeb6d01c3145743da"
    :COMPRESSED-BYTES 148 :COMPRESSED-SHA256
    "31c7bb0bb6448de6bd423c44040433d4d749904d3d79ebc357b815fbef6377cf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/45-1U6ZVQS-MKV-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "9742cbda060a09df4a0fe9454948571886d882357bbad7b75cbf97681e50e46f"
    :COMPRESSED-BYTES 94 :COMPRESSED-SHA256
    "158ca6098d4e2dbd966ecd1ec3acca6c6367a0fb7b9bdf2de97174d9faef31e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/5-1U6ZVQD-MKV-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "9742cbda060a09df4a0fe9454948571886d882357bbad7b75cbf97681e50e46f"
    :COMPRESSED-BYTES 94 :COMPRESSED-SHA256
    "158ca6098d4e2dbd966ecd1ec3acca6c6367a0fb7b9bdf2de97174d9faef31e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/50-1U6ZVQT-MKV-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4640 :STORED-BYTES 428 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 4640 :UNCOMPRESSED-SHA256
    "79fe523f42dbcb1f7ea027949e4e5fd992a6d529fca0f6fc2fc03739f0eae0fa"
    :COMPRESSED-BYTES 104 :COMPRESSED-SHA256
    "577e1a3645dd1dddfc9b84df68bc2699fbd09225a8709de8a8b83ee2ec8618e8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/55-1U6ZVQV-MKV-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 9280 :STORED-BYTES 445 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 9280 :UNCOMPRESSED-SHA256
    "a7ecb4beb06c7fa0e885c3d78fcdb50e2394c82d36cc4d24a8797aa2ca160e7f"
    :COMPRESSED-BYTES 121 :COMPRESSED-SHA256
    "2e665636ac1b5f9130d85939bfc8714d231b0c5d6d43668454d90f822b41d252"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/60-1U6ZVQW-MKV-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 18560 :STORED-BYTES 473 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 18560
    :UNCOMPRESSED-SHA256
    "33de2f021ec2f0119e83ca334566dbcccfe2e809e0caf9cfeb6d01c3145743da"
    :COMPRESSED-BYTES 148 :COMPRESSED-SHA256
    "31c7bb0bb6448de6bd423c44040433d4d749904d3d79ebc357b815fbef6377cf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/65-1U6ZVQZ-MKV-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "9742cbda060a09df4a0fe9454948571886d882357bbad7b75cbf97681e50e46f"
    :COMPRESSED-BYTES 94 :COMPRESSED-SHA256
    "158ca6098d4e2dbd966ecd1ec3acca6c6367a0fb7b9bdf2de97174d9faef31e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/70-1U6ZVR0-MKV-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 4640 :STORED-BYTES 428 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 4640 :UNCOMPRESSED-SHA256
    "79fe523f42dbcb1f7ea027949e4e5fd992a6d529fca0f6fc2fc03739f0eae0fa"
    :COMPRESSED-BYTES 104 :COMPRESSED-SHA256
    "577e1a3645dd1dddfc9b84df68bc2699fbd09225a8709de8a8b83ee2ec8618e8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/75-1U6ZVR2-MKV-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 9280 :STORED-BYTES 445 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 9280 :UNCOMPRESSED-SHA256
    "a7ecb4beb06c7fa0e885c3d78fcdb50e2394c82d36cc4d24a8797aa2ca160e7f"
    :COMPRESSED-BYTES 121 :COMPRESSED-SHA256
    "2e665636ac1b5f9130d85939bfc8714d231b0c5d6d43668454d90f822b41d252"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline-logs/2.6.9/80-1U6ZVR4-MKV-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 18560 :STORED-BYTES 473 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 18560
    :UNCOMPRESSED-SHA256
    "33de2f021ec2f0119e83ca334566dbcccfe2e809e0caf9cfeb6d01c3145743da"
    :COMPRESSED-BYTES 148 :COMPRESSED-SHA256
    "31c7bb0bb6448de6bd423c44040433d4d749904d3d79ebc357b815fbef6377cf"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/baseline/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 377757 :STORED-BYTES 113021 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 377757 :UNCOMPRESSED-SHA256
    "4bc22c8eb3daeec1356841faf6fe692d07ea5724a4988353899cde389d50b522"
    :COMPRESSED-BYTES 112705 :COMPRESSED-SHA256
    "fa906f0ff0b5abbfb61b59b3b71deba2d94b9122060e9abd2fef32f2ea7be474"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/benchmark-2.6.10/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 380783 :STORED-BYTES 113748 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 380783 :UNCOMPRESSED-SHA256
    "80ff74b1ef0488f8ec7d09c3297e6e54d755ff01677055b40a308e4c0fb2983c"
    :COMPRESSED-BYTES 113432 :COMPRESSED-SHA256
    "7b89254472889d868ad4e1d3957aea74cca5292f805c3fa0ff9f04a1365c6d66"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/benchmark-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349247 :STORED-BYTES 111686 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349247 :UNCOMPRESSED-SHA256
    "7418364b6cf265a45680f63be149beb1e365c7dbf6aa477c67f0a5266d24293a"
    :COMPRESSED-BYTES 111370 :COMPRESSED-SHA256
    "b1c24ae15d1cac47a1629371a86a951da5ad93d0ec15bc75569ed53dcf887ff5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/benchmark/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 380775 :STORED-BYTES 113775 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 380775 :UNCOMPRESSED-SHA256
    "fbe40c6540f9436925acd106391611d6784bb47d970f34eb0747b688fe60612c"
    :COMPRESSED-BYTES 113459 :COMPRESSED-SHA256
    "046d348da18af98e8295cf8ec712fd205f5881a66c8af86d9d2a49008c01f57d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/boundaries/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349428 :STORED-BYTES 111903 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349428 :UNCOMPRESSED-SHA256
    "8cfd624f583a45f921c44b9e0802d083f47b767a3d50f9769d91243712326725"
    :COMPRESSED-BYTES 111587 :COMPRESSED-SHA256
    "940d1217320d4ac743269d2f9930846dce3cfccdd07851004d3b809ce8b52469"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/ci-self-test-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349729 :STORED-BYTES 111860 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349729 :UNCOMPRESSED-SHA256
    "8a3f66c54a11379e4928ba871247fbba206f68f377b15f035919424e197d5078"
    :COMPRESSED-BYTES 111544 :COMPRESSED-SHA256
    "44c286598fc0108a2952814f9de83bef9288b9716ef78e5cf659bf39eab95ab1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/current-source-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349080 :STORED-BYTES 111684 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349080 :UNCOMPRESSED-SHA256
    "6ce4a551e52a4329d569aed601aeeb5a01f2ab6b0cfa1d3e29e248fe42006976"
    :COMPRESSED-BYTES 111368 :COMPRESSED-SHA256
    "d07d503cbda4cac65c183aa8ef506606d00cac5b9438d5065fd531de2bd79aff"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/development-core/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 357100 :STORED-BYTES 113956 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 357100 :UNCOMPRESSED-SHA256
    "d9b332d1623b57783e0f7375c50dad6446a6829473c40df8e35f9584ef7bb0d3"
    :COMPRESSED-BYTES 113640 :COMPRESSED-SHA256
    "9bdacad531a1e41d48867e07743117f7c47bae9b1101202732755ad326c89f19"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/development-get-wrapper-asdf/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 376363 :STORED-BYTES 115233 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 376363 :UNCOMPRESSED-SHA256
    "bc1b349e0340abde194133f6d35f23700c33282a5019cbfcfbdd61d57dbe0220"
    :COMPRESSED-BYTES 114917 :COMPRESSED-SHA256
    "7bfce7b51e1f677586740023b2c6f58f3cf4451a89ecffa291275b973a190b7f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/development-processes/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 379059 :STORED-BYTES 115519 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 379059 :UNCOMPRESSED-SHA256
    "c85eaf31754fd15449696d63623d89becde186a35e46034f8422f6afd0a6f466"
    :COMPRESSED-BYTES 115203 :COMPRESSED-SHA256
    "993e50b0ee7abe2b1f7941330c9b28c86cf494fc2c3c6edbe0e54305c62de0f4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/documentation/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 355168 :STORED-BYTES 113069 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 355168 :UNCOMPRESSED-SHA256
    "948aaddcca45f7d431100857e82fe4eab9cdfa7a75d7b0b8a6662f693e171b43"
    :COMPRESSED-BYTES 112753 :COMPRESSED-SHA256
    "12a4c705b234c239ca9516a8ef1a560b761e07e6a94b759f085c738daefbb605"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349240 :STORED-BYTES 111688 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349240 :UNCOMPRESSED-SHA256
    "be65b79116fad96f588098ce1f99bf19c66c90293458450b20971b6fc078325b"
    :COMPRESSED-BYTES 111372 :COMPRESSED-SHA256
    "0a89dd3400460136b5735e8f99048506a52cced0b6100a6331f5bd02b5205e1a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-checks/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349087 :STORED-BYTES 111704 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349087 :UNCOMPRESSED-SHA256
    "560f4e43b73f65a1fd59e94e17fc12397303a4bb747cbd6afb7cb17c960a22f2"
    :COMPRESSED-BYTES 111388 :COMPRESSED-SHA256
    "15f5890880a7c49261752ac0dbb1ddf1ff0fb3fd603536798de699e73a92e37e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/10-1U6ZYHN-1NTX-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "cc55ac926a2cb532a5bfade59b1262b101a41ad3b7a13545ba7bdec4ab7f583b"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "51f164cbec62197a63a78084707980bca0601514e258678b640bc1e3d890a2c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/15-1U6ZYHP-1NTX-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "14fe7ecffebb1656e8285650925cbcf8f47aeee7adf8b67db95df1d7d85fb3da"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "b9483518b0e7d3f591d47460d170579f5204ff195373d4b9f681d28929738e12"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/20-1U6ZYHQ-1NTX-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "c9bc4ce1025f129c1e1fef51e00dab25bc515fa70579cdf7c8890e74d180f902"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "1bf76122082e9f64a5a72579bae88dd5f1ae76bcdc6bcb2731486bb7e6a0f5fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/25-1U6ZYHR-1NTX-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "9742cbda060a09df4a0fe9454948571886d882357bbad7b75cbf97681e50e46f"
    :COMPRESSED-BYTES 94 :COMPRESSED-SHA256
    "158ca6098d4e2dbd966ecd1ec3acca6c6367a0fb7b9bdf2de97174d9faef31e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/30-1U6ZYHT-1NTX-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "cc55ac926a2cb532a5bfade59b1262b101a41ad3b7a13545ba7bdec4ab7f583b"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "51f164cbec62197a63a78084707980bca0601514e258678b640bc1e3d890a2c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/35-1U6ZYHU-1NTX-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "14fe7ecffebb1656e8285650925cbcf8f47aeee7adf8b67db95df1d7d85fb3da"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "b9483518b0e7d3f591d47460d170579f5204ff195373d4b9f681d28929738e12"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/40-1U6ZYHW-1NTX-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "c9bc4ce1025f129c1e1fef51e00dab25bc515fa70579cdf7c8890e74d180f902"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "1bf76122082e9f64a5a72579bae88dd5f1ae76bcdc6bcb2731486bb7e6a0f5fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/45-1U6ZYHX-1NTX-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "9742cbda060a09df4a0fe9454948571886d882357bbad7b75cbf97681e50e46f"
    :COMPRESSED-BYTES 94 :COMPRESSED-SHA256
    "158ca6098d4e2dbd966ecd1ec3acca6c6367a0fb7b9bdf2de97174d9faef31e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/5-1U6ZYHM-1NTX-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "9742cbda060a09df4a0fe9454948571886d882357bbad7b75cbf97681e50e46f"
    :COMPRESSED-BYTES 94 :COMPRESSED-SHA256
    "158ca6098d4e2dbd966ecd1ec3acca6c6367a0fb7b9bdf2de97174d9faef31e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/50-1U6ZYHZ-1NTX-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "cc55ac926a2cb532a5bfade59b1262b101a41ad3b7a13545ba7bdec4ab7f583b"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "51f164cbec62197a63a78084707980bca0601514e258678b640bc1e3d890a2c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/55-1U6ZYI0-1NTX-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "14fe7ecffebb1656e8285650925cbcf8f47aeee7adf8b67db95df1d7d85fb3da"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "b9483518b0e7d3f591d47460d170579f5204ff195373d4b9f681d28929738e12"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/60-1U6ZYI1-1NTX-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "c9bc4ce1025f129c1e1fef51e00dab25bc515fa70579cdf7c8890e74d180f902"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "1bf76122082e9f64a5a72579bae88dd5f1ae76bcdc6bcb2731486bb7e6a0f5fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/65-1U6ZYI3-1NTX-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "9742cbda060a09df4a0fe9454948571886d882357bbad7b75cbf97681e50e46f"
    :COMPRESSED-BYTES 94 :COMPRESSED-SHA256
    "158ca6098d4e2dbd966ecd1ec3acca6c6367a0fb7b9bdf2de97174d9faef31e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/70-1U6ZYI4-1NTX-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "cc55ac926a2cb532a5bfade59b1262b101a41ad3b7a13545ba7bdec4ab7f583b"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "51f164cbec62197a63a78084707980bca0601514e258678b640bc1e3d890a2c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/75-1U6ZYI6-1NTX-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "14fe7ecffebb1656e8285650925cbcf8f47aeee7adf8b67db95df1d7d85fb3da"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "b9483518b0e7d3f591d47460d170579f5204ff195373d4b9f681d28929738e12"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.10/80-1U6ZYI7-1NTX-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "c9bc4ce1025f129c1e1fef51e00dab25bc515fa70579cdf7c8890e74d180f902"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "1bf76122082e9f64a5a72579bae88dd5f1ae76bcdc6bcb2731486bb7e6a0f5fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/10-1U6ZYEV-1MS5-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "cc55ac926a2cb532a5bfade59b1262b101a41ad3b7a13545ba7bdec4ab7f583b"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "51f164cbec62197a63a78084707980bca0601514e258678b640bc1e3d890a2c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/15-1U6ZYEX-1MS5-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "14fe7ecffebb1656e8285650925cbcf8f47aeee7adf8b67db95df1d7d85fb3da"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "b9483518b0e7d3f591d47460d170579f5204ff195373d4b9f681d28929738e12"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/20-1U6ZYEZ-1MS5-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "c9bc4ce1025f129c1e1fef51e00dab25bc515fa70579cdf7c8890e74d180f902"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "1bf76122082e9f64a5a72579bae88dd5f1ae76bcdc6bcb2731486bb7e6a0f5fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/25-1U6ZYF0-1MS5-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "9742cbda060a09df4a0fe9454948571886d882357bbad7b75cbf97681e50e46f"
    :COMPRESSED-BYTES 94 :COMPRESSED-SHA256
    "158ca6098d4e2dbd966ecd1ec3acca6c6367a0fb7b9bdf2de97174d9faef31e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/30-1U6ZYF1-1MS5-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "cc55ac926a2cb532a5bfade59b1262b101a41ad3b7a13545ba7bdec4ab7f583b"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "51f164cbec62197a63a78084707980bca0601514e258678b640bc1e3d890a2c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/35-1U6ZYF3-1MS5-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "14fe7ecffebb1656e8285650925cbcf8f47aeee7adf8b67db95df1d7d85fb3da"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "b9483518b0e7d3f591d47460d170579f5204ff195373d4b9f681d28929738e12"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/40-1U6ZYF4-1MS5-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "c9bc4ce1025f129c1e1fef51e00dab25bc515fa70579cdf7c8890e74d180f902"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "1bf76122082e9f64a5a72579bae88dd5f1ae76bcdc6bcb2731486bb7e6a0f5fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/45-1U6ZYF6-1MS5-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "9742cbda060a09df4a0fe9454948571886d882357bbad7b75cbf97681e50e46f"
    :COMPRESSED-BYTES 94 :COMPRESSED-SHA256
    "158ca6098d4e2dbd966ecd1ec3acca6c6367a0fb7b9bdf2de97174d9faef31e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/5-1U6ZYEU-1MS5-0/001-v1-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v1-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "9742cbda060a09df4a0fe9454948571886d882357bbad7b75cbf97681e50e46f"
    :COMPRESSED-BYTES 94 :COMPRESSED-SHA256
    "158ca6098d4e2dbd966ecd1ec3acca6c6367a0fb7b9bdf2de97174d9faef31e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/50-1U6ZYF7-1MS5-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "cc55ac926a2cb532a5bfade59b1262b101a41ad3b7a13545ba7bdec4ab7f583b"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "51f164cbec62197a63a78084707980bca0601514e258678b640bc1e3d890a2c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/55-1U6ZYF8-1MS5-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "14fe7ecffebb1656e8285650925cbcf8f47aeee7adf8b67db95df1d7d85fb3da"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "b9483518b0e7d3f591d47460d170579f5204ff195373d4b9f681d28929738e12"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/60-1U6ZYFA-1MS5-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "c9bc4ce1025f129c1e1fef51e00dab25bc515fa70579cdf7c8890e74d180f902"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "1bf76122082e9f64a5a72579bae88dd5f1ae76bcdc6bcb2731486bb7e6a0f5fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/65-1U6ZYFB-1MS5-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "9742cbda060a09df4a0fe9454948571886d882357bbad7b75cbf97681e50e46f"
    :COMPRESSED-BYTES 94 :COMPRESSED-SHA256
    "158ca6098d4e2dbd966ecd1ec3acca6c6367a0fb7b9bdf2de97174d9faef31e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/70-1U6ZYFD-1MS5-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "cc55ac926a2cb532a5bfade59b1262b101a41ad3b7a13545ba7bdec4ab7f583b"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "51f164cbec62197a63a78084707980bca0601514e258678b640bc1e3d890a2c3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/75-1U6ZYFE-1MS5-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "14fe7ecffebb1656e8285650925cbcf8f47aeee7adf8b67db95df1d7d85fb3da"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "b9483518b0e7d3f591d47460d170579f5204ff195373d4b9f681d28929738e12"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/final-logs/2.6.9/80-1U6ZYFF-1MS5-0/001-v2-server-710.stderr"
   :STATUS :OK :ORIGINAL-BYTES 2320 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "001-v2-server-710.stderr.gz" :UNCOMPRESSED-BYTES 2320 :UNCOMPRESSED-SHA256
    "c9bc4ce1025f129c1e1fef51e00dab25bc515fa70579cdf7c8890e74d180f902"
    :COMPRESSED-BYTES 95 :COMPRESSED-SHA256
    "1bf76122082e9f64a5a72579bae88dd5f1ae76bcdc6bcb2731486bb7e6a0f5fd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/focused/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 379548 :STORED-BYTES 115654 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 379548 :UNCOMPRESSED-SHA256
    "29a0559a10a6561fa24812608fa7835fb6ccf2d04f3999536540e38ea2c3d4df"
    :COMPRESSED-BYTES 115338 :COMPRESSED-SHA256
    "c9b2c615ca25019f9f9d141611918868bb8f03054fa18a3d46128aa8aa458df0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-analysis-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349697 :STORED-BYTES 111930 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349697 :UNCOMPRESSED-SHA256
    "11b59e95ea0b44eb149232e84816f361ffada340c017f356e7a33663fa028f0f"
    :COMPRESSED-BYTES 111614 :COMPRESSED-SHA256
    "3080d0dbd11aee79052bbbeab03dec4f33efe58eccf2e49a16c894a6958ac3ee"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-analyzer-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349090 :STORED-BYTES 111689 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349090 :UNCOMPRESSED-SHA256
    "1bb98109c270a36229730dbd0390c2d9b535eb838f576075ddc7379613504808"
    :COMPRESSED-BYTES 111373 :COMPRESSED-SHA256
    "801211edb229a926a61e37fa5fe020da8e43873b15c5d6d05c429abee4ba57ed"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-benchmark/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 539620 :STORED-BYTES 156008 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 539620 :UNCOMPRESSED-SHA256
    "f5e2d0709a9615f67438d96af86145d723ecdd49de4509717acd49d1bf050771"
    :COMPRESSED-BYTES 155692 :COMPRESSED-SHA256
    "6e59a7b75469635adcf7e90fd2c8efc19aa000c38387f1fc4b9f6afc5869030b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-repeat-analysis-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349708 :STORED-BYTES 111936 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349708 :UNCOMPRESSED-SHA256
    "afd14a5110566c8b158b7b7a08ff35f92885ca83d994db52683c67028b046a2d"
    :COMPRESSED-BYTES 111620 :COMPRESSED-SHA256
    "438d7efd4034e6a7bb376649bd11f124a6e20f082b234f36bdb9826804e81383"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-repeat-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349248 :STORED-BYTES 111684 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349248 :UNCOMPRESSED-SHA256
    "d0838b59b6a87ac6a5e5d841a5463695bf14595b9a1f201bda8633e8c599fa22"
    :COMPRESSED-BYTES 111368 :COMPRESSED-SHA256
    "b7dd87f9bd9c80392138890f5b3dbb563735a00b07c4466929662037419340ce"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-repeat/get-benchmark/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 539632 :STORED-BYTES 149748 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 539632 :UNCOMPRESSED-SHA256
    "1bf1a5108db1fb0f766030786d7f35ef5ab4525e15b6ae2a06a3e0a8dca45bdd"
    :COMPRESSED-BYTES 149432 :COMPRESSED-SHA256
    "e86bc999b38df7cef0ad245ad1cb87d7136ce58640b1ba83bfb2654b830c385c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/get-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 352634 :STORED-BYTES 112685 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 352634 :UNCOMPRESSED-SHA256
    "2b6fbfa84fc51265201e8819175c9b512877a8086ceda12856821f8ea0bde689"
    :COMPRESSED-BYTES 112369 :COMPRESSED-SHA256
    "24d389154d81d2745e2c4602036c44d6ebf5f88764ddd804e38f741fb4b10d69"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/identity-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349083 :STORED-BYTES 111689 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349083 :UNCOMPRESSED-SHA256
    "31be6733921104bf213257ece0ca47df04029ef6432aaa3d38e94f28246ccd2f"
    :COMPRESSED-BYTES 111373 :COMPRESSED-SHA256
    "ff7a1116e88370b98c086426f957822e8d8f19233467a2a9247a60687f3e78f2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/identity-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349082 :STORED-BYTES 111685 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349082 :UNCOMPRESSED-SHA256
    "d3f323b5ccec4cf43b0abbbeafa6cda76aab9c73d7e3a48ab1350458324e9261"
    :COMPRESSED-BYTES 111369 :COMPRESSED-SHA256
    "531256af0e074be5a4edb8dda63964f24a6e0f45c85f92be912221e07af404f0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/initial-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349242 :STORED-BYTES 111690 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349242 :UNCOMPRESSED-SHA256
    "0be1102a3e1a778c38c7722e5b08d2bd072c28f72c829c86d6580f484ba9ab5a"
    :COMPRESSED-BYTES 111374 :COMPRESSED-SHA256
    "7ac6dcb9c52024578331087f7fdbeb0c866d9ab1624624b5ce86897a9af8a96e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-conditional-groups/qualification-summary-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349054 :STORED-BYTES 111680 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349054 :UNCOMPRESSED-SHA256
    "676219e07962c89728a0cc6c411f5dce94c5f4d39b3b6b533d4e1fc4661e6fb8"
    :COMPRESSED-BYTES 111364 :COMPRESSED-SHA256
    "8cc07b2c08bc0ce5ac0135b640564f35616a2f257f09daeabd3696d039058312")))
 :VERIFIED-FILES 173 :HASH-METHOD :STORED-BYTES-OR-VERIFIED-LOSSLESS-EXPANSION
 :LIMITS
 (:NEGATIVE-SELF-TEST-FIXTURE-TREES-EXCLUDED
  :NO-QUALIFICATION-INFERENCE-FROM-EXIT-CODE-ALONE))
