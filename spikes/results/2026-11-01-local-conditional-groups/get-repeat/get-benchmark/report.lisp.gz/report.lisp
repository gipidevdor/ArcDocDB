(:SOURCE-CONSISTENCY :STABLE :SOURCE-BLOBS-AFTER
 ((:PATH ".gitattributes" :GIT-BLOB "d22cbb201cb1d3384baa7e8422aa9d6ee8aea1f9")
  (:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "4ed9445eb02f439a3c781878622809125ed924e6")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "711b96fd6fb677d15473213023c40c35affb47c0")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "ea5cf67447809b2e413026d50e2f61609cb9e438")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "80da41aac60230141d5d2d0819c9b6c2c3b3ce91")
  (:PATH ".github/ci-toolchain.lock.lisp" :GIT-BLOB
   "c01b06c5b208014ab30bb000dc10acfc9e72cc89")
  (:PATH ".github/workflows/ci-results.yml" :GIT-BLOB
   "d5029660830b7dbef56d6648bbf0a9bbaa400c56")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "49fc8ba897e94dc36c31d973e6e12efeab51b715")
  (:PATH ".github/workflows/docs.yml" :GIT-BLOB
   "6eef2de086d133233892870f80f5771f90ab1676")
  (:PATH ".gitignore" :GIT-BLOB "a3a191b534821cfe86f062a09dbc2cb19ba153bf")
  (:PATH "CHANGELOG.md" :GIT-BLOB "465c726575f999f8d0a7965562735da3475f7299")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bc7dba35611947cb7c1e9fb898e294b00f9f2de1")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "20743e1dd5a32d14e0af066e27987eaa16c94964")
  (:PATH "README.md" :GIT-BLOB "9e6430d753813af59152d82a3959a45d70abfa94")
  (:PATH "SECURITY.md" :GIT-BLOB "331a1316c300159882e3a30f9f2c8575a8e586a9")
  (:PATH "THIRD-PARTY-NOTICES.txt" :GIT-BLOB
   "0c5bc85db048fb8970c3cc42fb128337eff77e39")
  (:PATH "arcdocdb.asd" :GIT-BLOB "f0f8de2af5e37d6a1e1b64ba7a98ac7091963722")
  (:PATH "assets/README.md" :GIT-BLOB
   "c30d58ba88d9dd9f146df6f03aeedbdea3df5c72")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "a024e50336c5d93b7619048432219020d84eb688")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "0bb1c4dcc1aef96287b5edf18db288467e37f9c1")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "data/unicode/18.0.0/CaseFolding.txt" :GIT-BLOB
   "9ee0a2dd654f6fa520cd932be19ac5c00ffacded")
  (:PATH "data/unicode/18.0.0/DerivedNormalizationProps.txt" :GIT-BLOB
   "32227e8f297e96f98954281d99c38839a7834d7c")
  (:PATH "data/unicode/18.0.0/LICENSE.txt" :GIT-BLOB
   "56da58912807030b451a4700687d5bd02c72d6ed")
  (:PATH "data/unicode/18.0.0/NormalizationTest.txt" :GIT-BLOB
   "730c1a013ac78f6a63118e670c72556d4f112eab")
  (:PATH "data/unicode/18.0.0/README.md" :GIT-BLOB
   "06ab2a1368779a5535c48e90a7e2fb77e44080c9")
  (:PATH "data/unicode/18.0.0/ReadMe.txt" :GIT-BLOB
   "aa18f7175c4a46df644c7c6435ad95a8ad3cd724")
  (:PATH "data/unicode/18.0.0/UnicodeData.txt" :GIT-BLOB
   "ebccf021c4fcf31c2ecbb9bd7da3f5eb7ed44851")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakProperty.txt" :GIT-BLOB
   "313ae91aad579445a1e06556a1d7a2edd0c782a2")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakTest.txt" :GIT-BLOB
   "8d734a2690b9f06018e02b0b4f165acc4d0d2853")
  (:PATH "data/unicode/18.0.0/emoji/emoji-data.txt" :GIT-BLOB
   "7a383f0dcfd6ad65a2b7b5e90f701e38485f151f")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "a677288d5fd65a8de671c8cb513fef7c9cb013d5")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "0f68efcd275602bc60b1ee3a2a104f8a49bc6b80")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "1445703c53c2f1b82ced7dd78f34ad4ab8aae7d1")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "3c1c28fb8949660be6391180be187f55d14d5bb6")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "4c0ad12a7532b5d518b0581301f28a3601228d94")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "fce97d7d8c70a6c8f5425cd47ade5a2db5892a11")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "d3973b8d3cca6c9df25ab1c2e76c305bdc28c51b")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "85c9f51f242e4e5c3239edb58eea0a3ae0013011")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "5e10ff0c486bc5e08163bcd5df5bd5736de102f0")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "8720f145cca1d03da5446c5398ad4417a6243a18")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "30462b46bdd4dffdc7a8217adb6ec89571bf8b89")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "c05d0f0f5f69c9ddd9a85769c4bb11cc5a921c75")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "4ccdd9d66495ccff8d47d70ab80b04fa3bc601ca")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "b6a6a520f82271f96513a10457ad400c3f86f2bd")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "b75830dd78d106f8db76e65c08d4e8f3b2a488e4")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "d102ba1c248c77c71c437e46675cd5fc913fcdc5")
  (:PATH "docs/README.md" :GIT-BLOB "db925522d2e683e87137b5f3bca8d234cfe435bc")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "641a7c9e540ff2ec1136bcaa53c6558691578577")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "85d24f91157ac79e6af8c3ac908ca03921913922")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "9baef4c50046aca7c2d9740896af96a9dc5974f3")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "c949015de0fa3a2c25e597b523cb9a00409549b7")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "dd5d59a612a804976a08a475b0cce0de5daba1e3")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "49c294e438f29b383bc825210ba12f070f24a7a1")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "b56195d0f7f43e7bdb91a3af0d1a33f161b8d36e")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "26cb290c6bed61bf397cf4f9dbad7ca81d97e8b0")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "289e40fc2198e9295b90cddd5444d061cccdacfc")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "570458150a9f118174d72cbf90b0b13400237997")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "86c3d28f5a8ecdcf0dbbff34e5eeddf69bea5c48")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "3a490fbb3a23a5de59e08a86b5d656e559ec3696")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "c6b0803782b4595bce94f73f37bfb3de06ef58e3")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "811067eb4311ef4ed3c3b5450325345c04d444e4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "c863c2471e2f6e2b6bb0cb79f9c303dda902f572")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "5117c423e298e8aee4e02b2daea95cdfa6747784")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "813ecfb7741a73bbe4065c0914eab22495bbca3e")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "c5fc54a10372cec9bbf1fd3cbb436a6e835cd079")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "08a71d783f74d8dc0c02db312902f4256668d49d")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "085506a53a59d44f70b63f9f550df428a1f7c564")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "6399188b2711a8860f5895fb92dfabb34fa2dafa")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "13e62eb82f21f3b5490511d47823439541edba33")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "7785da60ce293bc328817518fbf2be3f9ab9a7b8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "57f594b6143b04e40bc3fea9394ebe938ca799ee")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "6b41728bd67274b11b1fde42cfb6ac2b71b0340b")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "0ec3e4cb8daeb741d6be9428099f1da284b0f895")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "50cded21f18bd019fc190b08edb348945d05829f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "e0e408989c0d8b1a8594a31a9f4cda888232b8c7")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "51ecdb8e1af48f87cd2e53d8c3c334b4a4dd7062")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "8589ad553a5b18f96e5dbab682a024f90b671c2e")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "138cf9abbe606df8f544a669069ed94844c9960f")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "c6ee53cf623ad6294ab2ab7e46ee16a3304dfdda")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "0af09ca66b38c35361d30ddbd028a0cb7fcac4e8")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "98cad23c9c529f3f83ccf02dc9bd1a4cb1e6f318")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "2d7ba68f4a56fa80700825d44f2b4335b4d342f4")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "5150eca7a1e85c342e20519179c0560e19c816c4")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "3aa06135165157067c6eaf64d8317a43d32086f6")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "b352146cf5138b099155a819a2c0c19780a31af7")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "05cc183bb8bd0b7b468a7225065c4dc75dd6cd33")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "452553489ad4b466a118e5ec3f08a79223ba7f69")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "7323f9c4e7d6a41ee0e8edbc7c21f6c40fae7258")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c12ccb4a82f5e97c40c2e2df05f085c28f9356af")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "c5ccb103deb265db77ca14be9e4fb60ebb7395f3")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "d0ce5bcc0bbfbf2fa92187bbd09d0ff320d54e69")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "a52656154964c4588477288a15fb10284ac888a4")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "d23b7ee9ef2e3e178a663dbfb004ccc8fed2c542")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2c0669b7a0226ff342e15158899a06d75a30abbc")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "5ba95841ff8f467ed496f51101ddd832dca4fab1")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "2787435e8647b4c1702b7fb4f35f40cd64197fa0")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "18cf324a65ccb0d7684d357bbb8eeb6aeed6a11a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "6754d79f26141153b55bbe1bcaa4a82825f95700")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "fd7e70d402194978a3ffdad705318afb0431f04e")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "2c3d966a83d6f5c1ba122e38ee510b5277a1e89e")
  (:PATH "docs/adr/0053-ricerca-full-text-indici-invertiti.md" :GIT-BLOB
   "ed37b13d26276ccec88bc4eb7e9259bc8ea270a0")
  (:PATH "docs/adr/0054-contratto-e-formato-full-text.md" :GIT-BLOB
   "239a1b5bbb0be77e0a60cb3f0360d8f4906d0b46")
  (:PATH "docs/adr/0055-interfaccia-locale-unix-socket.md" :GIT-BLOB
   "3a1a8acc98918b9eff3f9c319da1d089bd55bf1b")
  (:PATH "docs/adr/0056-sessione-locale-m16.md" :GIT-BLOB
   "09aa317be40281eb6dfeedfb16c27bf4ee227782")
  (:PATH "docs/adr/0057-selezione-automatica-indice.md" :GIT-BLOB
   "dd056fe207e34cc13582ef67686f5cef50da0d52")
  (:PATH "docs/adr/0058-pagine-indice-primario.md" :GIT-BLOB
   "aace2fae9377ecc39befa24f30a71fa3544aa82f")
  (:PATH "docs/adr/0059-crc32c-arm64-sbcl.md" :GIT-BLOB
   "8abf118f525ac8e4bfb3657e7b9c2389825e3734")
  (:PATH "docs/adr/0060-crc32c-caricamento-portabile.md" :GIT-BLOB
   "e525cdb37bc853b13c077a139869132a6c8a3296")
  (:PATH "docs/adr/0061-conservazione-esterna-delle-prove.md" :GIT-BLOB
   "f72ff61077518b492f247dde021f8ae8d5749777")
  (:PATH "docs/adr/0062-cronologia-git-due-commit.md" :GIT-BLOB
   "d17a19b8086aeb412bb8622fe8dc5301fd3265d0")
  (:PATH "docs/adr/0063-immagini-sigillate-indice-primario.md" :GIT-BLOB
   "6bf24e2c250857907d5d36e6ea7f2d93cf2dcf63")
  (:PATH "docs/adr/0064-adozione-indice-paginato-m1.md" :GIT-BLOB
   "8b4f945e8e06c194b517c1563c2a78fe1ddbd609")
  (:PATH "docs/adr/0065-costruzione-immagini-dal-motore.md" :GIT-BLOB
   "09314a89fa7875d648062095cfd24081055e34f5")
  (:PATH "docs/adr/0066-attivazione-seriale-immagini-m1.md" :GIT-BLOB
   "ca6fd5d38685053ceb12922973a932f72fce5fd8")
  (:PATH "docs/adr/0067-delta-seriale-indice-m1.md" :GIT-BLOB
   "03ea9916428820920370aaeef7c422b0478d3b4e")
  (:PATH "docs/adr/0068-rinnovo-seriale-immagini-m1.md" :GIT-BLOB
   "2240c84c7e57c86d33df08772b173cc9d0d11aba")
  (:PATH "docs/adr/0069-manutenzione-a-soglie-delta-m1.md" :GIT-BLOB
   "7433e9b73ae1548f198181002505a8aabec65ceb")
  (:PATH "docs/adr/0070-scoperta-readonly-immagini-m1.md" :GIT-BLOB
   "f4a496e4556b220282b4a962a57a723ad2ccbf50")
  (:PATH "docs/adr/0071-delta-location-indice-m1.md" :GIT-BLOB
   "5f06b390d2223e5e5e85f38f5de73cf1ad668f5f")
  (:PATH "docs/adr/0072-rinnovo-automatico-delta-m1.md" :GIT-BLOB
   "99ae69d3d9fa5d6d69f9cb5efede395fe33ae408")
  (:PATH "docs/adr/0073-indice-automatico-operativo-m1.md" :GIT-BLOB
   "8f7677e90411d564c161e07d5f46fe774e32384e")
  (:PATH "docs/adr/0074-crc32c-sbcl-2.6.10.md" :GIT-BLOB
   "0d32b3a9bfe16d3755cc163e1ec2ec09394ca598")
  (:PATH "docs/adr/0075-codex-documentation-toolchain.md" :GIT-BLOB
   "60f2fca9be7d793cffd1f13dc43a80365df700a5")
  (:PATH "docs/adr/0076-rotazione-live-m1.md" :GIT-BLOB
   "1da6f99e64dbce919e88440c8a4662d9abc9ba82")
  (:PATH "docs/adr/0077-source-derived-code-reference.md" :GIT-BLOB
   "100230816ee9e513dfc78ba3c57c992bef61eec5")
  (:PATH "docs/adr/0078-compattazione-prefix-m1.md" :GIT-BLOB
   "89e9e72b6eb4aaf2a0fd494de6a72a33810a52b0")
  (:PATH "docs/adr/0079-cache-record-m1.md" :GIT-BLOB
   "114135347b465d247f7e05b091858c9791f88382")
  (:PATH "docs/adr/0080-group-commit-m1.md" :GIT-BLOB
   "86b89a39cfe8faa863e350dade7d77f9540364fb")
  (:PATH "docs/adr/0081-active-append-metadata.md" :GIT-BLOB
   "19b160c27564b5682637adc98ed39e1b47255f2d")
  (:PATH "docs/adr/0082-bounded-group-append.md" :GIT-BLOB
   "9d0be5661c2df788d2f3c1f2d1f03330011eb78e")
  (:PATH "docs/adr/0083-explicit-unix-write-groups.md" :GIT-BLOB
   "fbca2463c1168aabadea5dcaae48fd1dbaeffcfe")
  (:PATH "docs/adr/0084-explicit-unix-read-groups.md" :GIT-BLOB
   "d5882e72757a731cd02d71f7ae97208b2cdffce0")
  (:PATH "docs/adr/0085-conditional-current-writes.md" :GIT-BLOB
   "9ccb72269093a95c3be1a665a9809c8130096f2d")
  (:PATH "docs/adr/0086-conditional-same-turn-group-commit.md" :GIT-BLOB
   "f3aad4767ed3f071173c4b9622c92fc27aaa8e7a")
  (:PATH "docs/adr/0087-explicit-conditional-unix-groups.md" :GIT-BLOB
   "57e069b05fc8de1120d5c981ddd3ad7c63ee2ade")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "71818ef6ff77d04a135202700c9f816d42670d18")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "da6af58f171fe105407b444a400905f554110ec9")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "09805b5022bf9b338522c4078feae7334825c50a")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "2b878e6c0b9ea5576635f16b1d9e7433c956458f")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "0b92053bbe5abc8b74a59472a0ddaad7be9ba399")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "35ce8a542e4e77ba28c497e4a33358f308708bd0")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "5729dba5379c1eaf1366302e6243fa5219f60cd0")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "2325e50c80180c368d7e13c9181bb6e6fd8ff831")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "5f74a1692a934ddc9425d91ff0cadbf842c95bb2")
  (:PATH "docs/code-reference.md" :GIT-BLOB
   "ce9a8a5a9a8ef8d58833bb239199bbd2e1f6019a")
  (:PATH "docs/editorial-policy.md" :GIT-BLOB
   "23c70f794c8640f050be6eda8d1f75fbeeb13540")
  (:PATH "docs/editorial-review.md" :GIT-BLOB
   "9264d1e4e9b0189d3b3f5a5f3c8cebe5f5d728ec")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "d83cff978b0e2c61bfbf1308e4fdcdbd38fb4ebf")
  (:PATH "docs/formato-indice-full-text.md" :GIT-BLOB
   "be3b1b6661023f58d985a26c07c15216cb099a66")
  (:PATH "docs/full-text.md" :GIT-BLOB
   "29a9ee662cd39c103edaaf046bc8b68731bd8df4")
  (:PATH "docs/github-pages.md" :GIT-BLOB
   "1d624b0c03aa60ee582ce4c98c83b38272c0dc75")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "8c460a969441f5be9d94766fff808f15d6d33f36")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "0c946fd449c68453ea89231234ec67431189414d")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "107b5346c1b34eea45a66cd902820bc8cc45e5f8")
  (:PATH "docs/implementazione/active-recovery-metodo.md" :GIT-BLOB
   "5724560732e14d6d374483aa71ca0f7802541df5")
  (:PATH "docs/implementazione/active-recuperato-metodo.md" :GIT-BLOB
   "32524af882ad0a043f6d939994c9a6a11769fef9")
  (:PATH "docs/implementazione/active-recuperato-verifica.md" :GIT-BLOB
   "23af8d8e23577a92d5c0e74884061cb56639d55d")
  (:PATH "docs/implementazione/active-recuperato.md" :GIT-BLOB
   "0b685aa69fd7c078994b5d1feaa4b5b93c1cafc8")
  (:PATH "docs/implementazione/adozione-closed-runtime.md" :GIT-BLOB
   "21630d85433210b2f061c422c931ef0f14ad0b61")
  (:PATH "docs/implementazione/adozione-controller-runtime.md" :GIT-BLOB
   "f2f7826b7eb58b681d334e29834ddd1cf09fed06")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "797a1998753834a3204075954c9cfe81a0f064d4")
  (:PATH "docs/implementazione/archivio-csn-revisione.md" :GIT-BLOB
   "c886079a0ad9f47ae864fbb63084960f897e55fa")
  (:PATH "docs/implementazione/archivio-csn-verifica.md" :GIT-BLOB
   "873f06c415107bac58d781df316e5b484222316a")
  (:PATH "docs/implementazione/associazione-file.md" :GIT-BLOB
   "02e39a32261a5a901ca45e15dcc7505819a969e0")
  (:PATH "docs/implementazione/attivazione-indice-m1.md" :GIT-BLOB
   "cd609a5e9645be680b23798e0bda841d8507d772")
  (:PATH "docs/implementazione/cache-pagine.md" :GIT-BLOB
   "1eaeb517c655d918d307d46423e4aee54f39290b")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "3dbae0d9e595f509621e6bf6dd3380a5ed844f1d")
  (:PATH "docs/implementazione/cbor-array-decisioni.md" :GIT-BLOB
   "948258bd302c1820210e439862d432d8c5554e9e")
  (:PATH "docs/implementazione/cbor-array-lettura.md" :GIT-BLOB
   "c419ecc31f9e905f4d053fd4473c8b605415dc4d")
  (:PATH "docs/implementazione/cbor-array-metodo.md" :GIT-BLOB
   "a5e53c22e391f72573f89c01f58ae28fa1c40376")
  (:PATH "docs/implementazione/cbor-array-revisione.md" :GIT-BLOB
   "f992654650b2fb08a59058b337fef63f901bf75c")
  (:PATH "docs/implementazione/cbor-array-risultati.md" :GIT-BLOB
   "e4c253fcfbe86fd2dfce2bd3354614a67f4b97f5")
  (:PATH "docs/implementazione/cbor-array.md" :GIT-BLOB
   "0f8fa2876a7366cd62bd1b8669251e2107b19b7d")
  (:PATH "docs/implementazione/cbor-float-scrittura-copertura.md" :GIT-BLOB
   "c1f596a69e83504ff3fd2c7cf569f234e1c6554b")
  (:PATH "docs/implementazione/cbor-float-scrittura-dati.md" :GIT-BLOB
   "618a4fdc1d5fbb230414931295ff0f7ef9367c84")
  (:PATH "docs/implementazione/cbor-float-scrittura-decisioni.md" :GIT-BLOB
   "cd76b3d2b02c6c021849b2b85d1a403d76e38f78")
  (:PATH "docs/implementazione/cbor-float-scrittura-lettura.md" :GIT-BLOB
   "11a065b51085a23f42df7ca75e315cbee0328e70")
  (:PATH "docs/implementazione/cbor-float-scrittura-metodo.md" :GIT-BLOB
   "6c046bb92cc291fb00914da89e0eefb705b4ae65")
  (:PATH "docs/implementazione/cbor-float-scrittura-revisione.md" :GIT-BLOB
   "870474964d88a8b4099bf00cc31c0b2bc542f94a")
  (:PATH "docs/implementazione/cbor-float-scrittura-risultati.md" :GIT-BLOB
   "84faa8d4bbf5150c4b9df17879b5dd0b39a286d4")
  (:PATH "docs/implementazione/cbor-float-scrittura.md" :GIT-BLOB
   "c14c7bbaebcd803c24f62adcda19259b16f00e52")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c7fe2a7bad385932a72141de4ae46f04bbd8ce18")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "dd7621ec9feea82adec89e00ed232b22d8aead35")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "4984c8c845da1437c212f47a7a345979df1c5acc")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "ba09a11d806999c55e0cb75f5b638d1fe2cb0476")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "29f9c13299d7b2fbcea64db535c0ec3fd4456f73")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "fb04b79a27ae65e2097c21ace50ee70f26bb0e8a")
  (:PATH "docs/implementazione/cbor-item-decisioni.md" :GIT-BLOB
   "800cefe6cf8f8a8000dad71d3807df7e7efdd210")
  (:PATH "docs/implementazione/cbor-item-lettura.md" :GIT-BLOB
   "57bcf4f8d1c40334c68d53ad2b4a2092e769d8d1")
  (:PATH "docs/implementazione/cbor-item-metodo.md" :GIT-BLOB
   "05b4a0d45c993c6bfebb0555098334f40db82f33")
  (:PATH "docs/implementazione/cbor-item-revisione.md" :GIT-BLOB
   "de0ef7bc19fe539d4aef7cdc1c1f5345b8002a94")
  (:PATH "docs/implementazione/cbor-item-risultati.md" :GIT-BLOB
   "8b02e00a9d43febf09b846d1bf6a01ebee2b3005")
  (:PATH "docs/implementazione/cbor-item.md" :GIT-BLOB
   "8548c091f11308380d4ac4e01ff884644b470281")
  (:PATH "docs/implementazione/cbor-map-decisioni.md" :GIT-BLOB
   "f44e789f6d2bf153580332fb136e46cb9e57194a")
  (:PATH "docs/implementazione/cbor-map-lettura.md" :GIT-BLOB
   "23a1f7f9653522ebf02619977dc2d74ed275f891")
  (:PATH "docs/implementazione/cbor-map-metodo.md" :GIT-BLOB
   "50ad5d1f64b5dbd37f4285306c5430789e0c581e")
  (:PATH "docs/implementazione/cbor-map-revisione.md" :GIT-BLOB
   "4f9c6c7a2e2eed16e73bbb314f5936182d371420")
  (:PATH "docs/implementazione/cbor-map-risultati.md" :GIT-BLOB
   "5322d5cdd93ea61e00830138091c72eadd5effe9")
  (:PATH "docs/implementazione/cbor-map.md" :GIT-BLOB
   "3f4f8e64c19f21958bcc913a1ee701cc55a18f06")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "998d3f4d69a4915bd3d5ac13381d89b15a22afaf")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "1c7b8bc426f5054aa88e7b2cf8ce1d0c339e112b")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "d34c7e0e8b9347228e9c3121358824f106d1e663")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "8beb9758140566348297f59d8a85a1c6816c70ae")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "464af7d4e2264a4c7e0336b2219a0e886cd04c2b")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "a0a4beb749f27b8fdd721492a338ff29acd18420")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "3ac17f24029e9c242146cd994a7b2b907ef8177d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "1a2a1bc130b5e3f343f110bd9ccca2de3486a19b")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "ef1defbeb7d0f2f52a289e03fa52b7922bd8fff2")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "980896a21ef91e13e4c3a4d414d72115eb27fee1")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "a0533ae26074d23c19b098bcf11d7f3959c3b609")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "c3bd5167d49e4e2bc59bff90b6e62e3435ed43b6")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "556fddff139cb8660db889b3b1cb39046972c01f")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "d0bb1a35f08dc97dcb4e03e70e521707c8a8d29c")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "05a927871e8257d31d40c727f88858cc10f3f5b3")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "7b606f5d5c44abd25a7cea635c2e3086f7b08d7a")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "0c3f81227199b06df304e9e3bcbc6c98660bacc8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "54852d32fb4a642db32067148adbf6d9fb22a066")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "ab773c5d9261846c39c09f6cf06566344acd4ff9")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "a3e52d83ef8dab364c1e290a003fbcac3e4703b5")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "943ce8b93716e53b1048dbb672ecb01ecf2ecf2c")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "3bc420d5c29b2005395fdbf72ba1fe12fa0feb20")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "12ed41add43b64cf9a0cf317dab6a09a0f6a8f5e")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "7299368dd4c077d8e620e6a3f6b91dde5cde96c3")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "ee75788591cf776a011eddef4384ce6c9b0c1cf8")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "b5e504a3508da8c72295f9fa7a18ba44a482b547")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e5b9990f00978da272fac6353b4706e9cdb3e80e")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "46f011d10fbd376c7387ffe48a9730a3a2620b05")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "d33e32c7e570f1958c8af75a789ea3a6583e4289")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "032c6c20aa5e116d2c1fa4214a0701e40620b966")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "77e0e458eb0cfbeb0796d176ff54805fcec9fc13")
  (:PATH "docs/implementazione/cbor-stringa-lettura-decisioni.md" :GIT-BLOB
   "a307a12444fd16df6ad92dcdf8717f02e76ac7a8")
  (:PATH "docs/implementazione/cbor-stringa-lettura-metodo.md" :GIT-BLOB
   "3378a194f4eded0fc1316be064956d77b3132fb3")
  (:PATH "docs/implementazione/cbor-stringa-lettura-prima-revisione.md"
   :GIT-BLOB "6fb1e3c3cd8a7512958b54095940826c30980eed")
  (:PATH "docs/implementazione/cbor-stringa-lettura-risultati.md" :GIT-BLOB
   "b50555a7cf2b592b5c36b2d094d7500225581f06")
  (:PATH "docs/implementazione/cbor-stringa-lettura-seconda-revisione.md"
   :GIT-BLOB "ebfc3d0bbdd1a19a295c55770a6d505ddbd4aa84")
  (:PATH "docs/implementazione/cbor-stringa-lettura.md" :GIT-BLOB
   "9eecb30c6b1887b9a0a5f5aabe3516916c3ba025")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "82f1683ba3774d33e82fd23e118790e401c11085")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "ff78a1940b29beef1c4e685e2084767c948f9da0")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "280b19d5e97d5487ba6be4f59da8b015063074bf")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "7ac03f1075bd778be47916ef9eef72e5bcdc90ff")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "08f016eb4a073cf59dbb3c5c9b23791d4a1285ef")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "c17e8ed2fb902df4c971d0300c1c7842dd46a764")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "16b04b9a5451b880ea2449104f65e261ba7f6c7d")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "66c94d76bdb2c46714ea86774489f31580ac63c9")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "d64b31030580f02466562e86efae7cc27451d0a2")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "16ffa1f24020338735660b5b008fb3e00c498ea4")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "39fa55a82334440ea17d53dbefe050d53db6a716")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "5e801a7632e7ce46f56e79cad2073b3e155eae99")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "c77993b00f09e89d21d2ab2eb319964e9e2fa819")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "2221900158acbbd5cdaa39d3301b08501c071e97")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "e29635a7ce3cd150ea0801c4610ddd03af941c8c")
  (:PATH "docs/implementazione/cbor-tag-decisioni.md" :GIT-BLOB
   "f0329ac5196815f633bf7abc82c97730cee832a5")
  (:PATH "docs/implementazione/cbor-tag-lettura.md" :GIT-BLOB
   "49146a982d1297edaf0c31daca7c5eb6150a6ea7")
  (:PATH "docs/implementazione/cbor-tag-metodo.md" :GIT-BLOB
   "ffa487840cb2e0964e7fa7a7cd55d57fbeed3de4")
  (:PATH "docs/implementazione/cbor-tag-revisione.md" :GIT-BLOB
   "b61c84f5f4a70f3009748536709d37c2609d89cd")
  (:PATH "docs/implementazione/cbor-tag-risultati.md" :GIT-BLOB
   "a78c3f04408c306f2cddcc617274f2335b17fc81")
  (:PATH "docs/implementazione/cbor-tag.md" :GIT-BLOB
   "a67789164c1ca9ab5be6435322ae77606314831f")
  (:PATH "docs/implementazione/checkpoint-control.md" :GIT-BLOB
   "2e2d90188ad3b3bec79f9a2c90e9f2cff58f3c42")
  (:PATH "docs/implementazione/checkpoint-recovery.md" :GIT-BLOB
   "fd1444d3e09f58457eb3babe639bc93634e32aa3")
  (:PATH "docs/implementazione/ci-provenienza-pr.md" :GIT-BLOB
   "cfe42a5fe0ebb52b0c1217926a15078d8baf4cea")
  (:PATH "docs/implementazione/ci-statistiche.md" :GIT-BLOB
   "6d6d3ad1d0381ab4bf946a6c1e7561f5266ad494")
  (:PATH "docs/implementazione/ci-wire-processi.md" :GIT-BLOB
   "537159570d4bdc8e7dbcddb5be3dd9e2d57c26eb")
  (:PATH "docs/implementazione/closed-recuperato-revisione.md" :GIT-BLOB
   "38373f1de3d42b5e9056e60d30f215083a80c845")
  (:PATH "docs/implementazione/closed-recuperato-verifica.md" :GIT-BLOB
   "1c4b3e4f0e6c3d3c4519dcdd56c7a2ca8ca2d47d")
  (:PATH "docs/implementazione/closed-recuperato.md" :GIT-BLOB
   "3675c4a21cd14e15f136f1bdcd6e0c64f28564bc")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "07c702f3b926311b7af6950382459286f20c9d05")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "7c9473c0d5149a7cefab4ef33076c7f44bfe9f30")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "2dd9f8ab7dbdc2df6a41874a63aa62f45fa11ba8")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "714da56672b38ed721a71f7d81986f66ca3915e6")
  (:PATH "docs/implementazione/control-recuperato.md" :GIT-BLOB
   "050723cbdec05ccf343e6cf651023dbba053fa60")
  (:PATH "docs/implementazione/control-transizione-metodo.md" :GIT-BLOB
   "4af36a8e4c9c409cccb82beacd9a7243057c2b76")
  (:PATH "docs/implementazione/control-verifica-metodo.md" :GIT-BLOB
   "8ffecd3625f0d1c3b4cf5786e17354cd170a127f")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4e75306fe31c84d552c342f4294894121d647097")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "4c8e017a2fc5e52b4a26d3f90c50d2e89f90e5f1")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "a294f643c70035056ce585a186fe4fb0ad1f01f3")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "6a48c794b8d8619e762c0c33108175d26dab2235")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "e3bc4006b2c53306af00f16d8967e002be5be7f2")
  (:PATH "docs/implementazione/controllore-pool-decisioni.md" :GIT-BLOB
   "e45a4a1609e6ad2c4a8c507a3b6474b34329fc7e")
  (:PATH "docs/implementazione/controllore-pool-metodo.md" :GIT-BLOB
   "9452ebefc6280a045c051c394e3ab55a9b5b7b90")
  (:PATH "docs/implementazione/controllore-pool-revisione-2.md" :GIT-BLOB
   "f4b54f7f20f0dbc620c95098dfe8f7d11e00eb84")
  (:PATH "docs/implementazione/controllore-pool-revisione.md" :GIT-BLOB
   "8331ccdab4e1957b7eaa4ff7404ab2ed263fa924")
  (:PATH "docs/implementazione/controllore-pool-risultati.md" :GIT-BLOB
   "e0738c5de4ceb793d70419ac8fece82e1de2359d")
  (:PATH "docs/implementazione/controllore-pool.md" :GIT-BLOB
   "32a0876c84705abfb03a324d93c0e09997e8caaf")
  (:PATH "docs/implementazione/costruzione-indice-m1.md" :GIT-BLOB
   "954e5c11aac01cdcdbbe1300ab7ad5904a31186f")
  (:PATH "docs/implementazione/costruzione-indice-paginato.md" :GIT-BLOB
   "6f4a25f0f4a8c5c5ef123b587f34313cf18493ae")
  (:PATH "docs/implementazione/crc32c-arm64-metodo.md" :GIT-BLOB
   "fd0a6f8b0203eb527434d5c85b5a21bffaa83842")
  (:PATH "docs/implementazione/crc32c-arm64.md" :GIT-BLOB
   "9d44dfe4836c393debf1e2fedd781ba8d64ac854")
  (:PATH "docs/implementazione/crc32c-piattaforme.md" :GIT-BLOB
   "c48393540f18a1982fa9523d82684488f2d0e9ed")
  (:PATH "docs/implementazione/crc32c-unroll32.md" :GIT-BLOB
   "f9b81bfbbfe41d6f0433df1275b14e0ddb277521")
  (:PATH "docs/implementazione/csn-archivio-recovery.md" :GIT-BLOB
   "0501c6e7d687db9aa0196637ea4ceb5032d398b9")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "f3c71d7a014741290c658cd958ca5d5b6e5076a7")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "6809b9ff79f77032c94c726a67913fd86ed590f4")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "87df34a5915fead7f06bff837dfa0b904f9eb664")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "ac014f8282cf46645dd18f92f16bff17ac1da0b4")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "3d69beb591d794d62111bb695cf87fc6c4726e2c")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "7979e6edd61ac9300d6560b493a61948a4fd0d92")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "62df2e33eb3daa289da2fd2d544db1e367495b76")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "2ab09dc900d919686bd211a1fc0c9e233d6d8bbe")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "26b8a34a0c455ffa1244cd8930718ad68067983d")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "475fcdde02949a8500168f29ab43891d70fe7fa9")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "7e01085ba74008ba3f3715415c7196de10efe61f")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "a2f17134ae38a241a5610af3f00051f0e1c6bca5")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "04724b6857c83e623ba245bef65c657f416bbced")
  (:PATH "docs/implementazione/decisioni-recuperate-revisione.md" :GIT-BLOB
   "e8ec567a22d4a0b7f365d7649622e9a3405e69e4")
  (:PATH "docs/implementazione/decisioni-recuperate-verifica.md" :GIT-BLOB
   "efae51de3ab17894525f9803c2caa2dab2caa737")
  (:PATH "docs/implementazione/decisioni-recuperate.md" :GIT-BLOB
   "877dab2bc85bec554965e906163a950fa7f42dbb")
  (:PATH "docs/implementazione/delta-indice-m1.md" :GIT-BLOB
   "74b4d0337972db90f897380d1acf29cf56b5387d")
  (:PATH "docs/implementazione/delta-location-m1-metodo.md" :GIT-BLOB
   "546cbb2eb9169663e412972c9ffa3dfdd7a44eb7")
  (:PATH "docs/implementazione/delta-location-m1.md" :GIT-BLOB
   "dd39d0fa56ef87edaac933052523fb1092af9891")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "23c6bd3464be1c5de0e85dd1ceef49cb072e2610")
  (:PATH "docs/implementazione/evidenze-parallele.md" :GIT-BLOB
   "c1cf798f1d7aa870e6fc08666fb089bd0078f1b2")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "9ce191f9a921d27dd12773f67b2ea9dc2b724c11")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "5988fea2f0c49b45d4da2152cd2f213f7d4a3bbe")
  (:PATH "docs/implementazione/fonti-recovery-metodo.md" :GIT-BLOB
   "71889d31dc82e1ce9cb80228debcd2aaae265ca3")
  (:PATH "docs/implementazione/fonti-recovery.md" :GIT-BLOB
   "b613cfd01ebf4f093fd8d5b4f6ea14c2c43b1156")
  (:PATH "docs/implementazione/full-text-codec-decisioni.md" :GIT-BLOB
   "d84b4a8ea730f7eb6a08f7578322a9cbab97cc27")
  (:PATH "docs/implementazione/full-text-codec.md" :GIT-BLOB
   "dd648030eb25834fe6d66bf6fb61fad777ef7906")
  (:PATH "docs/implementazione/full-text-decisioni.md" :GIT-BLOB
   "891a19e59ded15ce976428e647431e6087fcda8b")
  (:PATH "docs/implementazione/full-text-documenti-decisioni.md" :GIT-BLOB
   "6df6ad62e11ea8977a258a6e11e774488c131e97")
  (:PATH "docs/implementazione/full-text-documenti.md" :GIT-BLOB
   "813e65fa97477a4d4451c483e137540af95cd667")
  (:PATH "docs/implementazione/full-text-put-metodo.md" :GIT-BLOB
   "2526a07b957970e7abc7f6baae970c2162d9b68e")
  (:PATH "docs/implementazione/full-text-put.md" :GIT-BLOB
   "a480bcb65e37731737a70f16554ca9e5e8cf8ee0")
  (:PATH "docs/implementazione/full-text-riferimenti-metodo.md" :GIT-BLOB
   "0cb603ba80950501cb439b61b4645274188ec75d")
  (:PATH "docs/implementazione/full-text-riferimenti.md" :GIT-BLOB
   "d363ee6d5e8e55f35668fbb129c2cf1f626a6d16")
  (:PATH "docs/implementazione/full-text-righe-metodo.md" :GIT-BLOB
   "2f576876ff695c0b662b91f8deea5b3793c3bc5b")
  (:PATH "docs/implementazione/full-text-righe.md" :GIT-BLOB
   "c6b643c4cf20d6b4378f7bfe7f05132cd4ba1d10")
  (:PATH "docs/implementazione/full-text-riserve-metodo.md" :GIT-BLOB
   "17663cca4a20e28e53be920eaa83792b520354a4")
  (:PATH "docs/implementazione/full-text-riserve.md" :GIT-BLOB
   "154f11b6ffc05e72273d3ab4a0b7a5d3867ad3a7")
  (:PATH "docs/implementazione/full-text.md" :GIT-BLOB
   "10317557bc507e5b786a0564626bc3109e851c46")
  (:PATH "docs/implementazione/get-active-metodo.md" :GIT-BLOB
   "de07ae6a11977904595cd321e2fdfb229cb0bbc0")
  (:PATH "docs/implementazione/get-active-preflight-metodo.md" :GIT-BLOB
   "2557776ad0c8c99e3c479ebfd557b6c912dd503d")
  (:PATH "docs/implementazione/get-active-preflight-verifica.md" :GIT-BLOB
   "2616f8e780fbc697519bc3517591c54197bd37f5")
  (:PATH "docs/implementazione/get-active-verifica.md" :GIT-BLOB
   "f46fdd16bd2ff24d0caa1426706db284b6e9f583")
  (:PATH "docs/implementazione/get-active-vuoto.md" :GIT-BLOB
   "2616e0c8ea4cf50baefe1d17c46277a3c11b1e51")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "b290db7acff4b04c7769062bff44c91f643765cc")
  (:PATH "docs/implementazione/get-costi-metodo.md" :GIT-BLOB
   "fb1926959f835883b7d88a5dda7bdea7f30998b8")
  (:PATH "docs/implementazione/get-costi-risultati.md" :GIT-BLOB
   "655b8a35ae16b285e8c5da3ee0249d47a7629c57")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "56133e69f5a305d3d7ed173361a60d11dc8083a1")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "242e710cf037c17f94ce2c6213210b87e1cd5108")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "017acf3977bd60a59c7cc3c093c084dc5742d8d6")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "d25a0d6bb499867c8e74865f76064205c70a904a")
  (:PATH "docs/implementazione/get-fonti-serie-metodo.md" :GIT-BLOB
   "0b3f2db806973acd21c7b0cb4fe203656db06baf")
  (:PATH "docs/implementazione/get-fonti-serie-revisione.md" :GIT-BLOB
   "91c14197cca8cfa11f46b4f5e2ef5cc03e269507")
  (:PATH "docs/implementazione/get-fonti-serie.md" :GIT-BLOB
   "ef7f5f3ae5748673a74ca960d3c5bb1c6e1dd44d")
  (:PATH "docs/implementazione/get-lifetime.md" :GIT-BLOB
   "3c83a87b6b59b2432c54145ff6d8e5144c7864be")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "953b28082bc52d2925a43c6e78ef19e9cd7710b6")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "adad30953d4d419ccd39475545619fb9e32b1392")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "a85bb276b698a7c20da89fb2fb23e19aef2bf5e0")
  (:PATH "docs/implementazione/get-resolver-metodo.md" :GIT-BLOB
   "fe7942c088ae3aa68d0e15e04c9f46faf05622ac")
  (:PATH "docs/implementazione/get-resolver-verifica.md" :GIT-BLOB
   "67b906cd6e8b8569f97a766b66deebd57f4be501")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "753deeb7ec87fcfdc7c8c1275368fa947827ac37")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "5d14690cdad3e3517bcd32522fd9b26f10475eac")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "4515dcc663abeaa09a60ea4c8b3bd6df1baad2d9")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "9a6c1470083bbd595277d9a9f3b430ff0c5f85d6")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "b8204499bb41f33cea556a86eab9551f8709de40")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "695650c8c40cd1cbe9ad38eed29698b7b71ba97f")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "78a7da074a3daca5f05793f03b88fc4ce45321aa")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "c1a36112a2dbf6afef54a654c262389ba9037ba2")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "83b6d477b9d16697c2002989891657ba95ee4e6a")
  (:PATH "docs/implementazione/id-directory-recovery.md" :GIT-BLOB
   "6ea173a4f8c1210432f00d11e6ce6aae4ad1174b")
  (:PATH "docs/implementazione/id-segmento-recovery.md" :GIT-BLOB
   "f2fa99ae8a932406bb74666fa401e0aa9b2655a0")
  (:PATH "docs/implementazione/immagini-indice-paginato.md" :GIT-BLOB
   "8e88cc05ab5ee90c1a1c98d9b20859b652a97bf3")
  (:PATH "docs/implementazione/indice-automatico-completamento-metodo.md"
   :GIT-BLOB "c354d887b3102978bf827b1959e323b7d9b18b27")
  (:PATH "docs/implementazione/indice-automatico-operativo.md" :GIT-BLOB
   "e70a739bfd63091d2ba9cec5c6fd6aa821e4d669")
  (:PATH "docs/implementazione/indice-automatico-risultati.md" :GIT-BLOB
   "d8823f505faa11809cea64f9f3c90675b0198fb0")
  (:PATH "docs/implementazione/indice-automatico.md" :GIT-BLOB
   "614b528773e7b34f955143e0afea744d431e2e1e")
  (:PATH "docs/implementazione/indice-da-recovery.md" :GIT-BLOB
   "486481170704785730c471af7dfd1a5816243a04")
  (:PATH "docs/implementazione/indice-paginato-m1.md" :GIT-BLOB
   "fe476e799ce3ec29caebbecb1a112a2e04bbe2f7")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "4e34fc8e0ffc4413a921b5538edd63693281b70e")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "439aa57177f9323735aaf1e8c4677cdf17e29ad7")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "3935af00f6b06ca6fbca8ab7a8c977eab164322c")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "32dd19680071319c88e9a91a0132260e921573d2")
  (:PATH "docs/implementazione/inizializzazione-active.md" :GIT-BLOB
   "d4c99e5ce4fb98ef862944a7cc41c08205cf60f7")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "56795353bfac9ce5c3ebc0b69f704890d306c194")
  (:PATH "docs/implementazione/inventario-directory-metodo.md" :GIT-BLOB
   "1c6d345a7b2d02c2687f08474a7805e79160b615")
  (:PATH "docs/implementazione/inventario-directory-revisione.md" :GIT-BLOB
   "42511becdd73740fd1ea37f271dc7d4482ddeb74")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "caab01e598ef66377c6da22dbcec17db820b8b91")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "7fcabec950c4e85735ab5bd7960cba65d0b1b494")
  (:PATH "docs/implementazione/io-apertura-relativa-metodo.md" :GIT-BLOB
   "fa44089871f66bddf1309fa5d75b4678eef58902")
  (:PATH "docs/implementazione/io-apertura-relativa-revisione.md" :GIT-BLOB
   "8b13ab5dd4831710adfa606e5edf659e31c8a714")
  (:PATH "docs/implementazione/io-apertura-relativa.md" :GIT-BLOB
   "975eed05b2318ed9b85f4d6f860c2431248f1db7")
  (:PATH "docs/implementazione/io-completamento.md" :GIT-BLOB
   "b5982e35ea000c4c9dcc91021374849d6670638b")
  (:PATH "docs/implementazione/io-creazione-relativa-metodo.md" :GIT-BLOB
   "84b9f6ac1bf934fb7c34e178542cce9dae62fdc6")
  (:PATH "docs/implementazione/io-creazione-relativa-revisione.md" :GIT-BLOB
   "6ad24b936952f03d7a70827f10314ac7f0ad1dfb")
  (:PATH "docs/implementazione/io-creazione-relativa.md" :GIT-BLOB
   "0a0d30b8c6cf826cb906b7d7d26bc8c4c68b3b8d")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "d6eb46b50c73b0150eddbc34cc93f127e82163dc")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "92c01fe2ab85af78f2f3cbf68cdaababa61f5ed9")
  (:PATH "docs/implementazione/io-pubblicazione-metodo.md" :GIT-BLOB
   "bdf72add9058e53ae707719af4ead4d18f462946")
  (:PATH "docs/implementazione/io-pubblicazione.md" :GIT-BLOB
   "f56f5f2f22e43b665a472d8560143b9430ea9ded")
  (:PATH "docs/implementazione/io-rinomina.md" :GIT-BLOB
   "d699c8433a309044b041ec1e2a0713ddb7d6f120")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "3db1a3257313b7040dd2b1222f4de77166de75da")
  (:PATH "docs/implementazione/lettura-indice-paginato.md" :GIT-BLOB
   "ce43161a04c6068b3ddce5b8eee94f35e46c5872")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "1fa26d055d5ee76d3a9bc6f6e6e31a3af3c0e0f1")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "91b0ee252ceff9071c62a573b7b499b8e36e1964")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "4b69dba2809dc40a4d039a6106dd02e560c8e26c")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "20b9246ebddba96db237e5ebcbf2529afbd26a91")
  (:PATH "docs/implementazione/manutenzione-indice-m1.md" :GIT-BLOB
   "bcf08f6c98961ee5660483cd627244c1243f2a99")
  (:PATH "docs/implementazione/merge-main-2026-10-23.md" :GIT-BLOB
   "cb672d06673d639a152ef3bea52b73f258513473")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "332563a00301c759a56fa56efeb0c733f5d8acb5")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "daca7cad14916fbc0b10743a6898bfba4f6c47ad")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "2789dc59d0173d4e0af289cfac129ab12d1bec00")
  (:PATH "docs/implementazione/moduli.md" :GIT-BLOB
   "971b841de90347b255a3e22aaf4e7682fbe25e2d")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "48ffbd9f476751940bbae8713788bd1d812a6002")
  (:PATH "docs/implementazione/pagine-indice-risultati.md" :GIT-BLOB
   "e8889ba9c0d836e73050037bd49faa9ae016a5a6")
  (:PATH "docs/implementazione/pagine-indice.md" :GIT-BLOB
   "34c6c7dec3f852d8dc6245a6c05a7f26ef2d09a5")
  (:PATH "docs/implementazione/pool-begin-metodo.md" :GIT-BLOB
   "8d10cde6f53e6e75cd936fa109121d0caab09d5f")
  (:PATH "docs/implementazione/pool-begin-revisione.md" :GIT-BLOB
   "95657e20c25dd27baddab5c04a2053170af45b96")
  (:PATH "docs/implementazione/pool-begin-risultati.md" :GIT-BLOB
   "c4049dcf13b516abf81bbea4d32aff64cb425c7f")
  (:PATH "docs/implementazione/pool-begin.md" :GIT-BLOB
   "06bd817d57eb415225973e0981778132621cf230")
  (:PATH "docs/implementazione/pool-catena-metodo.md" :GIT-BLOB
   "758327137a15f0f1ef344d51370add33a3a2c6cd")
  (:PATH "docs/implementazione/pool-catena-risultati.md" :GIT-BLOB
   "8bf6c0fe47438107778c68195e6f98ccb42b0b9c")
  (:PATH "docs/implementazione/pool-dispatch-metodo.md" :GIT-BLOB
   "eb6709befc9bdb0d67b04fd5c4c4f98a01ab94de")
  (:PATH "docs/implementazione/pool-dispatch-revisione.md" :GIT-BLOB
   "abda6bf2dbaa1fc5fdc6e55cc22bb0ee931513f2")
  (:PATH "docs/implementazione/pool-dispatch-risultati.md" :GIT-BLOB
   "ab68af4bc1ab1552d74c694ce96c1e1c4222920f")
  (:PATH "docs/implementazione/pool-dispatch.md" :GIT-BLOB
   "a540afacd7952495cc3300e0bced676639c55337")
  (:PATH "docs/implementazione/pool-prepara-metodo.md" :GIT-BLOB
   "4da00d6f92b7f949ec8acafbd3a97dd56bbbb367")
  (:PATH "docs/implementazione/pool-prepara-revisione.md" :GIT-BLOB
   "2c5e9f14f01fedcb7e3dc7a3b4ade9b8bfdcc9b6")
  (:PATH "docs/implementazione/pool-prepara-risultati.md" :GIT-BLOB
   "8c5a986a075da0555e225369bb08b72e4994558b")
  (:PATH "docs/implementazione/pool-prepara.md" :GIT-BLOB
   "84dcb4f1603e43af42c335d58a1d67ebe6347ae0")
  (:PATH "docs/implementazione/pool-recycle-metodo.md" :GIT-BLOB
   "2c811c8f11f65e5142e23c6d8e306b44e412d1e0")
  (:PATH "docs/implementazione/pool-recycle-revisione.md" :GIT-BLOB
   "100e57b2835ce7bc6b5dc68912cf99ae1e637c30")
  (:PATH "docs/implementazione/pool-recycle-risultati.md" :GIT-BLOB
   "4a192b8293368b041956bf12a8e266bd08d86cb5")
  (:PATH "docs/implementazione/pool-recycle.md" :GIT-BLOB
   "40dcde9abd1d21cf1d0d56cecc3b66c641b607b8")
  (:PATH "docs/implementazione/pool-step-metodo.md" :GIT-BLOB
   "e44a4958a4c0a67213243b112bc7362f0573e914")
  (:PATH "docs/implementazione/pool-step-revisione.md" :GIT-BLOB
   "66ab0543f271b9a5c96cb6aa2247be4d6925fd59")
  (:PATH "docs/implementazione/pool-step-risultati.md" :GIT-BLOB
   "470c7dc02213e5d01719829413da36ec08cc5d4c")
  (:PATH "docs/implementazione/pool-step.md" :GIT-BLOB
   "09a4edba6f17bed9682708707ecbe188b2b8e101")
  (:PATH "docs/implementazione/pool-worker-claim-metodo.md" :GIT-BLOB
   "b1b933f896ebb4b2c54a2a714a4c4291c431662d")
  (:PATH "docs/implementazione/pool-worker-claim-revisione.md" :GIT-BLOB
   "18aef79552d243af35866c3d2955e2d11761935d")
  (:PATH "docs/implementazione/pool-worker-claim-risultati.md" :GIT-BLOB
   "f0ce19f06da992cf25de5b3dd396258b7197105c")
  (:PATH "docs/implementazione/pool-worker-claim.md" :GIT-BLOB
   "5a69ddd2dad8066ee9d03792f8548abb9225222f")
  (:PATH "docs/implementazione/pool-worker-lifecycle-metodo.md" :GIT-BLOB
   "d32a1e07253c9138b176912091366712ff3037a4")
  (:PATH "docs/implementazione/pool-worker-lifecycle-revisione.md" :GIT-BLOB
   "9638731f43392e0a33b7f4ed84b19d6c46d1b0fa")
  (:PATH "docs/implementazione/pool-worker-lifecycle-risultati.md" :GIT-BLOB
   "d26d034ded38c3feb056a5a272e5147d790b36f6")
  (:PATH "docs/implementazione/pool-worker-lifecycle.md" :GIT-BLOB
   "5a1af3956ec7cb503cfe7b561acc66e3b32029ad")
  (:PATH "docs/implementazione/prestazioni-local-m1.md" :GIT-BLOB
   "d09055552b7b9fa8d15cd552465dc1025defa2d6")
  (:PATH "docs/implementazione/production-engine-bootstrap-metodo.md" :GIT-BLOB
   "92ea9255903acb119f72d1a61affda35f94a9358")
  (:PATH "docs/implementazione/production-engine-bootstrap.md" :GIT-BLOB
   "65664c0aa06fd0cf86dcd040b91dc8ab882e51ad")
  (:PATH "docs/implementazione/production-unix-m1.md" :GIT-BLOB
   "2da9b5fbfd5e21848587ca64eaba6276ba2ed1a5")
  (:PATH "docs/implementazione/prova-verticale.md" :GIT-BLOB
   "3b9642adce018f1bba63fca6cfaad10924f0351f")
  (:PATH "docs/implementazione/pubblicazione-control.md" :GIT-BLOB
   "8dee23aebeb7bd74de78153bff357b6810162ca0")
  (:PATH "docs/implementazione/raccolta-comandi-risultati.md" :GIT-BLOB
   "0e8a853a5618a1906dd4adbb7c9b18840959d03e")
  (:PATH "docs/implementazione/raccolta-comandi.md" :GIT-BLOB
   "69a9ac538805c31b2857a55f2d5b5c32c0a71b38")
  (:PATH "docs/implementazione/recovery-archivio.md" :GIT-BLOB
   "728fcfa388c5032d170b4f1924b6d614857baee7")
  (:PATH "docs/implementazione/recovery-csn.md" :GIT-BLOB
   "0a3b62e567853df795b710c8e080e3e4319d5153")
  (:PATH "docs/implementazione/recovery-serie.md" :GIT-BLOB
   "fb61bc33d840d815c72dcb3eb4c74c909708d42c")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "09620fc2b2248bec312b075e411f6864a5ebf16f")
  (:PATH "docs/implementazione/replay-closed.md" :GIT-BLOB
   "bb4499a07188b2887c5960e3eba59c951d80a159")
  (:PATH "docs/implementazione/rinnovo-automatico-m1-metodo.md" :GIT-BLOB
   "061f7030b0c9486754cea7333ee3838cf5f00e59")
  (:PATH "docs/implementazione/rinnovo-automatico-m1.md" :GIT-BLOB
   "29fbd690f61f74593e280c1be93b64d74b2609cd")
  (:PATH "docs/implementazione/rinnovo-indice-m1.md" :GIT-BLOB
   "048fb5e263d00771553c8de699ebe0e585c9c780")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "d7b9c49b07bae6f01a5562d15a2cdabcbb979878")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "2709d9ad98b8dd8028b36f0163ba09bf2f49ae14")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "fa341fd666506b060c4d1253773dd87859014238")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "569fb428d702f4a60440c10cb0d9a1a360670fd1")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "ac6b5e1ea180807849dc24481de16eb79e4999af")
  (:PATH "docs/implementazione/runtime-archivio-revisione.md" :GIT-BLOB
   "bba7a3fa2b7e2139ea24ec86cc97fb4b02909aff")
  (:PATH "docs/implementazione/runtime-archivio.md" :GIT-BLOB
   "f8efbf185c6e21920a72d7982f396f5f6e4360d8")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "54739f1b4f681ee51b684fd5f1706028a8922b11")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "24f4832f44e05b4958ee59a8b9b899228f5afa6d")
  (:PATH "docs/implementazione/scoperta-indice-local-m1.md" :GIT-BLOB
   "c6a2000090f8bf5b356b49804799739acccd1344")
  (:PATH "docs/implementazione/scoperta-indice-m1.md" :GIT-BLOB
   "4f05d679dfd56ea2922507433e26c876de136b00")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "40197f19d765e646a0e3ce558386997294130ab1")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "16a6ec600581f9c958650a8578117ad7d7d79584")
  (:PATH "docs/implementazione/selezione-versioni-recovery.md" :GIT-BLOB
   "47d2caa2887778182456420705e0228179305769")
  (:PATH "docs/implementazione/sessione-locale.md" :GIT-BLOB
   "2ecf722d1f5009738a021d2b451e71bfcf0a6c2a")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "3badf8773cc33d0a772b9bde5741af120be1db29")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "52ce3f078d06cad8ffac89ea2baa6ad830c0df34")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "d0ce2c9951518f30ccec2391bc8d9e3e508eaa19")
  (:PATH "docs/implementazione/stabilizzazione-archivio-metodo.md" :GIT-BLOB
   "e29923b3ea68b49f0d100baa7b41f221663d26f9")
  (:PATH "docs/implementazione/stabilizzazione-archivio.md" :GIT-BLOB
   "51adacc370255a8a7d7bb9cb32d5efd9d98cc21f")
  (:PATH "docs/implementazione/stabilizzazione-esclusiva-metodo.md" :GIT-BLOB
   "862b15afa8262596760a2b84e08ba266369e101a")
  (:PATH "docs/implementazione/stabilizzazione-nomi-recovery.md" :GIT-BLOB
   "19c7b3f57ea810a35ebe212071e06e27f61c3a21")
  (:PATH "docs/implementazione/stabilizzazione-serie-metodo.md" :GIT-BLOB
   "89673b60a8a5690b772ef365b2194470238efd14")
  (:PATH "docs/implementazione/stabilizzazione-serie.md" :GIT-BLOB
   "960b956f4841ce0d3a6e38612feee69f2666ab37")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "ec3c6b8f92c54a84bc98d5ac21e58758152de542")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "a60c8e7ee23f78e8a53a516e2c161fc0827ff699")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "e7cf6d0c9962ed26216d07d63d052d45bb9f03e7")
  (:PATH "docs/implementazione/verificatore-offline-m1.md" :GIT-BLOB
   "acb6d215ca675bd8fb4108a1fc93d4009cc9b69e")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "1a94e0e95ab7446193da420d97bedc24a721d387")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "8ab0ba990681d1b185ab87aad114593c0abb305a")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "f08e66f8b7925a5bcec55f2edf1380fc66d6c0a2")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "353a2d053b16ec57b6572aed1f17d1b49d8a232f")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "15c437c7c71674f8fc1cd5a72b3162f4f1715eba")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "e20c5c59567d8ce4800dc19e8dc5fdc2f7f0606f")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "f4edff819e12b287df3cf5f00ecd3550e930f9e0")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "1c4fb7c470a4cfbc6509ccb1c6f793e8bf74208c")
  (:PATH "docs/implementazione/worker-cbor-interleaving.md" :GIT-BLOB
   "02c902149e07d4ac4dfc6f6170799eb34574f09a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "ab3e69cc7051d3ce33f9b4d94cd0e2b20b49807c")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "2c5bcfdaa1783a21adba6911300d0baf7d12f339")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "8fcb335ad6bc807d58ab2ec9033f948421737de5")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "8fa6801e99ffb1abca08a0861883ace20672bd2c")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "63c27916925bec8cfbc39c0c9d558eb444e6dad2")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "f35b46574ff72f1ddac7498c601be30c990d859e")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "ebea51d87dc4f0c750be5834f48d66aac19c7e2d")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "9cd61461e8bfad2d757011db0307229f1517a0d2")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "865c639e5d48a0a77133b6fbe033d78113f703ac")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "1dd65b133120e4f660ed14e674caa8d9af55cfc9")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "4812ec2f65bf772695877b5760a2528fb69a70ef")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "debe8bfd28a95306a16004ca1ccb20ff2bf85fd6")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "7a1ffa13a41b58db26e43bb4090a5d7b6732e512")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "f0ab347bf7c6974b7968e96b9615238b2b14713d")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "b3d19a3668170d14b2ee8a1cec101a27334a8d41")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "14bca7f6cd2c9976cbfdbe3a24a146bc46a34d79")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "f0fd5c63f1adaf9e08e3a7f03dd3fa62bc10aea5")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "c96e7d84ba793911aca73e1deafe6da49509b879")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "8543024839bb87730a16489183b141a010d48cfc")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "234ef34a0065f902f68cdc9432513444a303731c")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ae34240b8fcb8fecbda5492828281de203dc5327")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "07bc53c1a476b0f93bf860fa18c97573d96c656f")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "e120e67c134bd2b9ddbbf55259f5195a3ef4989c")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "85cdbcee3cc2985f6935c6508b71ae9eccf58c99")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "a7329d98d65dd7a94773a87d27f7e3d3871469bf")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "370e2848280af70fbee9085f4c5f1fb44b110889")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "3a9260af22a77d11d636a787613bd50668ffc1cd")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "1600a7f92e73a45f44214bfb2074d0c5cf6decec")
  (:PATH "docs/legal/README.md" :GIT-BLOB
   "149c30dbb116c197f5046d245f765803ed6112f4")
  (:PATH "docs/legal/accessibility.md" :GIT-BLOB
   "f0075a299d3f10c36f250343da01908f39bfc447")
  (:PATH "docs/legal/distribution.md" :GIT-BLOB
   "60ae06a99a28b346e28a28dba81925e38b762192")
  (:PATH "docs/legal/privacy.md" :GIT-BLOB
   "668c2ffde82f4149697d070851e5fdbf281937b0")
  (:PATH "docs/legal/review-2026-10-31.md" :GIT-BLOB
   "8e4053b788081e583340d3531e8c618eba2ef312")
  (:PATH "docs/legal/third-party.md" :GIT-BLOB
   "308d64af3e3901e8c8ea6209ec772f65bd55796e")
  (:PATH "docs/limiti.md" :GIT-BLOB "18a03d0c1262b4ddaddf5ff1cb3dd1777f216c3c")
  (:PATH "docs/lisp-api.md" :GIT-BLOB
   "32c0e75b4f43c2f39f2f91a2584e82ccb47f1cfb")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "f639c868ec4145ce4d712345973822ada77abb6a")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "6c2425c43abbc961ab2845fca2e3ea069b39eb81")
  (:PATH "docs/riferimenti.md" :GIT-BLOB
   "9addadca061376e75319617301e590e010ab8467")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "6b24c490e7a4e90e7d0d751c0796f89a23849c39")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "113bbeaa93a2032b3a642d626836c1d5f5d16c4f")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "df1e19c126d44b07fecbf153fcafa2c9af44e861")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "641464f959c98af64505d506c6c58f7ead9ef3b8")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "c13d990acb745aa485147b8139293693c2b45504")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "b7ef23de41612f981d34a97641e52902a1840a50")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "33f78a2faae61cd73459658d3ba2a88e2ecafe81")
  (:PATH "docs/valutazione/caso-duso-nntp.md" :GIT-BLOB
   "b6a035e1d66b869f40a42e07f2021a42d7de2859")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "972ca495cf51f54d16f3c33ca31fe890b6db7806")
  (:PATH "docs/valutazione/cronologia.md" :GIT-BLOB
   "be43f507343a1c75d71d9e4ada287a9c2fc0de12")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "32026027782790da44884b029c4bae89d5f4e1fd")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "32e72f3b579ee02d5a5e0e897a7618434b02e60d")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "2eeb123c80d9f061d21d2f1a31c57613d7707506")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "a01e78e3fd9dbfe2705fa6fda631d9c387b3bc91")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "c3173768fe23a50691d7106bddbc8c46bb8cd040")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "ed0b8c472645dd6e31178034268a7e60a34e09be")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "603665f1033eb1a62f8b9a4115250a16cf39b429")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "dca0a8b0aa20c8d038dcbc11023182fd552de10f")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "45bf66ebba21b28f569e6f12344277dce7245cd9")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "11d712a7a3432a89299a2f5d7f23736d596d7e40")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "f3eecb3e77252633aac4a62f1100a77b64ca91e0")
  (:PATH "examples/local-roundtrip.lisp" :GIT-BLOB
   "f814d10935f22272e5a440e92e7c8109dda16be8")
  (:PATH "legal/algorithms/xxHash-v0.8.3-NOTICES.txt" :GIT-BLOB
   "1ac346f5f0bff517073cca31f1509f39a5818d55")
  (:PATH "legal/notice-files.lisp" :GIT-BLOB
   "30a68c858f462c6ef601c270ac48603374b149d9")
  (:PATH "legal/runtime/SBCL-2.6.9-COPYING.txt" :GIT-BLOB
   "4220b33974e7fc04036b2b5600cb3ca88ce2c4c3")
  (:PATH "spikes/README.md" :GIT-BLOB
   "f835fdd46c43312889de749d525290e541e891f3")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "c2c2487c33cadbec5444b81073eb9e417a16c42f")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "03a90c690b4673695f0380f81f0cf68e4da8eda4")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "049ff2032103d3d6a6a8049fa9d803d6f82beeaf")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "cd79005b8100b79cbbca35a5677125af54f5e854")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "b388bbb2a067537c8b03b046d63ed6fd5201fa58")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "be57e2f216618fb65d5dde48e8d29938d377a009")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "6452906fa525035cf6abe7967f05778aeaf17f76")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "014f488b7b50a9439b36f49afd6b6f0f11295d84")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "badf96cfb95709afc9174e40b521ac75c6adac8c")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "1a46426b6521ca207a747cd0d2a7fed0ad4ecfd1")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "0061c53057783cc076b2dcb9596e91017e473c47")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "7edbb7459ca78fb41cb812d82ce1dc1c68176ea6")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "18246e75e94db5f4517e96e827469d6a006b30d2")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "0597672e814ccc60c541439e838b7e4eb491788a")
  (:PATH "spikes/SPK-07-protocols/metodo-page-lifetime.md" :GIT-BLOB
   "fba367b24467642a6e544ff86e099b143a73a925")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "6c0034a70670b4249cd2b525c9fca3e140dbd94e")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "517286df830984ba4a6ff39b03175e445afd65d7")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "163e4c3222c4e5771660e6463367ec6b1bc914af")
  (:PATH "spikes/SPK-07-protocols/page-lifetime.lisp" :GIT-BLOB
   "c032387167188be066737f75583738843b12c883")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "1ec5a1db56a76daacbc7488d8b7940aa0e16eca0")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "95ab6095de30d013dbf5c426f7b6c0a99d5663e6")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "9daf0b57d92db583544653384217105121c8627d")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "4712fb08742000724dbbf5c1f7fac4505ca6ad4c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/comparison.lisp" :GIT-BLOB
   "b8b8ebfa609d6bfe9b710833f22cdff693ef46bd")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/crc32c-unroll32.lisp" :GIT-BLOB
   "6dbbe7218c7b5185329f099a8c1407e0f48d8648")
  (:PATH "spikes/SPK-08-generated-code/crc32c.lisp" :GIT-BLOB
   "72bccfafe9c5cb0fd5dc6392534c5be404774a64")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "680b5d9c4e112747e903e124e07cab8adbf97da9")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c-unroll32.md" :GIT-BLOB
   "d722f4f0145cca93b8cb46aa0572538df99a12e0")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c.md" :GIT-BLOB
   "fbbb491611d807c1022c50236fe29c8d7accb2c0")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "4a57493b511201112c533418f1846acdf96f35c8")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "1bbf37c97bcc7d527c3d5aa90cbb9217b807f3ee")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c-unroll32.lisp" :GIT-BLOB
   "79033530456f565b3b14e25b56146039b5356860")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c.lisp" :GIT-BLOB
   "a45f0c3e862c2174b64ac63d4ca97ae3ddf21569")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "7c797afe4a6060782ce58f0cfc06f539006d117a")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "2ed0e101d31cef0967820fc70155ddd4561140fa")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "740e01ad7ddd2dc170e50454befe9a63b9eff276")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "1e54780546d2bcdd623f7fa6c2faaf127bf15dae")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69ac8ef15f356257dae151e035689d8124e9a9eb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "95928362ab8fbde280a5f74be905ae2ca58729ab")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "df0869dea4916cdb5b671a79ffa812369d043773")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "spikes/SPK-11-unix-socket/README.md" :GIT-BLOB
   "47d0cf7d3d5b5541e38cb47814dbb1f0197ffbdc")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "spikes/SPK-11-unix-socket/core.lisp" :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/native-io-method.md" :GIT-BLOB
   "a90da59a3ecad08654d619a56c2ced177db88a40")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-method.md" :GIT-BLOB
   "ebd5dce74e96860ace17a05cf7e14f940adb126f")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/core-code-review.lisp" :GIT-BLOB
   "894a03026e1d4c55f8bde65ba79d64e2775d1826")
  (:PATH "spikes/evidence/README.md" :GIT-BLOB
   "d0dd48506d19490ae1c864f86f4606845241a15d")
  (:PATH "spikes/evidence/history.lisp" :GIT-BLOB
   "f210350eb462c1f3d45f24217f004775496b0eaa")
  (:PATH "spikes/evidence/snapshot.lisp" :GIT-BLOB
   "9ea68544e9490d6598d6361ae0bac6e27a69ce4e")
  (:PATH "spikes/verify-m1-check.lisp" :GIT-BLOB
   "5ec3e4bf45087fec1fd8f878f746dfec63bbb1ab")
  (:PATH "src/active/package.lisp" :GIT-BLOB
   "fbd3a32b30808508424c007ece26c9f3ea9ad0a9")
  (:PATH "src/active/preflight.lisp" :GIT-BLOB
   "9a7da536a7286f5996bf1720db7f9b9dbf20abff")
  (:PATH "src/active/prepare.lisp" :GIT-BLOB
   "e6739a357bdce50ca6bfda7dcd147ce8ffb790fd")
  (:PATH "src/active/source.lisp" :GIT-BLOB
   "27316c9e39b54ff4b2f6b4fe491ab7e67197a950")
  (:PATH "src/active/types.lisp" :GIT-BLOB
   "fc4c2d3ac0839aab37b91d4e017cdaf18bc5041e")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "b0230656edbe3dea63568e74a97e5193cab7c54a")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "a1db79505e00f465b0f0debacbcbd8aad60c5b75")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9725836f0c142b5e292fea4d073f5fbc52b99825")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "84b090e318216a832ab684fc5a936c68e465c169")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "93ecc29914d02b4b6066896de8c2590906ca91bc")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "03bdfeeef2e2639030d3509bd6905364c55f345a")
  (:PATH "src/codec/cbor-array-input.lisp" :GIT-BLOB
   "1b028f9e5f945266f1144b664bf206e89f603863")
  (:PATH "src/codec/cbor-array-write.lisp" :GIT-BLOB
   "625b61e204f7485e1015d109426810ef9d92827c")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-float-narrow.lisp" :GIT-BLOB
   "a2424c60204a55c7ec315de4446e41e243a1afca")
  (:PATH "src/codec/cbor-float-write.lisp" :GIT-BLOB
   "5a44cea28eb51016ce5155ebdf5750b93d15a1b3")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-item-read.lisp" :GIT-BLOB
   "e95db7d9f407e9e0039dc8892e4af8065490d99d")
  (:PATH "src/codec/cbor-map-input.lisp" :GIT-BLOB
   "87c9fd9dd6eb1f3ee1b79bdf2957801762601d97")
  (:PATH "src/codec/cbor-map-write.lisp" :GIT-BLOB
   "84887090a1fa543da817bd096528b576f3d58d9e")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "d9c686fef43c16c5cbf85672b2480a3d0340edfc")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-string-read.lisp" :GIT-BLOB
   "446498b0f3b0f014471312eeb01b3d9a254b6535")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a9028c0b30a22367baad2711346a5517089b1940")
  (:PATH "src/codec/cbor-tag-input.lisp" :GIT-BLOB
   "760e81952f8eb3210465a6cea5c0b89c3f15c5a4")
  (:PATH "src/codec/cbor-tag-write.lisp" :GIT-BLOB
   "4680d759cf12aaa61df5823cb86e71ed7379914c")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "159033291735d23258b340f8da17ad6bd001ccbf")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/control/build.lisp" :GIT-BLOB
   "d5aca4f9ade3c126e88709f1ada1a9e39132b6a1")
  (:PATH "src/control/dependency.lisp" :GIT-BLOB
   "144f908c5cafddc397dd8a1cab04cd641d93a32c")
  (:PATH "src/control/package.lisp" :GIT-BLOB
   "e56a6bb83abe9441350baa46573d74c6d55edf4e")
  (:PATH "src/control/preflight.lisp" :GIT-BLOB
   "850a8f3bedb592dad251e36d7e95ad9fa993979d")
  (:PATH "src/control/prepare.lisp" :GIT-BLOB
   "51cdc2f60ef3da074e98f5bbabd1bb1b4ffbd6ed")
  (:PATH "src/control/publication-read.lisp" :GIT-BLOB
   "a5ebb2f8fafe283f3816d48e633ef8471bfbf4ba")
  (:PATH "src/control/publication.lisp" :GIT-BLOB
   "c8c482c65af3a94bea9acc38b3b93f04933c93b1")
  (:PATH "src/control/recovery-publication.lisp" :GIT-BLOB
   "b01545b6647f5dbac8097dcab394260fb7f9d3cd")
  (:PATH "src/control/recovery-read.lisp" :GIT-BLOB
   "430665c20905e5f7d67245e2d7503bb0f9e0c11f")
  (:PATH "src/control/recovery-types.lisp" :GIT-BLOB
   "2ac4f985eec224f17cea5658cd9d42f4aed99cce")
  (:PATH "src/control/transfer.lisp" :GIT-BLOB
   "69bb7c2e27817201c5533fa4d6099a26750a38b7")
  (:PATH "src/control/types.lisp" :GIT-BLOB
   "7eaa6e2298ac264b7d64c1f7a78de8d1fab8ce09")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "c2ff554d80181b48d8ba414e9d2c6a84080cb413")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "c46fd76164808980af1d8b639890b3cc0ce8fb79")
  (:PATH "src/dispatch/begin.lisp" :GIT-BLOB
   "bb45bcad39e438aa082e92d01358d1059cc5fd20")
  (:PATH "src/dispatch/build.lisp" :GIT-BLOB
   "9d1c974830e92918b572af978e8a2b4acae257b6")
  (:PATH "src/dispatch/claim.lisp" :GIT-BLOB
   "a9d55f610fbd14b5bff7f9d6c2a6c8abb7ba405c")
  (:PATH "src/dispatch/package.lisp" :GIT-BLOB
   "db21c798588ff4a88be5b69b5fbe72bc84811a46")
  (:PATH "src/dispatch/recycle.lisp" :GIT-BLOB
   "57955f63a0cfc4efc3f7f742fd479c032dcec5b2")
  (:PATH "src/dispatch/start.lisp" :GIT-BLOB
   "4d519c9fba0c085d5789c2883c8d04079e3933ea")
  (:PATH "src/dispatch/step.lisp" :GIT-BLOB
   "36c8c1e84c7329f4a0b24186e09a40b2ce2d2b61")
  (:PATH "src/dispatch/types.lisp" :GIT-BLOB
   "6f3b3841a3158cac6daf70cc8a1ae3984f52566c")
  (:PATH "src/engine/adopt.lisp" :GIT-BLOB
   "e91cde14fcff879a1858b28c6063e5188dca4da0")
  (:PATH "src/engine/compaction-control.lisp" :GIT-BLOB
   "02cbb0127a3e9519ed0dc90730f077ade17fb5dd")
  (:PATH "src/engine/compaction-install.lisp" :GIT-BLOB
   "167777a12cf87a02b36a73c5609d098d9d8d1b46")
  (:PATH "src/engine/compaction-plan.lisp" :GIT-BLOB
   "d255c8440ee3abb0c190801e7c5b2e1a4872b47e")
  (:PATH "src/engine/compaction-reclaim.lisp" :GIT-BLOB
   "00076045f47b9b8a5a4a0aeee449a3a0cc5e2047")
  (:PATH "src/engine/compaction-relocate.lisp" :GIT-BLOB
   "3f316d79bf63b30bb5fa0cbac38927cf2a6e540d")
  (:PATH "src/engine/compaction-scan.lisp" :GIT-BLOB
   "942e0b2ba2be30a2e94efa1c80564dd7159e322a")
  (:PATH "src/engine/compaction-types.lisp" :GIT-BLOB
   "ee6f36958a147af9cdabdfee2ebe77752476da74")
  (:PATH "src/engine/compaction-verify.lisp" :GIT-BLOB
   "57628bb40f5be4c42b4366e81a0662f7f98c0137")
  (:PATH "src/engine/compaction-write.lisp" :GIT-BLOB
   "41cc966628e64d765c8a8f9d132321451025a3bd")
  (:PATH "src/engine/compaction.lisp" :GIT-BLOB
   "1eac672cf412fc36ae6fbfe5d8b4e7b93dcf480e")
  (:PATH "src/engine/conditional-group-types.lisp" :GIT-BLOB
   "f018f3b3512695c2fd5cc35f88e0e04ca90aef19")
  (:PATH "src/engine/conditional-group.lisp" :GIT-BLOB
   "f502618dc0a4c33aa5024408baccb116ed943c94")
  (:PATH "src/engine/conditional.lisp" :GIT-BLOB
   "e31cf1694c34220247c84e57022561e3757aa796")
  (:PATH "src/engine/config.lisp" :GIT-BLOB
   "354198f7b04489a46d0a67018d181a4c8668a42e")
  (:PATH "src/engine/delta-location.lisp" :GIT-BLOB
   "367601a853f8d2dd155b1dc0002b86d1b4bcdd5b")
  (:PATH "src/engine/delta-types.lisp" :GIT-BLOB
   "539f08cdb3736546b2b1556f81050d6c5d09ece9")
  (:PATH "src/engine/delta.lisp" :GIT-BLOB
   "b865dc6c8be351c3e89fcddbce61a4e0d7a2dd5d")
  (:PATH "src/engine/files.lisp" :GIT-BLOB
   "eda0f6adb8eb34225b6775b8ef666224e753deda")
  (:PATH "src/engine/image-activation.lisp" :GIT-BLOB
   "51ef93215340364bc2c881f3e7efa6a47aac6aa8")
  (:PATH "src/engine/image-auto-types.lisp" :GIT-BLOB
   "8879e3aa9b00d18cb138da9ca6d04028816502af")
  (:PATH "src/engine/image-auto-write.lisp" :GIT-BLOB
   "ac1ad97829a4b076b6f223e9e010c55752bf3066")
  (:PATH "src/engine/image-auto.lisp" :GIT-BLOB
   "0449392da3326308f5697fc231d24d329a691db8")
  (:PATH "src/engine/image-build-io.lisp" :GIT-BLOB
   "fbd185cd56d4d980575c4d0fec5597b715074f61")
  (:PATH "src/engine/image-build-plan.lisp" :GIT-BLOB
   "ccd01ee41d0d7a103680785731c5271a54f6f2df")
  (:PATH "src/engine/image-build-read.lisp" :GIT-BLOB
   "b11e63f292b93ddaee8b0c645d525a175a1906b0")
  (:PATH "src/engine/image-build-tree.lisp" :GIT-BLOB
   "d9a657c2fbdbb294e34fe8ba40c4fe8c8df11f03")
  (:PATH "src/engine/image-build-types.lisp" :GIT-BLOB
   "d2aacfe57703a7a99354657e4823a641d6eabb43")
  (:PATH "src/engine/image-build.lisp" :GIT-BLOB
   "a4c8ad027a796610299f457399f566ac0ca4284d")
  (:PATH "src/engine/image-config.lisp" :GIT-BLOB
   "47becee77666bb573500cc1d23735e627e65411b")
  (:PATH "src/engine/image-discovery-config.lisp" :GIT-BLOB
   "66c7f2c7f7eb87e0147d858c11787ffdd06b14bb")
  (:PATH "src/engine/image-discovery.lisp" :GIT-BLOB
   "aa41ecbc41a335a25fd3f62761147be516ebce6c")
  (:PATH "src/engine/image-maintenance-config.lisp" :GIT-BLOB
   "cbd5f1cdde00a60ee8cd952898c06e205c8edf1c")
  (:PATH "src/engine/image-maintenance.lisp" :GIT-BLOB
   "44bdff3e98ff1176b51b1bbc20bb8f54b94f5f3d")
  (:PATH "src/engine/image-recovery.lisp" :GIT-BLOB
   "f42286cf6d43cd486d9c4a79f764c99c35e2aa37")
  (:PATH "src/engine/image-renewal.lisp" :GIT-BLOB
   "0e6c21fcdec1d316551417b024e1ba5bda472abc")
  (:PATH "src/engine/image-source.lisp" :GIT-BLOB
   "8b7c7ecdebbf07ada9b68037976be5af53a6a106")
  (:PATH "src/engine/index-auto-api.lisp" :GIT-BLOB
   "1241871a3195c1c42b890e08373803a816809817")
  (:PATH "src/engine/index-auto-apply.lisp" :GIT-BLOB
   "7062c70c0f6322cda8de3f089bab2a216dae3d44")
  (:PATH "src/engine/index-auto-files.lisp" :GIT-BLOB
   "2c79ded6eb822d4f238f31cd7756bcdc79d5be7d")
  (:PATH "src/engine/index-auto-memory.lisp" :GIT-BLOB
   "8199f78030cc2d21af63d223c7d9cb99cb22b4fb")
  (:PATH "src/engine/index-auto-migrate.lisp" :GIT-BLOB
   "52e44cd130f7dc77bf6fa0be130dfc4827b4ec59")
  (:PATH "src/engine/index-auto-resolver.lisp" :GIT-BLOB
   "82554d4e3b9382c60bbdb0cf2986a4e75af1dafa")
  (:PATH "src/engine/index-auto-types.lisp" :GIT-BLOB
   "7d848c894841cdcf2abf615cd8140568a264351c")
  (:PATH "src/engine/index.lisp" :GIT-BLOB
   "650e3e008a6e489ebc3972366724edab5a3189c0")
  (:PATH "src/engine/initialize.lisp" :GIT-BLOB
   "8c39b866a402a30b1aa1ef7409e675f367e4ec97")
  (:PATH "src/engine/lifecycle.lisp" :GIT-BLOB
   "717898da19e3288ee03ac782959c23d32c9b8170")
  (:PATH "src/engine/package.lisp" :GIT-BLOB
   "b67b3b15539954ba4d3c92fcb3f4ccfafebca4c1")
  (:PATH "src/engine/preflight.lisp" :GIT-BLOB
   "272b6ffeb63fa9536bade7a0fd48764340128e4c")
  (:PATH "src/engine/read.lisp" :GIT-BLOB
   "a1737e9c70b317464520811512a42d4ae059bbdd")
  (:PATH "src/engine/record-cache.lisp" :GIT-BLOB
   "6d00296bffb12094dafd46a4ac898c9a20f81dfa")
  (:PATH "src/engine/recovery.lisp" :GIT-BLOB
   "05b64c0a49c59c209af8bac92f6823c193a92122")
  (:PATH "src/engine/rotation.lisp" :GIT-BLOB
   "db73c93ab163dc4cf2699cb6c357cfa3591be092")
  (:PATH "src/engine/startup.lisp" :GIT-BLOB
   "5245c459ca92fa0f69ff1810befc748fbb303f7f")
  (:PATH "src/engine/types.lisp" :GIT-BLOB
   "9a3c91e2a88056e611555fad3f5bd90c3ec1cbdd")
  (:PATH "src/engine/write-group-build.lisp" :GIT-BLOB
   "20a777cd92be4b8f91dad208132945c42309496c")
  (:PATH "src/engine/write-group-commit.lisp" :GIT-BLOB
   "18a21f787b8bdb1f41dd4f1ee3e215253cd62c0c")
  (:PATH "src/engine/write-group-index.lisp" :GIT-BLOB
   "b28196235d2b2853edbe75fcb5d024c0e7ea1b11")
  (:PATH "src/engine/write-group-legacy.lisp" :GIT-BLOB
   "a0c17966476bfa9d5a008bec9b6071c91070040f")
  (:PATH "src/engine/write-group-plan.lisp" :GIT-BLOB
   "d126d7176bef13a8dc19bac5836581cb65dfbd35")
  (:PATH "src/engine/write-group-types.lisp" :GIT-BLOB
   "2f1e78aef52cbdb0aabc663873b832eb31713bba")
  (:PATH "src/engine/write-group.lisp" :GIT-BLOB
   "bacee8da25a18c7736921c10357a344394eb5ed8")
  (:PATH "src/engine/write.lisp" :GIT-BLOB
   "3b83c17a8bf510c110648b4257fe9b8df43b6bf5")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "93dbc244d3e8a86e64254b31e2954102f65ab149")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "0fc4c81f23e27dabfe52485a3976ec3eb390eb4c")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "e0d503d2ad85689ac6162636857f4e44f2b5c7f9")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "474ddacfc871629aad94b6d59b87de7cd4349475")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "838611d288696767dc539b155fcfefe3feec79e2")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "bbed8c36a799b57baebe6350dd96c3a968dd05e7")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "b27df62179c9f43132c445c82f0c2bf4ee78f366")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "5d4e27472170bfffa85a6e8aac0760236e7fefb6")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "f79bbd85269d50eb929816276353b2fbb85f92c9")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "a36b9bc921e8d58f9cf3a10a8426eb388e710226")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "c066712083a07bc574481ae3a3cdcc996c9303a8")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "3c970d0cbd3866d837c07bd03d7e4e0fae24f21f")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "c048d0e7321d26e5ec3ec4eb7d3bd79b4714aef5")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "7170e6de30721bcb89cb94b56e9d3c579a1269be")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8be80a716738875d5e6fe056c5f3c81d2ffad2e5")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "5560532f4cae67478c11adc65e632cfe3da10ad7")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/crc32c-native.lisp" :GIT-BLOB
   "2e80dc72cce0064a460b8ee78970acae71a9da35")
  (:PATH "src/foundation/crc32c-vops.lisp" :GIT-BLOB
   "0677d1d29c7fc16dbd8bda529cffa5f1076327a8")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "3dee5a43950d683f83deffaa6f329d6dcbc6cfc2")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "6fca7bd583990cf07093243c95f399d294b74d45")
  (:PATH "src/fulltext-admission/build.lisp" :GIT-BLOB
   "ba813f4178d646f412363e8b3f86f7309878a4a1")
  (:PATH "src/fulltext-admission/copy.lisp" :GIT-BLOB
   "43488c42525991544b355bfc061c2c753e866c88")
  (:PATH "src/fulltext-admission/guards.lisp" :GIT-BLOB
   "c4734194dc53a5f98397bd0b35079c5739f95a41")
  (:PATH "src/fulltext-admission/lifecycle.lisp" :GIT-BLOB
   "088b775f74cf633ecb3b84a0c0b9445209cc4b93")
  (:PATH "src/fulltext-admission/package.lisp" :GIT-BLOB
   "74d06aa6d0d0b263b806f678b23cec40b5db3ef1")
  (:PATH "src/fulltext-admission/preflight.lisp" :GIT-BLOB
   "eeff3e04503f0dac81da9816112f2da68e384dc2")
  (:PATH "src/fulltext-admission/query.lisp" :GIT-BLOB
   "a8aac3c938ada73cb2b18abfaf44d7bc1ff4cfa5")
  (:PATH "src/fulltext-admission/reserve.lisp" :GIT-BLOB
   "374c03ecf29417aad8e760dd432ff3e5a6383e4c")
  (:PATH "src/fulltext-admission/row-update.lisp" :GIT-BLOB
   "1d77f5d5c6e1ddb8ab08136d7d7afaf1f79a7f79")
  (:PATH "src/fulltext-admission/rows.lisp" :GIT-BLOB
   "f1c6dc8236477b5de6b2f0e5db4bab8a02fcbe95")
  (:PATH "src/fulltext-admission/types.lisp" :GIT-BLOB
   "b4766a5b561c1a1f3e53bfc9485f72b128dfb1d1")
  (:PATH "src/fulltext-put/append.lisp" :GIT-BLOB
   "df244937278aebfabba27f14555b36476e6d9858")
  (:PATH "src/fulltext-put/binding.lisp" :GIT-BLOB
   "c47d939287b3be63ec090d24bd64903556b2b86a")
  (:PATH "src/fulltext-put/build.lisp" :GIT-BLOB
   "1f4113fb6ce043099672cf72c995b976c9543cea")
  (:PATH "src/fulltext-put/package.lisp" :GIT-BLOB
   "0ffd3fb459d14ef6da0ab6789930b8ee54b78fe5")
  (:PATH "src/fulltext-put/physical-header.lisp" :GIT-BLOB
   "8fbb48b2ceb0ccb9c73b9344e14fbb025174b7e4")
  (:PATH "src/fulltext-put/physical.lisp" :GIT-BLOB
   "f7a1a29690b384cdd8bf791e62ac2d98deb7495b")
  (:PATH "src/fulltext-put/prepare.lisp" :GIT-BLOB
   "5a6929f64ba29f63efa2717a79fb79c93206b74c")
  (:PATH "src/fulltext-put/reserve.lisp" :GIT-BLOB
   "81642e379bb158bed9bec2f0fa9c70190a637567")
  (:PATH "src/fulltext-put/row-reference.lisp" :GIT-BLOB
   "b24f1dc1bd7ea08b7efe05e954cd30190f8a1aa1")
  (:PATH "src/fulltext-put/start.lisp" :GIT-BLOB
   "8c6677841d374a7bfc1834a83ccf610eecce0890")
  (:PATH "src/fulltext-put/types.lisp" :GIT-BLOB
   "c0bb31863f4f17894f85f69df42d5476d988f9da")
  (:PATH "src/fulltext/analysis-emit.lisp" :GIT-BLOB
   "17bcef98c46d7a035d2945be0c7407ed178e3da7")
  (:PATH "src/fulltext/analysis-nfc.lisp" :GIT-BLOB
   "e3e34d111a4cbab7a860d995e0658e154f1a4031")
  (:PATH "src/fulltext/analysis-package.lisp" :GIT-BLOB
   "5729cfba660c391cf9dee6fc3d5e6ccbddcd2552")
  (:PATH "src/fulltext/analysis-properties.lisp" :GIT-BLOB
   "320a03b22e01f755184d3d8b6aa1a61b009ce538")
  (:PATH "src/fulltext/analysis-space.lisp" :GIT-BLOB
   "7ab493596664f1488b369fc0b14b083e9eee31af")
  (:PATH "src/fulltext/analysis-word-context.lisp" :GIT-BLOB
   "023c1d7676f5f1325e7b112ba38a132a010f36e8")
  (:PATH "src/fulltext/analysis-word-rules.lisp" :GIT-BLOB
   "0278fccb36c8320d8b0b11b26e067773b8435e1a")
  (:PATH "src/fulltext/analysis.lisp" :GIT-BLOB
   "496c3196aa6efc23695486f15253f9275b58c1c6")
  (:PATH "src/fulltext/codec-input.lisp" :GIT-BLOB
   "ff8ede224c154fa075b7f1eb53cacecbcc7d73c3")
  (:PATH "src/fulltext/codec-package.lisp" :GIT-BLOB
   "fcd63be08134216e7a0d79c68ba6fc1120415689")
  (:PATH "src/fulltext/codec-plan.lisp" :GIT-BLOB
   "b614382a5beec3c0ccc3134f0e2abffc0fb44e87")
  (:PATH "src/fulltext/codec-query.lisp" :GIT-BLOB
   "1047b265bf2140ea5d14ea55987f1bdfae2f6e0c")
  (:PATH "src/fulltext/codec-read-base.lisp" :GIT-BLOB
   "5a24b81342a564255563e9309efcc9f043aa33a4")
  (:PATH "src/fulltext/codec-read-dict.lisp" :GIT-BLOB
   "5958a63148c0942343fa93fce59a59d614850bb2")
  (:PATH "src/fulltext/codec-read-lengths.lisp" :GIT-BLOB
   "91b77b0ef9cc16fb29c437130453ca97c19de60f")
  (:PATH "src/fulltext/codec-read-postings.lisp" :GIT-BLOB
   "46fc1a96ed8bd3e616392ac6c891a678b4e8f33a")
  (:PATH "src/fulltext/codec-read-term.lisp" :GIT-BLOB
   "bf77c4c7d7f7faeaa68077cc1dfbb8349ff6eeb7")
  (:PATH "src/fulltext/codec-run.lisp" :GIT-BLOB
   "fbe693aa1579466dc55fc03fe88a1bb04d7c097f")
  (:PATH "src/fulltext/codec-space.lisp" :GIT-BLOB
   "48e907be585f73c58fd7fa4e89a0b5cdfbfef309")
  (:PATH "src/fulltext/codec-view.lisp" :GIT-BLOB
   "49a4547d0153a45281e2bd2188891f2c5517523d")
  (:PATH "src/fulltext/codec-write-entries.lisp" :GIT-BLOB
   "035e0c6d0826d7be8e5308c3dbabf9f4b6b94b50")
  (:PATH "src/fulltext/codec-write.lisp" :GIT-BLOB
   "64731ed8f9fc9f1246a62c659b18fa85ae2a0f3e")
  (:PATH "src/fulltext/descriptor.lisp" :GIT-BLOB
   "d53475000e9a1f3f3ab97f29780b526b39c43e58")
  (:PATH "src/fulltext/document-analysis.lisp" :GIT-BLOB
   "5f4635b04bf39a7673c4071ac423f3c23b595c57")
  (:PATH "src/fulltext/document-bound.lisp" :GIT-BLOB
   "6eb42da6fa77f01a38b92559b1eccc32f1313d43")
  (:PATH "src/fulltext/document-config-input.lisp" :GIT-BLOB
   "f9522d52f03c808c9e31903ac6393ba113c487f0")
  (:PATH "src/fulltext/document-config.lisp" :GIT-BLOB
   "4d28290bec4b6bca2f8a79338323fa1e4b2ed617")
  (:PATH "src/fulltext/document-package.lisp" :GIT-BLOB
   "c699e405a2ce6c5a18cc27842352f8ad43647e4b")
  (:PATH "src/fulltext/document-paths.lisp" :GIT-BLOB
   "dc31d23d3316043885526af964aab860fe4a6f45")
  (:PATH "src/fulltext/document-scan.lisp" :GIT-BLOB
   "62df7660d399fe08ccb948a21fe6ceb0bbca507b")
  (:PATH "src/fulltext/document-space.lisp" :GIT-BLOB
   "ab484dddcbd81d464e8739e4aa28a1be667accc1")
  (:PATH "src/fulltext/document-start.lisp" :GIT-BLOB
   "d59279a55290ed8b35e722dd9ee47cef68502a1a")
  (:PATH "src/fulltext/document.lisp" :GIT-BLOB
   "447a0f0d27d1e197483f839e7a03d75bce92585d")
  (:PATH "src/fulltext/format-constants.lisp" :GIT-BLOB
   "cc040653f809c725a063eee35fff6e2f9570b675")
  (:PATH "src/fulltext/format-input.lisp" :GIT-BLOB
   "891ad11bf97386317a7a56d6e81c7d425745dfdb")
  (:PATH "src/fulltext/format-package.lisp" :GIT-BLOB
   "1f72e2d40467a20422c5bfaa2564bb5b84fedf29")
  (:PATH "src/fulltext/format-read.lisp" :GIT-BLOB
   "323807f0a973049dd290dd7dad4d2266301e6e57")
  (:PATH "src/fulltext/format-write.lisp" :GIT-BLOB
   "2b89b266d96de0264d92b164b4d59e4e27079f82")
  (:PATH "src/fulltext/index-build.lisp" :GIT-BLOB
   "54ae060c29f1345430a44b2b378c8cb43039dcdc")
  (:PATH "src/fulltext/index-lookup.lisp" :GIT-BLOB
   "9ef394661c96beef9e4cbf3f2e8e5812ec6828c6")
  (:PATH "src/fulltext/index-package.lisp" :GIT-BLOB
   "20bfb93adc06f0782e20fe842f4805b2249d440a")
  (:PATH "src/fulltext/index-sort.lisp" :GIT-BLOB
   "369d3de6ee0ecee94aadfe6ebbce619b84e8147b")
  (:PATH "src/fulltext/index-step.lisp" :GIT-BLOB
   "9206fd68138b97057494978f7713618063510654")
  (:PATH "src/fulltext/meta-fields.lisp" :GIT-BLOB
   "afaeeadd5831bac5804c57a9b67428a3e3c2eaa0")
  (:PATH "src/fulltext/meta-read.lisp" :GIT-BLOB
   "9a4f5a543e68b9c585126096feadaa754f10c6d7")
  (:PATH "src/fulltext/unicode-tables.lisp" :GIT-BLOB
   "a0b079ee4bfba2d1a6ca83b4bb9c555462b75b3c")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "4ebfa97211671287aa2c972a8923654c2390d0f9")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "8dcddeb0536c1104af92c722ffbfab2059601c74")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "a957b1f91e495637b700756736a96baafd233abe")
  (:PATH "src/get-directory/sources-read.lisp" :GIT-BLOB
   "fbb8b26fcfd9de939bf4f3c61d5fd0c5c335754c")
  (:PATH "src/get-directory/sources-types.lisp" :GIT-BLOB
   "ce426ea6409d588e0ca6add8e6c95a1c594e0c89")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "564cdaea8cb9aae672cbbd4328ea7e76b4430f4a")
  (:PATH "src/get-resolver/active-arena-read.lisp" :GIT-BLOB
   "b70b14e779d6c841bd52ca53a599822b77dcdc32")
  (:PATH "src/get-resolver/active-arena-write.lisp" :GIT-BLOB
   "2f893bf07fc9a7d36761a54cf2bbd03300d5a945")
  (:PATH "src/get-resolver/active-arena.lisp" :GIT-BLOB
   "8195220c0d648304d57dac090ab0da03f7812fe9")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "136d22104439f016932e90d45622553f070c1724")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "3a3dae662d06b1e2b6bc936b227894d2f0396b6d")
  (:PATH "src/get-resolver/active-init.lisp" :GIT-BLOB
   "89d45e100f395e65aeca93e7d317073cfb5ffdc3")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "93a32b00aef08a29b4ae7d638eaf16cc68a284ff")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "430b3ba6b063931e60c477a22ce3c50fa1898750")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "6e481f4d41ba4d20649978f806df1685b7afa8fb")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "9634424bab5ea2fe66d950f30e7d51b1baa3a395")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "d6854c7ec8b7125b33391a27760be11cd01c89db")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "33d7b898b5f5a7b20c8112484191c14df44b770e")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1a5479dc776fd56b3c6871dd2984a620bf43f991")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "b747d3a4b6517d7574225dc26cab8703747f0e05")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "c0f1a6b32a1725b6e9ae05e00e130a3e0097be78")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "7f2f8b496d65b70d83eee58c19b5b679b5d632ba")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "77b07c57b7e57505ff35724dc36a90cb554679ee")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "76ac8e35c01b887cec70ccd78d29d87690557eae")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "2a393aae53a7b13b567dc5a44b5d0d1da83714f3")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "01233e1565f301c96ce6ee3bb33a50f10cb2e937")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "7a3600dfe26168cc956e1ef62d07221a6d51a61f")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "fe1475f001e9b5719980f7e7507f735edc7e208a")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "4dd3840c525e54acc7d1577b45aadff217a77c4b")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "f1a5060bb6071bec929476a9151fba0ec68e1604")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "db2d060ad9f747deaa7f5016d09eb8ff0299d36e")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "9827cb4af0343e4241d2fed6e3c62830455f8749")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index-disk/api.lisp" :GIT-BLOB
   "daeaeeaef31f8cd903ad02f6cd60193611714643")
  (:PATH "src/index-disk/balance.lisp" :GIT-BLOB
   "c1189c5fcb2a3389004a0b2d19357c4f93e9e026")
  (:PATH "src/index-disk/build.lisp" :GIT-BLOB
   "85d0f397ea8062235c537806caa21fe03d790589")
  (:PATH "src/index-disk/cache.lisp" :GIT-BLOB
   "e61013c7d4d60aa0711024615dcdf42476c69ecb")
  (:PATH "src/index-disk/copy.lisp" :GIT-BLOB
   "b26cdc656f9112ab344983c5a7f473e97442c8e3")
  (:PATH "src/index-disk/mutate.lisp" :GIT-BLOB
   "ac7a72b3d506de92ec80bbb9653904188b98d8f8")
  (:PATH "src/index-disk/package.lisp" :GIT-BLOB
   "23536e507f5fee4b20554184835addebab23ba3e")
  (:PATH "src/index-disk/read.lisp" :GIT-BLOB
   "20599afde6adbb9cd9decdc852f0de469a5d72e5")
  (:PATH "src/index-disk/relocate.lisp" :GIT-BLOB
   "34399623c2c31e68c16d069f57d1b7e6b9bd4ab2")
  (:PATH "src/index-disk/types.lisp" :GIT-BLOB
   "df13ba528aa6bba71981c44b8fbf14c69fa4551e")
  (:PATH "src/index-disk/visit.lisp" :GIT-BLOB
   "ec8ae71e8f2d27b7e2a49cefbeb2c86e7367bbe2")
  (:PATH "src/index-disk/write.lisp" :GIT-BLOB
   "7b6e37218626e782f22cc2903328c40f23d52fac")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "64be10d7b2dc85c6dd6c31becefbb6ee3ae74d21")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "ec86f5be5b5d465d5e32dc3c492cbc0c90daaba5")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "6dc9775423900dd855c71c06079cdc5e69411c5b")
  (:PATH "src/index/image-codec.lisp" :GIT-BLOB
   "e3b96642767e7e0d116481f41e279274646c2b12")
  (:PATH "src/index/image-constants.lisp" :GIT-BLOB
   "6c123802b75884937c2e9bcd7cfe4e214173ab9e")
  (:PATH "src/index/image-publication.lisp" :GIT-BLOB
   "7733d528d07acc24ec9f8c00c6767c2e3b09975e")
  (:PATH "src/index/image-recovery.lisp" :GIT-BLOB
   "ea1a681932b0fa2a1a7a3f44238816657505e55c")
  (:PATH "src/index/image-seal.lisp" :GIT-BLOB
   "f788cc87a9f2f963210d5bb54310f359df78adba")
  (:PATH "src/index/image-types.lisp" :GIT-BLOB
   "69315a89f5b007ebfbb838bc87dde37221fa69c8")
  (:PATH "src/index/image-verify-edges.lisp" :GIT-BLOB
   "2bdfd22b88408ff57efe6dc6e8c61fb5bb4f2fa1")
  (:PATH "src/index/image-verify-entry.lisp" :GIT-BLOB
   "6d240011e6b3f2c8795537bdead86763cd5a0dd5")
  (:PATH "src/index/image-verify-key.lisp" :GIT-BLOB
   "c7bde57d3d327f32321c29d358cb84eb90f1eadc")
  (:PATH "src/index/image-verify-types.lisp" :GIT-BLOB
   "a7f39bfa563402bb113c3430c5229926c0354ff9")
  (:PATH "src/index/mode-package.lisp" :GIT-BLOB
   "53da3230da115c0d702cc762d3f2ab69e6af253e")
  (:PATH "src/index/mode-policy.lisp" :GIT-BLOB
   "2acdfd94b5a0e5bfc04135cf9f39b4a72ef93482")
  (:PATH "src/index/mode-types.lisp" :GIT-BLOB
   "9e42e46cfa22a400da7635e45ab7c8192e25204c")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/page-body.lisp" :GIT-BLOB
   "c4143fd0c6350883ff10db74c2f8b9c7320b7600")
  (:PATH "src/index/page-bucket.lisp" :GIT-BLOB
   "f6f9c5b2076c8f3c1ae9dd1c23bdab00cbd69005")
  (:PATH "src/index/page-build-config.lisp" :GIT-BLOB
   "8d34342f4e34d3edacf6edb07a3059b8cd199d62")
  (:PATH "src/index/page-build-emit.lisp" :GIT-BLOB
   "479818ed5d901eee9ecfee456e39b66d4f02c620")
  (:PATH "src/index/page-build-plan.lisp" :GIT-BLOB
   "86bf82eb3913ca8dad0f7e1dbe1e9016da5b18a9")
  (:PATH "src/index/page-build-proof.lisp" :GIT-BLOB
   "f86fd7f850a9f1559e9af7fdf445971e07020eff")
  (:PATH "src/index/page-build-types.lisp" :GIT-BLOB
   "4fb20f67faa960088aadf112246f84a98f58117a")
  (:PATH "src/index/page-build.lisp" :GIT-BLOB
   "b632710d7d32cac680b10a9312bd9c4878024fd0")
  (:PATH "src/index/page-cache-types.lisp" :GIT-BLOB
   "bbea574ced62361daf59b1d03fb6f06cdb840991")
  (:PATH "src/index/page-cache.lisp" :GIT-BLOB
   "e66d3fa17f78dde39eff02eb8993a7c68f9ba9f5")
  (:PATH "src/index/page-constants.lisp" :GIT-BLOB
   "de904d211f301a087b3d1d53fa47a8054ccf2eb7")
  (:PATH "src/index/page-lookup-key.lisp" :GIT-BLOB
   "9e2e8f43e9a787b7a9223d57dcbab979dbbc233e")
  (:PATH "src/index/page-lookup-types.lisp" :GIT-BLOB
   "9abfe5a3024425124a8e9cc3b0a7087ad5cad1ff")
  (:PATH "src/index/page-lookup.lisp" :GIT-BLOB
   "9dde416acf27111c21e3f439dd2c948d27517eb7")
  (:PATH "src/index/page-package.lisp" :GIT-BLOB
   "d3f1ff0b939b5a4a1e2df7f22fb04077886220ea")
  (:PATH "src/index/page-read.lisp" :GIT-BLOB
   "0386ec4059fbb6a01d34a137e5bf5a6f44a6f589")
  (:PATH "src/index/page-types.lisp" :GIT-BLOB
   "74a9db44b348db25a046c9250f092a0e03f82ca0")
  (:PATH "src/index/page-validation.lisp" :GIT-BLOB
   "a45eb2aa3d449c9500a95950709cb6019fb8f76b")
  (:PATH "src/index/page-write.lisp" :GIT-BLOB
   "6206be6610c55d48389763a3205ff80ebd79a6d8")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "27c03d2d3e8bfb6b93088bb55bd6e615350261d0")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "83fe7ca83cad1b84f41a579d56bb02ee0bac881e")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "86debb0798063a5e05be0a96f125dece7edd0f0a")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "5afb91ab551d915d29f6630573a17328839cc616")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "099d59bb9acc155380a3baaa3a10816e0902d8ca")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "d054587f29d5108d65704fe8b5b6794178923902")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "7cc651a3e3de17decfe71f3ee9b826dfa7b3ca2f")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "fde846254989ef432159c1ffcfc25fb3f950dbcc")
  (:PATH "src/index/primary-restore.lisp" :GIT-BLOB
   "252bd2cb57700c33fd4ec94749ea6f0b80ae6817")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "179de5b6f466cfcb72c719c49a0e885b5bcf6a12")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "621a82743aceafa1653340330e413bc902c58ebb")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "0187f4d9603d23a6ddb0a76d282af9c811080534")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "589e1557b2906a15c6c874f126968669206ceed9")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "bebb4f103854e0b3dbfc248cae5b82cdeafb0b57")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "ad43248f2f9ec4978a07df5bb696c49a1c055ea7")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "6a55454412edc8466e9c7972f9c81d9a3c945697")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "d42c883908d8a8c9c467342b8977498f38dcf33b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "83bec7e5e8d66f78d9b127c5310b2058b3c3fed6")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "ab3fd8e8abe4fd803038cf11e13c3fef75a8144b")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "0e8ca5847c6683a89cdd47e3476665b1bd46e6da")
  (:PATH "src/io/cpu-build.lisp" :GIT-BLOB
   "0dd046093289729dbc7817a3eeb7dff004f0e9fa")
  (:PATH "src/io/cpu-features.lisp" :GIT-BLOB
   "80653c6c8871127b3d76cc631d47ba0e711b6e5d")
  (:PATH "src/io/cpu-package.lisp" :GIT-BLOB
   "baf8aa6f2ef5231eb6462bca65d83ac1886d09e5")
  (:PATH "src/io/create-relative.lisp" :GIT-BLOB
   "eb4a8c292b30a3083cd256eda697b05737553022")
  (:PATH "src/io/derived-remove.lisp" :GIT-BLOB
   "a0631348bc17fc4e5c1638522be73ae87fa53a97")
  (:PATH "src/io/directory-lock.lisp" :GIT-BLOB
   "f0135b3b43625d9535db6196507b55154d36f852")
  (:PATH "src/io/directory.lisp" :GIT-BLOB
   "8b3fb30b5fa092a5f88ce55cbcf5ebfa6bddf993")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "9b04b83cf53f493aaf75d1c19a6d5f9f4ee0971f")
  (:PATH "src/io/identity-types.lisp" :GIT-BLOB
   "d53f8c4793af7e98dcab62ee5c94571dd8d520a2")
  (:PATH "src/io/identity.lisp" :GIT-BLOB
   "0cb49ca63800c1fc25bee5bf94c2811969511a07")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "9ea7d77f1bccbb7051123ac2e5793d38b770ffbf")
  (:PATH "src/io/namespace.lisp" :GIT-BLOB
   "1f73f6bf5c4b8f12064b515008d6c8f9076518ce")
  (:PATH "src/io/native-create-relative.lisp" :GIT-BLOB
   "9d715484a72332fb056b8102d2277140128b2f59")
  (:PATH "src/io/native-directory.lisp" :GIT-BLOB
   "95ea1018b8693a89e0967f9a7a6dea95542d6005")
  (:PATH "src/io/native-namespace.lisp" :GIT-BLOB
   "599c21713f3d82b6bc9faac71e42a45da0e6cd90")
  (:PATH "src/io/native-open-relative.lisp" :GIT-BLOB
   "d924a8a202ab02406cdae147cfa0cb742a0917e6")
  (:PATH "src/io/native-publish.lisp" :GIT-BLOB
   "d62f716c3965b838e0cdb7a629c78bdf845bbdc2")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "37f1e1782e0e3580447aa0ef56cb0942cfbd0e66")
  (:PATH "src/io/open-relative.lisp" :GIT-BLOB
   "e712b098ddbd883b77382c60b1b511427e8c4db7")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "c0be7a664e6642b7dcc6362d6194090fa9a8290e")
  (:PATH "src/io/publish.lisp" :GIT-BLOB
   "cb759a6c4c6d4b9300c1bb9e1e7b7d781f629f65")
  (:PATH "src/io/readiness.lisp" :GIT-BLOB
   "8ae8de38729e3866227360cc1cf6022c9220490b")
  (:PATH "src/io/rename.lisp" :GIT-BLOB
   "38a7d50880a012266e59eb915edafe64f2047e4e")
  (:PATH "src/io/segment-remove.lisp" :GIT-BLOB
   "8530ef67554d751b20d1004a9af49f20b8fc1861")
  (:PATH "src/io/stabilize-preflight.lisp" :GIT-BLOB
   "290915923be47b7739c3f44560a62f9819c7a26e")
  (:PATH "src/io/stabilize.lisp" :GIT-BLOB
   "504c9dca2fece31bc79f8788f7524d7397a1fee2")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "b66a02dbc2eda6d43388a0946ae46b795efb2a76")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "8e7b3506c6f1da4493bba4817d8b1f6c57585aaf")
  (:PATH "src/local/cli.lisp" :GIT-BLOB
   "801ea182eab95273f82e3b5687605dfbf31aef75")
  (:PATH "src/local/client-conditional-group.lisp" :GIT-BLOB
   "8d12830d12a112368469e0718c0ddfe168b79e7c")
  (:PATH "src/local/client-group.lisp" :GIT-BLOB
   "a55657c6d0e22e5dedf411fe33aa6c2f1c153503")
  (:PATH "src/local/client-read-group.lisp" :GIT-BLOB
   "3ca89d062de82fec20c9410c7149e53a4741755b")
  (:PATH "src/local/client-version.lisp" :GIT-BLOB
   "9880ac8380a3db16e8eb22f70ae63d3d8d7943f2")
  (:PATH "src/local/client.lisp" :GIT-BLOB
   "f44ab49bbccb626b59571aae29deb2920ebc9867")
  (:PATH "src/local/conditional-group-build.lisp" :GIT-BLOB
   "e2ddc3a893bbf3eea01088a464efd73abfa5a6cd")
  (:PATH "src/local/conditional-group-dispatch.lisp" :GIT-BLOB
   "f820570f134d630a00902d502929eb6a385e00e2")
  (:PATH "src/local/conditional-group-read.lisp" :GIT-BLOB
   "a553ce75413332d7663b6068b3adc940976c50c7")
  (:PATH "src/local/dispatch.lisp" :GIT-BLOB
   "39d79ba99a3215d88d5508a1e31e293623bae800")
  (:PATH "src/local/group-build.lisp" :GIT-BLOB
   "428ad39cb77c5e6e5e9328a1ac9e86e27646174a")
  (:PATH "src/local/group-dispatch.lisp" :GIT-BLOB
   "302d9e8be91d13b7602e9102eb4a1022e437e0da")
  (:PATH "src/local/group-read.lisp" :GIT-BLOB
   "ba4b57f80dec489589233d4d62d6d87084600026")
  (:PATH "src/local/group-types.lisp" :GIT-BLOB
   "c16e042f44592838506d24b88bd0aa62278532c9")
  (:PATH "src/local/native.lisp" :GIT-BLOB
   "380f655e5da39eaff4daeef4c6eaf63217762a48")
  (:PATH "src/local/package.lisp" :GIT-BLOB
   "0f17791b74c83f3745e536dc696cc9a2e5895ce2")
  (:PATH "src/local/read-group-dispatch.lisp" :GIT-BLOB
   "36e54c6bc2f11c73dfc9dec62a32f3975ad5edee")
  (:PATH "src/local/read-group-wire.lisp" :GIT-BLOB
   "e959bfb13b654e27f5420bf6abcb9f48197960c3")
  (:PATH "src/local/readiness.lisp" :GIT-BLOB
   "bbc9fce59ab612aa4dd003d90a854506c7b047f1")
  (:PATH "src/local/server.lisp" :GIT-BLOB
   "4e66c50f51bf570605f4b835b9ad766942c3397b")
  (:PATH "src/local/state.lisp" :GIT-BLOB
   "a164a655cecd9a8375008529391f0cc6038abd29")
  (:PATH "src/local/version-dispatch.lisp" :GIT-BLOB
   "861ebbf4facb1fcdde20fea1d5a28ed4ed03faf4")
  (:PATH "src/local/version-wire.lisp" :GIT-BLOB
   "bf2032d91087f0eeb1f947128a005b446b8f6c4c")
  (:PATH "src/local/wire.lisp" :GIT-BLOB
   "95e4ccc5010a4b8261ec0125c281816f85c9faa5")
  (:PATH "src/local/write-group.lisp" :GIT-BLOB
   "3af25a194f451448fd87b37c4b635267386e60f4")
  (:PATH "src/local/write-queue.lisp" :GIT-BLOB
   "739d7a6ba109c153afe9534a98dbe04f21efb844")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "fdeac572e64c3591208a87872b8aa9d520c3bde7")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "74ebd63accc8216dfe5a1794c0e430bb9bccd29e")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "a05a5732511ffca3591110f617e3a19be819b47b")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "158b5a6d1eb171d07bd4f67addc2f4be5495d54b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "06a0af0e813b9c22ce98d523d42c031c79ca3734")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "95f5a8c59ff1fef05bcd3fd220d6a14d9c332d61")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "e5130ba55ee942238a5a98ecc51e07725e1c9655")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "2de7b390c89ab19f8be03767ecb07af8fe1e4fb1")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "172a43f86726ec68af730700c99098d66500ad66")
  (:PATH "src/recovery-active/build.lisp" :GIT-BLOB
   "0fa0e554f7e3aa6990d861dec7cbf8408db28068")
  (:PATH "src/recovery-active/closure.lisp" :GIT-BLOB
   "326b2070076e6e9a8d8ee66567d05b5c19329467")
  (:PATH "src/recovery-active/csn.lisp" :GIT-BLOB
   "42b1279ccd9910816bd8d0887b60bcfe9b6e252a")
  (:PATH "src/recovery-active/frames.lisp" :GIT-BLOB
   "3d01c07ff8118b92e5de7b31ca72b19db5ec72ff")
  (:PATH "src/recovery-active/package.lisp" :GIT-BLOB
   "474cd54f2a31f4ded95fd723b4170bee8addece4")
  (:PATH "src/recovery-active/publication.lisp" :GIT-BLOB
   "38542ec938fd3409d73d7531e90fc6474ef42fad")
  (:PATH "src/recovery-active/query.lisp" :GIT-BLOB
   "e2a5aea0f5a97670cc20a583ed312c89df1c7187")
  (:PATH "src/recovery-active/read.lisp" :GIT-BLOB
   "f801950d67755cd15804ef43f1461d435eda54a6")
  (:PATH "src/recovery-active/resolve.lisp" :GIT-BLOB
   "66f4ada585e085a8403d4cdbc9a3dfee31754bce")
  (:PATH "src/recovery-active/types.lisp" :GIT-BLOB
   "069ca4b815c98d82695dd7eb9337a83c5f35b98b")
  (:PATH "src/recovery-archive-csn/build.lisp" :GIT-BLOB
   "ea5a6abf3d6b0817cfa99db490e9e5df57cb200a")
  (:PATH "src/recovery-archive-csn/package.lisp" :GIT-BLOB
   "bacf4fc95e38a8d0416110c6b87b506d561a7e59")
  (:PATH "src/recovery-archive-csn/preflight.lisp" :GIT-BLOB
   "a7a20c65ba54da28dd88c941736fb374065d580f")
  (:PATH "src/recovery-archive-csn/query.lisp" :GIT-BLOB
   "28f8acd47abad20efb95ec0ea8bd765bfa10baff")
  (:PATH "src/recovery-archive-csn/series.lisp" :GIT-BLOB
   "f8eb49763d533cd34cdf05593d2416a63c5f1d0c")
  (:PATH "src/recovery-archive-csn/types.lisp" :GIT-BLOB
   "d30bb8cb36fd1c64a720073fd3f4b4921e507cad")
  (:PATH "src/recovery-archive/active.lisp" :GIT-BLOB
   "5eb16b6f93d24ac3c6f06af8ed3c005328b457a5")
  (:PATH "src/recovery-archive/build.lisp" :GIT-BLOB
   "81a581f63c21154b8a55f2f429ec28ee32a659b3")
  (:PATH "src/recovery-archive/package.lisp" :GIT-BLOB
   "82c707853b1a5b2b6d657e120c7e0ecb82404134")
  (:PATH "src/recovery-archive/query.lisp" :GIT-BLOB
   "8ae65f7a41d2b4a395d6e6a1829d334dfbe88878")
  (:PATH "src/recovery-archive/read.lisp" :GIT-BLOB
   "07ee8571028ca0ec5f754ec9f8478077650ee48d")
  (:PATH "src/recovery-archive/types.lisp" :GIT-BLOB
   "80d29b79c185d0007d0b0e4baa913ed18ec0524c")
  (:PATH "src/recovery-bootstrap/build.lisp" :GIT-BLOB
   "60d549030aa9d16b823fcb98398f14cd3786f73b")
  (:PATH "src/recovery-bootstrap/package.lisp" :GIT-BLOB
   "29ce39efa53a72cd766810b81a08c9a2f86afc91")
  (:PATH "src/recovery-bootstrap/preflight.lisp" :GIT-BLOB
   "601685cad9fd3829ea36672e86b94952f3fe4493")
  (:PATH "src/recovery-bootstrap/shape.lisp" :GIT-BLOB
   "56e6694b910c05854961e920deeb0da390d4a428")
  (:PATH "src/recovery-bootstrap/stabilize-preflight.lisp" :GIT-BLOB
   "5c05f4f7b52c72cce8f3a086a64c4d190e7de36e")
  (:PATH "src/recovery-bootstrap/stabilize-shape.lisp" :GIT-BLOB
   "649080985356be430b25c841c7d345e9d24cb543")
  (:PATH "src/recovery-bootstrap/stabilize.lisp" :GIT-BLOB
   "2ef2dda4858003135215d7d36f816f4929d214a3")
  (:PATH "src/recovery-checkpoint/build.lisp" :GIT-BLOB
   "c274d47f45d845a6e16049e2a573e8d9d76fbc3a")
  (:PATH "src/recovery-checkpoint/order.lisp" :GIT-BLOB
   "a265f08779f2abc94be058454cf75643c33272ca")
  (:PATH "src/recovery-checkpoint/package.lisp" :GIT-BLOB
   "7b191ecff3dbac6b5f690ad221c68b4762a9f0aa")
  (:PATH "src/recovery-checkpoint/preflight.lisp" :GIT-BLOB
   "61e245a5495de984a94fef573f88d11245e86b71")
  (:PATH "src/recovery-checkpoint/sections.lisp" :GIT-BLOB
   "eb05b6c58fe3131fbd597dff5655e4a476b55092")
  (:PATH "src/recovery-closed/build.lisp" :GIT-BLOB
   "bab6c80812e70ffb31a59f29ffaaa6f90678cea1")
  (:PATH "src/recovery-closed/csn-serie.lisp" :GIT-BLOB
   "078d9bbd66289b667c4273053f706a3a2af120e6")
  (:PATH "src/recovery-closed/csn.lisp" :GIT-BLOB
   "41144f854694ff9338e0067d2f59b3312119c5b2")
  (:PATH "src/recovery-closed/package.lisp" :GIT-BLOB
   "49ac245e2430e719b1d417b91b0ffcd53555e47d")
  (:PATH "src/recovery-closed/publication.lisp" :GIT-BLOB
   "fc512bece4fead39a0c75c943cc5d10bbfb810b4")
  (:PATH "src/recovery-closed/read.lisp" :GIT-BLOB
   "08bcf5a490ceba1ae7a94258f1c0bd9ca148cdaa")
  (:PATH "src/recovery-closed/resolve.lisp" :GIT-BLOB
   "2f107b18e7060dc54e902dbe0363d836285ace5f")
  (:PATH "src/recovery-closed/types.lisp" :GIT-BLOB
   "a403121cd1459db7eb753981a402152615541caa")
  (:PATH "src/recovery-closed/verify.lisp" :GIT-BLOB
   "bac75f2ed61947826ca194cf57f8d2feb003f7fc")
  (:PATH "src/recovery-replay/package.lisp" :GIT-BLOB
   "8639d959e29e9f36270a94831eace49f6535a863")
  (:PATH "src/recovery-replay/read.lisp" :GIT-BLOB
   "05eade0aed1e83cf2df5f5e2bab563d31c95081a")
  (:PATH "src/recovery-replay/resolve.lisp" :GIT-BLOB
   "85eb7133fe1463016604e6a6c9ca26dea7bb5633")
  (:PATH "src/recovery-replay/visit.lisp" :GIT-BLOB
   "0c94187caae5986c8481cf1a8e8bc060db2a7b53")
  (:PATH "src/recovery-selection/frame.lisp" :GIT-BLOB
   "101813cb3536365ac914f10e926f424dec18647e")
  (:PATH "src/recovery-selection/index-preflight.lisp" :GIT-BLOB
   "c3d336e63fbb2b5d972a314a86edd123f050aa7b")
  (:PATH "src/recovery-selection/index.lisp" :GIT-BLOB
   "b4b3488404b09fd1df4f351910043b333c1f355e")
  (:PATH "src/recovery-selection/key.lisp" :GIT-BLOB
   "f751a1ed921903353ab48e52e9fa24d374202ed1")
  (:PATH "src/recovery-selection/package.lisp" :GIT-BLOB
   "9dd583b4bf868183f7555b1e4f7c29f2a13c244c")
  (:PATH "src/recovery-selection/read.lisp" :GIT-BLOB
   "04903a7aa14fe3c332bad4255ff62f87d2e69b77")
  (:PATH "src/recovery-selection/select.lisp" :GIT-BLOB
   "dc4345cbad0fd4223eb50ed2d0ed6bcccb8ec709")
  (:PATH "src/recovery-selection/types.lisp" :GIT-BLOB
   "85930de29d2bc071ea7bbb8677d9aa0ac4e1310e")
  (:PATH "src/recovery-series/build.lisp" :GIT-BLOB
   "41324774ac594767e6931c141858270d2a2125ad")
  (:PATH "src/recovery-series/entry.lisp" :GIT-BLOB
   "a37b7c87eff82670540beb78aa78cb40fab88455")
  (:PATH "src/recovery-series/package.lisp" :GIT-BLOB
   "51f3d64796df1a2180cb977adb8a094e7c7fd94b")
  (:PATH "src/recovery-series/preflight.lisp" :GIT-BLOB
   "0daff10989f88386221d11ff4123384a67092075")
  (:PATH "src/recovery-series/read.lisp" :GIT-BLOB
   "d7ec011280d40883408a816425210f60f4ae4561")
  (:PATH "src/recovery-series/stabilize-preflight.lisp" :GIT-BLOB
   "4e6d9e8047e76ce2fa5324ebca9456d29bd69c2f")
  (:PATH "src/recovery-series/stabilize-set-preflight.lisp" :GIT-BLOB
   "81cc2dcf0e684ccc710e51b221b84c10f057db8f")
  (:PATH "src/recovery-series/stabilize-set.lisp" :GIT-BLOB
   "7fe9646c0721b02d48f8ee99cf3f2e5fa020d4c5")
  (:PATH "src/recovery-series/stabilize.lisp" :GIT-BLOB
   "1fe16c3863409635d882ebce5a9f5abc03ad5ecc")
  (:PATH "src/recovery-series/types.lisp" :GIT-BLOB
   "eb8d4a347b96aca4e5277435fe1361ed794f39b6")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "d7ac44761869f57e333497212510416fd1e794c9")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "58a3e620a8def39d2b24cd210d9283184c247ed2")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "b30dd16f31dcb00316d6983c7cfc5cb2948ce0ee")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "54b5092b76b1c609ee195c44bd9206c1800542c4")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "c7bd0b41e7a84ef73829aeaef3a113f12e7a6031")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "c2fab3b7b2cec568adfe88f0037fc216f83765c9")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "2059363677925a732eb1c70fc1ed1be94d715ea9")
  (:PATH "src/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "7b7f3c4c1bbcd252583249b650f82ab968409e24")
  (:PATH "src/recovery/inventory-directory.lisp" :GIT-BLOB
   "4f253cf7dbe6dad5814749ff53d40759ab882d73")
  (:PATH "src/recovery/inventory-id.lisp" :GIT-BLOB
   "c6dabcd733010fe6966aa1d27656b0760744e55d")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47bc32082a709eb46a5fdb5a5b3011d2c4377f80")
  (:PATH "src/recovery/inventory-sources-build.lisp" :GIT-BLOB
   "149e9ca5fc1bf3ed1f473beb075d5c35b6099886")
  (:PATH "src/recovery/inventory-sources-query.lisp" :GIT-BLOB
   "9742c023b3347d38f678c7a1752a9cc37b665996")
  (:PATH "src/recovery/inventory-sources-types.lisp" :GIT-BLOB
   "b52908d02b1cda451190be58333ef9c9508fddf9")
  (:PATH "src/recovery/inventory-sources.lisp" :GIT-BLOB
   "3619190b49dcbaa32ef4dd2111995df5beace5c5")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "1cbb826a8999579a98e51b9c0ecd1cd6a6ff9661")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "1a98289ea132f2b68309efb3a7552f99a514796e")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "801976598bd390814c4ddfaf00377ee38369405c")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "2ddd4fb6d4c1717a25c369c6a7252f9f80769221")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "9754b563a1d0fbfcda0f306e94b1b6d0257dfb0e")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "43af5d7e8cf2c8465492531133ea9647f614e613")
  (:PATH "src/recovery/manifest-transition.lisp" :GIT-BLOB
   "c871c345eb51367427adbb9bda778a6857a97510")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "40c49f4692e11b4c7f9f55b93bae69210adbdcbb")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "eb0e60664ad7abeefde7a4fc81fa7b3fa38ac57f")
  (:PATH "src/runtime/active.lisp" :GIT-BLOB
   "d7889b0103e18eb47878a88c760cae38de48b3fa")
  (:PATH "src/runtime/build.lisp" :GIT-BLOB
   "4fbf71ebd764f7d90977d027372437e113fdeed3")
  (:PATH "src/runtime/closed-preflight.lisp" :GIT-BLOB
   "5e10ae83ae0e4cd3adbbdae389629a0a854182a2")
  (:PATH "src/runtime/closed-transfer.lisp" :GIT-BLOB
   "3db2e73c10bf24d3931cbf993f240aac45e88e0f")
  (:PATH "src/runtime/closed.lisp" :GIT-BLOB
   "b06f0ae33a9c084c5101cfa5170e358bd4f7fe55")
  (:PATH "src/runtime/package.lisp" :GIT-BLOB
   "5eb61dac53e09bdaf493680967ab65938b6b8f63")
  (:PATH "src/runtime/preflight.lisp" :GIT-BLOB
   "7babef89ceacca9a7c8fac7068b54f653a4a3c58")
  (:PATH "src/runtime/query.lisp" :GIT-BLOB
   "34a7a4ebe5d0baeb93acca991f02a38b0cad2204")
  (:PATH "src/runtime/types.lisp" :GIT-BLOB
   "19fe3cc6004382550ea7939c5bf100d1fcc92607")
  (:PATH "src/scheduler/build.lisp" :GIT-BLOB
   "a55b8e7089ba3880ffa69cee4adb13dc0543069c")
  (:PATH "src/scheduler/lifecycle-build.lisp" :GIT-BLOB
   "7dfa330d606ef9c4dbceeb83845a32e75eb62fe6")
  (:PATH "src/scheduler/lifecycle-read.lisp" :GIT-BLOB
   "3b7ece551dae47957d9350c49285617d60b6ee3f")
  (:PATH "src/scheduler/lifecycle-types.lisp" :GIT-BLOB
   "5a03c1176d6bc019bcd230b0fd665cc48d555395")
  (:PATH "src/scheduler/lifecycle-update.lisp" :GIT-BLOB
   "47d323541ba45f5fb507ebcdb2eae9dd701533a2")
  (:PATH "src/scheduler/lifecycle-worker.lisp" :GIT-BLOB
   "8ae274af549a3464fd5f03d64e3c10ac73145630")
  (:PATH "src/scheduler/package.lisp" :GIT-BLOB
   "cadff5f2e29e7c5b625b95f9387faf29aad02178")
  (:PATH "src/scheduler/policy.lisp" :GIT-BLOB
   "37ed8717cf05ca8f03c06204641f47af18858a7b")
  (:PATH "src/scheduler/pool-claim.lisp" :GIT-BLOB
   "9ba00e2b77cbca2189e947e00b435fb81145668e")
  (:PATH "src/scheduler/read.lisp" :GIT-BLOB
   "ea882e41d231cc0dbafc9eac66bdd1f935433f00")
  (:PATH "src/scheduler/types.lisp" :GIT-BLOB
   "6fcd3d494dc339f8061a64fcce4133b9c86708b3")
  (:PATH "src/scheduler/update.lisp" :GIT-BLOB
   "eb0ad7a3abf119d733ae571d98695980ca4fe694")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "b1aeaa0032d7418cd3c9a7dcbc35add751fb17ce")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "5b189fb0ff0e54abaf72adcb05e5da58ebecb741")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "f81c0946f3e173fa6bf87c24e7c51999afc46363")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "6fd26253982dba01e9eef2702c5f4ede6ba70659")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "95cf61b5df1cdd57975f64a05f890528568046b1")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "79cc08666f83630adba9cab148bb71c2f6d46253")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "f21cae5c4f5cfd94d5d4b6a437ac2ede15750b5d")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "4d09a75d977a0eed0819e7c7d61737d245514b00")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "dee5f67f723edb5ba47b78e68baeee49eb56015c")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "18a29843546af6fc28fa36742a175fc3e6f19e1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "3b6335d3c665f5fe66771242c4d43db3de10b333")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "16700994fa5959633b21d4c7eb21483cd489f0c4")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "2a15783bbd1f5fdd1adb0ae4a045449970f46650")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "d7c667389bf8ad8ec4a04ce2b1bc9ec90e64a54d")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "fd552f6657ade1482eeada765c0880b6afe8a73f")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "6643873870526ee603a5c5b554a91650e5be0e6f")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "028c7b1111e43c0749479067451894b38479a7ec")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "10af1f2b835f387f7c5c69011b712c37bce142f9")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0548df3e81bff3332c67897fc70d7aece4c822ea")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "0e6f1849a77fd2de1109e3576f174f13e2eca665")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "05cb8e127c9384da1c40d21c7566f5d57b705ecf")
  (:PATH "src/verify/order.lisp" :GIT-BLOB
   "d563554aeaddb02585f4e4ad03b739dea5387669")
  (:PATH "src/verify/package.lisp" :GIT-BLOB
   "c98aae86e4bbd9642c2d5481503bf944c88e7811")
  (:PATH "src/verify/read.lisp" :GIT-BLOB
   "913463f4e6529cda367092c7aefe85e8471416c7")
  (:PATH "src/verify/report.lisp" :GIT-BLOB
   "5771c02a6384a61711735571ee64e219bdbc145c")
  (:PATH "src/verify/resources.lisp" :GIT-BLOB
   "48232232f028b479a5839420a42253416f7edffe")
  (:PATH "src/verify/types.lisp" :GIT-BLOB
   "ed2a9617dce5a03c691bc2826a5996f8a3161e2a")
  (:PATH "src/wal/append.lisp" :GIT-BLOB
   "769b86afb5de6d2f706a015e049ea04b63031f79")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "65b17519d6d6e5d9e104bc37b2c4eb4d3b93f132")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "51110c6784e99fc94ddf5a2344e0d85262c297d5")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "ae53e978652629ff407be47d3abe04176626dbb4")
  (:PATH "src/wal/frame.lisp" :GIT-BLOB
   "2f2f1af60a399d9263f15ce4565502da1c70f173")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "17858cffba82609484a6f4a32d082d14ceec1c4b")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "e0ea179069a7b297c7c26f6c294c7d4aea3db671")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "d9f682a05cf5adb22850728a839228f02744c5f2")
  (:PATH "tests/cache/README.md" :GIT-BLOB
   "3836e59b86c5a731e772fbf0a6cca376b14806af")
  (:PATH "tests/cache/guards.lisp" :GIT-BLOB
   "af881fd91c3820ab19d1daa2d56f1fe57257d08f")
  (:PATH "tests/cache/support.lisp" :GIT-BLOB
   "fd829e7352ba878e73df30d979e9558ff6ccba14")
  (:PATH "tests/cache/threads.lisp" :GIT-BLOB
   "ca03c59f0fada09cae8c452fed6490de32d4a3a6")
  (:PATH "tests/ci-catalog.lisp" :GIT-BLOB
   "f99940cde88fc16095679156dd2ca561edab453c")
  (:PATH "tests/codec/cbor-array-write-support.lisp" :GIT-BLOB
   "2a47078354c45a5775f48f6dd8f5d784da7de202")
  (:PATH "tests/codec/cbor-array-write-threads.lisp" :GIT-BLOB
   "43bac6c9604140af2594d85b76c14c3101b6925b")
  (:PATH "tests/codec/cbor-array-write.lisp" :GIT-BLOB
   "b13f58264f3cd97e1947ee52936732a7fcebe672")
  (:PATH "tests/codec/cbor-float-write-support.lisp" :GIT-BLOB
   "5416b62340ae8f3332915f8891529d95549a5fba")
  (:PATH "tests/codec/cbor-float-write-threads.lisp" :GIT-BLOB
   "3b0840150945cd4f118516b1d6d61524fa6856fa")
  (:PATH "tests/codec/cbor-float-write.lisp" :GIT-BLOB
   "747cd8a72445a3ea638cd1910bc9faa63f4cdc33")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-item-read-support.lisp" :GIT-BLOB
   "0326100362a1c4b24d2c7e511e45357f09a56d33")
  (:PATH "tests/codec/cbor-item-read-threads.lisp" :GIT-BLOB
   "a0da65545ed80ede0a967cadbb337731f6fe1ce9")
  (:PATH "tests/codec/cbor-item-read.lisp" :GIT-BLOB
   "b2cbdcb4255c51d9da4fe73b28939c1cb923fefe")
  (:PATH "tests/codec/cbor-map-write-support.lisp" :GIT-BLOB
   "113bfc4529199f69dea1862baec0aa7403c6fa97")
  (:PATH "tests/codec/cbor-map-write-threads.lisp" :GIT-BLOB
   "892d30fd1c7a8f12430c6caa6f43ee872574eb09")
  (:PATH "tests/codec/cbor-map-write.lisp" :GIT-BLOB
   "6ad0e9b5a48ba9c32c46d720f2f7f1821368d6c8")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "532c3f1d5898083364f17f9fc9cbf0da7b798bda")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "d88b573a98689b5e1c0cbade8f8a7ac69470554f")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "0989d7f8e43ec7213df856b842b1e9149df96d9f")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "186f1772335ce33e4e3d1d933bf4d4e91fe0763f")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-read-support.lisp" :GIT-BLOB
   "cfd55cd47d782673113e67af625c1360195a345c")
  (:PATH "tests/codec/cbor-string-read-threads.lisp" :GIT-BLOB
   "c3686d6e47ad56e53db556747ee2d49cea527df5")
  (:PATH "tests/codec/cbor-string-read.lisp" :GIT-BLOB
   "8437bdcaa4cf308dbf4614e748cdab4be2ae6d62")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "66b5d03695f522cca8013ccdad3ede690cc63412")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "16cc32f2c51d28f75a64b93ead642340f88e9c05")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "595d51a96ee3767c13797910ea324061a4788617")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-tag-write-support.lisp" :GIT-BLOB
   "e6e1e91e5ed95019e20b11d2dc0e408911acb46e")
  (:PATH "tests/codec/cbor-tag-write-threads.lisp" :GIT-BLOB
   "1c731f7ed83f703e3d2a8a4c57e6c702ef127887")
  (:PATH "tests/codec/cbor-tag-write.lisp" :GIT-BLOB
   "df97950ec8d24157bb6566c7995262f7beea7742")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "0f66cc1f8b493598d436b1d62d7211f4196fb430")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "7717054be474eba254f3f645fc62ec4ef65a511c")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "0c1a6d9fbe44a95b951a7e1a9aad90f65cef961b")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/control/native.lisp" :GIT-BLOB
   "2107cb66de45ded987c7fb1392155ff6afebbed6")
  (:PATH "tests/control/publication.lisp" :GIT-BLOB
   "f987c9317990ce977ecadb747268b39d2612eba1")
  (:PATH "tests/control/recovery-guards.lisp" :GIT-BLOB
   "b2e877dfcc35468cfafd95f398f33d1415692c1f")
  (:PATH "tests/control/recovery-publication.lisp" :GIT-BLOB
   "cd99169af8aecf204ce9cd2e6e1f2a9fbb081f68")
  (:PATH "tests/control/recovery-read.lisp" :GIT-BLOB
   "21f33af3220a237d7a8dc2ff3a98bfd4c41fa201")
  (:PATH "tests/control/support.lisp" :GIT-BLOB
   "053d81269526d2e7c78181fbe2f8e58ac3f878f3")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/engine/active-arena.lisp" :GIT-BLOB
   "bc3374fac887f4d210b7f3ed661ee38cb22f402e")
  (:PATH "tests/engine/compaction.lisp" :GIT-BLOB
   "4e46ba4400a7af10db08d35e191be80204237234")
  (:PATH "tests/engine/conditional-group.lisp" :GIT-BLOB
   "bb7b7ee3e52c0b3c0ae69c2bdc48de594f0bd945")
  (:PATH "tests/engine/conditional.lisp" :GIT-BLOB
   "dc0a709ca6f298ccb870dc2e57504831c01d4285")
  (:PATH "tests/engine/delta-location.lisp" :GIT-BLOB
   "3ab2c0e5c6d45ed746de955c72192327c525c71c")
  (:PATH "tests/engine/delta.lisp" :GIT-BLOB
   "5160313851bdfa637e80b76095679b9e965f22a7")
  (:PATH "tests/engine/group-append.lisp" :GIT-BLOB
   "39881bdf066184487a19e1d82c3cf834e731257d")
  (:PATH "tests/engine/image-activation.lisp" :GIT-BLOB
   "bb8b9470cae4854efd1336bc5a289d7305faed54")
  (:PATH "tests/engine/image-auto.lisp" :GIT-BLOB
   "19215e89154e8f65ba0e83e21b04d3d069c93a69")
  (:PATH "tests/engine/image-build.lisp" :GIT-BLOB
   "8543c508064d8198957a25f93e6da3c343d6c26a")
  (:PATH "tests/engine/image-discovery.lisp" :GIT-BLOB
   "50891fbd9ded0ece20969b466f24f1f591bd1439")
  (:PATH "tests/engine/image-maintenance.lisp" :GIT-BLOB
   "3b28dcea4388823fe8999b1fd67edb7a0da5343d")
  (:PATH "tests/engine/image-renewal.lisp" :GIT-BLOB
   "01e55612ec38f31fe281c0f1707bf1aa50aa1345")
  (:PATH "tests/engine/images.lisp" :GIT-BLOB
   "7ea979d2249807380c4532acc52e2ad299dcc0ad")
  (:PATH "tests/engine/index-auto-disk.lisp" :GIT-BLOB
   "57efb3be2095d695461717b131b95f2b6c1131f7")
  (:PATH "tests/engine/index-automatic.lisp" :GIT-BLOB
   "d2f9514760932005ab95e12f037606cf0dd94fde")
  (:PATH "tests/engine/lifecycle.lisp" :GIT-BLOB
   "55f8a525a7fb68846724b869d15eee8238924fe3")
  (:PATH "tests/engine/processes.lisp" :GIT-BLOB
   "ec6545a30fd1d4405ceb31c6c05b1c0ceb999711")
  (:PATH "tests/engine/record-cache.lisp" :GIT-BLOB
   "7dc3029e1048aedb7aab3bfb2649a69731e01734")
  (:PATH "tests/engine/rotation.lisp" :GIT-BLOB
   "f0de9a0e81ab82a161ba5e19a0706aae803e63e5")
  (:PATH "tests/engine/support.lisp" :GIT-BLOB
   "4f050bd297add4aff17a15bb24b3f499785018fd")
  (:PATH "tests/engine/write-group.lisp" :GIT-BLOB
   "debeeb853848ef25d28ce1293b2af3648b4b02dc")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "b1e71783b65b85e6253f733098c3153d41c4971c")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ca77be5b92c1cec98860dd5f59b278e9dcaf8ae4")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/fulltext/admission-concurrency.lisp" :GIT-BLOB
   "fbc2b0294a9369c4812bf206f001399be2af0ff3")
  (:PATH "tests/fulltext/admission-guards.lisp" :GIT-BLOB
   "b3475774a8a7f31269ea0e1b33bb659e230f67c7")
  (:PATH "tests/fulltext/admission-lifecycle.lisp" :GIT-BLOB
   "175c3e3bd33b163bc7593066ade68eb426e8e757")
  (:PATH "tests/fulltext/admission-resources.lisp" :GIT-BLOB
   "29ac6bf4b0b392579997b79c10142b2f491a5eb7")
  (:PATH "tests/fulltext/admission-rows-support.lisp" :GIT-BLOB
   "1713cd556e5e37525af25a15b4f5b36474967d88")
  (:PATH "tests/fulltext/admission-rows.lisp" :GIT-BLOB
   "6e2d6c65c8046ad7dee030a4e95330f3ce3993dd")
  (:PATH "tests/fulltext/admission-support.lisp" :GIT-BLOB
   "1eaef196dc555b086cd53584731041bfb97cda59")
  (:PATH "tests/fulltext/admission.lisp" :GIT-BLOB
   "74ed0e49ce0c839cb5e74d854704d21cb8dbbf68")
  (:PATH "tests/fulltext/allocation-threads.lisp" :GIT-BLOB
   "870a308baeed93e1aabb6dc9a88db443592439c0")
  (:PATH "tests/fulltext/analysis-conformance.lisp" :GIT-BLOB
   "ad704e6457ad7873b3eb2feea241da5129962c8f")
  (:PATH "tests/fulltext/analysis-support.lisp" :GIT-BLOB
   "805f7e60fd3f6aa25b4c53680e5251188e57868e")
  (:PATH "tests/fulltext/analysis.lisp" :GIT-BLOB
   "4d529aef551bd365f0c12eb3dffbb7b2960fae56")
  (:PATH "tests/fulltext/codec-corruption.lisp" :GIT-BLOB
   "c62dd05be34d1f653eed8565cc0b40b950bdb97f")
  (:PATH "tests/fulltext/codec-differential.lisp" :GIT-BLOB
   "91b651930dd7f9da36fd317453686d272e0d2c40")
  (:PATH "tests/fulltext/codec-guards.lisp" :GIT-BLOB
   "9f6b8e823ae25c43b767141e0193b908ca0e763a")
  (:PATH "tests/fulltext/codec-support.lisp" :GIT-BLOB
   "890e176db757eed9e2680f5b247a12922709d4b9")
  (:PATH "tests/fulltext/codec.lisp" :GIT-BLOB
   "50b924b1c0e9127da33413f1100bf04ef2ee500d")
  (:PATH "tests/fulltext/document-differential.lisp" :GIT-BLOB
   "78466a8bc1213d0794155535eb28a990a45a38aa")
  (:PATH "tests/fulltext/document-guards.lisp" :GIT-BLOB
   "608f322bd4ac149abb9ffbb352595b5c94d3d217")
  (:PATH "tests/fulltext/document-support.lisp" :GIT-BLOB
   "57d59f345c6cbe8dba253acce7993409b5bbed94")
  (:PATH "tests/fulltext/document.lisp" :GIT-BLOB
   "ab305e31ece6bf7fd20ac5b7ea119b01c57e7c92")
  (:PATH "tests/fulltext/format-guards.lisp" :GIT-BLOB
   "9a23048572dfa5eee314221ced3425a1ea46c28a")
  (:PATH "tests/fulltext/format-support.lisp" :GIT-BLOB
   "d03bd892800d593a3550bdc709d43c357041bfab")
  (:PATH "tests/fulltext/format-threads.lisp" :GIT-BLOB
   "b8e8eb4491b59c721071396ce656eb09186f988d")
  (:PATH "tests/fulltext/format.lisp" :GIT-BLOB
   "b7cb19b82d4e50d457c603b8708693adf27785f0")
  (:PATH "tests/fulltext/index.lisp" :GIT-BLOB
   "0673c32fe456a9cb77cf4aa5cc4e071a888cccf2")
  (:PATH "tests/fulltext/minimum-v2.hex" :GIT-BLOB
   "c4db496b0e5b920665d1c80bea204f6227da1f0e")
  (:PATH "tests/fulltext/put-concurrency.lisp" :GIT-BLOB
   "613b2e5a89d505701583aa9c68e6273f4163d2e7")
  (:PATH "tests/fulltext/put-guards.lisp" :GIT-BLOB
   "6b531c1b143860a46e84d5c77da982f54fbd413b")
  (:PATH "tests/fulltext/put-lifecycle.lisp" :GIT-BLOB
   "8cba90b629299c8494194a73ef8b819f554ca557")
  (:PATH "tests/fulltext/put-physical-guards.lisp" :GIT-BLOB
   "bd293d0ef1d5596e85859cb85e41639b3a0fd70e")
  (:PATH "tests/fulltext/put-physical-native.lisp" :GIT-BLOB
   "635118c4287ab13b4b98e34d04dc307b97497827")
  (:PATH "tests/fulltext/put-physical-support.lisp" :GIT-BLOB
   "1e81cc2af12f24515debc953d4f7884b07a2e197")
  (:PATH "tests/fulltext/put-physical.lisp" :GIT-BLOB
   "f8d1fa41090aaa40c2146ec9280bff08d968fdce")
  (:PATH "tests/fulltext/put-rows.lisp" :GIT-BLOB
   "0ee39c61cdbb6742eb36d65677030d44c96ad98e")
  (:PATH "tests/fulltext/put-support.lisp" :GIT-BLOB
   "2a3c9b543587b1a9c5402a16f82cfc1c671a6160")
  (:PATH "tests/fulltext/put.lisp" :GIT-BLOB
   "83f9503ec4bd1a6610443bb8eea991e6069c6565")
  (:PATH "tests/get-active/append.lisp" :GIT-BLOB
   "0779a03e322f321a930393c5667e11252b84eff5")
  (:PATH "tests/get-active/construction.lisp" :GIT-BLOB
   "ec2831edef2e452597ce867b026eb73c84fc5214")
  (:PATH "tests/get-active/directory.lisp" :GIT-BLOB
   "48c9a60e58536170a610844e853eae6f91beeff1")
  (:PATH "tests/get-active/preflight.lisp" :GIT-BLOB
   "7f41c04257e0bab10a2ffbc091b02d660029c4df")
  (:PATH "tests/get-active/read.lisp" :GIT-BLOB
   "0ab8c2b2b639a51b0217876a896d9468f41e22de")
  (:PATH "tests/get-active/support.lisp" :GIT-BLOB
   "b0a6f9bda4866f82471ec73120182caa786f7d11")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "ced6f8b39836c1c2ff264822ddaf05d0653bfff6")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/lifetime-support.lisp" :GIT-BLOB
   "cd514970e84f8654318dcc23a6b1ef24323be8a9")
  (:PATH "tests/get-directory/lifetime.lisp" :GIT-BLOB
   "c57261d2de469318402d5bf79f5ab5d27108bb46")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/series-read.lisp" :GIT-BLOB
   "b500bb83170622b6d96edbd363ebc85240064c18")
  (:PATH "tests/get-directory/series-support.lisp" :GIT-BLOB
   "ead990e110b588bb4df35ea17d3816db3b79cee5")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "a5b09ee5120bedc4e946366239dd5e6c978b27d2")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "9e03608bef23c0aa5a69dce8c7dfd09ed818a377")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get-resolver/construction.lisp" :GIT-BLOB
   "322c63ee6576304ca1ab19e28b902b680bc2acae")
  (:PATH "tests/get-resolver/read.lisp" :GIT-BLOB
   "a1788d1aab3f76b9dc29095676ec42f3a1f936a8")
  (:PATH "tests/get-resolver/sort.lisp" :GIT-BLOB
   "442ce9eef4fac8f593a9d94ed08a76b830773563")
  (:PATH "tests/get-resolver/support.lisp" :GIT-BLOB
   "11d5cf0efe8ee4f5606707cc7eca175442a50190")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/image-processes.lisp" :GIT-BLOB
   "11c9ba829c73bb71f54be52710ac699b40b47f60")
  (:PATH "tests/index/image-tests.lisp" :GIT-BLOB
   "3ea1eb66179db5125b2b5137372c70c9d953e95f")
  (:PATH "tests/index/mode-policy.lisp" :GIT-BLOB
   "4513fb320a9f1ced973820d8a9c58ee9a0d73ea6")
  (:PATH "tests/index/mode-support.lisp" :GIT-BLOB
   "14d4c82bd54795844d14ac1d7f1b7ced320c4233")
  (:PATH "tests/index/page-build.lisp" :GIT-BLOB
   "bd600c74e28d32328559e9b9f268b4afa3481a55")
  (:PATH "tests/index/page-cache.lisp" :GIT-BLOB
   "aaace9b80ff3c6ce2ab52a3644be8c56eef4ebfd")
  (:PATH "tests/index/page-chains.lisp" :GIT-BLOB
   "265a85cd6aff51dd8a5ceae50f60ff7b8d63660e")
  (:PATH "tests/index/page-corruption.lisp" :GIT-BLOB
   "880775f39ed5c6352c0ae448b7a830ea63b03a85")
  (:PATH "tests/index/page-fixtures.lisp" :GIT-BLOB
   "0ed84fd77dc21375773651e4bb42e56a2c0a5e43")
  (:PATH "tests/index/page-lookup-support.lisp" :GIT-BLOB
   "8800a152c6f0eefa572fda9e17ee9e5e1ff77023")
  (:PATH "tests/index/page-lookup.lisp" :GIT-BLOB
   "290b471927fc1647a000099d8f3f8b57b878c843")
  (:PATH "tests/index/page-support.lisp" :GIT-BLOB
   "920c631d2763260aec7bcb02d3172d8be1d4b21f")
  (:PATH "tests/index/page-tests.lisp" :GIT-BLOB
   "a18f0315e5480a356504f1f541bffc1ad3484fc6")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "d21142f34f3687c35f39c86d962f2c8ffd52c330")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/create-relative-native.lisp" :GIT-BLOB
   "fd5e819e2197869a93259857aacfa68bfe9e9a44")
  (:PATH "tests/io/create-relative-support.lisp" :GIT-BLOB
   "8382ffb8f04b6d2fc3e4adb89f995c9c37b0e445")
  (:PATH "tests/io/create-relative.lisp" :GIT-BLOB
   "7fb4c3665ca1b8f6de2dedd2827cfc150dcddf02")
  (:PATH "tests/io/directory-lock.lisp" :GIT-BLOB
   "4cefd15616f4ac2312a669b1242929d2706eb540")
  (:PATH "tests/io/flush-failure.lisp" :GIT-BLOB
   "76a80588d99b441e8c57a97f9a10d4d9d6c7b59b")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/open-relative-native.lisp" :GIT-BLOB
   "cdb197bf2760de70e7ec49af76e2954a18006997")
  (:PATH "tests/io/open-relative-support.lisp" :GIT-BLOB
   "4256567b2a10423a41540298317c8ef80e6b5af0")
  (:PATH "tests/io/open-relative.lisp" :GIT-BLOB
   "4bec9451a13db1437e081bda2858d4cb8b1e5de1")
  (:PATH "tests/io/readiness.lisp" :GIT-BLOB
   "1a7ce2205d7278a080395a3f4287540e11d3bea4")
  (:PATH "tests/io/rename-native.lisp" :GIT-BLOB
   "99f79041529d20d0ea774b01e3ed82fc5a274cdd")
  (:PATH "tests/io/rename.lisp" :GIT-BLOB
   "e83443eec6187d53118795c4f6ee797112f27ea2")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer-failure.lisp" :GIT-BLOB
   "c87c80fb9c82062bf4d4179d67f710ff10b4f051")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/local/client-group.lisp" :GIT-BLOB
   "a01da9851d2c0dc468d7c7dab4e050000c679e54")
  (:PATH "tests/local/conditional-group-processes.lisp" :GIT-BLOB
   "3fbda41b85d7b3ea69b36b4b9165be82bdbeda00")
  (:PATH "tests/local/conditional-group.lisp" :GIT-BLOB
   "67c45820cbaead998fad90500f697c52d241884b")
  (:PATH "tests/local/explicit-conditional-group.lisp" :GIT-BLOB
   "f1d46ab6c3096c534daf294cd0cdda232e9aaeef")
  (:PATH "tests/local/explicit-conditional-processes.lisp" :GIT-BLOB
   "b985cc28457754bf305fe21882799db24fdaff37")
  (:PATH "tests/local/explicit-group.lisp" :GIT-BLOB
   "d2ab3e8180c6c27791ea29458526fd2e6be732ff")
  (:PATH "tests/local/group-processes.lisp" :GIT-BLOB
   "8a1d7078a5b37124cfa30867860e47f56ed77f00")
  (:PATH "tests/local/native.lisp" :GIT-BLOB
   "b8891b57aa6229995b7c6ee5581d9cde650e3c93")
  (:PATH "tests/local/processes.lisp" :GIT-BLOB
   "937434fd8d56bd4e4a1961d7ee17d8673c4acbb9")
  (:PATH "tests/local/read-group-processes.lisp" :GIT-BLOB
   "818db6481b2d9e2cc1dce4703bba1516a4b88542")
  (:PATH "tests/local/read-group.lisp" :GIT-BLOB
   "31871cfd92a2cd26de0c486ba497e5d547cae864")
  (:PATH "tests/local/server.lisp" :GIT-BLOB
   "049822aa7abc1acf525920011be267d49320a0cf")
  (:PATH "tests/local/version-processes.lisp" :GIT-BLOB
   "33a51023abe1a9a5e7b08926caf8fd2ff2f1e9bc")
  (:PATH "tests/local/version.lisp" :GIT-BLOB
   "52a44805faa6d6356ca17258885a986001231b76")
  (:PATH "tests/local/wire-conditional-group.lisp" :GIT-BLOB
   "05d7bd65c4d204328887e7830bd5eb0def5e5da3")
  (:PATH "tests/local/wire-group.lisp" :GIT-BLOB
   "f1caba660e45e35c58ecf27219d934f5277ccf4c")
  (:PATH "tests/local/wire-read-group.lisp" :GIT-BLOB
   "5ff23c95d4f6e0e3f24c15970423052ec6b16a9a")
  (:PATH "tests/local/wire-version.lisp" :GIT-BLOB
   "11f313bc4d63d5746637fa82215f40293d9eed97")
  (:PATH "tests/local/wire.lisp" :GIT-BLOB
   "349d7df061b5871658ad3fa6a14601bd58f1fa2c")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery-active-checkpoint/guards.lisp" :GIT-BLOB
   "cae7d70c2a5598bb5c3e1256ef4bb8b391656f6f")
  (:PATH "tests/recovery-active-checkpoint/publication.lisp" :GIT-BLOB
   "a996bc5f82f16fe12a74d9bee5962f8d8629f53a")
  (:PATH "tests/recovery-active-checkpoint/semantics.lisp" :GIT-BLOB
   "a4b80a1a678cdc4537ee9d989f178124829e70cb")
  (:PATH "tests/recovery-active-checkpoint/support.lisp" :GIT-BLOB
   "998ab160b939c93797fc90206a9b50f2cf55e452")
  (:PATH "tests/recovery-active/publication.lisp" :GIT-BLOB
   "8a3c4ba88dd7010c65a464d231ebdab2c8c27e67")
  (:PATH "tests/recovery-active/read.lisp" :GIT-BLOB
   "63f52ee0e0ab244ed278562a5d7fbc752b7617e7")
  (:PATH "tests/recovery-active/semantics.lisp" :GIT-BLOB
   "1d3c935a1169904c900461b67adb96f4dfd96b94")
  (:PATH "tests/recovery-active/support.lisp" :GIT-BLOB
   "5ebf9d06ae855b07875aadc10e2a8ac01ba56036")
  (:PATH "tests/recovery-archive-csn/guards.lisp" :GIT-BLOB
   "a6d91274479da64fa689ca370ff495cc96ae0e51")
  (:PATH "tests/recovery-archive-csn/native.lisp" :GIT-BLOB
   "d66af858c855e39c984f1ff8534e6de3c7c7fc88")
  (:PATH "tests/recovery-archive-csn/plan.lisp" :GIT-BLOB
   "b740c77023c500208ff742e02c4d5aebcd44db70")
  (:PATH "tests/recovery-archive-csn/set.lisp" :GIT-BLOB
   "d163bf160241d2225ac3282c1d925aa65e249ab3")
  (:PATH "tests/recovery-archive-csn/support.lisp" :GIT-BLOB
   "0c458a3f6f8aa062c2cc8831834c29159e09762d")
  (:PATH "tests/recovery-archive/active.lisp" :GIT-BLOB
   "ccbaaa3294880905584ad42c0601201fa3a3dc36")
  (:PATH "tests/recovery-archive/guards.lisp" :GIT-BLOB
   "8afea2a3df30099c07badd7d9c0bcf627a5f9a9d")
  (:PATH "tests/recovery-archive/native.lisp" :GIT-BLOB
   "ae8df9ced72f9142ade184ec78bdc576e05593e1")
  (:PATH "tests/recovery-archive/query.lisp" :GIT-BLOB
   "b0a56949ec13ec7c80466ac8b3cecc79c0fc6d63")
  (:PATH "tests/recovery-archive/read.lisp" :GIT-BLOB
   "22d1042700435e2c15e3f610f9ada9c4a8d8d4ed")
  (:PATH "tests/recovery-archive/support.lisp" :GIT-BLOB
   "0cbefaed0f74c8e34e4cea9a359c58f9196f22ad")
  (:PATH "tests/recovery-closed/csn.lisp" :GIT-BLOB
   "754611c3818a0aac26b189392d4024a251439d0c")
  (:PATH "tests/recovery-closed/guards.lisp" :GIT-BLOB
   "344857641ef2206d4d5a800fbb93b834a9f13c4d")
  (:PATH "tests/recovery-closed/publication.lisp" :GIT-BLOB
   "72f179d28936100b91d1847eeb8a24c696552619")
  (:PATH "tests/recovery-closed/read.lisp" :GIT-BLOB
   "0e401337f36768cd63206cbb7b6adf91eeeeb1ef")
  (:PATH "tests/recovery-closed/semantics.lisp" :GIT-BLOB
   "a931be1523c72d49e955aa7708bec6bd3b273be0")
  (:PATH "tests/recovery-closed/support.lisp" :GIT-BLOB
   "15bafc01c04fe1763d9a6580f6ad0bbb1917f40c")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "e6f289d77025dce439787287abc6a4dde0ac69f5")
  (:PATH "tests/recovery/inventory-directory-native.lisp" :GIT-BLOB
   "8f89629becea88fdc74c920a59676412c3a7b976")
  (:PATH "tests/recovery/inventory-directory-support.lisp" :GIT-BLOB
   "c316b3647e7ea5391d687917fe802907f2273bb4")
  (:PATH "tests/recovery/inventory-directory.lisp" :GIT-BLOB
   "ead38feadd94f49276596d0abf989f29d13af497")
  (:PATH "tests/recovery/inventory-id.lisp" :GIT-BLOB
   "1f05c46bfc887984c476bd7673d2b2dde998c44d")
  (:PATH "tests/recovery/inventory-sources-native.lisp" :GIT-BLOB
   "86144ee3fe19ef0f2a54c9760ed193860881ced4")
  (:PATH "tests/recovery/inventory-sources-support.lisp" :GIT-BLOB
   "36b79c4091825c32ffc3aa32a146ee5121881ebc")
  (:PATH "tests/recovery/inventory-sources.lisp" :GIT-BLOB
   "3ffd5a9fb098ab4aeb091a6823fcec68d22c19aa")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest-transition.lisp" :GIT-BLOB
   "cdde7b60edddd974153ee670d859a94993afa367")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/runtime/adoption.lisp" :GIT-BLOB
   "8fbee7f08a25445b66895ae2e329a217070f67f4")
  (:PATH "tests/runtime/bootstrap.lisp" :GIT-BLOB
   "1398120574f95ebaec3c7431a74a35e0ced01652")
  (:PATH "tests/runtime/guards.lisp" :GIT-BLOB
   "a097cc38e13a1ef7369a2ed996d042718cf7312c")
  (:PATH "tests/runtime/native.lisp" :GIT-BLOB
   "e92ba03fb8184a6c95c44269a26a831b714974a1")
  (:PATH "tests/runtime/support.lisp" :GIT-BLOB
   "7d4dc59eab68672512aed0f4ae578436e669fe2e")
  (:PATH "tests/runtime/threads.lisp" :GIT-BLOB
   "2454593a231d5d6bb9ef4318eb06567ce3192d24")
  (:PATH "tests/scheduler/controller.lisp" :GIT-BLOB
   "8e14282e1f42f3b247a5c578d8a683ddc6147381")
  (:PATH "tests/scheduler/dispatch.lisp" :GIT-BLOB
   "6a493f0022ac8c9b6117c2a62df49fa596194c7b")
  (:PATH "tests/scheduler/lifecycle.lisp" :GIT-BLOB
   "874391809401f42a4db81fe544306165f99ceb5d")
  (:PATH "tests/scheduler/pool-begin.lisp" :GIT-BLOB
   "13a239cf97403806a73242abbd5b545440a17645")
  (:PATH "tests/scheduler/pool-chain-support.lisp" :GIT-BLOB
   "a1ea8258495b9a717e1e0ef164133f6b7140f8a5")
  (:PATH "tests/scheduler/pool-chain.lisp" :GIT-BLOB
   "86675c17ea47eff262cb03cdb41e50bcdb82b78e")
  (:PATH "tests/scheduler/pool-claim.lisp" :GIT-BLOB
   "f636ee873deb2cd5347a50c9aec4a6afa16d13c5")
  (:PATH "tests/scheduler/pool-recycle.lisp" :GIT-BLOB
   "3c779589cd7df6ae1146c2ca50b70320093bbf4a")
  (:PATH "tests/scheduler/pool-start.lisp" :GIT-BLOB
   "ec19bb409799e7956e40c34cc9264d02033cfb22")
  (:PATH "tests/scheduler/pool-step.lisp" :GIT-BLOB
   "d0ff803608990744408749722210e812f6268782")
  (:PATH "tests/scheduler/support.lisp" :GIT-BLOB
   "f2301a1adf44c33284aaa1171acd90c5828b0396")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "ef3d4671b3df48b932c1666f8b58fdca4eecbc77")
  (:PATH "tests/series/log-binding.lisp" :GIT-BLOB
   "c116a9169058ddd9e384fda5f52bb5787977e20e")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "257c6f8cf28bdd8408a3363041d621497f4a5f67")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "c3eb1ce7870b81944c23efac9b8cb7f8f4888ba9")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/verify/canonical.lisp" :GIT-BLOB
   "66f603183d98b01acf07228f19bf3025e48254d7")
  (:PATH "tests/verify/cli.lisp" :GIT-BLOB
   "93078b49e212420f81f52083a7b717a163b7727f")
  (:PATH "tests/verify/guards.lisp" :GIT-BLOB
   "d2511620da049cd377a4847e74b82f7200fbebcd")
  (:PATH "tests/verify/observer.lisp" :GIT-BLOB
   "ecc44b603fba3142bc5a069d3d2be22e8e76a55a")
  (:PATH "tests/verify/order.lisp" :GIT-BLOB
   "1e61ba11c977de74cadbe950bc68fe6d3fb11170")
  (:PATH "tests/verify/processes.lisp" :GIT-BLOB
   "feb165176cc6c6661b30453513c21f981cb58113")
  (:PATH "tests/verify/support.lisp" :GIT-BLOB
   "668b4909687394df5b41f27fd0636f22027ca1ab")
  (:PATH "tests/vertical/method.md" :GIT-BLOB
   "3e60572557391e2c772d3b44491ae18eecb352bf")
  (:PATH "tests/vertical/processes.lisp" :GIT-BLOB
   "059fbd2bb702e76e986b97edfbe4d3784599d583")
  (:PATH "tests/vertical/resume.lisp" :GIT-BLOB
   "6f80a0d0fec9f725beca54d06d961932bd815043")
  (:PATH "tests/vertical/scenarios.lisp" :GIT-BLOB
   "fcbc7878d56720604f0e86a916d2e42c0f28cffd")
  (:PATH "tests/vertical/support.lisp" :GIT-BLOB
   "37c2e8d1da68eb425cdd11548f8699c888afd7bf")
  (:PATH "tests/wal/append.lisp" :GIT-BLOB
   "2e0d75a68d6ca657634c22fcb5632d1cf5fa8a1a")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/arcdocdb-verify.lisp" :GIT-BLOB
   "5aed85033d701c64e2c4698fae58dcb947dc80e8")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-float-write-audit.lisp" :GIT-BLOB
   "485544868eeadff247968b86c2d5da9b3b610295")
  (:PATH "tools/cbor-float-write-bench.lisp" :GIT-BLOB
   "d992c9f8cf6ff0d748fcb77f871fb77969480bca")
  (:PATH "tools/cbor-float-write-mutation.lisp" :GIT-BLOB
   "5d0d6bd46b0286f153ee9c482734c659959396e2")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-read-driver.lisp" :GIT-BLOB
   "a6b65bd233dba2a2eec941d96a75b9db948d19f8")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-parallel-tests.lisp" :GIT-BLOB
   "a49a03a64a137e66c07c98f981327fc42d9cb508")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "e3df9f52590ce2de86ad75b872c859b81bbcc518")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "1f63d49150e6b7b23c1df2a9c25c3d2288861b8a")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "253fea1c65c6aacb77fa56f2ab05cce086a1856d")
  (:PATH "tools/ci.lisp" :GIT-BLOB "c0b6255982f4299b883992f5829baaebcd2aaa36")
  (:PATH "tools/ci/archive.lisp" :GIT-BLOB
   "03712985b7cf1493a7009a35965cadf6c9902292")
  (:PATH "tools/ci/conditions-self-test.lisp" :GIT-BLOB
   "99f857163fa38683871790731b6f72448cf92ffb")
  (:PATH "tools/ci/coverage.lisp" :GIT-BLOB
   "233ae46d6ab9fab6a74046140323eecc64243174")
  (:PATH "tools/ci/data-self-test.lisp" :GIT-BLOB
   "b5d6a8f505604e3c45d228582933af38713cc01a")
  (:PATH "tools/ci/data.lisp" :GIT-BLOB
   "8cec68fa2e6e5d7e4484a53cde13964b875f9222")
  (:PATH "tools/ci/github.lisp" :GIT-BLOB
   "a2ca20ed9c586b104f59091d174028b3454d6a10")
  (:PATH "tools/ci/identity.lisp" :GIT-BLOB
   "abf3cc722957379e1408d629b81a2d1916a0788b")
  (:PATH "tools/ci/measure-self-test.lisp" :GIT-BLOB
   "18959f2608b1be4ef1b77b0a7d3b1a67735c16d4")
  (:PATH "tools/ci/measure.lisp" :GIT-BLOB
   "7e16fd5b80a7bbce27a0c856a6abd001ff4814ed")
  (:PATH "tools/ci/producer.lisp" :GIT-BLOB
   "a7fab0bcc8dc6a33ed37acb0d391ec1a73674493")
  (:PATH "tools/ci/publish-self-test.lisp" :GIT-BLOB
   "400b9ba4c1c3fd0e6bd158f3f89bcc58e802c595")
  (:PATH "tools/ci/publish.lisp" :GIT-BLOB
   "d8a212faaa5bba7df102377a70e6cd9d75d7810c")
  (:PATH "tools/ci/self-test.lisp" :GIT-BLOB
   "8b2cfa7eab4f728c70a4f0f6e4a81da3259a9e38")
  (:PATH "tools/ci/support.lisp" :GIT-BLOB
   "b5fe7c565ed0f885b666d8dba836bec4a7ba4c65")
  (:PATH "tools/ci/test-self-test.lisp" :GIT-BLOB
   "518ac77485351807b4b72c0cc7e030821ec81ab0")
  (:PATH "tools/ci/tests.lisp" :GIT-BLOB
   "9c81cf6aec5f89896d9e4ccdcd59ccf1d3c65c6f")
  (:PATH "tools/ci/workflow-self-test.lisp" :GIT-BLOB
   "f0278d9bc21245d6890e52011414627376bca5de")
  (:PATH "tools/collect-command-archive-tests.lisp" :GIT-BLOB
   "49da390b7e170acc9ffdafa78285f215aec75f44")
  (:PATH "tools/collect-command-archive.lisp" :GIT-BLOB
   "d2eb1bd8a62b0fd98ec023243b2a768c19988dc7")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/control-checkpoint-bench.lisp" :GIT-BLOB
   "f631bbb7096359592fde0ae2b4462c2d2067d5a1")
  (:PATH "tools/control-transition-bench.lisp" :GIT-BLOB
   "40fd5a04dc62cced8e688ed30f59e0d810716a43")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/engine-crash.lisp" :GIT-BLOB
   "04c4796c05bdcecf6d8fc83d3ee1eafcf969fed9")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "abd8e62e937c60e9ac68c3ccce904111388bff09")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "f520ecdb46cc94e07d774d39cb73beed380aa867")
  (:PATH "tools/fulltext-codec-fixture.lisp" :GIT-BLOB
   "f6756e030cdde7beaab41a6b38516950f1663c9e")
  (:PATH "tools/fulltext-persistence.lisp" :GIT-BLOB
   "ab0dbf4ec2e5335721818cc03711b92d7d62111d")
  (:PATH "tools/fulltext-qualification.lisp" :GIT-BLOB
   "d649e9cafa96bcb4351bbced5de04bb10352ab85")
  (:PATH "tools/fulltext-unicode-tables.lisp" :GIT-BLOB
   "ba86b196441a40e662f6052e189074eef08b75d5")
  (:PATH "tools/get-active-init-bench.lisp" :GIT-BLOB
   "c62f2bf8ba96c3e80cdd50ba067e4c4df3e5e957")
  (:PATH "tools/get-active-init-mutation.lisp" :GIT-BLOB
   "b2cd809d99d049757156ddf0141997e3b67903b4")
  (:PATH "tools/get-cost-bench.lisp" :GIT-BLOB
   "696d56846ce992f186da2b468f8de55063532b02")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "45897c0afa972a437bbb595493b87dd0c8ed9710")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/get-resolver-coverage.lisp" :GIT-BLOB
   "5ab21d923b68e35adbc177ecd352bb33340f0c07")
  (:PATH "tools/get-series-bench.lisp" :GIT-BLOB
   "2950d4fcb7fc93fbfc7d78c860f0ac43ed984f35")
  (:PATH "tools/get-series-capture.lisp" :GIT-BLOB
   "9c42e23d381751e8140f186f969c6c2ef8d606cf")
  (:PATH "tools/get-series-mutation.lisp" :GIT-BLOB
   "3d3e887ba8e1d90612e561dfffb3d71c486e813b")
  (:PATH "tools/get-throughput-bench.lisp" :GIT-BLOB
   "6554b119583602b9d06b3ff7b2bb9c8104130d79")
  (:PATH "tools/index-image-crash.lisp" :GIT-BLOB
   "01f7cec3a08a55fcf51b4c743e588ad53a0023ae")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/io-completion-mutation.lisp" :GIT-BLOB
   "7fd59fd86e2d477a6b6ee0f7a2142f8ea6b073c6")
  (:PATH "tools/io-rename-bench.lisp" :GIT-BLOB
   "988d259af126212adc2be8fb9ca9acd8755fdce0")
  (:PATH "tools/io-rename-mutation.lisp" :GIT-BLOB
   "dfc691c88e9ab940a065703a223a1c414454b0f2")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/legal-notices.lisp" :GIT-BLOB
   "f120b9660591fd3eda904c9cf0722bddae3f05a0")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "adf3ca235874a2b950e57ea61a719c4c90e9dda8")
  (:PATH "tools/local-client.lisp" :GIT-BLOB
   "1ab2f474ad7db04a3fc8cc6dd7e84a2441498d20")
  (:PATH "tools/local-conditional-group-server.lisp" :GIT-BLOB
   "92145f31ddb22c4e6c205413ad31fdb24fc0dc17")
  (:PATH "tools/local-conditional-request-server.lisp" :GIT-BLOB
   "11ea1128fb278c71bc6cf5b1ed94be5ac6e2513b")
  (:PATH "tools/local-fault-server.lisp" :GIT-BLOB
   "92cd3d6164c6000c181374e3b917bbf1bb83aaa6")
  (:PATH "tools/local-group-server.lisp" :GIT-BLOB
   "924184dbc27702cbf84cf13b0cdb6e0d62a00bb5")
  (:PATH "tools/local-read-loss-server.lisp" :GIT-BLOB
   "56f7401d185564c0bfe9c834742812fc42a4a6a7")
  (:PATH "tools/local-server.lisp" :GIT-BLOB
   "517652d80ad2d4fbbe85be42fa110d4c902d8cf8")
  (:PATH "tools/local-tests.lisp" :GIT-BLOB
   "02aace929b7f5e2fd790c02d1557628ea17d7afc")
  (:PATH "tools/local-version-loss-server.lisp" :GIT-BLOB
   "89f4ed52dd4f7de5b0b4ac2420f3aaef78618a41")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/measure-pool-begin.lisp" :GIT-BLOB
   "e3094d9f35efdaa647751f19a7acda00c36d515a")
  (:PATH "tools/measure-pool-claim.lisp" :GIT-BLOB
   "712a4a5393b69539f02cd625223918e404b331d3")
  (:PATH "tools/measure-pool-dispatch.lisp" :GIT-BLOB
   "bddb449176d3b7b6ae946e841a0ca3202e6c28ef")
  (:PATH "tools/measure-pool-lifecycle.lisp" :GIT-BLOB
   "3a229eecc3c158cec9af8fad6abd5fc2d980e2dd")
  (:PATH "tools/measure-pool-recycle.lisp" :GIT-BLOB
   "cb20f6d271889a9801106daf230ee934aaa7bf81")
  (:PATH "tools/measure-pool-start.lisp" :GIT-BLOB
   "e6be453833925b89cdc49303b99a23374f3b2689")
  (:PATH "tools/measure-pool-step.lisp" :GIT-BLOB
   "cdcb410e27475282d157b0d64a4656ea6ad069a1")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/pages/bootstrap.lisp" :GIT-BLOB
   "a9cf9ea45672b576b76acf1e4773c2c2949bc2ca")
  (:PATH "tools/pages/build.lisp" :GIT-BLOB
   "e319acad4fe5bf1f9cd14b65772775c95ab632fe")
  (:PATH "tools/pages/check.lisp" :GIT-BLOB
   "b0524f02c494e61f4edf08aa2802ba1a3d16cd66")
  (:PATH "tools/pages/code-reference.lisp" :GIT-BLOB
   "16bf45ca14cc936283e32700698e696f4a36a09c")
  (:PATH "tools/pages/code-source.lisp" :GIT-BLOB
   "8ba99903d3afdae918fd8966410fbbaf7438066f")
  (:PATH "tools/pages/code-tests.lisp" :GIT-BLOB
   "1f1349e749863b14d9690a33dda48537d96434e3")
  (:PATH "tools/pages/dependencies.lock.lisp" :GIT-BLOB
   "f0f339aabf9998e7f910f8904744549766426ec6")
  (:PATH "tools/pages/editorial.lisp" :GIT-BLOB
   "f5a43b2ba1a876c3643ad4b3b64b43096c193b49")
  (:PATH "tools/pages/generate.lisp" :GIT-BLOB
   "56ee4dcf36cc76e82b3997357630eca1083dadff")
  (:PATH "tools/pages/markdown.lisp" :GIT-BLOB
   "a6ce370b0cbbeb2869c88112b69ee7aa38e7effa")
  (:PATH "tools/pages/model.lisp" :GIT-BLOB
   "bed6a6fb53b8efb13020bcf5cc5d1ec27aa31436")
  (:PATH "tools/pages/publication.lisp" :GIT-BLOB
   "8154535b76733cbdd33b3217744481635860a5a0")
  (:PATH "tools/pages/runtime-check.lisp" :GIT-BLOB
   "f9ab88e954f1b07f9c59594f55e67e909ee5f2e3")
  (:PATH "tools/pages/site.css" :GIT-BLOB
   "8069a0942d7ce79b272d8011c4f6c6002aae07e1")
  (:PATH "tools/pages/site.js" :GIT-BLOB
   "06770c92736cc6bd2b3e0c9638ec09f5c0dcc1c3")
  (:PATH "tools/pages/tests.lisp" :GIT-BLOB
   "d05b62748b36cefed5977d1a445c18e1d70b8e62")
  (:PATH "tools/pages/theme.lisp" :GIT-BLOB
   "547ef0acc0e6070c7fcd53385b0efed1aec5f82d")
  (:PATH "tools/pages/third-party-notices.lisp" :GIT-BLOB
   "907abf85677565bb547a4b7f0e7c6311b3bfa3ce")
  (:PATH "tools/pages/third-party-notices.txt" :GIT-BLOB
   "68ebcf8172dcbbf0865767f5194abb97911a83ef")
  (:PATH "tools/pool-controller-bench.lisp" :GIT-BLOB
   "cf6f31dd9c7a8d7f4e7cc1f19c4b9c5a48af6d55")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "068090ec38864b2b55877918aec57375312ee8db")
  (:PATH "tools/recovery-active-bench.lisp" :GIT-BLOB
   "9c11d5654a6168c27c64abcc8f852673c5974515")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/vertical-crash.lisp" :GIT-BLOB
   "8f920374d5b1049f5bac1e8dfb441099575de6cd")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :WALL-SECONDS 38.65468d0 :FINISHED-AT-UNIVERSAL-TIME 4002523979
 :SCHEMA-VERSION 1 :KIND :COMMAND-VERIFICATION :ENVIRONMENT
 (:LISP #A((4) BASE-CHAR . "SBCL") :VERSION #A((5) BASE-CHAR . "2.6.9") :OS
  #A((6) BASE-CHAR . "Darwin") :OS-VERSION #A((6) BASE-CHAR . "27.2.0")
  :MACHINE #A((5) BASE-CHAR . "ARM64") :CPU "Apple M4" :MEMORY-BYTES
  17179869184 :LOGICAL-CPUS 10 :EXTERNAL-LOAD-STATUS :UNCONTROLLED
  :LOAD-AVERAGE "{ 3.15 4.24 5.77 }" :COMMIT
  "636166661e638855e5c512165d61f38e5c1a796a" :WORKING-TREE "M CHANGELOG.md
 M arcdocdb.asd
 M docs/adr/README.md
 M docs/implementazione/README.md
 M docs/implementazione/production-engine-bootstrap.md
 M docs/implementazione/production-unix-m1.md
 M docs/lisp-api.md
 M docs/tracciabilita/matrice.md
 M docs/tracciabilita/requisiti.lisp
 M src/local/client.lisp
 M src/local/dispatch.lisp
 M src/local/group-types.lisp
 M src/local/package.lisp
 M src/local/server.lisp
 M src/local/state.lisp
 M src/local/wire.lisp
 M src/local/write-group.lisp
 M tests/local/client-group.lisp
 M tests/local/wire-read-group.lisp
 M tests/local/wire-version.lisp
?? docs/adr/0087-explicit-conditional-unix-groups.md
?? spikes/results/2026-11-01-local-conditional-groups/
?? src/local/client-conditional-group.lisp
?? src/local/conditional-group-build.lisp
?? src/local/conditional-group-dispatch.lisp
?? src/local/conditional-group-read.lisp
?? tests/local/explicit-conditional-group.lisp
?? tests/local/explicit-conditional-processes.lisp
?? tests/local/wire-conditional-group.lisp
?? tools/local-conditional-request-server.lisp"
  :CWD
  #A((74) BASE-CHAR
     . "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/")
  :DATE-UNIVERSAL-TIME 4002523941)
 :COMMAND
 (#A((22) BASE-CHAR . "/opt/homebrew/bin/sbcl")
  #A((10) BASE-CHAR . "--noinform") #A((13) BASE-CHAR . "--no-userinit")
  #A((12) BASE-CHAR . "--no-sysinit") #A((8) BASE-CHAR . "--script")
  #A((74) BASE-CHAR
     . "spikes/results/2026-11-01-local-conditional-groups/get-repeat/get-run.lisp")
  #A((5) BASE-CHAR . "--run"))
 :STATUS :OK :STARTED-AT-UNIVERSAL-TIME 4002523941 :SOURCE-BLOBS-BEFORE
 ((:PATH ".gitattributes" :GIT-BLOB "d22cbb201cb1d3384baa7e8422aa9d6ee8aea1f9")
  (:PATH ".github/ISSUE_TEMPLATE/config.yml" :GIT-BLOB
   "0086358db1eb971c0cfa8739c27518bbc18a5ff4")
  (:PATH ".github/ISSUE_TEMPLATE/decisione-architetturale.md" :GIT-BLOB
   "4ed9445eb02f439a3c781878622809125ed924e6")
  (:PATH ".github/PULL_REQUEST_TEMPLATE.md" :GIT-BLOB
   "711b96fd6fb677d15473213023c40c35affb47c0")
  (:PATH ".github/actions/setup-sbcl/README.md" :GIT-BLOB
   "ea5cf67447809b2e413026d50e2f61609cb9e438")
  (:PATH ".github/actions/setup-sbcl/action.yml" :GIT-BLOB
   "80da41aac60230141d5d2d0819c9b6c2c3b3ce91")
  (:PATH ".github/ci-toolchain.lock.lisp" :GIT-BLOB
   "c01b06c5b208014ab30bb000dc10acfc9e72cc89")
  (:PATH ".github/workflows/ci-results.yml" :GIT-BLOB
   "d5029660830b7dbef56d6648bbf0a9bbaa400c56")
  (:PATH ".github/workflows/ci.yml" :GIT-BLOB
   "49fc8ba897e94dc36c31d973e6e12efeab51b715")
  (:PATH ".github/workflows/docs.yml" :GIT-BLOB
   "6eef2de086d133233892870f80f5771f90ab1676")
  (:PATH ".gitignore" :GIT-BLOB "a3a191b534821cfe86f062a09dbc2cb19ba153bf")
  (:PATH "CHANGELOG.md" :GIT-BLOB "465c726575f999f8d0a7965562735da3475f7299")
  (:PATH "CONTRIBUTING.md" :GIT-BLOB
   "bc7dba35611947cb7c1e9fb898e294b00f9f2de1")
  (:PATH "LICENSE" :GIT-BLOB "aa9c159fc3ef804068ce29d1bb990d0010eedb00")
  (:PATH "Makefile" :GIT-BLOB "20743e1dd5a32d14e0af066e27987eaa16c94964")
  (:PATH "README.md" :GIT-BLOB "9e6430d753813af59152d82a3959a45d70abfa94")
  (:PATH "SECURITY.md" :GIT-BLOB "331a1316c300159882e3a30f9f2c8575a8e586a9")
  (:PATH "THIRD-PARTY-NOTICES.txt" :GIT-BLOB
   "0c5bc85db048fb8970c3cc42fb128337eff77e39")
  (:PATH "arcdocdb.asd" :GIT-BLOB "f0f8de2af5e37d6a1e1b64ba7a98ac7091963722")
  (:PATH "assets/README.md" :GIT-BLOB
   "c30d58ba88d9dd9f146df6f03aeedbdea3df5c72")
  (:PATH "assets/img/flow-dark.svg" :GIT-BLOB
   "daae22922420bfde91c8ce8c313343c03c045d17")
  (:PATH "assets/img/flow-light.svg" :GIT-BLOB
   "d3e0bf360226c3d05b603aef74cf022177d9f213")
  (:PATH "assets/img/hero-dark.svg" :GIT-BLOB
   "a024e50336c5d93b7619048432219020d84eb688")
  (:PATH "assets/img/hero-light.svg" :GIT-BLOB
   "0bb1c4dcc1aef96287b5edf18db288467e37f9c1")
  (:PATH "assets/img/mark-dark.svg" :GIT-BLOB
   "2402f3bf0362118bba64640d64382ac5e86a20e0")
  (:PATH "assets/img/mark-light.svg" :GIT-BLOB
   "58ee962d4dffe098eaff67a88e6533b46d1fae53")
  (:PATH "assets/img/social.png" :GIT-BLOB
   "82582b11d03a6b1e447af3aeec37545fcc4067bd")
  (:PATH "assets/img/social.svg" :GIT-BLOB
   "6a4f2b2dc8c1325ec78b5736df18a97e701709c2")
  (:PATH "data/unicode/18.0.0/CaseFolding.txt" :GIT-BLOB
   "9ee0a2dd654f6fa520cd932be19ac5c00ffacded")
  (:PATH "data/unicode/18.0.0/DerivedNormalizationProps.txt" :GIT-BLOB
   "32227e8f297e96f98954281d99c38839a7834d7c")
  (:PATH "data/unicode/18.0.0/LICENSE.txt" :GIT-BLOB
   "56da58912807030b451a4700687d5bd02c72d6ed")
  (:PATH "data/unicode/18.0.0/NormalizationTest.txt" :GIT-BLOB
   "730c1a013ac78f6a63118e670c72556d4f112eab")
  (:PATH "data/unicode/18.0.0/README.md" :GIT-BLOB
   "06ab2a1368779a5535c48e90a7e2fb77e44080c9")
  (:PATH "data/unicode/18.0.0/ReadMe.txt" :GIT-BLOB
   "aa18f7175c4a46df644c7c6435ad95a8ad3cd724")
  (:PATH "data/unicode/18.0.0/UnicodeData.txt" :GIT-BLOB
   "ebccf021c4fcf31c2ecbb9bd7da3f5eb7ed44851")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakProperty.txt" :GIT-BLOB
   "313ae91aad579445a1e06556a1d7a2edd0c782a2")
  (:PATH "data/unicode/18.0.0/auxiliary/WordBreakTest.txt" :GIT-BLOB
   "8d734a2690b9f06018e02b0b4f165acc4d0d2853")
  (:PATH "data/unicode/18.0.0/emoji/emoji-data.txt" :GIT-BLOB
   "7a383f0dcfd6ad65a2b7b5e90f701e38485f151f")
  (:PATH "docs/01-visione-e-obiettivi.md" :GIT-BLOB
   "a677288d5fd65a8de671c8cb513fef7c9cb013d5")
  (:PATH "docs/02-modello-logico.md" :GIT-BLOB
   "0f68efcd275602bc60b1ee3a2a104f8a49bc6b80")
  (:PATH "docs/03-storage.md" :GIT-BLOB
   "1445703c53c2f1b82ced7dd78f34ad4ab8aae7d1")
  (:PATH "docs/04-wal-e-durability.md" :GIT-BLOB
   "3c1c28fb8949660be6391180be187f55d14d5bb6")
  (:PATH "docs/05-transazioni.md" :GIT-BLOB
   "4c0ad12a7532b5d518b0581301f28a3601228d94")
  (:PATH "docs/06-mvcc-e-snapshot.md" :GIT-BLOB
   "fce97d7d8c70a6c8f5425cd47ade5a2db5892a11")
  (:PATH "docs/07-compaction.md" :GIT-BLOB
   "d3973b8d3cca6c9df25ab1c2e76c305bdc28c51b")
  (:PATH "docs/08-indici.md" :GIT-BLOB
   "85c9f51f242e4e5c3239edb58eea0a3ae0013011")
  (:PATH "docs/09-cache.md" :GIT-BLOB
   "5e10ff0c486bc5e08163bcd5df5bd5736de102f0")
  (:PATH "docs/10-concorrenza-e-scheduling.md" :GIT-BLOB
   "8720f145cca1d03da5446c5398ad4417a6243a18")
  (:PATH "docs/11-recovery.md" :GIT-BLOB
   "30462b46bdd4dffdc7a8217adb6ec89571bf8b89")
  (:PATH "docs/12-osservabilita.md" :GIT-BLOB
   "c05d0f0f5f69c9ddd9a85769c4bb11cc5a921c75")
  (:PATH "docs/13-benchmark.md" :GIT-BLOB
   "4ccdd9d66495ccff8d47d70ab80b04fa3bc601ca")
  (:PATH "docs/14-fault-injection.md" :GIT-BLOB
   "b6a6a520f82271f96513a10457ad400c3f86f2bd")
  (:PATH "docs/15-ottimizzazioni-native.md" :GIT-BLOB
   "b75830dd78d106f8db76e65c08d4e8f3b2a488e4")
  (:PATH "docs/16-moduli.md" :GIT-BLOB
   "d102ba1c248c77c71c437e46675cd5fc913fcdc5")
  (:PATH "docs/README.md" :GIT-BLOB "db925522d2e683e87137b5f3bca8d234cfe435bc")
  (:PATH "docs/adr/0000-modello.md" :GIT-BLOB
   "641a7c9e540ff2ec1136bcaa53c6558691578577")
  (:PATH "docs/adr/0001-common-lisp-sbcl.md" :GIT-BLOB
   "85d24f91157ac79e6af8c3ac908ca03921913922")
  (:PATH "docs/adr/0002-serie-unita-di-storage-e-parallelismo.md" :GIT-BLOB
   "9baef4c50046aca7c2d9740896af96a9dc5974f3")
  (:PATH "docs/adr/0003-wal-per-serie.md" :GIT-BLOB
   "c949015de0fa3a2c25e597b523cb9a00409549b7")
  (:PATH "docs/adr/0004-storage-append-only-un-solo-active.md" :GIT-BLOB
   "dd5d59a612a804976a08a475b0cce0de5daba1e3")
  (:PATH "docs/adr/0005-writer-logico-per-serie.md" :GIT-BLOB
   "49c294e438f29b383bc825210ba12f070f24a7a1")
  (:PATH "docs/adr/0006-transazioni-multiserie-2pc.md" :GIT-BLOB
   "b56195d0f7f43e7bdb91a3af0d1a33f161b8d36e")
  (:PATH "docs/adr/0007-clean-e-merge-distinti.md" :GIT-BLOB
   "26cb290c6bed61bf397cf4f9dbad7ca81d97e8b0")
  (:PATH "docs/adr/0008-merge-opportunistico.md" :GIT-BLOB
   "289e40fc2198e9295b90cddd5444d061cccdacfc")
  (:PATH "docs/adr/0009-indici-immutabili-atomic-swap.md" :GIT-BLOB
   "570458150a9f118174d72cbf90b0b13400237997")
  (:PATH "docs/adr/0010-cache-clock.md" :GIT-BLOB
   "86c3d28f5a8ecdcf0dbbff34e5eeddf69bea5c48")
  (:PATH "docs/adr/0011-thread-pool-dinamico.md" :GIT-BLOB
   "3a490fbb3a23a5de59e08a86b5d656e559ec3696")
  (:PATH "docs/adr/0012-simd-guidato-dai-benchmark.md" :GIT-BLOB
   "c6b0803782b4595bce94f73f37bfb3de06ef58e3")
  (:PATH "docs/adr/0013-log-structured-segmento-active-come-log.md" :GIT-BLOB
   "811067eb4311ef4ed3c3b5450325345c04d444e4")
  (:PATH "docs/adr/0014-formato-record-documento-id.md" :GIT-BLOB
   "c863c2471e2f6e2b6bb0cb79f9c303dda902f572")
  (:PATH "docs/adr/0015-primary-index-swiss-table-swmr.md" :GIT-BLOB
   "5117c423e298e8aee4e02b2daea95cdfa6747784")
  (:PATH "docs/adr/0016-epoch-based-reclamation.md" :GIT-BLOB
   "813ecfb7741a73bbe4065c0914eab22495bbca3e")
  (:PATH "docs/adr/0017-piattaforma-e-io.md" :GIT-BLOB
   "c5fc54a10372cec9bbf1fd3cbb436a6e835cd079")
  (:PATH "docs/adr/0018-control-log-manifest-swap.md" :GIT-BLOB
   "08a71d783f74d8dc0c02db312902f4256668d49d")
  (:PATH "docs/adr/0019-durability-e-group-commit-pipelined.md" :GIT-BLOB
   "085506a53a59d44f70b63f9f550df428a1f7c564")
  (:PATH "docs/adr/0020-csn-snapshot-isolamento.md" :GIT-BLOB
   "6399188b2711a8860f5895fb92dfabb34fa2dafa")
  (:PATH "docs/adr/0021-2pc-intenti-outcome.md" :GIT-BLOB
   "13e62eb82f21f3b5490511d47823439541edba33")
  (:PATH "docs/adr/0022-registri-come-serie-catalogo.md" :GIT-BLOB
   "7785da60ce293bc328817518fbf2be3f9ab9a7b8")
  (:PATH "docs/adr/0023-politiche-di-compaction.md" :GIT-BLOB
   "57f594b6143b04e40bc3fea9394ebe938ca799ee")
  (:PATH "docs/adr/0024-memoria-e-gc.md" :GIT-BLOB
   "6b41728bd67274b11b1fde42cfb6ac2b71b0340b")
  (:PATH "docs/adr/0025-cache-per-location.md" :GIT-BLOB
   "0ec3e4cb8daeb741d6be9428099f1da284b0f895")
  (:PATH "docs/adr/0026-indici-secondari-segmentati.md" :GIT-BLOB
   "50cded21f18bd019fc190b08edb348945d05829f")
  (:PATH "docs/adr/0027-dipendenze-e-test.md" :GIT-BLOB
   "e0e408989c0d8b1a8594a31a9f4cda888232b8c7")
  (:PATH "docs/adr/0028-target-e-obiettivi-di-latenza.md" :GIT-BLOB
   "51ecdb8e1af48f87cd2e53d8c3c334b4a4dd7062")
  (:PATH "docs/adr/0029-interfacce-protocollo-query-contratto.md" :GIT-BLOB
   "8589ad553a5b18f96e5dbab682a024f90b671c2e")
  (:PATH "docs/adr/0030-scope-v1.md" :GIT-BLOB
   "138cf9abbe606df8f544a669069ed94844c9960f")
  (:PATH "docs/adr/0031-software-critico-criteri-e-priorita.md" :GIT-BLOB
   "c6ee53cf623ad6294ab2ab7e46ee16a3304dfdda")
  (:PATH "docs/adr/0032-seqlock-a-64-bit.md" :GIT-BLOB
   "0af09ca66b38c35361d30ddbd028a0cb7fcac4e8")
  (:PATH "docs/adr/0033-fail-stop-e-integrita-end-to-end.md" :GIT-BLOB
   "98cad23c9c529f3f83ccf02dc9bd1a4cb1e6f318")
  (:PATH "docs/adr/0034-policy-di-compilazione-e-standard-di-codifica.md"
   :GIT-BLOB "2d7ba68f4a56fa80700825d44f2b4335b4d342f4")
  (:PATH "docs/adr/0035-strategia-di-verifica-e-tracciabilita.md" :GIT-BLOB
   "5150eca7a1e85c342e20519179c0560e19c816c4")
  (:PATH "docs/adr/0036-leggi-di-progetto.md" :GIT-BLOB
   "3aa06135165157067c6eaf64d8317a43d32086f6")
  (:PATH "docs/adr/0037-lotto-sigillato.md" :GIT-BLOB
   "b352146cf5138b099155a819a2c0c19780a31af7")
  (:PATH "docs/adr/0038-orizzonte-di-visibilita.md" :GIT-BLOB
   "05cc183bb8bd0b7b468a7225065c4dc75dd6cd33")
  (:PATH "docs/adr/0039-cornice-unica-dei-record.md" :GIT-BLOB
   "452553489ad4b466a118e5ec3f08a79223ba7f69")
  (:PATH "docs/adr/0040-manifest-a-record-unico.md" :GIT-BLOB
   "7323f9c4e7d6a41ee0e8edbc7c21f6c40fae7258")
  (:PATH "docs/adr/0041-multiserie-segmenti-autosufficienti.md" :GIT-BLOB
   "c12ccb4a82f5e97c40c2e2df05f085c28f9356af")
  (:PATH "docs/adr/0042-tombstone-e-indice-dei-vivi.md" :GIT-BLOB
   "c5ccb103deb265db77ca14be9e4fb60ebb7395f3")
  (:PATH "docs/adr/0043-primary-index-a-frammenti.md" :GIT-BLOB
   "d0ce5bcc0bbfbf2fa92187bbd09d0ff320d54e69")
  (:PATH "docs/adr/0044-cache-acceleratore-puro.md" :GIT-BLOB
   "a52656154964c4588477288a15fb10284ac888a4")
  (:PATH "docs/adr/0045-modello-di-esecuzione.md" :GIT-BLOB
   "d23b7ee9ef2e3e178a663dbfb004ccc8fed2c542")
  (:PATH "docs/adr/0046-orizzonte-con-registro-limitato.md" :GIT-BLOB
   "2c0669b7a0226ff342e15158899a06d75a30abbc")
  (:PATH "docs/adr/0047-verifica-csn-dei-record-prepared.md" :GIT-BLOB
   "5ba95841ff8f467ed496f51101ddd832dca4fab1")
  (:PATH "docs/adr/0048-limiti-documentali-e-formato-v2.md" :GIT-BLOB
   "2787435e8647b4c1702b7fb4f35f40cd64197fa0")
  (:PATH "docs/adr/0049-capacita-oltre-la-ram.md" :GIT-BLOB
   "18cf324a65ccb0d7684d357bbb8eeb6aeed6a11a")
  (:PATH "docs/adr/0050-pubblicazione-e-costi-della-directory.md" :GIT-BLOB
   "6754d79f26141153b55bbe1bcaa4a82825f95700")
  (:PATH "docs/adr/0051-presentazione-della-documentazione.md" :GIT-BLOB
   "fd7e70d402194978a3ffdad705318afb0431f04e")
  (:PATH "docs/adr/0052-header-dei-log-di-controllo.md" :GIT-BLOB
   "2c3d966a83d6f5c1ba122e38ee510b5277a1e89e")
  (:PATH "docs/adr/0053-ricerca-full-text-indici-invertiti.md" :GIT-BLOB
   "ed37b13d26276ccec88bc4eb7e9259bc8ea270a0")
  (:PATH "docs/adr/0054-contratto-e-formato-full-text.md" :GIT-BLOB
   "239a1b5bbb0be77e0a60cb3f0360d8f4906d0b46")
  (:PATH "docs/adr/0055-interfaccia-locale-unix-socket.md" :GIT-BLOB
   "3a1a8acc98918b9eff3f9c319da1d089bd55bf1b")
  (:PATH "docs/adr/0056-sessione-locale-m16.md" :GIT-BLOB
   "09aa317be40281eb6dfeedfb16c27bf4ee227782")
  (:PATH "docs/adr/0057-selezione-automatica-indice.md" :GIT-BLOB
   "dd056fe207e34cc13582ef67686f5cef50da0d52")
  (:PATH "docs/adr/0058-pagine-indice-primario.md" :GIT-BLOB
   "aace2fae9377ecc39befa24f30a71fa3544aa82f")
  (:PATH "docs/adr/0059-crc32c-arm64-sbcl.md" :GIT-BLOB
   "8abf118f525ac8e4bfb3657e7b9c2389825e3734")
  (:PATH "docs/adr/0060-crc32c-caricamento-portabile.md" :GIT-BLOB
   "e525cdb37bc853b13c077a139869132a6c8a3296")
  (:PATH "docs/adr/0061-conservazione-esterna-delle-prove.md" :GIT-BLOB
   "f72ff61077518b492f247dde021f8ae8d5749777")
  (:PATH "docs/adr/0062-cronologia-git-due-commit.md" :GIT-BLOB
   "d17a19b8086aeb412bb8622fe8dc5301fd3265d0")
  (:PATH "docs/adr/0063-immagini-sigillate-indice-primario.md" :GIT-BLOB
   "6bf24e2c250857907d5d36e6ea7f2d93cf2dcf63")
  (:PATH "docs/adr/0064-adozione-indice-paginato-m1.md" :GIT-BLOB
   "8b4f945e8e06c194b517c1563c2a78fe1ddbd609")
  (:PATH "docs/adr/0065-costruzione-immagini-dal-motore.md" :GIT-BLOB
   "09314a89fa7875d648062095cfd24081055e34f5")
  (:PATH "docs/adr/0066-attivazione-seriale-immagini-m1.md" :GIT-BLOB
   "ca6fd5d38685053ceb12922973a932f72fce5fd8")
  (:PATH "docs/adr/0067-delta-seriale-indice-m1.md" :GIT-BLOB
   "03ea9916428820920370aaeef7c422b0478d3b4e")
  (:PATH "docs/adr/0068-rinnovo-seriale-immagini-m1.md" :GIT-BLOB
   "2240c84c7e57c86d33df08772b173cc9d0d11aba")
  (:PATH "docs/adr/0069-manutenzione-a-soglie-delta-m1.md" :GIT-BLOB
   "7433e9b73ae1548f198181002505a8aabec65ceb")
  (:PATH "docs/adr/0070-scoperta-readonly-immagini-m1.md" :GIT-BLOB
   "f4a496e4556b220282b4a962a57a723ad2ccbf50")
  (:PATH "docs/adr/0071-delta-location-indice-m1.md" :GIT-BLOB
   "5f06b390d2223e5e5e85f38f5de73cf1ad668f5f")
  (:PATH "docs/adr/0072-rinnovo-automatico-delta-m1.md" :GIT-BLOB
   "99ae69d3d9fa5d6d69f9cb5efede395fe33ae408")
  (:PATH "docs/adr/0073-indice-automatico-operativo-m1.md" :GIT-BLOB
   "8f7677e90411d564c161e07d5f46fe774e32384e")
  (:PATH "docs/adr/0074-crc32c-sbcl-2.6.10.md" :GIT-BLOB
   "0d32b3a9bfe16d3755cc163e1ec2ec09394ca598")
  (:PATH "docs/adr/0075-codex-documentation-toolchain.md" :GIT-BLOB
   "60f2fca9be7d793cffd1f13dc43a80365df700a5")
  (:PATH "docs/adr/0076-rotazione-live-m1.md" :GIT-BLOB
   "1da6f99e64dbce919e88440c8a4662d9abc9ba82")
  (:PATH "docs/adr/0077-source-derived-code-reference.md" :GIT-BLOB
   "100230816ee9e513dfc78ba3c57c992bef61eec5")
  (:PATH "docs/adr/0078-compattazione-prefix-m1.md" :GIT-BLOB
   "89e9e72b6eb4aaf2a0fd494de6a72a33810a52b0")
  (:PATH "docs/adr/0079-cache-record-m1.md" :GIT-BLOB
   "114135347b465d247f7e05b091858c9791f88382")
  (:PATH "docs/adr/0080-group-commit-m1.md" :GIT-BLOB
   "86b89a39cfe8faa863e350dade7d77f9540364fb")
  (:PATH "docs/adr/0081-active-append-metadata.md" :GIT-BLOB
   "19b160c27564b5682637adc98ed39e1b47255f2d")
  (:PATH "docs/adr/0082-bounded-group-append.md" :GIT-BLOB
   "9d0be5661c2df788d2f3c1f2d1f03330011eb78e")
  (:PATH "docs/adr/0083-explicit-unix-write-groups.md" :GIT-BLOB
   "fbca2463c1168aabadea5dcaae48fd1dbaeffcfe")
  (:PATH "docs/adr/0084-explicit-unix-read-groups.md" :GIT-BLOB
   "d5882e72757a731cd02d71f7ae97208b2cdffce0")
  (:PATH "docs/adr/0085-conditional-current-writes.md" :GIT-BLOB
   "9ccb72269093a95c3be1a665a9809c8130096f2d")
  (:PATH "docs/adr/0086-conditional-same-turn-group-commit.md" :GIT-BLOB
   "f3aad4767ed3f071173c4b9622c92fc27aaa8e7a")
  (:PATH "docs/adr/0087-explicit-conditional-unix-groups.md" :GIT-BLOB
   "57e069b05fc8de1120d5c981ddd3ad7c63ee2ade")
  (:PATH "docs/adr/README.md" :GIT-BLOB
   "71818ef6ff77d04a135202700c9f816d42670d18")
  (:PATH "docs/affidabilita/README.md" :GIT-BLOB
   "da6af58f171fe105407b444a400905f554110ec9")
  (:PATH "docs/affidabilita/analisi-dei-guasti.md" :GIT-BLOB
   "09805b5022bf9b338522c4078feae7334825c50a")
  (:PATH "docs/affidabilita/copertura-eccezioni.md" :GIT-BLOB
   "2b878e6c0b9ea5576635f16b1d9e7433c956458f")
  (:PATH "docs/affidabilita/deviazioni.md" :GIT-BLOB
   "0b92053bbe5abc8b74a59472a0ddaad7be9ba399")
  (:PATH "docs/affidabilita/piano-di-verifica.md" :GIT-BLOB
   "35ce8a542e4e77ba28c497e4a33358f308708bd0")
  (:PATH "docs/affidabilita/standard-di-codifica.md" :GIT-BLOB
   "5729dba5379c1eaf1366302e6243fa5219f60cd0")
  (:PATH "docs/analisi-progettuale.md" :GIT-BLOB
   "2325e50c80180c368d7e13c9181bb6e6fd8ff831")
  (:PATH "docs/architettura.md" :GIT-BLOB
   "5f74a1692a934ddc9425d91ff0cadbf842c95bb2")
  (:PATH "docs/code-reference.md" :GIT-BLOB
   "ce9a8a5a9a8ef8d58833bb239199bbd2e1f6019a")
  (:PATH "docs/editorial-policy.md" :GIT-BLOB
   "23c70f794c8640f050be6eda8d1f75fbeeb13540")
  (:PATH "docs/editorial-review.md" :GIT-BLOB
   "9264d1e4e9b0189d3b3f5a5f3c8cebe5f5d728ec")
  (:PATH "docs/formati-su-disco.md" :GIT-BLOB
   "d83cff978b0e2c61bfbf1308e4fdcdbd38fb4ebf")
  (:PATH "docs/formato-indice-full-text.md" :GIT-BLOB
   "be3b1b6661023f58d985a26c07c15216cb099a66")
  (:PATH "docs/full-text.md" :GIT-BLOB
   "29a9ee662cd39c103edaaf046bc8b68731bd8df4")
  (:PATH "docs/github-pages.md" :GIT-BLOB
   "1d624b0c03aa60ee582ce4c98c83b38272c0dc75")
  (:PATH "docs/glossario.md" :GIT-BLOB
   "8c460a969441f5be9d94766fff808f15d6d33f36")
  (:PATH "docs/guida-al-repository.md" :GIT-BLOB
   "0c946fd449c68453ea89231234ec67431189414d")
  (:PATH "docs/implementazione/README.md" :GIT-BLOB
   "107b5346c1b34eea45a66cd902820bc8cc45e5f8")
  (:PATH "docs/implementazione/active-recovery-metodo.md" :GIT-BLOB
   "5724560732e14d6d374483aa71ca0f7802541df5")
  (:PATH "docs/implementazione/active-recuperato-metodo.md" :GIT-BLOB
   "32524af882ad0a043f6d939994c9a6a11769fef9")
  (:PATH "docs/implementazione/active-recuperato-verifica.md" :GIT-BLOB
   "23af8d8e23577a92d5c0e74884061cb56639d55d")
  (:PATH "docs/implementazione/active-recuperato.md" :GIT-BLOB
   "0b685aa69fd7c078994b5d1feaa4b5b93c1cafc8")
  (:PATH "docs/implementazione/adozione-closed-runtime.md" :GIT-BLOB
   "21630d85433210b2f061c422c931ef0f14ad0b61")
  (:PATH "docs/implementazione/adozione-controller-runtime.md" :GIT-BLOB
   "f2f7826b7eb58b681d334e29834ddd1cf09fed06")
  (:PATH "docs/implementazione/archivi-comandi-lettura.md" :GIT-BLOB
   "797a1998753834a3204075954c9cfe81a0f064d4")
  (:PATH "docs/implementazione/archivio-csn-revisione.md" :GIT-BLOB
   "c886079a0ad9f47ae864fbb63084960f897e55fa")
  (:PATH "docs/implementazione/archivio-csn-verifica.md" :GIT-BLOB
   "873f06c415107bac58d781df316e5b484222316a")
  (:PATH "docs/implementazione/associazione-file.md" :GIT-BLOB
   "02e39a32261a5a901ca45e15dcc7505819a969e0")
  (:PATH "docs/implementazione/attivazione-indice-m1.md" :GIT-BLOB
   "cd609a5e9645be680b23798e0bda841d8507d772")
  (:PATH "docs/implementazione/cache-pagine.md" :GIT-BLOB
   "1eaeb517c655d918d307d46423e4aee54f39290b")
  (:PATH "docs/implementazione/cache-record.md" :GIT-BLOB
   "3dbae0d9e595f509621e6bf6dd3380a5ed844f1d")
  (:PATH "docs/implementazione/cbor-array-decisioni.md" :GIT-BLOB
   "948258bd302c1820210e439862d432d8c5554e9e")
  (:PATH "docs/implementazione/cbor-array-lettura.md" :GIT-BLOB
   "c419ecc31f9e905f4d053fd4473c8b605415dc4d")
  (:PATH "docs/implementazione/cbor-array-metodo.md" :GIT-BLOB
   "a5e53c22e391f72573f89c01f58ae28fa1c40376")
  (:PATH "docs/implementazione/cbor-array-revisione.md" :GIT-BLOB
   "f992654650b2fb08a59058b337fef63f901bf75c")
  (:PATH "docs/implementazione/cbor-array-risultati.md" :GIT-BLOB
   "e4c253fcfbe86fd2dfce2bd3354614a67f4b97f5")
  (:PATH "docs/implementazione/cbor-array.md" :GIT-BLOB
   "0f8fa2876a7366cd62bd1b8669251e2107b19b7d")
  (:PATH "docs/implementazione/cbor-float-scrittura-copertura.md" :GIT-BLOB
   "c1f596a69e83504ff3fd2c7cf569f234e1c6554b")
  (:PATH "docs/implementazione/cbor-float-scrittura-dati.md" :GIT-BLOB
   "618a4fdc1d5fbb230414931295ff0f7ef9367c84")
  (:PATH "docs/implementazione/cbor-float-scrittura-decisioni.md" :GIT-BLOB
   "cd76b3d2b02c6c021849b2b85d1a403d76e38f78")
  (:PATH "docs/implementazione/cbor-float-scrittura-lettura.md" :GIT-BLOB
   "11a065b51085a23f42df7ca75e315cbee0328e70")
  (:PATH "docs/implementazione/cbor-float-scrittura-metodo.md" :GIT-BLOB
   "6c046bb92cc291fb00914da89e0eefb705b4ae65")
  (:PATH "docs/implementazione/cbor-float-scrittura-revisione.md" :GIT-BLOB
   "870474964d88a8b4099bf00cc31c0b2bc542f94a")
  (:PATH "docs/implementazione/cbor-float-scrittura-risultati.md" :GIT-BLOB
   "84faa8d4bbf5150c4b9df17879b5dd0b39a286d4")
  (:PATH "docs/implementazione/cbor-float-scrittura.md" :GIT-BLOB
   "c14c7bbaebcd803c24f62adcda19259b16f00e52")
  (:PATH "docs/implementazione/cbor-header-decisioni.md" :GIT-BLOB
   "c7fe2a7bad385932a72141de4ae46f04bbd8ce18")
  (:PATH "docs/implementazione/cbor-header-lettura.md" :GIT-BLOB
   "dd7621ec9feea82adec89e00ed232b22d8aead35")
  (:PATH "docs/implementazione/cbor-header-metodo.md" :GIT-BLOB
   "4984c8c845da1437c212f47a7a345979df1c5acc")
  (:PATH "docs/implementazione/cbor-header-revisione.md" :GIT-BLOB
   "ba09a11d806999c55e0cb75f5b638d1fe2cb0476")
  (:PATH "docs/implementazione/cbor-header-strumenti-review.md" :GIT-BLOB
   "29f9c13299d7b2fbcea64db535c0ec3fd4456f73")
  (:PATH "docs/implementazione/cbor-header.md" :GIT-BLOB
   "fb04b79a27ae65e2097c21ace50ee70f26bb0e8a")
  (:PATH "docs/implementazione/cbor-item-decisioni.md" :GIT-BLOB
   "800cefe6cf8f8a8000dad71d3807df7e7efdd210")
  (:PATH "docs/implementazione/cbor-item-lettura.md" :GIT-BLOB
   "57bcf4f8d1c40334c68d53ad2b4a2092e769d8d1")
  (:PATH "docs/implementazione/cbor-item-metodo.md" :GIT-BLOB
   "05b4a0d45c993c6bfebb0555098334f40db82f33")
  (:PATH "docs/implementazione/cbor-item-revisione.md" :GIT-BLOB
   "de0ef7bc19fe539d4aef7cdc1c1f5345b8002a94")
  (:PATH "docs/implementazione/cbor-item-risultati.md" :GIT-BLOB
   "8b02e00a9d43febf09b846d1bf6a01ebee2b3005")
  (:PATH "docs/implementazione/cbor-item.md" :GIT-BLOB
   "8548c091f11308380d4ac4e01ff884644b470281")
  (:PATH "docs/implementazione/cbor-map-decisioni.md" :GIT-BLOB
   "f44e789f6d2bf153580332fb136e46cb9e57194a")
  (:PATH "docs/implementazione/cbor-map-lettura.md" :GIT-BLOB
   "23a1f7f9653522ebf02619977dc2d74ed275f891")
  (:PATH "docs/implementazione/cbor-map-metodo.md" :GIT-BLOB
   "50ad5d1f64b5dbd37f4285306c5430789e0c581e")
  (:PATH "docs/implementazione/cbor-map-revisione.md" :GIT-BLOB
   "4f9c6c7a2e2eed16e73bbb314f5936182d371420")
  (:PATH "docs/implementazione/cbor-map-risultati.md" :GIT-BLOB
   "5322d5cdd93ea61e00830138091c72eadd5effe9")
  (:PATH "docs/implementazione/cbor-map.md" :GIT-BLOB
   "3f4f8e64c19f21958bcc913a1ee701cc55a18f06")
  (:PATH "docs/implementazione/cbor-minimo-decisioni.md" :GIT-BLOB
   "998d3f4d69a4915bd3d5ac13381d89b15a22afaf")
  (:PATH "docs/implementazione/cbor-minimo-driver-review.md" :GIT-BLOB
   "1c7b8bc426f5054aa88e7b2cf8ce1d0c339e112b")
  (:PATH "docs/implementazione/cbor-minimo-lettura.md" :GIT-BLOB
   "d34c7e0e8b9347228e9c3121358824f106d1e663")
  (:PATH "docs/implementazione/cbor-minimo-metodo.md" :GIT-BLOB
   "8beb9758140566348297f59d8a85a1c6816c70ae")
  (:PATH "docs/implementazione/cbor-minimo-revisione.md" :GIT-BLOB
   "464af7d4e2264a4c7e0336b2219a0e886cd04c2b")
  (:PATH "docs/implementazione/cbor-minimo-risultati.md" :GIT-BLOB
   "a0a4beb749f27b8fdd721492a338ff29acd18420")
  (:PATH "docs/implementazione/cbor-minimo-strumenti-review.md" :GIT-BLOB
   "3ac17f24029e9c242146cd994a7b2b907ef8177d")
  (:PATH "docs/implementazione/cbor-minimo-struttura-decisioni.md" :GIT-BLOB
   "1a2a1bc130b5e3f343f110bd9ccca2de3486a19b")
  (:PATH "docs/implementazione/cbor-minimo-struttura-driver-review.md"
   :GIT-BLOB "ef1defbeb7d0f2f52a289e03fa52b7922bd8fff2")
  (:PATH "docs/implementazione/cbor-minimo-struttura-lettura.md" :GIT-BLOB
   "980896a21ef91e13e4c3a4d414d72115eb27fee1")
  (:PATH "docs/implementazione/cbor-minimo-struttura-metodo.md" :GIT-BLOB
   "a0533ae26074d23c19b098bcf11d7f3959c3b609")
  (:PATH "docs/implementazione/cbor-minimo-struttura-revisione.md" :GIT-BLOB
   "c3bd5167d49e4e2bc59bff90b6e62e3435ed43b6")
  (:PATH "docs/implementazione/cbor-minimo-struttura-risultati.md" :GIT-BLOB
   "556fddff139cb8660db889b3b1cb39046972c01f")
  (:PATH "docs/implementazione/cbor-minimo-struttura-strumenti-review.md"
   :GIT-BLOB "d0bb1a35f08dc97dcb4e03e70e521707c8a8d29c")
  (:PATH "docs/implementazione/cbor-minimo-struttura.md" :GIT-BLOB
   "05a927871e8257d31d40c727f88858cc10f3f5b3")
  (:PATH "docs/implementazione/cbor-minimo.md" :GIT-BLOB
   "7b606f5d5c44abd25a7cea635c2e3086f7b08d7a")
  (:PATH "docs/implementazione/cbor-mutazioni-processi.md" :GIT-BLOB
   "0c3f81227199b06df304e9e3bcbc6c98660bacc8")
  (:PATH "docs/implementazione/cbor-scrittura-decisioni.md" :GIT-BLOB
   "54852d32fb4a642db32067148adbf6d9fb22a066")
  (:PATH "docs/implementazione/cbor-scrittura-lettura.md" :GIT-BLOB
   "ab773c5d9261846c39c09f6cf06566344acd4ff9")
  (:PATH "docs/implementazione/cbor-scrittura-metodo.md" :GIT-BLOB
   "a3e52d83ef8dab364c1e290a003fbcac3e4703b5")
  (:PATH "docs/implementazione/cbor-scrittura-revisione.md" :GIT-BLOB
   "943ce8b93716e53b1048dbb672ecb01ecf2ecf2c")
  (:PATH "docs/implementazione/cbor-scrittura-risultati.md" :GIT-BLOB
   "3bc420d5c29b2005395fdbf72ba1fe12fa0feb20")
  (:PATH "docs/implementazione/cbor-scrittura.md" :GIT-BLOB
   "12ed41add43b64cf9a0cf317dab6a09a0f6a8f5e")
  (:PATH "docs/implementazione/cbor-semplici-dati.md" :GIT-BLOB
   "7299368dd4c077d8e620e6a3f6b91dde5cde96c3")
  (:PATH "docs/implementazione/cbor-semplici-decisioni.md" :GIT-BLOB
   "ee75788591cf776a011eddef4384ce6c9b0c1cf8")
  (:PATH "docs/implementazione/cbor-semplici-lettura.md" :GIT-BLOB
   "b5e504a3508da8c72295f9fa7a18ba44a482b547")
  (:PATH "docs/implementazione/cbor-semplici-metodo.md" :GIT-BLOB
   "e5b9990f00978da272fac6353b4706e9cdb3e80e")
  (:PATH "docs/implementazione/cbor-semplici-revisione.md" :GIT-BLOB
   "46f011d10fbd376c7387ffe48a9730a3a2620b05")
  (:PATH "docs/implementazione/cbor-semplici-risultati.md" :GIT-BLOB
   "d33e32c7e570f1958c8af75a789ea3a6583e4289")
  (:PATH "docs/implementazione/cbor-semplici-verificatori.md" :GIT-BLOB
   "032c6c20aa5e116d2c1fa4214a0701e40620b966")
  (:PATH "docs/implementazione/cbor-semplici.md" :GIT-BLOB
   "77e0e458eb0cfbeb0796d176ff54805fcec9fc13")
  (:PATH "docs/implementazione/cbor-stringa-lettura-decisioni.md" :GIT-BLOB
   "a307a12444fd16df6ad92dcdf8717f02e76ac7a8")
  (:PATH "docs/implementazione/cbor-stringa-lettura-metodo.md" :GIT-BLOB
   "3378a194f4eded0fc1316be064956d77b3132fb3")
  (:PATH "docs/implementazione/cbor-stringa-lettura-prima-revisione.md"
   :GIT-BLOB "6fb1e3c3cd8a7512958b54095940826c30980eed")
  (:PATH "docs/implementazione/cbor-stringa-lettura-risultati.md" :GIT-BLOB
   "b50555a7cf2b592b5c36b2d094d7500225581f06")
  (:PATH "docs/implementazione/cbor-stringa-lettura-seconda-revisione.md"
   :GIT-BLOB "ebfc3d0bbdd1a19a295c55770a6d505ddbd4aa84")
  (:PATH "docs/implementazione/cbor-stringa-lettura.md" :GIT-BLOB
   "9eecb30c6b1887b9a0a5f5aabe3516916c3ba025")
  (:PATH "docs/implementazione/cbor-stringhe-dati.md" :GIT-BLOB
   "82f1683ba3774d33e82fd23e118790e401c11085")
  (:PATH "docs/implementazione/cbor-stringhe-decisioni.md" :GIT-BLOB
   "ff78a1940b29beef1c4e685e2084767c948f9da0")
  (:PATH "docs/implementazione/cbor-stringhe-lettura.md" :GIT-BLOB
   "280b19d5e97d5487ba6be4f59da8b015063074bf")
  (:PATH "docs/implementazione/cbor-stringhe-metodo.md" :GIT-BLOB
   "7ac03f1075bd778be47916ef9eef72e5bcdc90ff")
  (:PATH "docs/implementazione/cbor-stringhe-revisione.md" :GIT-BLOB
   "08f016eb4a073cf59dbb3c5c9b23791d4a1285ef")
  (:PATH "docs/implementazione/cbor-stringhe-risultati.md" :GIT-BLOB
   "c17e8ed2fb902df4c971d0300c1c7842dd46a764")
  (:PATH "docs/implementazione/cbor-stringhe.md" :GIT-BLOB
   "16b04b9a5451b880ea2449104f65e261ba7f6c7d")
  (:PATH "docs/implementazione/cbor-struttura-decisioni.md" :GIT-BLOB
   "66c94d76bdb2c46714ea86774489f31580ac63c9")
  (:PATH "docs/implementazione/cbor-struttura-driver-review.md" :GIT-BLOB
   "d64b31030580f02466562e86efae7cc27451d0a2")
  (:PATH "docs/implementazione/cbor-struttura-lettura.md" :GIT-BLOB
   "16ffa1f24020338735660b5b008fb3e00c498ea4")
  (:PATH "docs/implementazione/cbor-struttura-metodo.md" :GIT-BLOB
   "39fa55a82334440ea17d53dbefe050d53db6a716")
  (:PATH "docs/implementazione/cbor-struttura-revisione.md" :GIT-BLOB
   "5e801a7632e7ce46f56e79cad2073b3e155eae99")
  (:PATH "docs/implementazione/cbor-struttura-risultati.md" :GIT-BLOB
   "c77993b00f09e89d21d2ab2eb319964e9e2fa819")
  (:PATH "docs/implementazione/cbor-struttura-strumenti-review.md" :GIT-BLOB
   "2221900158acbbd5cdaa39d3301b08501c071e97")
  (:PATH "docs/implementazione/cbor-struttura.md" :GIT-BLOB
   "e29635a7ce3cd150ea0801c4610ddd03af941c8c")
  (:PATH "docs/implementazione/cbor-tag-decisioni.md" :GIT-BLOB
   "f0329ac5196815f633bf7abc82c97730cee832a5")
  (:PATH "docs/implementazione/cbor-tag-lettura.md" :GIT-BLOB
   "49146a982d1297edaf0c31daca7c5eb6150a6ea7")
  (:PATH "docs/implementazione/cbor-tag-metodo.md" :GIT-BLOB
   "ffa487840cb2e0964e7fa7a7cd55d57fbeed3de4")
  (:PATH "docs/implementazione/cbor-tag-revisione.md" :GIT-BLOB
   "b61c84f5f4a70f3009748536709d37c2609d89cd")
  (:PATH "docs/implementazione/cbor-tag-risultati.md" :GIT-BLOB
   "a78c3f04408c306f2cddcc617274f2335b17fc81")
  (:PATH "docs/implementazione/cbor-tag.md" :GIT-BLOB
   "a67789164c1ca9ab5be6435322ae77606314831f")
  (:PATH "docs/implementazione/checkpoint-control.md" :GIT-BLOB
   "2e2d90188ad3b3bec79f9a2c90e9f2cff58f3c42")
  (:PATH "docs/implementazione/checkpoint-recovery.md" :GIT-BLOB
   "fd1444d3e09f58457eb3babe639bc93634e32aa3")
  (:PATH "docs/implementazione/ci-provenienza-pr.md" :GIT-BLOB
   "cfe42a5fe0ebb52b0c1217926a15078d8baf4cea")
  (:PATH "docs/implementazione/ci-statistiche.md" :GIT-BLOB
   "6d6d3ad1d0381ab4bf946a6c1e7561f5266ad494")
  (:PATH "docs/implementazione/ci-wire-processi.md" :GIT-BLOB
   "537159570d4bdc8e7dbcddb5be3dd9e2d57c26eb")
  (:PATH "docs/implementazione/closed-recuperato-revisione.md" :GIT-BLOB
   "38373f1de3d42b5e9056e60d30f215083a80c845")
  (:PATH "docs/implementazione/closed-recuperato-verifica.md" :GIT-BLOB
   "1c4b3e4f0e6c3d3c4519dcdd56c7a2ca8ca2d47d")
  (:PATH "docs/implementazione/closed-recuperato.md" :GIT-BLOB
   "3675c4a21cd14e15f136f1bdcd6e0c64f28564bc")
  (:PATH "docs/implementazione/code-writer-decisioni.md" :GIT-BLOB
   "07c702f3b926311b7af6950382459286f20c9d05")
  (:PATH "docs/implementazione/code-writer-metodo.md" :GIT-BLOB
   "7c9473c0d5149a7cefab4ef33076c7f44bfe9f30")
  (:PATH "docs/implementazione/code-writer.md" :GIT-BLOB
   "2dd9f8ab7dbdc2df6a41874a63aa62f45fa11ba8")
  (:PATH "docs/implementazione/compiti-lettura.md" :GIT-BLOB
   "714da56672b38ed721a71f7d81986f66ca3915e6")
  (:PATH "docs/implementazione/control-recuperato.md" :GIT-BLOB
   "050723cbdec05ccf343e6cf651023dbba053fa60")
  (:PATH "docs/implementazione/control-transizione-metodo.md" :GIT-BLOB
   "4af36a8e4c9c409cccb82beacd9a7243057c2b76")
  (:PATH "docs/implementazione/control-verifica-metodo.md" :GIT-BLOB
   "8ffecd3625f0d1c3b4cf5786e17354cd170a127f")
  (:PATH "docs/implementazione/controller-serie-decisioni.md" :GIT-BLOB
   "4e75306fe31c84d552c342f4294894121d647097")
  (:PATH "docs/implementazione/controller-serie-metodo.md" :GIT-BLOB
   "4c8e017a2fc5e52b4a26d3f90c50d2e89f90e5f1")
  (:PATH "docs/implementazione/controller-serie-revisione.md" :GIT-BLOB
   "a294f643c70035056ce585a186fe4fb0ad1f01f3")
  (:PATH "docs/implementazione/controller-serie-risultati.md" :GIT-BLOB
   "6a48c794b8d8619e762c0c33108175d26dab2235")
  (:PATH "docs/implementazione/controller-serie.md" :GIT-BLOB
   "e3bc4006b2c53306af00f16d8967e002be5be7f2")
  (:PATH "docs/implementazione/controllore-pool-decisioni.md" :GIT-BLOB
   "e45a4a1609e6ad2c4a8c507a3b6474b34329fc7e")
  (:PATH "docs/implementazione/controllore-pool-metodo.md" :GIT-BLOB
   "9452ebefc6280a045c051c394e3ab55a9b5b7b90")
  (:PATH "docs/implementazione/controllore-pool-revisione-2.md" :GIT-BLOB
   "f4b54f7f20f0dbc620c95098dfe8f7d11e00eb84")
  (:PATH "docs/implementazione/controllore-pool-revisione.md" :GIT-BLOB
   "8331ccdab4e1957b7eaa4ff7404ab2ed263fa924")
  (:PATH "docs/implementazione/controllore-pool-risultati.md" :GIT-BLOB
   "e0738c5de4ceb793d70419ac8fece82e1de2359d")
  (:PATH "docs/implementazione/controllore-pool.md" :GIT-BLOB
   "32a0876c84705abfb03a324d93c0e09997e8caaf")
  (:PATH "docs/implementazione/costruzione-indice-m1.md" :GIT-BLOB
   "954e5c11aac01cdcdbbe1300ab7ad5904a31186f")
  (:PATH "docs/implementazione/costruzione-indice-paginato.md" :GIT-BLOB
   "6f4a25f0f4a8c5c5ef123b587f34313cf18493ae")
  (:PATH "docs/implementazione/crc32c-arm64-metodo.md" :GIT-BLOB
   "fd0a6f8b0203eb527434d5c85b5a21bffaa83842")
  (:PATH "docs/implementazione/crc32c-arm64.md" :GIT-BLOB
   "9d44dfe4836c393debf1e2fedd781ba8d64ac854")
  (:PATH "docs/implementazione/crc32c-piattaforme.md" :GIT-BLOB
   "c48393540f18a1982fa9523d82684488f2d0e9ed")
  (:PATH "docs/implementazione/crc32c-unroll32.md" :GIT-BLOB
   "f9b81bfbbfe41d6f0433df1275b14e0ddb277521")
  (:PATH "docs/implementazione/csn-archivio-recovery.md" :GIT-BLOB
   "0501c6e7d687db9aa0196637ea4ceb5032d398b9")
  (:PATH "docs/implementazione/csn-decisioni.md" :GIT-BLOB
   "f3c71d7a014741290c658cd958ca5d5b6e5076a7")
  (:PATH "docs/implementazione/csn-metodo.md" :GIT-BLOB
   "6809b9ff79f77032c94c726a67913fd86ed590f4")
  (:PATH "docs/implementazione/csn-revisione.md" :GIT-BLOB
   "87df34a5915fead7f06bff837dfa0b904f9eb664")
  (:PATH "docs/implementazione/csn-risultati.md" :GIT-BLOB
   "ac014f8282cf46645dd18f92f16bff17ac1da0b4")
  (:PATH "docs/implementazione/csn.md" :GIT-BLOB
   "3d69beb591d794d62111bb695cf87fc6c4726e2c")
  (:PATH "docs/implementazione/decisioni-multiserie-decisioni.md" :GIT-BLOB
   "7979e6edd61ac9300d6560b493a61948a4fd0d92")
  (:PATH "docs/implementazione/decisioni-multiserie-metodo.md" :GIT-BLOB
   "62df2e33eb3daa289da2fd2d544db1e367495b76")
  (:PATH "docs/implementazione/decisioni-multiserie.md" :GIT-BLOB
   "2ab09dc900d919686bd211a1fc0c9e233d6d8bbe")
  (:PATH "docs/implementazione/decisioni-radix-decisioni.md" :GIT-BLOB
   "26b8a34a0c455ffa1244cd8930718ad68067983d")
  (:PATH "docs/implementazione/decisioni-radix-lettura-autore.md" :GIT-BLOB
   "475fcdde02949a8500168f29ab43891d70fe7fa9")
  (:PATH "docs/implementazione/decisioni-radix-metodo.md" :GIT-BLOB
   "7e01085ba74008ba3f3715415c7196de10efe61f")
  (:PATH "docs/implementazione/decisioni-radix-revisione.md" :GIT-BLOB
   "a2f17134ae38a241a5610af3f00051f0e1c6bca5")
  (:PATH "docs/implementazione/decisioni-radix-risultati.md" :GIT-BLOB
   "04724b6857c83e623ba245bef65c657f416bbced")
  (:PATH "docs/implementazione/decisioni-recuperate-revisione.md" :GIT-BLOB
   "e8ec567a22d4a0b7f365d7649622e9a3405e69e4")
  (:PATH "docs/implementazione/decisioni-recuperate-verifica.md" :GIT-BLOB
   "efae51de3ab17894525f9803c2caa2dab2caa737")
  (:PATH "docs/implementazione/decisioni-recuperate.md" :GIT-BLOB
   "877dab2bc85bec554965e906163a950fa7f42dbb")
  (:PATH "docs/implementazione/delta-indice-m1.md" :GIT-BLOB
   "74b4d0337972db90f897380d1acf29cf56b5387d")
  (:PATH "docs/implementazione/delta-location-m1-metodo.md" :GIT-BLOB
   "546cbb2eb9169663e412972c9ffa3dfdd7a44eb7")
  (:PATH "docs/implementazione/delta-location-m1.md" :GIT-BLOB
   "dd39d0fa56ef87edaac933052523fb1092af9891")
  (:PATH "docs/implementazione/epoche-e-reclaim.md" :GIT-BLOB
   "23c6bd3464be1c5de0e85dd1ceef49cb072e2610")
  (:PATH "docs/implementazione/evidenze-parallele.md" :GIT-BLOB
   "c1cf798f1d7aa870e6fc08666fb089bd0078f1b2")
  (:PATH "docs/implementazione/fondazioni-binarie.md" :GIT-BLOB
   "9ce191f9a921d27dd12773f67b2ea9dc2b724c11")
  (:PATH "docs/implementazione/fondazioni-decisioni.md" :GIT-BLOB
   "5988fea2f0c49b45d4da2152cd2f213f7d4a3bbe")
  (:PATH "docs/implementazione/fonti-recovery-metodo.md" :GIT-BLOB
   "71889d31dc82e1ce9cb80228debcd2aaae265ca3")
  (:PATH "docs/implementazione/fonti-recovery.md" :GIT-BLOB
   "b613cfd01ebf4f093fd8d5b4f6ea14c2c43b1156")
  (:PATH "docs/implementazione/full-text-codec-decisioni.md" :GIT-BLOB
   "d84b4a8ea730f7eb6a08f7578322a9cbab97cc27")
  (:PATH "docs/implementazione/full-text-codec.md" :GIT-BLOB
   "dd648030eb25834fe6d66bf6fb61fad777ef7906")
  (:PATH "docs/implementazione/full-text-decisioni.md" :GIT-BLOB
   "891a19e59ded15ce976428e647431e6087fcda8b")
  (:PATH "docs/implementazione/full-text-documenti-decisioni.md" :GIT-BLOB
   "6df6ad62e11ea8977a258a6e11e774488c131e97")
  (:PATH "docs/implementazione/full-text-documenti.md" :GIT-BLOB
   "813e65fa97477a4d4451c483e137540af95cd667")
  (:PATH "docs/implementazione/full-text-put-metodo.md" :GIT-BLOB
   "2526a07b957970e7abc7f6baae970c2162d9b68e")
  (:PATH "docs/implementazione/full-text-put.md" :GIT-BLOB
   "a480bcb65e37731737a70f16554ca9e5e8cf8ee0")
  (:PATH "docs/implementazione/full-text-riferimenti-metodo.md" :GIT-BLOB
   "0cb603ba80950501cb439b61b4645274188ec75d")
  (:PATH "docs/implementazione/full-text-riferimenti.md" :GIT-BLOB
   "d363ee6d5e8e55f35668fbb129c2cf1f626a6d16")
  (:PATH "docs/implementazione/full-text-righe-metodo.md" :GIT-BLOB
   "2f576876ff695c0b662b91f8deea5b3793c3bc5b")
  (:PATH "docs/implementazione/full-text-righe.md" :GIT-BLOB
   "c6b643c4cf20d6b4378f7bfe7f05132cd4ba1d10")
  (:PATH "docs/implementazione/full-text-riserve-metodo.md" :GIT-BLOB
   "17663cca4a20e28e53be920eaa83792b520354a4")
  (:PATH "docs/implementazione/full-text-riserve.md" :GIT-BLOB
   "154f11b6ffc05e72273d3ab4a0b7a5d3867ad3a7")
  (:PATH "docs/implementazione/full-text.md" :GIT-BLOB
   "10317557bc507e5b786a0564626bc3109e851c46")
  (:PATH "docs/implementazione/get-active-metodo.md" :GIT-BLOB
   "de07ae6a11977904595cd321e2fdfb229cb0bbc0")
  (:PATH "docs/implementazione/get-active-preflight-metodo.md" :GIT-BLOB
   "2557776ad0c8c99e3c479ebfd557b6c912dd503d")
  (:PATH "docs/implementazione/get-active-preflight-verifica.md" :GIT-BLOB
   "2616f8e780fbc697519bc3517591c54197bd37f5")
  (:PATH "docs/implementazione/get-active-verifica.md" :GIT-BLOB
   "f46fdd16bd2ff24d0caa1426706db284b6e9f583")
  (:PATH "docs/implementazione/get-active-vuoto.md" :GIT-BLOB
   "2616e0c8ea4cf50baefe1d17c46277a3c11b1e51")
  (:PATH "docs/implementazione/get-active.md" :GIT-BLOB
   "b290db7acff4b04c7769062bff44c91f643765cc")
  (:PATH "docs/implementazione/get-costi-metodo.md" :GIT-BLOB
   "fb1926959f835883b7d88a5dda7bdea7f30998b8")
  (:PATH "docs/implementazione/get-costi-risultati.md" :GIT-BLOB
   "655b8a35ae16b285e8c5da3ee0249d47a7629c57")
  (:PATH "docs/implementazione/get-directory-metodo.md" :GIT-BLOB
   "56133e69f5a305d3d7ed173361a60d11dc8083a1")
  (:PATH "docs/implementazione/get-directory-mutazioni.md" :GIT-BLOB
   "242e710cf037c17f94ce2c6213210b87e1cd5108")
  (:PATH "docs/implementazione/get-directory-revisione.md" :GIT-BLOB
   "017acf3977bd60a59c7cc3c093c084dc5742d8d6")
  (:PATH "docs/implementazione/get-directory.md" :GIT-BLOB
   "d25a0d6bb499867c8e74865f76064205c70a904a")
  (:PATH "docs/implementazione/get-fonti-serie-metodo.md" :GIT-BLOB
   "0b3f2db806973acd21c7b0cb4fe203656db06baf")
  (:PATH "docs/implementazione/get-fonti-serie-revisione.md" :GIT-BLOB
   "91c14197cca8cfa11f46b4f5e2ef5cc03e269507")
  (:PATH "docs/implementazione/get-fonti-serie.md" :GIT-BLOB
   "ef7f5f3ae5748673a74ca960d3c5bb1c6e1dd44d")
  (:PATH "docs/implementazione/get-lifetime.md" :GIT-BLOB
   "3c83a87b6b59b2432c54145ff6d8e5144c7864be")
  (:PATH "docs/implementazione/get-performance-metodo.md" :GIT-BLOB
   "953b28082bc52d2925a43c6e78ef19e9cd7710b6")
  (:PATH "docs/implementazione/get-performance-revisione.md" :GIT-BLOB
   "adad30953d4d419ccd39475545619fb9e32b1392")
  (:PATH "docs/implementazione/get-record.md" :GIT-BLOB
   "a85bb276b698a7c20da89fb2fb23e19aef2bf5e0")
  (:PATH "docs/implementazione/get-resolver-metodo.md" :GIT-BLOB
   "fe7942c088ae3aa68d0e15e04c9f46faf05622ac")
  (:PATH "docs/implementazione/get-resolver-verifica.md" :GIT-BLOB
   "67b906cd6e8b8569f97a766b66deebd57f4be501")
  (:PATH "docs/implementazione/get-resolver.md" :GIT-BLOB
   "753deeb7ec87fcfdc7c8c1275368fa947827ac37")
  (:PATH "docs/implementazione/get-verifica.md" :GIT-BLOB
   "5d14690cdad3e3517bcd32522fd9b26f10475eac")
  (:PATH "docs/implementazione/hash-chiavi-decisioni.md" :GIT-BLOB
   "4515dcc663abeaa09a60ea4c8b3bd6df1baad2d9")
  (:PATH "docs/implementazione/hash-chiavi-metodo.md" :GIT-BLOB
   "9a6c1470083bbd595277d9a9f3b430ff0c5f85d6")
  (:PATH "docs/implementazione/hash-chiavi-revisione.md" :GIT-BLOB
   "b8204499bb41f33cea556a86eab9551f8709de40")
  (:PATH "docs/implementazione/hash-chiavi-risultati.md" :GIT-BLOB
   "695650c8c40cd1cbe9ad38eed29698b7b71ba97f")
  (:PATH "docs/implementazione/hash-chiavi.md" :GIT-BLOB
   "78a7da074a3daca5f05793f03b88fc4ce45321aa")
  (:PATH "docs/implementazione/header-log-metodo.md" :GIT-BLOB
   "c1a36112a2dbf6afef54a654c262389ba9037ba2")
  (:PATH "docs/implementazione/header-log.md" :GIT-BLOB
   "83b6d477b9d16697c2002989891657ba95ee4e6a")
  (:PATH "docs/implementazione/id-directory-recovery.md" :GIT-BLOB
   "6ea173a4f8c1210432f00d11e6ce6aae4ad1174b")
  (:PATH "docs/implementazione/id-segmento-recovery.md" :GIT-BLOB
   "f2fa99ae8a932406bb74666fa401e0aa9b2655a0")
  (:PATH "docs/implementazione/immagini-indice-paginato.md" :GIT-BLOB
   "8e88cc05ab5ee90c1a1c98d9b20859b652a97bf3")
  (:PATH "docs/implementazione/indice-automatico-completamento-metodo.md"
   :GIT-BLOB "c354d887b3102978bf827b1959e323b7d9b18b27")
  (:PATH "docs/implementazione/indice-automatico-operativo.md" :GIT-BLOB
   "e70a739bfd63091d2ba9cec5c6fd6aa821e4d669")
  (:PATH "docs/implementazione/indice-automatico-risultati.md" :GIT-BLOB
   "d8823f505faa11809cea64f9f3c90675b0198fb0")
  (:PATH "docs/implementazione/indice-automatico.md" :GIT-BLOB
   "614b528773e7b34f955143e0afea744d431e2e1e")
  (:PATH "docs/implementazione/indice-da-recovery.md" :GIT-BLOB
   "486481170704785730c471af7dfd1a5816243a04")
  (:PATH "docs/implementazione/indice-paginato-m1.md" :GIT-BLOB
   "fe476e799ce3ec29caebbecb1a112a2e04bbe2f7")
  (:PATH "docs/implementazione/indice-primario.md" :GIT-BLOB
   "4e34fc8e0ffc4413a921b5538edd63693281b70e")
  (:PATH "docs/implementazione/indice-ricostruzione-benchmark-metodo.md"
   :GIT-BLOB "439aa57177f9323735aaf1e8c4677cdf17e29ad7")
  (:PATH "docs/implementazione/indice-ricostruzione-revisione.md" :GIT-BLOB
   "3935af00f6b06ca6fbca8ab7a8c977eab164322c")
  (:PATH "docs/implementazione/indice-ricostruzione.md" :GIT-BLOB
   "32dd19680071319c88e9a91a0132260e921573d2")
  (:PATH "docs/implementazione/inizializzazione-active.md" :GIT-BLOB
   "d4c99e5ce4fb98ef862944a7cc41c08205cf60f7")
  (:PATH "docs/implementazione/inventario-decisioni.md" :GIT-BLOB
   "56795353bfac9ce5c3ebc0b69f704890d306c194")
  (:PATH "docs/implementazione/inventario-directory-metodo.md" :GIT-BLOB
   "1c6d345a7b2d02c2687f08474a7805e79160b615")
  (:PATH "docs/implementazione/inventario-directory-revisione.md" :GIT-BLOB
   "42511becdd73740fd1ea37f271dc7d4482ddeb74")
  (:PATH "docs/implementazione/inventario-metodo.md" :GIT-BLOB
   "caab01e598ef66377c6da22dbcec17db820b8b91")
  (:PATH "docs/implementazione/inventario.md" :GIT-BLOB
   "7fcabec950c4e85735ab5bd7960cba65d0b1b494")
  (:PATH "docs/implementazione/io-apertura-relativa-metodo.md" :GIT-BLOB
   "fa44089871f66bddf1309fa5d75b4678eef58902")
  (:PATH "docs/implementazione/io-apertura-relativa-revisione.md" :GIT-BLOB
   "8b13ab5dd4831710adfa606e5edf659e31c8a714")
  (:PATH "docs/implementazione/io-apertura-relativa.md" :GIT-BLOB
   "975eed05b2318ed9b85f4d6f860c2431248f1db7")
  (:PATH "docs/implementazione/io-completamento.md" :GIT-BLOB
   "b5982e35ea000c4c9dcc91021374849d6670638b")
  (:PATH "docs/implementazione/io-creazione-relativa-metodo.md" :GIT-BLOB
   "84b9f6ac1bf934fb7c34e178542cce9dae62fdc6")
  (:PATH "docs/implementazione/io-creazione-relativa-revisione.md" :GIT-BLOB
   "6ad24b936952f03d7a70827f10314ac7f0ad1dfb")
  (:PATH "docs/implementazione/io-creazione-relativa.md" :GIT-BLOB
   "0a0d30b8c6cf826cb906b7d7d26bc8c4c68b3b8d")
  (:PATH "docs/implementazione/io-decisioni.md" :GIT-BLOB
   "d6eb46b50c73b0150eddbc34cc93f127e82163dc")
  (:PATH "docs/implementazione/io-metodo.md" :GIT-BLOB
   "92c01fe2ab85af78f2f3cbf68cdaababa61f5ed9")
  (:PATH "docs/implementazione/io-pubblicazione-metodo.md" :GIT-BLOB
   "bdf72add9058e53ae707719af4ead4d18f462946")
  (:PATH "docs/implementazione/io-pubblicazione.md" :GIT-BLOB
   "f56f5f2f22e43b665a472d8560143b9430ea9ded")
  (:PATH "docs/implementazione/io-rinomina.md" :GIT-BLOB
   "d699c8433a309044b041ec1e2a0713ddb7d6f120")
  (:PATH "docs/implementazione/io.md" :GIT-BLOB
   "3db1a3257313b7040dd2b1222f4de77166de75da")
  (:PATH "docs/implementazione/lettura-indice-paginato.md" :GIT-BLOB
   "ce43161a04c6068b3ddce5b8eee94f35e46c5872")
  (:PATH "docs/implementazione/lettura-verifica.md" :GIT-BLOB
   "1fa26d055d5ee76d3a9bc6f6e6e31a3af3c0e0f1")
  (:PATH "docs/implementazione/manifest-control-log-decisioni.md" :GIT-BLOB
   "91b0ee252ceff9071c62a573b7b499b8e36e1964")
  (:PATH "docs/implementazione/manifest-control-log-metodo.md" :GIT-BLOB
   "4b69dba2809dc40a4d039a6106dd02e560c8e26c")
  (:PATH "docs/implementazione/manifest-control-log.md" :GIT-BLOB
   "20b9246ebddba96db237e5ebcbf2529afbd26a91")
  (:PATH "docs/implementazione/manutenzione-indice-m1.md" :GIT-BLOB
   "bcf08f6c98961ee5660483cd627244c1243f2a99")
  (:PATH "docs/implementazione/merge-main-2026-10-23.md" :GIT-BLOB
   "cb672d06673d639a152ef3bea52b73f258513473")
  (:PATH "docs/implementazione/metadati-storage-decisioni.md" :GIT-BLOB
   "332563a00301c759a56fa56efeb0c733f5d8acb5")
  (:PATH "docs/implementazione/metadati-storage-metodo.md" :GIT-BLOB
   "daca7cad14916fbc0b10743a6898bfba4f6c47ad")
  (:PATH "docs/implementazione/metadati-storage.md" :GIT-BLOB
   "2789dc59d0173d4e0af289cfac129ab12d1bec00")
  (:PATH "docs/implementazione/moduli.md" :GIT-BLOB
   "971b841de90347b255a3e22aaf4e7682fbe25e2d")
  (:PATH "docs/implementazione/orizzonte-csn.md" :GIT-BLOB
   "48ffbd9f476751940bbae8713788bd1d812a6002")
  (:PATH "docs/implementazione/pagine-indice-risultati.md" :GIT-BLOB
   "e8889ba9c0d836e73050037bd49faa9ae016a5a6")
  (:PATH "docs/implementazione/pagine-indice.md" :GIT-BLOB
   "34c6c7dec3f852d8dc6245a6c05a7f26ef2d09a5")
  (:PATH "docs/implementazione/pool-begin-metodo.md" :GIT-BLOB
   "8d10cde6f53e6e75cd936fa109121d0caab09d5f")
  (:PATH "docs/implementazione/pool-begin-revisione.md" :GIT-BLOB
   "95657e20c25dd27baddab5c04a2053170af45b96")
  (:PATH "docs/implementazione/pool-begin-risultati.md" :GIT-BLOB
   "c4049dcf13b516abf81bbea4d32aff64cb425c7f")
  (:PATH "docs/implementazione/pool-begin.md" :GIT-BLOB
   "06bd817d57eb415225973e0981778132621cf230")
  (:PATH "docs/implementazione/pool-catena-metodo.md" :GIT-BLOB
   "758327137a15f0f1ef344d51370add33a3a2c6cd")
  (:PATH "docs/implementazione/pool-catena-risultati.md" :GIT-BLOB
   "8bf6c0fe47438107778c68195e6f98ccb42b0b9c")
  (:PATH "docs/implementazione/pool-dispatch-metodo.md" :GIT-BLOB
   "eb6709befc9bdb0d67b04fd5c4c4f98a01ab94de")
  (:PATH "docs/implementazione/pool-dispatch-revisione.md" :GIT-BLOB
   "abda6bf2dbaa1fc5fdc6e55cc22bb0ee931513f2")
  (:PATH "docs/implementazione/pool-dispatch-risultati.md" :GIT-BLOB
   "ab68af4bc1ab1552d74c694ce96c1e1c4222920f")
  (:PATH "docs/implementazione/pool-dispatch.md" :GIT-BLOB
   "a540afacd7952495cc3300e0bced676639c55337")
  (:PATH "docs/implementazione/pool-prepara-metodo.md" :GIT-BLOB
   "4da00d6f92b7f949ec8acafbd3a97dd56bbbb367")
  (:PATH "docs/implementazione/pool-prepara-revisione.md" :GIT-BLOB
   "2c5e9f14f01fedcb7e3dc7a3b4ade9b8bfdcc9b6")
  (:PATH "docs/implementazione/pool-prepara-risultati.md" :GIT-BLOB
   "8c5a986a075da0555e225369bb08b72e4994558b")
  (:PATH "docs/implementazione/pool-prepara.md" :GIT-BLOB
   "84dcb4f1603e43af42c335d58a1d67ebe6347ae0")
  (:PATH "docs/implementazione/pool-recycle-metodo.md" :GIT-BLOB
   "2c811c8f11f65e5142e23c6d8e306b44e412d1e0")
  (:PATH "docs/implementazione/pool-recycle-revisione.md" :GIT-BLOB
   "100e57b2835ce7bc6b5dc68912cf99ae1e637c30")
  (:PATH "docs/implementazione/pool-recycle-risultati.md" :GIT-BLOB
   "4a192b8293368b041956bf12a8e266bd08d86cb5")
  (:PATH "docs/implementazione/pool-recycle.md" :GIT-BLOB
   "40dcde9abd1d21cf1d0d56cecc3b66c641b607b8")
  (:PATH "docs/implementazione/pool-step-metodo.md" :GIT-BLOB
   "e44a4958a4c0a67213243b112bc7362f0573e914")
  (:PATH "docs/implementazione/pool-step-revisione.md" :GIT-BLOB
   "66ab0543f271b9a5c96cb6aa2247be4d6925fd59")
  (:PATH "docs/implementazione/pool-step-risultati.md" :GIT-BLOB
   "470c7dc02213e5d01719829413da36ec08cc5d4c")
  (:PATH "docs/implementazione/pool-step.md" :GIT-BLOB
   "09a4edba6f17bed9682708707ecbe188b2b8e101")
  (:PATH "docs/implementazione/pool-worker-claim-metodo.md" :GIT-BLOB
   "b1b933f896ebb4b2c54a2a714a4c4291c431662d")
  (:PATH "docs/implementazione/pool-worker-claim-revisione.md" :GIT-BLOB
   "18aef79552d243af35866c3d2955e2d11761935d")
  (:PATH "docs/implementazione/pool-worker-claim-risultati.md" :GIT-BLOB
   "f0ce19f06da992cf25de5b3dd396258b7197105c")
  (:PATH "docs/implementazione/pool-worker-claim.md" :GIT-BLOB
   "5a69ddd2dad8066ee9d03792f8548abb9225222f")
  (:PATH "docs/implementazione/pool-worker-lifecycle-metodo.md" :GIT-BLOB
   "d32a1e07253c9138b176912091366712ff3037a4")
  (:PATH "docs/implementazione/pool-worker-lifecycle-revisione.md" :GIT-BLOB
   "9638731f43392e0a33b7f4ed84b19d6c46d1b0fa")
  (:PATH "docs/implementazione/pool-worker-lifecycle-risultati.md" :GIT-BLOB
   "d26d034ded38c3feb056a5a272e5147d790b36f6")
  (:PATH "docs/implementazione/pool-worker-lifecycle.md" :GIT-BLOB
   "5a1af3956ec7cb503cfe7b561acc66e3b32029ad")
  (:PATH "docs/implementazione/prestazioni-local-m1.md" :GIT-BLOB
   "d09055552b7b9fa8d15cd552465dc1025defa2d6")
  (:PATH "docs/implementazione/production-engine-bootstrap-metodo.md" :GIT-BLOB
   "92ea9255903acb119f72d1a61affda35f94a9358")
  (:PATH "docs/implementazione/production-engine-bootstrap.md" :GIT-BLOB
   "65664c0aa06fd0cf86dcd040b91dc8ab882e51ad")
  (:PATH "docs/implementazione/production-unix-m1.md" :GIT-BLOB
   "2da9b5fbfd5e21848587ca64eaba6276ba2ed1a5")
  (:PATH "docs/implementazione/prova-verticale.md" :GIT-BLOB
   "3b9642adce018f1bba63fca6cfaad10924f0351f")
  (:PATH "docs/implementazione/pubblicazione-control.md" :GIT-BLOB
   "8dee23aebeb7bd74de78153bff357b6810162ca0")
  (:PATH "docs/implementazione/raccolta-comandi-risultati.md" :GIT-BLOB
   "0e8a853a5618a1906dd4adbb7c9b18840959d03e")
  (:PATH "docs/implementazione/raccolta-comandi.md" :GIT-BLOB
   "69a9ac538805c31b2857a55f2d5b5c32c0a71b38")
  (:PATH "docs/implementazione/recovery-archivio.md" :GIT-BLOB
   "728fcfa388c5032d170b4f1924b6d614857baee7")
  (:PATH "docs/implementazione/recovery-csn.md" :GIT-BLOB
   "0a3b62e567853df795b710c8e080e3e4319d5153")
  (:PATH "docs/implementazione/recovery-serie.md" :GIT-BLOB
   "fb61bc33d840d815c72dcb3eb4c74c909708d42c")
  (:PATH "docs/implementazione/registro-snapshot.md" :GIT-BLOB
   "09620fc2b2248bec312b075e411f6864a5ebf16f")
  (:PATH "docs/implementazione/replay-closed.md" :GIT-BLOB
   "bb4499a07188b2887c5960e3eba59c951d80a159")
  (:PATH "docs/implementazione/rinnovo-automatico-m1-metodo.md" :GIT-BLOB
   "061f7030b0c9486754cea7333ee3838cf5f00e59")
  (:PATH "docs/implementazione/rinnovo-automatico-m1.md" :GIT-BLOB
   "29fbd690f61f74593e280c1be93b64d74b2609cd")
  (:PATH "docs/implementazione/rinnovo-indice-m1.md" :GIT-BLOB
   "048fb5e263d00771553c8de699ebe0e585c9c780")
  (:PATH "docs/implementazione/risultati/2026-10-08-benchmark.lisp" :GIT-BLOB
   "2d404302bc9dd73a3d453d2f32ee9d38b795b25c")
  (:PATH "docs/implementazione/risultati/2026-10-08-copertura.lisp" :GIT-BLOB
   "d2dea0f2d5f23f4b10bbf8f721bd2316d0f74449")
  (:PATH "docs/implementazione/risultati/2026-10-08-mutazioni.lisp" :GIT-BLOB
   "342fcd80e236d28bbf49d44b76278fdfa7099f6d")
  (:PATH "docs/implementazione/routing-worker-decisioni.md" :GIT-BLOB
   "d7b9c49b07bae6f01a5562d15a2cdabcbb979878")
  (:PATH "docs/implementazione/routing-worker-metodo.md" :GIT-BLOB
   "2709d9ad98b8dd8028b36f0163ba09bf2f49ae14")
  (:PATH "docs/implementazione/routing-worker-revisione.md" :GIT-BLOB
   "fa341fd666506b060c4d1253773dd87859014238")
  (:PATH "docs/implementazione/routing-worker-risultati.md" :GIT-BLOB
   "569fb428d702f4a60440c10cb0d9a1a360670fd1")
  (:PATH "docs/implementazione/routing-worker.md" :GIT-BLOB
   "ac6b5e1ea180807849dc24481de16eb79e4999af")
  (:PATH "docs/implementazione/runtime-archivio-revisione.md" :GIT-BLOB
   "bba7a3fa2b7e2139ea24ec86cc97fb4b02909aff")
  (:PATH "docs/implementazione/runtime-archivio.md" :GIT-BLOB
   "f8efbf185c6e21920a72d7982f396f5f6e4360d8")
  (:PATH "docs/implementazione/scansione-log-decisioni.md" :GIT-BLOB
   "54739f1b4f681ee51b684fd5f1706028a8922b11")
  (:PATH "docs/implementazione/scansione-log.md" :GIT-BLOB
   "24f4832f44e05b4958ee59a8b9b899228f5afa6d")
  (:PATH "docs/implementazione/scoperta-indice-local-m1.md" :GIT-BLOB
   "c6a2000090f8bf5b356b49804799739acccd1344")
  (:PATH "docs/implementazione/scoperta-indice-m1.md" :GIT-BLOB
   "4f05d679dfd56ea2922507433e26c876de136b00")
  (:PATH "docs/implementazione/segmenti-compattati-metodo.md" :GIT-BLOB
   "40197f19d765e646a0e3ce558386997294130ab1")
  (:PATH "docs/implementazione/segmenti-compattati.md" :GIT-BLOB
   "16a6ec600581f9c958650a8578117ad7d7d79584")
  (:PATH "docs/implementazione/selezione-versioni-recovery.md" :GIT-BLOB
   "47d2caa2887778182456420705e0228179305769")
  (:PATH "docs/implementazione/sessione-locale.md" :GIT-BLOB
   "2ecf722d1f5009738a021d2b451e71bfcf0a6c2a")
  (:PATH "docs/implementazione/slot-indice-v2.md" :GIT-BLOB
   "3badf8773cc33d0a772b9bde5741af120be1db29")
  (:PATH "docs/implementazione/snapshot-csn.md" :GIT-BLOB
   "52ce3f078d06cad8ffac89ea2baa6ad830c0df34")
  (:PATH "docs/implementazione/snapshot-verifica.md" :GIT-BLOB
   "d0ce2c9951518f30ccec2391bc8d9e3e508eaa19")
  (:PATH "docs/implementazione/stabilizzazione-archivio-metodo.md" :GIT-BLOB
   "e29923b3ea68b49f0d100baa7b41f221663d26f9")
  (:PATH "docs/implementazione/stabilizzazione-archivio.md" :GIT-BLOB
   "51adacc370255a8a7d7bb9cb32d5efd9d98cc21f")
  (:PATH "docs/implementazione/stabilizzazione-esclusiva-metodo.md" :GIT-BLOB
   "862b15afa8262596760a2b84e08ba266369e101a")
  (:PATH "docs/implementazione/stabilizzazione-nomi-recovery.md" :GIT-BLOB
   "19c7b3f57ea810a35ebe212071e06e27f61c3a21")
  (:PATH "docs/implementazione/stabilizzazione-serie-metodo.md" :GIT-BLOB
   "89673b60a8a5690b772ef365b2194470238efd14")
  (:PATH "docs/implementazione/stabilizzazione-serie.md" :GIT-BLOB
   "960b956f4841ce0d3a6e38612feee69f2666ab37")
  (:PATH "docs/implementazione/utf8-decisioni.md" :GIT-BLOB
   "ec3c6b8f92c54a84bc98d5ac21e58758152de542")
  (:PATH "docs/implementazione/utf8-metodo.md" :GIT-BLOB
   "a60c8e7ee23f78e8a53a516e2c161fc0827ff699")
  (:PATH "docs/implementazione/utf8.md" :GIT-BLOB
   "e7cf6d0c9962ed26216d07d63d052d45bb9f03e7")
  (:PATH "docs/implementazione/verificatore-offline-m1.md" :GIT-BLOB
   "acb6d215ca675bd8fb4108a1fc93d4009cc9b69e")
  (:PATH "docs/implementazione/wal-csn-decisioni.md" :GIT-BLOB
   "1a94e0e95ab7446193da420d97bedc24a721d387")
  (:PATH "docs/implementazione/wal-csn-metodo.md" :GIT-BLOB
   "8ab0ba990681d1b185ab87aad114593c0abb305a")
  (:PATH "docs/implementazione/wal-csn-revisione.md" :GIT-BLOB
   "f08e66f8b7925a5bcec55f2edf1380fc66d6c0a2")
  (:PATH "docs/implementazione/wal-csn-risultati.md" :GIT-BLOB
   "353a2d053b16ec57b6572aed1f17d1b49d8a232f")
  (:PATH "docs/implementazione/wal-csn.md" :GIT-BLOB
   "15c437c7c71674f8fc1cd5a72b3162f4f1715eba")
  (:PATH "docs/implementazione/wal-decisioni.md" :GIT-BLOB
   "e20c5c59567d8ce4800dc19e8dc5fdc2f7f0606f")
  (:PATH "docs/implementazione/wal-metodo.md" :GIT-BLOB
   "f4edff819e12b287df3cf5f00ecd3550e930f9e0")
  (:PATH "docs/implementazione/wal.md" :GIT-BLOB
   "1c4fb7c470a4cfbc6509ccb1c6f793e8bf74208c")
  (:PATH "docs/implementazione/worker-cbor-interleaving.md" :GIT-BLOB
   "02c902149e07d4ac4dfc6f6170799eb34574f09a")
  (:PATH "docs/implementazione/worker-serie-decisioni.md" :GIT-BLOB
   "ab3e69cc7051d3ce33f9b4d94cd0e2b20b49807c")
  (:PATH "docs/implementazione/worker-serie-integrazione.md" :GIT-BLOB
   "2c5bcfdaa1783a21adba6911300d0baf7d12f339")
  (:PATH "docs/implementazione/worker-serie-metodo.md" :GIT-BLOB
   "8fcb335ad6bc807d58ab2ec9033f948421737de5")
  (:PATH "docs/implementazione/worker-serie-revisione.md" :GIT-BLOB
   "8fa6801e99ffb1abca08a0861883ace20672bd2c")
  (:PATH "docs/implementazione/worker-serie-risultati.md" :GIT-BLOB
   "63c27916925bec8cfbc39c0c9d558eb444e6dad2")
  (:PATH "docs/implementazione/worker-serie.md" :GIT-BLOB
   "f35b46574ff72f1ddac7498c601be30c990d859e")
  (:PATH "docs/implementazione/writer-handoff-decisioni.md" :GIT-BLOB
   "ebea51d87dc4f0c750be5834f48d66aac19c7e2d")
  (:PATH "docs/implementazione/writer-handoff-metodo.md" :GIT-BLOB
   "9cd61461e8bfad2d757011db0307229f1517a0d2")
  (:PATH "docs/implementazione/writer-handoff-revisione.md" :GIT-BLOB
   "865c639e5d48a0a77133b6fbe033d78113f703ac")
  (:PATH "docs/implementazione/writer-handoff-risultati.md" :GIT-BLOB
   "1dd65b133120e4f660ed14e674caa8d9af55cfc9")
  (:PATH "docs/implementazione/writer-handoff.md" :GIT-BLOB
   "4812ec2f65bf772695877b5760a2528fb69a70ef")
  (:PATH "docs/implementazione/writer-ready-decisioni.md" :GIT-BLOB
   "debe8bfd28a95306a16004ca1ccb20ff2bf85fd6")
  (:PATH "docs/implementazione/writer-ready-metodo.md" :GIT-BLOB
   "7a1ffa13a41b58db26e43bb4090a5d7b6732e512")
  (:PATH "docs/implementazione/writer-ready-revisione.md" :GIT-BLOB
   "f0ab347bf7c6974b7968e96b9615238b2b14713d")
  (:PATH "docs/implementazione/writer-ready-risultati.md" :GIT-BLOB
   "b3d19a3668170d14b2ee8a1cec101a27334a8d41")
  (:PATH "docs/implementazione/writer-ready.md" :GIT-BLOB
   "14bca7f6cd2c9976cbfdbe3a24a146bc46a34d79")
  (:PATH "docs/implementazione/writer-recycle-decisioni.md" :GIT-BLOB
   "f0fd5c63f1adaf9e08e3a7f03dd3fa62bc10aea5")
  (:PATH "docs/implementazione/writer-recycle-metodo.md" :GIT-BLOB
   "c96e7d84ba793911aca73e1deafe6da49509b879")
  (:PATH "docs/implementazione/writer-recycle-revisione.md" :GIT-BLOB
   "8543024839bb87730a16489183b141a010d48cfc")
  (:PATH "docs/implementazione/writer-recycle-risultati.md" :GIT-BLOB
   "234ef34a0065f902f68cdc9432513444a303731c")
  (:PATH "docs/implementazione/writer-recycle.md" :GIT-BLOB
   "ae34240b8fcb8fecbda5492828281de203dc5327")
  (:PATH "docs/implementazione/writer-worker-decisioni.md" :GIT-BLOB
   "07bc53c1a476b0f93bf860fa18c97573d96c656f")
  (:PATH "docs/implementazione/writer-worker-integrazione.md" :GIT-BLOB
   "e120e67c134bd2b9ddbbf55259f5195a3ef4989c")
  (:PATH "docs/implementazione/writer-worker-metodo.md" :GIT-BLOB
   "85cdbcee3cc2985f6935c6508b71ae9eccf58c99")
  (:PATH "docs/implementazione/writer-worker-revisione.md" :GIT-BLOB
   "a7329d98d65dd7a94773a87d27f7e3d3871469bf")
  (:PATH "docs/implementazione/writer-worker-risultati.md" :GIT-BLOB
   "370e2848280af70fbee9085f4c5f1fb44b110889")
  (:PATH "docs/implementazione/writer-worker.md" :GIT-BLOB
   "3a9260af22a77d11d636a787613bd50668ffc1cd")
  (:PATH "docs/invarianti.md" :GIT-BLOB
   "1600a7f92e73a45f44214bfb2074d0c5cf6decec")
  (:PATH "docs/legal/README.md" :GIT-BLOB
   "149c30dbb116c197f5046d245f765803ed6112f4")
  (:PATH "docs/legal/accessibility.md" :GIT-BLOB
   "f0075a299d3f10c36f250343da01908f39bfc447")
  (:PATH "docs/legal/distribution.md" :GIT-BLOB
   "60ae06a99a28b346e28a28dba81925e38b762192")
  (:PATH "docs/legal/privacy.md" :GIT-BLOB
   "668c2ffde82f4149697d070851e5fdbf281937b0")
  (:PATH "docs/legal/review-2026-10-31.md" :GIT-BLOB
   "8e4053b788081e583340d3531e8c618eba2ef312")
  (:PATH "docs/legal/third-party.md" :GIT-BLOB
   "308d64af3e3901e8c8ea6209ec772f65bd55796e")
  (:PATH "docs/limiti.md" :GIT-BLOB "18a03d0c1262b4ddaddf5ff1cb3dd1777f216c3c")
  (:PATH "docs/lisp-api.md" :GIT-BLOB
   "32c0e75b4f43c2f39f2f91a2584e82ccb47f1cfb")
  (:PATH "docs/principi-di-ingegneria.md" :GIT-BLOB
   "f639c868ec4145ce4d712345973822ada77abb6a")
  (:PATH "docs/questioni-aperte.md" :GIT-BLOB
   "6c2425c43abbc961ab2845fca2e3ea069b39eb81")
  (:PATH "docs/riferimenti.md" :GIT-BLOB
   "9addadca061376e75319617301e590e010ab8467")
  (:PATH "docs/roadmap.md" :GIT-BLOB
   "6b24c490e7a4e90e7d0d751c0796f89a23849c39")
  (:PATH "docs/specifica/specifica-originale.md" :GIT-BLOB
   "113bbeaa93a2032b3a642d626836c1d5f5d16c4f")
  (:PATH "docs/tracciabilita/README.md" :GIT-BLOB
   "df1e19c126d44b07fecbf153fcafa2c9af44e861")
  (:PATH "docs/tracciabilita/matrice.md" :GIT-BLOB
   "641464f959c98af64505d506c6c58f7ead9ef3b8")
  (:PATH "docs/tracciabilita/requisiti.lisp" :GIT-BLOB
   "c13d990acb745aa485147b8139293693c2b45504")
  (:PATH "docs/valutazione/README.md" :GIT-BLOB
   "b7ef23de41612f981d34a97641e52902a1840a50")
  (:PATH "docs/valutazione/analisi-critica.md" :GIT-BLOB
   "33f78a2faae61cd73459658d3ba2a88e2ecafe81")
  (:PATH "docs/valutazione/caso-duso-nntp.md" :GIT-BLOB
   "b6a035e1d66b869f40a42e07f2021a42d7de2859")
  (:PATH "docs/valutazione/conservazione-compatta.md" :GIT-BLOB
   "972ca495cf51f54d16f3c33ca31fe890b6db7806")
  (:PATH "docs/valutazione/cronologia.md" :GIT-BLOB
   "be43f507343a1c75d71d9e4ada287a9c2fc0de12")
  (:PATH "docs/valutazione/piano-spike.md" :GIT-BLOB
   "32026027782790da44884b029c4bae89d5f4e1fd")
  (:PATH "docs/valutazione/registro-delle-prove.md" :GIT-BLOB
   "32e72f3b579ee02d5a5e0e897a7618434b02e60d")
  (:PATH "docs/valutazione/registro-rischi.md" :GIT-BLOB
   "2eeb123c80d9f061d21d2f1a31c57613d7707506")
  (:PATH "docs/valutazione/risultati-2026-10-08.md" :GIT-BLOB
   "a01e78e3fd9dbfe2705fa6fda631d9c387b3bc91")
  (:PATH "docs/valutazione/risultati-SPK-01-lettura-2026-10-08.md" :GIT-BLOB
   "c3173768fe23a50691d7106bddbc8c46bb8cd040")
  (:PATH "docs/valutazione/risultati-SPK-04-2026-10-08.md" :GIT-BLOB
   "ed0b8c472645dd6e31178034268a7e60a34e09be")
  (:PATH "docs/valutazione/risultati-SPK-05-2026-10-08.md" :GIT-BLOB
   "603665f1033eb1a62f8b9a4115250a16cf39b429")
  (:PATH "docs/valutazione/risultati-SPK-06-2026-10-08.md" :GIT-BLOB
   "dca0a8b0aa20c8d038dcbc11023182fd552de10f")
  (:PATH "docs/valutazione/risultati-SPK-07-08-2026-10-08.md" :GIT-BLOB
   "45bf66ebba21b28f569e6f12344277dce7245cd9")
  (:PATH "docs/valutazione/risultati-SPK-08-bitmap-2026-10-08.md" :GIT-BLOB
   "11d712a7a3432a89299a2f5d7f23736d596d7e40")
  (:PATH "docs/valutazione/stime-ordine-di-grandezza.md" :GIT-BLOB
   "f3eecb3e77252633aac4a62f1100a77b64ca91e0")
  (:PATH "examples/local-roundtrip.lisp" :GIT-BLOB
   "f814d10935f22272e5a440e92e7c8109dda16be8")
  (:PATH "legal/algorithms/xxHash-v0.8.3-NOTICES.txt" :GIT-BLOB
   "1ac346f5f0bff517073cca31f1509f39a5818d55")
  (:PATH "legal/notice-files.lisp" :GIT-BLOB
   "30a68c858f462c6ef601c270ac48603374b149d9")
  (:PATH "legal/runtime/SBCL-2.6.9-COPYING.txt" :GIT-BLOB
   "4220b33974e7fc04036b2b5600cb3ca88ce2c4c3")
  (:PATH "spikes/README.md" :GIT-BLOB
   "f835fdd46c43312889de749d525290e541e891f3")
  (:PATH "spikes/SPK-01-primary-index/README.md" :GIT-BLOB
   "c2c2487c33cadbec5444b81073eb9e417a16c42f")
  (:PATH "spikes/SPK-01-primary-index/bench-lettura-buffer.lisp" :GIT-BLOB
   "2fd1b13855a94dc946f9f1b5e1c7556558b7e0c0")
  (:PATH "spikes/SPK-01-primary-index/check-lettura-buffer.lisp" :GIT-BLOB
   "fd32c5260ffb7c6e96cf1a420765eb01effe70bc")
  (:PATH "spikes/SPK-01-primary-index/core.lisp" :GIT-BLOB
   "c019f6ad53e173a0d336a4dbfaf903e274a66f08")
  (:PATH "spikes/SPK-01-primary-index/lettura-buffer.lisp" :GIT-BLOB
   "34b3574a554ca4e03a34f04b3fc66022abb7893b")
  (:PATH "spikes/SPK-01-primary-index/metodo-bench-lettura-buffer.md" :GIT-BLOB
   "03a90c690b4673695f0380f81f0cf68e4da8eda4")
  (:PATH "spikes/SPK-01-primary-index/metodo-check-lettura-buffer.md" :GIT-BLOB
   "049ff2032103d3d6a6a8049fa9d803d6f82beeaf")
  (:PATH "spikes/SPK-01-primary-index/metodo-integrazione-lettura-buffer.md"
   :GIT-BLOB "cd79005b8100b79cbbca35a5677125af54f5e854")
  (:PATH "spikes/SPK-01-primary-index/metodo-lettura-buffer.md" :GIT-BLOB
   "b388bbb2a067537c8b03b046d63ed6fd5201fa58")
  (:PATH "spikes/SPK-01-primary-index/profile.lisp" :GIT-BLOB
   "a71fde100e32072b6e7b010228683b640ea4ff9a")
  (:PATH "spikes/SPK-01-primary-index/run.lisp" :GIT-BLOB
   "b6e680b0c2d1a96c1d7fc3b0e133c80b6564a01e")
  (:PATH "spikes/SPK-02-gc/README.md" :GIT-BLOB
   "be57e2f216618fb65d5dde48e8d29938d377a009")
  (:PATH "spikes/SPK-02-gc/core.lisp" :GIT-BLOB
   "01f6760c75fa6e96a480fca41b1426941a9f703d")
  (:PATH "spikes/SPK-02-gc/run.lisp" :GIT-BLOB
   "9fbe499100da40c2f7a14072af67c35c734949c5")
  (:PATH "spikes/SPK-03-group-commit/README.md" :GIT-BLOB
   "6452906fa525035cf6abe7967f05778aeaf17f76")
  (:PATH "spikes/SPK-03-group-commit/core.lisp" :GIT-BLOB
   "d3c58f2866e299ba27b0fa820c20317438774410")
  (:PATH "spikes/SPK-03-group-commit/run.lisp" :GIT-BLOB
   "c0b093e87028dd587c43d3cd52e59492270fdc38")
  (:PATH "spikes/SPK-04-writer-pool/README.md" :GIT-BLOB
   "014f488b7b50a9439b36f49afd6b6f0f11295d84")
  (:PATH "spikes/SPK-04-writer-pool/core.lisp" :GIT-BLOB
   "557b32e6378290c46c7d9b128fc8e59a0e7e0a44")
  (:PATH "spikes/SPK-04-writer-pool/parcheggi.lisp" :GIT-BLOB
   "c0fee7b738395fcaf3359f297282cd266ce6dfad")
  (:PATH "spikes/SPK-04-writer-pool/pool.lisp" :GIT-BLOB
   "cbec51aad2b64fb8c5be026891eff859ba371c18")
  (:PATH "spikes/SPK-04-writer-pool/run.lisp" :GIT-BLOB
   "77056cc1f695574ed0f4d34795b99aaea736f378")
  (:PATH "spikes/SPK-05-segment-read/README.md" :GIT-BLOB
   "badf96cfb95709afc9174e40b521ac75c6adac8c")
  (:PATH "spikes/SPK-05-segment-read/core.lisp" :GIT-BLOB
   "15fad418184ce9969c337b181317b855ede9f5ce")
  (:PATH "spikes/SPK-05-segment-read/io.lisp" :GIT-BLOB
   "ba470bce3cae0ce14888dbec6e26c5656e9bbd1a")
  (:PATH "spikes/SPK-05-segment-read/record.lisp" :GIT-BLOB
   "baea7833c8e6f9a49b5ea2f8ee15f76fe35f93fe")
  (:PATH "spikes/SPK-05-segment-read/run.lisp" :GIT-BLOB
   "c67a3ae8e672f96d9105deb935fb621b07d67afb")
  (:PATH "spikes/SPK-06-compaction-load/README.md" :GIT-BLOB
   "1a46426b6521ca207a747cd0d2a7fed0ad4ecfd1")
  (:PATH "spikes/SPK-06-compaction-load/controllore.lisp" :GIT-BLOB
   "4602972e2400d31d4d3b771f60703c68e23f0804")
  (:PATH "spikes/SPK-06-compaction-load/core.lisp" :GIT-BLOB
   "375cb97e1490e0252c04fd1a3076a17342cefd68")
  (:PATH "spikes/SPK-06-compaction-load/interferenza.lisp" :GIT-BLOB
   "9ad30ce92bdb643aeb5163e96508bf677996a4ef")
  (:PATH "spikes/SPK-06-compaction-load/run.lisp" :GIT-BLOB
   "b2863cbac49d0988b850bdeeae1713108a21bfca")
  (:PATH "spikes/SPK-07-protocols/README.md" :GIT-BLOB
   "0061c53057783cc076b2dcb9596e91017e473c47")
  (:PATH "spikes/SPK-07-protocols/byte-crash.lisp" :GIT-BLOB
   "66a6c3b458d808fc214f7c3bd96e09d239312c67")
  (:PATH "spikes/SPK-07-protocols/compaction.lisp" :GIT-BLOB
   "93483f72f3bfe43f0e2afa93b022892114a824e1")
  (:PATH "spikes/SPK-07-protocols/core.lisp" :GIT-BLOB
   "489e2732cf5bfed4cd11251bb686a5d4f4e10b3e")
  (:PATH "spikes/SPK-07-protocols/memoria.lisp" :GIT-BLOB
   "96b6cf64d481643cdba7857f339a7cb7c029b765")
  (:PATH "spikes/SPK-07-protocols/metodo-byte-crash.md" :GIT-BLOB
   "7edbb7459ca78fb41cb812d82ce1dc1c68176ea6")
  (:PATH "spikes/SPK-07-protocols/metodo-compaction.md" :GIT-BLOB
   "18246e75e94db5f4517e96e827469d6a006b30d2")
  (:PATH "spikes/SPK-07-protocols/metodo-memoria.md" :GIT-BLOB
   "0597672e814ccc60c541439e838b7e4eb491788a")
  (:PATH "spikes/SPK-07-protocols/metodo-page-lifetime.md" :GIT-BLOB
   "fba367b24467642a6e544ff86e099b143a73a925")
  (:PATH "spikes/SPK-07-protocols/metodo-pubblicazione.md" :GIT-BLOB
   "6c0034a70670b4249cd2b525c9fca3e140dbd94e")
  (:PATH "spikes/SPK-07-protocols/metodo-scadenza.md" :GIT-BLOB
   "517286df830984ba4a6ff39b03175e445afd65d7")
  (:PATH "spikes/SPK-07-protocols/metodo-seqlock-readers.md" :GIT-BLOB
   "163e4c3222c4e5771660e6463367ec6b1bc914af")
  (:PATH "spikes/SPK-07-protocols/page-lifetime.lisp" :GIT-BLOB
   "c032387167188be066737f75583738843b12c883")
  (:PATH "spikes/SPK-07-protocols/pubblicazione.lisp" :GIT-BLOB
   "d317849b3f95394a7f604b82fb131495b5b3770c")
  (:PATH "spikes/SPK-07-protocols/run-module.lisp" :GIT-BLOB
   "1ec5a1db56a76daacbc7488d8b7940aa0e16eca0")
  (:PATH "spikes/SPK-07-protocols/run.lisp" :GIT-BLOB
   "95ab6095de30d013dbf5c426f7b6c0a99d5663e6")
  (:PATH "spikes/SPK-07-protocols/scadenza.lisp" :GIT-BLOB
   "05a5e93591e2d6e96c2c7548e90888424cbb1f9f")
  (:PATH "spikes/SPK-07-protocols/seqlock-readers.lisp" :GIT-BLOB
   "b2e704bbe7e699b9df68173319f64d2ae8abc5fc")
  (:PATH "spikes/SPK-07-protocols/suite.lisp" :GIT-BLOB
   "9daf0b57d92db583544653384217105121c8627d")
  (:PATH "spikes/SPK-08-generated-code/README.md" :GIT-BLOB
   "4712fb08742000724dbbf5c1f7fac4505ca6ad4c")
  (:PATH "spikes/SPK-08-generated-code/bitmap.lisp" :GIT-BLOB
   "cbeff7e2a58f268291b01cb6a1f124533063d5d6")
  (:PATH "spikes/SPK-08-generated-code/comparison.lisp" :GIT-BLOB
   "b8b8ebfa609d6bfe9b710833f22cdff693ef46bd")
  (:PATH "spikes/SPK-08-generated-code/core-bitmap.lisp" :GIT-BLOB
   "a4be2005a702a77a631f35568778673c503c60b5")
  (:PATH "spikes/SPK-08-generated-code/crc32c-unroll32.lisp" :GIT-BLOB
   "6dbbe7218c7b5185329f099a8c1407e0f48d8648")
  (:PATH "spikes/SPK-08-generated-code/crc32c.lisp" :GIT-BLOB
   "72bccfafe9c5cb0fd5dc6392534c5be404774a64")
  (:PATH "spikes/SPK-08-generated-code/impronte.lisp" :GIT-BLOB
   "d187e3d95f0e85a0a8ae84843a67a326e803cd2c")
  (:PATH "spikes/SPK-08-generated-code/metodo-bitmap.md" :GIT-BLOB
   "680b5d9c4e112747e903e124e07cab8adbf97da9")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c-unroll32.md" :GIT-BLOB
   "d722f4f0145cca93b8cb46aa0572538df99a12e0")
  (:PATH "spikes/SPK-08-generated-code/metodo-crc32c.md" :GIT-BLOB
   "fbbb491611d807c1022c50236fe29c8d7accb2c0")
  (:PATH "spikes/SPK-08-generated-code/metodo-impronte.md" :GIT-BLOB
   "4a57493b511201112c533418f1846acdf96f35c8")
  (:PATH "spikes/SPK-08-generated-code/metodo-simd.md" :GIT-BLOB
   "1bbf37c97bcc7d527c3d5aa90cbb9217b807f3ee")
  (:PATH "spikes/SPK-08-generated-code/run-bitmap.lisp" :GIT-BLOB
   "40c3761959a7759fe2d606d66c0fe5d9efa7aca2")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c-unroll32.lisp" :GIT-BLOB
   "79033530456f565b3b14e25b56146039b5356860")
  (:PATH "spikes/SPK-08-generated-code/run-crc32c.lisp" :GIT-BLOB
   "a45f0c3e862c2174b64ac63d4ca97ae3ddf21569")
  (:PATH "spikes/SPK-08-generated-code/run.lisp" :GIT-BLOB
   "7c797afe4a6060782ce58f0cfc06f539006d117a")
  (:PATH "spikes/SPK-08-generated-code/simd.lisp" :GIT-BLOB
   "dbd551322880f1e0ddac6436c8af8f0dd85ddb9f")
  (:PATH "spikes/SPK-09-integrity/README.md" :GIT-BLOB
   "2ed0e101d31cef0967820fc70155ddd4561140fa")
  (:PATH "spikes/SPK-09-integrity/core.lisp" :GIT-BLOB
   "80cdac4c0e52703618e1f274413b2ecbe00e6b14")
  (:PATH "spikes/SPK-09-integrity/run.lisp" :GIT-BLOB
   "c95660a4df5f2e6f6eb93e1078c2c36df6dabc85")
  (:PATH "spikes/SPK-10-v2-limits/README.md" :GIT-BLOB
   "740e01ad7ddd2dc170e50454befe9a63b9eff276")
  (:PATH "spikes/SPK-10-v2-limits/cbor.lisp" :GIT-BLOB
   "d6a5c93e34a0444d64b206df875a25b380545631")
  (:PATH "spikes/SPK-10-v2-limits/codec.lisp" :GIT-BLOB
   "567c84546d29e1b8ddc5cd9e1a31b4e93519c75d")
  (:PATH "spikes/SPK-10-v2-limits/core.lisp" :GIT-BLOB
   "c5b7cfd27c663734b7d5fae481dde939418566b5")
  (:PATH "spikes/SPK-10-v2-limits/indice.lisp" :GIT-BLOB
   "bc978eb16aa7f0d69e3deac2df86057a650f8551")
  (:PATH "spikes/SPK-10-v2-limits/metodo-cbor.md" :GIT-BLOB
   "1e54780546d2bcdd623f7fa6c2faaf127bf15dae")
  (:PATH "spikes/SPK-10-v2-limits/metodo-codec.md" :GIT-BLOB
   "69ac8ef15f356257dae151e035689d8124e9a9eb")
  (:PATH "spikes/SPK-10-v2-limits/metodo-indice.md" :GIT-BLOB
   "95928362ab8fbde280a5f74be905ae2ca58729ab")
  (:PATH "spikes/SPK-10-v2-limits/metodo-migrazione.md" :GIT-BLOB
   "df0869dea4916cdb5b671a79ffa812369d043773")
  (:PATH "spikes/SPK-10-v2-limits/migrazione.lisp" :GIT-BLOB
   "cab850dc32ff9908b487b24edf3e1df2cc90008c")
  (:PATH "spikes/SPK-10-v2-limits/run.lisp" :GIT-BLOB
   "6aa63afeac91c3b75174b76daba61e354bb7fe4d")
  (:PATH "spikes/SPK-11-unix-socket/README.md" :GIT-BLOB
   "47d0cf7d3d5b5541e38cb47814dbb1f0197ffbdc")
  (:PATH "spikes/SPK-11-unix-socket/codec-inputs.lisp" :GIT-BLOB
   "d0db0b9a40edd8e47d5e758f012bb45d489eaa89")
  (:PATH "spikes/SPK-11-unix-socket/core.lisp" :GIT-BLOB
   "7b526422d5be781d26213e128a49a07bc3e25788")
  (:PATH "spikes/SPK-11-unix-socket/io-checks.lisp" :GIT-BLOB
   "b0bfea2d8042566852c6d23568087db11fd2bfe2")
  (:PATH "spikes/SPK-11-unix-socket/io-state.lisp" :GIT-BLOB
   "30db13814ebed2fb85a10ac1858cd8ec9931a6ee")
  (:PATH "spikes/SPK-11-unix-socket/io-transport.lisp" :GIT-BLOB
   "5a1f26feeae1f415557f28ae62ee1b3297314423")
  (:PATH "spikes/SPK-11-unix-socket/native-io-method.md" :GIT-BLOB
   "a90da59a3ecad08654d619a56c2ced177db88a40")
  (:PATH "spikes/SPK-11-unix-socket/native-io.lisp" :GIT-BLOB
   "0740e3d5542c6ad5b2d4106fb73c26f4e97ab0c5")
  (:PATH "spikes/SPK-11-unix-socket/run.lisp" :GIT-BLOB
   "3c83e79a935184239c21f02296f262acf4f5c64d")
  (:PATH "spikes/SPK-11-unix-socket/scenarios.lisp" :GIT-BLOB
   "e192b075c58d0b554f1fa1c3b09acf86607ad9e1")
  (:PATH "spikes/SPK-11-unix-socket/session-checks.lisp" :GIT-BLOB
   "75d5e70617a33fa738b911397d8bab22ea3e1faf")
  (:PATH "spikes/SPK-11-unix-socket/session-method.md" :GIT-BLOB
   "ebd5dce74e96860ace17a05cf7e14f940adb126f")
  (:PATH "spikes/SPK-11-unix-socket/session-model.lisp" :GIT-BLOB
   "02b389e0579f4c268bc35afc9e2eb75ab501e88a")
  (:PATH "spikes/SPK-11-unix-socket/session-transport.lisp" :GIT-BLOB
   "a79fed48095bd01e56860372badc1e168ac8eb7a")
  (:PATH "spikes/SPK-11-unix-socket/session-wire.lisp" :GIT-BLOB
   "d3bd3a22eb6ab70554f13ca798b8ea5ab310e863")
  (:PATH "spikes/SPK-11-unix-socket/transport.lisp" :GIT-BLOB
   "413d13844d7fccc8d036832778851ceeb26dbc33")
  (:PATH "spikes/core-code-review.lisp" :GIT-BLOB
   "894a03026e1d4c55f8bde65ba79d64e2775d1826")
  (:PATH "spikes/evidence/README.md" :GIT-BLOB
   "d0dd48506d19490ae1c864f86f4606845241a15d")
  (:PATH "spikes/evidence/history.lisp" :GIT-BLOB
   "f210350eb462c1f3d45f24217f004775496b0eaa")
  (:PATH "spikes/evidence/snapshot.lisp" :GIT-BLOB
   "9ea68544e9490d6598d6361ae0bac6e27a69ce4e")
  (:PATH "spikes/verify-m1-check.lisp" :GIT-BLOB
   "5ec3e4bf45087fec1fd8f878f746dfec63bbb1ab")
  (:PATH "src/active/package.lisp" :GIT-BLOB
   "fbd3a32b30808508424c007ece26c9f3ea9ad0a9")
  (:PATH "src/active/preflight.lisp" :GIT-BLOB
   "9a7da536a7286f5996bf1720db7f9b9dbf20abff")
  (:PATH "src/active/prepare.lisp" :GIT-BLOB
   "e6739a357bdce50ca6bfda7dcd147ce8ffb790fd")
  (:PATH "src/active/source.lisp" :GIT-BLOB
   "27316c9e39b54ff4b2f6b4fe491ab7e67197a950")
  (:PATH "src/active/types.lisp" :GIT-BLOB
   "fc4c2d3ac0839aab37b91d4e017cdaf18bc5041e")
  (:PATH "src/cache/build.lisp" :GIT-BLOB
   "b0230656edbe3dea63568e74a97e5193cab7c54a")
  (:PATH "src/cache/clock.lisp" :GIT-BLOB
   "a1db79505e00f465b0f0debacbcbd8aad60c5b75")
  (:PATH "src/cache/core.lisp" :GIT-BLOB
   "9725836f0c142b5e292fea4d073f5fbc52b99825")
  (:PATH "src/cache/package.lisp" :GIT-BLOB
   "c86ef56ec05e92ebc0fa155423289775970eedd2")
  (:PATH "src/cache/read.lisp" :GIT-BLOB
   "84b090e318216a832ab684fc5a936c68e465c169")
  (:PATH "src/cache/types.lisp" :GIT-BLOB
   "93ecc29914d02b4b6066896de8c2590906ca91bc")
  (:PATH "src/cache/write.lisp" :GIT-BLOB
   "03bdfeeef2e2639030d3509bd6905364c55f345a")
  (:PATH "src/codec/cbor-array-input.lisp" :GIT-BLOB
   "1b028f9e5f945266f1144b664bf206e89f603863")
  (:PATH "src/codec/cbor-array-write.lisp" :GIT-BLOB
   "625b61e204f7485e1015d109426810ef9d92827c")
  (:PATH "src/codec/cbor-float-minimal.lisp" :GIT-BLOB
   "b7c915a734f60d820debb0694a09fcc8706c556b")
  (:PATH "src/codec/cbor-float-narrow.lisp" :GIT-BLOB
   "a2424c60204a55c7ec315de4446e41e243a1afca")
  (:PATH "src/codec/cbor-float-write.lisp" :GIT-BLOB
   "5a44cea28eb51016ce5155ebdf5750b93d15a1b3")
  (:PATH "src/codec/cbor-header.lisp" :GIT-BLOB
   "646ae0cc73acd7cf38882c0066cda7feecc68ca7")
  (:PATH "src/codec/cbor-item-read.lisp" :GIT-BLOB
   "e95db7d9f407e9e0039dc8892e4af8065490d99d")
  (:PATH "src/codec/cbor-map-input.lisp" :GIT-BLOB
   "87c9fd9dd6eb1f3ee1b79bdf2957801762601d97")
  (:PATH "src/codec/cbor-map-write.lisp" :GIT-BLOB
   "84887090a1fa543da817bd096528b576f3d58d9e")
  (:PATH "src/codec/cbor-minimal.lisp" :GIT-BLOB
   "0c424427595a99e281ec41009f1210a2978dc693")
  (:PATH "src/codec/cbor-package.lisp" :GIT-BLOB
   "3e31d60234585442baa5664be96a83915e034397")
  (:PATH "src/codec/cbor-scan-input.lisp" :GIT-BLOB
   "f7b702e065a9a3183f63ee68e784d6767ca2d6d1")
  (:PATH "src/codec/cbor-scan-items.lisp" :GIT-BLOB
   "fd984a4c3069787c6d0a45fab8bf1854c9fcf00a")
  (:PATH "src/codec/cbor-scan-minimal.lisp" :GIT-BLOB
   "3ee967ae0158b992fd2629dd79e8f4c4b6c5edcf")
  (:PATH "src/codec/cbor-scan-stack.lisp" :GIT-BLOB
   "dc2141629f609c56bb852b92699b07188a29b769")
  (:PATH "src/codec/cbor-scan.lisp" :GIT-BLOB
   "2fb5a339d2131187f3b62a41ee1b96b1d84fac1b")
  (:PATH "src/codec/cbor-simple-write.lisp" :GIT-BLOB
   "d9c686fef43c16c5cbf85672b2480a3d0340edfc")
  (:PATH "src/codec/cbor-space.lisp" :GIT-BLOB
   "37d9b785db8645666403b3d2a45f29da4fb9cd55")
  (:PATH "src/codec/cbor-string-read.lisp" :GIT-BLOB
   "446498b0f3b0f014471312eeb01b3d9a254b6535")
  (:PATH "src/codec/cbor-string-write.lisp" :GIT-BLOB
   "a9028c0b30a22367baad2711346a5517089b1940")
  (:PATH "src/codec/cbor-tag-input.lisp" :GIT-BLOB
   "760e81952f8eb3210465a6cea5c0b89c3f15c5a4")
  (:PATH "src/codec/cbor-tag-write.lisp" :GIT-BLOB
   "4680d759cf12aaa61df5823cb86e71ed7379914c")
  (:PATH "src/codec/cbor-write.lisp" :GIT-BLOB
   "159033291735d23258b340f8da17ad6bd001ccbf")
  (:PATH "src/codec/package.lisp" :GIT-BLOB
   "7139b8ce1a947efe6599f2cbbdf78a02e35a68f1")
  (:PATH "src/codec/utf8.lisp" :GIT-BLOB
   "685040c58e99547c42b0577ffecc8a86de1a680e")
  (:PATH "src/control/build.lisp" :GIT-BLOB
   "d5aca4f9ade3c126e88709f1ada1a9e39132b6a1")
  (:PATH "src/control/dependency.lisp" :GIT-BLOB
   "144f908c5cafddc397dd8a1cab04cd641d93a32c")
  (:PATH "src/control/package.lisp" :GIT-BLOB
   "e56a6bb83abe9441350baa46573d74c6d55edf4e")
  (:PATH "src/control/preflight.lisp" :GIT-BLOB
   "850a8f3bedb592dad251e36d7e95ad9fa993979d")
  (:PATH "src/control/prepare.lisp" :GIT-BLOB
   "51cdc2f60ef3da074e98f5bbabd1bb1b4ffbd6ed")
  (:PATH "src/control/publication-read.lisp" :GIT-BLOB
   "a5ebb2f8fafe283f3816d48e633ef8471bfbf4ba")
  (:PATH "src/control/publication.lisp" :GIT-BLOB
   "c8c482c65af3a94bea9acc38b3b93f04933c93b1")
  (:PATH "src/control/recovery-publication.lisp" :GIT-BLOB
   "b01545b6647f5dbac8097dcab394260fb7f9d3cd")
  (:PATH "src/control/recovery-read.lisp" :GIT-BLOB
   "430665c20905e5f7d67245e2d7503bb0f9e0c11f")
  (:PATH "src/control/recovery-types.lisp" :GIT-BLOB
   "2ac4f985eec224f17cea5658cd9d42f4aed99cce")
  (:PATH "src/control/transfer.lisp" :GIT-BLOB
   "69bb7c2e27817201c5533fa4d6099a26750a38b7")
  (:PATH "src/control/types.lisp" :GIT-BLOB
   "7eaa6e2298ac264b7d64c1f7a78de8d1fab8ce09")
  (:PATH "src/csn/package.lisp" :GIT-BLOB
   "c2ff554d80181b48d8ba414e9d2c6a84080cb413")
  (:PATH "src/csn/registry.lisp" :GIT-BLOB
   "c46fd76164808980af1d8b639890b3cc0ce8fb79")
  (:PATH "src/dispatch/begin.lisp" :GIT-BLOB
   "bb45bcad39e438aa082e92d01358d1059cc5fd20")
  (:PATH "src/dispatch/build.lisp" :GIT-BLOB
   "9d1c974830e92918b572af978e8a2b4acae257b6")
  (:PATH "src/dispatch/claim.lisp" :GIT-BLOB
   "a9d55f610fbd14b5bff7f9d6c2a6c8abb7ba405c")
  (:PATH "src/dispatch/package.lisp" :GIT-BLOB
   "db21c798588ff4a88be5b69b5fbe72bc84811a46")
  (:PATH "src/dispatch/recycle.lisp" :GIT-BLOB
   "57955f63a0cfc4efc3f7f742fd479c032dcec5b2")
  (:PATH "src/dispatch/start.lisp" :GIT-BLOB
   "4d519c9fba0c085d5789c2883c8d04079e3933ea")
  (:PATH "src/dispatch/step.lisp" :GIT-BLOB
   "36c8c1e84c7329f4a0b24186e09a40b2ce2d2b61")
  (:PATH "src/dispatch/types.lisp" :GIT-BLOB
   "6f3b3841a3158cac6daf70cc8a1ae3984f52566c")
  (:PATH "src/engine/adopt.lisp" :GIT-BLOB
   "e91cde14fcff879a1858b28c6063e5188dca4da0")
  (:PATH "src/engine/compaction-control.lisp" :GIT-BLOB
   "02cbb0127a3e9519ed0dc90730f077ade17fb5dd")
  (:PATH "src/engine/compaction-install.lisp" :GIT-BLOB
   "167777a12cf87a02b36a73c5609d098d9d8d1b46")
  (:PATH "src/engine/compaction-plan.lisp" :GIT-BLOB
   "d255c8440ee3abb0c190801e7c5b2e1a4872b47e")
  (:PATH "src/engine/compaction-reclaim.lisp" :GIT-BLOB
   "00076045f47b9b8a5a4a0aeee449a3a0cc5e2047")
  (:PATH "src/engine/compaction-relocate.lisp" :GIT-BLOB
   "3f316d79bf63b30bb5fa0cbac38927cf2a6e540d")
  (:PATH "src/engine/compaction-scan.lisp" :GIT-BLOB
   "942e0b2ba2be30a2e94efa1c80564dd7159e322a")
  (:PATH "src/engine/compaction-types.lisp" :GIT-BLOB
   "ee6f36958a147af9cdabdfee2ebe77752476da74")
  (:PATH "src/engine/compaction-verify.lisp" :GIT-BLOB
   "57628bb40f5be4c42b4366e81a0662f7f98c0137")
  (:PATH "src/engine/compaction-write.lisp" :GIT-BLOB
   "41cc966628e64d765c8a8f9d132321451025a3bd")
  (:PATH "src/engine/compaction.lisp" :GIT-BLOB
   "1eac672cf412fc36ae6fbfe5d8b4e7b93dcf480e")
  (:PATH "src/engine/conditional-group-types.lisp" :GIT-BLOB
   "f018f3b3512695c2fd5cc35f88e0e04ca90aef19")
  (:PATH "src/engine/conditional-group.lisp" :GIT-BLOB
   "f502618dc0a4c33aa5024408baccb116ed943c94")
  (:PATH "src/engine/conditional.lisp" :GIT-BLOB
   "e31cf1694c34220247c84e57022561e3757aa796")
  (:PATH "src/engine/config.lisp" :GIT-BLOB
   "354198f7b04489a46d0a67018d181a4c8668a42e")
  (:PATH "src/engine/delta-location.lisp" :GIT-BLOB
   "367601a853f8d2dd155b1dc0002b86d1b4bcdd5b")
  (:PATH "src/engine/delta-types.lisp" :GIT-BLOB
   "539f08cdb3736546b2b1556f81050d6c5d09ece9")
  (:PATH "src/engine/delta.lisp" :GIT-BLOB
   "b865dc6c8be351c3e89fcddbce61a4e0d7a2dd5d")
  (:PATH "src/engine/files.lisp" :GIT-BLOB
   "eda0f6adb8eb34225b6775b8ef666224e753deda")
  (:PATH "src/engine/image-activation.lisp" :GIT-BLOB
   "51ef93215340364bc2c881f3e7efa6a47aac6aa8")
  (:PATH "src/engine/image-auto-types.lisp" :GIT-BLOB
   "8879e3aa9b00d18cb138da9ca6d04028816502af")
  (:PATH "src/engine/image-auto-write.lisp" :GIT-BLOB
   "ac1ad97829a4b076b6f223e9e010c55752bf3066")
  (:PATH "src/engine/image-auto.lisp" :GIT-BLOB
   "0449392da3326308f5697fc231d24d329a691db8")
  (:PATH "src/engine/image-build-io.lisp" :GIT-BLOB
   "fbd185cd56d4d980575c4d0fec5597b715074f61")
  (:PATH "src/engine/image-build-plan.lisp" :GIT-BLOB
   "ccd01ee41d0d7a103680785731c5271a54f6f2df")
  (:PATH "src/engine/image-build-read.lisp" :GIT-BLOB
   "b11e63f292b93ddaee8b0c645d525a175a1906b0")
  (:PATH "src/engine/image-build-tree.lisp" :GIT-BLOB
   "d9a657c2fbdbb294e34fe8ba40c4fe8c8df11f03")
  (:PATH "src/engine/image-build-types.lisp" :GIT-BLOB
   "d2aacfe57703a7a99354657e4823a641d6eabb43")
  (:PATH "src/engine/image-build.lisp" :GIT-BLOB
   "a4c8ad027a796610299f457399f566ac0ca4284d")
  (:PATH "src/engine/image-config.lisp" :GIT-BLOB
   "47becee77666bb573500cc1d23735e627e65411b")
  (:PATH "src/engine/image-discovery-config.lisp" :GIT-BLOB
   "66c7f2c7f7eb87e0147d858c11787ffdd06b14bb")
  (:PATH "src/engine/image-discovery.lisp" :GIT-BLOB
   "aa41ecbc41a335a25fd3f62761147be516ebce6c")
  (:PATH "src/engine/image-maintenance-config.lisp" :GIT-BLOB
   "cbd5f1cdde00a60ee8cd952898c06e205c8edf1c")
  (:PATH "src/engine/image-maintenance.lisp" :GIT-BLOB
   "44bdff3e98ff1176b51b1bbc20bb8f54b94f5f3d")
  (:PATH "src/engine/image-recovery.lisp" :GIT-BLOB
   "f42286cf6d43cd486d9c4a79f764c99c35e2aa37")
  (:PATH "src/engine/image-renewal.lisp" :GIT-BLOB
   "0e6c21fcdec1d316551417b024e1ba5bda472abc")
  (:PATH "src/engine/image-source.lisp" :GIT-BLOB
   "8b7c7ecdebbf07ada9b68037976be5af53a6a106")
  (:PATH "src/engine/index-auto-api.lisp" :GIT-BLOB
   "1241871a3195c1c42b890e08373803a816809817")
  (:PATH "src/engine/index-auto-apply.lisp" :GIT-BLOB
   "7062c70c0f6322cda8de3f089bab2a216dae3d44")
  (:PATH "src/engine/index-auto-files.lisp" :GIT-BLOB
   "2c79ded6eb822d4f238f31cd7756bcdc79d5be7d")
  (:PATH "src/engine/index-auto-memory.lisp" :GIT-BLOB
   "8199f78030cc2d21af63d223c7d9cb99cb22b4fb")
  (:PATH "src/engine/index-auto-migrate.lisp" :GIT-BLOB
   "52e44cd130f7dc77bf6fa0be130dfc4827b4ec59")
  (:PATH "src/engine/index-auto-resolver.lisp" :GIT-BLOB
   "82554d4e3b9382c60bbdb0cf2986a4e75af1dafa")
  (:PATH "src/engine/index-auto-types.lisp" :GIT-BLOB
   "7d848c894841cdcf2abf615cd8140568a264351c")
  (:PATH "src/engine/index.lisp" :GIT-BLOB
   "650e3e008a6e489ebc3972366724edab5a3189c0")
  (:PATH "src/engine/initialize.lisp" :GIT-BLOB
   "8c39b866a402a30b1aa1ef7409e675f367e4ec97")
  (:PATH "src/engine/lifecycle.lisp" :GIT-BLOB
   "717898da19e3288ee03ac782959c23d32c9b8170")
  (:PATH "src/engine/package.lisp" :GIT-BLOB
   "b67b3b15539954ba4d3c92fcb3f4ccfafebca4c1")
  (:PATH "src/engine/preflight.lisp" :GIT-BLOB
   "272b6ffeb63fa9536bade7a0fd48764340128e4c")
  (:PATH "src/engine/read.lisp" :GIT-BLOB
   "a1737e9c70b317464520811512a42d4ae059bbdd")
  (:PATH "src/engine/record-cache.lisp" :GIT-BLOB
   "6d00296bffb12094dafd46a4ac898c9a20f81dfa")
  (:PATH "src/engine/recovery.lisp" :GIT-BLOB
   "05b64c0a49c59c209af8bac92f6823c193a92122")
  (:PATH "src/engine/rotation.lisp" :GIT-BLOB
   "db73c93ab163dc4cf2699cb6c357cfa3591be092")
  (:PATH "src/engine/startup.lisp" :GIT-BLOB
   "5245c459ca92fa0f69ff1810befc748fbb303f7f")
  (:PATH "src/engine/types.lisp" :GIT-BLOB
   "9a3c91e2a88056e611555fad3f5bd90c3ec1cbdd")
  (:PATH "src/engine/write-group-build.lisp" :GIT-BLOB
   "20a777cd92be4b8f91dad208132945c42309496c")
  (:PATH "src/engine/write-group-commit.lisp" :GIT-BLOB
   "18a21f787b8bdb1f41dd4f1ee3e215253cd62c0c")
  (:PATH "src/engine/write-group-index.lisp" :GIT-BLOB
   "b28196235d2b2853edbe75fcb5d024c0e7ea1b11")
  (:PATH "src/engine/write-group-legacy.lisp" :GIT-BLOB
   "a0c17966476bfa9d5a008bec9b6071c91070040f")
  (:PATH "src/engine/write-group-plan.lisp" :GIT-BLOB
   "d126d7176bef13a8dc19bac5836581cb65dfbd35")
  (:PATH "src/engine/write-group-types.lisp" :GIT-BLOB
   "2f1e78aef52cbdb0aabc663873b832eb31713bba")
  (:PATH "src/engine/write-group.lisp" :GIT-BLOB
   "bacee8da25a18c7736921c10357a344394eb5ed8")
  (:PATH "src/engine/write.lisp" :GIT-BLOB
   "3b83c17a8bf510c110648b4257fe9b8df43b6bf5")
  (:PATH "src/epochs/core.lisp" :GIT-BLOB
   "93dbc244d3e8a86e64254b31e2954102f65ab149")
  (:PATH "src/epochs/package.lisp" :GIT-BLOB
   "43bc1aefdeec0e19e729160b3aa085091634a11a")
  (:PATH "src/epochs/read.lisp" :GIT-BLOB
   "0fc4c81f23e27dabfe52485a3976ec3eb390eb4c")
  (:PATH "src/epochs/reclaim.lisp" :GIT-BLOB
   "e0d503d2ad85689ac6162636857f4e44f2b5c7f9")
  (:PATH "src/epochs/retire.lisp" :GIT-BLOB
   "474ddacfc871629aad94b6d59b87de7cd4349475")
  (:PATH "src/epochs/types.lisp" :GIT-BLOB
   "838611d288696767dc539b155fcfefe3feec79e2")
  (:PATH "src/execution/handoff.lisp" :GIT-BLOB
   "bbed8c36a799b57baebe6350dd96c3a968dd05e7")
  (:PATH "src/execution/package.lisp" :GIT-BLOB
   "dcdf82cb17b20f6d4e96cc94d3f1522520c3a236")
  (:PATH "src/execution/queue.lisp" :GIT-BLOB
   "b27df62179c9f43132c445c82f0c2bf4ee78f366")
  (:PATH "src/execution/ready-recycle.lisp" :GIT-BLOB
   "5d4e27472170bfffa85a6e8aac0760236e7fefb6")
  (:PATH "src/execution/ready-types.lisp" :GIT-BLOB
   "f79bbd85269d50eb929816276353b2fbb85f92c9")
  (:PATH "src/execution/ready.lisp" :GIT-BLOB
   "a36b9bc921e8d58f9cf3a10a8426eb388e710226")
  (:PATH "src/execution/worker-boundary.lisp" :GIT-BLOB
   "c066712083a07bc574481ae3a3cdcc996c9303a8")
  (:PATH "src/execution/worker-claim.lisp" :GIT-BLOB
   "3c970d0cbd3866d837c07bd03d7e4e0fae24f21f")
  (:PATH "src/execution/worker-run.lisp" :GIT-BLOB
   "c048d0e7321d26e5ec3ec4eb7d3bd79b4714aef5")
  (:PATH "src/execution/worker-types.lisp" :GIT-BLOB
   "7170e6de30721bcb89cb94b56e9d3c579a1269be")
  (:PATH "src/execution/writer.lisp" :GIT-BLOB
   "8be80a716738875d5e6fe056c5f3c81d2ffad2e5")
  (:PATH "src/foundation/batch.lisp" :GIT-BLOB
   "5560532f4cae67478c11adc65e632cfe3da10ad7")
  (:PATH "src/foundation/binary.lisp" :GIT-BLOB
   "1548e1cf2f30a547b7e8a4331ced97e293718bbb")
  (:PATH "src/foundation/conditions.lisp" :GIT-BLOB
   "a652b2e7ea5a431ce46827a9ba37d7d4931f6cba")
  (:PATH "src/foundation/crc32c-native.lisp" :GIT-BLOB
   "2e80dc72cce0064a460b8ee78970acae71a9da35")
  (:PATH "src/foundation/crc32c-vops.lisp" :GIT-BLOB
   "0677d1d29c7fc16dbd8bda529cffa5f1076327a8")
  (:PATH "src/foundation/crc32c.lisp" :GIT-BLOB
   "3dee5a43950d683f83deffaa6f329d6dcbc6cfc2")
  (:PATH "src/foundation/package.lisp" :GIT-BLOB
   "964bc89007b51d5176bf73358e90d25ce7499497")
  (:PATH "src/foundation/record.lisp" :GIT-BLOB
   "6fca7bd583990cf07093243c95f399d294b74d45")
  (:PATH "src/fulltext-admission/build.lisp" :GIT-BLOB
   "ba813f4178d646f412363e8b3f86f7309878a4a1")
  (:PATH "src/fulltext-admission/copy.lisp" :GIT-BLOB
   "43488c42525991544b355bfc061c2c753e866c88")
  (:PATH "src/fulltext-admission/guards.lisp" :GIT-BLOB
   "c4734194dc53a5f98397bd0b35079c5739f95a41")
  (:PATH "src/fulltext-admission/lifecycle.lisp" :GIT-BLOB
   "088b775f74cf633ecb3b84a0c0b9445209cc4b93")
  (:PATH "src/fulltext-admission/package.lisp" :GIT-BLOB
   "74d06aa6d0d0b263b806f678b23cec40b5db3ef1")
  (:PATH "src/fulltext-admission/preflight.lisp" :GIT-BLOB
   "eeff3e04503f0dac81da9816112f2da68e384dc2")
  (:PATH "src/fulltext-admission/query.lisp" :GIT-BLOB
   "a8aac3c938ada73cb2b18abfaf44d7bc1ff4cfa5")
  (:PATH "src/fulltext-admission/reserve.lisp" :GIT-BLOB
   "374c03ecf29417aad8e760dd432ff3e5a6383e4c")
  (:PATH "src/fulltext-admission/row-update.lisp" :GIT-BLOB
   "1d77f5d5c6e1ddb8ab08136d7d7afaf1f79a7f79")
  (:PATH "src/fulltext-admission/rows.lisp" :GIT-BLOB
   "f1c6dc8236477b5de6b2f0e5db4bab8a02fcbe95")
  (:PATH "src/fulltext-admission/types.lisp" :GIT-BLOB
   "b4766a5b561c1a1f3e53bfc9485f72b128dfb1d1")
  (:PATH "src/fulltext-put/append.lisp" :GIT-BLOB
   "df244937278aebfabba27f14555b36476e6d9858")
  (:PATH "src/fulltext-put/binding.lisp" :GIT-BLOB
   "c47d939287b3be63ec090d24bd64903556b2b86a")
  (:PATH "src/fulltext-put/build.lisp" :GIT-BLOB
   "1f4113fb6ce043099672cf72c995b976c9543cea")
  (:PATH "src/fulltext-put/package.lisp" :GIT-BLOB
   "0ffd3fb459d14ef6da0ab6789930b8ee54b78fe5")
  (:PATH "src/fulltext-put/physical-header.lisp" :GIT-BLOB
   "8fbb48b2ceb0ccb9c73b9344e14fbb025174b7e4")
  (:PATH "src/fulltext-put/physical.lisp" :GIT-BLOB
   "f7a1a29690b384cdd8bf791e62ac2d98deb7495b")
  (:PATH "src/fulltext-put/prepare.lisp" :GIT-BLOB
   "5a6929f64ba29f63efa2717a79fb79c93206b74c")
  (:PATH "src/fulltext-put/reserve.lisp" :GIT-BLOB
   "81642e379bb158bed9bec2f0fa9c70190a637567")
  (:PATH "src/fulltext-put/row-reference.lisp" :GIT-BLOB
   "b24f1dc1bd7ea08b7efe05e954cd30190f8a1aa1")
  (:PATH "src/fulltext-put/start.lisp" :GIT-BLOB
   "8c6677841d374a7bfc1834a83ccf610eecce0890")
  (:PATH "src/fulltext-put/types.lisp" :GIT-BLOB
   "c0bb31863f4f17894f85f69df42d5476d988f9da")
  (:PATH "src/fulltext/analysis-emit.lisp" :GIT-BLOB
   "17bcef98c46d7a035d2945be0c7407ed178e3da7")
  (:PATH "src/fulltext/analysis-nfc.lisp" :GIT-BLOB
   "e3e34d111a4cbab7a860d995e0658e154f1a4031")
  (:PATH "src/fulltext/analysis-package.lisp" :GIT-BLOB
   "5729cfba660c391cf9dee6fc3d5e6ccbddcd2552")
  (:PATH "src/fulltext/analysis-properties.lisp" :GIT-BLOB
   "320a03b22e01f755184d3d8b6aa1a61b009ce538")
  (:PATH "src/fulltext/analysis-space.lisp" :GIT-BLOB
   "7ab493596664f1488b369fc0b14b083e9eee31af")
  (:PATH "src/fulltext/analysis-word-context.lisp" :GIT-BLOB
   "023c1d7676f5f1325e7b112ba38a132a010f36e8")
  (:PATH "src/fulltext/analysis-word-rules.lisp" :GIT-BLOB
   "0278fccb36c8320d8b0b11b26e067773b8435e1a")
  (:PATH "src/fulltext/analysis.lisp" :GIT-BLOB
   "496c3196aa6efc23695486f15253f9275b58c1c6")
  (:PATH "src/fulltext/codec-input.lisp" :GIT-BLOB
   "ff8ede224c154fa075b7f1eb53cacecbcc7d73c3")
  (:PATH "src/fulltext/codec-package.lisp" :GIT-BLOB
   "fcd63be08134216e7a0d79c68ba6fc1120415689")
  (:PATH "src/fulltext/codec-plan.lisp" :GIT-BLOB
   "b614382a5beec3c0ccc3134f0e2abffc0fb44e87")
  (:PATH "src/fulltext/codec-query.lisp" :GIT-BLOB
   "1047b265bf2140ea5d14ea55987f1bdfae2f6e0c")
  (:PATH "src/fulltext/codec-read-base.lisp" :GIT-BLOB
   "5a24b81342a564255563e9309efcc9f043aa33a4")
  (:PATH "src/fulltext/codec-read-dict.lisp" :GIT-BLOB
   "5958a63148c0942343fa93fce59a59d614850bb2")
  (:PATH "src/fulltext/codec-read-lengths.lisp" :GIT-BLOB
   "91b77b0ef9cc16fb29c437130453ca97c19de60f")
  (:PATH "src/fulltext/codec-read-postings.lisp" :GIT-BLOB
   "46fc1a96ed8bd3e616392ac6c891a678b4e8f33a")
  (:PATH "src/fulltext/codec-read-term.lisp" :GIT-BLOB
   "bf77c4c7d7f7faeaa68077cc1dfbb8349ff6eeb7")
  (:PATH "src/fulltext/codec-run.lisp" :GIT-BLOB
   "fbe693aa1579466dc55fc03fe88a1bb04d7c097f")
  (:PATH "src/fulltext/codec-space.lisp" :GIT-BLOB
   "48e907be585f73c58fd7fa4e89a0b5cdfbfef309")
  (:PATH "src/fulltext/codec-view.lisp" :GIT-BLOB
   "49a4547d0153a45281e2bd2188891f2c5517523d")
  (:PATH "src/fulltext/codec-write-entries.lisp" :GIT-BLOB
   "035e0c6d0826d7be8e5308c3dbabf9f4b6b94b50")
  (:PATH "src/fulltext/codec-write.lisp" :GIT-BLOB
   "64731ed8f9fc9f1246a62c659b18fa85ae2a0f3e")
  (:PATH "src/fulltext/descriptor.lisp" :GIT-BLOB
   "d53475000e9a1f3f3ab97f29780b526b39c43e58")
  (:PATH "src/fulltext/document-analysis.lisp" :GIT-BLOB
   "5f4635b04bf39a7673c4071ac423f3c23b595c57")
  (:PATH "src/fulltext/document-bound.lisp" :GIT-BLOB
   "6eb42da6fa77f01a38b92559b1eccc32f1313d43")
  (:PATH "src/fulltext/document-config-input.lisp" :GIT-BLOB
   "f9522d52f03c808c9e31903ac6393ba113c487f0")
  (:PATH "src/fulltext/document-config.lisp" :GIT-BLOB
   "4d28290bec4b6bca2f8a79338323fa1e4b2ed617")
  (:PATH "src/fulltext/document-package.lisp" :GIT-BLOB
   "c699e405a2ce6c5a18cc27842352f8ad43647e4b")
  (:PATH "src/fulltext/document-paths.lisp" :GIT-BLOB
   "dc31d23d3316043885526af964aab860fe4a6f45")
  (:PATH "src/fulltext/document-scan.lisp" :GIT-BLOB
   "62df7660d399fe08ccb948a21fe6ceb0bbca507b")
  (:PATH "src/fulltext/document-space.lisp" :GIT-BLOB
   "ab484dddcbd81d464e8739e4aa28a1be667accc1")
  (:PATH "src/fulltext/document-start.lisp" :GIT-BLOB
   "d59279a55290ed8b35e722dd9ee47cef68502a1a")
  (:PATH "src/fulltext/document.lisp" :GIT-BLOB
   "447a0f0d27d1e197483f839e7a03d75bce92585d")
  (:PATH "src/fulltext/format-constants.lisp" :GIT-BLOB
   "cc040653f809c725a063eee35fff6e2f9570b675")
  (:PATH "src/fulltext/format-input.lisp" :GIT-BLOB
   "891ad11bf97386317a7a56d6e81c7d425745dfdb")
  (:PATH "src/fulltext/format-package.lisp" :GIT-BLOB
   "1f72e2d40467a20422c5bfaa2564bb5b84fedf29")
  (:PATH "src/fulltext/format-read.lisp" :GIT-BLOB
   "323807f0a973049dd290dd7dad4d2266301e6e57")
  (:PATH "src/fulltext/format-write.lisp" :GIT-BLOB
   "2b89b266d96de0264d92b164b4d59e4e27079f82")
  (:PATH "src/fulltext/index-build.lisp" :GIT-BLOB
   "54ae060c29f1345430a44b2b378c8cb43039dcdc")
  (:PATH "src/fulltext/index-lookup.lisp" :GIT-BLOB
   "9ef394661c96beef9e4cbf3f2e8e5812ec6828c6")
  (:PATH "src/fulltext/index-package.lisp" :GIT-BLOB
   "20bfb93adc06f0782e20fe842f4805b2249d440a")
  (:PATH "src/fulltext/index-sort.lisp" :GIT-BLOB
   "369d3de6ee0ecee94aadfe6ebbce619b84e8147b")
  (:PATH "src/fulltext/index-step.lisp" :GIT-BLOB
   "9206fd68138b97057494978f7713618063510654")
  (:PATH "src/fulltext/meta-fields.lisp" :GIT-BLOB
   "afaeeadd5831bac5804c57a9b67428a3e3c2eaa0")
  (:PATH "src/fulltext/meta-read.lisp" :GIT-BLOB
   "9a4f5a543e68b9c585126096feadaa754f10c6d7")
  (:PATH "src/fulltext/unicode-tables.lisp" :GIT-BLOB
   "a0b079ee4bfba2d1a6ca83b4bb9c555462b75b3c")
  (:PATH "src/get-directory/build.lisp" :GIT-BLOB
   "4ebfa97211671287aa2c972a8923654c2390d0f9")
  (:PATH "src/get-directory/package.lisp" :GIT-BLOB
   "8dcddeb0536c1104af92c722ffbfab2059601c74")
  (:PATH "src/get-directory/read.lisp" :GIT-BLOB
   "a957b1f91e495637b700756736a96baafd233abe")
  (:PATH "src/get-directory/sources-read.lisp" :GIT-BLOB
   "fbb8b26fcfd9de939bf4f3c61d5fd0c5c335754c")
  (:PATH "src/get-directory/sources-types.lisp" :GIT-BLOB
   "ce426ea6409d588e0ca6add8e6c95a1c594e0c89")
  (:PATH "src/get-directory/types.lisp" :GIT-BLOB
   "564cdaea8cb9aae672cbbd4328ea7e76b4430f4a")
  (:PATH "src/get-resolver/active-arena-read.lisp" :GIT-BLOB
   "b70b14e779d6c841bd52ca53a599822b77dcdc32")
  (:PATH "src/get-resolver/active-arena-write.lisp" :GIT-BLOB
   "2f893bf07fc9a7d36761a54cf2bbd03300d5a945")
  (:PATH "src/get-resolver/active-arena.lisp" :GIT-BLOB
   "8195220c0d648304d57dac090ab0da03f7812fe9")
  (:PATH "src/get-resolver/active-build.lisp" :GIT-BLOB
   "136d22104439f016932e90d45622553f070c1724")
  (:PATH "src/get-resolver/active-directory.lisp" :GIT-BLOB
   "3a3dae662d06b1e2b6bc936b227894d2f0396b6d")
  (:PATH "src/get-resolver/active-init.lisp" :GIT-BLOB
   "89d45e100f395e65aeca93e7d317073cfb5ffdc3")
  (:PATH "src/get-resolver/active-preflight.lisp" :GIT-BLOB
   "93a32b00aef08a29b4ae7d638eaf16cc68a284ff")
  (:PATH "src/get-resolver/active-read.lisp" :GIT-BLOB
   "430b3ba6b063931e60c477a22ce3c50fa1898750")
  (:PATH "src/get-resolver/active-scan.lisp" :GIT-BLOB
   "6e481f4d41ba4d20649978f806df1685b7afa8fb")
  (:PATH "src/get-resolver/active-types.lisp" :GIT-BLOB
   "9634424bab5ea2fe66d950f30e7d51b1baa3a395")
  (:PATH "src/get-resolver/build.lisp" :GIT-BLOB
   "d6854c7ec8b7125b33391a27760be11cd01c89db")
  (:PATH "src/get-resolver/package.lisp" :GIT-BLOB
   "33d7b898b5f5a7b20c8112484191c14df44b770e")
  (:PATH "src/get-resolver/read.lisp" :GIT-BLOB
   "1a5479dc776fd56b3c6871dd2984a620bf43f991")
  (:PATH "src/get-resolver/rows.lisp" :GIT-BLOB
   "b747d3a4b6517d7574225dc26cab8703747f0e05")
  (:PATH "src/get-resolver/scan.lisp" :GIT-BLOB
   "c0f1a6b32a1725b6e9ae05e00e130a3e0097be78")
  (:PATH "src/get-resolver/sort.lisp" :GIT-BLOB
   "7f2f8b496d65b70d83eee58c19b5b679b5d632ba")
  (:PATH "src/get-resolver/types.lisp" :GIT-BLOB
   "77b07c57b7e57505ff35724dc36a90cb554679ee")
  (:PATH "src/get/build.lisp" :GIT-BLOB
   "76ac8e35c01b887cec70ccd78d29d87690557eae")
  (:PATH "src/get/lifecycle.lisp" :GIT-BLOB
   "2a393aae53a7b13b567dc5a44b5d0d1da83714f3")
  (:PATH "src/get/lookup.lisp" :GIT-BLOB
   "01233e1565f301c96ce6ee3bb33a50f10cb2e937")
  (:PATH "src/get/package.lisp" :GIT-BLOB
   "a22de99a63db56417822bb5e66f82e5c89d73bc2")
  (:PATH "src/get/segment.lisp" :GIT-BLOB
   "7a3600dfe26168cc956e1ef62d07221a6d51a61f")
  (:PATH "src/get/target.lisp" :GIT-BLOB
   "fe1475f001e9b5719980f7e7507f735edc7e208a")
  (:PATH "src/get/types.lisp" :GIT-BLOB
   "4dd3840c525e54acc7d1577b45aadff217a77c4b")
  (:PATH "src/hash/arithmetic.lisp" :GIT-BLOB
   "f1a5060bb6071bec929476a9151fba0ec68e1604")
  (:PATH "src/hash/blocks.lisp" :GIT-BLOB
   "db2d060ad9f747deaa7f5016d09eb8ff0299d36e")
  (:PATH "src/hash/hash64.lisp" :GIT-BLOB
   "9827cb4af0343e4241d2fed6e3c62830455f8749")
  (:PATH "src/hash/package.lisp" :GIT-BLOB
   "0c73ce15b8de3f9173a99f7216ead4e79d04d535")
  (:PATH "src/index-disk/api.lisp" :GIT-BLOB
   "daeaeeaef31f8cd903ad02f6cd60193611714643")
  (:PATH "src/index-disk/balance.lisp" :GIT-BLOB
   "c1189c5fcb2a3389004a0b2d19357c4f93e9e026")
  (:PATH "src/index-disk/build.lisp" :GIT-BLOB
   "85d0f397ea8062235c537806caa21fe03d790589")
  (:PATH "src/index-disk/cache.lisp" :GIT-BLOB
   "e61013c7d4d60aa0711024615dcdf42476c69ecb")
  (:PATH "src/index-disk/copy.lisp" :GIT-BLOB
   "b26cdc656f9112ab344983c5a7f473e97442c8e3")
  (:PATH "src/index-disk/mutate.lisp" :GIT-BLOB
   "ac7a72b3d506de92ec80bbb9653904188b98d8f8")
  (:PATH "src/index-disk/package.lisp" :GIT-BLOB
   "23536e507f5fee4b20554184835addebab23ba3e")
  (:PATH "src/index-disk/read.lisp" :GIT-BLOB
   "20599afde6adbb9cd9decdc852f0de469a5d72e5")
  (:PATH "src/index-disk/relocate.lisp" :GIT-BLOB
   "34399623c2c31e68c16d069f57d1b7e6b9bd4ab2")
  (:PATH "src/index-disk/types.lisp" :GIT-BLOB
   "df13ba528aa6bba71981c44b8fbf14c69fa4551e")
  (:PATH "src/index-disk/visit.lisp" :GIT-BLOB
   "ec8ae71e8f2d27b7e2a49cefbeb2c86e7367bbe2")
  (:PATH "src/index-disk/write.lisp" :GIT-BLOB
   "7b6e37218626e782f22cc2903328c40f23d52fac")
  (:PATH "src/index/core.lisp" :GIT-BLOB
   "64be10d7b2dc85c6dd6c31becefbb6ee3ae74d21")
  (:PATH "src/index/hash-digests.lisp" :GIT-BLOB
   "ec86f5be5b5d465d5e32dc3c492cbc0c90daaba5")
  (:PATH "src/index/hash-seed.lisp" :GIT-BLOB
   "6dc9775423900dd855c71c06079cdc5e69411c5b")
  (:PATH "src/index/image-codec.lisp" :GIT-BLOB
   "e3b96642767e7e0d116481f41e279274646c2b12")
  (:PATH "src/index/image-constants.lisp" :GIT-BLOB
   "6c123802b75884937c2e9bcd7cfe4e214173ab9e")
  (:PATH "src/index/image-publication.lisp" :GIT-BLOB
   "7733d528d07acc24ec9f8c00c6767c2e3b09975e")
  (:PATH "src/index/image-recovery.lisp" :GIT-BLOB
   "ea1a681932b0fa2a1a7a3f44238816657505e55c")
  (:PATH "src/index/image-seal.lisp" :GIT-BLOB
   "f788cc87a9f2f963210d5bb54310f359df78adba")
  (:PATH "src/index/image-types.lisp" :GIT-BLOB
   "69315a89f5b007ebfbb838bc87dde37221fa69c8")
  (:PATH "src/index/image-verify-edges.lisp" :GIT-BLOB
   "2bdfd22b88408ff57efe6dc6e8c61fb5bb4f2fa1")
  (:PATH "src/index/image-verify-entry.lisp" :GIT-BLOB
   "6d240011e6b3f2c8795537bdead86763cd5a0dd5")
  (:PATH "src/index/image-verify-key.lisp" :GIT-BLOB
   "c7bde57d3d327f32321c29d358cb84eb90f1eadc")
  (:PATH "src/index/image-verify-types.lisp" :GIT-BLOB
   "a7f39bfa563402bb113c3430c5229926c0354ff9")
  (:PATH "src/index/mode-package.lisp" :GIT-BLOB
   "53da3230da115c0d702cc762d3f2ab69e6af253e")
  (:PATH "src/index/mode-policy.lisp" :GIT-BLOB
   "2acdfd94b5a0e5bfc04135cf9f39b4a72ef93482")
  (:PATH "src/index/mode-types.lisp" :GIT-BLOB
   "9e42e46cfa22a400da7635e45ab7c8192e25204c")
  (:PATH "src/index/package.lisp" :GIT-BLOB
   "02d4fd9bf5f1701eefd5e6997b89c1d98a8cef5c")
  (:PATH "src/index/page-body.lisp" :GIT-BLOB
   "c4143fd0c6350883ff10db74c2f8b9c7320b7600")
  (:PATH "src/index/page-bucket.lisp" :GIT-BLOB
   "f6f9c5b2076c8f3c1ae9dd1c23bdab00cbd69005")
  (:PATH "src/index/page-build-config.lisp" :GIT-BLOB
   "8d34342f4e34d3edacf6edb07a3059b8cd199d62")
  (:PATH "src/index/page-build-emit.lisp" :GIT-BLOB
   "479818ed5d901eee9ecfee456e39b66d4f02c620")
  (:PATH "src/index/page-build-plan.lisp" :GIT-BLOB
   "86bf82eb3913ca8dad0f7e1dbe1e9016da5b18a9")
  (:PATH "src/index/page-build-proof.lisp" :GIT-BLOB
   "f86fd7f850a9f1559e9af7fdf445971e07020eff")
  (:PATH "src/index/page-build-types.lisp" :GIT-BLOB
   "4fb20f67faa960088aadf112246f84a98f58117a")
  (:PATH "src/index/page-build.lisp" :GIT-BLOB
   "b632710d7d32cac680b10a9312bd9c4878024fd0")
  (:PATH "src/index/page-cache-types.lisp" :GIT-BLOB
   "bbea574ced62361daf59b1d03fb6f06cdb840991")
  (:PATH "src/index/page-cache.lisp" :GIT-BLOB
   "e66d3fa17f78dde39eff02eb8993a7c68f9ba9f5")
  (:PATH "src/index/page-constants.lisp" :GIT-BLOB
   "de904d211f301a087b3d1d53fa47a8054ccf2eb7")
  (:PATH "src/index/page-lookup-key.lisp" :GIT-BLOB
   "9e2e8f43e9a787b7a9223d57dcbab979dbbc233e")
  (:PATH "src/index/page-lookup-types.lisp" :GIT-BLOB
   "9abfe5a3024425124a8e9cc3b0a7087ad5cad1ff")
  (:PATH "src/index/page-lookup.lisp" :GIT-BLOB
   "9dde416acf27111c21e3f439dd2c948d27517eb7")
  (:PATH "src/index/page-package.lisp" :GIT-BLOB
   "d3f1ff0b939b5a4a1e2df7f22fb04077886220ea")
  (:PATH "src/index/page-read.lisp" :GIT-BLOB
   "0386ec4059fbb6a01d34a137e5bf5a6f44a6f589")
  (:PATH "src/index/page-types.lisp" :GIT-BLOB
   "74a9db44b348db25a046c9250f092a0e03f82ca0")
  (:PATH "src/index/page-validation.lisp" :GIT-BLOB
   "a45eb2aa3d449c9500a95950709cb6019fb8f76b")
  (:PATH "src/index/page-write.lisp" :GIT-BLOB
   "6206be6610c55d48389763a3205ff80ebd79a6d8")
  (:PATH "src/index/primary-arena.lisp" :GIT-BLOB
   "27c03d2d3e8bfb6b93088bb55bd6e615350261d0")
  (:PATH "src/index/primary-build.lisp" :GIT-BLOB
   "83fe7ca83cad1b84f41a579d56bb02ee0bac881e")
  (:PATH "src/index/primary-core.lisp" :GIT-BLOB
   "86debb0798063a5e05be0a96f125dece7edd0f0a")
  (:PATH "src/index/primary-directory.lisp" :GIT-BLOB
   "5afb91ab551d915d29f6630573a17328839cc616")
  (:PATH "src/index/primary-package.lisp" :GIT-BLOB
   "099d59bb9acc155380a3baaa3a10816e0902d8ca")
  (:PATH "src/index/primary-probe.lisp" :GIT-BLOB
   "d054587f29d5108d65704fe8b5b6794178923902")
  (:PATH "src/index/primary-read.lisp" :GIT-BLOB
   "7cc651a3e3de17decfe71f3ee9b826dfa7b3ca2f")
  (:PATH "src/index/primary-relocate.lisp" :GIT-BLOB
   "fde846254989ef432159c1ffcfc25fb3f950dbcc")
  (:PATH "src/index/primary-restore.lisp" :GIT-BLOB
   "252bd2cb57700c33fd4ec94749ea6f0b80ae6817")
  (:PATH "src/index/primary-types.lisp" :GIT-BLOB
   "179de5b6f466cfcb72c719c49a0e885b5bcf6a12")
  (:PATH "src/index/primary-write.lisp" :GIT-BLOB
   "621a82743aceafa1653340330e413bc902c58ebb")
  (:PATH "src/index/read.lisp" :GIT-BLOB
   "0187f4d9603d23a6ddb0a76d282af9c811080534")
  (:PATH "src/index/rebuild-budget.lisp" :GIT-BLOB
   "589e1557b2906a15c6c874f126968669206ceed9")
  (:PATH "src/index/rebuild-copy.lisp" :GIT-BLOB
   "bebb4f103854e0b3dbfc248cae5b82cdeafb0b57")
  (:PATH "src/index/rebuild-scan.lisp" :GIT-BLOB
   "ad43248f2f9ec4978a07df5bb696c49a1c055ea7")
  (:PATH "src/index/rebuild.lisp" :GIT-BLOB
   "6a55454412edc8466e9c7972f9c81d9a3c945697")
  (:PATH "src/index/relocate.lisp" :GIT-BLOB
   "d42c883908d8a8c9c467342b8977498f38dcf33b")
  (:PATH "src/index/types.lisp" :GIT-BLOB
   "83bec7e5e8d66f78d9b127c5310b2058b3c3fed6")
  (:PATH "src/index/validation.lisp" :GIT-BLOB
   "ab3fd8e8abe4fd803038cf11e13c3fef75a8144b")
  (:PATH "src/index/write.lisp" :GIT-BLOB
   "0e8ca5847c6683a89cdd47e3476665b1bd46e6da")
  (:PATH "src/io/cpu-build.lisp" :GIT-BLOB
   "0dd046093289729dbc7817a3eeb7dff004f0e9fa")
  (:PATH "src/io/cpu-features.lisp" :GIT-BLOB
   "80653c6c8871127b3d76cc631d47ba0e711b6e5d")
  (:PATH "src/io/cpu-package.lisp" :GIT-BLOB
   "baf8aa6f2ef5231eb6462bca65d83ac1886d09e5")
  (:PATH "src/io/create-relative.lisp" :GIT-BLOB
   "eb4a8c292b30a3083cd256eda697b05737553022")
  (:PATH "src/io/derived-remove.lisp" :GIT-BLOB
   "a0631348bc17fc4e5c1638522be73ae87fa53a97")
  (:PATH "src/io/directory-lock.lisp" :GIT-BLOB
   "f0135b3b43625d9535db6196507b55154d36f852")
  (:PATH "src/io/directory.lisp" :GIT-BLOB
   "8b3fb30b5fa092a5f88ce55cbcf5ebfa6bddf993")
  (:PATH "src/io/flush.lisp" :GIT-BLOB
   "9b04b83cf53f493aaf75d1c19a6d5f9f4ee0971f")
  (:PATH "src/io/identity-types.lisp" :GIT-BLOB
   "d53f8c4793af7e98dcab62ee5c94571dd8d520a2")
  (:PATH "src/io/identity.lisp" :GIT-BLOB
   "0cb49ca63800c1fc25bee5bf94c2811969511a07")
  (:PATH "src/io/lifecycle.lisp" :GIT-BLOB
   "9ea7d77f1bccbb7051123ac2e5793d38b770ffbf")
  (:PATH "src/io/namespace.lisp" :GIT-BLOB
   "1f73f6bf5c4b8f12064b515008d6c8f9076518ce")
  (:PATH "src/io/native-create-relative.lisp" :GIT-BLOB
   "9d715484a72332fb056b8102d2277140128b2f59")
  (:PATH "src/io/native-directory.lisp" :GIT-BLOB
   "95ea1018b8693a89e0967f9a7a6dea95542d6005")
  (:PATH "src/io/native-namespace.lisp" :GIT-BLOB
   "599c21713f3d82b6bc9faac71e42a45da0e6cd90")
  (:PATH "src/io/native-open-relative.lisp" :GIT-BLOB
   "d924a8a202ab02406cdae147cfa0cb742a0917e6")
  (:PATH "src/io/native-publish.lisp" :GIT-BLOB
   "d62f716c3965b838e0cdb7a629c78bdf845bbdc2")
  (:PATH "src/io/native.lisp" :GIT-BLOB
   "37f1e1782e0e3580447aa0ef56cb0942cfbd0e66")
  (:PATH "src/io/open-relative.lisp" :GIT-BLOB
   "e712b098ddbd883b77382c60b1b511427e8c4db7")
  (:PATH "src/io/package.lisp" :GIT-BLOB
   "c0be7a664e6642b7dcc6362d6194090fa9a8290e")
  (:PATH "src/io/publish.lisp" :GIT-BLOB
   "cb759a6c4c6d4b9300c1bb9e1e7b7d781f629f65")
  (:PATH "src/io/readiness.lisp" :GIT-BLOB
   "8ae8de38729e3866227360cc1cf6022c9220490b")
  (:PATH "src/io/rename.lisp" :GIT-BLOB
   "38a7d50880a012266e59eb915edafe64f2047e4e")
  (:PATH "src/io/segment-remove.lisp" :GIT-BLOB
   "8530ef67554d751b20d1004a9af49f20b8fc1861")
  (:PATH "src/io/stabilize-preflight.lisp" :GIT-BLOB
   "290915923be47b7739c3f44560a62f9819c7a26e")
  (:PATH "src/io/stabilize.lisp" :GIT-BLOB
   "504c9dca2fece31bc79f8788f7524d7397a1fee2")
  (:PATH "src/io/transfer.lisp" :GIT-BLOB
   "b66a02dbc2eda6d43388a0946ae46b795efb2a76")
  (:PATH "src/io/types.lisp" :GIT-BLOB
   "8e7b3506c6f1da4493bba4817d8b1f6c57585aaf")
  (:PATH "src/local/cli.lisp" :GIT-BLOB
   "801ea182eab95273f82e3b5687605dfbf31aef75")
  (:PATH "src/local/client-conditional-group.lisp" :GIT-BLOB
   "8d12830d12a112368469e0718c0ddfe168b79e7c")
  (:PATH "src/local/client-group.lisp" :GIT-BLOB
   "a55657c6d0e22e5dedf411fe33aa6c2f1c153503")
  (:PATH "src/local/client-read-group.lisp" :GIT-BLOB
   "3ca89d062de82fec20c9410c7149e53a4741755b")
  (:PATH "src/local/client-version.lisp" :GIT-BLOB
   "9880ac8380a3db16e8eb22f70ae63d3d8d7943f2")
  (:PATH "src/local/client.lisp" :GIT-BLOB
   "f44ab49bbccb626b59571aae29deb2920ebc9867")
  (:PATH "src/local/conditional-group-build.lisp" :GIT-BLOB
   "e2ddc3a893bbf3eea01088a464efd73abfa5a6cd")
  (:PATH "src/local/conditional-group-dispatch.lisp" :GIT-BLOB
   "f820570f134d630a00902d502929eb6a385e00e2")
  (:PATH "src/local/conditional-group-read.lisp" :GIT-BLOB
   "a553ce75413332d7663b6068b3adc940976c50c7")
  (:PATH "src/local/dispatch.lisp" :GIT-BLOB
   "39d79ba99a3215d88d5508a1e31e293623bae800")
  (:PATH "src/local/group-build.lisp" :GIT-BLOB
   "428ad39cb77c5e6e5e9328a1ac9e86e27646174a")
  (:PATH "src/local/group-dispatch.lisp" :GIT-BLOB
   "302d9e8be91d13b7602e9102eb4a1022e437e0da")
  (:PATH "src/local/group-read.lisp" :GIT-BLOB
   "ba4b57f80dec489589233d4d62d6d87084600026")
  (:PATH "src/local/group-types.lisp" :GIT-BLOB
   "c16e042f44592838506d24b88bd0aa62278532c9")
  (:PATH "src/local/native.lisp" :GIT-BLOB
   "380f655e5da39eaff4daeef4c6eaf63217762a48")
  (:PATH "src/local/package.lisp" :GIT-BLOB
   "0f17791b74c83f3745e536dc696cc9a2e5895ce2")
  (:PATH "src/local/read-group-dispatch.lisp" :GIT-BLOB
   "36e54c6bc2f11c73dfc9dec62a32f3975ad5edee")
  (:PATH "src/local/read-group-wire.lisp" :GIT-BLOB
   "e959bfb13b654e27f5420bf6abcb9f48197960c3")
  (:PATH "src/local/readiness.lisp" :GIT-BLOB
   "bbc9fce59ab612aa4dd003d90a854506c7b047f1")
  (:PATH "src/local/server.lisp" :GIT-BLOB
   "4e66c50f51bf570605f4b835b9ad766942c3397b")
  (:PATH "src/local/state.lisp" :GIT-BLOB
   "a164a655cecd9a8375008529391f0cc6038abd29")
  (:PATH "src/local/version-dispatch.lisp" :GIT-BLOB
   "861ebbf4facb1fcdde20fea1d5a28ed4ed03faf4")
  (:PATH "src/local/version-wire.lisp" :GIT-BLOB
   "bf2032d91087f0eeb1f947128a005b446b8f6c4c")
  (:PATH "src/local/wire.lisp" :GIT-BLOB
   "95e4ccc5010a4b8261ec0125c281816f85c9faa5")
  (:PATH "src/local/write-group.lisp" :GIT-BLOB
   "3af25a194f451448fd87b37c4b635267386e60f4")
  (:PATH "src/local/write-queue.lisp" :GIT-BLOB
   "739d7a6ba109c153afe9534a98dbe04f21efb844")
  (:PATH "src/mvcc/package.lisp" :GIT-BLOB
   "d45fbf57051e43d0d998f3de9b4177665d24c9d9")
  (:PATH "src/mvcc/snapshots-core.lisp" :GIT-BLOB
   "fdeac572e64c3591208a87872b8aa9d520c3bde7")
  (:PATH "src/mvcc/snapshots-csn.lisp" :GIT-BLOB
   "74ebd63accc8216dfe5a1794c0e430bb9bccd29e")
  (:PATH "src/mvcc/snapshots-lifecycle.lisp" :GIT-BLOB
   "a05a5732511ffca3591110f617e3a19be819b47b")
  (:PATH "src/mvcc/snapshots-read.lisp" :GIT-BLOB
   "158b5a6d1eb171d07bd4f67addc2f4be5495d54b")
  (:PATH "src/mvcc/snapshots-register.lisp" :GIT-BLOB
   "06a0af0e813b9c22ce98d523d42c031c79ca3734")
  (:PATH "src/mvcc/snapshots-types.lisp" :GIT-BLOB
   "95f5a8c59ff1fef05bcd3fd220d6a14d9c332d61")
  (:PATH "src/mvcc/types.lisp" :GIT-BLOB
   "4cf0edbc70bc9e02ff3b0442cbce4ca44630d3e6")
  (:PATH "src/package.lisp" :GIT-BLOB
   "576f0467295d8cac40fe8238d4d9df123ee81b23")
  (:PATH "src/read/core.lisp" :GIT-BLOB
   "e5130ba55ee942238a5a98ecc51e07725e1c9655")
  (:PATH "src/read/package.lisp" :GIT-BLOB
   "dd00cd8e7dc8340e2006cfe03b0bf141968223fd")
  (:PATH "src/read/task.lisp" :GIT-BLOB
   "2de7b390c89ab19f8be03767ecb07af8fe1e4fb1")
  (:PATH "src/read/types.lisp" :GIT-BLOB
   "172a43f86726ec68af730700c99098d66500ad66")
  (:PATH "src/recovery-active/build.lisp" :GIT-BLOB
   "0fa0e554f7e3aa6990d861dec7cbf8408db28068")
  (:PATH "src/recovery-active/closure.lisp" :GIT-BLOB
   "326b2070076e6e9a8d8ee66567d05b5c19329467")
  (:PATH "src/recovery-active/csn.lisp" :GIT-BLOB
   "42b1279ccd9910816bd8d0887b60bcfe9b6e252a")
  (:PATH "src/recovery-active/frames.lisp" :GIT-BLOB
   "3d01c07ff8118b92e5de7b31ca72b19db5ec72ff")
  (:PATH "src/recovery-active/package.lisp" :GIT-BLOB
   "474cd54f2a31f4ded95fd723b4170bee8addece4")
  (:PATH "src/recovery-active/publication.lisp" :GIT-BLOB
   "38542ec938fd3409d73d7531e90fc6474ef42fad")
  (:PATH "src/recovery-active/query.lisp" :GIT-BLOB
   "e2a5aea0f5a97670cc20a583ed312c89df1c7187")
  (:PATH "src/recovery-active/read.lisp" :GIT-BLOB
   "f801950d67755cd15804ef43f1461d435eda54a6")
  (:PATH "src/recovery-active/resolve.lisp" :GIT-BLOB
   "66f4ada585e085a8403d4cdbc9a3dfee31754bce")
  (:PATH "src/recovery-active/types.lisp" :GIT-BLOB
   "069ca4b815c98d82695dd7eb9337a83c5f35b98b")
  (:PATH "src/recovery-archive-csn/build.lisp" :GIT-BLOB
   "ea5a6abf3d6b0817cfa99db490e9e5df57cb200a")
  (:PATH "src/recovery-archive-csn/package.lisp" :GIT-BLOB
   "bacf4fc95e38a8d0416110c6b87b506d561a7e59")
  (:PATH "src/recovery-archive-csn/preflight.lisp" :GIT-BLOB
   "a7a20c65ba54da28dd88c941736fb374065d580f")
  (:PATH "src/recovery-archive-csn/query.lisp" :GIT-BLOB
   "28f8acd47abad20efb95ec0ea8bd765bfa10baff")
  (:PATH "src/recovery-archive-csn/series.lisp" :GIT-BLOB
   "f8eb49763d533cd34cdf05593d2416a63c5f1d0c")
  (:PATH "src/recovery-archive-csn/types.lisp" :GIT-BLOB
   "d30bb8cb36fd1c64a720073fd3f4b4921e507cad")
  (:PATH "src/recovery-archive/active.lisp" :GIT-BLOB
   "5eb16b6f93d24ac3c6f06af8ed3c005328b457a5")
  (:PATH "src/recovery-archive/build.lisp" :GIT-BLOB
   "81a581f63c21154b8a55f2f429ec28ee32a659b3")
  (:PATH "src/recovery-archive/package.lisp" :GIT-BLOB
   "82c707853b1a5b2b6d657e120c7e0ecb82404134")
  (:PATH "src/recovery-archive/query.lisp" :GIT-BLOB
   "8ae65f7a41d2b4a395d6e6a1829d334dfbe88878")
  (:PATH "src/recovery-archive/read.lisp" :GIT-BLOB
   "07ee8571028ca0ec5f754ec9f8478077650ee48d")
  (:PATH "src/recovery-archive/types.lisp" :GIT-BLOB
   "80d29b79c185d0007d0b0e4baa913ed18ec0524c")
  (:PATH "src/recovery-bootstrap/build.lisp" :GIT-BLOB
   "60d549030aa9d16b823fcb98398f14cd3786f73b")
  (:PATH "src/recovery-bootstrap/package.lisp" :GIT-BLOB
   "29ce39efa53a72cd766810b81a08c9a2f86afc91")
  (:PATH "src/recovery-bootstrap/preflight.lisp" :GIT-BLOB
   "601685cad9fd3829ea36672e86b94952f3fe4493")
  (:PATH "src/recovery-bootstrap/shape.lisp" :GIT-BLOB
   "56e6694b910c05854961e920deeb0da390d4a428")
  (:PATH "src/recovery-bootstrap/stabilize-preflight.lisp" :GIT-BLOB
   "5c05f4f7b52c72cce8f3a086a64c4d190e7de36e")
  (:PATH "src/recovery-bootstrap/stabilize-shape.lisp" :GIT-BLOB
   "649080985356be430b25c841c7d345e9d24cb543")
  (:PATH "src/recovery-bootstrap/stabilize.lisp" :GIT-BLOB
   "2ef2dda4858003135215d7d36f816f4929d214a3")
  (:PATH "src/recovery-checkpoint/build.lisp" :GIT-BLOB
   "c274d47f45d845a6e16049e2a573e8d9d76fbc3a")
  (:PATH "src/recovery-checkpoint/order.lisp" :GIT-BLOB
   "a265f08779f2abc94be058454cf75643c33272ca")
  (:PATH "src/recovery-checkpoint/package.lisp" :GIT-BLOB
   "7b191ecff3dbac6b5f690ad221c68b4762a9f0aa")
  (:PATH "src/recovery-checkpoint/preflight.lisp" :GIT-BLOB
   "61e245a5495de984a94fef573f88d11245e86b71")
  (:PATH "src/recovery-checkpoint/sections.lisp" :GIT-BLOB
   "eb05b6c58fe3131fbd597dff5655e4a476b55092")
  (:PATH "src/recovery-closed/build.lisp" :GIT-BLOB
   "bab6c80812e70ffb31a59f29ffaaa6f90678cea1")
  (:PATH "src/recovery-closed/csn-serie.lisp" :GIT-BLOB
   "078d9bbd66289b667c4273053f706a3a2af120e6")
  (:PATH "src/recovery-closed/csn.lisp" :GIT-BLOB
   "41144f854694ff9338e0067d2f59b3312119c5b2")
  (:PATH "src/recovery-closed/package.lisp" :GIT-BLOB
   "49ac245e2430e719b1d417b91b0ffcd53555e47d")
  (:PATH "src/recovery-closed/publication.lisp" :GIT-BLOB
   "fc512bece4fead39a0c75c943cc5d10bbfb810b4")
  (:PATH "src/recovery-closed/read.lisp" :GIT-BLOB
   "08bcf5a490ceba1ae7a94258f1c0bd9ca148cdaa")
  (:PATH "src/recovery-closed/resolve.lisp" :GIT-BLOB
   "2f107b18e7060dc54e902dbe0363d836285ace5f")
  (:PATH "src/recovery-closed/types.lisp" :GIT-BLOB
   "a403121cd1459db7eb753981a402152615541caa")
  (:PATH "src/recovery-closed/verify.lisp" :GIT-BLOB
   "bac75f2ed61947826ca194cf57f8d2feb003f7fc")
  (:PATH "src/recovery-replay/package.lisp" :GIT-BLOB
   "8639d959e29e9f36270a94831eace49f6535a863")
  (:PATH "src/recovery-replay/read.lisp" :GIT-BLOB
   "05eade0aed1e83cf2df5f5e2bab563d31c95081a")
  (:PATH "src/recovery-replay/resolve.lisp" :GIT-BLOB
   "85eb7133fe1463016604e6a6c9ca26dea7bb5633")
  (:PATH "src/recovery-replay/visit.lisp" :GIT-BLOB
   "0c94187caae5986c8481cf1a8e8bc060db2a7b53")
  (:PATH "src/recovery-selection/frame.lisp" :GIT-BLOB
   "101813cb3536365ac914f10e926f424dec18647e")
  (:PATH "src/recovery-selection/index-preflight.lisp" :GIT-BLOB
   "c3d336e63fbb2b5d972a314a86edd123f050aa7b")
  (:PATH "src/recovery-selection/index.lisp" :GIT-BLOB
   "b4b3488404b09fd1df4f351910043b333c1f355e")
  (:PATH "src/recovery-selection/key.lisp" :GIT-BLOB
   "f751a1ed921903353ab48e52e9fa24d374202ed1")
  (:PATH "src/recovery-selection/package.lisp" :GIT-BLOB
   "9dd583b4bf868183f7555b1e4f7c29f2a13c244c")
  (:PATH "src/recovery-selection/read.lisp" :GIT-BLOB
   "04903a7aa14fe3c332bad4255ff62f87d2e69b77")
  (:PATH "src/recovery-selection/select.lisp" :GIT-BLOB
   "dc4345cbad0fd4223eb50ed2d0ed6bcccb8ec709")
  (:PATH "src/recovery-selection/types.lisp" :GIT-BLOB
   "85930de29d2bc071ea7bbb8677d9aa0ac4e1310e")
  (:PATH "src/recovery-series/build.lisp" :GIT-BLOB
   "41324774ac594767e6931c141858270d2a2125ad")
  (:PATH "src/recovery-series/entry.lisp" :GIT-BLOB
   "a37b7c87eff82670540beb78aa78cb40fab88455")
  (:PATH "src/recovery-series/package.lisp" :GIT-BLOB
   "51f3d64796df1a2180cb977adb8a094e7c7fd94b")
  (:PATH "src/recovery-series/preflight.lisp" :GIT-BLOB
   "0daff10989f88386221d11ff4123384a67092075")
  (:PATH "src/recovery-series/read.lisp" :GIT-BLOB
   "d7ec011280d40883408a816425210f60f4ae4561")
  (:PATH "src/recovery-series/stabilize-preflight.lisp" :GIT-BLOB
   "4e6d9e8047e76ce2fa5324ebca9456d29bd69c2f")
  (:PATH "src/recovery-series/stabilize-set-preflight.lisp" :GIT-BLOB
   "81cc2dcf0e684ccc710e51b221b84c10f057db8f")
  (:PATH "src/recovery-series/stabilize-set.lisp" :GIT-BLOB
   "7fe9646c0721b02d48f8ee99cf3f2e5fa020d4c5")
  (:PATH "src/recovery-series/stabilize.lisp" :GIT-BLOB
   "1fe16c3863409635d882ebce5a9f5abc03ad5ecc")
  (:PATH "src/recovery-series/types.lisp" :GIT-BLOB
   "eb8d4a347b96aca4e5277435fe1361ed794f39b6")
  (:PATH "src/recovery/decisions-build.lisp" :GIT-BLOB
   "d7ac44761869f57e333497212510416fd1e794c9")
  (:PATH "src/recovery/decisions-package.lisp" :GIT-BLOB
   "58a3e620a8def39d2b24cd210d9283184c247ed2")
  (:PATH "src/recovery/decisions-query.lisp" :GIT-BLOB
   "b30dd16f31dcb00316d6983c7cfc5cb2948ce0ee")
  (:PATH "src/recovery/decisions-radix.lisp" :GIT-BLOB
   "54b5092b76b1c609ee195c44bd9206c1800542c4")
  (:PATH "src/recovery/decisions-sort.lisp" :GIT-BLOB
   "c7bd0b41e7a84ef73829aeaef3a113f12e7a6031")
  (:PATH "src/recovery/decisions-types.lisp" :GIT-BLOB
   "c2fab3b7b2cec568adfe88f0037fc216f83765c9")
  (:PATH "src/recovery/inventory-build.lisp" :GIT-BLOB
   "2059363677925a732eb1c70fc1ed1be94d715ea9")
  (:PATH "src/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "7b7f3c4c1bbcd252583249b650f82ab968409e24")
  (:PATH "src/recovery/inventory-directory.lisp" :GIT-BLOB
   "4f253cf7dbe6dad5814749ff53d40759ab882d73")
  (:PATH "src/recovery/inventory-id.lisp" :GIT-BLOB
   "c6dabcd733010fe6966aa1d27656b0760744e55d")
  (:PATH "src/recovery/inventory-query.lisp" :GIT-BLOB
   "47bc32082a709eb46a5fdb5a5b3011d2c4377f80")
  (:PATH "src/recovery/inventory-sources-build.lisp" :GIT-BLOB
   "149e9ca5fc1bf3ed1f473beb075d5c35b6099886")
  (:PATH "src/recovery/inventory-sources-query.lisp" :GIT-BLOB
   "9742c023b3347d38f678c7a1752a9cc37b665996")
  (:PATH "src/recovery/inventory-sources-types.lisp" :GIT-BLOB
   "b52908d02b1cda451190be58333ef9c9508fddf9")
  (:PATH "src/recovery/inventory-sources.lisp" :GIT-BLOB
   "3619190b49dcbaa32ef4dd2111995df5beace5c5")
  (:PATH "src/recovery/inventory-types.lisp" :GIT-BLOB
   "1cbb826a8999579a98e51b9c0ecd1cd6a6ff9661")
  (:PATH "src/recovery/manifest-build.lisp" :GIT-BLOB
   "1a98289ea132f2b68309efb3a7552f99a514796e")
  (:PATH "src/recovery/manifest-decode.lisp" :GIT-BLOB
   "801976598bd390814c4ddfaf00377ee38369405c")
  (:PATH "src/recovery/manifest-fold.lisp" :GIT-BLOB
   "2ddd4fb6d4c1717a25c369c6a7252f9f80769221")
  (:PATH "src/recovery/manifest-package.lisp" :GIT-BLOB
   "9754b563a1d0fbfcda0f306e94b1b6d0257dfb0e")
  (:PATH "src/recovery/manifest-query.lisp" :GIT-BLOB
   "43af5d7e8cf2c8465492531133ea9647f614e613")
  (:PATH "src/recovery/manifest-transition.lisp" :GIT-BLOB
   "c871c345eb51367427adbb9bda778a6857a97510")
  (:PATH "src/recovery/manifest-types.lisp" :GIT-BLOB
   "40c49f4692e11b4c7f9f55b93bae69210adbdcbb")
  (:PATH "src/recovery/package.lisp" :GIT-BLOB
   "b97b5c9bca6955e5dc45d9d4257089ab7132f3fb")
  (:PATH "src/recovery/scan.lisp" :GIT-BLOB
   "eb0e60664ad7abeefde7a4fc81fa7b3fa38ac57f")
  (:PATH "src/runtime/active.lisp" :GIT-BLOB
   "d7889b0103e18eb47878a88c760cae38de48b3fa")
  (:PATH "src/runtime/build.lisp" :GIT-BLOB
   "4fbf71ebd764f7d90977d027372437e113fdeed3")
  (:PATH "src/runtime/closed-preflight.lisp" :GIT-BLOB
   "5e10ae83ae0e4cd3adbbdae389629a0a854182a2")
  (:PATH "src/runtime/closed-transfer.lisp" :GIT-BLOB
   "3db2e73c10bf24d3931cbf993f240aac45e88e0f")
  (:PATH "src/runtime/closed.lisp" :GIT-BLOB
   "b06f0ae33a9c084c5101cfa5170e358bd4f7fe55")
  (:PATH "src/runtime/package.lisp" :GIT-BLOB
   "5eb61dac53e09bdaf493680967ab65938b6b8f63")
  (:PATH "src/runtime/preflight.lisp" :GIT-BLOB
   "7babef89ceacca9a7c8fac7068b54f653a4a3c58")
  (:PATH "src/runtime/query.lisp" :GIT-BLOB
   "34a7a4ebe5d0baeb93acca991f02a38b0cad2204")
  (:PATH "src/runtime/types.lisp" :GIT-BLOB
   "19fe3cc6004382550ea7939c5bf100d1fcc92607")
  (:PATH "src/scheduler/build.lisp" :GIT-BLOB
   "a55b8e7089ba3880ffa69cee4adb13dc0543069c")
  (:PATH "src/scheduler/lifecycle-build.lisp" :GIT-BLOB
   "7dfa330d606ef9c4dbceeb83845a32e75eb62fe6")
  (:PATH "src/scheduler/lifecycle-read.lisp" :GIT-BLOB
   "3b7ece551dae47957d9350c49285617d60b6ee3f")
  (:PATH "src/scheduler/lifecycle-types.lisp" :GIT-BLOB
   "5a03c1176d6bc019bcd230b0fd665cc48d555395")
  (:PATH "src/scheduler/lifecycle-update.lisp" :GIT-BLOB
   "47d323541ba45f5fb507ebcdb2eae9dd701533a2")
  (:PATH "src/scheduler/lifecycle-worker.lisp" :GIT-BLOB
   "8ae274af549a3464fd5f03d64e3c10ac73145630")
  (:PATH "src/scheduler/package.lisp" :GIT-BLOB
   "cadff5f2e29e7c5b625b95f9387faf29aad02178")
  (:PATH "src/scheduler/policy.lisp" :GIT-BLOB
   "37ed8717cf05ca8f03c06204641f47af18858a7b")
  (:PATH "src/scheduler/pool-claim.lisp" :GIT-BLOB
   "9ba00e2b77cbca2189e947e00b435fb81145668e")
  (:PATH "src/scheduler/read.lisp" :GIT-BLOB
   "ea882e41d231cc0dbafc9eac66bdd1f935433f00")
  (:PATH "src/scheduler/types.lisp" :GIT-BLOB
   "6fcd3d494dc339f8061a64fcce4133b9c86708b3")
  (:PATH "src/scheduler/update.lisp" :GIT-BLOB
   "eb0ad7a3abf119d733ae571d98695980ca4fe694")
  (:PATH "src/series/events.lisp" :GIT-BLOB
   "b1aeaa0032d7418cd3c9a7dcbc35add751fb17ce")
  (:PATH "src/series/io-events.lisp" :GIT-BLOB
   "5b189fb0ff0e54abaf72adcb05e5da58ebecb741")
  (:PATH "src/series/ownership.lisp" :GIT-BLOB
   "f81c0946f3e173fa6bf87c24e7c51999afc46363")
  (:PATH "src/series/package.lisp" :GIT-BLOB
   "6fd26253982dba01e9eef2702c5f4ede6ba70659")
  (:PATH "src/series/publication.lisp" :GIT-BLOB
   "95cf61b5df1cdd57975f64a05f890528568046b1")
  (:PATH "src/series/query.lisp" :GIT-BLOB
   "79cc08666f83630adba9cab148bb71c2f6d46253")
  (:PATH "src/series/retirement.lisp" :GIT-BLOB
   "f21cae5c4f5cfd94d5d4b6a437ac2ede15750b5d")
  (:PATH "src/series/routing-build.lisp" :GIT-BLOB
   "4d09a75d977a0eed0819e7c7d61737d245514b00")
  (:PATH "src/series/routing-select.lisp" :GIT-BLOB
   "dee5f67f723edb5ba47b78e68baeee49eb56015c")
  (:PATH "src/series/routing-types.lisp" :GIT-BLOB
   "18a29843546af6fc28fa36742a175fc3e6f19e1c")
  (:PATH "src/series/types.lisp" :GIT-BLOB
   "3b6335d3c665f5fe66771242c4d43db3de10b333")
  (:PATH "src/series/worker-boundary.lisp" :GIT-BLOB
   "16700994fa5959633b21d4c7eb21483cd489f0c4")
  (:PATH "src/series/worker-package.lisp" :GIT-BLOB
   "d0316128bae48e4251a519d7daab25dbaf52f031")
  (:PATH "src/series/worker-run.lisp" :GIT-BLOB
   "2a15783bbd1f5fdd1adb0ae4a045449970f46650")
  (:PATH "src/series/worker-types.lisp" :GIT-BLOB
   "d7c667389bf8ad8ec4a04ce2b1bc9ec90e64a54d")
  (:PATH "src/storage/compaction-scan.lisp" :GIT-BLOB
   "fd552f6657ade1482eeada765c0880b6afe8a73f")
  (:PATH "src/storage/control-payload.lisp" :GIT-BLOB
   "6643873870526ee603a5c5b554a91650e5be0e6f")
  (:PATH "src/storage/formats.lisp" :GIT-BLOB
   "028c7b1111e43c0749479067451894b38479a7ec")
  (:PATH "src/storage/log-header.lisp" :GIT-BLOB
   "10af1f2b835f387f7c5c69011b712c37bce142f9")
  (:PATH "src/storage/package.lisp" :GIT-BLOB
   "c15553a65171e5dfb2dbadb62c92ed4dc48aee3a")
  (:PATH "src/storage/payload-record.lisp" :GIT-BLOB
   "0548df3e81bff3332c67897fc70d7aece4c822ea")
  (:PATH "src/storage/payload-write.lisp" :GIT-BLOB
   "0e6f1849a77fd2de1109e3576f174f13e2eca665")
  (:PATH "src/storage/segment-header.lisp" :GIT-BLOB
   "05cb8e127c9384da1c40d21c7566f5d57b705ecf")
  (:PATH "src/verify/order.lisp" :GIT-BLOB
   "d563554aeaddb02585f4e4ad03b739dea5387669")
  (:PATH "src/verify/package.lisp" :GIT-BLOB
   "c98aae86e4bbd9642c2d5481503bf944c88e7811")
  (:PATH "src/verify/read.lisp" :GIT-BLOB
   "913463f4e6529cda367092c7aefe85e8471416c7")
  (:PATH "src/verify/report.lisp" :GIT-BLOB
   "5771c02a6384a61711735571ee64e219bdbc145c")
  (:PATH "src/verify/resources.lisp" :GIT-BLOB
   "48232232f028b479a5839420a42253416f7edffe")
  (:PATH "src/verify/types.lisp" :GIT-BLOB
   "ed2a9617dce5a03c691bc2826a5996f8a3161e2a")
  (:PATH "src/wal/append.lisp" :GIT-BLOB
   "769b86afb5de6d2f706a015e049ea04b63031f79")
  (:PATH "src/wal/builder.lisp" :GIT-BLOB
   "65b17519d6d6e5d9e104bc37b2c4eb4d3b93f132")
  (:PATH "src/wal/csn.lisp" :GIT-BLOB
   "51110c6784e99fc94ddf5a2344e0d85262c297d5")
  (:PATH "src/wal/executor.lisp" :GIT-BLOB
   "ae53e978652629ff407be47d3abe04176626dbb4")
  (:PATH "src/wal/frame.lisp" :GIT-BLOB
   "2f2f1af60a399d9263f15ce4565502da1c70f173")
  (:PATH "src/wal/group.lisp" :GIT-BLOB
   "17858cffba82609484a6f4a32d082d14ceec1c4b")
  (:PATH "src/wal/package.lisp" :GIT-BLOB
   "e0ea179069a7b297c7c26f6c294c7d4aea3db671")
  (:PATH "src/wal/types.lisp" :GIT-BLOB
   "d9f682a05cf5adb22850728a839228f02744c5f2")
  (:PATH "tests/cache/README.md" :GIT-BLOB
   "3836e59b86c5a731e772fbf0a6cca376b14806af")
  (:PATH "tests/cache/guards.lisp" :GIT-BLOB
   "af881fd91c3820ab19d1daa2d56f1fe57257d08f")
  (:PATH "tests/cache/support.lisp" :GIT-BLOB
   "fd829e7352ba878e73df30d979e9558ff6ccba14")
  (:PATH "tests/cache/threads.lisp" :GIT-BLOB
   "ca03c59f0fada09cae8c452fed6490de32d4a3a6")
  (:PATH "tests/ci-catalog.lisp" :GIT-BLOB
   "f99940cde88fc16095679156dd2ca561edab453c")
  (:PATH "tests/codec/cbor-array-write-support.lisp" :GIT-BLOB
   "2a47078354c45a5775f48f6dd8f5d784da7de202")
  (:PATH "tests/codec/cbor-array-write-threads.lisp" :GIT-BLOB
   "43bac6c9604140af2594d85b76c14c3101b6925b")
  (:PATH "tests/codec/cbor-array-write.lisp" :GIT-BLOB
   "b13f58264f3cd97e1947ee52936732a7fcebe672")
  (:PATH "tests/codec/cbor-float-write-support.lisp" :GIT-BLOB
   "5416b62340ae8f3332915f8891529d95549a5fba")
  (:PATH "tests/codec/cbor-float-write-threads.lisp" :GIT-BLOB
   "3b0840150945cd4f118516b1d6d61524fa6856fa")
  (:PATH "tests/codec/cbor-float-write.lisp" :GIT-BLOB
   "747cd8a72445a3ea638cd1910bc9faa63f4cdc33")
  (:PATH "tests/codec/cbor-header.lisp" :GIT-BLOB
   "a1541916590304adccc2092c226ef3be9c644168")
  (:PATH "tests/codec/cbor-item-read-support.lisp" :GIT-BLOB
   "0326100362a1c4b24d2c7e511e45357f09a56d33")
  (:PATH "tests/codec/cbor-item-read-threads.lisp" :GIT-BLOB
   "a0da65545ed80ede0a967cadbb337731f6fe1ce9")
  (:PATH "tests/codec/cbor-item-read.lisp" :GIT-BLOB
   "b2cbdcb4255c51d9da4fe73b28939c1cb923fefe")
  (:PATH "tests/codec/cbor-map-write-support.lisp" :GIT-BLOB
   "113bfc4529199f69dea1862baec0aa7403c6fa97")
  (:PATH "tests/codec/cbor-map-write-threads.lisp" :GIT-BLOB
   "892d30fd1c7a8f12430c6caa6f43ee872574eb09")
  (:PATH "tests/codec/cbor-map-write.lisp" :GIT-BLOB
   "6ad0e9b5a48ba9c32c46d720f2f7f1821368d6c8")
  (:PATH "tests/codec/cbor-minimal-edges.lisp" :GIT-BLOB
   "c6f891dff335a37689ddbfabccf793d2e9f2f143")
  (:PATH "tests/codec/cbor-minimal-scan-support.lisp" :GIT-BLOB
   "c2af64af4e5f8b5f669819fd56a00f416b3aaf0d")
  (:PATH "tests/codec/cbor-minimal-scan-threads.lisp" :GIT-BLOB
   "532c3f1d5898083364f17f9fc9cbf0da7b798bda")
  (:PATH "tests/codec/cbor-minimal-scan.lisp" :GIT-BLOB
   "1742189ff6845197ba76996c09c1097d59216fcb")
  (:PATH "tests/codec/cbor-minimal-support.lisp" :GIT-BLOB
   "774e6cd0bec4a9d2242ad4dede878ffa2afca90c")
  (:PATH "tests/codec/cbor-minimal-threads.lisp" :GIT-BLOB
   "d88b573a98689b5e1c0cbade8f8a7ac69470554f")
  (:PATH "tests/codec/cbor-minimal.lisp" :GIT-BLOB
   "b863ace9a22e8b7508b7c9d8f91465ebfbcd4e98")
  (:PATH "tests/codec/cbor-simple-write-support.lisp" :GIT-BLOB
   "0989d7f8e43ec7213df856b842b1e9149df96d9f")
  (:PATH "tests/codec/cbor-simple-write-threads.lisp" :GIT-BLOB
   "186f1772335ce33e4e3d1d933bf4d4e91fe0763f")
  (:PATH "tests/codec/cbor-simple-write.lisp" :GIT-BLOB
   "efaa31b8ea2d74af162fd00a3b4e923ae5f60cdd")
  (:PATH "tests/codec/cbor-string-read-support.lisp" :GIT-BLOB
   "cfd55cd47d782673113e67af625c1360195a345c")
  (:PATH "tests/codec/cbor-string-read-threads.lisp" :GIT-BLOB
   "c3686d6e47ad56e53db556747ee2d49cea527df5")
  (:PATH "tests/codec/cbor-string-read.lisp" :GIT-BLOB
   "8437bdcaa4cf308dbf4614e748cdab4be2ae6d62")
  (:PATH "tests/codec/cbor-string-write-support.lisp" :GIT-BLOB
   "66b5d03695f522cca8013ccdad3ede690cc63412")
  (:PATH "tests/codec/cbor-string-write-threads.lisp" :GIT-BLOB
   "16cc32f2c51d28f75a64b93ead642340f88e9c05")
  (:PATH "tests/codec/cbor-string-write.lisp" :GIT-BLOB
   "ed0f6a67c46498bdc9c721480cb76bc727fc5b4f")
  (:PATH "tests/codec/cbor-structure-support.lisp" :GIT-BLOB
   "e9cc8a08917903cab7b7f5617225884b7d89e6c4")
  (:PATH "tests/codec/cbor-structure-threads.lisp" :GIT-BLOB
   "595d51a96ee3767c13797910ea324061a4788617")
  (:PATH "tests/codec/cbor-structure.lisp" :GIT-BLOB
   "7e9b7a518bc3a260d721e85d62ff986553bb06de")
  (:PATH "tests/codec/cbor-support.lisp" :GIT-BLOB
   "172c4a335b2d504f785b2036532346a24ccf1378")
  (:PATH "tests/codec/cbor-tag-write-support.lisp" :GIT-BLOB
   "e6e1e91e5ed95019e20b11d2dc0e408911acb46e")
  (:PATH "tests/codec/cbor-tag-write-threads.lisp" :GIT-BLOB
   "1c731f7ed83f703e3d2a8a4c57e6c702ef127887")
  (:PATH "tests/codec/cbor-tag-write.lisp" :GIT-BLOB
   "df97950ec8d24157bb6566c7995262f7beea7742")
  (:PATH "tests/codec/cbor-threads.lisp" :GIT-BLOB
   "0f66cc1f8b493598d436b1d62d7211f4196fb430")
  (:PATH "tests/codec/cbor-write-roundtrip.lisp" :GIT-BLOB
   "e225cb69e82ad1038da71e31b6513619f5e09d40")
  (:PATH "tests/codec/cbor-write-support.lisp" :GIT-BLOB
   "92327e4b840b8586c50c32a7732e718ee6e9db98")
  (:PATH "tests/codec/cbor-write-threads.lisp" :GIT-BLOB
   "7717054be474eba254f3f645fc62ec4ef65a511c")
  (:PATH "tests/codec/cbor-write.lisp" :GIT-BLOB
   "903a213c810d99fdefc2af2afa93445574a13be7")
  (:PATH "tests/codec/support.lisp" :GIT-BLOB
   "6b8226ae1b41dc9e47e45986e18287a10a8d54e7")
  (:PATH "tests/codec/threads.lisp" :GIT-BLOB
   "0c1a6d9fbe44a95b951a7e1a9aad90f65cef961b")
  (:PATH "tests/codec/utf8.lisp" :GIT-BLOB
   "59e3ffc9cee96d97ef20d132e3e531aef2f9ddf7")
  (:PATH "tests/control/native.lisp" :GIT-BLOB
   "2107cb66de45ded987c7fb1392155ff6afebbed6")
  (:PATH "tests/control/publication.lisp" :GIT-BLOB
   "f987c9317990ce977ecadb747268b39d2612eba1")
  (:PATH "tests/control/recovery-guards.lisp" :GIT-BLOB
   "b2e877dfcc35468cfafd95f398f33d1415692c1f")
  (:PATH "tests/control/recovery-publication.lisp" :GIT-BLOB
   "cd99169af8aecf204ce9cd2e6e1f2a9fbb081f68")
  (:PATH "tests/control/recovery-read.lisp" :GIT-BLOB
   "21f33af3220a237d7a8dc2ff3a98bfd4c41fa201")
  (:PATH "tests/control/support.lisp" :GIT-BLOB
   "053d81269526d2e7c78181fbe2f8e58ac3f878f3")
  (:PATH "tests/csn/registry.lisp" :GIT-BLOB
   "b5c507d831098b28e6d1fe7880a01e1a3cb8ded2")
  (:PATH "tests/csn/support.lisp" :GIT-BLOB
   "a6c462233eed3bbdf9f08feb0195488688af287c")
  (:PATH "tests/csn/threads.lisp" :GIT-BLOB
   "b198b4936a119a6194e720cd51a6cbe5f49d72c1")
  (:PATH "tests/engine/active-arena.lisp" :GIT-BLOB
   "bc3374fac887f4d210b7f3ed661ee38cb22f402e")
  (:PATH "tests/engine/compaction.lisp" :GIT-BLOB
   "4e46ba4400a7af10db08d35e191be80204237234")
  (:PATH "tests/engine/conditional-group.lisp" :GIT-BLOB
   "bb7b7ee3e52c0b3c0ae69c2bdc48de594f0bd945")
  (:PATH "tests/engine/conditional.lisp" :GIT-BLOB
   "dc0a709ca6f298ccb870dc2e57504831c01d4285")
  (:PATH "tests/engine/delta-location.lisp" :GIT-BLOB
   "3ab2c0e5c6d45ed746de955c72192327c525c71c")
  (:PATH "tests/engine/delta.lisp" :GIT-BLOB
   "5160313851bdfa637e80b76095679b9e965f22a7")
  (:PATH "tests/engine/group-append.lisp" :GIT-BLOB
   "39881bdf066184487a19e1d82c3cf834e731257d")
  (:PATH "tests/engine/image-activation.lisp" :GIT-BLOB
   "bb8b9470cae4854efd1336bc5a289d7305faed54")
  (:PATH "tests/engine/image-auto.lisp" :GIT-BLOB
   "19215e89154e8f65ba0e83e21b04d3d069c93a69")
  (:PATH "tests/engine/image-build.lisp" :GIT-BLOB
   "8543c508064d8198957a25f93e6da3c343d6c26a")
  (:PATH "tests/engine/image-discovery.lisp" :GIT-BLOB
   "50891fbd9ded0ece20969b466f24f1f591bd1439")
  (:PATH "tests/engine/image-maintenance.lisp" :GIT-BLOB
   "3b28dcea4388823fe8999b1fd67edb7a0da5343d")
  (:PATH "tests/engine/image-renewal.lisp" :GIT-BLOB
   "01e55612ec38f31fe281c0f1707bf1aa50aa1345")
  (:PATH "tests/engine/images.lisp" :GIT-BLOB
   "7ea979d2249807380c4532acc52e2ad299dcc0ad")
  (:PATH "tests/engine/index-auto-disk.lisp" :GIT-BLOB
   "57efb3be2095d695461717b131b95f2b6c1131f7")
  (:PATH "tests/engine/index-automatic.lisp" :GIT-BLOB
   "d2f9514760932005ab95e12f037606cf0dd94fde")
  (:PATH "tests/engine/lifecycle.lisp" :GIT-BLOB
   "55f8a525a7fb68846724b869d15eee8238924fe3")
  (:PATH "tests/engine/processes.lisp" :GIT-BLOB
   "ec6545a30fd1d4405ceb31c6c05b1c0ceb999711")
  (:PATH "tests/engine/record-cache.lisp" :GIT-BLOB
   "7dc3029e1048aedb7aab3bfb2649a69731e01734")
  (:PATH "tests/engine/rotation.lisp" :GIT-BLOB
   "f0de9a0e81ab82a161ba5e19a0706aae803e63e5")
  (:PATH "tests/engine/support.lisp" :GIT-BLOB
   "4f050bd297add4aff17a15bb24b3f499785018fd")
  (:PATH "tests/engine/write-group.lisp" :GIT-BLOB
   "debeeb853848ef25d28ce1293b2af3648b4b02dc")
  (:PATH "tests/epochs/lifecycle.lisp" :GIT-BLOB
   "6980f8ef0aec2f962d2c85c38ad5b712132ce2be")
  (:PATH "tests/epochs/support.lisp" :GIT-BLOB
   "de53c4db528218c5bb4e074d7cd26a4a38f0ecc5")
  (:PATH "tests/epochs/threads.lisp" :GIT-BLOB
   "a7e34763661de9edd8bd049c817ba961cc1d3104")
  (:PATH "tests/execution/handoff.lisp" :GIT-BLOB
   "ba702352ee63241b9ac993b0aca8f162c3deef1b")
  (:PATH "tests/execution/queue.lisp" :GIT-BLOB
   "546d4215f9f63007f632c522f0f8c1e75ac4bbeb")
  (:PATH "tests/execution/ready-recycle.lisp" :GIT-BLOB
   "1dff8707436ca52f20f62e9946621ca1037f33d2")
  (:PATH "tests/execution/ready.lisp" :GIT-BLOB
   "9f81552333f86fe0b20f2d5e8ba48b20634f5a09")
  (:PATH "tests/execution/support.lisp" :GIT-BLOB
   "b8bac07926727a644f0246f6b57d600332288310")
  (:PATH "tests/execution/threads.lisp" :GIT-BLOB
   "b1e71783b65b85e6253f733098c3153d41c4971c")
  (:PATH "tests/execution/worker.lisp" :GIT-BLOB
   "2a14573906b94b254712a1e9322058ec1081f6f8")
  (:PATH "tests/foundation/batch.lisp" :GIT-BLOB
   "00bb40ad87340ee86f5da281c09207c8da8888a6")
  (:PATH "tests/foundation/binary.lisp" :GIT-BLOB
   "ca77be5b92c1cec98860dd5f59b278e9dcaf8ae4")
  (:PATH "tests/foundation/record.lisp" :GIT-BLOB
   "4294dcba9b307bddd9cc3636d7e2865f0f7030c5")
  (:PATH "tests/foundation/support.lisp" :GIT-BLOB
   "d383b1cddf929ba0340d1b74eec3ec03673eac09")
  (:PATH "tests/fulltext/admission-concurrency.lisp" :GIT-BLOB
   "fbc2b0294a9369c4812bf206f001399be2af0ff3")
  (:PATH "tests/fulltext/admission-guards.lisp" :GIT-BLOB
   "b3475774a8a7f31269ea0e1b33bb659e230f67c7")
  (:PATH "tests/fulltext/admission-lifecycle.lisp" :GIT-BLOB
   "175c3e3bd33b163bc7593066ade68eb426e8e757")
  (:PATH "tests/fulltext/admission-resources.lisp" :GIT-BLOB
   "29ac6bf4b0b392579997b79c10142b2f491a5eb7")
  (:PATH "tests/fulltext/admission-rows-support.lisp" :GIT-BLOB
   "1713cd556e5e37525af25a15b4f5b36474967d88")
  (:PATH "tests/fulltext/admission-rows.lisp" :GIT-BLOB
   "6e2d6c65c8046ad7dee030a4e95330f3ce3993dd")
  (:PATH "tests/fulltext/admission-support.lisp" :GIT-BLOB
   "1eaef196dc555b086cd53584731041bfb97cda59")
  (:PATH "tests/fulltext/admission.lisp" :GIT-BLOB
   "74ed0e49ce0c839cb5e74d854704d21cb8dbbf68")
  (:PATH "tests/fulltext/allocation-threads.lisp" :GIT-BLOB
   "870a308baeed93e1aabb6dc9a88db443592439c0")
  (:PATH "tests/fulltext/analysis-conformance.lisp" :GIT-BLOB
   "ad704e6457ad7873b3eb2feea241da5129962c8f")
  (:PATH "tests/fulltext/analysis-support.lisp" :GIT-BLOB
   "805f7e60fd3f6aa25b4c53680e5251188e57868e")
  (:PATH "tests/fulltext/analysis.lisp" :GIT-BLOB
   "4d529aef551bd365f0c12eb3dffbb7b2960fae56")
  (:PATH "tests/fulltext/codec-corruption.lisp" :GIT-BLOB
   "c62dd05be34d1f653eed8565cc0b40b950bdb97f")
  (:PATH "tests/fulltext/codec-differential.lisp" :GIT-BLOB
   "91b651930dd7f9da36fd317453686d272e0d2c40")
  (:PATH "tests/fulltext/codec-guards.lisp" :GIT-BLOB
   "9f6b8e823ae25c43b767141e0193b908ca0e763a")
  (:PATH "tests/fulltext/codec-support.lisp" :GIT-BLOB
   "890e176db757eed9e2680f5b247a12922709d4b9")
  (:PATH "tests/fulltext/codec.lisp" :GIT-BLOB
   "50b924b1c0e9127da33413f1100bf04ef2ee500d")
  (:PATH "tests/fulltext/document-differential.lisp" :GIT-BLOB
   "78466a8bc1213d0794155535eb28a990a45a38aa")
  (:PATH "tests/fulltext/document-guards.lisp" :GIT-BLOB
   "608f322bd4ac149abb9ffbb352595b5c94d3d217")
  (:PATH "tests/fulltext/document-support.lisp" :GIT-BLOB
   "57d59f345c6cbe8dba253acce7993409b5bbed94")
  (:PATH "tests/fulltext/document.lisp" :GIT-BLOB
   "ab305e31ece6bf7fd20ac5b7ea119b01c57e7c92")
  (:PATH "tests/fulltext/format-guards.lisp" :GIT-BLOB
   "9a23048572dfa5eee314221ced3425a1ea46c28a")
  (:PATH "tests/fulltext/format-support.lisp" :GIT-BLOB
   "d03bd892800d593a3550bdc709d43c357041bfab")
  (:PATH "tests/fulltext/format-threads.lisp" :GIT-BLOB
   "b8e8eb4491b59c721071396ce656eb09186f988d")
  (:PATH "tests/fulltext/format.lisp" :GIT-BLOB
   "b7cb19b82d4e50d457c603b8708693adf27785f0")
  (:PATH "tests/fulltext/index.lisp" :GIT-BLOB
   "0673c32fe456a9cb77cf4aa5cc4e071a888cccf2")
  (:PATH "tests/fulltext/minimum-v2.hex" :GIT-BLOB
   "c4db496b0e5b920665d1c80bea204f6227da1f0e")
  (:PATH "tests/fulltext/put-concurrency.lisp" :GIT-BLOB
   "613b2e5a89d505701583aa9c68e6273f4163d2e7")
  (:PATH "tests/fulltext/put-guards.lisp" :GIT-BLOB
   "6b531c1b143860a46e84d5c77da982f54fbd413b")
  (:PATH "tests/fulltext/put-lifecycle.lisp" :GIT-BLOB
   "8cba90b629299c8494194a73ef8b819f554ca557")
  (:PATH "tests/fulltext/put-physical-guards.lisp" :GIT-BLOB
   "bd293d0ef1d5596e85859cb85e41639b3a0fd70e")
  (:PATH "tests/fulltext/put-physical-native.lisp" :GIT-BLOB
   "635118c4287ab13b4b98e34d04dc307b97497827")
  (:PATH "tests/fulltext/put-physical-support.lisp" :GIT-BLOB
   "1e81cc2af12f24515debc953d4f7884b07a2e197")
  (:PATH "tests/fulltext/put-physical.lisp" :GIT-BLOB
   "f8d1fa41090aaa40c2146ec9280bff08d968fdce")
  (:PATH "tests/fulltext/put-rows.lisp" :GIT-BLOB
   "0ee39c61cdbb6742eb36d65677030d44c96ad98e")
  (:PATH "tests/fulltext/put-support.lisp" :GIT-BLOB
   "2a3c9b543587b1a9c5402a16f82cfc1c671a6160")
  (:PATH "tests/fulltext/put.lisp" :GIT-BLOB
   "83f9503ec4bd1a6610443bb8eea991e6069c6565")
  (:PATH "tests/get-active/append.lisp" :GIT-BLOB
   "0779a03e322f321a930393c5667e11252b84eff5")
  (:PATH "tests/get-active/construction.lisp" :GIT-BLOB
   "ec2831edef2e452597ce867b026eb73c84fc5214")
  (:PATH "tests/get-active/directory.lisp" :GIT-BLOB
   "48c9a60e58536170a610844e853eae6f91beeff1")
  (:PATH "tests/get-active/preflight.lisp" :GIT-BLOB
   "7f41c04257e0bab10a2ffbc091b02d660029c4df")
  (:PATH "tests/get-active/read.lisp" :GIT-BLOB
   "0ab8c2b2b639a51b0217876a896d9468f41e22de")
  (:PATH "tests/get-active/support.lisp" :GIT-BLOB
   "b0a6f9bda4866f82471ec73120182caa786f7d11")
  (:PATH "tests/get-directory/README.md" :GIT-BLOB
   "ced6f8b39836c1c2ff264822ddaf05d0653bfff6")
  (:PATH "tests/get-directory/construction.lisp" :GIT-BLOB
   "537a67a6931f1c7445e68bd30683c08108bf37e7")
  (:PATH "tests/get-directory/lifetime-support.lisp" :GIT-BLOB
   "cd514970e84f8654318dcc23a6b1ef24323be8a9")
  (:PATH "tests/get-directory/lifetime.lisp" :GIT-BLOB
   "c57261d2de469318402d5bf79f5ab5d27108bb46")
  (:PATH "tests/get-directory/read.lisp" :GIT-BLOB
   "04c509eb39d9f552f4d2762630c20861e7b1c48f")
  (:PATH "tests/get-directory/series-read.lisp" :GIT-BLOB
   "b500bb83170622b6d96edbd363ebc85240064c18")
  (:PATH "tests/get-directory/series-support.lisp" :GIT-BLOB
   "ead990e110b588bb4df35ea17d3816db3b79cee5")
  (:PATH "tests/get-directory/support.lisp" :GIT-BLOB
   "a5b09ee5120bedc4e946366239dd5e6c978b27d2")
  (:PATH "tests/get-directory/threads.lisp" :GIT-BLOB
   "832073baa5d1e8aefe89ac42dc60023c96038ba3")
  (:PATH "tests/get-performance/README.md" :GIT-BLOB
   "9e03608bef23c0aa5a69dce8c7dfd09ed818a377")
  (:PATH "tests/get-performance/guards.lisp" :GIT-BLOB
   "9bbf7b2ceb817d6ecf2e7c67b0928373c2c07f70")
  (:PATH "tests/get-performance/paths.lisp" :GIT-BLOB
   "160dae42a9723e9b0e93a085864affa96a4cd6be")
  (:PATH "tests/get-performance/support.lisp" :GIT-BLOB
   "f7eac312809b34fa72dcd3b9a8b67d290cb08cd6")
  (:PATH "tests/get-performance/threads.lisp" :GIT-BLOB
   "5780e3ef9c9e34a4098ddbd72e19cebfa6a34edd")
  (:PATH "tests/get-resolver/construction.lisp" :GIT-BLOB
   "322c63ee6576304ca1ab19e28b902b680bc2acae")
  (:PATH "tests/get-resolver/read.lisp" :GIT-BLOB
   "a1788d1aab3f76b9dc29095676ec42f3a1f936a8")
  (:PATH "tests/get-resolver/sort.lisp" :GIT-BLOB
   "442ce9eef4fac8f593a9d94ed08a76b830773563")
  (:PATH "tests/get-resolver/support.lisp" :GIT-BLOB
   "11d5cf0efe8ee4f5606707cc7eca175442a50190")
  (:PATH "tests/get/lifecycle.lisp" :GIT-BLOB
   "c65090a98c47f89d42ea8e77f00d402afbb9a9bc")
  (:PATH "tests/get/segment.lisp" :GIT-BLOB
   "125d274ba50ba29a9c0d7e1d04ce8e22f7f240f2")
  (:PATH "tests/get/support.lisp" :GIT-BLOB
   "387c1101e92dce8482c3d0e27a47fa42f21e3501")
  (:PATH "tests/hash/guards.lisp" :GIT-BLOB
   "3a4454e0f55fe12ff4c84a44aa60509623621b93")
  (:PATH "tests/hash/hash64.lisp" :GIT-BLOB
   "5044b9d9d2e5872a78bfc81d9ff3c3295b242069")
  (:PATH "tests/hash/support.lisp" :GIT-BLOB
   "be3d132c4eeb9e4ee0892a98174b9e10771a38a9")
  (:PATH "tests/hash/threads.lisp" :GIT-BLOB
   "0b804901ec2c1de69c0781c08a30f8389b2d3d34")
  (:PATH "tests/index/hash-digests.lisp" :GIT-BLOB
   "bee75932d859ac1c3d02147672f9186e53d71b5b")
  (:PATH "tests/index/image-processes.lisp" :GIT-BLOB
   "11c9ba829c73bb71f54be52710ac699b40b47f60")
  (:PATH "tests/index/image-tests.lisp" :GIT-BLOB
   "3ea1eb66179db5125b2b5137372c70c9d953e95f")
  (:PATH "tests/index/mode-policy.lisp" :GIT-BLOB
   "4513fb320a9f1ced973820d8a9c58ee9a0d73ea6")
  (:PATH "tests/index/mode-support.lisp" :GIT-BLOB
   "14d4c82bd54795844d14ac1d7f1b7ced320c4233")
  (:PATH "tests/index/page-build.lisp" :GIT-BLOB
   "bd600c74e28d32328559e9b9f268b4afa3481a55")
  (:PATH "tests/index/page-cache.lisp" :GIT-BLOB
   "aaace9b80ff3c6ce2ab52a3644be8c56eef4ebfd")
  (:PATH "tests/index/page-chains.lisp" :GIT-BLOB
   "265a85cd6aff51dd8a5ceae50f60ff7b8d63660e")
  (:PATH "tests/index/page-corruption.lisp" :GIT-BLOB
   "880775f39ed5c6352c0ae448b7a830ea63b03a85")
  (:PATH "tests/index/page-fixtures.lisp" :GIT-BLOB
   "0ed84fd77dc21375773651e4bb42e56a2c0a5e43")
  (:PATH "tests/index/page-lookup-support.lisp" :GIT-BLOB
   "8800a152c6f0eefa572fda9e17ee9e5e1ff77023")
  (:PATH "tests/index/page-lookup.lisp" :GIT-BLOB
   "290b471927fc1647a000099d8f3f8b57b878c843")
  (:PATH "tests/index/page-support.lisp" :GIT-BLOB
   "920c631d2763260aec7bcb02d3172d8be1d4b21f")
  (:PATH "tests/index/page-tests.lisp" :GIT-BLOB
   "a18f0315e5480a356504f1f541bffc1ad3484fc6")
  (:PATH "tests/index/primary-support.lisp" :GIT-BLOB
   "38c629112ce062064d66409349f76ba91b26801f")
  (:PATH "tests/index/primary-threads.lisp" :GIT-BLOB
   "289d129a4ae1690c24874714bae3812ee01bad8b")
  (:PATH "tests/index/primary.lisp" :GIT-BLOB
   "d21142f34f3687c35f39c86d962f2c8ffd52c330")
  (:PATH "tests/index/rebuild.lisp" :GIT-BLOB
   "838091c9035b5a489c12467daf3a564de1ca0746")
  (:PATH "tests/index/slot-support.lisp" :GIT-BLOB
   "384a6ac91ac56abfe7db43d587366ba6eaf369aa")
  (:PATH "tests/index/slot-threads.lisp" :GIT-BLOB
   "f7eee8b0026ee742163ab90d31a7b09263820033")
  (:PATH "tests/index/slots.lisp" :GIT-BLOB
   "5f443c496559abe79e0abace6555dc96eb6c4276")
  (:PATH "tests/io/create-relative-native.lisp" :GIT-BLOB
   "fd5e819e2197869a93259857aacfa68bfe9e9a44")
  (:PATH "tests/io/create-relative-support.lisp" :GIT-BLOB
   "8382ffb8f04b6d2fc3e4adb89f995c9c37b0e445")
  (:PATH "tests/io/create-relative.lisp" :GIT-BLOB
   "7fb4c3665ca1b8f6de2dedd2827cfc150dcddf02")
  (:PATH "tests/io/directory-lock.lisp" :GIT-BLOB
   "4cefd15616f4ac2312a669b1242929d2706eb540")
  (:PATH "tests/io/flush-failure.lisp" :GIT-BLOB
   "76a80588d99b441e8c57a97f9a10d4d9d6c7b59b")
  (:PATH "tests/io/native.lisp" :GIT-BLOB
   "bb3f9a460953d5575d7333b8b6eef6ecdb8e1e7d")
  (:PATH "tests/io/open-relative-native.lisp" :GIT-BLOB
   "cdb197bf2760de70e7ec49af76e2954a18006997")
  (:PATH "tests/io/open-relative-support.lisp" :GIT-BLOB
   "4256567b2a10423a41540298317c8ef80e6b5af0")
  (:PATH "tests/io/open-relative.lisp" :GIT-BLOB
   "4bec9451a13db1437e081bda2858d4cb8b1e5de1")
  (:PATH "tests/io/readiness.lisp" :GIT-BLOB
   "1a7ce2205d7278a080395a3f4287540e11d3bea4")
  (:PATH "tests/io/rename-native.lisp" :GIT-BLOB
   "99f79041529d20d0ea774b01e3ed82fc5a274cdd")
  (:PATH "tests/io/rename.lisp" :GIT-BLOB
   "e83443eec6187d53118795c4f6ee797112f27ea2")
  (:PATH "tests/io/support.lisp" :GIT-BLOB
   "0179a0c19bdde944f47fe83716ecc6241e37c686")
  (:PATH "tests/io/transfer-failure.lisp" :GIT-BLOB
   "c87c80fb9c82062bf4d4179d67f710ff10b4f051")
  (:PATH "tests/io/transfer.lisp" :GIT-BLOB
   "40c8f4d5e2d493db090d5d09ab024c67ca6f4037")
  (:PATH "tests/lint-fixtures/bad.lisp" :GIT-BLOB
   "d0d5fd7285428e569d3dd595a0c38de5211e10a5")
  (:PATH "tests/lint-fixtures/good.lisp" :GIT-BLOB
   "35558ab0ab2be7688e9fd55a38be44ebe9a57f37")
  (:PATH "tests/lint-fixtures/keyword-barrier.lisp" :GIT-BLOB
   "b71f5472914b386c88fe6bf079470d19a40a9b96")
  (:PATH "tests/lint-fixtures/qualified-reader.lisp" :GIT-BLOB
   "583969b51a66447b4dfffd6a8fba19e156550e8d")
  (:PATH "tests/local/client-group.lisp" :GIT-BLOB
   "a01da9851d2c0dc468d7c7dab4e050000c679e54")
  (:PATH "tests/local/conditional-group-processes.lisp" :GIT-BLOB
   "3fbda41b85d7b3ea69b36b4b9165be82bdbeda00")
  (:PATH "tests/local/conditional-group.lisp" :GIT-BLOB
   "67c45820cbaead998fad90500f697c52d241884b")
  (:PATH "tests/local/explicit-conditional-group.lisp" :GIT-BLOB
   "f1d46ab6c3096c534daf294cd0cdda232e9aaeef")
  (:PATH "tests/local/explicit-conditional-processes.lisp" :GIT-BLOB
   "b985cc28457754bf305fe21882799db24fdaff37")
  (:PATH "tests/local/explicit-group.lisp" :GIT-BLOB
   "d2ab3e8180c6c27791ea29458526fd2e6be732ff")
  (:PATH "tests/local/group-processes.lisp" :GIT-BLOB
   "8a1d7078a5b37124cfa30867860e47f56ed77f00")
  (:PATH "tests/local/native.lisp" :GIT-BLOB
   "b8891b57aa6229995b7c6ee5581d9cde650e3c93")
  (:PATH "tests/local/processes.lisp" :GIT-BLOB
   "937434fd8d56bd4e4a1961d7ee17d8673c4acbb9")
  (:PATH "tests/local/read-group-processes.lisp" :GIT-BLOB
   "818db6481b2d9e2cc1dce4703bba1516a4b88542")
  (:PATH "tests/local/read-group.lisp" :GIT-BLOB
   "31871cfd92a2cd26de0c486ba497e5d547cae864")
  (:PATH "tests/local/server.lisp" :GIT-BLOB
   "049822aa7abc1acf525920011be267d49320a0cf")
  (:PATH "tests/local/version-processes.lisp" :GIT-BLOB
   "33a51023abe1a9a5e7b08926caf8fd2ff2f1e9bc")
  (:PATH "tests/local/version.lisp" :GIT-BLOB
   "52a44805faa6d6356ca17258885a986001231b76")
  (:PATH "tests/local/wire-conditional-group.lisp" :GIT-BLOB
   "05d7bd65c4d204328887e7830bd5eb0def5e5da3")
  (:PATH "tests/local/wire-group.lisp" :GIT-BLOB
   "f1caba660e45e35c58ecf27219d934f5277ccf4c")
  (:PATH "tests/local/wire-read-group.lisp" :GIT-BLOB
   "5ff23c95d4f6e0e3f24c15970423052ec6b16a9a")
  (:PATH "tests/local/wire-version.lisp" :GIT-BLOB
   "11f313bc4d63d5746637fa82215f40293d9eed97")
  (:PATH "tests/local/wire.lisp" :GIT-BLOB
   "349d7df061b5871658ad3fa6a14601bd58f1fa2c")
  (:PATH "tests/mvcc/capture.lisp" :GIT-BLOB
   "3e08116a1f53e1b764a2f62d9174ff11037a8399")
  (:PATH "tests/mvcc/lifecycle.lisp" :GIT-BLOB
   "2cc481df77ba8d2353985d5a4fb94644fd0861e2")
  (:PATH "tests/mvcc/support.lisp" :GIT-BLOB
   "ca49c8db671b145088d7acfac77cc28a4777dfc2")
  (:PATH "tests/read/lifecycle.lisp" :GIT-BLOB
   "6b20bd639c91aee4c0011b26ba10487ab0f54cc0")
  (:PATH "tests/read/support.lisp" :GIT-BLOB
   "e7f982fc2737ac7c0985c4881325be2711f30bd1")
  (:PATH "tests/read/threads.lisp" :GIT-BLOB
   "b4961a7cb2455d792430a31e8a7528f4561ddc54")
  (:PATH "tests/recovery-active-checkpoint/guards.lisp" :GIT-BLOB
   "cae7d70c2a5598bb5c3e1256ef4bb8b391656f6f")
  (:PATH "tests/recovery-active-checkpoint/publication.lisp" :GIT-BLOB
   "a996bc5f82f16fe12a74d9bee5962f8d8629f53a")
  (:PATH "tests/recovery-active-checkpoint/semantics.lisp" :GIT-BLOB
   "a4b80a1a678cdc4537ee9d989f178124829e70cb")
  (:PATH "tests/recovery-active-checkpoint/support.lisp" :GIT-BLOB
   "998ab160b939c93797fc90206a9b50f2cf55e452")
  (:PATH "tests/recovery-active/publication.lisp" :GIT-BLOB
   "8a3c4ba88dd7010c65a464d231ebdab2c8c27e67")
  (:PATH "tests/recovery-active/read.lisp" :GIT-BLOB
   "63f52ee0e0ab244ed278562a5d7fbc752b7617e7")
  (:PATH "tests/recovery-active/semantics.lisp" :GIT-BLOB
   "1d3c935a1169904c900461b67adb96f4dfd96b94")
  (:PATH "tests/recovery-active/support.lisp" :GIT-BLOB
   "5ebf9d06ae855b07875aadc10e2a8ac01ba56036")
  (:PATH "tests/recovery-archive-csn/guards.lisp" :GIT-BLOB
   "a6d91274479da64fa689ca370ff495cc96ae0e51")
  (:PATH "tests/recovery-archive-csn/native.lisp" :GIT-BLOB
   "d66af858c855e39c984f1ff8534e6de3c7c7fc88")
  (:PATH "tests/recovery-archive-csn/plan.lisp" :GIT-BLOB
   "b740c77023c500208ff742e02c4d5aebcd44db70")
  (:PATH "tests/recovery-archive-csn/set.lisp" :GIT-BLOB
   "d163bf160241d2225ac3282c1d925aa65e249ab3")
  (:PATH "tests/recovery-archive-csn/support.lisp" :GIT-BLOB
   "0c458a3f6f8aa062c2cc8831834c29159e09762d")
  (:PATH "tests/recovery-archive/active.lisp" :GIT-BLOB
   "ccbaaa3294880905584ad42c0601201fa3a3dc36")
  (:PATH "tests/recovery-archive/guards.lisp" :GIT-BLOB
   "8afea2a3df30099c07badd7d9c0bcf627a5f9a9d")
  (:PATH "tests/recovery-archive/native.lisp" :GIT-BLOB
   "ae8df9ced72f9142ade184ec78bdc576e05593e1")
  (:PATH "tests/recovery-archive/query.lisp" :GIT-BLOB
   "b0a56949ec13ec7c80466ac8b3cecc79c0fc6d63")
  (:PATH "tests/recovery-archive/read.lisp" :GIT-BLOB
   "22d1042700435e2c15e3f610f9ada9c4a8d8d4ed")
  (:PATH "tests/recovery-archive/support.lisp" :GIT-BLOB
   "0cbefaed0f74c8e34e4cea9a359c58f9196f22ad")
  (:PATH "tests/recovery-closed/csn.lisp" :GIT-BLOB
   "754611c3818a0aac26b189392d4024a251439d0c")
  (:PATH "tests/recovery-closed/guards.lisp" :GIT-BLOB
   "344857641ef2206d4d5a800fbb93b834a9f13c4d")
  (:PATH "tests/recovery-closed/publication.lisp" :GIT-BLOB
   "72f179d28936100b91d1847eeb8a24c696552619")
  (:PATH "tests/recovery-closed/read.lisp" :GIT-BLOB
   "0e401337f36768cd63206cbb7b6adf91eeeeb1ef")
  (:PATH "tests/recovery-closed/semantics.lisp" :GIT-BLOB
   "a931be1523c72d49e955aa7708bec6bd3b273be0")
  (:PATH "tests/recovery-closed/support.lisp" :GIT-BLOB
   "15bafc01c04fe1763d9a6580f6ad0bbb1917f40c")
  (:PATH "tests/recovery/corruption.lisp" :GIT-BLOB
   "2f9ead22a4e3b45cb3a680aa3a32a94bfcc6d77f")
  (:PATH "tests/recovery/decisions-audit.lisp" :GIT-BLOB
   "1b79a76515d8b8c2e67c46700cd6968b40047d62")
  (:PATH "tests/recovery/decisions-radix.lisp" :GIT-BLOB
   "232312cdd4ed6b1efcedc33ddda0fd8d1d8545d7")
  (:PATH "tests/recovery/decisions-support.lisp" :GIT-BLOB
   "f67450a9d681512a4b66efe1af1bfc82180e0058")
  (:PATH "tests/recovery/decisions.lisp" :GIT-BLOB
   "28d04d8738f077bf21ac22393a4014b518a6a0f2")
  (:PATH "tests/recovery/inventory-directory-id.lisp" :GIT-BLOB
   "e6f289d77025dce439787287abc6a4dde0ac69f5")
  (:PATH "tests/recovery/inventory-directory-native.lisp" :GIT-BLOB
   "8f89629becea88fdc74c920a59676412c3a7b976")
  (:PATH "tests/recovery/inventory-directory-support.lisp" :GIT-BLOB
   "c316b3647e7ea5391d687917fe802907f2273bb4")
  (:PATH "tests/recovery/inventory-directory.lisp" :GIT-BLOB
   "ead38feadd94f49276596d0abf989f29d13af497")
  (:PATH "tests/recovery/inventory-id.lisp" :GIT-BLOB
   "1f05c46bfc887984c476bd7673d2b2dde998c44d")
  (:PATH "tests/recovery/inventory-sources-native.lisp" :GIT-BLOB
   "86144ee3fe19ef0f2a54c9760ed193860881ced4")
  (:PATH "tests/recovery/inventory-sources-support.lisp" :GIT-BLOB
   "36b79c4091825c32ffc3aa32a146ee5121881ebc")
  (:PATH "tests/recovery/inventory-sources.lisp" :GIT-BLOB
   "3ffd5a9fb098ab4aeb091a6823fcec68d22c19aa")
  (:PATH "tests/recovery/inventory-support.lisp" :GIT-BLOB
   "06eeff2101a97f9abdec6b6f14aa621c2fec29fd")
  (:PATH "tests/recovery/inventory.lisp" :GIT-BLOB
   "0d5722e4f5ba0025d3a6fb38f0bd056a3ea0b8e9")
  (:PATH "tests/recovery/manifest-audit.lisp" :GIT-BLOB
   "9dc9667bdae700ff8ff2afc93bb385c0617eda70")
  (:PATH "tests/recovery/manifest-support.lisp" :GIT-BLOB
   "7d3b1be9964aba5894215f29b7eda3d7a14a797f")
  (:PATH "tests/recovery/manifest-transition.lisp" :GIT-BLOB
   "cdde7b60edddd974153ee670d859a94993afa367")
  (:PATH "tests/recovery/manifest.lisp" :GIT-BLOB
   "085e019e251106f6feecc7452e7b2d471a1a626f")
  (:PATH "tests/recovery/scan.lisp" :GIT-BLOB
   "1c7d71c32d58b05f7e06450680270cb55f6325dc")
  (:PATH "tests/recovery/support.lisp" :GIT-BLOB
   "f784671c59065b4363bcc5e49f06559b11e6562c")
  (:PATH "tests/runtime/adoption.lisp" :GIT-BLOB
   "8fbee7f08a25445b66895ae2e329a217070f67f4")
  (:PATH "tests/runtime/bootstrap.lisp" :GIT-BLOB
   "1398120574f95ebaec3c7431a74a35e0ced01652")
  (:PATH "tests/runtime/guards.lisp" :GIT-BLOB
   "a097cc38e13a1ef7369a2ed996d042718cf7312c")
  (:PATH "tests/runtime/native.lisp" :GIT-BLOB
   "e92ba03fb8184a6c95c44269a26a831b714974a1")
  (:PATH "tests/runtime/support.lisp" :GIT-BLOB
   "7d4dc59eab68672512aed0f4ae578436e669fe2e")
  (:PATH "tests/runtime/threads.lisp" :GIT-BLOB
   "2454593a231d5d6bb9ef4318eb06567ce3192d24")
  (:PATH "tests/scheduler/controller.lisp" :GIT-BLOB
   "8e14282e1f42f3b247a5c578d8a683ddc6147381")
  (:PATH "tests/scheduler/dispatch.lisp" :GIT-BLOB
   "6a493f0022ac8c9b6117c2a62df49fa596194c7b")
  (:PATH "tests/scheduler/lifecycle.lisp" :GIT-BLOB
   "874391809401f42a4db81fe544306165f99ceb5d")
  (:PATH "tests/scheduler/pool-begin.lisp" :GIT-BLOB
   "13a239cf97403806a73242abbd5b545440a17645")
  (:PATH "tests/scheduler/pool-chain-support.lisp" :GIT-BLOB
   "a1ea8258495b9a717e1e0ef164133f6b7140f8a5")
  (:PATH "tests/scheduler/pool-chain.lisp" :GIT-BLOB
   "86675c17ea47eff262cb03cdb41e50bcdb82b78e")
  (:PATH "tests/scheduler/pool-claim.lisp" :GIT-BLOB
   "f636ee873deb2cd5347a50c9aec4a6afa16d13c5")
  (:PATH "tests/scheduler/pool-recycle.lisp" :GIT-BLOB
   "3c779589cd7df6ae1146c2ca50b70320093bbf4a")
  (:PATH "tests/scheduler/pool-start.lisp" :GIT-BLOB
   "ec19bb409799e7956e40c34cc9264d02033cfb22")
  (:PATH "tests/scheduler/pool-step.lisp" :GIT-BLOB
   "d0ff803608990744408749722210e812f6268782")
  (:PATH "tests/scheduler/support.lisp" :GIT-BLOB
   "f2301a1adf44c33284aaa1171acd90c5828b0396")
  (:PATH "tests/series/boundaries.lisp" :GIT-BLOB
   "ca1e85473a76a5255cc591d7d239cedbd35acbe4")
  (:PATH "tests/series/controller.lisp" :GIT-BLOB
   "ef3d4671b3df48b932c1666f8b58fdca4eecbc77")
  (:PATH "tests/series/log-binding.lisp" :GIT-BLOB
   "c116a9169058ddd9e384fda5f52bb5787977e20e")
  (:PATH "tests/series/support.lisp" :GIT-BLOB
   "257c6f8cf28bdd8408a3363041d621497f4a5f67")
  (:PATH "tests/series/threads.lisp" :GIT-BLOB
   "c3eb1ce7870b81944c23efac9b8cb7f8f4888ba9")
  (:PATH "tests/series/worker-bridge.lisp" :GIT-BLOB
   "cb61feecd1f097cfc86af5de8b169d222b84f7a8")
  (:PATH "tests/series/worker-routing.lisp" :GIT-BLOB
   "59722f73f21ad9d5ce59e1b4785c025054a57cc5")
  (:PATH "tests/smoke.lisp" :GIT-BLOB
   "6bd4ab9af1f3d9eedd54822eae10b7f167aa99ed")
  (:PATH "tests/storage/compaction-scan.lisp" :GIT-BLOB
   "16e5c9e5231883844ecd7956c7f790349acd2a05")
  (:PATH "tests/storage/control-payload.lisp" :GIT-BLOB
   "72358c6f324e1c7aaab2bb2c9d03d39ccf78f664")
  (:PATH "tests/storage/log-header.lisp" :GIT-BLOB
   "b3c4c96603ee769429b847569559defda5059744")
  (:PATH "tests/storage/segment-header.lisp" :GIT-BLOB
   "7155aaf2e9c0df4f96533a0be0f6532b54f44590")
  (:PATH "tests/storage/support.lisp" :GIT-BLOB
   "6aa5df3b3cc62b552f5da890583654b82df99431")
  (:PATH "tests/verify/canonical.lisp" :GIT-BLOB
   "66f603183d98b01acf07228f19bf3025e48254d7")
  (:PATH "tests/verify/cli.lisp" :GIT-BLOB
   "93078b49e212420f81f52083a7b717a163b7727f")
  (:PATH "tests/verify/guards.lisp" :GIT-BLOB
   "d2511620da049cd377a4847e74b82f7200fbebcd")
  (:PATH "tests/verify/observer.lisp" :GIT-BLOB
   "ecc44b603fba3142bc5a069d3d2be22e8e76a55a")
  (:PATH "tests/verify/order.lisp" :GIT-BLOB
   "1e61ba11c977de74cadbe950bc68fe6d3fb11170")
  (:PATH "tests/verify/processes.lisp" :GIT-BLOB
   "feb165176cc6c6661b30453513c21f981cb58113")
  (:PATH "tests/verify/support.lisp" :GIT-BLOB
   "668b4909687394df5b41f27fd0636f22027ca1ab")
  (:PATH "tests/vertical/method.md" :GIT-BLOB
   "3e60572557391e2c772d3b44491ae18eecb352bf")
  (:PATH "tests/vertical/processes.lisp" :GIT-BLOB
   "059fbd2bb702e76e986b97edfbe4d3784599d583")
  (:PATH "tests/vertical/resume.lisp" :GIT-BLOB
   "6f80a0d0fec9f725beca54d06d961932bd815043")
  (:PATH "tests/vertical/scenarios.lisp" :GIT-BLOB
   "fcbc7878d56720604f0e86a916d2e42c0f28cffd")
  (:PATH "tests/vertical/support.lisp" :GIT-BLOB
   "37c2e8d1da68eb425cdd11548f8699c888afd7bf")
  (:PATH "tests/wal/append.lisp" :GIT-BLOB
   "2e0d75a68d6ca657634c22fcb5632d1cf5fa8a1a")
  (:PATH "tests/wal/builder.lisp" :GIT-BLOB
   "d62777cd09f8c30fc7246f59fd1bca8ea80c4559")
  (:PATH "tests/wal/csn-threads.lisp" :GIT-BLOB
   "25f9b134556bd4f1a842f536ddc89ba64a76892e")
  (:PATH "tests/wal/csn.lisp" :GIT-BLOB
   "da91333751d4b72259cf766e7441065b8c4387ec")
  (:PATH "tests/wal/fault.lisp" :GIT-BLOB
   "6361a87d73ce90f78438008693a7cd9d6461fe9b")
  (:PATH "tests/wal/group.lisp" :GIT-BLOB
   "04281d9ea3837ed2af0e7fa33b7e17df814982d7")
  (:PATH "tests/wal/native.lisp" :GIT-BLOB
   "077a835fb47524d97e449ae87c74461ebb374653")
  (:PATH "tests/wal/support.lisp" :GIT-BLOB
   "638262b264c64b96774ddb0a6095f4e582debe3e")
  (:PATH "tools/arcdocdb-verify.lisp" :GIT-BLOB
   "5aed85033d701c64e2c4698fae58dcb947dc80e8")
  (:PATH "tools/build.lisp" :GIT-BLOB
   "40879533738e1fc49e74941a9def5b089c551921")
  (:PATH "tools/cbor-float-write-audit.lisp" :GIT-BLOB
   "485544868eeadff247968b86c2d5da9b3b610295")
  (:PATH "tools/cbor-float-write-bench.lisp" :GIT-BLOB
   "d992c9f8cf6ff0d748fcb77f871fb77969480bca")
  (:PATH "tools/cbor-float-write-mutation.lisp" :GIT-BLOB
   "5d0d6bd46b0286f153ee9c482734c659959396e2")
  (:PATH "tools/cbor-header-bench.lisp" :GIT-BLOB
   "82b7068432790f9883a56c0b03229003d3541f90")
  (:PATH "tools/cbor-header-mutation.lisp" :GIT-BLOB
   "a47d36577af8e249c045096a5f7270cd628f0df8")
  (:PATH "tools/cbor-minimal-bench.lisp" :GIT-BLOB
   "fd85474e6bbc781a0e5df7c6df3a4891b4da29f7")
  (:PATH "tools/cbor-minimal-mutation.lisp" :GIT-BLOB
   "60b1ac184498623d1364df66e1d95f93165af159")
  (:PATH "tools/cbor-minimal-scan-bench.lisp" :GIT-BLOB
   "3cdd34a3dd5747f7fd0e513a1f2daeb7e2c2bbfb")
  (:PATH "tools/cbor-simple-write-audit.lisp" :GIT-BLOB
   "6acfcc656bfed5f8b4c59e487cffb5325d30d790")
  (:PATH "tools/cbor-simple-write-bench.lisp" :GIT-BLOB
   "07e5b0b7773f95ddae9458267b285c0ccb24dba9")
  (:PATH "tools/cbor-simple-write-mutation.lisp" :GIT-BLOB
   "ec2fe6b3235591ec5b3bb82b32046e906b045bf6")
  (:PATH "tools/cbor-string-read-driver.lisp" :GIT-BLOB
   "a6b65bd233dba2a2eec941d96a75b9db948d19f8")
  (:PATH "tools/cbor-string-write-audit.lisp" :GIT-BLOB
   "ae591bf0f2b37d0ed2ae08f16d0270568268a048")
  (:PATH "tools/cbor-string-write-bench.lisp" :GIT-BLOB
   "c4bd98e145d13deb47b7eedb0f4581a241f1d0e1")
  (:PATH "tools/cbor-string-write-mutation.lisp" :GIT-BLOB
   "ac4e1b095c88051cb9425ed023a8be8311b0108e")
  (:PATH "tools/cbor-structure-bench.lisp" :GIT-BLOB
   "a0a676c0107dee9429f27d3fdcdc78bb3d7f2957")
  (:PATH "tools/cbor-structure-mutation.lisp" :GIT-BLOB
   "e43405f5a6825f420364f112de951013d36b85ca")
  (:PATH "tools/cbor-write-bench.lisp" :GIT-BLOB
   "7ebf958bfc54c312cfd7f80146fec2117529b6f1")
  (:PATH "tools/cbor-write-mutation.lisp" :GIT-BLOB
   "a39159a8f63d995166eabec0a6f6e0836af9f799")
  (:PATH "tools/check-command-archive.lisp" :GIT-BLOB
   "4c56e6f317cc0e1a6785c4071126c6cca7dd68b7")
  (:PATH "tools/check-evidence-normalize.lisp" :GIT-BLOB
   "b15b6ab7edaacfc8d78ab0f36a0416af2e1c306d")
  (:PATH "tools/check-evidence-parallel-tests.lisp" :GIT-BLOB
   "a49a03a64a137e66c07c98f981327fc42d9cb508")
  (:PATH "tools/check-evidence-publication.lisp" :GIT-BLOB
   "458e9b82cea915be89180a02c406522f75175f75")
  (:PATH "tools/check-evidence-storage.lisp" :GIT-BLOB
   "76afc9a986beb31ae7ce37443ad3748b7052bdb4")
  (:PATH "tools/check-evidence.lisp" :GIT-BLOB
   "e3df9f52590ce2de86ad75b872c859b81bbcc518")
  (:PATH "tools/check-links.lisp" :GIT-BLOB
   "1f63d49150e6b7b23c1df2a9c25c3d2288861b8a")
  (:PATH "tools/check-trace.lisp" :GIT-BLOB
   "253fea1c65c6aacb77fa56f2ab05cce086a1856d")
  (:PATH "tools/ci.lisp" :GIT-BLOB "c0b6255982f4299b883992f5829baaebcd2aaa36")
  (:PATH "tools/ci/archive.lisp" :GIT-BLOB
   "03712985b7cf1493a7009a35965cadf6c9902292")
  (:PATH "tools/ci/conditions-self-test.lisp" :GIT-BLOB
   "99f857163fa38683871790731b6f72448cf92ffb")
  (:PATH "tools/ci/coverage.lisp" :GIT-BLOB
   "233ae46d6ab9fab6a74046140323eecc64243174")
  (:PATH "tools/ci/data-self-test.lisp" :GIT-BLOB
   "b5d6a8f505604e3c45d228582933af38713cc01a")
  (:PATH "tools/ci/data.lisp" :GIT-BLOB
   "8cec68fa2e6e5d7e4484a53cde13964b875f9222")
  (:PATH "tools/ci/github.lisp" :GIT-BLOB
   "a2ca20ed9c586b104f59091d174028b3454d6a10")
  (:PATH "tools/ci/identity.lisp" :GIT-BLOB
   "abf3cc722957379e1408d629b81a2d1916a0788b")
  (:PATH "tools/ci/measure-self-test.lisp" :GIT-BLOB
   "18959f2608b1be4ef1b77b0a7d3b1a67735c16d4")
  (:PATH "tools/ci/measure.lisp" :GIT-BLOB
   "7e16fd5b80a7bbce27a0c856a6abd001ff4814ed")
  (:PATH "tools/ci/producer.lisp" :GIT-BLOB
   "a7fab0bcc8dc6a33ed37acb0d391ec1a73674493")
  (:PATH "tools/ci/publish-self-test.lisp" :GIT-BLOB
   "400b9ba4c1c3fd0e6bd158f3f89bcc58e802c595")
  (:PATH "tools/ci/publish.lisp" :GIT-BLOB
   "d8a212faaa5bba7df102377a70e6cd9d75d7810c")
  (:PATH "tools/ci/self-test.lisp" :GIT-BLOB
   "8b2cfa7eab4f728c70a4f0f6e4a81da3259a9e38")
  (:PATH "tools/ci/support.lisp" :GIT-BLOB
   "b5fe7c565ed0f885b666d8dba836bec4a7ba4c65")
  (:PATH "tools/ci/test-self-test.lisp" :GIT-BLOB
   "518ac77485351807b4b72c0cc7e030821ec81ab0")
  (:PATH "tools/ci/tests.lisp" :GIT-BLOB
   "9c81cf6aec5f89896d9e4ccdcd59ccf1d3c65c6f")
  (:PATH "tools/ci/workflow-self-test.lisp" :GIT-BLOB
   "f0278d9bc21245d6890e52011414627376bca5de")
  (:PATH "tools/collect-command-archive-tests.lisp" :GIT-BLOB
   "49da390b7e170acc9ffdafa78285f215aec75f44")
  (:PATH "tools/collect-command-archive.lisp" :GIT-BLOB
   "d2eb1bd8a62b0fd98ec023243b2a768c19988dc7")
  (:PATH "tools/compact-evidence.lisp" :GIT-BLOB
   "72a1c32b1efcb7fd89ff798a669a558ceffb0aa0")
  (:PATH "tools/compaction-bench.lisp" :GIT-BLOB
   "08ed205d82e6df9e1c044ef6ad714568bb140c0b")
  (:PATH "tools/compaction-mutation.lisp" :GIT-BLOB
   "a8d9a27713e0dfd1d98626aa43e05554285e5aa9")
  (:PATH "tools/control-checkpoint-bench.lisp" :GIT-BLOB
   "f631bbb7096359592fde0ae2b4462c2d2067d5a1")
  (:PATH "tools/control-transition-bench.lisp" :GIT-BLOB
   "40fd5a04dc62cced8e688ed30f59e0d810716a43")
  (:PATH "tools/csn-bench.lisp" :GIT-BLOB
   "6bf306166acbe72f0e57849656d4ab4e06f44c38")
  (:PATH "tools/csn-mutation.lisp" :GIT-BLOB
   "6e34a662d052b72eaf3b318365140f8d7d215851")
  (:PATH "tools/decisions-radix-mutation.lisp" :GIT-BLOB
   "1068f3f3ef7d46253c8ff83109791cd8d40a92e9")
  (:PATH "tools/decisions-sort-bench.lisp" :GIT-BLOB
   "a1bee0418d542eae3800213fc23df402ccd75a41")
  (:PATH "tools/engine-crash.lisp" :GIT-BLOB
   "04c4796c05bdcecf6d8fc83d3ee1eafcf969fed9")
  (:PATH "tools/evidence-size-audit.lisp" :GIT-BLOB
   "6c77f9642dc0fb373677dbcdca579c65cc8f4d83")
  (:PATH "tools/evidence-storage.lisp" :GIT-BLOB
   "fa2b5d36dca0837e2ed5e49b282887b2e110b2b7")
  (:PATH "tools/finish-evidence.lisp" :GIT-BLOB
   "c8ebe7bbe4c99a3c712033d0f58e97610914f87f")
  (:PATH "tools/foundation-bench.lisp" :GIT-BLOB
   "7dcbedc52483f6374b0dad9cf00230f9112f952d")
  (:PATH "tools/foundation-coverage.lisp" :GIT-BLOB
   "abd8e62e937c60e9ac68c3ccce904111388bff09")
  (:PATH "tools/foundation-mutation.lisp" :GIT-BLOB
   "f520ecdb46cc94e07d774d39cb73beed380aa867")
  (:PATH "tools/fulltext-codec-fixture.lisp" :GIT-BLOB
   "f6756e030cdde7beaab41a6b38516950f1663c9e")
  (:PATH "tools/fulltext-persistence.lisp" :GIT-BLOB
   "ab0dbf4ec2e5335721818cc03711b92d7d62111d")
  (:PATH "tools/fulltext-qualification.lisp" :GIT-BLOB
   "d649e9cafa96bcb4351bbced5de04bb10352ab85")
  (:PATH "tools/fulltext-unicode-tables.lisp" :GIT-BLOB
   "ba86b196441a40e662f6052e189074eef08b75d5")
  (:PATH "tools/get-active-init-bench.lisp" :GIT-BLOB
   "c62f2bf8ba96c3e80cdd50ba067e4c4df3e5e957")
  (:PATH "tools/get-active-init-mutation.lisp" :GIT-BLOB
   "b2cd809d99d049757156ddf0141997e3b67903b4")
  (:PATH "tools/get-cost-bench.lisp" :GIT-BLOB
   "696d56846ce992f186da2b468f8de55063532b02")
  (:PATH "tools/get-directory-bench.lisp" :GIT-BLOB
   "a6aea6c5a019aa377c7dc7c0d70a5e58b0050773")
  (:PATH "tools/get-directory-evidence.lisp" :GIT-BLOB
   "fbebdbcdb40b2e96c0098a987b16ba2fe3c9b7b5")
  (:PATH "tools/get-directory-mutation.lisp" :GIT-BLOB
   "7aa626295770df49dc1fb703137542de1c93564c")
  (:PATH "tools/get-performance-bench.lisp" :GIT-BLOB
   "45897c0afa972a437bbb595493b87dd0c8ed9710")
  (:PATH "tools/get-performance-evidence.lisp" :GIT-BLOB
   "f098cdb4cf5f0447365cf0bf255e1935d04bc53b")
  (:PATH "tools/get-performance-mutation.lisp" :GIT-BLOB
   "231cb906b55b9c92905deefc112f7baebecbd4af")
  (:PATH "tools/get-resolver-coverage.lisp" :GIT-BLOB
   "5ab21d923b68e35adbc177ecd352bb33340f0c07")
  (:PATH "tools/get-series-bench.lisp" :GIT-BLOB
   "2950d4fcb7fc93fbfc7d78c860f0ac43ed984f35")
  (:PATH "tools/get-series-capture.lisp" :GIT-BLOB
   "9c42e23d381751e8140f186f969c6c2ef8d606cf")
  (:PATH "tools/get-series-mutation.lisp" :GIT-BLOB
   "3d3e887ba8e1d90612e561dfffb3d71c486e813b")
  (:PATH "tools/get-throughput-bench.lisp" :GIT-BLOB
   "6554b119583602b9d06b3ff7b2bb9c8104130d79")
  (:PATH "tools/index-image-crash.lisp" :GIT-BLOB
   "01f7cec3a08a55fcf51b4c743e588ad53a0023ae")
  (:PATH "tools/index-rebuild-bench.lisp" :GIT-BLOB
   "0f6143fe0f69d972eb3723adb98cf4c1df1f7033")
  (:PATH "tools/index-rebuild-evidence.lisp" :GIT-BLOB
   "ba2c92a3dd88e2414b5500739eb5622da1d91d6b")
  (:PATH "tools/index-rebuild-mutation.lisp" :GIT-BLOB
   "8d60f445b933c82a6c6dbe98e4c9c3f7b1589340")
  (:PATH "tools/io-bench.lisp" :GIT-BLOB
   "ccb75032fce4765f0db7948cb594ef14f50be36e")
  (:PATH "tools/io-completion-mutation.lisp" :GIT-BLOB
   "7fd59fd86e2d477a6b6ee0f7a2142f8ea6b073c6")
  (:PATH "tools/io-rename-bench.lisp" :GIT-BLOB
   "988d259af126212adc2be8fb9ca9acd8755fdce0")
  (:PATH "tools/io-rename-mutation.lisp" :GIT-BLOB
   "dfc691c88e9ab940a065703a223a1c414454b0f2")
  (:PATH "tools/key-hash-bench.lisp" :GIT-BLOB
   "c86f91b92ba547d6fd0ad4f2b38710281d7c19db")
  (:PATH "tools/key-hash-evidence.lisp" :GIT-BLOB
   "7a54d7baa419f642b610d8d939b9048125e0efe6")
  (:PATH "tools/key-hash-mutation.lisp" :GIT-BLOB
   "5209188cf4f85d6f28b07e8e526ea859da91c083")
  (:PATH "tools/legal-notices.lisp" :GIT-BLOB
   "f120b9660591fd3eda904c9cf0722bddae3f05a0")
  (:PATH "tools/lint.lisp" :GIT-BLOB
   "adf3ca235874a2b950e57ea61a719c4c90e9dda8")
  (:PATH "tools/local-client.lisp" :GIT-BLOB
   "1ab2f474ad7db04a3fc8cc6dd7e84a2441498d20")
  (:PATH "tools/local-conditional-group-server.lisp" :GIT-BLOB
   "92145f31ddb22c4e6c205413ad31fdb24fc0dc17")
  (:PATH "tools/local-conditional-request-server.lisp" :GIT-BLOB
   "11ea1128fb278c71bc6cf5b1ed94be5ac6e2513b")
  (:PATH "tools/local-fault-server.lisp" :GIT-BLOB
   "92cd3d6164c6000c181374e3b917bbf1bb83aaa6")
  (:PATH "tools/local-group-server.lisp" :GIT-BLOB
   "924184dbc27702cbf84cf13b0cdb6e0d62a00bb5")
  (:PATH "tools/local-read-loss-server.lisp" :GIT-BLOB
   "56f7401d185564c0bfe9c834742812fc42a4a6a7")
  (:PATH "tools/local-server.lisp" :GIT-BLOB
   "517652d80ad2d4fbbe85be42fa110d4c902d8cf8")
  (:PATH "tools/local-tests.lisp" :GIT-BLOB
   "02aace929b7f5e2fd790c02d1557628ea17d7afc")
  (:PATH "tools/local-version-loss-server.lisp" :GIT-BLOB
   "89f4ed52dd4f7de5b0b4ac2420f3aaef78618a41")
  (:PATH "tools/log-header-bench.lisp" :GIT-BLOB
   "acf45c9c691752a1f1516ca92d71459a3c94d5bd")
  (:PATH "tools/log-header-mutation.lisp" :GIT-BLOB
   "3c1e7eaa014e7ebf57b42c2bb83b4f448eeec31b")
  (:PATH "tools/measure-pool-begin.lisp" :GIT-BLOB
   "e3094d9f35efdaa647751f19a7acda00c36d515a")
  (:PATH "tools/measure-pool-claim.lisp" :GIT-BLOB
   "712a4a5393b69539f02cd625223918e404b331d3")
  (:PATH "tools/measure-pool-dispatch.lisp" :GIT-BLOB
   "bddb449176d3b7b6ae946e841a0ca3202e6c28ef")
  (:PATH "tools/measure-pool-lifecycle.lisp" :GIT-BLOB
   "3a229eecc3c158cec9af8fad6abd5fc2d980e2dd")
  (:PATH "tools/measure-pool-recycle.lisp" :GIT-BLOB
   "cb20f6d271889a9801106daf230ee934aaa7bf81")
  (:PATH "tools/measure-pool-start.lisp" :GIT-BLOB
   "e6be453833925b89cdc49303b99a23374f3b2689")
  (:PATH "tools/measure-pool-step.lisp" :GIT-BLOB
   "cdcb410e27475282d157b0d64a4656ea6ad069a1")
  (:PATH "tools/normalize-spike-report.lisp" :GIT-BLOB
   "e745f0c67e0abf3a9ea1bbc2981f6331ffc48e4c")
  (:PATH "tools/pages/bootstrap.lisp" :GIT-BLOB
   "a9cf9ea45672b576b76acf1e4773c2c2949bc2ca")
  (:PATH "tools/pages/build.lisp" :GIT-BLOB
   "e319acad4fe5bf1f9cd14b65772775c95ab632fe")
  (:PATH "tools/pages/check.lisp" :GIT-BLOB
   "b0524f02c494e61f4edf08aa2802ba1a3d16cd66")
  (:PATH "tools/pages/code-reference.lisp" :GIT-BLOB
   "16bf45ca14cc936283e32700698e696f4a36a09c")
  (:PATH "tools/pages/code-source.lisp" :GIT-BLOB
   "8ba99903d3afdae918fd8966410fbbaf7438066f")
  (:PATH "tools/pages/code-tests.lisp" :GIT-BLOB
   "1f1349e749863b14d9690a33dda48537d96434e3")
  (:PATH "tools/pages/dependencies.lock.lisp" :GIT-BLOB
   "f0f339aabf9998e7f910f8904744549766426ec6")
  (:PATH "tools/pages/editorial.lisp" :GIT-BLOB
   "f5a43b2ba1a876c3643ad4b3b64b43096c193b49")
  (:PATH "tools/pages/generate.lisp" :GIT-BLOB
   "56ee4dcf36cc76e82b3997357630eca1083dadff")
  (:PATH "tools/pages/markdown.lisp" :GIT-BLOB
   "a6ce370b0cbbeb2869c88112b69ee7aa38e7effa")
  (:PATH "tools/pages/model.lisp" :GIT-BLOB
   "bed6a6fb53b8efb13020bcf5cc5d1ec27aa31436")
  (:PATH "tools/pages/publication.lisp" :GIT-BLOB
   "8154535b76733cbdd33b3217744481635860a5a0")
  (:PATH "tools/pages/runtime-check.lisp" :GIT-BLOB
   "f9ab88e954f1b07f9c59594f55e67e909ee5f2e3")
  (:PATH "tools/pages/site.css" :GIT-BLOB
   "8069a0942d7ce79b272d8011c4f6c6002aae07e1")
  (:PATH "tools/pages/site.js" :GIT-BLOB
   "06770c92736cc6bd2b3e0c9638ec09f5c0dcc1c3")
  (:PATH "tools/pages/tests.lisp" :GIT-BLOB
   "d05b62748b36cefed5977d1a445c18e1d70b8e62")
  (:PATH "tools/pages/theme.lisp" :GIT-BLOB
   "547ef0acc0e6070c7fcd53385b0efed1aec5f82d")
  (:PATH "tools/pages/third-party-notices.lisp" :GIT-BLOB
   "907abf85677565bb547a4b7f0e7c6311b3bfa3ce")
  (:PATH "tools/pages/third-party-notices.txt" :GIT-BLOB
   "68ebcf8172dcbbf0865767f5194abb97911a83ef")
  (:PATH "tools/pool-controller-bench.lisp" :GIT-BLOB
   "cf6f31dd9c7a8d7f4e7cc1f19c4b9c5a48af6d55")
  (:PATH "tools/read-evidence.lisp" :GIT-BLOB
   "c41d27bfad39875f6c80858d451bacfcac862945")
  (:PATH "tools/reader-mutation.lisp" :GIT-BLOB
   "256252a0cdeb1d62bce34cee030093858fd2a5f8")
  (:PATH "tools/record-command.lisp" :GIT-BLOB
   "068090ec38864b2b55877918aec57375312ee8db")
  (:PATH "tools/recovery-active-bench.lisp" :GIT-BLOB
   "9c11d5654a6168c27c64abcc8f852673c5974515")
  (:PATH "tools/run-spikes.lisp" :GIT-BLOB
   "f4951198a9198f32cf064534bbdc42d7bf3be9f8")
  (:PATH "tools/series-controller-bench.lisp" :GIT-BLOB
   "e1150055aeba7db590f07bb4e041094a9816fd4e")
  (:PATH "tools/series-controller-evidence.lisp" :GIT-BLOB
   "48e94f7e3432d29c29ec0ac1c75834769ba93dcd")
  (:PATH "tools/series-controller-mutation.lisp" :GIT-BLOB
   "ac124ab2fdd0d7562c0c8af8dc03153b2abde3f1")
  (:PATH "tools/snapshot-mutation.lisp" :GIT-BLOB
   "b46e9d42dd1c21e28ebbd661afe3ee05a1749fcd")
  (:PATH "tools/storage-bench.lisp" :GIT-BLOB
   "1da33e31673c8ab8458292350ac44fff2a5e96b3")
  (:PATH "tools/utf8-bench.lisp" :GIT-BLOB
   "a5edc926e662d0259712840d502a1f1a13143399")
  (:PATH "tools/utf8-mutation.lisp" :GIT-BLOB
   "27769759bb927e2055d711a6e723a69c468b0a0c")
  (:PATH "tools/vertical-crash.lisp" :GIT-BLOB
   "8f920374d5b1049f5bac1e8dfb441099575de6cd")
  (:PATH "tools/wal-bench.lisp" :GIT-BLOB
   "e6a3c8104fb0b7ebfaaff3e7966ad6d46d8a23ff")
  (:PATH "tools/wal-csn-bench.lisp" :GIT-BLOB
   "686671a5ea321554bbde0bbe6952d1d09a568f65")
  (:PATH "tools/wal-csn-mutation.lisp" :GIT-BLOB
   "b2413c756269e73eb3b08576d42f9584e311ee71")
  (:PATH "tools/worker-routing-bench.lisp" :GIT-BLOB
   "062e8dbbfb0fc912af22d037091d8b1b64f07b1e")
  (:PATH "tools/worker-series-bench.lisp" :GIT-BLOB
   "2d9b7fca164ef84543bb3c0f68c525e6813a8a8c")
  (:PATH "tools/writer-handoff-bench.lisp" :GIT-BLOB
   "7222a4a43a9be50653f8c63b1d09b37a249347c0")
  (:PATH "tools/writer-handoff-mutation.lisp" :GIT-BLOB
   "cafc0dbaedb6671672f994dfd86814d72f3307b8")
  (:PATH "tools/writer-queue-bench.lisp" :GIT-BLOB
   "6eda115b6379e6639aaff706c557f2e0c4e08b3d")
  (:PATH "tools/writer-queue-mutation.lisp" :GIT-BLOB
   "124778bd5b293d0436acf29c1bfa58480de1f701")
  (:PATH "tools/writer-ready-bench.lisp" :GIT-BLOB
   "f666bc8d68738c65c442404ffffc6d342a020c9b")
  (:PATH "tools/writer-ready-mutation.lisp" :GIT-BLOB
   "1401a183d345aedb1eb7eb07e3331180325fb07a")
  (:PATH "tools/writer-recycle-bench.lisp" :GIT-BLOB
   "e41b25ceb84621af27f22f11f7ad4ee11bd4a1b8")
  (:PATH "tools/writer-recycle-mutation.lisp" :GIT-BLOB
   "6ed4f867fd875231189f99367958300b2cecaab7")
  (:PATH "tools/writer-worker-bench.lisp" :GIT-BLOB
   "1208ddc9971179fc3fcb9300a9ba3c22fcd4a8b9")
  (:PATH "tools/writer-worker-mutation.lisp" :GIT-BLOB
   "568bccdb1229b124e43e5c1b756cf726ead6fcbc"))
 :STDOUT "(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 174374
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61606032 :P50-TICKS 133
 :P99-TICKS 173 :LATENCY-TICKS
 #(139 154 140 173 152 144 132 133 138 147 136 148 115 130 141 130 131 133 130
   144 129 129 144 149 157 153 131 148 134 137 132 127 131 131 129 138 153 137
   129 148 137 135 128 147 151 149 134 153 155 144 136 152 135 147 136 128 145
   134 129 155 134 135 152 135 147 148 133 156 135 136 131 130 127 144 130 128
   129 129 129 132 127 144 127 128 128 171 137 142 134 136 168 140 131 130 130
   132 132 149 131 130 130 149 130 131 129 131 135 131 146 142 140 150 135 139
   130 153 134 136 129 129 137 130 129 148 137 130 129 149 136 128 134 150 137
   160 136 136 129 130 143 135 131 133 130 143 133 128 135 130 129 163 128 136
   129 159 147 148 134 130 127 140 127 127 130 128 129 146 134 142 132 136 145
   149 137 129 135 154 130 148 169 144 134 135 131 138 129 151 135 134 133 144
   134 133 129 129 143 145 134 139 160 162 162 128 136 128 144 127 129 128 130
   144 135 129 129 133 128 152 136 129 147 131 128 155 135 129 129 143 143 170
   138 147 135 128 129 129 128 129 139 166 119 130 128 147 133 139 132 143 130
   153 131 129 129 129 135 138 129 160 152 162 128 129 130 164 135 128 129 130
   133 140 137 130 136 127 129 121 128 127 127 134 143 144 148 147 129 128 128
   139 132 128 143 137 152 140 138 135 132 135 137 140 134 158 144 159 156 140
   135 136 136 136 135 142 140 137 133 136 134 133 134 141 141 133 133 139 134
   133 137 141 134 135 169 147 167 142 136 134 29922 327 199 182 158 133 132
   136 165 134 130 137 133 136 151 136 134 132 134 128 155 134 128 131 140 158
   134 137 132 149 133 128 127 132 153 137 133 127 152 138 154 132 129 134 148
   149 146 130 130 129 147 133 129 127 152 128 128 128 127 133 133 141 133 129
   129 129 135 149 142 128 129 144 133 128 134 128 155 141 131 120 129 127 128
   146 133 131 129 127 251 155 145 136 142 135 132 129 249 133 135 127 150 129
   130 138 146 130 141 136 138 136 140 138 130 165 132 127 133 152 134 132 133
   129 133 131 129 143 137 129 123 133 129 155 143 138 151 133 114 128 146 134
   135 132 132 144 125 127 127 143 133 132 132 126 144 132 146 147 129 133 135
   142 128 125 128 127 127 131 130 134 142 134 128 129 128 145 128 141 134 146
   146 129 127 127 128 145 133 126 128 144 133 126 129 131 129 129 129 129 129
   143 141 141 140 130 133 148 137 132 131 128 129 134 130 149 133 132 146 132
   132 129 144 134 145 148 154 134 143 134 127 129 131 144 135 127 122 146 133
   128 133 149 136 129 134 137 3250 170 147 161 144 145 141 155 2110 207 160
   172 142 130 129 129 129 155 134 132 132 134 152 133 119 130 137 150 156 166
   152 131 131 128 129 130 149 131 130 131 129 128 147 128 123 128 129 135 127
   143 129 128 131 130 123 130 152 144 148 165 134 130 130 142 132 137 132 128
   149 134 129 132 146 128 133 129 127 146 133 128 132 129 132 129 131 134 127
   136 167 175 140 128 128 130 130 135 138 130 134 128 123 133 123 130 129 142
   130 130 129 132 131 133 148 130 128 128 153 131 168 150 141 131 129 124 129
   130 130 131 98 130 130 131 128 125 157 128 130 127 129 129 127 129 133 128
   134 129 154 139 144 140 148 132 127 141 129 133 128 135 129 128 128 128 127
   128 129 138 129 141 134 131 127 153 135 160 134 130 127 127 131 127 142 128
   127 127 130 106 127 129 141 135 127 132 142 135 162 155 129 127 130 128 131
   127 128 127 127 126 127 127 127 127 127 140 128 126 143 140 139 145 129 146
   127 130 128 128 134 128 129 128 128 131 127 134 129 130 133 136 127 137 138
   139 148 132 133 128 129 132 127 127 131 128 164 135 136 140 136 136 131 133
   128 148 133 147 149 135 133 128 135 132 128 127 128 127 130 129 128 134 127
   132 132 132 130 137 145 159 161 128 153 133 129 135 127 128 133 141 139 131
   134 128 128 138 127 127 127 132 145 137 142 142 141 129 128 138 127 129 128
   139 136 129 128 128 127 134 127 129 131 128 153 129 148 161 133 137 134 133
   128 127 128 130 135 127 128 128 127 127 133 132 129 137 160 134 151 158 140
   132 130 130 136 103 139 128 128 140 128 130 141 129 133 129 129 127 128 150
   140 135 146 138 128 131 129 129 130 137 129 133 130 128 128 132 129 128 128
   131 140 142 135 139 162 137 135 140 128 130 130 136 133 129 130 130 132 127
   134 131 128 130 134 130 143 146 141 151 127 132 128 128 128 134 129 128 130
   133 135 127 128 127 127 127 127 129 140 134 158 139 135 122 120 139 130 131))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 143189
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61605280 :P50-TICKS 133
 :P99-TICKS 262 :LATENCY-TICKS
 #(144 130 134 129 129 157 151 162 141 128 135 129 134 128 128 128 134 129 129
   131 128 128 132 129 137 128 131 130 150 143 161 128 130 129 130 127 128 130
   128 128 139 126 127 127 129 128 128 128 129 128 155 135 133 163 130 134 135
   141 137 140 145 147 122 134 148 129 143 138 122 133 129 148 129 132 139 143
   145 137 136 133 130 129 131 139 138 145 137 123 145 142 149 139 145 128 133
   135 128 143 155 146 136 153 129 143 148 141 133 143 141 128 128 127 136 134
   140 139 151 147 152 127 146 143 139 115 128 127 114 129 133 142 131 129 128
   134 152 134 136 136 129 129 122 122 149 138 138 150 129 165 135 133 134 152
   134 149 138 135 125 134 129 127 128 139 139 163 165 153 138 160 138 148 130
   138 139 138 136 130 130 130 139 126 135 140 134 129 143 152 141 172 151 151
   147 148 167 146 153 144 145 152 136 152 146 148 1923 141 137 131 127 117 129
   130 115 139 138 136 135 114 127 115 119 138 127 131 129 108 130 98 129 129
   128 133 129 141 129 129 150 142 163 137 122 129 128 129 139 129 121 129 129
   132 114 123 148 127 157 129 133 128 136 132 139 137 157 142 132 149 133 138
   133 140 138 140 123 136 132 138 150 133 133 127 136 135 155 142 152 136 148
   138 131 147 111 140 134 132 131 132 139 128 132 128 134 127 136 143 145 151
   146 131 129 140 132 127 135 126 128 111 127 127 127 146 108 136 129 129 139
   128 128 152 131 153 152 138 133 134 134 153 136 135 132 127 132 136 135 134
   134 125 140 140 131 155 137 166 147 142 137 130 129 130 136 130 129 131 127
   127 130 129 130 130 132 122 128 142 157 145 127 129 120 131 130 129 116 143
   128 132 149 128 129 127 128 127 128 113 128 133 130 137 140 150 154 138 130
   135 129 129 128 130 129 137 129 129 131 134 129 127 129 146 137 150 130 129
   132 134 128 128 129 128 135 129 128 128 128 129 129 122 115 128 128 127 144
   139 151 128 132 129 133 128 130 128 130 128 127 145 130 128 128 127 130 128
   129 127 128 145 140 151 130 130 128 128 130 130 128 129 137 131 170 135 129
   128 127 130 135 116 130 132 136 159 139 139 139 131 129 129 141 136 129 123
   126 138 131 129 127 132 128 129 127 129 144 135 150 129 133 134 128 128 127
   126 129 132 129 128 129 128 127 131 130 128 130 128 128 149 147 137 129 128
   137 128 127 119 130 128 127 130 127 129 128 129 129 127 130 127 126 134 140
   136 146 128 128 127 127 127 130 127 127 127 128 127 128 128 129 129 127 131
   127 128 127 160 137 161 136 127 133 128 112 128 147 129 144 132 124 130 131
   131 130 129 130 128 129 132 148 170 142 116 129 128 128 131 133 135 125 143
   140 139 134 137 135 138 128 133 129 127 132 142 132 154 127 127 128 128 127
   116 106 127 127 127 129 130 127 128 128 128 126 130 128 150 138 153 128 128
   129 126 130 144 127 134 130 127 129 129 127 131 130 126 130 127 127 131 145
   153 143 140 129 129 127 128 130 128 129 130 129 143 142 129 135 128 132 127
   127 126 128 152 133 145 135 127 117 132 131 128 129 128 129 130 127 128 126
   130 128 126 129 100 128 146 140 130 145 128 130 128 136 135 138 142 137 133
   127 130 133 133 127 127 128 128 128 129 159 141 141 133 128 132 134 128 127
   126 127 133 135 136 126 132 157 132 128 143 130 128 140 128 137 136 146 139
   126 127 135 130 129 138 138 129 127 127 161 150 146 137 141 144 159 141 148
   165 165 144 134 130 131 134 129 137 136 130 134 131 149 139 128 133 127 132
   158 145 133 149 152 141 143 136 128 142 145 137 134 134 153 128 104 128 129
   179 156 164 182 157 140 159 154 171 151 146 149 134 133 153 168 148 163 142
   134 133 137 148 145 147 140 145 148 163 142 157 147 167 173 134 147 158 145
   146 162 174 152 140 148 169 153 146 138 153 147 138 177 158 174 153 135 137
   132 133 136 151 143 155 138 169 162 137 153 150 169 134 143 136 140 155 160
   151 141 147 130 126 129 128 150 146 142 154 157 135 134 128 128 133 128 126
   133 132 129 128 130 131 133 128 129 128 129 149 135 142 128 169 141 140 134
   140 134 132 127 127 139 135 133 133 138 135 146 140 135 141 130 140 130 152
   128 129 144 135 131 138 158 185 204 140 133 137 139 227 377 262 273 246 228
   145 139 162 133 131 169 150 136 136 138 134 130 272 184 310 186 186 158 165
   151 271 241 207 131 142 137 132 161 129 127 141 136 154 132 126 300 241 286
   317 147 137 276 129 134 140 131 126 134 125 135 133 133 128 127 133))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 172710
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61546576 :P50-TICKS 133
 :P99-TICKS 172 :LATENCY-TICKS
 #(162 135 137 125 126 127 128 127 125 126 126 128 126 142 133 126 127 128 126
   141 139 128 134 130 129 128 128 129 128 129 136 129 128 128 127 128 127 129
   128 129 128 127 128 127 128 128 128 133 127 128 140 138 138 152 128 126 127
   127 126 125 131 127 126 126 132 125 126 127 125 126 32582 200 140 135 122
   134 132 132 132 131 138 131 131 132 160 155 173 157 139 135 133 133 134 131
   133 133 135 131 132 132 133 132 132 131 133 133 152 172 137 134 136 133 135
   135 137 133 139 132 133 133 132 132 132 132 132 133 133 132 149 152 157 135
   133 131 133 168 135 133 132 132 132 132 132 131 134 133 141 132 132 139 143
   164 135 132 130 133 132 130 136 131 133 131 132 130 131 132 130 131 131 131
   131 130 152 138 164 143 139 134 133 131 132 133 133 132 132 133 133 131 134
   126 132 132 133 133 145 145 150 134 133 132 134 132 132 133 133 132 142 133
   133 137 137 132 131 131 132 133 147 144 166 133 131 133 131 131 132 133 130
   130 131 132 131 130 130 132 131 131 130 131 130 148 136 163 135 132 145 136
   132 136 132 132 132 132 131 133 132 136 132 144 131 131 132 150 184 147 139
   132 132 131 131 131 132 131 133 135 131 139 130 129 130 132 131 132 130 148
   135 152 136 132 131 145 134 132 135 132 136 133 132 132 133 132 131 133 133
   132 131 153 189 138 133 140 148 136 131 161 131 133 131 131 131 131 131 131
   132 131 131 131 130 144 154 149 135 131 131 132 131 130 131 146 140 137 137
   132 130 135 131 136 131 132 131 147 144 156 132 154 136 133 132 133 132 132
   132 132 132 139 138 133 133 123 132 148 133 144 148 157 132 131 132 132 132
   134 138 133 132 131 130 141 133 132 132 132 132 131 131 146 137 161 131 132
   139 133 132 131 138 137 132 134 136 131 131 138 130 135 136 133 132 146 137
   167 136 131 131 134 131 133 131 132 132 133 132 132 132 131 133 132 140 131
   133 132 155 151 135 137 131 132 131 131 131 132 134 136 134 130 131 131 131
   130 131 131 132 133 156 145 157 134 133 132 134 133 132 132 133 133 131 133
   153 132 133 132 132 132 131 133 148 159 141 131 134 131 132 130 131 132 133
   130 134 152 132 131 131 134 131 131 133 133 143 136 157 132 131 131 133 132
   130 133 132 135 131 131 130 132 131 131 132 131 131 131 131 154 164 141 136
   141 132 133 131 131 132 132 133 151 132 132 130 131 136 122 131 134 137 132
   146 172 144 132 132 131 132 136 132 131 131 130 133 134 139 132 131 131 132
   131 132 143 148 153 135 132 132 130 133 132 151 140 133 131 131 132 133 132
   131 132 132 132 131 165 148 143 143 133 133 136 132 131 131 134 132 131 132
   132 132 132 132 139 139 133 131 155 154 164 143 137 134 134 135 135 132 133
   132 132 150 140 133 133 131 133 132 131 131 131 144 142 157 135 133 133 152
   138 131 133 137 133 131 132 132 135 131 130 130 131 133 146 138 146 148 133
   138 132 131 133 131 133 132 138 130 133 132 132 131 137 132 131 132 143 138
   135 139 131 132 134 132 133 133 132 132 149 133 131 132 140 142 134 131 131
   132 132 153 141 151 133 134 140 124 131 136 133 132 132 151 131 132 130 132
   132 135 134 130 131 148 148 145 132 133 133 133 134 137 133 134 132 131 133
   132 132 135 133 132 132 132 131 147 142 176 133 132 132 132 133 132 132 133
   131 133 130 131 133 132 131 132 151 133 132 143 137 167 130 138 130 133 132
   131 131 132 131 140 132 130 130 135 132 132 133 134 138 133 140 163 149 133
   132 133 133 132 133 132 131 132 132 132 134 139 144 137 131 133 132 141 138
   148 151 143 135 132 134 144 132 133 133 134 134 157 133 134 132 133 133 133
   132 134 138 182 142 134 133 135 132 133 132 131 133 132 131 136 131 132 132
   132 135 132 131 134 149 146 145 139 132 130 143 133 133 132 132 152 144 135
   132 132 133 132 133 133 138 156 142 166 143 139 135 144 141 139 137 137 141
   135 134 134 136 134 135 138 136 136 140 172 140 164 137 133 133 132 133 134
   132 134 134 137 134 142 141 157 140 133 138 133 133 149 162 145 132 145 143
   143 139 135 132 136 132 134 133 133 131 146 135 135 132 132 145 138 156 139
   138 137 132 132 139 136 138 133 134 135 133 136 138 138 1573 138 130 130 129
   127 128 130 128 135 128 127 129 127 129 134 149 145 140 150 138 132 132 135
   136 139 132 133 132 134 133 134 133 132 134 133 145 143 149 153 154 133 132
   132 135 131 134 134 131 133 133 133 134 132 143 131 134 134 131 131 142))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 137157
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61605936 :P50-TICKS 130
 :P99-TICKS 158 :LATENCY-TICKS
 #(138 127 130 151 134 133 133 131 131 132 132 132 132 133 132 142 140 157 133
   140 126 134 128 128 129 127 127 128 129 129 127 132 141 138 129 126 128 129
   149 136 137 132 132 132 131 134 131 126 129 129 126 127 126 128 127 129 128
   126 128 127 127 146 135 147 125 127 132 128 126 127 126 126 126 126 127 126
   127 131 126 127 127 127 127 132 144 138 160 144 130 128 127 130 132 127 128
   130 129 128 127 128 129 127 126 128 128 128 127 148 135 149 129 130 127 128
   129 132 133 133 133 129 128 128 127 133 130 131 127 127 128 129 138 135 149
   148 134 133 129 129 134 129 130 129 130 129 115 129 128 129 128 106 143 130
   136 150 142 154 128 133 132 137 135 133 123 136 132 134 153 134 137 130 128
   127 129 129 128 148 141 165 130 128 130 133 151 132 132 132 132 131 135 135
   134 133 134 132 133 129 120 128 145 140 145 139 130 128 131 131 130 128 129
   134 128 130 128 129 127 143 131 129 134 134 147 139 152 130 129 129 131 131
   128 130 130 154 130 139 132 151 136 131 128 129 128 131 141 140 163 130 130
   141 129 130 128 128 130 130 125 128 128 130 128 140 128 129 127 128 137 147
   137 152 130 130 130 135 139 128 130 134 134 130 128 129 135 130 127 127 133
   129 128 137 135 159 130 129 128 130 130 130 129 133 131 133 129 128 122 128
   128 132 130 128 128 128 148 137 157 139 129 128 128 132 134 131 131 132 133
   133 136 136 134 128 127 127 133 130 130 148 137 151 138 130 122 132 129 131
   135 134 133 133 148 136 137 136 136 140 129 154 139 149 153 134 130 127 132
   139 148 134 134 131 135 113 138 131 114 131 131 137 131 137 132 150 145 159
   131 132 117 134 127 128 128 127 129 127 129 128 128 128 131 133 134 132 133
   133 144 151 139 127 129 128 128 129 129 128 131 130 169 139 136 137 133 128
   133 129 129 129 152 142 153 143 143 129 139 132 130 128 129 128 129 129 128
   129 132 120 130 130 132 150 150 134 138 139 130 130 130 129 129 128 116 127
   129 127 127 128 131 146 129 117 127 129 129 140 141 151 173 131 129 137 129
   127 130 129 131 128 128 130 128 133 129 130 130 128 129 130 144 151 142 134
   133 133 133 132 147 137 135 134 134 138 135 128 120 129 130 129 117 140 143
   136 157 142 118 127 135 128 130 129 127 128 129 130 130 131 126 128 129 130
   129 135 129 144 133 143 152 129 130 131 130 129 129 127 127 131 128 131 129
   128 129 129 129 128 128 128 152 138 156 145 130 130 131 128 128 129 128 128
   128 129 128 129 130 130 131 147 128 132 149 137 145 157 133 131 136 135 134
   134 132 131 135 139 132 131 132 134 133 134 132 131 147 142 161 153 137 138
   140 138 131 129 129 129 131 131 129 117 129 116 130 128 131 129 129 143 151
   159 139 131 129 130 129 129 128 131 130 130 131 128 131 131 138 129 131 135
   150 150 135 150 137 131 129 133 129 128 127 130 129 129 128 129 127 128 129
   128 130 128 129 127 139 137 139 135 129 137 136 129 128 129 129 128 104 127
   134 128 128 129 129 129 128 128 142 150 137 143 129 129 128 128 129 128 130
   127 127 128 128 128 129 133 130 128 129 129 129 128 138 134 135 135 129 127
   133 128 135 138 156 135 133 129 129 136 130 129 131 128 117 130 149 135 129
   140 154 128 139 134 131 139 114 129 128 129 129 128 130 127 133 127 124 137
   128 147 132 145 155 119 132 140 128 141 129 121 124 132 127 131 134 129 129
   127 127 127 127 126 132 138 143 152 132 129 129 128 150 129 128 129 128 128
   126 121 129 128 127 134 128 128 138 141 134 153 155 131 127 128 129 114 129
   128 127 131 127 129 128 128 128 128 133 131 129 139 128 1689 149 132 129 129
   129 130 121 130 138 137 149 151 131 131 130 136 131 128 129 128 130 129 129
   130 129 128 128 130 130 129 129 141 149 151 138 129 127 129 127 128 128 127
   127 129 127 127 128 126 126 129 126 127 126 127 133 136 142 146 131 128 126
   127 127 127 130 128 129 118 127 129 127 127 127 129 127 128 126 150 135 142
   141 132 119 134 126 127 126 130 127 129 127 128 129 127 128 129 127 128 120
   131 143 145 151 149 130 117 127 129 131 128 118 130 121 120 119 122 142 121
   119 129 129 131 130 150 139 136 142 127 130 130 129 129 127 137 130 128 129
   129 129 128 128 128 129 131 127 129 144 142 158 155 127 134 136 144 131 130
   136 130 128 130 128 130 128 129 129 128 140 131 133 150 140 143 130 128 128
   131 129 118 131 129 130 127 130 136 131 128 130 130 128 129 130 146))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 136450
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61605936 :P50-TICKS 129
 :P99-TICKS 158 :LATENCY-TICKS
 #(137 142 126 136 131 126 130 128 126 129 130 127 128 128 129 128 150 143 147
   128 129 129 129 129 127 131 127 131 129 129 133 129 133 130 136 132 129 117
   153 140 161 132 135 130 128 134 130 135 130 130 140 132 130 129 131 128 130
   147 135 136 142 134 146 137 127 115 128 134 129 122 125 129 132 127 131 129
   142 133 127 134 127 128 128 144 138 144 141 142 129 128 126 131 120 128 116
   128 130 130 128 131 136 131 130 127 128 122 154 137 148 141 131 129 129 128
   129 128 128 135 129 128 130 128 136 127 129 127 132 140 129 145 142 146 131
   134 135 137 137 133 129 130 127 132 128 127 128 125 128 128 130 144 131 142
   131 140 145 142 129 128 133 150 135 140 135 149 130 130 129 128 128 127 128
   128 129 127 144 136 144 139 130 135 142 127 117 129 128 129 129 130 131 127
   129 129 128 129 128 133 156 137 126 136 128 128 123 129 128 126 122 128 129
   128 130 128 127 136 120 129 126 143 139 135 153 141 150 136 146 141 129 127
   128 140 128 137 129 126 127 135 129 128 126 128 114 129 130 145 139 148 133
   128 129 127 128 130 131 127 129 115 129 128 130 130 129 128 132 137 128 142
   135 148 134 129 129 129 129 130 129 129 129 129 131 138 130 129 129 128 122
   130 128 132 147 139 160 128 128 128 128 129 136 130 128 133 128 128 128 127
   129 127 133 128 130 130 127 141 152 138 130 117 131 128 113 130 130 129 129
   131 132 129 129 130 129 131 133 133 130 135 143 140 143 129 131 131 122 134
   128 128 130 128 136 130 128 133 129 129 127 128 130 131 139 140 155 144 129
   127 128 130 133 127 128 135 128 132 128 130 127 127 131 126 128 126 129 147
   135 139 132 130 131 126 129 133 121 130 122 128 128 129 119 132 129 122 131
   128 129 130 146 144 148 160 128 129 132 130 129 132 128 140 141 135 129 129
   154 130 131 132 134 125 151 133 128 130 135 160 148 168 127 139 142 129 134
   143 130 129 136 127 130 132 140 124 130 144 129 130 138 151 142 147 134 127
   130 129 128 128 128 132 134 130 127 128 128 128 130 129 146 142 134 138 130
   127 129 128 136 130 128 129 128 128 127 130 128 128 131 127 129 127 144 138
   145 149 129 129 126 127 129 129 127 126 133 130 129 138 134 133 132 136 128
   127 137 136 144 158 130 129 129 128 130 129 129 128 128 129 136 130 128 128
   150 126 145 128 128 143 138 145 152 127 128 130 145 126 130 127 129 129 150
   128 130 128 128 127 129 127 127 131 142 149 149 133 127 129 133 130 127 127
   126 114 129 127 129 126 129 126 133 126 129 128 121 141 139 143 157 127 128
   127 127 128 127 130 122 129 127 130 119 126 127 127 126 128 127 128 142 123
   157 128 127 134 128 128 129 130 130 129 129 130 130 129 131 127 128 130 133
   114 130 148 145 144 118 136 130 128 128 130 128 128 127 127 119 127 126 134
   129 128 129 127 127 127 139 132 151 144 129 128 128 126 126 128 144 128 129
   132 127 127 129 131 127 127 129 131 128 152 137 145 143 140 130 131 129 114
   128 131 127 131 129 128 131 131 128 128 128 129 131 147 141 1617 134 133 132
   129 128 127 130 127 127 126 130 150 142 154 127 128 129 142 130 127 128 128
   133 128 127 129 120 126 130 126 127 131 144 142 154 136 128 129 126 129 129
   128 117 129 127 112 128 127 128 126 130 148 132 130 132 150 152 147 128 129
   131 129 130 128 129 129 128 133 128 130 127 128 128 128 128 126 136 144 139
   154 132 128 127 129 130 128 128 126 130 126 128 127 131 127 127 127 127 127
   129 127 142 145 138 146 127 129 130 128 128 128 127 127 129 127 127 130 129
   127 131 131 130 129 129 163 140 135 144 127 130 128 127 127 130 126 138 127
   127 127 129 126 129 126 126 117 128 128 144 133 155 147 129 134 127 132 129
   127 129 128 128 130 128 129 126 127 127 127 129 129 134 131 136 145 165 123
   128 130 128 120 127 130 127 132 128 132 140 131 128 130 132 128 128 132 142
   137 147 140 129 127 129 127 129 132 137 163 134 128 127 127 136 127 129 130
   129 127 144 129 138 134 134 128 129 127 128 130 129 151 128 128 128 114 127
   127 127 130 127 129 129 145 132 155 138 129 128 127 128 129 128 129 126 128
   129 146 127 128 127 127 130 133 128 127 143 130 143 153 129 132 128 130 131
   128 130 128 134 129 130 131 127 131 128 129 131 128 128 149 148 132 135 129
   129 129 126 129 132 129 129 130 128 129 128 127 130 135 126 126 131 129 146
   150 167 127 128 128 128 130 127 128 133 128 129 128 128 128 127 130))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 149650 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61605904 :P50-TICKS 142 :P99-TICKS 178
 :LATENCY-TICKS
 #(181 184 169 168 169 166 164 163 163 160 143 162 148 152 177 160 178 189 185
   160 151 161 156 149 162 162 165 159 150 146 143 141 157 144 146 159 146 162
   158 141 140 138 143 144 141 141 139 139 138 141 138 137 139 132 142 142 182
   156 167 152 147 152 150 140 143 144 145 140 144 139 144 137 141 152 131 142
   127 178 170 167 147 148 147 147 142 140 125 146 147 146 143 142 143 149 141
   143 142 181 160 172 148 140 143 140 144 143 142 141 143 121 143 144 131 139
   139 143 140 127 162 162 164 132 139 138 139 142 139 140 142 139 149 150 154
   159 159 147 142 145 160 147 159 158 145 139 141 138 144 139 150 139 140 140
   137 143 144 145 144 138 139 155 147 163 158 162 166 150 149 144 144 142 140
   141 142 141 142 139 137 139 145 138 154 149 165 159 137 123 144 143 138 138
   141 143 138 148 143 144 146 141 161 148 175 159 152 163 150 147 157 149 153
   142 142 142 141 144 142 143 146 139 143 140 146 142 149 174 155 146 142 153
   148 141 156 141 138 141 135 137 139 138 146 138 137 161 149 161 155 139 145
   148 138 138 139 138 142 135 146 144 144 146 145 146 145 148 155 165 181 149
   145 147 152 145 133 143 141 140 142 136 137 139 140 140 145 144 162 161 153
   152 145 147 142 142 149 147 145 150 155 153 142 148 164 150 146 144 147 158
   149 171 156 144 144 143 144 136 147 162 148 148 145 129 147 138 146 146 149
   164 168 155 142 143 145 139 147 145 143 145 145 144 143 142 143 144 147 145
   145 166 154 155 142 128 124 146 147 143 146 145 148 143 147 144 154 146 147
   144 144 148 147 167 154 153 149 144 144 151 144 151 145 137 148 146 143 142
   142 147 143 144 160 156 164 147 145 166 159 151 138 151 151 143 143 144 139
   145 146 143 170 144 157 149 161 142 142 131 139 143 141 141 139 145 147 149
   139 138 139 137 140 136 149 164 173 158 148 151 146 153 165 147 145 149 141
   141 138 138 138 144 144 142 141 167 149 169 138 159 152 155 146 136 138 138
   138 139 137 140 137 135 164 138 156 155 145 185 142 136 140 139 139 137 140
   140 138 149 136 140 142 137 143 153 156 145 156 137 157 150 138 142 144 144
   142 138 227 2293 155 148 150 142 133 147 142 138 135 144 160 146 141 139 153
   145 157 160 138 141 138 140 146 143 137 147 139 140 152 146 138 142 141 139
   140 165 156 163 140 140 141 140 142 140 139 141 144 141 139 150 139 140 141
   141 140 149 153 144 161 159 148 142 139 145 137 142 139 143 147 141 149 139
   138 139 146 139 139 146 166 160 134 142 138 140 138 150 135 139 140 140 136
   138 139 140 137 136 139 140 159 154 172 146 147 164 154 138 140 138 140 136
   140 137 142 121 142 144 154 144 149 144 156 163 148 130 143 146 143 139 144
   142 148 147 143 139 142 139 139 137 145 150 148 155 153 141 145 141 147 146
   142 144 154 143 146 145 141 145 141 142 147 146 154 161 150 143 142 139 140
   137 139 142 140 139 144 139 139 141 144 146 139 142 142 158 147 149 159 138
   144 144 140 169 141 137 144 150 135 142 138 155 141 138 136 137 144 144 160
   155 151 149 141 144 144 141 144 146 144 144 140 140 141 146 139 141 167 151
   172 148 140 140 141 139 137 140 139 141 142 137 138 137 155 145 145 137 141
   151 146 171 140 133 141 140 139 138 139 144 138 130 127 141 138 141 136 125
   139 139 140 144 144 154 141 140 142 139 139 139 142 139 142 141 137 139 138
   139 138 137 151 146 155 154 149 136 142 140 138 141 138 138 138 137 138 153
   144 139 141 138 141 142 143 163 150 172 147 144 145 140 142 151 142 143 143
   136 143 143 138 137 143 138 143 146 153 152 148 136 140 135 134 134 134 135
   133 131 131 134 133 133 131 136 142 135 132 156 142 158 136 140 137 136 136
   132 131 133 132 135 145 131 133 134 131 134 137 145 133 149 136 146 139 136
   134 158 140 137 135 134 139 136 135 136 132 131 132 133 131 132 133 143 152
   157 139 138 136 134 124 131 138 138 132 131 139 132 132 132 144 131 136 137
   133 154 143 159 136 133 136 132 137 138 138 133 149 134 131 132 132 130 130
   130 130 133 130 139 152 141 136 132 141 131 131 132 131 133 132 131 132 131
   132 131 131 131 135 130 133 151 145 153 137 131 131 131 131 131 130 133 129
   131 133 132 131 150 132 132 135 132 132 132 137 143 141 152 136 130 137 135
   132 139 134 132 125 131 134 131 134 133 131 133 132 134 142 141 160 142 134
   130 137 134 134 134 134 139 114 128 128 133 131 132 131 133 140 133))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 139942 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61605024 :P50-TICKS 133 :P99-TICKS 162
 :LATENCY-TICKS
 #(135 134 132 133 124 137 134 133 135 133 131 131 136 133 132 134 157 153 149
   132 137 138 133 134 138 131 131 136 133 132 133 131 132 134 132 135 132 133
   138 142 156 140 140 132 132 131 133 131 132 133 126 131 136 131 133 132 153
   132 132 132 161 136 138 153 123 135 136 135 132 136 132 132 150 130 132 131
   131 131 133 130 131 131 148 136 157 132 138 131 136 132 132 133 132 131 134
   138 133 132 129 133 133 136 131 131 151 139 145 140 132 131 132 132 132 132
   131 131 133 131 133 132 131 139 132 132 131 133 134 155 134 155 129 133 131
   131 130 132 131 144 136 130 131 131 130 130 131 131 132 132 131 143 141 150
   137 135 129 131 133 131 131 132 132 125 133 134 123 131 131 134 132 134 152
   133 147 140 147 131 135 150 138 132 134 125 135 133 134 133 139 131 132 134
   134 130 130 133 153 140 154 115 120 135 138 137 133 132 129 140 133 133 136
   132 133 132 131 133 133 134 138 134 151 135 139 133 135 120 130 132 135 135
   134 136 137 124 131 147 138 143 131 132 153 271 144 134 132 136 135 134 133
   131 121 133 148 133 134 133 132 131 136 131 132 138 143 146 149 131 132 132
   134 136 132 132 132 131 132 133 135 131 133 131 131 131 130 131 158 115 145
   134 131 116 132 132 132 130 134 130 140 143 137 138 131 134 134 131 137 146
   147 147 149 133 137 129 130 131 138 146 138 146 131 133 132 142 130 138 135
   133 130 131 135 138 158 140 114 131 132 133 134 133 131 130 131 119 138 151
   131 134 131 136 134 137 138 147 139 172 137 139 137 133 129 130 133 133 135
   134 132 145 146 1615 133 133 130 139 136 132 132 131 133 130 130 133 130 134
   130 133 148 139 151 154 135 135 131 134 137 131 131 135 131 130 133 132 131
   130 132 134 138 134 143 142 147 135 131 130 134 134 126 133 133 134 133 127
   152 133 132 115 122 147 150 138 142 139 154 137 136 132 132 145 142 146 142
   137 126 126 119 133 133 133 129 145 143 158 152 132 147 130 130 131 133 118
   117 139 121 121 135 135 134 126 138 136 141 135 137 132 149 143 157 139 135
   137 135 137 138 133 140 138 136 131 135 137 138 148 144 142 133 135 149 144
   158 139 129 132 127 114 133 133 134 132 129 131 132 131 132 134 130 131 147
   131 149 143 141 151 130 130 140 132 129 130 136 130 134 134 138 159 139 133
   132 137 134 132 143 139 132 134 124 132 125 131 147 144 138 137 131 130 132
   148 137 131 135 132 129 131 149 145 174 131 129 130 130 131 130 131 130 130
   134 132 132 133 130 133 129 137 130 132 132 145 131 153 131 132 116 131 137
   132 131 131 132 135 132 130 135 126 131 132 121 131 135 149 137 135 148 135
   125 134 136 134 132 126 119 133 135 128 135 142 132 131 132 132 129 126 156
   145 140 142 124 151 138 133 133 133 135 135 136 133 125 134 139 127 135 151
   142 134 149 159 140 139 134 141 151 143 133 135 139 135 135 134 137 133 139
   131 131 130 133 150 140 140 140 132 141 131 135 130 131 136 168 133 140 131
   132 134 131 132 132 133 157 145 151 139 144 111 150 118 127 132 107 137 132
   127 134 135 132 136 133 133 136 167 137 131 147 177 162 130 131 131 135 134
   140 133 134 124 138 135 134 135 132 130 123 131 133 143 139 146 169 137 135
   132 131 133 134 134 134 133 132 132 136 131 134 132 130 138 131 150 145 154
   151 135 137 133 134 134 136 133 148 133 133 136 136 130 132 132 132 130 131
   149 140 161 149 135 131 131 147 135 133 131 132 131 130 132 132 134 139 132
   130 130 131 145 133 154 153 126 131 132 133 133 131 134 132 134 132 132 132
   130 131 138 132 132 133 131 137 143 154 147 137 135 134 130 140 130 131 153
   134 131 132 130 129 131 135 131 133 132 155 160 144 135 137 145 137 132 137
   139 130 131 134 131 131 130 131 135 131 126 113 118 157 149 151 147 133 134
   135 132 132 132 129 136 135 133 120 130 137 133 132 133 120 116 129 142 155
   143 127 132 114 123 133 132 130 138 125 133 131 132 129 121 122 136 122 132
   130 152 144 154 149 137 131 126 133 131 131 102 118 133 125 131 121 132 112
   131 132 132 147 132 155 154 162 132 133 132 133 131 136 123 122 132 130 131
   137 132 130 130 131 130 131 131 134 138 149 142 141 130 130 131 132 132 129
   130 133 132 131 131 134 131 129 131 129 131 133 154 149 167 131 132 131 131
   132 130 133 132 131 135 130 131 131 130 132 131 149 133 132 151 138 159 153
   132 137 115 115 133 132 132 133 136 135 130 130 132 126 130 140 130))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 139546 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61605696 :P50-TICKS 132 :P99-TICKS 161
 :LATENCY-TICKS
 #(130 140 138 137 120 131 114 134 135 134 130 130 114 113 130 131 135 132 168
   155 143 133 133 131 133 132 132 133 131 132 132 132 132 130 132 134 131 132
   132 131 148 144 153 145 131 138 135 130 132 132 131 133 131 133 133 130 132
   130 117 130 147 136 131 138 154 142 155 138 134 130 129 115 132 129 133 133
   137 130 129 132 131 133 133 141 154 138 139 113 130 132 130 132 132 131 134
   133 130 131 132 130 135 131 131 131 131 130 132 148 155 159 133 132 133 133
   133 134 136 131 133 130 115 131 132 131 132 131 131 130 134 147 137 139 143
   140 133 134 133 131 133 131 132 129 130 130 130 132 130 137 136 145 135 142
   137 141 137 130 134 131 133 132 137 131 132 132 132 142 138 133 134 132 130
   135 130 132 148 147 160 135 135 131 137 144 131 131 136 133 133 118 131 129
   132 123 129 124 121 135 136 147 147 152 130 135 133 134 134 137 134 135 130
   135 132 130 131 130 157 143 144 139 153 141 159 136 136 129 134 137 136 136
   131 135 140 129 131 1599 136 147 136 143 132 132 133 136 134 134 134 134 132
   137 136 132 136 132 151 141 133 150 132 138 131 134 133 135 142 140 139 140
   134 141 137 132 132 135 133 156 146 139 141 131 132 135 132 132 131 137 139
   134 132 135 136 135 135 131 130 133 130 150 138 163 148 137 136 133 132 132
   131 133 131 133 132 133 130 131 131 132 133 131 137 133 149 160 141 105 132
   124 131 105 129 131 130 130 130 130 131 133 132 130 131 130 133 130 148 137
   148 139 132 130 143 134 139 152 136 140 138 130 129 129 128 129 129 138 134
   134 148 136 142 162 139 131 139 140 130 131 131 134 130 135 145 128 135 131
   130 140 137 131 134 149 145 143 134 131 135 132 137 137 130 133 133 139 142
   131 132 131 131 128 132 136 144 140 147 145 135 131 131 136 134 129 131 135
   130 135 132 133 129 131 138 131 133 130 130 142 147 141 146 125 131 131 132
   129 132 129 134 131 131 133 132 132 132 141 135 120 129 145 138 150 146 128
   132 132 130 132 134 129 125 137 129 130 133 143 133 133 131 130 131 138 160
   152 147 131 131 136 130 135 129 130 130 133 136 131 146 135 128 130 140 131
   133 141 144 141 145 172 135 156 144 135 135 129 134 131 131 130 132 141 132
   134 134 127 129 131 167 149 160 138 134 136 129 129 129 144 128 130 133 129
   132 136 129 131 128 130 132 141 154 161 157 147 128 131 135 130 133 138 135
   130 121 129 129 130 134 149 140 130 129 149 142 142 157 142 135 131 135 137
   110 134 121 152 140 130 127 131 131 134 132 129 130 130 158 140 168 138 131
   136 140 128 129 128 131 130 129 129 137 146 151 143 136 130 130 155 138 140
   145 159 136 131 132 131 129 132 129 129 130 130 129 130 150 131 131 129 131
   129 155 139 142 140 133 128 136 130 130 128 149 139 130 131 131 132 131 124
   128 130 111 130 135 135 145 155 135 134 129 134 129 129 130 129 131 129 129
   129 130 130 135 132 131 138 132 145 139 168 154 130 135 129 134 130 131 130
   129 130 136 138 132 131 135 130 128 128 130 145 136 138 153 131 132 130 132
   129 135 130 129 128 114 130 131 130 130 131 130 132 133 130 139 143 148 148
   135 134 132 132 132 118 136 129 131 133 130 130 131 129 130 147 132 129 155
   140 153 149 130 129 129 118 130 131 133 131 132 135 131 129 131 131 130 131
   129 128 139 136 144 152 132 135 132 135 133 135 132 133 132 112 120 153 133
   133 136 133 126 123 130 149 145 173 122 131 130 133 129 129 131 129 113 130
   131 128 129 133 130 137 131 133 130 136 146 147 142 150 131 130 131 131 129
   130 130 137 131 128 129 131 129 132 130 129 129 132 144 137 151 152 133 139
   138 132 131 132 134 130 131 130 130 133 130 129 133 131 131 133 148 137 156
   143 140 138 148 143 130 130 133 129 129 133 129 132 136 130 129 129 129 110
   130 152 138 134 144 131 133 134 131 131 131 131 129 380 130 129 130 132 134
   130 131 143 136 151 143 131 129 144 131 135 134 135 134 124 133 132 128 131
   130 133 128 131 132 132 134 142 151 159 130 130 131 133 126 130 129 130 129
   130 147 133 130 129 129 131 129 129 150 143 151 134 131 133 149 160 131 137
   130 130 128 130 130 130 129 130 129 129 128 131 147 136 159 148 132 131 130
   135 132 130 128 130 130 130 130 130 130 130 139 131 132 129 140 148 140 155
   136 130 110 130 129 129 135 135 129 154 132 135 132 128 131 130 127 130 121
   151 131 147 156 129 131 136 145 135 145 131 131 130 131 131 110 129))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 144702 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61545808 :P50-TICKS 131 :P99-TICKS 166
 :LATENCY-TICKS
 #(146 146 162 125 126 133 132 130 131 117 130 131 129 132 132 131 130 130 131
   130 132 132 150 149 148 129 116 132 130 131 135 115 130 128 111 128 131 129
   128 130 121 129 131 129 110 144 146 161 133 131 129 131 130 129 131 129 129
   131 129 129 108 130 131 132 135 122 133 138 136 150 152 131 130 133 130 129
   128 130 129 130 140 129 131 129 128 128 129 130 128 129 129 130 147 141 142
   141 131 134 132 117 130 1622 140 143 164 131 131 130 132 128 129 132 131 129
   133 130 130 129 130 132 130 130 131 129 156 144 161 130 130 131 130 130 131
   130 133 137 129 129 128 130 130 130 130 130 130 129 130 146 149 154 142 128
   131 131 131 130 131 131 133 130 132 130 132 130 129 129 129 129 134 136 140
   149 158 132 130 129 132 131 132 135 129 131 131 142 143 125 129 129 129 128
   129 154 139 151 148 130 131 130 130 129 133 131 128 129 130 130 130 129 130
   135 132 129 121 128 149 146 159 139 129 130 129 135 137 148 134 133 129 139
   128 129 129 130 129 140 138 129 150 153 151 137 132 128 131 130 129 132 134
   132 129 132 132 129 130 130 128 131 129 129 147 138 154 140 131 132 129 130
   135 130 130 130 129 130 140 130 135 129 132 131 131 130 136 151 164 142 140
   132 145 130 131 142 131 131 131 131 130 129 131 129 133 141 130 118 133 150
   115 146 139 131 129 129 131 129 130 128 130 133 130 128 130 131 129 128 131
   130 128 132 142 148 134 130 130 129 138 130 130 129 130 130 130 131 130 129
   130 131 129 131 129 129 130 152 147 143 130 129 129 129 129 130 130 131 129
   129 135 129 131 135 130 130 131 129 128 150 137 147 137 130 131 130 159 137
   137 132 132 130 129 129 121 143 134 130 132 132 122 133 146 137 160 133 131
   135 130 130 130 129 129 130 130 122 130 131 129 129 131 136 130 133 144 139
   152 138 134 130 132 130 130 129 131 131 128 141 130 130 134 129 130 133 130
   130 134 153 136 150 139 141 136 117 131 134 129 131 131 130 130 130 131 146
   131 139 138 133 141 168 163 3562 210 148 419 136 149 138 134 136 154 148 135
   135 142 139 141 130 133 139 131 135 136 135 136 145 137 147 161 140 134 138
   135 141 156 119 142 142 132 128 142 134 137 134 143 137 139 138 139 147 154
   153 144 135 138 148 137 148 134 138 141 129 155 150 145 133 141 164 135 131
   134 132 140 140 145 139 147 139 139 131 136 131 132 137 133 135 156 148 136
   135 129 136 144 166 137 155 152 138 130 131 131 130 133 132 133 140 137 140
   137 137 140 136 130 130 130 144 135 151 158 144 136 131 134 163 143 146 132
   130 121 137 130 133 142 140 136 131 131 146 153 175 154 131 148 130 132 131
   130 130 130 129 129 128 120 130 130 144 145 137 135 141 143 166 131 129 131
   130 136 131 131 132 130 129 148 151 145 129 130 136 126 137 147 135 145 144
   152 136 130 137 133 130 130 130 136 133 129 129 135 137 129 129 137 131 178
   137 142 144 134 137 130 134 101 129 129 118 130 136 128 132 147 131 129 132
   129 131 130 145 135 153 143 146 131 130 129 132 132 136 129 129 128 131 130
   128 128 130 131 131 130 131 142 149 154 134 130 131 129 129 130 130 129 122
   129 130 131 129 129 129 128 129 136 135 145 139 159 145 131 132 130 129 130
   128 133 126 128 131 133 121 130 121 134 132 136 131 137 137 136 145 145 132
   133 130 130 138 132 130 132 132 132 131 137 129 134 129 128 133 133 152 144
   149 155 136 131 130 132 130 130 131 130 131 132 132 133 131 132 131 138 132
   131 136 147 169 160 134 132 130 130 131 131 137 132 130 132 129 132 132 130
   130 130 117 130 129 146 152 147 152 118 122 139 136 139 136 129 130 128 130
   129 132 131 130 133 131 136 131 159 138 147 161 130 131 133 132 133 134 132
   133 133 138 131 136 133 134 128 134 131 120 150 143 149 152 119 135 134 132
   131 131 132 138 132 130 134 132 131 130 129 131 132 131 130 148 156 148 134
   146 129 131 131 130 130 110 132 128 129 144 134 136 130 130 130 129 135 144
   145 155 137 121 131 131 129 130 130 128 129 130 130 129 143 132 128 130 129
   130 137 148 141 147 161 131 132 130 131 129 148 130 132 130 132 125 144 131
   131 131 134 134 133 134 150 140 160 142 133 135 134 138 133 129 131 131 129
   133 137 130 129 129 130 136 131 131 144 139 150 157 130 129 131 134 132 130
   129 131 131 145 135 131 1599 143 161 139 153 142 137 130 131 137 137 143 137
   145 131 134 158 154 157 162 137 135 130 135 130 103 131 136 132 131))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 1 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 139112 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61605168 :P50-TICKS 132 :P99-TICKS 161
 :LATENCY-TICKS
 #(136 130 161 136 158 150 130 131 130 130 118 112 115 131 136 134 131 129 135
   130 130 129 133 131 131 149 155 162 134 134 146 130 130 131 131 131 130 128
   132 132 122 131 131 129 126 132 130 137 149 141 152 170 131 135 130 132 130
   130 129 119 129 129 129 142 136 145 130 130 129 130 134 147 150 147 130 130
   129 130 130 129 134 130 131 133 130 130 130 129 132 131 131 131 156 134 147
   136 138 141 141 140 132 131 132 131 131 131 131 132 131 133 129 119 151 134
   137 137 153 143 129 131 134 129 131 133 129 132 130 134 147 132 133 130 118
   131 102 119 134 144 138 150 158 131 131 133 131 143 140 136 130 121 131 137
   129 129 129 138 118 134 133 149 147 151 146 136 133 130 130 132 131 133 133
   130 130 132 131 132 133 138 136 129 131 143 149 137 152 146 131 132 130 131
   138 131 135 129 130 130 131 130 130 131 130 130 130 154 140 148 159 118 140
   125 115 131 132 134 132 135 132 132 137 150 135 131 127 131 128 141 139 155
   152 136 128 130 131 133 130 132 130 129 131 131 152 152 134 129 130 128 130
   130 137 135 135 157 132 132 133 132 137 155 132 131 130 122 131 133 130 130
   131 129 132 132 147 143 155 142 141 128 129 135 135 130 130 131 130 130 125
   131 135 131 133 132 138 132 137 146 150 144 137 128 129 130 129 130 131 129
   133 131 137 116 130 131 130 132 133 132 135 139 140 145 147 138 131 134 135
   128 134 136 130 139 132 130 132 136 137 131 137 135 130 152 137 157 160 132
   136 134 130 130 116 119 129 132 134 129 130 129 136 138 135 129 130 128 141
   136 150 157 131 130 131 138 130 130 132 131 137 130 129 129 128 130 130 130
   129 130 150 141 153 155 137 135 153 133 138 137 130 129 132 132 134 137 134
   130 131 130 131 135 168 139 157 144 138 133 114 128 136 130 134 130 134 118
   130 130 139 130 129 129 131 130 131 140 150 151 131 129 130 130 131 131 130
   138 130 131 130 134 131 121 131 116 132 131 132 156 148 156 143 139 132 130
   133 137 133 129 131 133 131 132 130 133 130 130 132 131 149 156 150 142 132
   129 132 131 131 128 130 130 129 129 130 133 132 129 130 131 131 130 129 133
   129 160 145 151 152 133 126 130 136 134 130 131 131 131 127 132 133 133 132
   135 130 135 150 157 155 135 132 134 129 126 131 132 131 130 133 129 131 130
   134 131 129 139 136 131 144 149 142 141 130 132 132 130 131 128 132 146 140
   139 132 131 131 130 132 130 122 140 168 146 151 143 132 131 130 138 128 130
   132 119 131 131 110 134 135 139 135 140 131 129 132 143 159 150 132 143 132
   137 148 139 139 134 131 133 132 132 131 130 131 130 132 117 131 144 148 147
   151 142 134 132 130 130 122 136 153 137 130 128 144 144 140 134 134 130 142
   139 142 135 134 121 138 149 131 119 134 142 143 151 136 129 133 133 121 131
   129 134 133 149 149 178 132 112 130 134 130 135 131 130 132 132 129 134 139
   138 130 131 132 132 129 146 140 148 152 129 131 129 131 130 135 117 129 119
   129 132 129 129 131 135 132 132 133 147 134 143 155 147 136 134 131 132 131
   131 130 132 131 130 129 135 129 132 130 132 133 131 149 137 136 148 130 132
   130 129 130 129 129 129 130 131 142 129 134 130 128 130 129 130 146 142 146
   140 132 129 131 132 148 131 136 131 132 129 130 129 132 130 128 132 129 131
   130 139 140 162 165 130 134 132 118 133 132 130 132 131 130 130 131 130 130
   132 131 112 129 130 147 150 149 140 130 132 130 121 132 151 130 123 135 132
   132 114 132 133 118 114 122 119 150 138 152 152 136 131 140 131 132 131 130
   134 131 130 132 135 136 119 115 135 135 130 149 144 141 150 129 137 134 131
   130 136 135 129 130 133 131 129 129 151 132 131 130 130 130 147 143 148 150
   133 132 130 132 129 134 145 1536 140 145 170 144 142 138 134 135 133 131 131
   139 149 150 134 138 130 135 133 131 138 143 139 143 151 130 135 131 124 134
   146 140 139 133 131 130 148 136 135 132 135 134 132 148 153 154 139 132 130
   129 130 129 136 128 124 132 131 130 129 130 129 130 129 107 130 128 140 137
   149 138 131 131 118 130 134 132 130 119 132 131 134 133 135 136 146 149 131
   136 130 121 161 150 135 153 131 137 133 131 132 129 119 152 132 130 133 142
   134 133 129 130 146 137 141 154 131 133 130 138 136 141 118 130 121 130 130
   130 131 131 132 130 111 126 134 148 147 162 135 131 131 124 129 132 129 132
   130 133 130 128 131 129 131 137 130 135 124 139 152 138 147 145 134))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 152365 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61606160 :P50-TICKS 147 :P99-TICKS 163
 :LATENCY-TICKS
 #(157 143 164 148 136 154 150 152 162 151 150 148 152 148 144 142 144 143 153
   147 139 147 146 147 159 150 156 147 155 142 148 157 145 157 147 144 151 154
   145 149 153 159 149 157 149 151 151 159 150 149 148 145 148 148 146 137 145
   151 147 154 160 149 150 146 145 150 146 144 160 163 152 144 145 148 145 154
   148 147 145 147 162 147 147 148 144 146 139 144 144 148 148 146 148 158 147
   141 145 144 147 146 154 148 149 148 141 147 147 142 145 146 145 146 143 145
   147 144 158 154 144 156 152 156 149 149 148 157 155 148 142 149 139 144 144
   147 148 147 141 153 147 144 148 154 144 145 145 149 147 146 145 146 146 161
   163 157 162 147 149 154 156 147 145 151 145 147 150 150 146 149 148 146 145
   146 145 148 137 155 147 146 146 145 147 146 162 149 169 149 153 148 152 146
   150 146 154 148 147 145 147 148 148 145 145 146 149 147 143 146 149 148 137
   129 169 150 149 152 147 146 146 155 148 146 139 147 146 156 150 147 143 144
   151 143 141 145 140 147 148 145 148 160 152 146 144 148 145 148 144 139 145
   154 143 147 158 142 152 146 150 146 148 143 151 145 144 162 146 146 155 151
   158 147 146 149 149 146 139 148 147 144 146 152 147 149 153 151 150 140 145
   147 154 138 146 133 147 148 153 147 144 145 129 146 144 141 146 155 147 151
   146 148 147 145 150 148 139 156 146 159 146 144 149 148 136 147 145 150 146
   152 152 146 145 154 144 152 149 144 146 156 146 145 137 146 140 143 151 154
   149 147 142 159 150 157 132 150 146 153 141 148 149 145 150 149 142 145 137
   153 150 140 147 161 147 144 146 147 146 144 138 147 144 143 144 144 155 147
   146 146 145 136 154 145 137 153 135 146 152 140 143 151 143 143 139 146 145
   154 148 150 146 150 144 145 160 151 145 148 148 155 155 150 146 156 147 139
   152 145 147 141 152 151 151 147 147 147 160 151 147 148 139 147 152 148 153
   149 139 156 149 142 145 145 147 149 145 147 163 150 142 150 146 142 151 150
   148 147 150 146 147 159 146 142 154 152 151 162 146 148 146 146 142 150 143
   147 151 157 146 145 144 148 139 144 146 140 145 153 145 152 140 143 149 148
   152 151 148 148 146 143 145 139 160 143 136 155 153 149 148 148 152 157 139
   151 153 140 146 160 145 154 139 138 151 147 145 148 142 150 145 144 147 147
   144 148 149 146 146 149 156 146 148 147 147 143 146 148 146 152 147 147 147
   149 144 160 151 147 146 148 153 150 149 147 147 145 145 156 137 148 144 147
   148 150 144 153 146 145 145 147 147 145 154 147 147 149 145 145 147 145 146
   137 144 145 145 154 140 154 150 151 146 147 143 151 159 149 157 152 145 155
   146 146 147 144 145 145 151 148 147 151 159 147 167 152 148 150 151 153 135
   149 170 140 158 150 152 161 162 146 144 148 148 1885 140 151 148 146 139 154
   150 148 142 156 148 150 148 148 146 147 147 144 156 145 156 147 154 145 145
   146 132 143 136 146 116 157 146 155 149 148 149 141 147 147 146 147 149 151
   145 146 151 147 147 148 148 145 148 150 148 150 145 146 147 136 144 146 153
   150 147 153 150 151 149 146 152 148 148 155 150 146 147 146 147 146 144 146
   154 154 148 148 145 149 157 154 153 153 150 158 160 153 153 155 149 146 148
   149 155 172 167 120 156 146 149 149 149 159 151 148 173 159 150 151 152 153
   147 149 156 150 156 157 151 146 150 153 151 152 148 150 146 145 145 145 146
   144 148 147 147 146 145 145 148 154 149 147 146 145 137 146 145 159 160 146
   146 148 144 147 150 147 146 152 143 141 140 141 165 145 143 142 144 143 163
   141 144 140 141 141 141 140 146 146 145 141 142 143 151 146 137 142 140 147
   142 140 137 139 141 144 142 136 149 152 143 145 142 140 142 147 160 145 152
   142 142 162 141 144 139 145 147 151 146 153 142 134 145 141 141 142 141 141
   142 142 141 142 143 137 140 152 151 146 141 143 134 143 145 141 142 138 143
   148 149 142 147 143 143 151 142 143 142 141 140 139 133 138 140 155 154 140
   143 144 145 138 142 143 155 145 129 143 132 139 132 141 135 126 149 145 141
   141 141 139 142 140 148 144 145 136 143 151 141 155 156 141 142 138 141 138
   141 154 140 144 142 142 135 141 137 140 140 142 160 144 149 139 141 143 138
   141 144 140 142 140 139 155 144 153 141 141 150 143 141 142 143 149 138 141
   142 141 153 151 138 145 144 152 141 154 141 141 117 144 143 140 141 141 141
   152 151 141 142 143 155 143 139 140 141 141 151 136 149 140 148 142))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 154408 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61606352 :P50-TICKS 145 :P99-TICKS 212
 :LATENCY-TICKS
 #(159 148 144 142 145 149 144 160 146 159 151 178 143 149 150 163 156 138 145
   154 144 264 184 148 140 144 249 205 142 146 138 144 142 145 160 171 165 145
   147 155 143 158 143 143 144 144 161 152 150 149 173 187 219 172 149 163 141
   145 145 146 143 157 139 147 162 172 144 155 149 162 152 141 149 157 154 151
   166 143 154 159 147 148 148 147 139 161 143 153 165 160 130 146 144 147 161
   148 140 146 167 150 144 150 155 197 138 167 144 148 158 144 145 148 141 147
   135 140 133 163 151 159 146 171 146 141 150 147 217 203 146 142 150 142 150
   147 154 143 144 150 149 173 157 152 164 151 156 161 153 149 165 147 137 174
   163 224 158 147 147 165 144 142 140 144 145 143 140 209 137 147 140 161 140
   140 149 148 156 172 138 143 143 161 146 150 136 147 134 142 143 179 174 150
   149 157 141 140 144 151 165 146 149 156 195 136 156 143 142 142 155 142 138
   144 141 148 146 151 165 146 149 156 177 153 151 141 169 212 148 141 145 145
   144 151 137 142 150 143 149 151 167 141 143 150 137 147 143 137 167 143 147
   141 137 207 141 151 149 153 146 148 142 150 153 147 145 166 148 142 147 166
   161 145 134 146 164 188 142 144 144 143 152 149 145 144 144 144 143 149 162
   146 159 145 141 153 142 141 142 142 141 141 143 141 144 138 142 153 146 145
   134 142 143 139 143 149 144 147 140 143 150 140 146 143 142 141 151 144 143
   136 142 144 141 155 144 143 142 141 142 155 148 141 142 156 144 142 141 145
   140 144 157 151 155 140 142 157 142 143 145 142 151 147 144 150 143 155 155
   138 143 144 140 153 142 144 140 144 161 142 144 140 158 126 153 166 142 161
   144 141 164 167 138 150 148 140 142 162 154 141 155 141 142 141 140 143 141
   140 146 159 141 147 144 150 146 145 142 170 147 145 155 172 162 142 151 145
   164 146 143 143 139 134 138 146 134 163 144 144 146 164 159 153 143 145 148
   221 171 168 156 153 165 139 144 142 139 142 139 156 149 138 152 154 154 143
   142 143 147 141 146 144 152 147 148 148 168 168 142 142 154 143 152 148 140
   142 145 142 142 144 160 144 144 140 157 154 162 140 146 152 180 154 144 144
   151 141 139 164 144 149 142 146 142 133 151 142 153 1484 142 163 143 148 141
   183 147 144 185 143 141 147 143 168 175 146 142 142 141 143 162 162 158 145
   143 158 142 141 142 144 140 141 156 149 175 159 143 143 143 139 150 143 142
   157 147 156 154 171 136 143 137 149 147 177 143 145 143 143 135 142 147 228
   149 156 145 153 142 134 142 157 144 150 138 215 144 141 140 155 143 160 146
   153 142 145 148 157 164 155 147 152 163 170 156 141 143 142 148 157 165 145
   142 135 147 134 142 142 141 141 149 144 167 158 158 146 142 142 137 141 154
   174 148 142 157 135 144 135 145 168 170 146 143 141 148 156 147 152 157 141
   140 142 141 158 143 162 141 158 137 176 160 143 141 143 141 139 144 148 193
   151 154 179 153 150 161 157 180 187 151 143 145 141 143 140 168 145 144 153
   163 144 144 160 158 141 144 187 157 146 153 145 141 158 153 142 168 172 158
   142 162 149 156 155 150 160 140 143 147 144 144 141 161 155 140 156 148 150
   142 141 145 161 141 158 137 192 165 139 135 140 142 141 158 139 174 142 149
   165 140 159 147 141 164 157 141 159 148 140 141 140 151 157 146 154 145 157
   140 147 161 143 135 149 138 212 139 143 145 140 138 145 144 160 138 147 161
   144 143 135 144 148 168 152 141 150 146 154 144 144 153 143 144 145 146 151
   139 143 170 146 145 174 156 151 143 143 140 154 138 139 141 158 144 152 172
   141 154 156 171 168 144 145 141 150 140 141 142 137 159 145 145 147 135 141
   149 151 151 147 139 139 144 139 157 142 145 162 145 160 155 180 170 145 146
   137 141 142 134 143 155 150 143 154 157 148 146 151 144 205 248 142 143 141
   144 146 139 142 142 141 139 135 140 140 142 148 156 133 139 153 144 140 137
   144 140 147 141 143 143 146 134 144 137 141 138 137 144 151 141 142 143 152
   143 143 140 144 142 145 141 141 152 146 136 140 141 138 139 140 139 141 141
   141 136 146 140 152 142 143 142 141 140 156 145 140 139 141 148 142 145 136
   141 141 147 142 140 142 142 143 141 144 139 140 154 135 144 141 149 141 146
   144 158 140 149 134 143 133 149 141 142 140 140 154 143 141 141 138 140 151
   140 141 142 148 147 146 140 141 140 148 143 163 142 148 153 140 148 142 143
   146 139 142 153 170 154 146 152 154 155 159 152 161 161 157 149 158))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 150544 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61606544 :P50-TICKS 136 :P99-TICKS 227
 :LATENCY-TICKS
 #(140 155 142 142 151 143 142 140 140 152 144 139 157 143 151 142 133 146 142
   142 139 147 137 155 140 144 143 149 144 141 140 140 153 145 145 141 147 143
   160 142 144 148 137 156 149 149 145 140 142 155 134 141 143 145 150 145 157
   142 151 140 143 141 141 141 146 142 139 141 150 162 154 142 143 146 143 142
   141 143 141 141 139 148 141 141 140 145 142 141 140 142 141 140 149 142 141
   141 140 142 144 140 145 142 164 156 140 143 142 140 142 146 145 144 141 142
   141 148 141 146 144 156 163 159 163 146 146 209 143 149 147 154 168 162 154
   160 172 158 156 157 158 171 152 161 155 178 152 150 155 144 163 150 147 154
   144 156 142 141 141 143 143 146 154 144 145 140 142 142 141 140 141 227 222
   220 221 222 221 221 220 221 222 225 223 225 224 223 220 222 225 227 233 230
   227 222 220 220 222 219 221 223 228 218 224 224 221 220 223 221 220 218 222
   221 221 219 219 223 220 221 220 224 228 220 217 217 221 194 229 224 221 210
   134 146 139 132 131 146 139 142 147 146 141 136 146 147 152 142 163 153 147
   146 131 135 133 131 143 132 131 132 133 136 134 136 133 137 132 141 132 141
   134 130 130 131 131 138 135 134 134 138 133 133 131 133 131 133 133 134 151
   139 140 134 132 133 133 136 133 130 137 132 129 133 132 140 136 137 141 132
   130 149 134 136 150 133 134 131 130 141 144 137 143 132 132 136 135 133 146
   138 133 132 134 139 134 133 139 132 133 134 132 137 137 136 132 139 136 143
   136 131 129 137 134 130 131 141 130 130 131 131 140 131 141 132 133 130 138
   140 133 144 140 134 131 134 136 147 137 138 138 144 132 1430 141 135 135 133
   148 136 136 134 131 133 142 138 132 135 118 142 136 132 137 137 133 441 330
   140 132 132 133 134 133 133 132 133 146 142 134 132 136 147 137 133 132 134
   140 129 134 136 137 150 135 133 137 130 137 137 131 135 131 134 151 134 134
   143 137 140 141 134 133 134 134 133 130 138 136 139 134 130 138 134 133 131
   146 139 133 132 133 133 133 132 131 134 147 142 141 139 132 131 136 133 132
   130 135 132 133 138 133 146 134 131 136 139 137 129 135 137 132 130 141 132
   132 133 130 146 137 130 132 146 132 132 131 137 135 129 132 133 132 138 137
   139 138 156 137 134 144 135 133 135 141 132 134 144 132 134 139 142 137 130
   133 133 133 132 131 139 133 132 132 132 131 132 130 131 133 130 131 132 136
   131 130 138 132 131 132 133 134 133 131 132 133 130 134 133 131 132 131 132
   137 130 133 132 132 132 130 154 153 145 157 153 138 136 131 133 140 135 131
   134 131 133 131 133 133 131 133 132 133 131 133 134 140 131 131 133 132 148
   141 136 134 152 168 142 132 132 131 133 151 131 134 132 131 131 130 132 133
   130 133 138 132 137 130 138 143 156 159 135 133 140 131 135 134 130 132 133
   138 135 131 133 134 140 144 139 134 132 133 145 147 139 157 137 132 131 130
   132 133 129 131 132 131 136 131 131 130 129 138 133 130 131 129 147 147 151
   156 148 143 132 132 134 139 131 139 134 131 131 130 135 134 134 136 142 141
   149 147 144 143 136 165 156 164 151 157 143 146 164 141 156 137 134 132 134
   133 130 133 131 132 137 130 132 134 130 133 132 132 132 131 133 147 138 142
   163 138 137 132 133 135 129 132 133 132 132 131 137 133 130 132 132 133 132
   130 132 140 131 132 132 132 132 141 147 149 141 134 134 134 131 134 133 139
   131 133 134 133 132 130 134 134 131 132 134 132 133 131 133 135 136 132 137
   136 151 143 134 133 132 132 133 133 132 132 134 134 136 133 135 132 138 131
   135 135 134 143 154 147 134 136 135 135 139 133 135 133 132 133 133 134 137
   139 134 133 133 136 134 134 136 133 138 134 136 132 140 151 137 133 145 134
   132 132 133 133 145 136 134 137 134 136 134 134 132 132 135 133 135 132 142
   135 136 135 134 132 133 132 134 134 131 133 134 132 135 132 156 161 141 136
   133 135 138 132 135 129 133 134 135 136 132 131 134 133 133 136 134 133 134
   132 135 135 133 134 133 134 116 137 157 141 130 133 134 132 133 130 135 135
   131 134 132 133 136 132 134 134 131 133 130 131 131 131 133 131 131 132 121
   132 132 131 132 144 135 132 133 131 131 131 132 133 131 130 133 132 131 131
   132 133 136 132 133 131 150 135 141 139 131 132 131 131 133 144 136 133 191
   224 220 220 222 216 218 212 220 217 223 219 217 216 198 200 181 164 217 216
   214 214 218 219 217 215 219 201 217 212 214 217 212 212 212 213 212))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 222914 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61606704 :P50-TICKS 216 :P99-TICKS 226
 :LATENCY-TICKS
 #(217 215 214 212 214 222 210 214 211 213 215 213 213 214 213 212 212 215 213
   211 216 215 211 213 211 215 214 212 212 213 212 196 158 215 214 213 214 213
   212 214 211 215 216 212 214 216 217 220 216 218 218 215 219 217 219 218 215
   216 217 215 188 224 221 216 216 217 218 215 226 222 225 221 221 216 216 215
   216 223 222 217 215 218 229 219 217 217 216 223 220 223 219 195 225 221 226
   227 227 226 228 227 226 227 228 225 226 227 224 215 216 224 216 215 217 213
   218 216 215 218 216 217 214 217 221 222 219 217 216 218 215 216 217 213 218
   218 216 217 215 217 220 219 217 217 220 217 222 220 220 215 218 217 216 220
   218 215 218 214 217 216 216 216 215 217 217 216 216 217 215 217 211 217 217
   215 177 217 218 216 215 217 217 215 216 218 215 222 216 217 216 215 216 218
   217 216 215 219 217 215 216 216 216 216 216 217 217 218 217 217 216 215 215
   216 218 215 215 217 216 217 214 217 217 214 217 216 216 215 216 216 216 212
   218 216 216 216 214 218 220 215 216 216 219 217 214 217 216 1540 220 218 216
   216 219 219 217 213 216 216 216 216 214 215 220 215 215 218 214 214 218 216
   216 214 219 217 216 216 215 216 217 215 217 217 215 217 213 217 218 214 216
   217 215 222 213 218 217 214 216 216 215 216 215 216 216 217 216 217 215 216
   214 217 216 214 215 218 215 214 214 217 217 213 217 216 217 219 213 217 215
   214 216 216 215 216 214 224 217 216 217 218 225 217 214 217 216 218 216 215
   216 216 214 216 215 217 217 220 217 216 215 216 218 216 216 216 216 216 216
   217 218 215 216 216 216 216 217 216 221 217 216 217 215 217 215 217 217 215
   221 217 217 216 215 217 217 213 216 215 220 215 215 217 216 215 215 216 216
   216 218 216 217 216 216 220 217 217 216 217 220 215 216 218 217 216 215 217
   217 214 221 219 216 217 215 218 218 215 217 216 216 218 215 217 217 181 217
   215 215 216 214 219 216 215 216 216 218 214 214 216 217 218 215 216 216 216
   214 217 218 214 217 219 215 213 214 221 216 214 214 216 214 220 214 217 217
   214 215 217 216 216 213 217 217 214 215 216 215 215 214 219 217 215 217 216
   215 216 214 217 216 214 216 216 219 215 214 215 216 214 216 216 214 216 217
   216 216 213 216 215 215 215 214 216 218 214 213 220 217 216 215 216 217 214
   216 219 217 216 215 217 217 214 217 216 220 219 214 217 216 214 217 216 215
   215 214 221 221 220 217 217 215 216 215 216 218 218 217 216 217 216 214 217
   216 218 215 220 215 215 214 216 216 215 216 217 215 216 216 216 217 214 215
   224 226 216 217 226 220 214 215 216 215 215 214 216 221 218 216 216 216 217
   218 217 216 214 215 218 215 215 214 218 219 214 216 215 215 211 218 216 217
   214 216 218 216 216 214 216 217 214 217 216 217 213 214 216 216 220 219 217
   216 215 216 217 216 214 215 217 219 214 214 216 216 213 215 216 215 217 217
   218 216 214 218 215 223 216 215 216 219 216 215 216 215 216 215 216 217 217
   216 217 214 215 213 217 216 214 217 216 215 221 222 218 215 216 215 217 213
   217 216 220 217 214 216 221 216 215 216 219 217 218 216 218 216 217 220 221
   222 220 215 220 216 216 216 218 202 223 220 220 216 220 216 224 222 216 219
   216 215 217 215 221 218 215 217 217 217 216 216 216 216 215 218 216 217 217
   215 214 218 216 216 217 219 215 214 218 216 214 216 217 216 216 216 218 217
   214 216 216 215 216 217 218 220 214 219 218 215 216 213 216 216 214 218 217
   215 215 216 216 218 214 217 216 219 216 215 216 216 214 216 215 216 216 216
   217 216 213 215 222 215 214 224 226 222 217 218 218 222 218 214 216 223 216
   218 217 216 216 215 224 220 213 216 216 216 220 220 216 217 214 215 217 215
   217 215 219 216 214 216 216 215 214 214 217 217 217 215 216 215 215 214 216
   216 215 215 217 215 215 212 218 218 215 215 217 216 214 220 221 216 217 214
   217 215 215 215 216 218 214 215 217 218 215 214 217 217 214 220 216 215 215
   215 217 217 213 218 216 217 216 213 217 218 213 224 225 219 221 221 219 217
   214 215 216 215 217 215 216 221 210 215 216 216 216 214 217 216 214 219 216
   216 216 219 218 217 215 216 217 217 217 215 216 216 214 217 217 216 215 214
   218 217 216 216 217 216 216 215 217 216 220 217 217 215 216 216 217 218 216
   216 221 217 216 214 217 216 215 217 216 217 225 214 217 218 215 217 217 214
   216 216 220 217 215 216 216 219 217 214 218 216 216 215 218 216 217))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 222153 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61546688 :P50-TICKS 214 :P99-TICKS 226
 :LATENCY-TICKS
 #(217 217 220 217 217 217 216 215 216 216 218 215 220 217 216 216 215 233 241
   239 225 221 220 216 215 217 216 213 215 215 214 213 215 216 208 213 216 214
   213 215 213 219 217 212 213 214 213 214 211 214 214 212 216 212 214 213 212
   216 214 211 214 214 214 214 212 214 217 211 215 214 214 214 212 213 213 211
   214 213 213 213 211 214 168 313 214 213 216 211 212 213 216 212 213 213 214
   213 214 213 216 212 213 214 213 215 212 213 216 212 213 214 212 1521 215 216
   216 212 214 213 216 214 212 214 214 211 213 215 213 213 214 217 215 212 215
   215 213 214 211 213 224 214 213 215 212 213 212 215 214 213 213 217 214 213
   211 221 213 213 214 216 214 217 212 215 214 212 216 214 214 215 213 219 217
   213 214 214 214 213 213 214 214 216 213 215 214 213 212 214 214 212 213 215
   215 212 214 216 213 213 214 216 213 214 215 215 215 212 214 214 213 212 212
   216 217 212 211 216 214 215 211 214 214 212 215 216 213 213 215 215 213 213
   213 214 213 215 212 215 214 211 215 215 214 212 212 216 220 213 213 213 214
   212 211 212 222 215 214 213 213 212 212 214 214 213 215 212 216 212 213 213
   211 211 215 214 213 209 212 213 213 213 213 213 212 213 211 213 216 211 212
   214 211 213 210 214 214 213 213 215 213 212 212 214 213 212 216 213 211 216
   212 213 214 211 215 213 212 212 212 215 213 212 212 213 213 212 211 214 212
   209 214 212 213 212 213 213 212 217 213 212 215 215 211 213 213 212 212 213
   212 212 217 216 214 211 211 214 212 212 212 214 216 211 213 214 218 213 211
   214 213 212 213 214 212 212 224 232 214 210 214 213 214 215 214 213 214 210
   214 212 212 213 211 218 215 212 213 213 209 214 211 220 217 212 214 214 212
   212 210 214 213 211 214 213 214 216 218 217 212 211 212 213 212 212 214 212
   212 210 213 212 212 212 211 213 215 212 214 213 212 211 212 213 214 211 214
   216 214 211 212 214 212 210 213 212 212 217 211 210 214 212 214 213 213 212
   211 216 215 212 213 213 212 212 211 214 213 211 217 213 213 213 212 214 214
   213 214 214 216 213 212 214 215 212 218 215 213 213 213 214 212 212 212 214
   214 214 214 214 214 213 213 214 212 212 213 213 213 198 222 243 213 213 210
   164 216 211 214 214 216 212 214 217 214 212 218 213 218 215 212 214 220 213
   214 213 211 212 211 214 217 210 213 173 216 212 210 213 213 214 212 212 212
   214 211 211 215 214 215 214 213 212 210 213 212 222 221 215 216 213 209 213
   214 211 213 213 212 223 212 181 219 212 214 214 212 213 211 218 216 211 212
   214 214 211 177 215 214 212 212 215 213 212 217 217 214 210 213 213 215 211
   214 212 213 210 212 212 212 214 215 213 213 211 212 212 213 212 210 212 217
   209 215 212 212 213 217 216 214 212 214 214 212 212 211 212 213 210 212 213
   213 216 211 214 213 211 212 212 212 212 212 216 212 211 212 214 212 212 213
   212 214 210 214 212 212 212 211 213 213 218 166 214 215 211 211 214 212 211
   213 213 212 217 211 215 213 211 213 213 218 213 211 213 212 212 212 213 213
   211 211 213 213 212 213 215 211 211 211 213 212 212 212 213 212 214 211 211
   214 212 214 213 211 212 211 212 216 210 212 213 212 213 210 213 214 210 217
   213 212 213 210 213 209 211 213 212 213 214 210 213 212 213 211 211 219 213
   210 214 212 214 213 212 211 213 212 212 212 212 213 212 212 211 211 213 213
   212 211 220 218 217 216 218 216 216 216 218 216 216 218 217 216 215 216 217
   216 216 214 219 218 215 216 214 216 217 217 217 217 216 219 216 216 215 215
   216 216 215 216 215 219 215 214 216 219 217 219 218 217 216 220 223 212 219
   217 217 218 216 215 217 221 215 216 218 216 216 215 218 216 215 216 220 217
   219 215 219 218 215 216 217 216 218 215 224 217 215 217 217 217 215 216 224
   218 215 216 216 215 217 213 216 217 216 215 216 215 216 215 216 216 213 215
   219 216 216 215 217 216 215 216 216 215 218 214 217 216 215 216 217 216 215
   214 218 217 212 219 216 216 216 214 216 217 214 215 218 215 217 214 217 216
   215 217 216 220 216 215 217 217 214 216 217 215 216 218 216 216 214 216 219
   216 217 217 217 220 214 217 216 216 215 215 216 218 215 218 217 216 217 216
   217 217 215 216 218 219 214 216 216 217 214 217 218 215 211 214 218 217 214
   217 216 219 217 215 215 217 219 215 217 216 217 213 217 216 216 1533 227 226
   219 215 219 218 215 219 216 216 217 213 217 216 217 220 223 216 463))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 195296 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61606128 :P50-TICKS 217 :P99-TICKS 243 :LATENCY-TICKS
 #(139 143 140 138 141 141 140 139 141 142 141 138 139 141 140 144 138 141 141
   138 140 145 139 171 146 147 142 138 139 141 139 142 139 145 147 145 117 144
   139 143 138 146 140 138 139 135 140 140 138 144 146 137 141 140 173 245 230
   231 230 226 229 228 228 228 228 232 238 230 231 230 228 227 227 233 229 226
   229 228 226 227 225 228 230 228 226 229 228 226 224 170 236 228 226 230 226
   232 232 233 233 226 227 227 235 240 228 230 230 227 228 227 226 226 228 226
   228 225 228 231 233 232 232 232 233 225 231 235 227 228 236 241 250 244 238
   234 242 254 233 230 228 227 228 228 227 226 224 227 226 224 228 228 231 227
   236 243 233 226 227 229 228 225 229 234 229 224 227 227 225 228 224 226 226
   223 224 226 225 231 229 228 227 224 226 238 231 231 224 226 232 228 225 227
   226 224 224 226 226 225 227 228 223 279 293 235 241 253 228 233 228 226 225
   231 227 225 225 226 227 226 223 226 225 224 227 226 225 224 227 226 225 234
   227 227 226 229 225 226 229 225 227 229 226 226 223 227 227 225 228 227 225
   230 226 230 230 225 227 230 227 228 224 227 227 224 233 229 231 239 230 226
   226 227 227 225 226 225 225 227 226 223 225 228 225 227 227 228 230 224 226
   227 226 226 226 227 227 235 231 227 226 225 225 225 229 225 227 233 230 228
   224 227 229 225 226 226 227 229 224 226 231 230 230 230 228 229 229 232 230
   227 230 230 229 229 226 227 230 222 229 231 231 228 229 231 230 227 231 230
   228 228 228 229 233 231 232 233 229 228 223 230 228 227 229 229 228 231 227
   229 230 226 228 232 230 229 236 237 234 234 227 228 223 223 223 225 186 149
   141 145 142 142 138 140 141 145 140 156 171 149 157 171 147 142 143 143 147
   143 139 141 142 139 145 136 140 127 142 142 142 139 142 139 141 141 138 146
   145 139 145 181 159 146 142 142 143 124 140 142 140 140 148 152 142 138 125
   140 140 146 138 141 140 141 141 151 140 132 138 141 140 142 154 173 158 141
   142 140 142 138 141 141 140 143 140 143 144 128 142 153 148 141 140 143 143
   142 144 145 144 144 158 151 149 156 157 148 139 146 140 142 140 149 146 140
   140 141 139 141 140 140 145 141 141 139 137 145 142 154 150 150 144 150 148
   168 162 157 149 146 141 142 145 143 141 139 140 141 139 139 139 153 154 144
   142 141 141 144 162 151 149 139 140 140 142 140 139 148 141 140 141 139 140
   130 128 156 146 144 150 156 160 143 139 152 145 143 146 145 145 144 143 142
   141 139 117 149 142 140 144 153 168 143 145 142 143 146 139 142 141 144 146
   141 145 143 138 142 127 138 141 142 158 152 154 146 154 142 148 143 148 141
   141 140 151 144 142 141 141 140 142 141 141 138 156 155 141 146 153 137 169
   148 147 142 141 142 139 147 143 125 140 145 145 142 125 142 142 140 141 143
   162 148 145 142 147 140 155 143 145 151 143 141 137 149 144 145 141 144 139
   141 142 151 141 141 141 141 140 142 141 141 139 140 141 140 139 141 142 146
   145 143 141 140 139 145 144 143 145 130 145 146 145 144 140 145 145 144 143
   139 142 139 143 141 143 141 142 141 140 144 143 137 142 142 142 140 138 141
   140 139 140 139 143 141 145 161 149 142 144 137 145 142 142 144 143 141 144
   142 148 174 151 143 132 141 140 143 122 141 141 143 143 140 142 143 141 144
   140 149 143 141 126 142 154 148 142 146 136 146 144 147 228 243 230 229 230
   227 228 234 228 1932 225 231 232 227 228 228 228 227 224 229 227 229 226 228
   227 227 225 228 225 225 222 231 225 222 221 225 222 219 222 222 219 222 219
   222 222 218 221 222 223 222 220 227 224 220 221 182 222 217 217 218 220 218
   218 219 218 218 215 219 218 219 219 221 216 217 214 218 217 216 217 219 218
   219 215 218 220 216 217 217 217 217 215 230 220 217 219 218 217 217 217 218
   217 220 217 220 225 227 225 227 226 226 227 243 232 228 224 227 227 217 218
   216 217 217 214 217 218 220 221 218 216 217 215 220 217 215 217 217 216 215
   216 216 218 218 217 217 216 220 215 218 217 215 217 219 218 217 215 216 218
   216 223 225 218 222 215 218 220 218 217 217 216 218 214 219 223 216 217 219
   217 218 214 218 219 220 217 226 218 217 215 218 217 215 218 217 218 218 215
   218 216 215 216 218 217 217 217 217 218 214 218 218 218 219 215 219 228 220
   217 225 219 222 218 218 218 216 219 219 219 216 215 217 217 214 218 218 219
   217 216 218 217 215 216 218 216 216 216 217 219 216 217 217 217 215))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 227649 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61606704 :P50-TICKS 220 :P99-TICKS 235 :LATENCY-TICKS
 #(220 217 217 217 216 218 218 218 224 220 218 214 216 218 215 215 213 217 221
   216 217 217 217 216 214 217 216 215 219 216 216 216 213 217 217 215 216 218
   217 218 214 217 217 217 216 218 216 215 215 222 219 216 217 217 216 207 214
   217 217 217 216 217 217 216 215 217 216 213 217 219 215 216 214 217 215 214
   225 236 242 235 222 230 219 230 315 223 222 220 227 225 223 286 222 222 220
   221 219 223 225 220 225 222 221 229 220 221 221 224 224 221 220 223 220 222
   221 220 221 220 224 222 223 237 230 222 222 222 221 223 219 221 225 220 220
   223 221 220 219 230 222 219 223 224 222 222 220 222 221 222 220 223 221 220
   221 221 223 219 220 224 220 234 221 221 221 220 222 224 219 223 218 221 222
   218 220 221 219 221 219 225 226 225 222 219 220 220 219 219 221 220 221 221
   221 220 217 220 219 218 220 223 220 219 217 220 220 218 219 220 222 222 219
   222 221 219 221 220 223 218 219 222 220 218 220 221 219 220 218 221 221 223
   223 220 220 222 218 223 221 219 220 224 220 220 220 220 220 220 220 220 221
   221 218 222 220 220 220 220 221 220 217 224 220 219 220 221 219 220 219 221
   222 222 220 221 222 223 218 221 225 218 220 223 219 227 227 223 221 219 219
   220 218 225 228 223 192 225 220 219 220 219 166 226 220 219 221 226 225 221
   218 222 227 221 220 220 220 220 219 221 220 220 223 221 221 220 218 220 221
   219 221 221 221 220 219 221 221 218 221 221 220 219 221 221 220 219 219 222
   221 219 220 220 223 220 220 221 220 219 218 221 220 220 224 222 221 220 219
   220 221 218 219 221 223 224 218 220 221 218 220 221 221 220 220 220 220 218
   220 221 221 222 217 220 222 217 219 219 220 220 218 219 220 218 221 220 219
   219 218 219 222 217 220 220 221 219 217 221 221 217 222 220 219 220 220 220
   221 217 219 220 218 218 199 220 223 218 220 219 218 218 217 220 219 218 222
   220 218 219 219 220 220 218 220 219 221 219 219 221 221 219 220 220 220 219
   220 221 220 219 219 220 220 219 218 221 222 224 223 224 222 223 218 221 219
   218 222 220 219 219 218 222 221 218 219 220 225 222 217 220 221 219 219 223
   219 220 221 221 220 218 220 221 220 220 217 220 222 218 220 220 235 224 219
   221 222 220 231 222 222 221 219 221 229 228 229 221 221 221 219 229 226 219
   219 220 223 220 220 226 224 238 224 223 221 228 224 221 220 224 225 228 227
   229 218 227 223 222 223 223 220 219 217 222 222 198 232 221 224 220 219 222
   220 221 221 225 224 221 218 221 220 220 220 220 225 225 214 229 223 219 221
   220 220 233 222 223 220 225 223 220 219 219 218 221 220 219 219 220 219 220
   219 220 220 228 220 222 219 219 218 220 220 218 219 219 219 220 217 220 222
   219 220 221 220 219 217 223 221 219 219 221 219 219 218 218 219 219 218 220
   218 218 230 230 227 1574 225 224 222 221 217 222 220 219 218 221 220 218 219
   220 220 223 221 220 221 220 219 220 220 219 222 220 219 218 217 220 223 218
   222 220 223 220 217 222 220 218 220 222 220 219 221 223 220 218 219 220 220
   219 217 221 226 219 220 220 221 219 219 221 221 219 225 221 220 220 219 224
   220 218 219 221 222 220 217 221 220 218 219 220 219 219 221 221 220 218 219
   220 219 219 218 220 223 219 219 221 220 221 220 221 220 221 223 221 220 221
   219 221 220 219 223 222 223 219 219 220 220 217 222 221 219 219 222 220 222
   219 220 222 222 219 217 221 226 218 223 221 219 219 219 222 220 226 253 233
   227 225 223 226 225 229 224 224 224 221 220 221 222 220 222 225 220 224 222
   222 227 223 221 224 221 221 220 222 223 223 228 222 223 224 220 223 223 227
   221 223 222 222 219 222 224 220 222 225 222 223 219 224 222 220 226 223 221
   220 221 222 222 221 221 223 221 222 219 225 222 221 226 223 221 222 223 222
   222 222 221 222 221 221 219 221 222 220 221 224 222 223 220 222 222 219 223
   225 224 224 221 222 222 221 221 223 220 222 219 226 222 220 224 221 221 221
   219 221 221 221 221 222 220 221 218 220 221 220 220 229 225 221 219 222 222
   219 221 222 222 222 219 222 224 221 317 224 220 220 222 221 222 219 220 221
   220 221 220 220 224 219 221 222 220 221 220 220 221 220 223 221 221 220 218
   222 220 220 221 221 221 221 220 221 222 219 221 222 220 221 222 221 226 221
   222 222 221 229 220 224 223 220 220 223 221 220 219 222 221 220 223 222 220
   221 220 222 221 220 222 224 222 221 219 221 222 220 221 223 224 226))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 227481 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61606688 :P50-TICKS 220 :P99-TICKS 233 :LATENCY-TICKS
 #(220 223 221 224 223 224 226 219 221 221 222 219 221 222 221 224 221 223 223
   220 221 221 220 220 220 224 222 219 222 221 226 221 219 221 222 223 220 220
   221 221 219 192 231 223 225 221 226 221 219 225 222 219 220 221 220 223 219
   221 221 221 221 221 222 219 219 224 230 222 221 220 224 222 220 220 222 225
   221 221 220 226 223 223 220 218 222 227 220 221 218 223 220 219 221 221 221
   225 222 221 224 225 221 221 219 221 220 222 220 219 220 221 220 220 218 220
   222 221 223 222 221 226 219 222 220 219 223 221 220 224 218 222 221 219 221
   223 223 222 219 221 221 219 220 224 224 223 217 224 221 218 220 221 220 220
   219 222 221 219 219 221 219 219 217 221 224 217 220 220 219 224 218 221 222
   222 230 223 221 219 219 222 221 221 221 225 221 230 222 224 221 220 221 221
   218 223 220 222 220 219 221 221 220 220 218 223 221 219 222 220 220 220 218
   220 221 221 220 220 220 222 222 221 232 225 228 236 224 223 220 222 222 219
   220 221 220 222 220 221 222 223 225 222 219 220 221 222 220 220 220 221 220
   220 218 221 220 222 223 220 220 219 218 220 221 219 220 222 220 220 221 220
   220 218 217 219 219 220 218 221 219 219 220 223 220 220 218 222 220 218 220
   220 220 222 218 221 220 222 219 221 220 221 218 221 221 220 220 222 221 220
   219 221 222 220 219 222 222 221 219 222 221 219 221 221 220 219 219 222 221
   218 219 221 221 219 218 221 221 220 221 220 219 219 218 221 220 218 220 223
   219 220 219 221 221 219 220 220 220 222 218 222 232 223 222 222 230 233 225
   225 222 220 221 224 223 221 219 221 225 222 220 222 221 220 219 221 222 220
   227 224 221 220 220 221 224 219 222 220 223 220 218 221 221 219 220 223 220
   221 223 221 222 222 220 221 222 219 219 221 233 220 220 223 223 219 218 222
   221 219 224 220 220 219 218 220 221 218 220 220 222 220 218 221 220 218 220
   220 220 219 220 220 222 219 221 220 220 221 218 221 224 219 220 221 219 222
   220 221 221 219 221 220 219 220 217 220 220 219 223 220 222 219 217 220 220
   220 220 225 220 220 221 220 221 220 223 220 219 221 218 221 223 219 225 221
   220 220 218 221 221 219 222 220 220 219 217 224 221 218 220 221 222 220 218
   221 220 220 221 221 220 1560 222 221 221 223 221 220 221 220 218 231 222 222
   220 223 224 222 220 222 220 219 221 220 220 223 218 223 221 218 221 220 221
   220 219 223 222 219 221 220 219 220 218 220 221 222 219 220 221 220 219 220
   221 225 232 225 221 221 218 226 225 219 222 222 223 227 185 225 223 218 223
   221 220 220 217 222 221 222 221 220 219 220 217 221 223 230 220 220 221 218
   217 225 223 224 220 220 220 218 217 220 221 217 219 221 219 223 218 220 219
   218 220 220 219 219 217 222 220 217 220 219 219 220 218 220 223 222 220 223
   222 219 217 220 195 221 227 183 218 219 217 220 219 218 222 224 224 217 217
   220 220 219 222 219 219 219 219 219 220 218 219 221 219 219 217 220 223 217
   219 221 218 218 218 220 222 218 220 219 219 219 220 219 221 217 220 220 222
   219 217 221 219 216 219 226 221 219 219 224 231 225 220 221 219 219 218 222
   224 221 222 220 220 226 226 233 225 231 233 231 222 224 221 231 229 230 219
   233 225 248 226 205 230 237 223 228 221 218 214 217 218 215 221 218 222 217
   214 219 219 221 232 227 210 235 224 196 231 225 220 215 178 227 212 229 215
   234 227 239 215 234 210 226 198 226 230 221 219 225 220 221 220 219 221 220
   220 232 193 223 220 218 220 219 220 220 218 221 221 220 220 221 221 222 222
   221 220 220 222 224 220 220 218 221 219 219 219 220 219 225 217 220 221 215
   230 227 226 232 232 225 222 221 221 223 226 223 226 223 224 220 222 223 228
   227 223 224 220 219 222 220 223 224 229 225 224 204 230 228 228 232 221 229
   221 219 225 220 219 219 220 219 220 218 219 221 219 219 218 220 220 220 221
   221 221 219 218 220 222 221 225 229 222 218 219 219 223 217 219 220 221 219
   217 220 219 218 219 221 219 219 220 220 220 220 220 219 220 219 217 221 221
   218 220 219 219 220 218 220 220 222 222 220 219 219 218 220 220 218 220 220
   219 219 218 220 221 219 218 219 221 225 225 221 218 220 219 222 220 219 231
   233 225 220 221 222 219 220 217 220 220 218 221 219 223 220 217 221 220 219
   221 221 220 212 217 219 220 216 218 223 221 223 220 222 222 217 221 220 222
   219 220 221 222 219 221 224 225 224 223 227 158 222 228 227 223 224))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 226935 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61606640 :P50-TICKS 220 :P99-TICKS 233 :LATENCY-TICKS
 #(223 208 233 222 225 221 220 221 219 221 226 223 226 227 224 220 219 222 223
   220 223 225 232 236 224 234 224 219 221 222 222 220 218 224 219 218 220 220
   222 221 221 221 221 219 220 221 219 222 218 222 226 220 219 221 222 221 218
   220 221 218 222 219 220 224 218 220 224 219 220 221 223 219 219 221 229 224
   233 239 224 222 222 222 375 219 221 221 220 221 219 223 221 217 221 220 219
   221 219 221 221 221 220 221 219 221 221 221 222 219 220 222 220 221 218 225
   222 224 219 221 219 220 220 222 221 218 221 220 219 220 218 221 222 218 220
   221 223 220 219 222 222 221 222 221 220 219 219 221 221 220 220 177 219 219
   217 220 220 222 220 221 220 221 219 222 224 220 219 221 230 223 224 230 222
   225 223 219 219 220 217 237 214 224 224 221 221 232 219 219 222 223 232 228
   229 226 220 223 226 225 230 220 224 221 222 230 219 219 219 220 219 221 222
   224 223 231 221 229 219 219 217 219 225 208 221 223 225 222 218 222 221 224
   222 229 226 220 217 220 219 218 220 220 222 218 218 220 220 219 219 224 224
   222 218 222 219 219 219 220 219 219 229 224 221 220 219 222 221 221 218 221
   229 226 222 222 219 220 221 227 232 234 222 220 219 219 218 220 221 219 219
   221 230 229 223 220 223 219 226 221 222 222 220 222 221 218 222 227 224 220
   218 220 221 217 221 218 217 219 217 219 219 218 222 220 218 226 225 221 220
   217 220 219 221 219 216 219 220 218 222 221 219 219 219 220 218 218 219 219
   217 219 216 219 221 210 221 221 219 219 218 221 220 218 221 219 220 219 217
   221 220 218 221 220 221 217 218 219 221 219 224 224 219 217 218 220 220 218
   220 220 218 219 217 220 221 1525 222 222 220 220 218 220 221 218 219 220 220
   219 220 221 218 221 177 226 219 219 217 221 223 218 219 220 219 219 218 220
   220 218 223 219 219 220 220 224 219 219 219 222 223 220 218 220 221 218 220
   220 220 219 221 220 220 218 219 219 219 218 218 221 225 218 221 221 220 189
   228 237 225 224 227 224 223 225 229 223 220 221 223 224 223 221 219 221 221
   218 222 222 220 220 221 221 223 218 219 221 219 220 218 222 229 224 223 220
   221 220 225 220 221 219 223 222 222 221 219 214 224 220 221 222 222 219 220
   221 220 221 220 219 219 219 219 220 224 220 221 220 219 220 216 219 221 218
   219 219 220 218 217 220 220 218 220 219 218 219 220 220 221 218 219 220 220
   219 217 221 220 219 220 220 219 219 221 220 220 218 219 220 220 219 216 218
   222 218 220 218 219 219 219 220 219 218 221 219 223 180 219 219 219 218 221
   220 228 222 219 221 220 219 219 221 220 220 221 221 221 219 220 221 219 219
   218 220 222 218 220 220 219 219 218 222 220 219 223 225 224 220 218 225 221
   219 220 220 221 220 226 221 219 219 219 221 232 223 226 227 225 223 219 222
   219 218 220 227 164 218 218 219 217 220 217 218 218 218 218 219 217 217 215
   218 217 216 219 220 219 216 216 219 221 216 217 217 216 219 214 218 218 215
   216 218 216 217 223 223 219 216 217 218 215 218 216 219 217 221 216 217 217
   216 217 217 217 217 217 220 217 220 217 219 218 216 217 218 217 220 215 218
   217 216 216 218 217 216 215 221 219 214 216 219 216 217 217 218 216 217 218
   217 216 216 215 218 217 215 216 217 217 216 214 216 217 215 216 217 215 226
   223 218 217 216 217 217 217 215 215 220 217 214 217 192 223 217 216 219 217
   218 219 217 217 217 215 218 217 216 216 217 217 218 214 217 217 216 217 217
   216 216 219 224 224 218 217 217 215 218 214 218 219 216 216 218 217 215 214
   218 218 216 219 220 229 221 218 220 221 219 221 221 221 219 219 220 221 218
   219 222 219 219 221 228 224 219 220 220 233 224 225 225 223 219 220 221 221
   225 220 221 221 219 131 221 220 220 218 227 221 219 222 221 224 221 225 226
   221 219 222 220 221 219 220 221 279 219 220 221 219 221 218 222 224 222 221
   222 220 219 218 222 220 219 222 221 232 224 221 225 227 220 221 225 220 219
   217 224 225 220 220 221 221 225 225 222 236 232 225 232 230 228 222 225 220
   219 221 221 220 222 219 232 222 222 221 226 220 221 219 222 221 219 219 223
   220 220 220 207 227 223 221 222 220 222 220 222 221 218 221 222 220 220 218
   223 220 220 220 221 220 224 222 221 231 204 223 222 220 219 220 221 221 219
   219 223 220 219 218 220 221 220 222 222 219 222 222 224 220 220 220 221 220
   220 219 224 223 218 220 221 221 219 218 220 222 220 220 220 219 220))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 1 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 210133 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61606496 :P50-TICKS 219 :P99-TICKS 230 :LATENCY-TICKS
 #(225 221 224 219 222 227 224 222 222 222 227 220 220 222 221 220 219 222 220
   218 232 225 221 221 218 222 221 218 221 220 224 220 219 222 220 219 220 221
   220 219 223 221 222 219 220 220 220 219 220 221 225 220 219 221 219 220 218
   221 220 218 223 221 218 220 218 223 220 218 221 220 227 220 218 222 221 219
   221 222 220 219 221 220 221 219 220 220 219 220 218 221 225 221 220 222 220
   221 218 221 220 218 224 221 219 220 218 220 221 219 220 221 226 219 218 221
   220 218 222 220 221 219 221 221 223 220 221 222 220 221 220 220 223 218 220
   221 220 221 229 222 221 220 222 220 221 221 217 222 223 261 221 220 223 220
   217 221 222 221 222 222 221 221 219 203 231 221 222 221 222 221 224 229 229
   226 222 221 222 226 223 228 226 227 224 225 226 226 224 227 229 221 219 226
   219 220 220 221 220 219 220 221 220 223 218 220 221 219 220 223 220 222 219
   225 222 219 220 221 220 219 218 220 220 221 220 220 219 220 218 221 221 218
   219 223 223 222 218 222 221 219 230 220 221 221 217 220 178 224 220 221 217
   220 219 229 228 220 220 222 220 1493 222 223 222 220 221 220 220 224 218 222
   221 219 219 222 220 219 219 225 220 218 220 220 220 218 218 222 221 227 223
   224 220 220 219 222 221 218 222 223 220 219 219 220 221 220 220 221 219 224
   219 221 221 219 221 220 220 220 223 222 223 218 220 229 224 234 222 221 221
   221 219 220 221 219 229 227 226 223 222 221 220 220 222 225 223 218 220 225
   169 227 220 222 222 222 223 224 220 222 219 223 224 218 221 227 225 224 219
   231 227 220 222 220 215 227 220 221 223 223 227 225 221 220 219 230 225 218
   222 226 225 222 220 225 221 219 222 221 222 222 218 221 222 221 225 223 221
   223 220 222 221 218 220 222 223 221 221 221 224 221 222 221 221 220 219 223
   221 221 223 143 141 143 146 166 157 122 140 138 136 136 135 135 137 133 141
   137 136 135 133 138 136 134 136 137 141 127 135 137 160 150 144 135 135 135
   135 139 137 134 133 136 136 141 134 142 136 123 141 139 124 135 133 136 137
   140 139 136 136 140 134 136 137 134 142 137 136 139 138 140 147 139 137 138
   136 136 133 138 139 142 145 138 136 136 138 139 157 146 141 129 139 136 143
   137 141 134 142 137 135 135 135 136 135 135 135 136 136 138 128 138 141 137
   142 137 136 136 134 137 137 134 136 136 136 136 133 135 135 124 130 137 134
   138 135 139 135 134 134 136 136 135 138 135 136 132 139 136 136 123 133 135
   135 134 134 136 134 139 134 139 141 134 128 136 136 135 133 136 136 133 135
   135 135 134 133 135 136 143 145 136 138 135 149 115 135 134 135 136 135 135
   131 140 135 133 135 224 230 224 222 192 225 222 221 220 221 220 217 221 221
   220 222 221 220 220 219 223 221 218 220 219 218 223 221 220 220 220 219 219
   221 220 219 220 220 218 219 223 219 220 217 220 219 217 220 221 219 220 219
   219 223 219 219 220 219 220 217 224 219 218 219 220 222 219 216 224 222 221
   226 221 225 218 214 216 216 214 216 219 215 216 213 227 219 216 218 217 216
   220 215 217 217 215 217 217 216 216 215 221 216 215 217 217 217 216 215 217
   218 219 218 217 216 217 215 216 216 215 217 226 227 226 223 227 228 225 226
   225 225 229 224 246 217 215 217 216 217 214 215 196 220 216 216 216 217 216
   216 217 219 218 216 216 215 216 216 217 217 215 216 220 218 215 214 217 216
   214 217 217 216 214 216 218 216 216 215 215 216 216 214 217 220 214 218 217
   217 216 214 217 216 214 220 217 217 215 214 216 217 215 225 215 213 216 213
   218 216 217 220 229 196 212 196 228 234 224 222 224 219 215 214 218 219 215
   216 217 219 224 217 217 218 215 219 216 216 218 214 218 216 215 217 216 215
   221 215 220 217 225 221 220 216 217 204 222 217 214 216 215 217 215 214 220
   217 217 216 216 217 220 217 218 216 217 216 222 215 215 214 217 217 215 215
   215 216 219 213 217 217 215 231 223 217 202 217 221 224 223 218 218 218 219
   221 225 219 220 218 226 173 220 215 218 218 216 216 221 222 221 217 218 218
   215 216 217 217 217 215 218 217 218 217 217 218 216 215 217 221 215 217 217
   215 215 215 217 217 214 219 216 216 216 203 219 217 216 219 219 219 215 214
   216 217 214 215 217 216 215 216 217 216 214 216 217 216 216 221 222 190 220
   216 217 217 216 215 217 218 215 218 219 216 217 216 218 217 216 217 217 220
   220 215 217 216 215 217 217 215 216 215 219 217 216 216 217 215 216))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 213031 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61546304 :P50-TICKS 220 :P99-TICKS 234
 :LATENCY-TICKS
 #(155 139 146 146 140 144 137 164 139 131 139 118 136 130 137 137 137 136 136
   137 144 145 146 151 155 143 145 140 138 137 138 164 141 138 139 138 139 136
   138 139 151 139 154 156 155 141 122 147 141 140 148 136 136 136 136 2012 138
   142 147 152 140 134 139 126 137 138 142 138 137 138 138 129 146 147 154 140
   125 141 141 137 143 140 138 133 139 138 139 139 140 138 141 130 141 141 159
   145 142 146 145 139 140 141 147 184 145 140 140 167 139 149 138 139 143 154
   185 168 137 141 143 167 152 156 152 140 139 143 152 140 139 137 139 141 139
   139 144 140 140 141 143 142 148 143 144 143 142 142 142 142 144 142 148 150
   143 144 149 141 140 144 146 143 140 137 145 138 142 145 154 147 144 141 141
   138 144 146 140 140 138 138 134 138 138 145 138 139 142 133 140 139 139 139
   144 139 140 138 142 242 145 139 124 145 137 128 138 129 140 138 128 139 139
   139 141 139 145 250 229 225 224 224 224 225 228 224 224 222 222 223 221 221
   222 220 221 221 225 225 189 221 203 226 228 228 225 224 225 223 231 224 225
   225 224 222 225 224 232 228 224 223 225 224 226 225 224 227 224 225 223 224
   224 222 221 223 227 225 221 221 224 223 222 223 220 224 220 228 223 220 221
   221 226 227 226 230 229 231 224 223 224 225 228 231 225 222 228 223 229 227
   220 218 216 217 217 222 220 219 219 221 220 221 220 223 221 221 224 221 224
   222 222 221 221 220 222 136 222 225 221 223 221 222 220 221 219 221 224 222
   220 221 225 223 225 221 221 221 224 221 221 218 227 232 232 233 231 231 234
   231 232 232 231 232 230 226 221 224 224 221 222 223 226 230 220 221 223 225
   221 220 221 221 220 219 222 221 224 234 230 222 220 233 244 230 228 227 226
   228 227 225 225 228 225 223 226 224 223 225 223 225 224 224 228 224 225 224
   227 223 225 223 223 225 223 224 223 225 229 226 225 224 224 228 222 221 222
   220 226 229 223 222 220 224 232 225 223 227 233 224 223 226 226 224 194 233
   225 225 221 220 221 221 221 225 226 224 226 224 225 233 227 229 225 224 223
   225 222 232 225 229 234 227 230 223 225 221 223 226 224 224 227 229 224 220
   221 220 222 223 220 220 283 218 228 224 220 220 228 230 222 220 220 222 222
   220 222 220 229 221 221 224 223 219 226 222 222 221 232 183 222 225 220 221
   221 220 232 227 222 220 221 230 165 222 220 233 228 221 222 221 221 230 226
   228 204 225 221 224 227 225 220 220 228 227 223 222 221 223 224 234 223 227
   227 225 227 223 224 223 221 220 219 221 222 221 220 221 226 227 220 221 220
   222 220 221 223 221 221 221 221 221 221 223 221 222 221 221 222 220 220 220
   222 223 222 222 224 221 221 222 221 221 221 224 219 221 221 221 221 219 227
   220 225 221 219 221 218 219 219 219 219 223 224 220 220 221 220 221 221 220
   223 220 222 220 219 220 219 220 219 221 220 221 223 221 220 220 220 220 223
   220 219 219 224 226 220 220 219 222 221 219 219 220 230 224 220 219 222 218
   219 240 227 222 221 221 219 223 220 220 220 220 219 220 224 219 219 220 219
   219 218 220 219 220 231 224 219 221 219 219 221 219 225 221 222 220 220 220
   220 220 220 219 219 221 221 224 223 222 221 221 219 220 219 219 222 219 219
   220 219 221 217 226 219 221 222 220 201 232 221 219 226 224 219 219 229 226
   220 219 220 219 220 224 219 219 224 220 218 219 219 220 219 221 219 218 223
   218 218 224 220 219 219 220 220 219 221 222 219 219 219 220 218 218 219 220
   222 221 221 220 220 217 231 220 219 220 221 221 221 222 221 220 220 220 219
   220 221 219 221 221 220 221 220 218 219 219 222 216 214 216 215 214 217 213
   214 214 216 213 218 215 214 214 215 214 214 214 218 214 214 218 214 213 214
   214 215 218 218 215 219 220 215 220 214 214 216 215 218 217 213 215 215 214
   214 214 214 219 215 216 215 215 214 214 214 213 216 215 214 217 214 213 214
   214 213 215 214 217 215 218 213 218 214 214 214 213 218 214 214 217 213 213
   214 214 220 220 218 214 213 220 218 215 216 220 218 215 216 213 214 214 217
   216 217 214 216 215 217 215 219 469 215 216 215 214 213 214 214 219 1708 224
   217 217 218 216 215 216 215 214 214 215 214 214 218 213 215 213 214 213 213
   222 222 217 220 216 214 213 214 215 215 214 214 214 223 220 214 215 215 214
   215 215 215 215 213 216 214 214 213 214 213 214 212 214 215 220 222 216 214
   214 213 214 214 213 214 217 214 213 213 213 215 213 215 213 213 216))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 221950 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61606704 :P50-TICKS 215 :P99-TICKS 227
 :LATENCY-TICKS
 #(217 215 218 214 214 220 216 214 213 217 214 213 215 216 217 214 219 221 215
   214 215 214 215 214 216 214 216 213 215 214 214 215 214 214 214 214 217 215
   214 215 213 214 214 214 214 214 217 214 213 215 213 214 215 215 213 214 214
   215 214 213 214 214 214 212 215 214 215 217 216 215 214 215 215 215 214 214
   215 221 214 214 215 213 214 215 214 214 214 216 214 214 215 214 214 214 218
   215 214 216 217 214 216 214 214 215 214 214 214 215 216 214 214 215 214 214
   215 214 214 215 216 214 215 215 214 215 214 215 214 214 218 215 214 214 215
   214 213 215 220 214 217 215 213 216 214 213 228 217 215 213 216 218 214 217
   214 214 217 216 216 214 215 216 214 222 220 215 215 213 214 220 221 214 213
   214 215 213 219 218 214 217 216 216 214 215 214 213 214 214 217 213 214 216
   215 214 215 214 214 219 214 214 215 221 217 216 219 217 213 215 214 214 213
   218 214 213 213 214 214 213 213 215 213 218 213 214 214 213 214 214 214 213
   214 214 215 214 215 213 214 214 225 219 215 214 217 214 217 217 214 214 215
   214 217 218 215 215 215 217 218 221 216 213 214 216 213 214 214 213 215 220
   219 221 215 217 240 235 215 213 214 213 213 215 212 213 213 213 212 212 213
   213 213 216 214 214 213 212 218 212 222 217 214 214 216 215 216 213 215 215
   214 215 214 214 217 214 214 215 215 214 220 214 214 218 219 215 214 214 214
   214 213 214 215 215 217 214 215 215 216 214 216 214 213 214 218 214 215 214
   215 214 214 216 215 216 215 218 214 215 215 225 219 215 214 219 215 219 214
   214 215 218 220 214 214 215 215 218 214 214 214 221 213 214 213 213 214 217
   212 214 214 213 213 215 214 214 213 214 214 214 216 213 214 213 219 156 220
   215 213 216 217 213 215 215 218 214 216 215 219 212 214 215 213 214 213 214
   213 215 215 213 214 220 215 215 212 214 213 165 216 214 215 221 214 214 213
   215 214 216 213 214 214 214 213 215 215 214 214 214 217 214 216 214 214 215
   214 214 214 214 218 214 215 214 214 214 214 215 215 213 216 216 214 215 214
   214 215 214 213 213 217 216 214 214 214 213 214 214 214 214 214 218 221 215
   213 215 214 214 215 214 215 225 214 214 214 214 214 215 214 215 214 219 215
   215 214 214 214 213 215 214 214 217 215 214 214 213 215 214 213 214 214 214
   215 215 215 214 214 214 213 214 214 215 215 213 214 214 214 214 214 214 214
   222 218 223 218 215 216 215 216 214 214 214 218 215 215 214 215 214 215 214
   178 220 216 220 214 215 214 214 214 215 214 214 213 215 214 215 213 214 213
   214 215 215 215 218 214 213 215 214 213 214 213 214 213 217 218 215 214 214
   214 215 214 241 215 217 215 213 214 213 214 215 214 213 214 214 216 214 215
   215 215 214 214 217 213 214 218 213 215 214 215 214 211 215 214 214 227 216
   214 214 215 213 214 214 215 213 219 218 215 213 214 214 215 215 218 218 213
   215 216 217 216 215 220 215 214 215 214 217 218 215 214 214 214 214 220 215
   217 216 215 215 214 227 220 219 216 218 215 219 217 216 219 217 216 216 216
   217 216 219 217 217 215 216 216 216 217 216 216 219 216 217 216 217 216 224
   227 221 215 219 216 218 218 222 218 217 216 216 216 226 231 221 219 218 217
   217 221 217 217 219 216 219 217 219 216 217 216 216 215 219 217 217 216 217
   216 217 216 216 216 216 217 216 216 219 215 217 216 216 218 220 216 217 215
   216 216 217 216 217 215 217 216 215 216 221 205 216 214 219 216 219 216 216
   217 216 216 215 217 216 215 219 215 216 215 218 224 220 219 216 215 221 1532
   221 216 219 216 216 215 216 215 215 216 216 216 219 214 215 214 216 215 216
   215 215 214 216 223 219 216 219 224 217 222 227 228 219 215 215 216 216 216
   215 215 216 216 225 218 221 216 216 214 217 215 217 217 220 217 216 215 216
   217 216 219 216 220 221 218 214 214 215 214 217 218 215 213 218 214 215 214
   216 215 214 218 223 217 216 224 219 216 216 215 216 215 221 215 215 218 222
   218 227 221 217 215 215 216 215 217 228 231 216 215 225 221 215 215 218 219
   214 216 149 220 223 220 215 215 219 226 216 215 215 215 215 216 214 215 216
   218 213 214 215 213 214 214 214 215 214 217 215 215 216 214 216 214 220 215
   214 215 217 215 214 215 214 214 215 215 215 215 217 214 216 213 214 214 214
   215 214 214 218 215 214 215 215 214 215 214 217 215 218 214 214 214 216 215
   215 214 214 215 214 216 214 215 214 217 214 214 218 215 216 216 216))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 221928 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61606688 :P50-TICKS 215 :P99-TICKS 228
 :LATENCY-TICKS
 #(216 217 225 214 217 213 214 214 213 214 215 215 216 214 216 215 214 215 214
   215 215 215 214 214 215 228 217 216 216 215 216 215 215 215 216 224 218 216
   216 215 215 220 216 216 218 216 216 215 215 216 214 215 217 215 215 217 219
   215 215 215 213 221 214 216 214 217 215 215 215 214 215 216 221 215 216 218
   216 215 216 221 218 216 218 217 218 227 228 219 215 216 215 215 216 214 216
   216 222 223 216 215 216 216 216 217 216 216 218 216 216 216 215 214 215 215
   217 215 218 215 216 218 216 222 215 214 214 214 218 216 215 216 216 215 215
   215 215 216 217 215 215 215 219 220 217 215 216 216 220 215 214 216 215 215
   215 218 215 216 218 215 217 215 216 216 218 218 216 219 218 231 215 217 217
   216 216 216 216 215 215 216 216 215 221 215 216 214 215 214 217 219 216 215
   215 215 215 215 215 215 216 218 216 215 215 215 215 215 216 215 215 219 215
   215 215 216 215 215 214 216 215 219 215 217 218 217 216 216 215 216 215 215
   216 215 216 215 216 216 215 216 217 218 217 201 230 220 216 218 216 215 215
   218 220 216 218 216 216 222 216 218 215 215 218 218 217 215 217 215 219 217
   215 215 218 215 216 216 216 216 216 219 216 220 220 217 219 331 216 215 214
   216 216 214 220 216 214 215 214 215 216 213 214 215 219 221 215 215 218 215
   214 214 214 219 212 216 215 214 213 215 214 215 215 203 216 217 215 215 216
   214 216 215 215 219 218 222 216 218 215 216 216 214 215 215 216 220 215 217
   216 216 215 216 217 216 216 216 218 216 216 216 216 214 215 219 224 220 214
   219 215 215 215 218 216 215 215 218 217 215 217 215 219 217 216 222 220 220
   199 216 216 217 215 216 216 215 219 216 218 216 215 216 216 216 218 214 215
   216 217 214 216 214 214 215 214 214 214 213 218 214 214 215 195 216 219 220
   216 215 218 216 217 214 216 214 215 218 217 216 218 219 218 215 218 214 224
   216 214 214 224 220 218 214 215 214 216 219 215 215 214 221 219 215 217 214
   214 215 215 213 214 217 214 214 215 214 214 214 215 213 222 229 222 215 217
   215 215 223 215 214 214 219 215 215 214 215 215 215 214 215 215 214 217 218
   214 214 217 214 214 214 213 215 215 215 215 214 217 215 215 214 215 215 217
   215 215 215 214 216 214 213 214 214 218 214 214 214 214 217 214 214 220 218
   217 215 215 216 220 214 215 216 214 169 217 217 214 214 216 213 216 205 217
   215 217 221 214 215 214 214 214 214 225 203 217 218 217 216 220 219 223 222
   216 215 215 222 216 218 214 214 216 214 216 214 215 218 219 216 216 215 214
   214 214 225 217 216 217 221 214 215 215 214 215 215 214 216 214 214 215 215
   215 215 215 214 214 214 219 215 214 215 214 218 215 215 215 215 217 217 215
   213 214 214 214 214 214 214 218 214 216 215 213 219 217 216 214 214 215 216
   214 216 214 215 214 214 200 216 214 230 215 214 215 214 215 217 214 215 213
   218 214 216 215 213 214 214 214 215 215 219 223 224 225 220 225 218 216 214
   1545 219 216 216 215 222 218 214 215 215 216 215 221 218 218 217 214 222 220
   215 215 215 215 214 214 215 215 215 213 214 212 214 214 216 216 221 217 215
   215 214 214 215 214 214 215 215 217 215 213 215 215 213 214 215 214 214 214
   213 214 215 214 213 215 215 215 214 217 215 215 215 214 237 219 214 214 215
   221 217 216 214 215 216 214 218 213 214 217 216 215 204 215 215 215 215 215
   219 215 216 215 215 217 216 215 215 225 223 215 214 217 213 212 213 213 213
   212 214 213 213 212 211 212 215 213 213 212 213 214 212 214 212 213 212 212
   212 213 212 216 212 211 212 212 211 212 213 213 211 212 213 212 220 212 213
   212 212 213 212 212 214 211 211 212 212 212 211 212 211 212 216 212 211 213
   212 212 212 212 212 212 212 213 214 212 211 213 211 212 214 212 283 213 212
   211 212 212 211 213 212 211 212 214 212 211 215 213 224 211 213 212 211 217
   225 217 214 212 214 212 213 213 213 212 212 211 212 212 212 211 212 211 212
   212 215 212 213 211 212 212 211 189 214 212 215 212 212 213 212 211 212 211
   211 212 212 214 212 213 212 214 213 212 213 212 211 215 210 212 211 212 212
   211 210 212 212 215 212 212 210 212 211 210 211 217 211 212 213 211 212 211
   212 212 211 212 211 212 214 211 211 213 211 212 214 212 211 211 213 212 211
   211 211 211 211 212 213 212 211 188 217 212 215 213 237 227 219 218 218 221
   216 216 217 215 222 222 217 218 215 219 215 217 215 215 221 216 215))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 219390 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61606672 :P50-TICKS 215 :P99-TICKS 225
 :LATENCY-TICKS
 #(216 216 216 215 216 215 216 220 221 217 215 219 216 215 215 217 218 214 215
   216 214 215 216 219 217 215 215 215 215 217 214 216 214 215 214 214 218 214
   214 217 214 214 215 217 215 214 213 213 215 219 216 215 214 214 215 214 217
   215 214 222 216 216 215 214 214 216 215 215 214 219 215 214 212 215 213 213
   215 214 214 217 215 214 215 214 214 215 214 214 214 213 218 214 229 220 216
   215 217 216 214 214 217 215 215 216 215 212 214 215 216 218 219 215 216 216
   214 215 217 214 215 215 229 215 215 214 220 215 215 215 217 217 218 215 216
   215 215 215 215 216 216 215 218 217 214 214 218 214 215 215 215 215 215 217
   213 214 219 213 215 214 215 214 213 216 217 214 218 221 214 215 218 216 215
   219 214 214 215 215 215 215 216 214 215 218 215 215 217 215 216 204 218 216
   213 216 219 216 216 214 217 220 224 215 214 215 215 216 214 214 214 213 214
   215 227 223 223 216 215 215 214 216 215 215 217 215 221 223 193 215 215 214
   214 216 214 214 218 219 216 215 214 215 215 214 215 216 215 217 215 216 215
   214 217 217 216 216 221 221 222 214 215 215 219 215 214 219 214 217 215 215
   214 215 215 215 213 215 217 219 217 215 214 215 215 216 217 216 214 217 223
   220 218 216 216 190 220 217 216 221 220 215 216 215 215 215 216 216 215 218
   216 214 215 218 217 217 216 216 215 215 218 216 215 215 214 216 215 216 215
   215 216 217 215 215 215 219 215 215 215 216 220 215 215 216 214 215 215 214
   214 221 216 214 219 215 215 215 214 215 214 214 217 216 215 216 214 214 213
   216 214 215 214 215 215 216 215 214 215 217 214 215 214 218 213 220 217 215
   215 215 215 215 214 219 214 216 215 214 215 214 215 215 213 218 215 215 214
   215 216 220 174 209 168 215 217 215 213 215 215 214 214 216 215 214 216 213
   214 214 214 214 217 216 213 215 221 216 215 215 215 214 215 214 215 214 218
   222 217 215 214 216 216 215 215 216 219 214 213 215 215 214 225 219 215 215
   216 215 214 213 213 203 214 214 214 217 217 214 214 215 216 214 222 229 216
   216 221 219 218 213 213 215 215 215 214 214 214 215 213 214 214 213 213 215
   215 214 214 217 214 214 215 214 213 214 214 214 213 217 215 213 215 214 214
   214 214 213 215 215 215 214 214 222 213 215 211 216 217 212 214 215 213 216
   215 215 215 214 216 214 219 215 215 215 215 214 215 215 215 216 218 215 215
   215 1526 219 215 219 216 216 216 214 215 216 217 215 214 215 214 215 213 215
   219 215 214 216 214 214 214 213 215 213 224 217 216 218 217 215 217 218 215
   216 215 215 215 218 214 218 214 214 215 214 215 216 214 217 215 215 214 214
   215 215 216 214 215 215 220 213 214 217 214 214 215 214 215 217 217 215 221
   215 215 215 215 216 215 216 217 214 215 215 215 221 215 216 215 215 219 215
   217 214 218 218 220 213 228 218 228 215 216 216 216 215 214 215 215 215 219
   216 215 215 215 215 214 215 214 214 216 216 215 214 217 228 228 217 212 213
   212 213 214 212 212 213 214 217 213 212 212 255 216 223 215 221 214 214 213
   211 211 215 212 211 212 213 216 213 214 215 219 221 219 217 215 213 213 218
   217 216 218 221 216 216 218 218 216 216 218 219 217 214 214 212 213 213 212
   212 211 211 212 213 212 212 213 210 211 212 212 212 211 210 215 214 134 211
   211 211 211 193 221 215 212 215 212 211 211 212 211 220 218 212 212 215 211
   212 216 212 212 213 212 212 213 214 213 212 211 212 212 215 220 214 217 214
   221 222 214 212 214 212 212 212 211 213 219 212 212 211 214 211 211 212 213
   212 219 215 215 214 215 213 212 211 213 220 213 213 211 212 211 212 211 214
   215 214 212 212 214 213 212 213 211 211 211 216 214 216 212 212 212 212 212
   212 211 218 212 212 212 212 212 212 211 212 212 214 212 211 210 211 210 212
   211 210 211 218 213 210 210 212 211 211 211 210 209 211 215 215 215 211 210
   211 211 210 211 213 211 221 213 211 210 210 211 214 211 212 211 214 211 204
   212 210 212 210 211 213 211 213 214 211 211 215 211 211 214 210 211 209 213
   210 210 210 211 210 216 211 209 210 213 210 209 209 211 210 209 211 210 211
   211 211 211 211 212 210 209 212 210 211 212 214 211 210 210 211 211 211 211
   210 210 213 211 210 210 211 213 211 210 212 211 211 215 211 211 216 212 210
   213 211 210 212 219 209 218 213 217 211 212 210 210 211 212 141 129 131 129
   130 129 129 130 129 129 153 141 136 148 150 156 147 129 133 130 128))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 0 :VALUE-BYTES
 60000 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 208050 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61606368 :P50-TICKS 215 :P99-TICKS 230
 :LATENCY-TICKS
 #(139 134 131 132 136 130 129 133 131 131 130 131 141 133 131 127 131 130 128
   136 130 136 132 149 139 134 130 130 130 132 131 134 130 131 131 130 131 131
   131 131 180 142 161 139 133 136 131 132 132 132 134 131 133 132 131 145 140
   146 135 131 131 131 130 131 131 129 130 133 149 140 134 131 131 132 132 131
   131 135 130 131 136 129 130 130 130 131 143 131 133 136 138 131 131 101 130
   116 131 115 130 132 130 131 129 148 138 132 132 131 132 132 132 130 116 131
   130 129 115 132 115 134 99 132 114 130 130 130 130 130 130 130 130 132 130
   130 130 130 130 116 130 130 130 131 128 130 130 132 130 136 138 136 136 133
   136 129 136 130 130 130 129 130 128 131 130 145 131 133 130 129 128 128 133
   215 222 218 219 181 217 233 217 218 221 171 186 219 216 217 216 215 216 215
   215 216 216 216 216 217 154 225 218 215 215 214 219 215 216 207 217 214 219
   216 216 222 219 215 216 216 215 215 215 216 215 215 218 217 219 217 215 216
   216 216 216 215 216 216 216 214 215 216 215 214 214 214 217 217 215 217 215
   217 215 216 217 216 221 217 214 214 217 216 215 215 217 215 215 219 214 215
   216 215 215 214 223 215 215 218 216 214 215 216 215 218 218 218 218 218 216
   215 214 214 215 214 216 217 212 215 217 215 218 216 214 214 223 222 156 229
   229 225 226 226 226 224 225 225 224 218 220 214 219 215 214 214 170 216 215
   216 217 214 216 224 215 220 218 216 214 214 218 215 214 214 216 214 218 218
   213 215 216 214 215 217 218 214 214 215 214 214 213 214 214 215 214 214 218
   219 213 215 216 217 215 214 215 215 215 215 213 215 215 219 213 214 214 214
   214 214 214 215 214 218 215 217 216 221 215 217 219 214 215 218 215 214 214
   215 214 216 214 216 223 215 215 215 215 214 216 215 214 215 215 215 219 221
   221 216 1561 230 217 216 216 214 215 215 215 214 219 215 216 215 215 218 215
   215 214 214 221 215 214 215 215 187 220 214 219 218 217 215 215 227 216 214
   215 213 217 215 215 216 214 210 189 217 215 216 214 213 214 216 214 214 215
   215 215 226 232 228 225 224 218 216 216 216 216 217 219 222 216 216 216 215
   216 216 218 216 215 218 216 215 215 215 215 216 215 221 215 218 216 215 215
   215 215 215 216 214 215 248 215 216 216 215 215 214 214 216 215 218 216 215
   217 215 216 215 215 215 216 215 222 215 216 214 218 217 221 214 215 216 219
   219 218 214 215 215 215 216 216 214 218 215 215 216 214 216 215 221 214 214
   217 214 215 215 215 215 215 216 214 215 217 216 215 215 214 215 217 213 215
   215 216 222 218 218 216 217 216 216 216 215 215 218 215 215 215 216 215 217
   215 215 215 217 216 216 216 218 216 216 215 215 215 219 216 216 214 215 221
   214 215 214 215 218 217 216 215 216 215 215 215 215 215 215 218 217 214 215
   215 216 215 215 215 215 217 216 215 216 215 216 221 217 215 215 195 233 239
   225 218 215 217 216 217 216 219 214 216 215 258 215 214 215 214 214 216 214
   214 223 217 215 216 214 215 214 221 216 214 215 214 216 215 215 217 215 219
   215 215 215 215 218 215 214 215 214 215 216 213 214 215 214 214 218 215 216
   214 216 215 216 214 215 215 215 216 215 215 217 214 214 215 214 214 214 216
   214 215 218 215 221 213 215 214 213 215 216 214 216 215 215 215 221 216 216
   214 215 214 216 216 214 215 215 214 216 217 215 215 215 216 215 214 214 216
   214 214 215 214 218 218 214 217 214 216 214 213 214 214 214 217 214 212 214
   216 215 214 215 214 214 213 215 214 214 217 215 218 215 215 215 217 221 215
   215 215 234 224 217 216 219 218 219 216 216 216 215 216 216 217 216 223 234
   225 216 216 216 216 222 215 214 216 217 214 214 215 214 214 214 214 215 218
   219 214 215 214 216 217 215 215 213 214 227 220 217 215 217 216 218 217 215
   216 218 216 215 215 215 216 217 216 216 215 219 215 215 216 216 217 215 215
   215 216 216 216 216 216 214 217 215 216 217 221 228 230 226 216 220 188 219
   216 215 215 214 217 216 216 216 215 215 215 221 216 215 218 218 216 218 215
   215 216 217 214 216 218 216 216 215 215 215 215 215 214 216 218 215 215 193
   216 216 215 216 216 216 216 218 214 215 215 218 215 222 221 217 218 218 216
   217 215 215 217 216 216 216 216 219 217 216 215 216 213 216 215 216 215 218
   215 214 214 215 215 215 216 215 215 219 217 220 214 219 216 215 216 216 216
   218 215 216 216 216 216 216 215 216 215 216 218 215 216 215 215 217))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 220133
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61606624 :P50-TICKS 218
 :P99-TICKS 233 :LATENCY-TICKS
 #(138 134 133 134 133 136 132 122 131 125 132 132 132 133 135 133 133 133 133
   134 132 120 139 136 134 132 133 132 133 132 133 137 133 133 132 120 133 132
   137 133 133 133 133 138 140 132 138 132 146 134 143 134 132 137 134 245 225
   222 221 222 226 221 220 221 224 219 220 219 219 221 223 223 220 220 223 220
   219 219 219 219 224 219 224 221 221 218 219 219 218 218 230 232 218 219 222
   218 219 218 220 218 219 218 218 218 222 218 218 219 218 220 219 217 220 222
   221 220 218 219 218 218 217 218 217 217 220 218 216 218 220 217 218 219 218
   219 228 218 219 224 218 220 219 219 219 220 222 218 219 218 218 223 226 217
   223 224 221 218 226 241 238 227 223 222 221 221 222 222 221 220 223 219 221
   220 226 223 226 219 219 219 222 220 221 219 220 218 221 220 219 218 219 219
   219 222 223 219 223 220 219 219 221 221 222 220 219 220 223 219 221 221 255
   228 176 219 222 223 226 219 219 219 220 218 1950 219 223 222 219 218 222 219
   221 220 218 219 219 218 225 221 221 218 220 220 218 220 219 217 219 219 222
   219 218 221 218 219 219 219 218 218 222 218 218 218 218 217 218 219 218 218
   220 219 218 224 218 220 219 218 219 219 220 217 218 217 218 219 219 220 219
   220 222 219 218 219 218 219 219 219 219 217 221 219 221 219 218 219 218 219
   218 219 221 219 219 219 218 219 219 219 220 218 222 218 218 219 219 218 220
   219 218 219 223 223 217 225 228 222 222 226 221 220 221 219 219 217 219 219
   218 218 220 219 221 220 218 219 218 218 217 220 218 225 233 222 218 218 217
   217 218 218 221 221 221 217 221 218 218 217 218 219 218 218 221 220 219 218
   218 218 219 217 218 217 224 214 223 219 219 218 218 219 219 219 222 218 217
   218 219 219 218 218 219 218 230 219 218 219 218 218 219 218 218 218 220 220
   218 218 218 219 218 218 218 217 222 218 218 218 217 217 218 218 218 217 219
   220 218 217 218 217 216 217 220 218 219 242 218 218 217 217 218 218 219 218
   219 219 217 218 218 219 221 221 219 218 218 221 219 219 217 218 219 219 221
   229 220 220 218 219 220 219 219 218 217 219 218 219 219 220 218 219 222 217
   220 218 216 219 219 218 218 219 218 218 217 219 212 222 217 219 218 219 217
   217 218 218 219 219 217 218 218 222 218 224 217 221 216 220 219 218 218 217
   218 217 219 217 218 219 218 218 217 217 217 218 219 219 218 221 218 217 218
   218 218 218 217 219 218 220 218 218 217 218 221 219 218 212 216 219 219 217
   219 218 217 217 217 218 218 220 217 221 218 218 219 219 218 219 217 221 219
   218 218 217 218 218 218 218 217 222 219 217 218 218 218 217 218 220 218 220
   219 221 218 217 218 217 219 217 218 220 219 217 218 218 218 218 218 223 218
   221 218 218 218 217 217 217 217 233 229 218 218 222 236 218 218 217 219 218
   227 218 218 218 217 218 218 229 227 221 218 218 218 217 218 217 218 219 220
   221 220 218 227 221 217 218 218 217 222 218 217 218 218 218 218 217 217 226
   195 221 217 218 224 220 217 217 217 217 220 217 217 218 216 218 216 217 217
   205 223 223 220 217 216 216 217 217 219 217 220 220 221 217 217 218 217 217
   217 217 220 216 218 217 217 218 217 217 217 217 220 216 218 217 217 216 217
   218 217 215 223 219 217 218 218 218 221 218 219 219 220 218 217 217 218 218
   221 219 219 220 219 220 219 218 217 217 217 218 218 218 218 219 217 218 218
   218 217 217 218 218 218 218 217 218 217 217 217 224 220 217 217 216 242 237
   225 223 221 220 220 228 223 220 218 219 218 218 219 219 219 219 221 221 218
   219 219 218 219 220 219 217 219 218 219 226 221 216 213 213 213 214 213 215
   212 213 213 213 212 212 214 213 212 215 213 213 214 213 212 212 213 213 213
   219 214 216 217 215 213 213 212 212 214 214 214 214 211 212 213 213 212 213
   213 213 214 213 214 212 212 213 212 212 212 212 216 211 213 212 214 216 213
   215 217 212 216 213 213 213 216 212 212 212 212 193 214 215 212 212 212 213
   212 212 212 212 213 213 214 211 209 212 223 214 213 211 210 213 212 210 209
   209 210 208 215 211 211 209 217 212 214 213 212 213 213 212 209 209 211 210
   209 209 209 209 209 209 210 209 213 216 219 210 209 210 210 209 209 210 208
   213 208 209 208 209 209 208 209 209 215 219 214 217 211 210 210 209 210 210
   209 210 211 209 208 208 209 209 209 208 209 217 213 209 209 209 210 209 209
   209 209 208 211 209 217 214 210 206 214 208 209 208 209 210 207 208))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 218435
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61546688 :P50-TICKS 210
 :P99-TICKS 223 :LATENCY-TICKS
 #(187 210 211 213 208 209 210 219 214 211 208 210 208 248 212 210 208 216 210
   210 208 209 209 219 213 210 208 208 209 209 210 209 210 208 212 208 209 209
   208 209 209 209 218 213 210 211 208 209 210 208 209 208 208 209 209 211 209
   209 209 211 209 210 208 210 209 215 218 210 210 222 216 211 208 210 215 210
   211 211 209 209 209 208 211 208 211 208 215 209 1698 213 212 210 208 208 209
   209 207 208 208 208 210 208 209 208 208 212 211 208 209 208 208 211 209 208
   208 208 209 208 209 209 208 215 183 220 215 215 213 219 214 221 215 208 208
   209 212 215 208 209 208 208 208 209 210 208 208 207 209 207 208 207 209 207
   208 209 208 210 209 210 208 208 208 208 208 212 208 208 210 208 209 208 208
   209 207 208 209 209 210 208 209 208 208 208 207 208 214 198 209 210 210 210
   211 209 208 208 208 214 208 209 209 209 208 211 208 209 209 213 208 209 209
   209 209 210 209 208 211 210 210 209 208 210 209 210 209 208 209 209 212 208
   208 209 211 209 211 212 210 205 209 209 209 210 208 210 208 209 208 209 209
   212 209 209 208 208 209 199 213 212 208 208 212 209 207 210 213 208 209 208
   208 209 214 210 208 207 207 208 208 208 209 208 207 210 207 207 209 207 207
   211 209 208 209 211 208 208 207 208 208 209 207 208 208 208 211 206 211 210
   211 210 193 209 209 211 222 233 228 225 216 215 217 220 216 215 219 213 215
   214 214 222 216 213 214 215 216 215 213 213 214 212 211 212 213 212 212 214
   213 213 212 213 212 213 216 217 219 217 214 213 212 215 212 213 213 213 212
   214 213 212 213 212 212 215 222 217 214 213 225 215 212 212 212 213 212 216
   214 215 212 212 212 212 212 215 212 213 213 213 211 212 211 212 213 211 211
   212 213 211 214 212 212 212 211 212 217 217 215 212 213 222 217 216 213 215
   213 214 213 212 213 211 218 216 212 213 212 211 214 219 213 212 211 213 211
   211 213 211 215 212 211 212 210 212 185 216 213 215 214 214 213 213 212 213
   213 211 212 212 211 215 213 213 212 212 212 211 211 214 215 214 214 212 213
   213 212 212 213 212 213 212 213 211 213 211 213 214 211 212 212 217 214 211
   211 212 212 211 212 211 211 211 217 215 212 211 211 211 212 212 212 212 212
   218 218 212 215 219 205 213 212 211 212 215 211 211 213 212 213 212 212 214
   212 212 211 211 212 211 211 210 211 211 210 212 212 210 212 212 211 211 208
   213 212 213 217 213 213 212 213 212 215 212 212 212 214 213 211 213 211 211
   210 212 211 211 212 213 211 213 211 218 213 213 211 213 213 211 212 211 212
   212 211 211 212 211 213 213 217 212 212 215 215 212 212 212 213 215 218 212
   215 201 211 214 212 212 210 212 215 210 212 211 211 211 211 212 211 211 214
   210 212 211 211 213 211 212 211 211 210 214 212 218 215 209 208 207 214 220
   210 212 208 208 212 208 208 209 210 208 208 208 211 208 211 208 212 211 209
   207 209 203 212 215 208 208 209 208 208 208 209 208 209 210 208 208 208 207
   208 208 208 208 207 210 207 207 207 207 209 208 207 208 207 208 213 207 207
   208 210 206 208 208 209 209 212 208 208 209 208 207 208 208 208 208 209 212
   208 208 209 208 208 209 206 209 208 211 209 207 207 207 208 207 207 207 209
   207 210 208 208 207 208 208 207 208 208 210 207 210 208 207 208 207 208 208
   208 207 208 209 207 208 209 207 208 208 210 206 208 208 209 210 207 207 209
   207 207 207 207 207 209 208 207 205 207 206 207 206 207 207 208 210 207 206
   206 210 207 208 207 207 207 209 208 207 207 207 208 210 207 210 209 207 213
   208 208 209 207 207 208 208 209 209 211 208 207 206 210 208 207 209 207 208
   208 209 208 207 207 210 207 208 207 207 207 217 209 208 209 207 207 207 208
   208 207 207 208 207 207 208 207 207 208 208 206 209 211 207 207 207 207 208
   208 208 209 211 208 210 207 207 208 210 209 207 208 208 208 209 210 207 207
   207 209 208 208 209 208 207 211 208 209 208 207 208 207 208 207 207 208 211
   207 207 209 208 207 207 208 208 207 210 207 209 209 208 208 211 209 208 222
   224 221 214 216 211 210 211 210 211 210 212 211 212 211 213 212 213 211 211
   211 210 215 210 213 212 211 210 211 212 210 215 214 212 211 207 209 213 212
   213 212 211 211 216 212 211 211 213 211 211 211 1500 216 212 213 212 212 214
   218 211 216 227 212 211 215 219 212 212 214 215 213 211 214 213 212 212 214
   211 214 210 211 210 211 211 209 211 210 211 223 227 213 212 213 211))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 218972
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61606656 :P50-TICKS 212
 :P99-TICKS 223 :LATENCY-TICKS
 #(219 224 210 212 212 212 211 214 212 212 212 212 211 220 221 212 212 211 215
   214 211 213 211 210 212 211 215 218 214 216 211 211 212 174 218 212 211 218
   218 217 214 214 216 211 211 212 211 214 210 214 211 210 213 217 211 210 211
   213 211 211 134 212 212 215 218 213 211 212 211 211 211 214 213 212 218 218
   212 211 215 214 211 211 211 211 220 226 219 212 213 211 211 211 212 211 214
   216 213 213 215 211 211 211 211 211 212 213 212 212 212 211 210 211 211 211
   211 215 213 211 211 212 220 211 212 212 213 214 212 211 214 212 212 211 212
   212 212 213 213 210 215 211 211 211 212 212 211 210 215 210 214 211 212 211
   211 212 211 211 131 211 212 210 210 211 210 210 209 211 210 210 212 210 211
   210 211 211 211 211 215 210 213 178 211 211 211 211 210 211 182 217 214 213
   212 212 211 212 212 214 212 211 212 216 211 211 212 211 214 211 214 222 214
   212 215 211 211 211 210 210 211 211 211 214 212 211 216 212 210 211 213 211
   212 212 211 212 211 211 210 212 214 211 209 211 214 211 211 212 211 212 211
   211 211 213 216 212 210 210 212 212 211 211 210 212 214 213 212 213 211 211
   217 214 211 211 210 215 211 211 211 211 211 211 212 212 211 217 212 211 212
   211 211 212 211 212 211 213 216 215 211 210 215 210 222 212 214 212 214 212
   212 211 213 211 213 211 212 212 214 215 212 211 211 213 217 212 212 211 214
   213 211 211 211 211 212 211 212 211 212 216 211 210 211 213 211 213 211 212
   211 216 214 212 212 211 212 211 211 213 213 211 215 212 211 159 212 215 211
   212 210 212 212 212 212 212 212 210 211 211 211 213 212 214 211 212 212 212
   211 211 211 212 210 214 212 212 212 211 212 211 212 211 212 212 216 213 212
   217 213 213 213 211 213 212 215 212 213 211 211 212 214 212 213 214 212 212
   212 211 213 213 213 214 213 212 213 213 211 213 211 213 212 212 212 212 213
   215 213 212 212 211 214 212 212 212 212 214 215 211 211 211 214 212 211 213
   211 213 214 211 211 212 224 221 215 216 213 212 214 215 213 212 212 213 213
   214 220 213 215 213 214 212 213 213 215 213 213 212 215 212 212 213 213 212
   213 219 223 215 214 215 214 212 212 213 215 213 212 212 212 215 212 212 213
   212 211 214 213 213 212 215 212 212 212 212 213 212 213 213 212 215 214 212
   212 212 216 218 215 212 214 213 215 212 211 213 215 212 213 212 213 211 214
   212 212 212 213 212 212 215 215 211 214 215 212 212 212 213 212 215 214 216
   213 215 214 213 212 213 213 212 212 214 213 217 213 215 213 212 213 213 212
   212 217 215 212 213 217 212 212 212 212 215 213 213 214 214 212 213 213 212
   213 213 213 216 224 215 213 212 212 212 215 212 213 212 214 215 212 212 214
   212 213 212 213 212 212 217 216 214 213 212 213 213 215 213 211 215 212 213
   212 212 213 212 211 212 211 214 219 212 212 212 214 213 212 212 214 214 217
   219 212 212 213 212 212 217 213 213 213 212 213 212 212 212 211 212 212 212
   217 214 217 217 211 213 211 213 213 214 217 219 218 212 212 214 213 211 212
   211 212 213 217 214 216 217 212 216 215 210 212 214 212 212 211 212 213 212
   211 212 212 215 211 214 223 219 222 219 213 212 212 215 211 211 212 211 212
   212 212 213 211 212 215 206 215 215 213 212 212 210 215 213 218 215 215 212
   215 212 212 211 211 212 224 218 214 213 212 213 213 223 215 213 212 213 212
   212 213 211 211 216 212 213 211 217 212 212 212 212 212 211 212 215 212 214
   217 218 214 214 212 211 212 216 216 212 214 214 216 212 212 212 221 219 215
   212 212 212 213 212 211 213 212 212 216 215 215 211 212 212 218 211 212 215
   213 213 212 211 212 211 211 212 212 212 212 219 217 1554 215 215 212 212 212
   215 213 212 213 212 211 216 212 211 212 213 212 212 211 212 211 213 213 211
   211 212 211 212 211 214 212 212 214 211 213 211 214 211 213 212 211 206 214
   213 212 212 210 211 211 212 215 212 214 213 212 212 211 212 212 211 212 213
   212 212 213 214 213 214 212 211 211 214 213 215 209 210 212 212 213 211 212
   211 210 212 212 211 212 214 213 211 211 212 211 213 214 214 212 215 216 211
   201 212 215 216 226 214 214 211 215 214 212 211 212 210 212 211 211 212 211
   211 212 212 214 212 212 215 205 212 212 226 212 214 214 212 213 214 212 211
   212 213 211 213 211 213 211 213 214 212 212 211 212 212 212 212 212 212 214
   213 212 212 218 212 212 212 212 212 226 224 217 213 214 213 213 213))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 201298
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61606560 :P50-TICKS 210
 :P99-TICKS 222 :LATENCY-TICKS
 #(216 213 213 212 223 218 214 212 212 220 213 208 212 213 214 213 213 212 214
   214 213 214 211 215 212 213 212 214 213 216 212 212 212 213 211 212 213 211
   211 213 215 211 212 211 212 198 211 215 215 213 220 212 184 217 213 212 212
   216 212 213 214 212 211 213 211 212 212 214 212 212 212 217 211 212 213 212
   212 215 212 214 218 217 208 214 217 213 212 211 211 216 212 215 213 213 213
   212 211 213 213 212 212 214 227 218 212 214 211 213 213 211 213 221 219 211
   212 213 211 215 213 213 211 212 215 211 212 212 210 219 212 211 210 210 211
   216 212 211 211 211 211 210 205 214 211 215 211 211 211 213 210 211 212 210
   212 213 212 212 211 212 210 212 204 217 212 211 221 211 211 212 211 211 212
   211 214 212 214 210 211 211 214 212 211 212 211 213 212 213 211 212 211 210
   210 212 210 210 211 213 211 210 212 211 211 211 211 210 211 213 212 211 212
   213 211 211 213 214 211 210 217 220 211 211 211 211 211 204 211 211 214 210
   210 210 210 210 210 209 211 211 211 212 211 211 210 209 210 210 209 211 214
   214 210 210 211 213 211 213 212 211 212 215 212 211 211 210 209 210 211 210
   211 211 213 211 210 210 210 211 222 213 214 210 212 211 211 210 201 223 214
   211 210 210 215 212 210 210 211 210 211 214 209 211 209 215 211 211 212 211
   215 213 213 209 210 214 210 210 210 211 211 210 212 210 213 211 216 211 210
   211 211 213 212 211 212 211 215 212 211 210 211 211 211 213 211 211 212 212
   231 214 211 211 211 210 211 210 212 213 210 215 212 211 210 213 210 211 212
   212 211 211 220 222 222 212 210 211 209 214 209 209 208 210 211 211 209 208
   208 209 211 210 210 211 208 214 217 214 208 208 210 209 208 208 207 209 210
   217 218 137 217 217 211 208 213 217 213 212 213 212 216 213 213 213 213 216
   213 213 209 207 208 207 211 208 208 208 213 208 207 208 207 208 211 211 208
   208 208 208 211 210 208 210 219 215 208 207 207 210 209 208 210 208 208 209
   209 208 207 210 211 214 207 207 210 211 214 207 207 214 208 207 212 206 207
   208 211 211 208 207 208 207 207 208 208 208 211 209 209 209 206 208 207 208
   209 215 207 212 209 207 208 213 208 210 208 208 209 208 209 212 210 209 209
   208 208 208 209 209 212 209 214 207 208 209 208 209 209 209 212 212 208 210
   209 209 210 209 208 209 208 212 208 208 209 207 209 209 208 208 209 210 217
   209 208 209 209 207 209 208 208 209 215 209 209 208 209 209 209 208 209 209
   210 211 209 208 208 209 208 209 213 223 210 207 210 212 208 207 212 210 208
   208 213 209 208 209 208 209 211 212 209 209 211 209 209 209 209 208 209 208
   209 212 208 211 208 208 208 209 208 208 209 207 208 210 208 208 209 209 209
   207 208 209 209 209 210 209 207 207 209 208 207 215 208 207 211 208 208 208
   208 208 208 208 207 208 207 209 208 208 208 208 207 207 208 208 213 212 217
   208 209 208 209 208 208 208 208 209 210 208 209 210 218 211 215 210 208 208
   203 130 127 127 125 127 126 127 125 127 127 126 121 127 129 126 126 127 128
   145 136 114 142 156 149 132 132 133 127 128 128 127 128 1443 135 127 141 131
   134 133 130 147 136 139 140 135 125 142 138 136 139 132 128 127 129 128 133
   130 132 128 127 127 133 128 134 128 127 131 128 128 124 133 133 115 137 127
   151 130 128 129 128 128 128 128 130 130 129 129 128 128 128 135 128 128 128
   129 128 129 130 129 128 129 127 130 128 129 130 127 134 128 128 128 128 128
   128 128 128 128 128 130 127 128 128 127 127 147 128 128 126 128 126 126 126
   128 126 126 127 126 126 125 126 125 130 126 126 126 133 128 126 130 127 126
   126 126 126 127 125 126 126 126 127 127 131 125 127 127 126 126 127 129 130
   125 126 126 126 127 126 131 127 126 127 126 127 126 129 127 131 126 127 127
   125 127 133 127 160 217 214 218 187 172 139 215 211 216 217 213 207 188 213
   210 207 208 208 208 210 208 211 208 211 208 207 207 208 208 207 208 210 207
   210 207 208 207 208 207 208 207 207 211 207 207 208 206 208 206 208 207 207
   211 207 209 206 210 213 208 207 208 208 207 212 209 207 207 209 207 207 207
   206 208 208 211 209 209 221 216 214 213 216 213 212 219 213 214 213 213 214
   212 211 211 216 215 211 210 212 212 213 213 212 211 211 214 213 212 211 212
   213 215 211 211 212 212 214 135 214 212 215 211 215 212 211 212 217 221 222
   220 222 223 221 221 220 221 223 227 221 218 211 212 212 211 212 211))
(:KIND :CACHE-UNIX-SAMPLE :MODE :RESIDENT :VERSION 2 :BUDGET 4194304
 :VALUE-BYTES 60000 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 218507
 :TICKS-PER-SECOND 1000000 :CLIENT-ALLOCATED-BYTES 61606688 :P50-TICKS 212
 :P99-TICKS 222 :LATENCY-TICKS
 #(215 212 212 213 211 211 212 214 213 213 215 212 211 212 212 212 212 215 212
   210 212 211 210 211 212 211 212 211 211 211 211 217 210 211 210 212 213 211
   214 210 218 213 211 210 196 212 212 211 214 212 210 210 211 211 211 210 211
   210 211 215 210 210 211 211 210 211 210 210 210 214 219 211 214 215 210 213
   211 214 211 210 209 212 212 211 210 211 216 211 211 210 219 210 211 211 209
   210 210 210 210 211 213 210 212 218 211 214 214 214 215 212 212 214 215 211
   215 215 212 212 211 212 212 217 212 211 211 212 213 212 211 216 211 217 213
   212 215 211 211 212 212 212 214 211 214 212 212 211 211 211 213 217 212 212
   213 212 211 211 211 212 213 213 211 211 215 211 210 211 212 211 211 211 211
   211 213 213 211 210 212 212 212 211 211 211 211 213 211 211 212 212 210 214
   212 212 211 213 215 211 211 215 211 211 211 211 212 212 213 212 211 212 212
   218 212 212 211 211 215 211 211 211 211 212 211 210 211 212 212 213 213 212
   211 211 212 211 211 211 212 218 211 211 211 213 212 211 211 215 212 216 211
   213 211 211 211 211 211 213 211 212 213 211 216 212 211 210 213 211 213 211
   213 213 217 214 211 211 211 212 214 211 213 214 212 210 211 212 211 212 211
   211 211 215 211 212 212 212 212 212 219 217 213 214 213 215 211 211 211 211
   214 211 212 214 212 211 211 211 212 211 211 212 211 211 213 211 211 211 211
   211 210 211 211 217 214 212 211 211 212 211 212 211 211 211 213 214 215 211
   212 212 212 211 210 211 212 213 212 211 211 212 211 211 212 210 213 213 212
   211 212 211 211 211 213 213 211 211 213 211 210 213 213 223 220 212 211 211
   213 210 211 212 210 211 210 216 214 211 215 211 212 212 212 212 211 211 211
   217 211 213 211 211 212 214 211 212 215 212 212 215 211 214 211 212 214 211
   213 211 214 217 214 212 213 212 212 212 211 212 211 212 215 211 212 212 213
   210 211 214 212 211 216 208 212 210 240 219 214 213 220 230 223 215 166 218
   212 211 212 213 215 213 213 218 211 215 213 213 214 212 214 212 211 216 211
   215 212 211 213 214 214 212 212 214 210 211 212 212 212 212 212 212 212 213
   214 215 211 211 212 212 212 212 228 221 212 217 209 208 211 210 209 209 208
   209 212 207 209 209 208 211 210 208 209 208 207 216 218 211 212 211 211 211
   210 211 213 215 210 211 211 212 212 211 211 211 211 213 210 210 211 215 214
   212 212 212 211 215 212 213 212 212 211 211 213 212 211 217 215 212 213 213
   211 210 210 213 211 210 213 213 212 213 212 213 221 222 214 1558 216 212 212
   212 214 211 211 212 211 211 214 214 212 217 212 215 216 213 212 212 213 212
   212 210 212 216 211 212 212 212 212 212 213 212 211 216 212 212 210 214 212
   211 211 211 212 214 215 212 210 210 212 212 212 212 213 212 215 212 212 211
   211 212 213 211 212 213 216 211 212 212 212 213 212 210 211 212 212 212 211
   212 210 212 211 211 212 212 211 216 212 214 211 210 211 210 211 210 211 203
   214 212 212 213 212 211 212 212 212 213 212 214 212 216 212 211 212 214 211
   212 216 212 215 212 212 211 213 212 215 213 215 225 219 213 213 212 212 212
   211 212 212 213 212 211 212 212 211 212 211 212 212 217 212 211 203 214 211
   211 212 218 211 213 211 211 211 211 213 212 212 212 209 211 221 217 213 216
   212 215 216 212 216 217 214 212 212 212 212 213 211 211 210 211 215 210 212
   210 211 210 210 214 212 212 212 213 211 212 212 211 215 222 219 212 221 218
   212 213 218 215 208 212 214 211 211 214 212 211 210 211 213 211 210 212 210
   210 212 212 210 212 210 210 211 214 212 212 214 211 215 211 210 212 211 211
   210 211 215 210 212 211 210 210 211 211 211 210 215 214 211 211 211 211 211
   212 210 211 214 216 211 208 213 211 211 211 211 215 215 213 213 211 213 212
   211 210 212 211 211 211 214 211 211 211 210 211 211 211 211 211 214 210 210
   212 211 211 211 211 211 211 211 214 211 211 211 214 211 211 210 211 211 215
   211 211 211 211 211 211 212 212 208 219 213 210 211 216 219 211 212 212 212
   211 213 211 211 211 211 215 211 210 211 211 214 211 220 224 230 218 222 230
   217 214 214 216 215 212 214 214 212 213 212 212 217 212 218 212 218 215 214
   149 213 212 209 211 208 210 209 209 212 209 176 210 210 211 211 209 209 208
   208 209 208 211 211 208 211 210 208 208 209 208 209 209 209 208 208 210 211
   210 209 209 208 207 209 208 209 210 209 208 209 208 209 211 208 209))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 226616 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61606704 :P50-TICKS 223 :P99-TICKS 261 :LATENCY-TICKS
 #(144 144 145 142 145 145 145 145 143 148 145 142 151 143 142 140 139 142 139
   139 141 140 141 140 139 141 142 174 161 153 145 144 142 146 140 139 141 172
   145 142 140 143 186 239 234 232 231 230 227 229 229 227 235 238 228 228 225
   227 229 226 228 230 226 226 225 227 227 226 226 227 226 229 224 227 228 226
   226 228 229 234 230 228 227 225 227 228 226 228 224 213 230 231 234 231 227
   228 224 228 228 231 227 227 226 227 225 228 226 226 226 231 226 226 224 226
   227 224 228 219 237 228 227 230 231 227 228 228 227 227 227 228 240 230 230
   228 227 227 225 230 228 227 227 228 227 226 225 230 226 226 226 228 226 226
   224 226 225 225 226 229 226 225 223 226 227 225 227 226 233 227 227 228 230
   223 227 226 225 225 228 226 227 224 226 226 327 226 223 230 226 223 226 226
   226 226 224 227 226 229 227 226 226 226 226 227 227 224 227 227 225 225 223
   231 226 225 225 226 244 225 224 226 226 228 231 231 224 226 227 227 226 224
   225 226 225 224 223 227 228 224 225 227 225 226 224 225 226 224 226 226 224
   225 222 223 264 250 235 234 229 227 228 229 227 227 227 228 230 229 226 228
   227 224 227 227 227 227 227 228 227 226 226 226 226 226 225 185 237 226 227
   229 227 227 225 228 228 225 230 226 226 227 225 227 228 226 227 229 228 226
   225 227 228 227 230 228 227 233 225 227 230 229 226 227 226 226 224 230 226
   225 229 272 384 227 227 228 229 225 225 226 226 226 224 226 226 228 227 227
   227 225 225 227 227 227 226 233 225 226 226 229 229 225 226 226 226 281 224
   227 226 224 1980 226 232 229 225 226 230 227 235 233 230 230 227 228 226 225
   231 222 226 225 222 223 224 227 222 228 223 222 220 223 224 222 222 224 223
   226 219 225 226 221 222 223 221 222 220 226 223 221 222 223 169 237 225 224
   224 225 226 224 223 222 221 223 223 222 222 228 222 223 220 224 223 221 223
   223 221 226 221 222 224 221 222 222 219 222 220 225 222 220 222 222 222 221
   219 223 222 221 220 222 220 222 219 221 221 220 221 223 222 222 219 223 222
   220 220 221 221 224 219 222 223 221 221 223 221 239 220 223 221 222 223 222
   221 223 220 222 223 222 222 223 293 221 219 221 223 220 225 223 223 221 220
   223 223 221 221 223 225 222 220 223 222 221 221 222 221 222 222 223 222 221
   223 222 222 222 219 223 224 221 221 222 221 221 221 222 223 220 224 221 223
   220 220 223 221 220 222 222 224 223 219 223 221 220 222 225 221 221 220 223
   221 219 222 221 222 221 221 224 224 221 221 222 225 227 227 220 224 224 221
   221 221 221 219 221 223 221 222 228 228 233 220 225 221 219 221 221 222 224
   220 221 222 220 221 222 222 222 221 226 222 220 221 224 221 222 167 223 223
   227 223 223 220 220 220 223 222 221 221 225 221 221 221 223 221 221 222 222
   222 356 226 229 228 225 226 226 224 226 229 226 228 224 224 227 225 226 223
   226 228 223 225 225 226 225 224 226 224 224 229 226 225 226 223 227 226 229
   228 225 224 225 230 223 223 231 242 224 221 220 220 223 232 235 228 223 224
   223 219 239 224 222 227 226 235 229 222 223 223 219 222 222 221 224 219 231
   228 226 228 227 221 221 224 227 228 227 229 226 224 226 224 228 232 226 229
   225 222 225 220 223 222 220 222 221 220 222 219 221 222 220 221 222 224 410
   222 222 222 225 228 222 221 222 219 222 223 219 222 223 221 222 220 222 222
   220 223 221 221 221 220 226 221 219 224 265 259 261 230 261 256 252 181 221
   226 223 218 221 220 223 218 222 219 218 219 219 217 214 216 215 216 226 217
   218 216 215 216 229 219 217 213 222 229 222 217 219 216 214 176 221 222 212
   216 218 215 217 213 216 217 215 216 218 216 220 215 229 220 216 219 219 219
   221 218 217 216 214 215 217 216 216 213 216 217 216 216 217 200 218 215 216
   217 220 221 218 217 221 217 216 217 213 215 218 217 215 213 217 216 214 218
   216 219 216 214 217 217 213 217 220 219 215 213 219 216 214 216 216 216 214
   214 242 241 225 223 223 221 220 221 227 224 219 220 223 220 220 219 220 221
   219 220 220 221 220 219 221 221 219 221 221 222 221 218 222 220 219 219 221
   219 221 219 220 221 220 221 220 220 221 217 221 220 219 221 226 232 221 219
   222 220 219 220 221 221 220 218 220 220 220 220 221 220 219 220 221 222 218
   220 219 231 231 226 218 221 217 217 218 217 217 215 217 218 216 225 145 160
   157 135 136 137 134 136 136 135 137 133 136 136 133 142 142 139 135))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 194963 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61606640 :P50-TICKS 216 :P99-TICKS 233 :LATENCY-TICKS
 #(153 139 140 135 135 136 142 132 133 135 136 133 136 134 135 135 133 135 134
   132 140 138 170 140 135 134 143 144 143 141 144 157 147 141 137 135 135 154
   140 137 135 140 129 135 135 137 135 136 133 136 134 139 135 143 135 136 134
   135 149 141 147 141 144 144 152 143 137 135 135 138 134 135 132 136 137 135
   136 135 134 136 134 137 136 136 136 142 136 146 132 137 137 133 141 142 144
   156 138 136 137 134 135 135 135 139 125 136 135 133 137 156 153 159 151 148
   138 134 140 136 134 133 132 134 135 130 134 135 133 132 132 135 134 133 135
   142 135 134 133 134 148 138 138 148 160 134 134 136 137 132 135 137 139 134
   132 135 140 137 135 135 135 161 134 134 136 154 139 137 146 133 161 158 138
   135 136 146 136 135 134 136 136 134 145 136 135 135 133 135 136 134 142 145
   153 144 134 138 137 134 141 141 134 135 133 136 137 127 134 136 135 134 135
   136 135 134 156 151 143 137 133 151 143 147 136 138 135 135 133 137 135 134
   141 136 135 135 1610 148 137 140 135 135 134 138 142 140 136 134 135 135 135
   134 135 147 139 133 134 142 135 135 133 136 139 137 136 140 160 139 137 140
   134 134 136 134 136 135 135 136 137 134 137 137 135 139 134 144 145 135 138
   136 136 138 137 138 138 135 136 138 137 136 138 151 136 134 137 136 136 136
   133 134 135 133 139 135 134 134 139 143 135 133 134 135 135 133 133 135 134
   133 133 135 133 133 133 136 135 134 135 133 134 134 132 134 136 133 133 134
   134 137 132 134 146 133 135 139 149 143 133 136 136 134 136 135 135 135 138
   135 149 134 136 136 136 139 133 135 135 134 146 137 138 149 148 145 209 223
   219 220 218 218 215 218 218 215 218 217 215 215 215 218 217 215 217 217 228
   217 214 217 216 215 216 215 216 215 216 217 217 216 216 216 216 215 215 217
   220 216 217 216 215 215 215 216 217 214 216 218 216 218 213 216 216 221 219
   216 216 219 216 217 217 216 217 218 224 208 226 225 222 219 222 220 221 218
   219 221 220 220 220 221 219 219 218 219 219 218 220 223 220 219 217 225 231
   219 219 221 219 221 219 220 220 218 219 220 218 221 224 222 187 226 224 226
   221 228 228 230 229 229 231 229 228 229 230 230 230 247 225 222 220 219 216
   221 219 217 219 220 222 218 217 220 219 217 220 219 218 220 220 220 220 221
   220 221 218 220 217 221 223 217 195 222 220 221 219 221 220 219 223 222 222
   219 223 221 221 219 219 221 222 220 218 220 228 223 225 222 252 223 218 220
   222 218 218 220 220 219 189 227 220 218 220 221 218 235 233 223 220 220 221
   221 219 220 218 223 225 221 221 224 224 220 217 215 221 219 225 227 221 224
   217 235 220 225 225 222 220 222 218 220 221 219 198 229 224 221 221 223 221
   221 210 218 223 223 221 223 221 233 205 160 226 224 224 228 221 221 225 193
   157 182 218 218 221 226 222 226 224 225 221 222 220 221 219 222 220 220 222
   222 225 172 202 168 216 169 197 223 230 226 227 224 224 227 225 227 224 225
   223 222 228 227 226 226 226 224 203 218 226 223 223 224 228 193 223 197 224
   227 224 226 223 219 221 218 228 223 202 223 227 187 207 226 222 206 227 230
   180 236 226 222 225 225 223 226 225 224 225 222 219 220 221 222 225 218 224
   515 229 218 216 219 218 216 217 217 218 216 214 216 218 218 215 216 216 217
   216 228 219 216 216 219 225 217 215 218 224 226 222 220 219 219 222 221 220
   218 220 223 221 219 214 220 219 226 222 218 220 228 222 216 215 218 216 216
   215 216 213 223 221 218 219 221 218 218 208 226 225 218 225 223 225 223 217
   222 228 233 221 217 215 216 213 218 231 215 216 217 216 217 215 215 217 217
   215 217 215 216 214 217 216 215 223 215 226 221 218 222 222 225 222 220 226
   208 230 232 228 222 220 216 215 215 216 218 217 214 217 219 231 207 216 220
   218 216 216 217 215 216 214 217 216 214 216 218 216 215 216 216 216 215 215
   217 215 218 215 216 216 214 214 217 214 215 213 221 219 215 215 217 215 216
   215 216 216 217 216 217 214 216 215 216 216 214 217 218 215 215 214 216 215
   215 215 216 214 215 216 219 218 215 216 215 216 216 213 216 219 215 216 216
   216 215 215 217 216 214 219 216 215 216 213 217 216 215 214 220 218 216 213
   216 216 215 215 216 216 216 216 217 215 216 216 216 216 214 213 216 220 214
   215 217 215 217 154 217 215 214 214 219 216 215 214 216 215 215 215 216 214
   218 213 215 215 214 214 216 215 215 214 231 241 222 222 222 221 221))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 228342 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61546688 :P50-TICKS 220 :P99-TICKS 235 :LATENCY-TICKS
 #(272 232 229 223 223 223 221 226 220 222 221 222 223 225 222 221 220 224 226
   221 221 222 220 221 218 221 181 224 221 226 176 220 224 230 220 231 229 225
   221 227 223 231 250 234 225 231 232 231 235 229 228 220 221 221 221 221 221
   221 220 219 222 222 219 219 220 221 222 219 224 221 221 219 219 220 220 219
   263 221 220 220 218 220 220 217 221 219 233 231 221 222 221 220 220 221 220
   219 221 221 221 220 1560 227 222 223 219 222 222 219 221 222 221 221 219 221
   221 219 222 221 221 159 222 220 222 223 221 222 221 220 219 220 223 220 220
   221 220 220 219 220 223 218 223 220 221 220 218 221 221 218 220 222 229 227
   220 222 220 219 220 221 220 219 220 221 221 218 221 221 219 219 219 223 222
   221 218 225 222 230 225 228 223 218 213 224 222 225 223 221 221 218 219 220
   221 219 218 221 220 217 218 220 220 219 220 221 219 218 221 222 219 219 218
   220 228 220 220 219 220 219 219 223 224 163 226 225 224 225 220 219 221 218
   219 220 221 211 221 220 220 219 219 220 221 219 223 230 230 219 220 220 219
   219 217 220 221 220 223 224 221 219 225 224 220 219 161 220 218 220 219 220
   219 218 220 224 224 218 219 225 220 218 220 220 219 219 219 220 221 218 220
   219 219 219 217 220 224 218 219 220 220 221 217 165 221 218 223 221 219 219
   217 220 220 217 219 220 222 219 217 219 220 217 219 219 219 219 221 220 219
   217 219 219 221 219 219 221 222 218 220 223 218 219 219 221 219 218 223 219
   219 219 217 223 228 164 227 229 230 221 218 232 222 226 221 226 228 226 223
   224 230 224 224 228 225 222 231 233 227 226 230 214 226 221 227 226 224 224
   230 227 228 225 220 222 221 222 226 223 223 223 228 222 230 223 231 231 224
   224 223 223 226 230 226 222 223 228 215 225 224 177 220 223 224 227 230 223
   221 225 230 223 227 230 219 224 225 230 228 179 223 222 220 222 221 222 253
   252 228 230 225 235 228 193 220 218 217 217 217 216 216 215 215 216 220 217
   214 225 226 203 250 233 221 220 219 221 220 220 220 221 218 220 218 220 221
   227 226 225 221 220 219 222 221 220 221 221 220 222 218 221 224 219 222 220
   220 220 218 224 221 218 219 221 219 219 218 224 222 229 225 232 231 224 232
   225 231 224 236 230 235 225 230 208 227 219 220 221 223 220 218 222 221 218
   220 221 223 220 222 220 221 219 221 221 219 219 218 219 220 219 220 221 219
   219 219 220 220 218 222 219 221 219 218 220 219 217 221 219 222 219 218 220
   220 218 221 220 220 219 221 220 222 218 221 220 220 219 217 221 224 218 220
   221 221 219 218 220 225 219 223 219 220 219 218 220 220 218 219 220 221 219
   217 221 220 217 220 221 219 219 221 220 219 218 220 219 219 221 217 220 223
   217 221 219 220 219 218 221 221 218 223 220 220 219 218 220 221 218 221 219
   224 219 218 219 220 219 219 219 218 220 221 220 220 218 220 219 219 218 218
   220 224 218 219 220 220 219 218 221 219 218 224 220 219 219 218 220 220 219
   220 220 222 219 218 219 220 219 219 219 220 219 214 220 221 218 219 221 220
   219 217 221 222 218 219 220 218 219 219 205 225 221 218 220 228 225 219 220
   220 218 221 220 219 220 218 221 220 219 220 221 222 221 218 220 220 217 219
   220 219 219 220 220 219 216 220 220 219 219 221 217 224 217 219 220 219 219
   218 220 221 220 220 221 220 219 218 222 220 218 210 225 219 221 219 221 221
   219 219 221 220 222 218 221 221 220 220 221 220 219 218 222 221 218 220 220
   220 220 218 221 220 220 220 219 220 219 218 220 222 218 221 222 220 220 219
   220 221 219 220 222 221 222 218 221 220 220 220 220 219 217 226 226 221 218
   220 221 219 219 218 221 221 222 218 222 220 219 217 221 222 227 225 223 219
   219 218 220 220 219 220 221 226 222 217 220 220 218 221 220 219 227 223 222
   224 218 220 219 228 222 219 221 222 218 220 219 221 219 218 220 220 217 222
   220 220 218 218 169 223 218 220 220 222 219 218 220 220 219 219 220 221 218
   224 221 220 218 219 219 220 218 218 220 221 218 224 224 221 220 218 219 222
   218 236 219 219 229 234 221 218 215 217 218 221 220 217 217 218 215 217 216
   218 216 217 218 216 214 216 217 215 215 215 217 219 214 217 217 215 217 215
   218 216 215 221 216 216 216 215 217 218 215 216 217 218 216 214 217 225 215
   216 217 216 215 215 1549 221 216 218 219 215 216 214 217 216 214 216 217 216
   219 213 215 219 215 218 216 216 216 215 216 217 214 217 216 215 215))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 226577 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61606704 :P50-TICKS 220 :P99-TICKS 243 :LATENCY-TICKS
 #(215 217 217 216 216 216 216 215 214 220 215 215 216 216 217 215 215 217 217
   218 216 216 216 216 214 217 215 215 223 221 216 216 212 217 216 214 217 217
   215 216 215 216 217 214 215 217 216 214 214 217 218 215 215 216 215 219 215
   216 216 215 218 216 215 215 214 217 216 214 215 216 217 215 214 217 218 213
   217 216 215 216 219 217 215 216 215 216 217 215 214 217 220 217 216 216 214
   216 213 217 217 214 217 218 216 215 217 217 216 213 216 216 215 221 213 216
   216 215 216 217 216 215 214 220 217 214 216 217 215 216 213 216 217 217 218
   216 216 214 213 217 217 215 217 220 215 216 215 217 217 215 217 217 215 218
   214 218 216 216 217 216 217 217 214 218 220 212 217 216 216 216 215 217 216
   218 217 220 217 215 213 217 221 232 233 224 220 224 219 223 222 219 221 222
   219 220 220 222 222 220 219 221 220 222 218 221 222 221 221 221 220 220 218
   221 220 219 223 221 219 220 218 219 220 217 219 221 222 220 227 222 221 219
   221 220 219 223 217 221 220 219 220 219 220 219 216 223 222 218 219 220 220
   219 217 221 222 220 221 220 219 218 218 221 221 219 220 221 221 218 218 220
   221 218 220 221 218 218 219 220 220 218 220 221 219 219 217 221 225 218 219
   221 219 218 217 221 220 220 221 220 220 218 217 221 221 217 220 220 221 218
   217 220 220 218 219 221 219 220 220 221 220 219 220 221 219 219 218 222 222
   218 220 221 221 218 218 220 222 218 221 220 219 219 217 232 223 222 226 236
   222 231 226 204 225 220 222 221 221 222 218 221 220 219 221 230 224 224 221
   225 222 219 227 225 224 222 219 222 222 222 221 222 219 220 218 221 221 218
   221 224 220 220 220 220 222 213 223 221 220 218 221 220 220 218 220 224 226
   220 217 234 223 222 225 222 220 220 219 221 220 221 220 221 221 223 221 223
   221 219 221 222 220 220 218 221 222 220 220 221 228 225 220 222 221 219 221
   223 220 222 220 223 220 219 220 220 226 222 219 223 223 228 233 223 219 220
   219 221 221 219 227 220 219 219 217 221 219 219 222 221 222 219 218 221 220
   218 220 219 221 219 221 227 227 219 220 219 220 220 218 220 223 220 220 220
   218 222 221 222 220 218 223 220 219 219 218 219 220 217 219 220 222 219 218
   220 219 218 219 220 221 217 223 223 221 219 220 221 220 219 218 221 224 218
   219 221 220 220 218 221 221 219 223 220 222 220 219 221 220 219 221 221 223
   220 217 221 220 222 220 220 219 219 224 220 221 218 220 221 218 219 217 221
   223 217 219 220 219 218 217 220 219 217 222 220 219 219 216 220 220 217 219
   219 224 225 207 227 224 219 221 222 219 220 222 223 220 221 221 221 219 221
   219 221 222 220 220 220 220 165 225 221 222 219 224 221 220 220 219 222 221
   219 221 221 224 221 218 220 221 219 220 220 243 221 221 220 221 219 220 220
   219 219 218 221 228 227 223 223 222 224 220 223 221 219 223 220 220 220 218
   223 221 222 222 221 222 220 218 239 236 222 222 222 221 221 220 222 219 220
   221 221 220 219 219 221 223 219 220 222 220 220 219 171 221 219 226 222 221
   220 220 221 220 219 219 221 222 220 217 221 222 219 220 221 220 221 221 222
   222 219 224 228 230 256 248 232 262 243 236 250 243 245 231 230 239 246 220
   221 222 220 224 222 221 219 221 221 220 220 218 220 222 221 218 222 220 220
   218 221 219 219 223 222 220 220 217 221 221 218 220 220 223 220 217 220 220
   218 220 221 219 219 221 220 221 218 221 222 220 219 218 221 223 218 220 220
   220 220 217 222 220 218 223 220 220 220 217 220 221 218 219 220 221 220 220
   222 219 219 220 220 219 218 222 220 220 217 219 219 219 219 216 221 222 219
   220 220 270 224 218 221 223 218 222 220 218 219 217 219 220 216 219 218 223
   219 219 219 221 218 218 1528 223 220 218 218 219 218 223 219 219 218 217 218
   219 217 221 221 222 220 218 219 220 218 219 221 219 219 220 220 220 216 219
   221 220 219 218 221 223 219 221 324 228 220 217 218 218 216 218 216 216 216
   214 217 217 214 216 217 217 216 214 217 217 215 216 216 216 216 218 217 216
   215 216 217 205 217 215 218 220 215 216 217 216 216 215 217 217 228 234 223
   222 221 219 222 222 220 222 222 226 222 218 222 220 220 222 220 220 221 222
   222 221 219 220 221 220 219 218 221 226 220 221 220 220 220 219 221 221 220
   225 220 221 220 219 220 224 220 221 220 221 219 218 221 221 219 220 220 220
   220 220 222 222 220 221 222 221 221 220 220 228 220 219 221 221 221))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 0 :VALUE-BYTES 60000
 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 227795 :TICKS-PER-SECOND 1000000
 :CLIENT-ALLOCATED-BYTES 61606704 :P50-TICKS 220 :P99-TICKS 256 :LATENCY-TICKS
 #(226 229 223 219 220 221 220 220 202 226 230 219 220 232 222 222 224 226 221
   219 220 220 221 219 218 225 223 218 219 176 225 222 220 222 221 220 230 225
   228 224 219 222 221 219 193 215 222 220 218 222 222 219 225 225 221 220 218
   220 221 222 223 225 220 224 219 221 220 221 221 221 221 227 223 221 222 218
   220 221 220 220 218 225 220 218 221 221 220 219 218 221 221 223 222 221 221
   220 218 221 220 219 221 223 220 222 220 221 222 219 222 224 223 220 219 220
   221 226 225 227 221 221 219 230 224 219 220 232 220 218 223 222 218 215 217
   216 217 216 210 224 221 217 216 217 215 217 214 219 218 218 218 217 216 216
   218 217 224 227 217 220 218 219 220 223 218 216 218 217 215 220 215 216 217
   216 223 220 217 216 216 218 218 215 216 217 215 216 213 217 218 214 217 215
   218 218 213 217 216 215 216 217 215 215 214 217 216 214 216 217 215 214 219
   216 217 214 218 217 215 216 214 222 220 215 216 219 216 218 215 217 216 215
   220 217 217 225 215 222 216 216 216 217 218 216 215 218 216 216 216 217 215
   215 218 219 217 215 217 216 216 217 215 216 218 217 217 217 215 219 213 216
   206 215 216 223 217 215 215 216 217 216 216 216 214 219 214 217 222 216 216
   217 216 216 213 220 217 215 216 215 215 215 214 216 216 216 215 215 214 215
   214 217 216 215 215 218 216 215 213 216 216 213 215 216 214 215 215 216 216
   214 217 217 220 216 212 216 216 214 214 216 218 217 214 217 216 214 218 217
   215 217 214 243 238 235 229 235 259 231 262 234 245 231 222 222 221 222 219
   222 221 220 220 225 223 223 218 221 223 220 221 220 220 223 218 221 221 218
   220 221 220 220 217 225 222 219 220 221 220 217 217 221 220 222 221 221 220
   220 218 221 222 218 221 225 225 219 219 222 222 219 220 220 219 223 218 221
   219 219 220 220 220 220 218 224 220 219 220 221 220 220 218 220 221 220 220
   220 220 219 218 222 221 217 218 225 219 219 217 221 220 218 219 220 219 221
   218 221 219 218 219 219 219 219 217 223 219 217 221 221 219 220 218 221 219
   221 219 220 219 218 218 221 220 218 220 223 218 221 218 220 221 217 220 220
   219 219 217 220 220 218 221 220 219 220 219 208 227 221 220 220 220 221 219
   221 220 222 220 221 219 220 218 220 222 218 220 223 220 221 219 220 221 219
   219 222 221 222 219 222 220 218 221 219 220 219 220 223 220 218 219 220 219
   218 218 220 220 219 220 221 220 219 218 220 220 218 220 223 220 219 218 222
   219 218 219 220 219 223 218 221 220 219 219 220 220 219 218 226 228 220 219
   220 219 220 218 220 221 221 221 220 220 219 216 219 220 219 218 223 219 219
   218 220 221 217 220 220 220 219 217 219 219 217 220 220 219 218 217 223 219
   218 219 220 218 219 217 220 219 220 220 219 220 219 221 220 220 219 218 224
   218 219 218 219 221 219 221 220 220 222 217 220 221 216 220 219 227 223 215
   223 221 215 216 216 216 215 213 218 216 218 216 218 216 216 214 216 218 214
   217 219 217 216 214 216 217 214 215 217 215 219 215 217 217 216 217 217 216
   217 214 224 247 253 229 252 239 240 227 237 246 256 228 237 264 238 232 223
   224 219 221 222 221 222 218 1576 232 222 222 221 220 220 217 221 222 219 221
   219 220 220 218 220 220 231 230 226 220 223 223 221 222 219 222 225 222 219
   219 222 300 226 221 222 220 223 219 222 221 220 220 220 220 220 219 224 220
   218 220 220 219 218 219 220 223 220 219 221 220 219 218 220 221 221 220 227
   222 225 222 222 221 219 220 227 225 222 219 220 222 218 219 221 219 219 218
   223 220 219 220 220 220 221 218 214 224 222 220 221 221 221 218 222 221 221
   219 228 221 220 218 220 225 220 220 221 220 222 222 223 220 219 220 220 220
   220 220 225 222 220 223 220 220 223 218 220 223 219 220 221 223 225 223 226
   226 222 224 222 225 224 223 227 232 161 234 228 228 226 231 272 249 229 252
   233 237 246 234 244 247 233 322 233 251 230 233 254 243 244 227 247 245 251
   228 249 273 246 251 244 248 220 240 237 256 220 221 221 220 219 219 221 221
   220 217 222 219 219 221 223 220 219 222 220 222 223 218 220 220 218 219 220
   220 219 223 223 228 217 298 241 259 223 221 219 220 234 221 221 220 219 219
   221 224 223 220 222 223 220 220 222 223 219 221 224 221 220 219 220 221 220
   219 221 219 223 219 222 220 219 221 222 220 224 220 222 222 225 223 220 221
   221 225 222 220 222 222 221 220 219 218 220 221 217 221 225 220 219))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 0 :OPERATIONS 1024 :WALL-TICKS 221437 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61606592 :P50-TICKS 220 :P99-TICKS 237
 :LATENCY-TICKS
 #(139 154 139 141 141 144 159 136 135 138 138 136 138 143 136 147 159 156 141
   146 144 149 150 137 147 163 141 144 150 146 143 145 144 143 143 138 146 145
   138 150 136 156 133 138 136 138 140 229 223 222 223 163 222 223 222 222 219
   221 220 217 220 222 219 219 220 221 221 222 219 220 220 218 219 219 221 218
   219 222 220 218 216 222 221 217 221 220 219 220 218 222 219 218 219 220 219
   219 217 221 219 216 219 221 218 220 218 222 219 219 219 225 228 220 217 220
   220 218 218 223 219 219 219 223 220 218 219 220 220 222 217 219 219 219 224
   221 220 229 219 220 220 217 219 219 219 218 221 220 220 224 223 221 219 218
   220 222 220 216 217 221 220 220 220 221 224 218 222 219 219 224 217 219 219
   220 223 221 218 218 217 224 220 217 220 226 223 227 220 228 230 229 221 220
   218 219 218 219 219 217 219 221 219 217 222 220 221 217 219 220 219 222 217
   222 219 217 219 219 219 221 219 223 219 218 219 218 218 221 218 219 222 219
   219 219 217 218 216 219 218 225 223 220 222 219 217 220 218 217 218 223 218
   218 217 218 219 217 218 218 217 218 217 218 218 217 240 219 219 219 217 221
   219 217 218 219 219 218 217 220 220 219 218 220 217 218 217 220 219 218 217
   222 218 218 216 220 220 217 218 220 217 221 217 219 220 216 219 219 217 217
   218 223 219 217 218 218 216 218 216 219 219 219 220 223 218 218 217 221 220
   216 216 223 218 218 217 219 219 218 218 220 218 222 220 220 220 217 218 219
   219 218 216 223 220 217 218 219 218 218 217 224 220 220 218 219 218 218 218
   219 219 218 218 229 219 218 218 219 219 217 218 219 221 220 217 220 219 216
   219 220 218 219 217 222 219 219 218 218 219 219 217 220 219 220 219 219 218
   218 217 219 222 216 220 222 219 218 216 224 224 217 230 228 223 235 226 225
   222 220 220 222 221 220 225 199 141 137 137 139 136 139 137 137 139 136 138
   138 137 136 136 144 137 135 136 139 129 147 137 137 139 135 138 137 136 140
   135 180 228 222 223 225 222 221 219 221 222 221 221 222 219 222 217 220 221
   219 221 223 221 219 217 221 229 220 222 221 220 222 219 220 223 221 223 221
   219 223 217 226 220 218 220 220 220 218 217 220 220 2137 222 229 221 218 218
   220 220 218 218 218 220 218 217 219 221 217 220 220 218 219 220 219 219 217
   218 224 221 219 217 221 222 218 218 220 219 219 217 220 221 216 222 220 219
   218 218 219 220 218 218 219 220 218 217 221 218 217 218 221 221 218 227 224
   224 218 218 219 219 221 218 219 222 217 219 219 218 219 217 218 218 216 211
   220 218 218 217 219 220 217 219 220 220 218 217 219 219 217 218 220 219 222
   219 224 219 218 219 219 219 220 217 221 223 219 225 222 219 222 218 227 226
   217 218 221 219 218 226 224 220 218 223 224 219 228 221 221 219 217 219 219
   221 218 217 219 219 217 218 219 218 218 220 219 218 225 225 223 219 218 217
   219 229 218 222 222 197 221 219 229 224 214 223 242 225 231 229 225 235 222
   233 232 232 240 180 230 226 230 227 215 227 208 227 224 225 170 241 233 222
   219 226 235 229 231 220 232 237 234 229 231 230 229 240 239 221 229 229 232
   233 217 227 233 212 144 222 193 227 233 227 237 222 227 179 216 232 230 189
   234 223 228 226 225 226 215 226 235 217 233 228 229 154 232 229 222 226 229
   221 231 221 229 232 188 221 212 231 232 235 224 226 233 224 227 227 223 227
   233 232 191 237 204 227 152 235 230 230 172 224 231 221 231 192 179 234 229
   227 162 217 231 236 228 236 214 228 220 223 225 219 224 226 221 222 206 224
   227 205 220 224 226 230 218 199 227 224 217 218 229 225 226 240 235 247 229
   229 223 227 221 223 231 220 224 229 223 226 187 224 223 222 224 223 227 168
   230 219 226 224 223 221 224 219 214 223 224 226 227 225 221 224 219 222 226
   227 216 222 215 226 228 224 222 222 231 220 221 230 224 223 229 232 208 224
   226 221 227 223 222 220 221 166 222 218 226 217 174 223 220 220 232 229 235
   176 224 226 140 236 222 226 222 220 236 234 221 190 224 224 222 220 221 218
   223 219 225 233 230 219 229 221 222 230 220 233 222 222 221 223 220 225 223
   223 228 223 225 221 228 219 226 223 225 220 223 227 221 219 224 222 220 222
   225 223 222 222 223 221 221 219 191 221 223 222 224 223 225 220 225 225 219
   226 221 223 220 222 223 228 220 223 220 219 221 219 224 225 219 222 229 220
   226 218 225 219 219 230 221 221 221 221 223 222 222 224 225 223 231))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 1 :OPERATIONS 1024 :WALL-TICKS 226222 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61606608 :P50-TICKS 221 :P99-TICKS 233
 :LATENCY-TICKS
 #(237 231 226 232 222 219 223 223 217 214 231 223 223 222 219 221 230 202 227
   217 223 224 223 227 218 226 224 232 218 221 230 222 222 226 228 222 225 218
   208 221 220 226 224 231 220 227 228 223 225 228 223 222 220 225 224 208 205
   171 223 209 224 226 223 223 220 208 225 217 229 224 228 218 227 224 181 219
   221 222 216 224 223 218 226 227 225 149 223 224 225 223 226 224 224 226 195
   223 218 222 210 205 225 226 231 226 218 224 215 224 225 222 226 218 219 231
   221 221 224 226 213 233 206 224 230 227 226 224 199 227 223 175 221 220 227
   231 212 226 217 211 234 225 219 225 213 230 223 228 222 225 224 224 218 224
   213 228 223 222 224 223 234 212 218 223 222 228 225 228 219 221 226 224 201
   219 150 170 222 207 209 224 226 220 224 225 231 227 210 222 227 227 216 221
   202 230 215 224 220 217 187 226 220 223 220 209 217 214 218 228 223 218 221
   220 222 224 224 224 218 227 221 220 219 217 221 223 224 221 221 222 224 222
   211 218 220 224 220 225 221 218 225 223 221 219 227 233 230 222 220 218 219
   210 223 217 231 223 220 219 229 220 225 218 224 223 222 223 199 227 218 227
   224 215 236 219 221 201 232 220 224 223 223 221 224 225 222 228 233 225 228
   223 212 224 207 224 220 223 223 214 223 226 224 225 229 225 219 231 222 212
   206 225 200 202 223 222 223 233 223 226 228 217 217 223 226 222 138 223 221
   198 230 200 220 220 216 187 223 219 220 175 223 230 228 222 226 222 222 219
   226 227 218 226 223 146 224 223 213 199 218 222 222 221 224 219 212 229 209
   223 233 217 220 220 223 222 217 225 220 217 216 223 233 1721 221 223 209 224
   225 223 223 221 219 216 223 208 226 228 226 219 221 227 218 217 220 223 225
   219 219 226 226 223 220 229 220 224 194 220 222 221 224 223 220 217 219 224
   224 219 236 221 229 227 222 224 224 227 222 203 222 225 226 228 221 216 215
   210 224 222 218 218 225 211 141 219 219 222 213 214 221 220 219 221 219 219
   226 225 229 223 220 228 226 221 225 225 227 217 224 224 228 177 219 223 213
   220 227 229 219 190 219 211 226 220 223 226 216 227 214 221 217 218 215 220
   217 220 215 221 221 218 217 221 219 226 219 219 207 222 208 218 216 216 215
   219 217 221 222 218 221 218 220 227 222 213 219 220 212 220 219 220 222 217
   227 224 218 207 216 229 226 209 225 223 218 224 225 222 225 217 222 222 226
   207 177 230 221 222 221 223 226 221 218 226 226 217 221 216 227 222 221 209
   222 222 220 222 223 222 220 222 219 218 224 220 221 223 214 217 219 222 220
   184 182 228 222 230 180 203 223 163 231 223 227 217 222 144 225 230 221 217
   218 215 222 222 218 223 206 224 220 172 217 219 220 200 229 221 216 224 221
   218 225 220 217 213 220 170 222 221 220 221 217 220 218 220 222 218 226 220
   218 220 217 220 221 217 219 220 219 217 217 220 219 217 216 218 218 220 218
   218 218 216 217 221 218 218 232 224 222 218 223 221 221 220 219 220 220 218
   242 224 221 218 223 221 222 219 226 221 223 225 155 233 221 220 234 230 230
   224 224 223 226 222 219 225 223 226 221 221 192 232 227 221 217 221 220 221
   210 222 228 233 219 218 220 224 217 218 223 228 226 228 223 154 222 223 224
   208 229 223 220 209 221 219 223 204 225 217 221 219 222 223 217 221 224 225
   221 222 224 217 225 225 220 224 224 217 231 221 217 221 225 223 217 219 219
   218 220 219 219 223 220 221 222 217 220 219 218 219 218 220 220 219 215 222
   221 218 219 220 221 218 222 220 222 220 222 200 228 220 222 227 227 228 221
   224 225 222 223 214 224 228 222 231 224 223 200 221 222 222 227 223 224 236
   234 226 220 228 221 226 225 225 220 224 222 220 221 221 223 226 220 226 222
   224 222 220 222 217 225 219 222 223 224 220 217 217 220 225 219 217 217 221
   218 216 222 218 218 214 219 219 217 219 218 218 216 216 215 218 217 215 218
   223 217 219 215 218 222 214 217 218 216 219 216 222 220 217 216 217 217 216
   217 224 218 215 217 215 225 219 215 219 218 219 218 218 217 217 216 218 218
   216 220 223 217 219 216 217 226 218 216 218 219 219 217 218 219 216 217 217
   217 216 216 217 220 216 216 217 216 216 215 218 218 219 220 219 220 218 216
   218 218 215 216 217 220 217 218 219 217 215 220 216 215 215 217 219 217 218
   220 217 217 216 218 217 221 215 217 216 217 228 222 218 217 216 225 219 218
   216 216 218 218 215 217 217 220 217 215 218 220 215 217 216 217 218))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 2 :OPERATIONS 1024 :WALL-TICKS 196772 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61606560 :P50-TICKS 216 :P99-TICKS 226
 :LATENCY-TICKS
 #(217 219 217 216 216 217 219 217 216 217 217 215 217 217 216 215 218 217 218
   215 222 220 218 216 217 217 220 215 216 218 215 216 216 217 216 215 217 219
   215 215 215 220 219 216 217 217 217 217 215 217 219 217 215 217 216 216 216
   220 217 216 217 217 217 216 216 219 217 218 217 216 216 216 215 219 218 215
   218 220 217 217 215 221 218 215 216 217 216 219 215 216 216 214 217 217 215
   216 214 223 217 215 216 220 215 204 216 218 218 220 218 218 219 217 216 221
   217 217 217 218 218 216 215 217 217 215 217 218 216 216 217 218 218 215 217
   220 219 216 216 216 219 214 217 217 216 217 216 216 217 215 219 226 216 216
   217 217 215 217 216 221 219 218 214 218 218 215 218 216 219 216 217 219 217
   216 217 218 217 216 215 218 221 216 218 217 216 216 216 217 217 216 219 218
   217 215 215 219 218 218 216 220 222 219 215 220 218 218 219 219 217 218 218
   220 219 218 216 219 217 218 217 220 218 219 218 219 216 217 216 219 218 217
   217 220 216 218 215 219 217 219 217 219 217 220 219 218 218 1497 220 218 218
   217 215 217 215 216 216 222 215 215 214 218 216 216 217 218 216 219 215 217
   217 215 222 218 219 216 218 221 219 216 217 217 217 217 216 218 219 219 217
   217 216 216 215 218 217 218 217 222 216 217 216 218 218 215 217 217 216 217
   217 219 223 216 217 217 216 217 215 218 220 215 217 218 217 216 215 217 218
   215 218 217 216 217 215 217 217 214 217 216 220 215 215 218 217 216 216 217
   216 216 221 217 218 215 217 218 217 216 218 233 226 213 215 216 214 213 212
   215 215 214 216 215 212 214 212 213 213 211 214 214 218 213 212 214 215 211
   214 214 212 213 214 216 213 212 214 226 218 216 216 217 219 218 218 217 217
   222 226 221 219 218 217 217 219 217 217 219 220 217 217 216 217 219 217 216
   217 214 217 221 222 222 223 225 219 215 220 226 222 220 223 223 221 225 224
   223 222 225 220 220 218 216 216 217 218 216 218 217 217 215 216 217 215 218
   216 218 221 216 216 217 216 218 214 219 217 214 216 217 216 216 215 218 216
   218 217 216 216 216 215 217 217 215 221 219 216 217 215 217 221 215 216 217
   216 220 215 222 220 220 223 218 217 218 216 225 219 217 219 219 217 218 217
   223 220 221 218 220 218 217 215 218 226 222 218 225 221 218 187 225 210 218
   223 205 224 221 221 220 219 181 223 226 220 225 227 226 225 217 218 218 218
   219 223 233 229 223 221 217 220 221 216 217 217 215 219 217 220 221 216 217
   218 215 217 217 227 218 219 219 219 217 223 218 217 229 223 220 219 225 221
   218 216 218 221 219 200 221 217 217 217 217 216 217 225 218 218 219 217 216
   215 218 218 217 219 220 220 219 215 223 222 217 216 218 217 217 211 222 218
   216 218 217 217 216 216 220 218 215 217 218 217 217 214 217 218 217 217 217
   217 217 216 219 218 215 217 214 223 216 215 217 217 215 214 222 216 215 215
   217 218 214 217 216 216 216 218 217 217 215 216 216 219 217 215 219 217 216
   217 217 189 240 225 230 227 193 150 138 133 132 131 132 132 130 132 132 131
   131 131 132 143 138 146 147 155 144 133 135 132 131 138 134 132 133 131 132
   133 131 141 139 145 153 131 133 135 135 155 142 142 137 130 133 133 131 140
   132 132 115 133 117 134 121 132 132 147 138 142 132 132 132 140 154 151 156
   133 133 133 133 134 132 132 133 130 133 134 132 135 134 132 132 131 134 134
   139 136 149 137 148 162 141 143 132 133 132 132 130 130 133 131 130 132 132
   131 130 129 133 141 129 131 133 125 132 151 139 135 131 133 132 139 139 166
   156 147 133 134 132 131 131 132 133 133 130 132 133 131 132 131 132 132 132
   132 132 131 131 129 137 131 130 132 148 137 140 161 163 141 133 132 133 132
   134 130 134 136 131 132 133 133 133 132 136 133 141 154 135 137 131 132 133
   146 139 145 154 134 135 133 134 135 135 133 133 132 135 133 135 134 140 139
   135 133 132 130 147 151 162 133 135 132 132 131 134 134 131 131 134 132 132
   130 134 132 137 132 131 132 157 142 161 134 132 132 137 133 132 132 133 134
   137 132 133 134 137 137 135 133 131 133 134 133 132 134 133 133 133 155 141
   135 137 133 134 134 132 134 134 134 133 132 134 135 132 147 139 139 134 132
   136 134 133 134 134 134 157 138 134 117 132 139 138 135 132 133 133 133 131
   132 134 132 133 131 134 133 132 139 134 133 133 132 134 134 131 135 134 137
   132 131 135 137 132 134 145 147 136 133 136 135 133 135 134 134 133))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 3 :OPERATIONS 1024 :WALL-TICKS 218092 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61546672 :P50-TICKS 217 :P99-TICKS 229
 :LATENCY-TICKS
 #(148 136 134 132 133 134 132 132 131 133 135 131 133 133 132 138 131 132 133
   131 133 133 133 132 131 133 133 131 139 145 150 140 135 134 133 131 133 132
   133 132 131 133 133 131 126 136 132 136 136 133 132 131 133 133 132 134 131
   134 132 131 132 132 137 136 136 133 142 139 133 133 133 136 133 134 133 132
   133 138 133 132 131 225 218 213 214 214 213 218 215 217 216 215 216 215 214
   215 212 216 214 211 212 220 216 213 211 227 215 212 214 214 214 1567 217 214
   215 218 216 214 212 214 216 167 216 211 213 215 213 213 211 213 214 213 213
   217 214 212 236 219 218 227 221 218 215 219 219 220 221 217 219 217 218 217
   215 218 218 215 220 218 217 217 215 218 217 216 218 218 219 216 215 218 219
   216 216 217 216 221 224 218 218 217 218 217 216 221 225 229 230 224 227 227
   226 226 226 227 229 225 222 218 221 217 215 218 218 204 217 218 218 217 215
   218 217 219 218 218 216 217 217 218 218 215 216 218 220 216 215 218 220 215
   217 217 215 216 215 217 217 214 222 217 215 216 215 217 220 216 216 218 219
   218 216 220 216 219 216 216 217 216 215 219 217 215 216 217 216 217 215 217
   217 218 216 217 216 215 216 217 219 215 216 221 215 216 218 219 218 217 219
   220 217 219 214 217 218 215 216 217 216 217 216 220 217 215 216 217 216 216
   216 217 220 219 217 217 217 219 215 218 218 215 215 219 216 215 223 223 217
   217 222 221 216 219 215 217 217 215 217 218 215 217 214 218 218 226 226 219
   218 216 215 216 216 216 219 216 216 215 215 216 217 216 215 216 233 220 216
   217 217 214 216 216 216 214 219 217 217 215 216 216 217 231 225 210 228 219
   218 218 216 219 215 217 218 215 218 217 218 216 214 220 217 215 217 217 219
   216 215 217 221 216 217 219 217 216 217 224 222 217 215 222 218 217 219 217
   220 216 217 216 217 216 218 217 217 216 218 218 217 215 216 218 219 215 218
   218 217 216 216 217 218 216 218 218 215 216 213 226 220 217 218 218 217 216
   216 217 218 219 217 219 217 219 215 216 217 214 216 220 216 217 215 217 217
   215 216 217 216 220 214 216 217 214 221 216 215 215 215 219 216 214 216 217
   217 216 216 218 217 219 217 217 217 215 215 218 217 216 217 216 217 216 214
   217 216 213 219 220 219 214 217 217 216 214 216 217 217 214 214 217 218 214
   216 215 216 215 217 218 218 215 220 217 217 217 217 218 217 215 217 217 220
   216 215 216 218 215 217 217 217 216 217 217 219 214 216 217 214 215 215 216
   220 215 216 217 215 216 215 218 219 216 217 218 216 216 215 217 218 215 217
   216 217 218 214 219 217 215 216 216 217 216 214 220 217 215 215 217 216 216
   215 220 218 218 216 216 215 215 215 217 217 214 181 224 217 217 215 218 218
   216 172 225 224 218 216 217 216 215 215 217 216 215 214 220 219 215 216 218
   224 222 216 216 216 214 217 216 218 215 215 216 216 215 218 220 218 216 214
   220 224 174 218 217 220 217 219 217 217 215 216 217 216 221 218 218 220 214
   216 217 215 215 222 221 217 214 219 229 239 236 222 222 221 220 219 220 220
   221 217 219 217 217 217 221 218 219 220 218 218 216 216 219 219 218 215 218
   220 215 212 221 218 215 215 217 217 215 219 218 215 216 215 218 217 218 226
   224 218 217 215 229 221 216 220 217 219 220 215 219 218 216 218 218 217 216
   216 220 224 219 219 218 218 217 215 217 217 218 218 217 217 216 215 217 218
   216 217 218 218 226 219 220 217 214 216 217 216 215 216 217 216 215 216 217
   221 221 217 217 221 216 218 218 217 217 216 215 158 220 217 219 216 216 215
   218 217 214 217 219 216 215 214 216 216 216 215 217 217 218 214 216 217 215
   216 216 217 215 215 218 217 214 217 216 216 216 215 217 217 222 221 216 216
   217 215 217 217 213 216 218 217 215 213 216 217 215 217 217 218 216 216 217
   216 215 216 217 217 217 214 216 222 216 192 215 221 219 216 217 219 217 219
   218 217 215 214 219 219 215 217 216 223 215 216 217 216 214 216 216 216 218
   214 218 216 214 216 216 215 216 185 218 221 216 217 217 217 216 215 216 218
   215 218 216 217 216 216 217 218 221 214 223 217 220 219 218 218 215 217 216
   219 216 219 222 219 216 218 217 217 217 217 220 218 217 218 218 217 219 217
   218 219 217 218 219 216 217 215 219 219 216 217 222 226 217 216 219 217 216
   217 217 217 220 216 219 219 218 218 180 220 217 215 222 218 216 1500 231 222
   219 216 220 219 217 221 222 218 222 153 222 219 217 222 221 217 218))
(:KIND :CACHE-UNIX-SAMPLE :MODE :PAGED :VERSION 2 :BUDGET 4194304 :VALUE-BYTES
 60000 :REPETITION 4 :OPERATIONS 1024 :WALL-TICKS 223753 :TICKS-PER-SECOND
 1000000 :CLIENT-ALLOCATED-BYTES 61606704 :P50-TICKS 217 :P99-TICKS 228
 :LATENCY-TICKS
 #(217 219 218 216 216 218 216 231 228 223 221 215 218 223 220 218 217 222 218
   216 218 219 218 217 216 219 218 217 222 217 218 218 216 219 219 217 218 218
   220 218 219 215 220 224 203 220 217 217 220 219 218 216 218 219 217 216 215
   218 219 216 218 220 217 217 216 219 218 215 221 176 222 217 216 218 218 215
   217 218 219 218 215 218 218 215 216 218 217 217 218 217 217 215 217 217 217
   216 215 218 220 217 217 218 218 216 216 218 217 216 219 220 216 216 216 218
   217 215 221 217 216 216 214 181 222 216 217 217 217 216 215 221 217 215 216
   218 217 216 215 218 218 217 217 218 216 216 217 220 219 217 217 221 218 216
   216 219 218 216 217 217 217 218 216 218 218 215 218 217 217 217 215 220 219
   215 218 216 217 216 217 219 218 218 218 218 218 216 216 218 219 215 217 222
   217 218 216 217 219 216 219 219 218 220 216 218 216 215 217 218 215 216 215
   221 216 214 217 217 217 216 218 221 217 218 220 218 217 217 216 218 218 216
   218 220 218 218 216 217 218 216 218 218 217 219 217 219 220 215 217 218 217
   217 215 218 218 217 216 221 217 216 217 218 218 214 220 218 217 216 216 217
   217 215 217 217 224 217 216 217 217 216 217 219 217 217 218 218 218 216 217
   219 217 215 216 217 219 216 217 218 216 218 215 218 217 216 220 216 216 217
   215 218 218 214 218 217 219 216 216 217 217 214 218 218 217 217 217 220 217
   216 217 218 217 217 217 216 217 217 217 217 218 217 216 217 217 215 217 218
   216 216 214 218 218 216 218 217 216 218 216 218 218 216 217 217 216 216 216
   220 218 215 216 218 218 216 215 218 217 219 217 218 233 239 241 226 223 220
   219 221 220 217 218 219 219 216 222 217 218 220 217 218 219 216 218 218 218
   218 217 220 218 217 218 218 216 218 215 219 217 222 216 217 217 216 216 219
   218 216 218 221 217 217 216 218 217 215 218 222 225 219 217 219 219 216 217
   223 159 224 216 218 219 216 218 219 217 217 217 223 222 222 223 220 217 217
   218 219 218 219 218 219 219 217 216 219 219 216 217 220 218 218 216 219 218
   217 217 218 217 218 217 217 219 215 217 218 218 218 217 224 218 215 217 218
   217 217 213 219 219 217 217 217 217 218 216 240 219 216 217 221 216 216 216
   217 216 215 217 218 217 219 218 219 217 215 217 218 216 217 216 215 222 222
   217 217 220 217 215 218 218 218 219 216 216 215 214 218 218 215 217 215 216
   216 215 216 217 213 217 216 216 216 216 216 217 214 213 218 217 216 216 218
   221 216 216 218 215 217 216 217 218 214 219 219 215 215 215 217 216 216 216
   216 220 216 214 216 217 215 216 218 216 216 218 216 216 214 217 216 215 216
   219 218 220 215 215 218 216 216 215 219 217 215 217 217 216 216 215 215 216
   215 217 216 214 217 215 216 222 221 220 219 217 216 215 227 222 216 218 218
   215 224 218 217 217 218 217 217 216 216 215 216 217 215 215 219 216 216 215
   216 218 214 215 217 215 218 218 231 191 216 216 216 218 220 217 217 217 217
   216 217 216 216 214 216 220 214 215 217 214 216 213 217 217 214 218 216 217
   214 214 217 217 214 215 216 218 217 215 217 216 216 217 217 216 216 215 218
   215 215 217 217 216 216 214 216 216 218 217 217 215 216 214 217 216 216 215
   220 215 217 214 217 216 215 217 217 216 220 215 216 218 214 216 215 216 215
   214 221 217 215 216 216 216 215 215 217 217 216 217 217 217 215 214 217 216
   215 216 220 216 216 215 217 217 216 215 219 216 217 217 216 217 215 216 217
   215 217 215 217 217 214 216 216 216 215 216 217 217 215 220 217 215 215 215
   216 223 230 223 218 218 216 215 217 218 214 216 221 216 215 222 221 217 228
   222 221 217 217 216 218 220 216 217 217 216 217 215 217 216 218 222 218 216
   216 215 218 218 215 217 220 219 217 215 219 219 216 218 217 218 217 1534 225
   219 216 221 218 218 217 217 220 218 216 217 217 217 221 216 224 229 220 217
   220 216 219 220 218 218 215 219 217 217 217 215 219 218 218 218 217 217 216
   215 218 217 215 217 220 217 220 214 219 218 215 216 217 217 218 216 217 216
   216 218 217 216 216 215 220 217 216 217 218 216 215 216 218 218 218 216 218
   224 179 218 218 217 215 216 220 215 217 216 217 216 214 217 223 228 219 217
   219 217 219 220 219 215 216 217 217 219 216 215 216 215 216 215 216 219 226
   224 217 218 220 216 217 216 216 217 218 214 216 214 216 217 214 216 217 217
   220 214 216 217 214 218 218 216 215 214 220 218 214 217 215 216 215))
(:KIND :PRODUCTION-LOCAL-TESTS :STATUS :PASSED :TESTS 18 :ROOT #A((55) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/\") :RETAINED NIL :PROCESSES ((:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-101\") :ROLE :SERVER :PID 85122 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-101/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v1-101.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--record-cache-budget\" #A((7) BASE-CHAR . \"4194304\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v1-101.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 1.71727d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/001-v1-server-101.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/001-v1-server-101.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 85122) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-102\") :ROLE :SERVER :PID 85132 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-102/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v1-102.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--record-cache-budget\" #A((1) BASE-CHAR . \"0\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v1-102.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 1.627951d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/002-v1-server-102.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/002-v1-server-102.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 85132) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-103\") :ROLE :SERVER :PID 85133 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-103/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v1-103.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((7) BASE-CHAR . \"4194304\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v1-103.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 8.666788d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/003-v1-server-103.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/003-v1-server-103.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 85133) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v1-server-104\") :ROLE :SERVER :PID 85136 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-104/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v1-104.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((1) BASE-CHAR . \"0\") \"--version\" #A((1) BASE-CHAR . \"1\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v1-104.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 6.100676d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/004-v1-server-104.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/004-v1-server-104.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 85136) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-105\") :ROLE :SERVER :PID 85146 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-105/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v2-105.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--record-cache-budget\" #A((1) BASE-CHAR . \"0\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v2-105.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 1.858925d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/005-v2-server-105.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/005-v2-server-105.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 85146) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-106\") :ROLE :SERVER :PID 85149 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-106/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v2-106.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--record-cache-budget\" #A((7) BASE-CHAR . \"4194304\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v2-106.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 1.868691d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/006-v2-server-106.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/006-v2-server-106.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 85149) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-107\") :ROLE :SERVER :PID 85152 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-107/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v2-107.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((1) BASE-CHAR . \"0\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v2-107.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 6.224892d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/007-v2-server-107.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/007-v2-server-107.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 85152) :RESPONSE NIL) (:KIND :LOCAL-PROCESS :NAME #A((13) BASE-CHAR . \"v2-server-108\") :ROLE :SERVER :PID 85161 :ARGUMENTS (\"--noinform\" \"--no-userinit\" \"--no-sysinit\" \"--script\" #A((97) BASE-CHAR . \"/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/tools/local-server.lisp\") #A((65) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-108/\") #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v2-108.sock\") \"49494949494949494949494949494949\" \"29292929292929292929292929292929\" \"--create\" \"--index-budget\" #A((7) BASE-CHAR . \"3400000\") \"--record-cache-budget\" #A((7) BASE-CHAR . \"4194304\") \"--version\" #A((1) BASE-CHAR . \"2\")) :SOCKET #A((80) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/cache-runtime/v2-108.sock\") :STATUS :EXITED :CODE 0 :OUTCOME :PASS :EXPECTED-FAILURE NIL :STOP-REASON :CACHE-BENCHMARK-COMPLETED :DURATION-SECONDS 6.13328d0 :STDOUT #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/008-v2-server-108.stdout\") :STDERR #A((79) BASE-CHAR . \"/Users/gpicchiarelli/.arcdocdb-p3-tests/1U6ZZ8M-1TOD-0/008-v2-server-108.stderr\") :READY (:KIND :LOCAL-SERVER :STATE :READY :PID 85161) :RESPONSE NIL)) :SCENARIOS NIL :SIGKILLS 0 :CONDITION NIL :CLEANUP-ERRORS NIL :BENCHMARK NIL :POWER-LOSS-QUALIFICATION NIL)
(:KIND :CACHE-UNIX-BENCHMARK :STATUS :PASSED :SELF-TEST NIL :LIMITS
 (:LOCAL-C4 :SINGLE-SYNCHRONOUS-CLIENT :WARM-READS :CLIENT-ALLOCATION-ONLY
  :NO-LOAD-TAIL-QUALIFICATION))
(:KIND :VERIFIED-GET-DRIVER :STATUS :PASSED :DRIVER-SHA256
 \"3cf071a92dfcc3593c0c2eb1e7fa37a568dd6b1fd88aa6c37d5017a20b6ec569\" :GIT-BLOB
 \"9d87a6edae749f57d411e6b197004b8b5564857b\" :ARGUMENTS (\"--run\") :COPIED-LOGS
 16)
"
 :STDERR "" :EXIT-CODE 0 :LIMITS
 (:COMMAND-OUTPUT-IS-RAW :WALL-TIME-INCLUDES-ENTIRE-COMMAND
  :NO-AUTOMATIC-REQUIREMENT-PROMOTION))
