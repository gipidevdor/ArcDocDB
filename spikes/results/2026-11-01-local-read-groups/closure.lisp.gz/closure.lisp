(:KIND :READ-GROUP-EVIDENCE-CLOSURE :STATUS :PASSED :UNIVERSAL-TIME 4002508256
 :DRIVER-SHA256
 "b3d7e45be5dc037846aae2f13d4357815fc4e4abb63baa7280e75fe67e3508be"
 :INPUT-SHA256
 "373758d697b4c97effb4968ae329b4ae2192178da3ea36f575188654230aaea1" :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002506649-command-92693-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/analysis-self-test/conservazione.lisp"
   :SHA256 "825ff3cc31529af59d6df45a1a20b2518a001dff7c489323b76da501b487d969")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002506649-command-92693-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/analysis-self-test/report.lisp"
   :SHA256 "e1593b7cb8c8b41bfcb1ec53748fee9f07a581576a8ba9288ff834cd9e72ee88")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002506649-command-92694-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/identity-self-test/conservazione.lisp"
   :SHA256 "51517401fad2788defe613ec3d8ef50e50858e274eca8baa5fb5a6938a113041")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002506649-command-92694-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/identity-self-test/report.lisp"
   :SHA256 "81ffb97d37b2cfc45ac295eaf3fa30a4592b9c29d8bc5e5d5c3fc7ef6ead093f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002506649-command-92695-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/archive-self-test/conservazione.lisp"
   :SHA256 "09c709c7ac51b7db46f56ad684f832dba66ef7fcd3c5a5f1d9400ce89bf013dd")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002506649-command-92695-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/archive-self-test/report.lisp"
   :SHA256 "54b0f0dc068c3c23d9fbe68106786b75db6967d1125540d72dd786c776ac8a81")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002506667-command-92839-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/initial-archive-command/conservazione.lisp"
   :SHA256 "7ea4bb2f02d475aa3bc753703714fbb06aca55e2ce5b15e7834d8eb424e2980f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002506667-command-92839-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/initial-archive-command/report.lisp"
   :SHA256 "09d8ac396af25ad3926df43b2fb6eb3f3a460d172fe71b68f21acd2e7adff2a1")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002506668-command-92879-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/failed-fixture-command/conservazione.lisp"
   :SHA256 "64f33d282bf6535a37fc7d00721396acdc02cf19c72173e84541cf637ff238fd")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002506668-command-92879-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/failed-fixture-command/report.lisp"
   :SHA256 "c1bda939fba89c104ae1c9f64699e98263ac55039e9b41f81e2bee88bc7e06ec")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507798-command-98504-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/final-archive-command/conservazione.lisp"
   :SHA256 "8d7b9c3375b5535acf50dfc3a4c53406ae7e29a5641ca0038a4fafeb234f091e")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507798-command-98504-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/final-archive-command/report.lisp"
   :SHA256 "eae919c0f935fc88c900eb7a7f1609dc9bd22237e6e9ecfcacfb3302ad0872da")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507803-command-98559-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/qualification-command/conservazione.lisp"
   :SHA256 "91383d4d361fa4be5b2f0ee69b81cc03f28b075ee34cf4cf2170e78ac4ad61d7")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507803-command-98559-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/qualification-command/report.lisp"
   :SHA256 "b720197d3ebf3acb2fa3aeaed74b19ba41e033a98a5ab188f6eb8e1158a47089")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507926-command-98766-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/benchmark-archive-command/conservazione.lisp"
   :SHA256 "316a8ca1793045eb00bfa95fa66ae3475d619a7edd6778695256f495fc66198f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507926-command-98766-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/benchmark-archive-command/report.lisp"
   :SHA256 "12630785dfa489691a6bd7efad20715634b7de6a4fc5b67c1483984366078887")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507929-command-98797-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/analysis-command/conservazione.lisp"
   :SHA256 "f58854bb2d1da4859fbed4ad0cffba10af47923d0e5723e8579a9bf695076dcd")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507929-command-98797-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/analysis-command/report.lisp"
   :SHA256 "ba22e10ba6538f9cacf4af77195a3984d189c9b0cd967ff6c798098cae0d7e0a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507932-command-98826-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/identity-command/conservazione.lisp"
   :SHA256 "8ef223906dec8957a6d867a86159109c58338955ebbd1e00d563c49af5283be3")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507932-command-98826-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/identity-command/report.lisp"
   :SHA256 "3d099ffdcf77493af471abb80cad8eb7a3acbc398a7508c9e559845558ed0342")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507936-command-98865-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/printed-metrics-command/conservazione.lisp"
   :SHA256 "40ad899b7790ee25463535fbba6ac864cb519e1a498568e08bc06465845bc7ee")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507936-command-98865-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/printed-metrics-command/report.lisp"
   :SHA256 "ce7f57dc1e40f3c8a6eeea60eed1a95eb7ac44d1227eb4b3f27af60102c6c9c8")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507691-command-97995-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/ci-self-test-command/conservazione.lisp"
   :SHA256 "823aca83366899da899cc989d3298de88ff04a904e567c2a162111033dc830d5")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507691-command-97995-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/ci-self-test-command/report.lisp"
   :SHA256 "634bab10236d83ba386dabae13183b039f7ec7f24a0535b875cbf33fda19a77b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002508025-command-99152-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/final-checks/conservazione.lisp"
   :SHA256 "d820b649ff245422baa2857e113422f84ffb416f309c318806533a87437027e0")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002508025-command-99152-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/final-checks/report.lisp"
   :SHA256 "8e316e1f5fe4d095990a20c944c21f1cf35add1acce7153b1721d153c18e9e7d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002508026-command-99173-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/current-source-command/conservazione.lisp"
   :SHA256 "c00174ca4430e19a1fb1608a059e79c9db84dd9d9c527b27c0eb3a0439491ee7")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002508026-command-99173-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/current-source-command/report.lisp"
   :SHA256 "439e8330067cbe01e2800cd080cdf4f1e4f58d64684095b163027bd4d9266206")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/0/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/0/scan-4.lisp"
   :SHA256 "a0e29ce51e351ed71cc338473ee984876e957ad5d47ee88023f6a38048c5c678")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/0/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/0/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/0/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/0/scan-4.stdout.log"
   :SHA256 "a922d6aaa55045dbf217cf87e830919890129fe4a0f891ab41850261e27b6eb6")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/0/session.pid"
   :SHA256 "b442e893e3ca0a1a6e71efd264d3b653a5516fdb6ed4bf9d7610bdaa11bff1b3")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/0/stdout.lisp"
   :SHA256 "3c3e1d0db8c3c9caca1995916027d78492d2f580d5e50cdf94d4e59281dd4aed")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/1/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/1/scan-1.lisp"
   :SHA256 "664397f2d96c3148fe0cadb3e0b3b0937df6500801118d8f55c8a7a9be59a733")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/1/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/1/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/1/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/1/scan-1.stdout.log"
   :SHA256 "b092caaa4a6ff103f70b30182deec2eff6a2fba6d845f06afbf1e1d614d011dd")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/1/session.pid"
   :SHA256 "0e958bffaeb6264f10a6c82848207b1adbf7e8065289af9b7405118baaf3949f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/1/stdout.lisp"
   :SHA256 "1408b0f66ab661b8673cd350d40e192493dba517be5a2705d382c63c8438d28d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/2/scan-3.lisp"
   :SHA256 "d85ac69e7744c4cb924e8c93b1b8d5a3f2dd2e68e6e5d34d88a29f76cf929fd1")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/2/scan-3.stdout.log"
   :SHA256 "ab04459feee3aacb17ce2e7f8c0e8d11928e979b3260c186310e78bb4cd47680")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/2/session.pid"
   :SHA256 "46c23cdcb6fedd09848b528e48eed2cb27e8b57eccec9744ed442959cc6f45d3")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/2/stdout.lisp"
   :SHA256 "2e7fca2d9e2fc0d9537df579c78b038ae3c1477cd817cd40fffacbc4cda80597")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/3/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/3/scan-2.lisp"
   :SHA256 "6c907b7442a4375164d40d23172767ce219b15c9651c5d034082c0d373a39382")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/3/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/3/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/3/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/3/scan-2.stdout.log"
   :SHA256 "49db085f75f15b480c9fe8668a971086b7dc9c4a0e3f8f9b4724a7e1496f7141")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/3/session.pid"
   :SHA256 "1eddd898a29e04118b8ebb5595449b47810c2efa6bceb6eafcbcd6025bc93130")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/3/stdout.lisp"
   :SHA256 "25564bda945c2105101cc7d392d13240d14238d1a27e9acf8da5f5ae0875158d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/4/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/4/scan-5.lisp"
   :SHA256 "830cfd2b044f8b46b3ddb141fe94f9c905eed2ee47310023be11c9b0debb25c1")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/4/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/4/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/4/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/4/scan-5.stdout.log"
   :SHA256 "45e5b9f3b3461e7226f2025a36f7f48acf2f721269d28a8c15b7ae05a51ea595")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/4/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/4/session.pid"
   :SHA256 "aaa5712414ba6a8ad1e3a2045ee5bee3ec167301dd0cd52662c49e0372e50ddc")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/4/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/4/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/4/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/4/stdout.lisp"
   :SHA256 "2be099c08baa117e6464bba3c631874220ab09ec3b9d2dfa3fa3a54fb50eb69f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/5/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/5/scan-6.lisp"
   :SHA256 "fa9294fc44caa4da5cdbcce038aa09e595fe743557054a4319ba0514a8a95bb6")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/5/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/5/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/5/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/5/scan-6.stdout.log"
   :SHA256 "f48815577a1ee8ec03b903d8fa48fcb40d04e3e842cdf13eb45a3d880b1fe8ef")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/5/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/5/session.pid"
   :SHA256 "21a1fa0b2dd65a25b4f402224c1dd60515c902b5987f390f6eee2675a8810e16")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/5/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/5/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/5/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/5/stdout.lisp"
   :SHA256 "c020b7cfad97537e62a5b046c84a727494a77429c7ba3d0b3c88699d692fadea")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/6/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/6/scan-7.lisp"
   :SHA256 "439ab2155aab8648598e4f43fae5ca6c9673ecf084471349ae2ed47f25728da7")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/6/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/6/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/6/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/6/scan-7.stdout.log"
   :SHA256 "a2f56450b68570587f00969d83534e95c57d3312552b2f46188bfa6d9d6b197d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/6/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/6/session.pid"
   :SHA256 "da20a8dcf003939703540ba5ea869043bda704e2f955259b718eefae444ea65a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/6/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/6/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/6/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/6/stdout.lisp"
   :SHA256 "632ff70d8e777211e68c9c6aa18fbbacd544790316335340e811020c0820425a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/7/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/7/scan-8.lisp"
   :SHA256 "fc3ee2fa6ff608959cf22727bd4f799de37b9ee79e8ccad3fb07389a5464becb")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/7/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/7/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/7/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/7/scan-8.stdout.log"
   :SHA256 "fbbe61ef065fa2d19a5b0901bb9daca2e74b14737ce273e3f004dc87b54a7c84")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/7/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/7/session.pid"
   :SHA256 "58bc145be775993279ffdc76e352331dc8ce1327528df2cc326d772f8f2e4584")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/7/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/7/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/7/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/7/stdout.lisp"
   :SHA256 "ba7fcea75bc2864a21f3b940483384447375da9144341dee0b2be1a13f199598")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/8/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/8/scan-9.lisp"
   :SHA256 "249e141abbb7c6f41b3567214b00eb412d1c4c6684415a5551508237f96d3afd")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/8/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/8/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/8/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/8/scan-9.stdout.log"
   :SHA256 "b4b49ff4fa0a540bfbd7f0fff5dd1c1707e6a6159eefc6f2ddf6f44ec4438564")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/8/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/8/session.pid"
   :SHA256 "e9e0e92a13ea6e0284d5fa1fa8f65229651b489b8c6fe1d7f742f684fa68658a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/8/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/8/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/8/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/8/stdout.lisp"
   :SHA256 "31ea0941716566ef078790085e72650d0e0e931bcea03088f090c3f9e6fb9c66")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/9/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/9/scan-10.lisp"
   :SHA256 "729505d6e371dc4eb91dbe9c0f998ca12e97610b52ae83c954414c7861df6c70")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/9/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/9/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/9/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/9/scan-10.stdout.log"
   :SHA256 "1a82681b9f557fb3e0de2723bf6867f931c389c53e6efe0759e57be4325219b4")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/9/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/9/session.pid"
   :SHA256 "f20ba74c01f6906b55903f6c8adeaedcf4269261a381e5881ad5447a82180f23")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/9/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/9/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-zqcQgh/9/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-zqcQgh/9/stdout.lisp"
   :SHA256 "15ed29b95978e446d17cd9f520516673c21d11b1ceb647a83107d088cbc75fb4")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/0/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/0/scan-4.lisp"
   :SHA256 "b7f8781cd9228aa60c552609a3461edf853263cf6681fe486099ae7cefb20972")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/0/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/0/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/0/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/0/scan-4.stdout.log"
   :SHA256 "624fe479a29f2bc2717ac0308031ee146c0d60000a467a33821f027130130349")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/0/session.pid"
   :SHA256 "5660a2f77bd7bca770b51c04d97d9111049dbfe10e81b15ab59c4cef1b92f5a2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/0/stdout.lisp"
   :SHA256 "3c3e1d0db8c3c9caca1995916027d78492d2f580d5e50cdf94d4e59281dd4aed")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/1/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/1/scan-1.lisp"
   :SHA256 "f85ef0ba63a2006dbde11b24f39078f0fd3f9bbcf1d9c2aa1daa198a3313a592")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/1/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/1/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/1/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/1/scan-1.stdout.log"
   :SHA256 "0e5acd0b93d8ab7b7bef003df3da93e0d428cde98c31b6c5893298eb572b82a9")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/1/session.pid"
   :SHA256 "b08ec877381e6fbe9ee4df41e25ff72a09eade6421850d712e71d54349d2d85e")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/1/stdout.lisp"
   :SHA256 "1408b0f66ab661b8673cd350d40e192493dba517be5a2705d382c63c8438d28d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/2/scan-3.lisp"
   :SHA256 "15d39267ba6cb03e66d37f4b827665e43d212f37864f04d624d6eaa7ffca143e")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/2/scan-3.stdout.log"
   :SHA256 "a7a3aab0eb6dcb4a699cbc058ed649532358bd8d758f693aba7e8a9158b15010")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/2/session.pid"
   :SHA256 "990d0574b40a4fdaa0575202931102e9290ae7126f66fd8f9ff8dcabe93514e7")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/2/stdout.lisp"
   :SHA256 "2e7fca2d9e2fc0d9537df579c78b038ae3c1477cd817cd40fffacbc4cda80597")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/3/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/3/scan-2.lisp"
   :SHA256 "005cdfb62912649ad2a504731af8cf6c48260938fdcbe789ffa40c4586bfda0b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/3/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/3/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/3/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/3/scan-2.stdout.log"
   :SHA256 "449c93799d1674c9fd33935380a251dbdea1a869a783fc6de209ddfa85f3c091")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/3/session.pid"
   :SHA256 "5dab14c1fb9902f14d82e10e59570a8761f566e263d142f73a2bf0b40b6fe32f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/3/stdout.lisp"
   :SHA256 "25564bda945c2105101cc7d392d13240d14238d1a27e9acf8da5f5ae0875158d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/4/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/4/scan-5.lisp"
   :SHA256 "d5d6847e0898c572ea8e854cd5b2eb3c6d9977252113e05d8b1e2fe6fc8a9bfb")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/4/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/4/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/4/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/4/scan-5.stdout.log"
   :SHA256 "480bf83e1fd9a17256e3acd4bc9049e56b78121166f85bbb216a1dd9c1b7d207")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/4/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/4/session.pid"
   :SHA256 "95bdee25f7c3dc6c70cc6678538f46a07f2f955e2bf405cc77319fe0ab8da6a0")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/4/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/4/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/4/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/4/stdout.lisp"
   :SHA256 "2be099c08baa117e6464bba3c631874220ab09ec3b9d2dfa3fa3a54fb50eb69f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/5/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/5/scan-6.lisp"
   :SHA256 "71030b6f730e71470869195f91ffcde6acc6759b30a3b37dd301e2d0686bd756")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/5/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/5/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/5/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/5/scan-6.stdout.log"
   :SHA256 "cec17fed8fea078c214c6dd20f48bba224d255b2d25464bba8633a7647f1174c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/5/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/5/session.pid"
   :SHA256 "a0768c00f615521b245f19a8f9db5139be22e7146fa55d31351fbc4dfddd8a14")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/5/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/5/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/5/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/5/stdout.lisp"
   :SHA256 "c020b7cfad97537e62a5b046c84a727494a77429c7ba3d0b3c88699d692fadea")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/6/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/6/scan-7.lisp"
   :SHA256 "b3dd287b3d6596790aa8a5822bbfe81f832cedcacc81632865f335aeabc25355")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/6/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/6/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/6/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/6/scan-7.stdout.log"
   :SHA256 "1d8123c3b087cd11391dc9dabfd516612b076bb12e8d1b81144e87b60888bcb2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/6/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/6/session.pid"
   :SHA256 "b45d510d4e32787648fa026c79b9370a77a25a064f9afe816704541223eff9aa")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/6/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/6/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/6/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/6/stdout.lisp"
   :SHA256 "632ff70d8e777211e68c9c6aa18fbbacd544790316335340e811020c0820425a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/7/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/7/scan-8.lisp"
   :SHA256 "eb41ac52465ad6784e9bd01d844279692dc53d927880c4831bf2430d1176b111")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/7/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/7/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/7/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/7/scan-8.stdout.log"
   :SHA256 "36abde54a430d678eeb1df3d971b1ff3d731d480ae2c2bde882f06383d90a19c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/7/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/7/session.pid"
   :SHA256 "6ba92d08bc7a97da6c7f57f76123db698d4181ad4a86eae8dda16dc78c2376d8")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/7/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/7/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/7/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/7/stdout.lisp"
   :SHA256 "ba7fcea75bc2864a21f3b940483384447375da9144341dee0b2be1a13f199598")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/8/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/8/scan-9.lisp"
   :SHA256 "72e3145a144c0b6cd163655f09a0e2168c0ea692510ea4e63e60d90759fa6911")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/8/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/8/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/8/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/8/scan-9.stdout.log"
   :SHA256 "e40444e6cbbd5f97e70b406d5b9366090c246dcc59346f3439d94694628700d7")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/8/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/8/session.pid"
   :SHA256 "635bbabf613c3881d61681c199e6a79c3d8515ea7b36ad556554bb0990e4b614")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/8/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/8/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/8/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/8/stdout.lisp"
   :SHA256 "31ea0941716566ef078790085e72650d0e0e931bcea03088f090c3f9e6fb9c66")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/9/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/9/scan-10.lisp"
   :SHA256 "c782714f1da8d15f4f25c08caaff2de3f84beba6ed73a8b7e1f2f773772e2a2c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/9/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/9/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/9/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/9/scan-10.stdout.log"
   :SHA256 "6a2ed2302de22501a0b2a79f5132c6c855b77f7afb8bab433791e6329ca8ac87")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/9/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/9/session.pid"
   :SHA256 "e0d11b93b70e747549dacf16e28416282f075783200cfe26454d8f2d4e1d13bc")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/9/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/9/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-vMt8UE/9/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-check-vMt8UE/9/stdout.lisp"
   :SHA256 "15ed29b95978e446d17cd9f520516673c21d11b1ceb647a83107d088cbc75fb4")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507363-command-94574-0/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/4002507363-command-94574-0/self-test-report.lisp"
   :SHA256 "7e47f646dc8ee821fcd8e3536a898b414e928bb78b4cbfd416d95f7b431a963b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507364-snapshot-self-test-94588-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/4002507364-snapshot-self-test-94588-0/report.lisp"
   :SHA256 "d088845eb647a31a3996aca3e481ab4f13203681b4752262e23d7527c2ff3b70")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002507365-reader-self-test-94591-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/4002507365-reader-self-test-94591-0/report.lisp"
   :SHA256 "3917d65677d64b3d48c503459b1102cbac4cb9bf932f0cab55dc8d4f207fc5e5")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/command-archive-collector-self-test-maPVWV/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/command-archive-collector-self-test-maPVWV/self-test-report.lisp"
   :SHA256 "2be179e31b9c08b6259443ae07a195e4354a1dc73b62fb9864ac454e4fd8f4b1")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-parallel-self-test-u5mjp6/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/evidence-parallel-self-test-u5mjp6/report.lisp"
   :SHA256 "072181cb0b20dc78651801eace1fe55a7fef6b131065b57efc58906bbd526a7f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793518891-97994/boundaries.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/ci/selftest-1793518891-97994/boundaries.lisp"
   :SHA256 "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793518891-97994/conditions.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/ci/selftest-1793518891-97994/conditions.lisp"
   :SHA256 "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793518891-97994/data.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/ci/selftest-1793518891-97994/data.lisp"
   :SHA256 "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793518891-97994/measure.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/ci/selftest-1793518891-97994/measure.lisp"
   :SHA256 "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793518891-97994/publication.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/ci/selftest-1793518891-97994/publication.lisp"
   :SHA256 "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793518891-97994/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/ci/selftest-1793518891-97994/report.lisp"
   :SHA256 "3bf53e3748c34568e0fb83b9f6f7ed394be5c711a74ca8b7bdde88a45f49bc23")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793518891-97994/tests.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/ci/selftest-1793518891-97994/tests.lisp"
   :SHA256 "ba1c0e543638f0424a2c9f3c07cc641b5f0e776c7e036135293eebd50a169904")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793518891-97994/workflow.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/support/ci/selftest-1793518891-97994/workflow.lisp"
   :SHA256 "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"))
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/source-identity.lisp"
   :STATUS :OK :ORIGINAL-BYTES 170968 :STORED-BYTES 54818 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "source-identity.lisp.gz" :UNCOMPRESSED-BYTES 170968 :UNCOMPRESSED-SHA256
    "0f813c19e37a6bc1585368156b43b4b2983e413c2ba5b4ac204deb4ea863248e"
    :COMPRESSED-BYTES 54494 :COMPRESSED-SHA256
    "8ef95d343b627991f7248ff83548c9b9f01afe4f7601b49647e30dddff370473"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/analysis-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 343004 :STORED-BYTES 109890 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 343004 :UNCOMPRESSED-SHA256
    "ba22e10ba6538f9cacf4af77195a3984d189c9b0cd967ff6c798098cae0d7e0a"
    :COMPRESSED-BYTES 109574 :COMPRESSED-SHA256
    "7957ad348aea786259da567a63dde97cfa03d6364c2ccf64c6806acb1a489543"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/analysis-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342983 :STORED-BYTES 109874 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342983 :UNCOMPRESSED-SHA256
    "e1593b7cb8c8b41bfcb1ec53748fee9f07a581576a8ba9288ff834cd9e72ee88"
    :COMPRESSED-BYTES 109558 :COMPRESSED-SHA256
    "a39b938c3a159273cb47b6c6873c856d39102e57e4433e49a2bb4bcc8adc462e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/archive-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342988 :STORED-BYTES 109878 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342988 :UNCOMPRESSED-SHA256
    "54b0f0dc068c3c23d9fbe68106786b75db6967d1125540d72dd786c776ac8a81"
    :COMPRESSED-BYTES 109562 :COMPRESSED-SHA256
    "1510f5097ebc6a6f5a60a629cf6c9ec83e781a9c58820adf9e69b417b172bc3a"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/baseline-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 344325 :STORED-BYTES 110140 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 344325 :UNCOMPRESSED-SHA256
    "c0e3f72735203bf2e03f6d8a43750fa05238931192b15c25bc3bc64e17f6d9e1"
    :COMPRESSED-BYTES 109824 :COMPRESSED-SHA256
    "4c20e76e278f578e87b67a9ef50118d3ae2a655467cc745f04b3354b1764d3f0"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/baseline/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 437099 :STORED-BYTES 120389 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 437099 :UNCOMPRESSED-SHA256
    "1fbb5cac8d8e92cab27fad3a7e0a5e2e2cb183a220e2768afc4b527b0a01a14b"
    :COMPRESSED-BYTES 120073 :COMPRESSED-SHA256
    "4771c097d4ea8460d4c575bfb7468aa8a6dbb5b9ce54e38c808ecbe5a80709f4"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/benchmark-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 343129 :STORED-BYTES 109873 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 343129 :UNCOMPRESSED-SHA256
    "12630785dfa489691a6bd7efad20715634b7de6a4fc5b67c1483984366078887"
    :COMPRESSED-BYTES 109557 :COMPRESSED-SHA256
    "a4a699b9c6802578e6323d6d1e908d46f08e270269fd4ebcacb2c04da9bd5a4f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/benchmark/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 539011 :STORED-BYTES 133508 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 539011 :UNCOMPRESSED-SHA256
    "d0e25b7b0ceb188fec9c68436eff43df87b34abff305cd97b3b48684cccfc42f"
    :COMPRESSED-BYTES 133192 :COMPRESSED-SHA256
    "e489c491a31f138486333a07003b71e0a490f932d0c2cf1d56a88218a55f0c10"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/ci-self-test-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 343745 :STORED-BYTES 110083 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 343745 :UNCOMPRESSED-SHA256
    "634bab10236d83ba386dabae13183b039f7ec7f24a0535b875cbf33fda19a77b"
    :COMPRESSED-BYTES 109767 :COMPRESSED-SHA256
    "492d2cc8541df64d6cf21c93943b17d5711bfcd3a99b16ea75d0f2f393240e63"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/codec-model/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 343118 :STORED-BYTES 109946 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 343118 :UNCOMPRESSED-SHA256
    "2d0ff802ef5bd7103960f007b0201ca0b7217dbf89dc904a8971821b9708332d"
    :COMPRESSED-BYTES 109630 :COMPRESSED-SHA256
    "7f94ca0e5888899f253223b696537befa1a9f230269c3dd36177868398eb1a09"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/current-source-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342980 :STORED-BYTES 109867 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342980 :UNCOMPRESSED-SHA256
    "439e8330067cbe01e2800cd080cdf4f1e4f58d64684095b163027bd4d9266206"
    :COMPRESSED-BYTES 109551 :COMPRESSED-SHA256
    "167bd67bb6a88a32cd833f608b0f55c120a0dd2642b704650617001c6ffbf945"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/development-prefix/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 352861 :STORED-BYTES 111681 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 352861 :UNCOMPRESSED-SHA256
    "c87209b43459e8ae90fa89862773602eb91240d202866f2f239424652af088f9"
    :COMPRESSED-BYTES 111365 :COMPRESSED-SHA256
    "a0c4abe4e56fe890e6262485cbba94915fc802df7db83e498411c2316636658e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/development-process-message/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 355060 :STORED-BYTES 112984 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 355060 :UNCOMPRESSED-SHA256
    "6c796ea675f73ff5816b6317d46544416ec14d2369918d0c0af283759c1ed00f"
    :COMPRESSED-BYTES 112668 :COMPRESSED-SHA256
    "84869128c2eff24c05c15a659d2ab92fd8d3ec2fe00c8f75b680831f3c53b09f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/development-process-reader/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 343370 :STORED-BYTES 109987 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 343370 :UNCOMPRESSED-SHA256
    "3f0faae922310e1ceb18f0770a607139ecdcfff492b88a0124ce3e8b51f70838"
    :COMPRESSED-BYTES 109671 :COMPRESSED-SHA256
    "c362add28b4fc90a985500584313cce7b02fc40238f475cf770d8769f37968e6"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/development-reader-balance/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 343185 :STORED-BYTES 109900 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 343185 :UNCOMPRESSED-SHA256
    "47cf70d288e8646405b2025cc82726738697d5b7c70f8ac59e445bf0465c6953"
    :COMPRESSED-BYTES 109584 :COMPRESSED-SHA256
    "76342dbe7b6df3232824fbf2185d58a0d3e2fabfa582ab42c3b06c6cf105d42d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/development-reader-step2/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342641 :STORED-BYTES 109815 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342641 :UNCOMPRESSED-SHA256
    "06025e817296cdecb393daa4ad7f4318811367d92da12840cd997a80d896ff4b"
    :COMPRESSED-BYTES 109499 :COMPRESSED-SHA256
    "4fb82cd5dab0ccfe826cf233b657c3f470d7e02180c4f9fcb215feddaee09803"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/development-reader-step3/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342534 :STORED-BYTES 109791 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342534 :UNCOMPRESSED-SHA256
    "6dcc2b5491bfda1811f621d6d6e8bd626dee0ab236c623eba684a9d7c74ad744"
    :COMPRESSED-BYTES 109475 :COMPRESSED-SHA256
    "54b70e5a6ec54f8d345298657e0fcd6242f6d363451e74251608491638d0e20b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/development-reader-traits/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 345563 :STORED-BYTES 110200 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 345563 :UNCOMPRESSED-SHA256
    "e695d4464bff7728e53b02fd3e7b8b971472bdc08cce8c17aebf6eec9a386612"
    :COMPRESSED-BYTES 109884 :COMPRESSED-SHA256
    "ec7fc8e401a5d27bdccbe09a89820b3eea817cc8ac6596f6960d8a83f33cfae1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/documentation/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349186 :STORED-BYTES 111240 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349186 :UNCOMPRESSED-SHA256
    "b52e9fea828a953fc43963f492793b855116818b5c1057a3d3c5f321a8bfd12d"
    :COMPRESSED-BYTES 110924 :COMPRESSED-SHA256
    "4c684047c1a55cfdb89049c27baa189f6fe3c7c27114ad62733b22b391bf9794"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/failed-fixture-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342961 :STORED-BYTES 109871 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342961 :UNCOMPRESSED-SHA256
    "c1bda939fba89c104ae1c9f64699e98263ac55039e9b41f81e2bee88bc7e06ec"
    :COMPRESSED-BYTES 109555 :COMPRESSED-SHA256
    "af9020d93812cf4cd851c762b487efe979a7f05e4e4ca19429c28b107d0c520b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/final-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 343123 :STORED-BYTES 109875 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 343123 :UNCOMPRESSED-SHA256
    "eae919c0f935fc88c900eb7a7f1609dc9bd22237e6e9ecfcacfb3302ad0872da"
    :COMPRESSED-BYTES 109559 :COMPRESSED-SHA256
    "714d98348cc3cdc77c51cb90abd721fb2bfeb656b011b1b0dca7d50871bfc1bc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/final-checks/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 343696 :STORED-BYTES 110261 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 343696 :UNCOMPRESSED-SHA256
    "8e316e1f5fe4d095990a20c944c21f1cf35add1acce7153b1721d153c18e9e7d"
    :COMPRESSED-BYTES 109945 :COMPRESSED-SHA256
    "fb9309a95412b19d1f242b5270d39f7251c351c2e7abb9ee1d9454ae42371f6e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/focused-initial/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 357575 :STORED-BYTES 112448 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 357575 :UNCOMPRESSED-SHA256
    "2f510506141fb08bb0773ff496fecb8dea829ce5479134942681613e8840574e"
    :COMPRESSED-BYTES 112132 :COMPRESSED-SHA256
    "0cbaa7506beee65a34cc8f668e64cc5fedfc247f2a8334cc6b0944ae40421326"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/focused/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 357635 :STORED-BYTES 112477 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 357635 :UNCOMPRESSED-SHA256
    "1ec4788b9b942dfc585089d741229d90fcbebbc504a70be20d78cfaf5e3545d4"
    :COMPRESSED-BYTES 112161 :COMPRESSED-SHA256
    "0b3a652377ef3b5fa26366e11127b81693d93fdb8da9d60043542cb0b7fb0f77"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/identity-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342981 :STORED-BYTES 109874 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342981 :UNCOMPRESSED-SHA256
    "3d099ffdcf77493af471abb80cad8eb7a3acbc398a7508c9e559845558ed0342"
    :COMPRESSED-BYTES 109558 :COMPRESSED-SHA256
    "d4779b1f005f747b3cb07ae7fafd5f317a15c09f83dba6184a94999d698d0036"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/identity-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342981 :STORED-BYTES 109869 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342981 :UNCOMPRESSED-SHA256
    "81ffb97d37b2cfc45ac295eaf3fa30a4592b9c29d8bc5e5d5c3fc7ef6ead093f"
    :COMPRESSED-BYTES 109553 :COMPRESSED-SHA256
    "58a5f412f08d25b82712d10e493f819e5d2bc20e017948dcbeb14294bdcc3bc8"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/initial-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 343128 :STORED-BYTES 109876 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 343128 :UNCOMPRESSED-SHA256
    "09d8ac396af25ad3926df43b2fb6eb3f3a460d172fe71b68f21acd2e7adff2a1"
    :COMPRESSED-BYTES 109560 :COMPRESSED-SHA256
    "27bb300ff0c571ead28e5b9879709772613ce8fcede9df76767403f930d1901e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/printed-metrics-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 345108 :STORED-BYTES 110623 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 345108 :UNCOMPRESSED-SHA256
    "ce7f57dc1e40f3c8a6eeea60eed1a95eb7ac44d1227eb4b3f27af60102c6c9c8"
    :COMPRESSED-BYTES 110307 :COMPRESSED-SHA256
    "4904785207a36ce6c402d284fb77a380213aa01a5fa925dd5cb9b976e962f9a2"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/qualification-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342953 :STORED-BYTES 109859 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342953 :UNCOMPRESSED-SHA256
    "b720197d3ebf3acb2fa3aeaed74b19ba41e033a98a5ab188f6eb8e1158a47089"
    :COMPRESSED-BYTES 109543 :COMPRESSED-SHA256
    "09c5a6249a09f399a2687d1d197b981b86f4e27b0c36d4358abf519e330774a1"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/reader-check/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342884 :STORED-BYTES 109825 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342884 :UNCOMPRESSED-SHA256
    "6cc6bda9fa83432a833f4ed8b7b0df51f9f5fcf63f46ddbd6d93481d7adedc2c"
    :COMPRESSED-BYTES 109509 :COMPRESSED-SHA256
    "15016ae3909fe166915400528d5fcfe1d6917c02be5082c6605b7ff74701c770"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-001-v1-server-301.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1376 :STORED-BYTES 511 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-001-v1-server-301.stderr.gz" :UNCOMPRESSED-BYTES 1376
    :UNCOMPRESSED-SHA256
    "7f825edd45f731b6ffb31b2c4baaa73ff8e5377261184ec25fc7f6b5064f4c2f"
    :COMPRESSED-BYTES 177 :COMPRESSED-SHA256
    "f490a4a11fc72a37191d7b56656d29cf032a5c1a02a892596b3cdcdf4c79252e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-003-v1-server-302.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1376 :STORED-BYTES 511 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-003-v1-server-302.stderr.gz" :UNCOMPRESSED-BYTES 1376
    :UNCOMPRESSED-SHA256
    "7f825edd45f731b6ffb31b2c4baaa73ff8e5377261184ec25fc7f6b5064f4c2f"
    :COMPRESSED-BYTES 177 :COMPRESSED-SHA256
    "f490a4a11fc72a37191d7b56656d29cf032a5c1a02a892596b3cdcdf4c79252e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-005-v1-server-303.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1514 :STORED-BYTES 540 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-005-v1-server-303.stderr.gz" :UNCOMPRESSED-BYTES 1514
    :UNCOMPRESSED-SHA256
    "74bacb1a11d43355c6072fdf420a64619da5bc96bc4007ae1e9a38e915c9a3d0"
    :COMPRESSED-BYTES 206 :COMPRESSED-SHA256
    "7821a80ac87dd70f103d750240db166a04e9203da8fdf0e1c30d2b533835eadb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-007-v1-server-304.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1514 :STORED-BYTES 540 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-007-v1-server-304.stderr.gz" :UNCOMPRESSED-BYTES 1514
    :UNCOMPRESSED-SHA256
    "74bacb1a11d43355c6072fdf420a64619da5bc96bc4007ae1e9a38e915c9a3d0"
    :COMPRESSED-BYTES 206 :COMPRESSED-SHA256
    "7821a80ac87dd70f103d750240db166a04e9203da8fdf0e1c30d2b533835eadb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-009-v1-server-305.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1376 :STORED-BYTES 511 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-009-v1-server-305.stderr.gz" :UNCOMPRESSED-BYTES 1376
    :UNCOMPRESSED-SHA256
    "7f825edd45f731b6ffb31b2c4baaa73ff8e5377261184ec25fc7f6b5064f4c2f"
    :COMPRESSED-BYTES 177 :COMPRESSED-SHA256
    "f490a4a11fc72a37191d7b56656d29cf032a5c1a02a892596b3cdcdf4c79252e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-011-v1-server-306.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1376 :STORED-BYTES 511 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-011-v1-server-306.stderr.gz" :UNCOMPRESSED-BYTES 1376
    :UNCOMPRESSED-SHA256
    "7f825edd45f731b6ffb31b2c4baaa73ff8e5377261184ec25fc7f6b5064f4c2f"
    :COMPRESSED-BYTES 177 :COMPRESSED-SHA256
    "f490a4a11fc72a37191d7b56656d29cf032a5c1a02a892596b3cdcdf4c79252e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-013-v1-server-307.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1514 :STORED-BYTES 540 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-013-v1-server-307.stderr.gz" :UNCOMPRESSED-BYTES 1514
    :UNCOMPRESSED-SHA256
    "74bacb1a11d43355c6072fdf420a64619da5bc96bc4007ae1e9a38e915c9a3d0"
    :COMPRESSED-BYTES 206 :COMPRESSED-SHA256
    "7821a80ac87dd70f103d750240db166a04e9203da8fdf0e1c30d2b533835eadb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-015-v1-server-308.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1514 :STORED-BYTES 540 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-015-v1-server-308.stderr.gz" :UNCOMPRESSED-BYTES 1514
    :UNCOMPRESSED-SHA256
    "74bacb1a11d43355c6072fdf420a64619da5bc96bc4007ae1e9a38e915c9a3d0"
    :COMPRESSED-BYTES 206 :COMPRESSED-SHA256
    "7821a80ac87dd70f103d750240db166a04e9203da8fdf0e1c30d2b533835eadb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-017-v2-server-309.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1376 :STORED-BYTES 511 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-017-v2-server-309.stderr.gz" :UNCOMPRESSED-BYTES 1376
    :UNCOMPRESSED-SHA256
    "7f825edd45f731b6ffb31b2c4baaa73ff8e5377261184ec25fc7f6b5064f4c2f"
    :COMPRESSED-BYTES 177 :COMPRESSED-SHA256
    "f490a4a11fc72a37191d7b56656d29cf032a5c1a02a892596b3cdcdf4c79252e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-019-v2-server-310.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1376 :STORED-BYTES 511 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-019-v2-server-310.stderr.gz" :UNCOMPRESSED-BYTES 1376
    :UNCOMPRESSED-SHA256
    "7f825edd45f731b6ffb31b2c4baaa73ff8e5377261184ec25fc7f6b5064f4c2f"
    :COMPRESSED-BYTES 177 :COMPRESSED-SHA256
    "f490a4a11fc72a37191d7b56656d29cf032a5c1a02a892596b3cdcdf4c79252e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-021-v2-server-311.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1514 :STORED-BYTES 540 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-021-v2-server-311.stderr.gz" :UNCOMPRESSED-BYTES 1514
    :UNCOMPRESSED-SHA256
    "74bacb1a11d43355c6072fdf420a64619da5bc96bc4007ae1e9a38e915c9a3d0"
    :COMPRESSED-BYTES 206 :COMPRESSED-SHA256
    "7821a80ac87dd70f103d750240db166a04e9203da8fdf0e1c30d2b533835eadb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-023-v2-server-312.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1514 :STORED-BYTES 540 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-023-v2-server-312.stderr.gz" :UNCOMPRESSED-BYTES 1514
    :UNCOMPRESSED-SHA256
    "74bacb1a11d43355c6072fdf420a64619da5bc96bc4007ae1e9a38e915c9a3d0"
    :COMPRESSED-BYTES 206 :COMPRESSED-SHA256
    "7821a80ac87dd70f103d750240db166a04e9203da8fdf0e1c30d2b533835eadb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-025-v2-server-313.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1376 :STORED-BYTES 511 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-025-v2-server-313.stderr.gz" :UNCOMPRESSED-BYTES 1376
    :UNCOMPRESSED-SHA256
    "7f825edd45f731b6ffb31b2c4baaa73ff8e5377261184ec25fc7f6b5064f4c2f"
    :COMPRESSED-BYTES 177 :COMPRESSED-SHA256
    "f490a4a11fc72a37191d7b56656d29cf032a5c1a02a892596b3cdcdf4c79252e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-027-v2-server-314.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1376 :STORED-BYTES 511 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-027-v2-server-314.stderr.gz" :UNCOMPRESSED-BYTES 1376
    :UNCOMPRESSED-SHA256
    "7f825edd45f731b6ffb31b2c4baaa73ff8e5377261184ec25fc7f6b5064f4c2f"
    :COMPRESSED-BYTES 177 :COMPRESSED-SHA256
    "f490a4a11fc72a37191d7b56656d29cf032a5c1a02a892596b3cdcdf4c79252e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-029-v2-server-315.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1514 :STORED-BYTES 540 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-029-v2-server-315.stderr.gz" :UNCOMPRESSED-BYTES 1514
    :UNCOMPRESSED-SHA256
    "74bacb1a11d43355c6072fdf420a64619da5bc96bc4007ae1e9a38e915c9a3d0"
    :COMPRESSED-BYTES 206 :COMPRESSED-SHA256
    "7821a80ac87dd70f103d750240db166a04e9203da8fdf0e1c30d2b533835eadb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/baseline-031-v2-server-316.stderr"
   :STATUS :OK :ORIGINAL-BYTES 1514 :STORED-BYTES 540 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-031-v2-server-316.stderr.gz" :UNCOMPRESSED-BYTES 1514
    :UNCOMPRESSED-SHA256
    "74bacb1a11d43355c6072fdf420a64619da5bc96bc4007ae1e9a38e915c9a3d0"
    :COMPRESSED-BYTES 206 :COMPRESSED-SHA256
    "7821a80ac87dd70f103d750240db166a04e9203da8fdf0e1c30d2b533835eadb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-001-v1-server-301.stderr"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 637 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-001-v1-server-301.stderr.gz" :UNCOMPRESSED-BYTES 5638
    :UNCOMPRESSED-SHA256
    "2529994a16333f71bdcdedb5991b3012cc4c48e24e283930ca7c6ed88a897c69"
    :COMPRESSED-BYTES 306 :COMPRESSED-SHA256
    "a5b582286c3a4369148015b043bc76f67bb908000bda84b51c07f001800c68c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-003-v1-server-302.stderr"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 637 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-003-v1-server-302.stderr.gz" :UNCOMPRESSED-BYTES 5638
    :UNCOMPRESSED-SHA256
    "2529994a16333f71bdcdedb5991b3012cc4c48e24e283930ca7c6ed88a897c69"
    :COMPRESSED-BYTES 306 :COMPRESSED-SHA256
    "a5b582286c3a4369148015b043bc76f67bb908000bda84b51c07f001800c68c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-005-v1-server-303.stderr"
   :STATUS :OK :ORIGINAL-BYTES 6246 :STORED-BYTES 720 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-005-v1-server-303.stderr.gz" :UNCOMPRESSED-BYTES 6246
    :UNCOMPRESSED-SHA256
    "b8f5b021e0d8d023a04155309a76059bf069a4d0305386deaff2b8cb18fce204"
    :COMPRESSED-BYTES 389 :COMPRESSED-SHA256
    "694f12c484505be39772e292bab34a36079f697099d53e2747ecd34f7c42d7be"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-007-v1-server-304.stderr"
   :STATUS :OK :ORIGINAL-BYTES 6246 :STORED-BYTES 720 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-007-v1-server-304.stderr.gz" :UNCOMPRESSED-BYTES 6246
    :UNCOMPRESSED-SHA256
    "b8f5b021e0d8d023a04155309a76059bf069a4d0305386deaff2b8cb18fce204"
    :COMPRESSED-BYTES 389 :COMPRESSED-SHA256
    "694f12c484505be39772e292bab34a36079f697099d53e2747ecd34f7c42d7be"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-009-v1-server-305.stderr"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 637 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-009-v1-server-305.stderr.gz" :UNCOMPRESSED-BYTES 5638
    :UNCOMPRESSED-SHA256
    "2529994a16333f71bdcdedb5991b3012cc4c48e24e283930ca7c6ed88a897c69"
    :COMPRESSED-BYTES 306 :COMPRESSED-SHA256
    "a5b582286c3a4369148015b043bc76f67bb908000bda84b51c07f001800c68c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-011-v1-server-306.stderr"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 637 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-011-v1-server-306.stderr.gz" :UNCOMPRESSED-BYTES 5638
    :UNCOMPRESSED-SHA256
    "2529994a16333f71bdcdedb5991b3012cc4c48e24e283930ca7c6ed88a897c69"
    :COMPRESSED-BYTES 306 :COMPRESSED-SHA256
    "a5b582286c3a4369148015b043bc76f67bb908000bda84b51c07f001800c68c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-013-v1-server-307.stderr"
   :STATUS :OK :ORIGINAL-BYTES 6246 :STORED-BYTES 720 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-013-v1-server-307.stderr.gz" :UNCOMPRESSED-BYTES 6246
    :UNCOMPRESSED-SHA256
    "b8f5b021e0d8d023a04155309a76059bf069a4d0305386deaff2b8cb18fce204"
    :COMPRESSED-BYTES 389 :COMPRESSED-SHA256
    "694f12c484505be39772e292bab34a36079f697099d53e2747ecd34f7c42d7be"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-015-v1-server-308.stderr"
   :STATUS :OK :ORIGINAL-BYTES 6246 :STORED-BYTES 720 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-015-v1-server-308.stderr.gz" :UNCOMPRESSED-BYTES 6246
    :UNCOMPRESSED-SHA256
    "b8f5b021e0d8d023a04155309a76059bf069a4d0305386deaff2b8cb18fce204"
    :COMPRESSED-BYTES 389 :COMPRESSED-SHA256
    "694f12c484505be39772e292bab34a36079f697099d53e2747ecd34f7c42d7be"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-017-v2-server-309.stderr"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 637 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-017-v2-server-309.stderr.gz" :UNCOMPRESSED-BYTES 5638
    :UNCOMPRESSED-SHA256
    "2529994a16333f71bdcdedb5991b3012cc4c48e24e283930ca7c6ed88a897c69"
    :COMPRESSED-BYTES 306 :COMPRESSED-SHA256
    "a5b582286c3a4369148015b043bc76f67bb908000bda84b51c07f001800c68c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-019-v2-server-310.stderr"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 637 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-019-v2-server-310.stderr.gz" :UNCOMPRESSED-BYTES 5638
    :UNCOMPRESSED-SHA256
    "2529994a16333f71bdcdedb5991b3012cc4c48e24e283930ca7c6ed88a897c69"
    :COMPRESSED-BYTES 306 :COMPRESSED-SHA256
    "a5b582286c3a4369148015b043bc76f67bb908000bda84b51c07f001800c68c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-021-v2-server-311.stderr"
   :STATUS :OK :ORIGINAL-BYTES 6246 :STORED-BYTES 720 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-021-v2-server-311.stderr.gz" :UNCOMPRESSED-BYTES 6246
    :UNCOMPRESSED-SHA256
    "b8f5b021e0d8d023a04155309a76059bf069a4d0305386deaff2b8cb18fce204"
    :COMPRESSED-BYTES 389 :COMPRESSED-SHA256
    "694f12c484505be39772e292bab34a36079f697099d53e2747ecd34f7c42d7be"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-023-v2-server-312.stderr"
   :STATUS :OK :ORIGINAL-BYTES 6246 :STORED-BYTES 720 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-023-v2-server-312.stderr.gz" :UNCOMPRESSED-BYTES 6246
    :UNCOMPRESSED-SHA256
    "b8f5b021e0d8d023a04155309a76059bf069a4d0305386deaff2b8cb18fce204"
    :COMPRESSED-BYTES 389 :COMPRESSED-SHA256
    "694f12c484505be39772e292bab34a36079f697099d53e2747ecd34f7c42d7be"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-025-v2-server-313.stderr"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 637 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-025-v2-server-313.stderr.gz" :UNCOMPRESSED-BYTES 5638
    :UNCOMPRESSED-SHA256
    "2529994a16333f71bdcdedb5991b3012cc4c48e24e283930ca7c6ed88a897c69"
    :COMPRESSED-BYTES 306 :COMPRESSED-SHA256
    "a5b582286c3a4369148015b043bc76f67bb908000bda84b51c07f001800c68c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-027-v2-server-314.stderr"
   :STATUS :OK :ORIGINAL-BYTES 5638 :STORED-BYTES 637 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-027-v2-server-314.stderr.gz" :UNCOMPRESSED-BYTES 5638
    :UNCOMPRESSED-SHA256
    "2529994a16333f71bdcdedb5991b3012cc4c48e24e283930ca7c6ed88a897c69"
    :COMPRESSED-BYTES 306 :COMPRESSED-SHA256
    "a5b582286c3a4369148015b043bc76f67bb908000bda84b51c07f001800c68c5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-029-v2-server-315.stderr"
   :STATUS :OK :ORIGINAL-BYTES 6246 :STORED-BYTES 720 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-029-v2-server-315.stderr.gz" :UNCOMPRESSED-BYTES 6246
    :UNCOMPRESSED-SHA256
    "b8f5b021e0d8d023a04155309a76059bf069a4d0305386deaff2b8cb18fce204"
    :COMPRESSED-BYTES 389 :COMPRESSED-SHA256
    "694f12c484505be39772e292bab34a36079f697099d53e2747ecd34f7c42d7be"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-read-groups/unix-logs/final-031-v2-server-316.stderr"
   :STATUS :OK :ORIGINAL-BYTES 6246 :STORED-BYTES 720 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-031-v2-server-316.stderr.gz" :UNCOMPRESSED-BYTES 6246
    :UNCOMPRESSED-SHA256
    "b8f5b021e0d8d023a04155309a76059bf069a4d0305386deaff2b8cb18fce204"
    :COMPRESSED-BYTES 389 :COMPRESSED-SHA256
    "694f12c484505be39772e292bab34a36079f697099d53e2747ecd34f7c42d7be")))
 :VERIFIED-FILES 203 :HASH-METHOD :STORED-BYTES-OR-VERIFIED-LOSSLESS-EXPANSION
 :LIMITS
 (:NEGATIVE-SELF-TEST-FIXTURE-TREES-EXCLUDED
  :NO-QUALIFICATION-INFERENCE-FROM-EXIT-CODE-ALONE))
