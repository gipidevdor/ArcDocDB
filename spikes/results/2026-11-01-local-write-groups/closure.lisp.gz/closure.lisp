(:KIND :EXPLICIT-GROUP-EVIDENCE-CLOSURE :STATUS :PASSED :UNIVERSAL-TIME
 4002504382 :DRIVER-SHA256
 "8de903378531a3955be2c43ce45ce6226ff0ab80e6d5e6a1cbe42df1fa901262"
 :INPUT-SHA256
 "894d78b676eeae49e470ff75d8d3b907573c7ee68c7a53c19ea7e9eeaab97a73" :COPIES
 ((:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002502784-command-79347-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/archive-self-test/conservazione.lisp"
   :SHA256 "b1d14c3c9566bb157700042b5f645e890ebcbf3e907ccc087b507ddf9e11983f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002502784-command-79347-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/archive-self-test/report.lisp"
   :SHA256 "a88e00c9ef02386a664c3d05c58a438fc0072bb41d2f569997cc0e94059b0110")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002502889-command-79907-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/initial-archive-command/conservazione.lisp"
   :SHA256 "2011df0cca013585a623a8710937d9f78aa995fe9bcf06f4760a31bde8a54987")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002502889-command-79907-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/initial-archive-command/report.lisp"
   :SHA256 "fcee71c0c9e8e19b8d425ccecbf2648694d63fbd02badcb243694800d084c329")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002502890-command-79932-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/failed-fixture-command/conservazione.lisp"
   :SHA256 "1e51e6745e3077f3a56b0c57eb49286c880c8d954ae7a0629f13b03c935571c1")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002502890-command-79932-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/failed-fixture-command/report.lisp"
   :SHA256 "262dd842e60c5e665232efdf3eb17caae148caa89c2fb4858cdcce2c52dabdad")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002503993-command-85830-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/final-archive-command/conservazione.lisp"
   :SHA256 "4ad815f1fbb33742c13db743e9d75323f355bc8c8c19501ddf10f19efbac88f6")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002503993-command-85830-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/final-archive-command/report.lisp"
   :SHA256 "9aa09204db21fef8f368efc8d5325bd59d76cdf5ff07d89a9b44e931e7f3ee8b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504001-command-85891-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/qualification-command/conservazione.lisp"
   :SHA256 "bdfb518034303187225b20de797f00ea41c70a8c71e6c99d0e2395f3c9f1d786")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504001-command-85891-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/qualification-command/report.lisp"
   :SHA256 "97b81d5e8dd449f8ca0747bba6a92b7d61837dc09da6940791ef4c890ae4e917")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504113-command-86188-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/benchmark-archive-command/conservazione.lisp"
   :SHA256 "985b5177237d1d6de16b8841cc0bdd2a47d1074ef64c90ae122fe519243a8461")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504113-command-86188-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/benchmark-archive-command/report.lisp"
   :SHA256 "5779673803d653f9537608061f74f91beb42f13715aae4b0444101821b58bde2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504116-command-86219-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/analysis-command/conservazione.lisp"
   :SHA256 "240e7fb615f873cc9438e198c7a28ab6af7d0310f182a68d9308187a37c3ced9")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504116-command-86219-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/analysis-command/report.lisp"
   :SHA256 "7ee018e86ab7c33edf4c5cb68bf6e46d252f9da9e84fb918a88ed9c75710c69b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504123-command-86343-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/identity-command/conservazione.lisp"
   :SHA256 "7f5a77abd3a04770f53cec98bd44ec9fa60e1b716310d2b524a5f0b3b31e1419")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504123-command-86343-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/identity-command/report.lisp"
   :SHA256 "1ce77069b5f4b0e7f41eba49d10f4987fbddabe839043b5415dac8395b214d63")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504163-command-86563-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/printed-metrics-command/conservazione.lisp"
   :SHA256 "21a8730ccf7211c45449dee54210b94bef7f2713675dc25aaa063a4a1ff9a283")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504163-command-86563-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/printed-metrics-command/report.lisp"
   :SHA256 "18dad54dcadc5b2266bb696f85d841f4f10da877e728490a82f2a12d42c9ce35")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504217-command-86720-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/ci-check-command/conservazione.lisp"
   :SHA256 "d94f948f90c3bc14c926804c1436995f5b25cf191df940c780a956510818985f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504217-command-86720-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/ci-check-command/report.lisp"
   :SHA256 "21720e622fd1580f5dbd95c52fff021bced8311fe94ec7be19c16d7c92aeea6b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504218-command-86765-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/ci-self-test-command/conservazione.lisp"
   :SHA256 "033a00f57057fbaba66e8b77806c09103a08975f9536d3160ce358f30c0298b3")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504218-command-86765-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/ci-self-test-command/report.lisp"
   :SHA256 "339c87fc88ea31b3607fdf989440dc30b781e7b17be081efd3d03d29de74df7c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504217-command-86719-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/final-checks/conservazione.lisp"
   :SHA256 "8d77e832954c11a7d18a6b41453ee6bf75e49966dbf515d9ba7e222d3026e5f4")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504217-command-86719-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/final-checks/report.lisp"
   :SHA256 "e071f39470774e3c0e7ac9b4a1efa60bccece1f39613aeb13e4c3ef8f986ef6d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504255-command-87377-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/late-archive-command/conservazione.lisp"
   :SHA256 "2bf46fde01aef84a84db5e567fd461a4228a7a5de8ccf7c6c86759eb46f4c648")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504255-command-87377-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/late-archive-command/report.lisp"
   :SHA256 "c5bdcd7aa9660de8fe21ae9ddc55f548f5ee3fcb66150889a8fff151231d99fd")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504265-command-87442-0/conservazione.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/current-source-command/conservazione.lisp"
   :SHA256 "0b20819962ca17fae2afa62e7c36313a9f90aa24c8524feeef393ebf707145f0")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002504265-command-87442-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/current-source-command/report.lisp"
   :SHA256 "53274fcbfd0d5147c7fa97021c51c948f6054e75d580e92e73856ae8e01a1c47")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/0/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/0/scan-4.lisp"
   :SHA256 "c12273e6abc62390db1a11c3218f2c6cd2d8afb15b0f41ad90abbd9738db313f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/0/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/0/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/0/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/0/scan-4.stdout.log"
   :SHA256 "3c84b3f3995e9433b8e2f4236d93075bc7cf2283ff67aecdf6af7dccae2db7f0")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/0/session.pid"
   :SHA256 "562e37dca2d6ef2d3eb6a3779a8b7a6f3ff2ae07af269fc8bd9c7a155ac42393")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/0/stdout.lisp"
   :SHA256 "3c3e1d0db8c3c9caca1995916027d78492d2f580d5e50cdf94d4e59281dd4aed")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/1/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/1/scan-1.lisp"
   :SHA256 "f5cf8dea1f6a9bab830e2f366956ed0599e8c5e277ea88acd97b6e09e2ca0b3f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/1/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/1/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/1/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/1/scan-1.stdout.log"
   :SHA256 "4fff59ea4dc8b6ee073ecce069de45d062840b1e5bd94f7984a12d33a9272563")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/1/session.pid"
   :SHA256 "2c3b91505c34119c78d62235b215214592da3f331960c8267e8743bc8bcb09fc")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/1/stdout.lisp"
   :SHA256 "1408b0f66ab661b8673cd350d40e192493dba517be5a2705d382c63c8438d28d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/2/scan-3.lisp"
   :SHA256 "3207e3ca9b77ecd6eeda31a41c52b1f4160fa7e31343db978b5d91044d9789d2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/2/scan-3.stdout.log"
   :SHA256 "5ce5b9905c261132277bc38bdc64530639a4155d5e2c517a24ca3fb3818261a0")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/2/session.pid"
   :SHA256 "e16e605789c2c0d729184ff798f9af485548455ac0094697d15f7e0fd79beef0")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/2/stdout.lisp"
   :SHA256 "2e7fca2d9e2fc0d9537df579c78b038ae3c1477cd817cd40fffacbc4cda80597")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/3/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/3/scan-2.lisp"
   :SHA256 "284a94bd54efbd7db95c44b0be81d9a6d142c4adf8520a38bfd13b167fc10797")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/3/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/3/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/3/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/3/scan-2.stdout.log"
   :SHA256 "be371cabca5f282de95fd84162c6b1bdca0a38452df1639ccfb3d99e49b535da")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/3/session.pid"
   :SHA256 "11e19a227a7ad72d7b3d462a6e2a2f07c8766b79378de5b5ec8c589364da669f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/3/stdout.lisp"
   :SHA256 "25564bda945c2105101cc7d392d13240d14238d1a27e9acf8da5f5ae0875158d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/4/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/4/scan-5.lisp"
   :SHA256 "1e5f6922709183bed036b039dbea2d1bfa8c3489ae77a1bfe7e94295189062cc")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/4/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/4/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/4/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/4/scan-5.stdout.log"
   :SHA256 "bdbb58bfff6286788e506ac4122797f84bff58ceb6869fea4ddfb6b60ff2b12c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/4/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/4/session.pid"
   :SHA256 "fed42906c373c32052c94d2626e00ffa3d400883c43d0b7133c5cccbd80ebfdf")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/4/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/4/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/4/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/4/stdout.lisp"
   :SHA256 "2be099c08baa117e6464bba3c631874220ab09ec3b9d2dfa3fa3a54fb50eb69f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/5/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/5/scan-6.lisp"
   :SHA256 "25b03f2e3f4a1ebb5570fbd79f47918fa0e4996a0e7dc20af5902ede5f53e14f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/5/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/5/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/5/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/5/scan-6.stdout.log"
   :SHA256 "d578852652e6cd3795f4b47857f809408cc2c599e2c5e9e114001bafb9208020")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/5/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/5/session.pid"
   :SHA256 "9421c08954c7417e8591b9d72a57f7e46dda240ea94e042900a5a3ebbb24e22e")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/5/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/5/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/5/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/5/stdout.lisp"
   :SHA256 "c020b7cfad97537e62a5b046c84a727494a77429c7ba3d0b3c88699d692fadea")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/6/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/6/scan-7.lisp"
   :SHA256 "2411a270f18741f381628110a2ee3f8db76ea5fde1462e8c083fa66263c042ab")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/6/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/6/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/6/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/6/scan-7.stdout.log"
   :SHA256 "773d0dcd358809b45b4463c8152bfa6936bcec36e066ddda5f11bae28faba49b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/6/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/6/session.pid"
   :SHA256 "7d34a1c73aa63adac9d4929c2b121abb33ceaa14c976c0c1b389cc9051b44335")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/6/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/6/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/6/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/6/stdout.lisp"
   :SHA256 "632ff70d8e777211e68c9c6aa18fbbacd544790316335340e811020c0820425a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/7/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/7/scan-8.lisp"
   :SHA256 "1dc32487b015c15f2d58e7938a7a147002d90e89fbd8da54387d0cffaccc906c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/7/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/7/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/7/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/7/scan-8.stdout.log"
   :SHA256 "471d8294d294de44f783475421abc4b6b5e0b86a32eaf96c71327e66bab88537")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/7/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/7/session.pid"
   :SHA256 "b02607908bceb477bbb83a35efddd1bbdf99dd5cf23066e68097c58c25995c54")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/7/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/7/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/7/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/7/stdout.lisp"
   :SHA256 "ba7fcea75bc2864a21f3b940483384447375da9144341dee0b2be1a13f199598")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/8/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/8/scan-9.lisp"
   :SHA256 "80e2972f9f97524c1056786d11ce10acdf3d00c3efcc5411185a82fb15728ed6")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/8/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/8/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/8/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/8/scan-9.stdout.log"
   :SHA256 "60fd3f6a8a61fe31c4854b4ab4861b4efd512220e4fd7dfcd112d2e36e3f6425")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/8/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/8/session.pid"
   :SHA256 "ee83ce0a16310e585edc240ff1ecb432d3b685288e3f7bf03482dd871b7c307e")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/8/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/8/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/8/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/8/stdout.lisp"
   :SHA256 "31ea0941716566ef078790085e72650d0e0e931bcea03088f090c3f9e6fb9c66")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/9/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/9/scan-10.lisp"
   :SHA256 "7ccc2f922153b87d620dda34462463b9c6ef1564dfdbb863a8c02d626c38a6e4")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/9/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/9/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/9/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/9/scan-10.stdout.log"
   :SHA256 "9c3f0a758958d6e303b65c8731872e66f944246d8c21816e97033dfcda8f43e3")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/9/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/9/session.pid"
   :SHA256 "38c7ea90bb1443eaad89434048c82a8650e5ecbe9b4d8ccce89362504e53b469")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/9/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/9/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-NgZYH8/9/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-NgZYH8/9/stdout.lisp"
   :SHA256 "15ed29b95978e446d17cd9f520516673c21d11b1ceb647a83107d088cbc75fb4")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/0/scan-4.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/0/scan-4.lisp"
   :SHA256 "f80a1ecb1e0729ed1705f8ffb2fac0f5ea242204c032d9b52334653debaba5b6")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/0/scan-4.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/0/scan-4.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/0/scan-4.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/0/scan-4.stdout.log"
   :SHA256 "d76f1a4effe204376cfeaec463f87076cc61842a767a7fc45f32a35cb1b369b9")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/0/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/0/session.pid"
   :SHA256 "fa973e7aca9d4b801bdde79d560b55b6ad55ad859a738cc139050ffc5856819a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/0/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/0/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/0/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/0/stdout.lisp"
   :SHA256 "3c3e1d0db8c3c9caca1995916027d78492d2f580d5e50cdf94d4e59281dd4aed")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/1/scan-1.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/1/scan-1.lisp"
   :SHA256 "dfa4cdf1c8882e8e9cde38062500fb367c9e8cbfdd899bffa59058e9571afe68")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/1/scan-1.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/1/scan-1.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/1/scan-1.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/1/scan-1.stdout.log"
   :SHA256 "42a0ada184257f8e0e78579c9afdf72a65e4b0f25e1aa5753da45a3f7b996e66")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/1/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/1/session.pid"
   :SHA256 "d11573b86448e42e266f4b2d144ff3e54c8bb1d3831698b39a76282813713d32")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/1/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/1/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/1/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/1/stdout.lisp"
   :SHA256 "1408b0f66ab661b8673cd350d40e192493dba517be5a2705d382c63c8438d28d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/2/scan-3.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/2/scan-3.lisp"
   :SHA256 "90b1fd08864514d9380412a1df128763f0fe2a1d06f474d0b97534c668acb355")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/2/scan-3.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/2/scan-3.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/2/scan-3.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/2/scan-3.stdout.log"
   :SHA256 "c641cdf0aa99c219d8e990d9c326699c689fddc2e7b973891e07b7fb20b98d66")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/2/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/2/session.pid"
   :SHA256 "32cadb2190828e1e630ae1aaf8c6bf12370a09be4f3db73f53198a9876b40892")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/2/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/2/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/2/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/2/stdout.lisp"
   :SHA256 "2e7fca2d9e2fc0d9537df579c78b038ae3c1477cd817cd40fffacbc4cda80597")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/3/scan-2.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/3/scan-2.lisp"
   :SHA256 "65188d94ba468a6feae6cd1b2d2394bb8c1873294e280968446fc6ed19c57de9")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/3/scan-2.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/3/scan-2.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/3/scan-2.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/3/scan-2.stdout.log"
   :SHA256 "c8d55abbc85cb7b63462476ae838da7164d67885df79488c375c726662954382")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/3/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/3/session.pid"
   :SHA256 "e7d76c8b4ec74ed0a576b96dc65e23f2cf6f0205e5f5bca34a3fe50413666760")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/3/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/3/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/3/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/3/stdout.lisp"
   :SHA256 "25564bda945c2105101cc7d392d13240d14238d1a27e9acf8da5f5ae0875158d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/4/scan-5.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/4/scan-5.lisp"
   :SHA256 "73f71a867ef97e1c7ae0e834513e760484e01ada704e698f1ccdd347d1154b50")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/4/scan-5.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/4/scan-5.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/4/scan-5.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/4/scan-5.stdout.log"
   :SHA256 "d91124d41f5b32fb02b881e05f01b9b081e4b592e6b2d8fae978b3a88d0f612b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/4/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/4/session.pid"
   :SHA256 "bf59759bcd5a771a28a7bb1abb4b894a07112fa768f4f26ba5855b202da7a2ef")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/4/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/4/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/4/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/4/stdout.lisp"
   :SHA256 "2be099c08baa117e6464bba3c631874220ab09ec3b9d2dfa3fa3a54fb50eb69f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/5/scan-6.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/5/scan-6.lisp"
   :SHA256 "f79c6fbee09fcb04389917b614685f7ec7bc85682b8f1efcfd852aadc7b3788a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/5/scan-6.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/5/scan-6.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/5/scan-6.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/5/scan-6.stdout.log"
   :SHA256 "55b286ff3cf2d49a189a10b82276c63f644f4a5a7951fd7a7921c7e4d2eed7ca")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/5/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/5/session.pid"
   :SHA256 "42e89d88302b54a6504a27db8e0621bfec40c30db592621b6e2b9a5e99897ec2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/5/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/5/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/5/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/5/stdout.lisp"
   :SHA256 "c020b7cfad97537e62a5b046c84a727494a77429c7ba3d0b3c88699d692fadea")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/6/scan-7.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/6/scan-7.lisp"
   :SHA256 "178879bf22e30509c5c6923e31985d07ed37847b6dc647b0be218fdf4a118588")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/6/scan-7.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/6/scan-7.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/6/scan-7.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/6/scan-7.stdout.log"
   :SHA256 "3872df19486837a3c69041c462caedd074d25de18e5ff9e57af10e06bd887772")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/6/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/6/session.pid"
   :SHA256 "1bd3906d82572bd22272bc0a3d96279f8f737e1cd3ee25e5b056aa1f3b3d7e9b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/6/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/6/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/6/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/6/stdout.lisp"
   :SHA256 "632ff70d8e777211e68c9c6aa18fbbacd544790316335340e811020c0820425a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/7/scan-8.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/7/scan-8.lisp"
   :SHA256 "8e93b1ee0e5f1921bb12f4cc7a708b71637b21ce718d8e37864f3bfd454011eb")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/7/scan-8.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/7/scan-8.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/7/scan-8.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/7/scan-8.stdout.log"
   :SHA256 "976d17e04145277b703a01d9dc2ca6b16ca731d39bd6d1c7902ee1898794807b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/7/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/7/session.pid"
   :SHA256 "b4232098ba5d7bcfee8d6f0cf6180cba9ddb6b312fb463a4bfc8e7bc67a2b2b2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/7/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/7/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/7/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/7/stdout.lisp"
   :SHA256 "ba7fcea75bc2864a21f3b940483384447375da9144341dee0b2be1a13f199598")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/8/scan-9.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/8/scan-9.lisp"
   :SHA256 "cb50b2fbbc0633536f587a91e563f4d6e0c73e7a8e6a3028671a4180144ad86d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/8/scan-9.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/8/scan-9.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/8/scan-9.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/8/scan-9.stdout.log"
   :SHA256 "2e563d9122e0001b2a2cee61759bbf8f533e2291caa16ab5559d0f6405b6eb97")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/8/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/8/session.pid"
   :SHA256 "a4fe69facaa5dcd75ba35803ff06717f19d18072e1d9bb14a7c7e768a2d6dd14")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/8/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/8/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/8/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/8/stdout.lisp"
   :SHA256 "31ea0941716566ef078790085e72650d0e0e931bcea03088f090c3f9e6fb9c66")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/9/scan-10.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/9/scan-10.lisp"
   :SHA256 "76dabe9448b98c8c964b0791e085039bfd834a37c7a3d0e5b513f09f8edf9e7d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/9/scan-10.stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/9/scan-10.stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/9/scan-10.stdout.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/9/scan-10.stdout.log"
   :SHA256 "6c7b0f5702701776f22a8d89f020ab3be5e5bc262750cc9e4710fd16cce2eb8d")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/9/session.pid"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/9/session.pid"
   :SHA256 "f4dfaa4e8959f2f574d5f40d8019819ffc661ce8b172e9136557965ce054061b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/9/stderr.log"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/9/stderr.log"
   :SHA256 "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-check-JBRGrj/9/stdout.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-check-JBRGrj/9/stdout.lisp"
   :SHA256 "15ed29b95978e446d17cd9f520516673c21d11b1ceb647a83107d088cbc75fb4")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002502623-command-78615-0/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/4002502623-command-78615-0/self-test-report.lisp"
   :SHA256 "7e47f646dc8ee821fcd8e3536a898b414e928bb78b4cbfd416d95f7b431a963b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002502625-reader-self-test-78632-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/4002502625-reader-self-test-78632-0/report.lisp"
   :SHA256 "3293012aaa1d418fc6114e686e8577f6fd2824d57b6d778fd8992555a249aacd")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002502625-snapshot-self-test-78629-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/4002502625-snapshot-self-test-78629-0/report.lisp"
   :SHA256 "12e8e90882daa2bfc4bfebac5882f9cab0e14ce69b76bc2a00e2832a123259af")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002503595-command-81886-0/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/4002503595-command-81886-0/self-test-report.lisp"
   :SHA256 "7e47f646dc8ee821fcd8e3536a898b414e928bb78b4cbfd416d95f7b431a963b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002503596-snapshot-self-test-81900-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/4002503596-snapshot-self-test-81900-0/report.lisp"
   :SHA256 "95405fa285c78bacb6b442e8401e44f2f632a8c5273e4a819e2e26c125c6a0be")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/4002503597-reader-self-test-81903-0/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/4002503597-reader-self-test-81903-0/report.lisp"
   :SHA256 "33e509a353de2b056999750abd4ea05af04adfe6fe235354c37fa2690b4ddc3b")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/command-archive-collector-self-test-rZ0S9C/self-test-report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/command-archive-collector-self-test-rZ0S9C/self-test-report.lisp"
   :SHA256 "42e4406320f89be3a7b895883f758f680e113fc7fefd18edcf24fe8d4835d7f7")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/evidence-parallel-self-test-0kQYB1/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/evidence-parallel-self-test-0kQYB1/report.lisp"
   :SHA256 "4681779dfbeb87b41f5839274c5142db1a9e37182a450d5587432149db7ff39a")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515111-85328/boundaries.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515111-85328/boundaries.lisp"
   :SHA256 "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515111-85328/conditions.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515111-85328/conditions.lisp"
   :SHA256 "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515111-85328/data.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515111-85328/data.lisp"
   :SHA256 "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515111-85328/measure.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515111-85328/measure.lisp"
   :SHA256 "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515111-85328/publication.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515111-85328/publication.lisp"
   :SHA256 "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515111-85328/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515111-85328/report.lisp"
   :SHA256 "3bf53e3748c34568e0fb83b9f6f7ed394be5c711a74ca8b7bdde88a45f49bc23")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515111-85328/tests.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515111-85328/tests.lisp"
   :SHA256 "ba1c0e543638f0424a2c9f3c07cc641b5f0e776c7e036135293eebd50a169904")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515111-85328/workflow.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515111-85328/workflow.lisp"
   :SHA256 "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515418-86764/boundaries.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515418-86764/boundaries.lisp"
   :SHA256 "45a300e40479bcaec51cae42c82b55e481861c06880c2d00527c2289c818df23")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515418-86764/conditions.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515418-86764/conditions.lisp"
   :SHA256 "d209de8e93efe4255f1ae149b8e88eef50a683378263e7953917230221c9235f")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515418-86764/data.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515418-86764/data.lisp"
   :SHA256 "1b61eec62d79d44cb0543b91c83c37d8c3ef787f125208c0093df05d63717fb2")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515418-86764/measure.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515418-86764/measure.lisp"
   :SHA256 "9da2833aeafef2ba03a78ef72bc7a1976d1fba4fee3ca693aab46a6e144dcb6c")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515418-86764/publication.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515418-86764/publication.lisp"
   :SHA256 "eb5ada9bf495a2d0c4f265a3499cd941e55c4ba526c118d9091f345b46fff8fc")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515418-86764/report.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515418-86764/report.lisp"
   :SHA256 "3bf53e3748c34568e0fb83b9f6f7ed394be5c711a74ca8b7bdde88a45f49bc23")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515418-86764/tests.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515418-86764/tests.lisp"
   :SHA256 "ba1c0e543638f0424a2c9f3c07cc641b5f0e776c7e036135293eebd50a169904")
  (:SOURCE
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/out/ci/selftest-1793515418-86764/workflow.lisp"
   :TARGET
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/support/ci/selftest-1793515418-86764/workflow.lisp"
   :SHA256 "2b5fb2eb839a3a22fb19dbcf406e287f2e8913c332a481ebe333960df73f2254"))
 :COMPACTIONS
 ((:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/source-identity.lisp"
   :STATUS :OK :ORIGINAL-BYTES 170154 :STORED-BYTES 54567 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "source-identity.lisp.gz" :UNCOMPRESSED-BYTES 170154 :UNCOMPRESSED-SHA256
    "f220b75b904602ade62bb670026ba9926d72d3c08879d58a4aea5a3974c58ece"
    :COMPRESSED-BYTES 54243 :COMPRESSED-SHA256
    "f15f1508fd44eaf1d0e9ad874c56bd79380493289fe3c6ee0791282a8848e62b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/analysis-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341456 :STORED-BYTES 109382 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341456 :UNCOMPRESSED-SHA256
    "7ee018e86ab7c33edf4c5cb68bf6e46d252f9da9e84fb918a88ed9c75710c69b"
    :COMPRESSED-BYTES 109066 :COMPRESSED-SHA256
    "27f000b767c59746b0abfb50f4a59f0723d68a1afa8ddef8f90e50a91ccd112d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/analysis-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341435 :STORED-BYTES 109364 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341435 :UNCOMPRESSED-SHA256
    "f1a8521c8a00e845547a4ef594893e0efa939f749ebab5a5545a4e4032fa3af3"
    :COMPRESSED-BYTES 109048 :COMPRESSED-SHA256
    "719f15f67534f9fe3736321ee270d5d0414598906a56df21509fd9731a34a63e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/archive-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341435 :STORED-BYTES 109372 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341435 :UNCOMPRESSED-SHA256
    "a88e00c9ef02386a664c3d05c58a438fc0072bb41d2f569997cc0e94059b0110"
    :COMPRESSED-BYTES 109056 :COMPRESSED-SHA256
    "1de47772e6fe390d2e9b25651aba227a756c69ff3a8abc7f25fbb6a4555f3839"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/baseline-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342185 :STORED-BYTES 109411 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342185 :UNCOMPRESSED-SHA256
    "b47d1b6882067cf0cf2dfccbf164e522f2c0c27748748129a2132327e8a90bdf"
    :COMPRESSED-BYTES 109095 :COMPRESSED-SHA256
    "962d07cabcc3e96954fd7b4e0d7f9a8babcdcd0c65b15d3fe020748d71868a60"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/baseline/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 395880 :STORED-BYTES 120128 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 395880 :UNCOMPRESSED-SHA256
    "6eb66dd6bae07a252bfa2b1d8976df30e19f6b20e37869d441cc8851fbec6050"
    :COMPRESSED-BYTES 119812 :COMPRESSED-SHA256
    "cc3585d869bbcd38daa06321c39ccbc9ac98464d790b24541ce3cb4b34a07142"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/benchmark-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341581 :STORED-BYTES 109361 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341581 :UNCOMPRESSED-SHA256
    "5779673803d653f9537608061f74f91beb42f13715aae4b0444101821b58bde2"
    :COMPRESSED-BYTES 109045 :COMPRESSED-SHA256
    "0904105814ca8e5685547f9e8e28dec7ef304992b4d56a1b54ce70786e0c13fa"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/benchmark/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 451321 :STORED-BYTES 130739 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 451321 :UNCOMPRESSED-SHA256
    "c54a6f36dec59e8f3dca2c665b7520f4205606d4028b7b74fbfa8d1786b24e55"
    :COMPRESSED-BYTES 130423 :COMPRESSED-SHA256
    "67e61e979e37788014309e76d484685084597a655109572e963311c97746dd2f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/ci-check-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341683 :STORED-BYTES 109440 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341683 :UNCOMPRESSED-SHA256
    "21720e622fd1580f5dbd95c52fff021bced8311fe94ec7be19c16d7c92aeea6b"
    :COMPRESSED-BYTES 109124 :COMPRESSED-SHA256
    "804cc8c3301f0f7e141efce9f961d038c5cfc25a7870aac3336b1bc505b9261b"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/ci-self-test-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342081 :STORED-BYTES 109535 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342081 :UNCOMPRESSED-SHA256
    "339c87fc88ea31b3607fdf989440dc30b781e7b17be081efd3d03d29de74df7c"
    :COMPRESSED-BYTES 109219 :COMPRESSED-SHA256
    "623396d7e5ae8ee038d4d85482576a2c6e96d7f454054306c66d2e8e51ba3146"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/codec-model/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341497 :STORED-BYTES 109436 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341497 :UNCOMPRESSED-SHA256
    "b297bf5b238e37e00c4a9deed6bdd40e9179e861708ea70b1e53cc3f2c09213f"
    :COMPRESSED-BYTES 109120 :COMPRESSED-SHA256
    "7d92bb39391c12839ccd2667eb30c43704e088a839c122cdefa097bba020773d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/current-source-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341433 :STORED-BYTES 109359 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341433 :UNCOMPRESSED-SHA256
    "53274fcbfd0d5147c7fa97021c51c948f6054e75d580e92e73856ae8e01a1c47"
    :COMPRESSED-BYTES 109043 :COMPRESSED-SHA256
    "b6c9c75ca5ba813879b5869658c12efbb7c08187b79f2877a7b4251b2ce65e07"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/development-absolute-child-path/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 348550 :STORED-BYTES 110115 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 348550 :UNCOMPRESSED-SHA256
    "f4d1accd66526b2fe8827ee9a42cd6096039504f226edc7e86ec1d2a514ab401"
    :COMPRESSED-BYTES 109799 :COMPRESSED-SHA256
    "dead909c99ca2e57d645699639f62db5bf98626aeef71859cbb4ae64e9ef692f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/development-codec-model/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341498 :STORED-BYTES 109429 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341498 :UNCOMPRESSED-SHA256
    "c2d6a8af29635e5370f6a841295b2c13d9e84c156325b224987d38f9df060042"
    :COMPRESSED-BYTES 109113 :COMPRESSED-SHA256
    "fc812376b0aeef25a1b2ca06544ced8b54484516f4eb5ecfb4fa5f90c46c07ec"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/development-documentation/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 347520 :STORED-BYTES 110669 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 347520 :UNCOMPRESSED-SHA256
    "db82082085510b588b47ad31d8953c62775a40a9f66df58d4d5e4356587c10c3"
    :COMPRESSED-BYTES 110353 :COMPRESSED-SHA256
    "c860bfa78bf75ddcff865d1be5e7fdfa30f63d88de516e18200d9e9f8029256c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/development-focused-deadline/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 355181 :STORED-BYTES 111547 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 355181 :UNCOMPRESSED-SHA256
    "687c31b85ad567de69916e6202f4bc3975ed5155843f5b071e552424817508f0"
    :COMPRESSED-BYTES 111231 :COMPRESSED-SHA256
    "c18d94cd234469f2528519fefc05a8fdb7274afa164b5522ad6a627e519daa9c"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/development-focused-initial/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 354740 :STORED-BYTES 111409 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 354740 :UNCOMPRESSED-SHA256
    "3c737118dfce8634bb9985051fae671c0e869ce38854c5d4906946f109352157"
    :COMPRESSED-BYTES 111093 :COMPRESSED-SHA256
    "3e2e1cea3fc1a18d9f69199bb939d592091b2e8139b0383f354128b5375cd7a3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/development-log-collision/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 351424 :STORED-BYTES 111002 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 351424 :UNCOMPRESSED-SHA256
    "a88e7097a8fc0a4c366b34264d7ca1f2b1f7d8bf1f25873f57ad5927e8d22470"
    :COMPRESSED-BYTES 110686 :COMPRESSED-SHA256
    "cd82ccb88e8d5ca753ebe895ea9b987981c77ddcba107f2005235490d3cb4616"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/development-print-initialization/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 344906 :STORED-BYTES 110265 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 344906 :UNCOMPRESSED-SHA256
    "d07a152b1ac7d62c10183ad49d3dd6bf60021ac38f1d27d6571b8d1b48534fc3"
    :COMPRESSED-BYTES 109949 :COMPRESSED-SHA256
    "df7542bf8f577f2cde51d5359b55ed57e1dba9f771357c80eee2ca761e561930"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/development-test-preflight/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 349439 :STORED-BYTES 111683 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 349439 :UNCOMPRESSED-SHA256
    "9068e8cf4b007678a89d5429acf1d0dbfc59f49de0b36c95ad3540565349a0e8"
    :COMPRESSED-BYTES 111367 :COMPRESSED-SHA256
    "a37873d31d0d30e2e5ec48fe45a07ad78e1d6186cfdbca9eff02ebc5f4806b34"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/development-test-reader/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 347234 :STORED-BYTES 110736 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 347234 :UNCOMPRESSED-SHA256
    "2b681b28afbc7806812da3aad6fd659eb109b5ffbf756c08b2716687cb41e34e"
    :COMPRESSED-BYTES 110420 :COMPRESSED-SHA256
    "4780cc3d11af14faf49375717311b21f556dbbf1793572f3aaec45347eeddb8f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/documentation/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 345150 :STORED-BYTES 110220 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 345150 :UNCOMPRESSED-SHA256
    "be697d81e728c50898916a6626d44c93967c0db4915fcb28211cf9ba38ddd4c4"
    :COMPRESSED-BYTES 109904 :COMPRESSED-SHA256
    "c43fcd543ab9787b1f9bca7dde01772d2c9ca97b4308e341d6e2dc3fd35189f3"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/failed-fixture-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341410 :STORED-BYTES 109358 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341410 :UNCOMPRESSED-SHA256
    "262dd842e60c5e665232efdf3eb17caae148caa89c2fb4858cdcce2c52dabdad"
    :COMPRESSED-BYTES 109042 :COMPRESSED-SHA256
    "8b460c07e13a2cbafa81757380e083e4bbf06af9baa6612d9652091c10a891b5"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/final-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341574 :STORED-BYTES 109364 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341574 :UNCOMPRESSED-SHA256
    "9aa09204db21fef8f368efc8d5325bd59d76cdf5ff07d89a9b44e931e7f3ee8b"
    :COMPRESSED-BYTES 109048 :COMPRESSED-SHA256
    "0b55edab42e0f2b0a3f59e193a5e44c3f57a2ba0076d67155d17257cb437cb71"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/final-checks/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342032 :STORED-BYTES 109713 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342032 :UNCOMPRESSED-SHA256
    "e071f39470774e3c0e7ac9b4a1efa60bccece1f39613aeb13e4c3ef8f986ef6d"
    :COMPRESSED-BYTES 109397 :COMPRESSED-SHA256
    "10739314142356df59de66fa14ea7f3231ba1c0e96eb156177b6971870f88560"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/focused/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 355255 :STORED-BYTES 111570 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 355255 :UNCOMPRESSED-SHA256
    "781175513cc6bd36ae5d139fada67d99e96fefb8cab7e747f06aa51ef1edeeec"
    :COMPRESSED-BYTES 111254 :COMPRESSED-SHA256
    "ef6bb282a5f40d4a9768f4de643e482de35c061c26ee68b2d5a12104f4edae7d"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/identity-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341433 :STORED-BYTES 109367 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341433 :UNCOMPRESSED-SHA256
    "1ce77069b5f4b0e7f41eba49d10f4987fbddabe839043b5415dac8395b214d63"
    :COMPRESSED-BYTES 109051 :COMPRESSED-SHA256
    "8d6cd99064b84dd85bdc0cf7202e755a81dd6b70b2d87036ad1527d2d9f0236f"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/identity-self-test/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341433 :STORED-BYTES 109360 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341433 :UNCOMPRESSED-SHA256
    "5193e8142debd1276787e4166069a967540768d3f9f0a1d877f2f657eb5fbbe0"
    :COMPRESSED-BYTES 109044 :COMPRESSED-SHA256
    "6caf315eb14b8aae85906fbe6a1c5cf3b1d88e2c6de57154306e4e16e217432e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/initial-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341578 :STORED-BYTES 109365 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341578 :UNCOMPRESSED-SHA256
    "fcee71c0c9e8e19b8d425ccecbf2648694d63fbd02badcb243694800d084c329"
    :COMPRESSED-BYTES 109049 :COMPRESSED-SHA256
    "e7c1bf0314c76f1abda647144df37dd0995f386b8213566e9abb1dd78cf0efcc"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/late-archive-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341571 :STORED-BYTES 109359 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341571 :UNCOMPRESSED-SHA256
    "c5bdcd7aa9660de8fe21ae9ddc55f548f5ee3fcb66150889a8fff151231d99fd"
    :COMPRESSED-BYTES 109043 :COMPRESSED-SHA256
    "1f21c97e8b096387a746efec4919a4e9275cc75d4dc592df79031ba09fee1419"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/printed-metrics-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 342732 :STORED-BYTES 109871 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 342732 :UNCOMPRESSED-SHA256
    "18dad54dcadc5b2266bb696f85d841f4f10da877e728490a82f2a12d42c9ce35"
    :COMPRESSED-BYTES 109555 :COMPRESSED-SHA256
    "1eba337ebf96e840723b9954228785d51a4c9da791744c203560404a921cbbde"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/qualification-command/report.lisp"
   :STATUS :OK :ORIGINAL-BYTES 341401 :STORED-BYTES 109350 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "report.lisp.gz" :UNCOMPRESSED-BYTES 341401 :UNCOMPRESSED-SHA256
    "97b81d5e8dd449f8ca0747bba6a92b7d61837dc09da6940791ef4c890ae4e917"
    :COMPRESSED-BYTES 109034 :COMPRESSED-SHA256
    "d9d11d2609eb02c7b2dd2d3699241160832c361a3e09fa0c2cc6bcefae98449e"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/baseline-001-v1-server-31.stderr"
   :STATUS :OK :ORIGINAL-BYTES 9089 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-001-v1-server-31.stderr.gz" :UNCOMPRESSED-BYTES 9089
    :UNCOMPRESSED-SHA256
    "43882f40da896b846dbd343fde91c5217592da6d057a075b578973e630d624b2"
    :COMPRESSED-BYTES 86 :COMPRESSED-SHA256
    "c9643068a315aadf7d271bd79318d58ca61844c15d60a7ffb006cee6e93edbdb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/baseline-003-v1-server-32.stderr"
   :STATUS :OK :ORIGINAL-BYTES 9089 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-003-v1-server-32.stderr.gz" :UNCOMPRESSED-BYTES 9089
    :UNCOMPRESSED-SHA256
    "43882f40da896b846dbd343fde91c5217592da6d057a075b578973e630d624b2"
    :COMPRESSED-BYTES 86 :COMPRESSED-SHA256
    "c9643068a315aadf7d271bd79318d58ca61844c15d60a7ffb006cee6e93edbdb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/baseline-005-v1-server-33.stderr"
   :STATUS :OK :ORIGINAL-BYTES 9086 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-005-v1-server-33.stderr.gz" :UNCOMPRESSED-BYTES 9086
    :UNCOMPRESSED-SHA256
    "78b3c0a7dabcfb27c98e98e38325bb277292af305f40451abc60f6792bfbbd30"
    :COMPRESSED-BYTES 85 :COMPRESSED-SHA256
    "2b4a1ba08e1618ed165c2a3bdf8bcc1614e03434aef7cfb8c139828d0a0490fe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/baseline-007-v1-server-34.stderr"
   :STATUS :OK :ORIGINAL-BYTES 9086 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-007-v1-server-34.stderr.gz" :UNCOMPRESSED-BYTES 9086
    :UNCOMPRESSED-SHA256
    "78b3c0a7dabcfb27c98e98e38325bb277292af305f40451abc60f6792bfbbd30"
    :COMPRESSED-BYTES 85 :COMPRESSED-SHA256
    "2b4a1ba08e1618ed165c2a3bdf8bcc1614e03434aef7cfb8c139828d0a0490fe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/baseline-009-v2-server-35.stderr"
   :STATUS :OK :ORIGINAL-BYTES 9089 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-009-v2-server-35.stderr.gz" :UNCOMPRESSED-BYTES 9089
    :UNCOMPRESSED-SHA256
    "43882f40da896b846dbd343fde91c5217592da6d057a075b578973e630d624b2"
    :COMPRESSED-BYTES 86 :COMPRESSED-SHA256
    "c9643068a315aadf7d271bd79318d58ca61844c15d60a7ffb006cee6e93edbdb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/baseline-011-v2-server-36.stderr"
   :STATUS :OK :ORIGINAL-BYTES 9089 :STORED-BYTES 418 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-011-v2-server-36.stderr.gz" :UNCOMPRESSED-BYTES 9089
    :UNCOMPRESSED-SHA256
    "43882f40da896b846dbd343fde91c5217592da6d057a075b578973e630d624b2"
    :COMPRESSED-BYTES 86 :COMPRESSED-SHA256
    "c9643068a315aadf7d271bd79318d58ca61844c15d60a7ffb006cee6e93edbdb"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/baseline-013-v2-server-37.stderr"
   :STATUS :OK :ORIGINAL-BYTES 9086 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-013-v2-server-37.stderr.gz" :UNCOMPRESSED-BYTES 9086
    :UNCOMPRESSED-SHA256
    "78b3c0a7dabcfb27c98e98e38325bb277292af305f40451abc60f6792bfbbd30"
    :COMPRESSED-BYTES 85 :COMPRESSED-SHA256
    "2b4a1ba08e1618ed165c2a3bdf8bcc1614e03434aef7cfb8c139828d0a0490fe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/baseline-015-v2-server-38.stderr"
   :STATUS :OK :ORIGINAL-BYTES 9086 :STORED-BYTES 417 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "baseline-015-v2-server-38.stderr.gz" :UNCOMPRESSED-BYTES 9086
    :UNCOMPRESSED-SHA256
    "78b3c0a7dabcfb27c98e98e38325bb277292af305f40451abc60f6792bfbbd30"
    :COMPRESSED-BYTES 85 :COMPRESSED-SHA256
    "2b4a1ba08e1618ed165c2a3bdf8bcc1614e03434aef7cfb8c139828d0a0490fe"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/final-001-v1-server-31.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16929 :STORED-BYTES 442 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-001-v1-server-31.stderr.gz" :UNCOMPRESSED-BYTES 16929
    :UNCOMPRESSED-SHA256
    "53c74d1cf7822dc0c636c3a1ff81c3d6e362b4cce75be93e76a60dc4092d4b41"
    :COMPRESSED-BYTES 111 :COMPRESSED-SHA256
    "609887689dace44b825368f73c8591f7d0e388818b88c7463b567c4ddbe61fbd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/final-003-v1-server-32.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16929 :STORED-BYTES 442 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-003-v1-server-32.stderr.gz" :UNCOMPRESSED-BYTES 16929
    :UNCOMPRESSED-SHA256
    "53c74d1cf7822dc0c636c3a1ff81c3d6e362b4cce75be93e76a60dc4092d4b41"
    :COMPRESSED-BYTES 111 :COMPRESSED-SHA256
    "609887689dace44b825368f73c8591f7d0e388818b88c7463b567c4ddbe61fbd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/final-005-v1-server-33.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16926 :STORED-BYTES 441 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-005-v1-server-33.stderr.gz" :UNCOMPRESSED-BYTES 16926
    :UNCOMPRESSED-SHA256
    "7c6f9598766da13393eac318ff272ba4f37dcd1deb3da394979ff4fd85e44436"
    :COMPRESSED-BYTES 110 :COMPRESSED-SHA256
    "a962f263224985084c6cdec490f8a2b8f59dd4d5e69626daba4ed4c29881b344"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/final-007-v1-server-34.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16926 :STORED-BYTES 441 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-007-v1-server-34.stderr.gz" :UNCOMPRESSED-BYTES 16926
    :UNCOMPRESSED-SHA256
    "7c6f9598766da13393eac318ff272ba4f37dcd1deb3da394979ff4fd85e44436"
    :COMPRESSED-BYTES 110 :COMPRESSED-SHA256
    "a962f263224985084c6cdec490f8a2b8f59dd4d5e69626daba4ed4c29881b344"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/final-009-v2-server-35.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16929 :STORED-BYTES 442 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-009-v2-server-35.stderr.gz" :UNCOMPRESSED-BYTES 16929
    :UNCOMPRESSED-SHA256
    "53c74d1cf7822dc0c636c3a1ff81c3d6e362b4cce75be93e76a60dc4092d4b41"
    :COMPRESSED-BYTES 111 :COMPRESSED-SHA256
    "609887689dace44b825368f73c8591f7d0e388818b88c7463b567c4ddbe61fbd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/final-011-v2-server-36.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16929 :STORED-BYTES 442 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-011-v2-server-36.stderr.gz" :UNCOMPRESSED-BYTES 16929
    :UNCOMPRESSED-SHA256
    "53c74d1cf7822dc0c636c3a1ff81c3d6e362b4cce75be93e76a60dc4092d4b41"
    :COMPRESSED-BYTES 111 :COMPRESSED-SHA256
    "609887689dace44b825368f73c8591f7d0e388818b88c7463b567c4ddbe61fbd"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/final-013-v2-server-37.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16926 :STORED-BYTES 441 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-013-v2-server-37.stderr.gz" :UNCOMPRESSED-BYTES 16926
    :UNCOMPRESSED-SHA256
    "7c6f9598766da13393eac318ff272ba4f37dcd1deb3da394979ff4fd85e44436"
    :COMPRESSED-BYTES 110 :COMPRESSED-SHA256
    "a962f263224985084c6cdec490f8a2b8f59dd4d5e69626daba4ed4c29881b344"))
  (:PATH
   "/Users/gpicchiarelli/.codex/worktrees/m1-service-index-discovery/ArcDocDB/spikes/results/2026-11-01-local-write-groups/unix-logs/final-015-v2-server-38.stderr"
   :STATUS :OK :ORIGINAL-BYTES 16926 :STORED-BYTES 441 :DESCRIPTOR
   (:SCHEMA-VERSION 1 :KIND :COMPRESSED-EVIDENCE :CODEC :GZIP :PAYLOAD
    "final-015-v2-server-38.stderr.gz" :UNCOMPRESSED-BYTES 16926
    :UNCOMPRESSED-SHA256
    "7c6f9598766da13393eac318ff272ba4f37dcd1deb3da394979ff4fd85e44436"
    :COMPRESSED-BYTES 110 :COMPRESSED-SHA256
    "a962f263224985084c6cdec490f8a2b8f59dd4d5e69626daba4ed4c29881b344")))
 :VERIFIED-FILES 220 :HASH-METHOD :STORED-BYTES-OR-VERIFIED-LOSSLESS-EXPANSION
 :LIMITS
 (:NEGATIVE-SELF-TEST-FIXTURE-TREES-EXCLUDED
  :NO-QUALIFICATION-INFERENCE-FROM-EXIT-CODE-ALONE))
