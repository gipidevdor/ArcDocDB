;;;; Independent STATIC review data only. Not a program, test result or qualification.
;;;; No product, tests or documentation were changed. Do not LOAD this data file.
(:schema 1
 :kind :independent-static-histogram-review
 :date "2026-11-01"
 :workspace "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB"
 :branch "codex/metrics-histograms"
 :reviewed-head "f5cae677e2f78a73dc5c2983fc24a854afee1724"
 :source-clean-at-read t
 :mode :static-only
 :executed (:compilation nil :tests nil :benchmarks nil :diagnostics nil)
 :scope (:existing-first-increment :counter-consolidation-design-constraints
         :coherent-snapshot-design-constraints :future-aggregation-contract)
 :not-reviewed (:parallel-merge-implementation :future-counter-implementation
                :engine-instrumentation :runtime-publication-protocol)
 :conclusion
 (:confirmed-current-implementation-bugs 0
  :statement "No confirmed correctness defect found in the first increment under its documented owner/private-state contract. Five concrete design constraints below need decisions in subsequent increments; they are not claims of bugs in an aggregation implementation, which does not exist in the reviewed sources."
  :merge-implication "Do not treat future-aggregation constraints as standalone blockers for the existing histogram-only increment. Resolve D1/D2 when adding counters and a coherent combined snapshot; resolve D3/D4/D5 before claiming aggregate correctness. No merge implementation was attempted.")
 :source-blobs
 ((:file "src/metrics/package.lisp" :git-blob "32a6b72af6c82c058f06a9ffc5c6bc706df48aee")
  (:file "src/metrics/types.lisp" :git-blob "c75da0ff4fbeabb78c2d281879320d96b4674e43")
  (:file "src/metrics/geometry.lisp" :git-blob "0296b72a27584238cb5364c2454a573e8533d5f2")
  (:file "src/metrics/build.lisp" :git-blob "50cd7cc335a8f3016c4e1ba041f639c3ff86a72a")
  (:file "src/metrics/record.lisp" :git-blob "5da0431c37b0a7d0cff27c7e117de27277797487")
  (:file "src/metrics/snapshot.lisp" :git-blob "d2f483b6b7c1ff5cf78552cc0b5da020e22613b1")
  (:file "src/metrics/quantile.lisp" :git-blob "8e45b9613f63129f611a95155b10a27d2982c257")
  (:file "docs/implementazione/istogrammi-latenza.md" :git-blob "cd81bbc07315160994e15cc14cf1989ea5a021f9")
  (:file "docs/implementazione/istogrammi-latenza-metodo.md" :git-blob "135ed8079d19debda9889ef22a5d1a4174a3772b"))
 :findings
 ((:id :D1
   :classification :confirmed-design-constraint
   :current-implementation-bug-p nil
   :priority :resolve-before-coherent-counter-snapshot
   :title "One histogram scope cannot be composed by nesting public histogram operations"
   :references
   ((:file "src/metrics/record.lisp" :lines (24 41))
    (:file "src/metrics/record.lisp" :lines (63 81))
    (:file "src/metrics/snapshot.lisp" :lines (7 18))
    (:file "tests/metrics/isolation.lisp" :lines (91 127)))
   :evidence "The active dynamic identity is per thread, not per histogram. Every public record/reset/capture enters that scope, so another public operation on any histogram in the same scope rejects with :metrics-histogram-reentry. The faulty flag and its commit cover only the supplied histogram."
   :static-counterexamples
   ("Wrap a combined capture in the existing read-only histogram scope, then call istantanea-istogramma: it necessarily rejects on reentry. This follows directly from the two scope entries; it was not executed."
    "Call registra-latenza, let it finish, then update a separate completed-request counter. An abnormal exit between the two leaves the histogram healthy and the counter behind. Reversing the order moves rather than removes the gap."
    "Copy a request counter, then call public histogram capture without an outer guard covering both. A reentrant owner callback between the copies can record another request, yielding fields from different logical instants.")
   :impact "Independent per-component health and same-owner execution do not prove coherence of the new combined image. A naive nested wrapper instead fails every call."
   :action "Define one entry/reentry and fault/commit boundary for the entire owner-local metrics bundle, covering event counters, latency acceptance, reset and combined capture. Use private already-entered helpers where composition is needed, while preserving guarded public APIs. Mark bundle mutation faulty before its first write and clear it only after every related field is consistent. Require recovery/reset of the affected bundle after an interrupted update. Combined capture must remain read-only, including on allocation failure."
   :qualification "The current histogram's own guard and fault marker are internally consistent. The counter bundle and wrapper are absent; no existing torn combined snapshot is alleged.")
  (:id :D2
   :classification :confirmed-representation-limitation
   :current-implementation-bug-p nil
   :priority :resolve-before-request-counters-and-throughput
   :title "Accepted histogram population cannot serve as the request counter"
   :references
   ((:file "src/metrics/record.lisp" :lines (45 59))
    (:file "src/metrics/types.lisp" :lines (50 60))
    (:file "src/metrics/quantile.lisp" :lines (40 52))
    (:file "docs/implementazione/istogrammi-latenza.md" :lines (86 102)))
   :evidence "At the sample cap, further valid observations set only sticky saturation. Population, bin counts and accepted maximum remain unchanged. A snapshot stores neither attempted observations nor a rejection count."
   :static-counterexample "With limit 2 and three valid submitted request latencies, histogram population is 2 and completeness is NIL. The same snapshot state can result from any larger number of rejected observations whose accepted prefix is the same. Request throughput cannot be reconstructed from that state."
   :impact "Using campioni for completed requests undercounts after the cap; stopping request counters when latency acceptance stops would hide ongoing work. Saturation also means an accepted-prefix percentile, not a distribution of all completed requests."
   :action "Keep request/outcome counters independent of latency sample acceptance, with explicit bounded-counter and loss semantics. Define which events each counter counts and how missing/invalid durations are represented. Carry separate latency completeness and counter completeness into combined snapshots, and update the chosen fields under D1's bundle boundary. Preserve histogram accepted maximum on rejection."
   :qualification "Reaching the cap without rejecting an observation correctly remains complete. The first rejection makes completeness false. No current saturation or wrap defect was found.")
  (:id :D3
   :classification :confirmed-missing-provenance
   :current-implementation-bug-p nil
   :priority :resolve-before-aggregation-or-window-rates
   :title "Snapshots cannot establish disjoint sources or a coherent observation window"
   :references
   ((:file "src/metrics/types.lisp" :lines (21 33))
    (:file "src/metrics/types.lisp" :lines (50 60))
    (:file "src/metrics/record.lisp" :lines (73 81))
    (:file "src/metrics/snapshot.lisp" :lines (13 18))
    (:file "docs/implementazione/istogrammi-latenza.md" :lines (104 125)))
   :evidence "The snapshot consists only of config, counts, accepted population, saturation and accepted maximum. Reset clears state without a generation. Neither source/Serie/measurement identity, capture revision, cumulative/delta semantics, epoch nor measurement interval is represented. Clock-domain keyword is config metadata, not source or window identity."
   :static-counterexamples
   ("Two cumulative captures of one producer at populations 100 and 120 sum to 220 if treated as independent contributors, although only 120 observations were submitted."
    "One producer's previous window and another producer's next window may have identical configs and perfectly valid local snapshots. Their sum is not evidence of a shared time window."
    "An aggregate over A+B later combined with A overlaps provenance even if the outer snapshot objects differ. Object identity or a direct-input-only duplicate check cannot detect all such overlaps."
    "A collector expecting A+B but receiving only A sees a locally complete histogram. That local flag cannot establish complete cross-producer coverage.")
   :impact "Config-compatible, individually coherent images can still double-count observations, mix windows or conceal missing contributors. The existing percentile completeness flag establishes only local submission acceptance. It cannot certify global coverage or a throughput denominator."
   :action "Add an immutable external envelope or equivalent contract identifying source incarnation, measurement semantics, reset/window generation and capture revision, plus explicit cumulative/delta behavior. Define a common collection epoch and the injected interval/clock semantics required for rates; an epoch label alone does not prove identical elapsed intervals. Reject incompatible windows and duplicate/overlapping provenance, including nested aggregates, or define an explicit replacement rule for newer cumulative captures. Carry expected/received source coverage separately from local saturation completeness. Keep capture metadata derived on the cold path without mutating the observed metrics."
   :qualification "Aggregation and throughput are explicitly deferred by the first-increment document. The absence is a concrete limitation for future consolidation, not a violation of the current local histogram contract.")
  (:id :D4
   :classification :confirmed-representation-limit
   :current-implementation-bug-p nil
   :priority :resolve-before-aggregation
   :title "Valid source snapshots need not have a representable summed population"
   :references
   ((:file "src/metrics/types.lisp" :lines (8 18))
    (:file "src/metrics/types.lisp" :lines (28 33))
    (:file "src/metrics/types.lisp" :lines (50 60))
    (:file "src/metrics/quantile.lisp" :lines (6 12))
    (:file "src/metrics/quantile.lisp" :lines (20 24))
    (:file "docs/implementazione/istogrammi-latenza.md" :lines (44 47)))
   :evidence "Snapshot population and percentile rank/scan arithmetic are typed to 0..2^60-1, independently of the unsigned-64 bin representation. A source configuration also retains its own sample cap. Summing valid sources does not preserve those source-level constraints."
   :static-counterexamples
   ("Sources with populations 2^60-1 and 1 are individually valid and complete, but their combined population is outside campioni even though a combined bin holding 2^60 still fits unsigned-64."
    "Two complete sources with cap 2 and population 2 each yield population 4. Reusing either source's unchanged cap-2 config violates the documented population<=configured-cap invariant; merely widening the struct count would not resolve cap semantics.")
   :impact "A future merger can fail typed arithmetic or construct metadata inconsistent with its bins/cap unless it defines aggregate admission and result bounds. Uncoordinated per-bin saturation can break sum(counts)=population and percentile ranks."
   :action "Define an aggregate count bound and aggregate configuration/cap policy separately from each contributor's admission cap. Check total representability before constructing/publishing the result, using arithmetic that itself cannot wrap. If keeping the current snapshot type, reject over-bound totals explicitly before publication; if widening it, revisit rank and cumulative-scan contracts too. OR contributor latency-incompleteness into the output, retain source cap/provenance as needed, and never silently clamp bins or turn an incomplete input into a complete aggregate."
   :qualification "All current single-owner increments stay within their configured population bound; the present nearest-rank decomposition is sound within that bound. No merger was executed or reviewed.")
  (:id :D5
   :classification :confirmed-compatibility-constraint
   :current-implementation-bug-p nil
   :priority :resolve-before-aggregation
   :title "Array geometry equality is insufficient to preserve percentile intervals"
   :references
   ((:file "src/metrics/build.lisp" :lines (14 25))
    (:file "src/metrics/record.lisp" :lines (49 58))
    (:file "src/metrics/quantile.lisp" :lines (25 33))
    (:file "docs/implementazione/istogrammi-latenza.md" :lines (30 47)))
   :evidence "Actual values are compared to massimo before selecting the reserved overflow cell. Configurations can therefore have the same array length and precision while assigning a value to different kinds of cells. Units, frequency and domain also affect interpretation without necessarily changing array length."
   :static-counterexample "At precision 7, maxima 256 and 257 both map to index 256 and allocate 258 cells. Value 257 overflows under maximum 256 but is regular cell 256 under maximum 257. Reinterpreting the latter snapshot using maximum 256 can return regular bounds [256,256], excluding its actual value 257. This is a derivation from source, not a run of an existing merger."
   :impact "A length-only or geometry-only compatibility check would permit invalid interval semantics. Equal nominal units do not establish equal tick scale/domain; equal histogram configs do not establish equal metric meaning or disjoint provenance."
   :action "Centralize semantic compatibility checks for precision, maximum, unit, tick frequency and clock domain, as already required by the document. Compare validated values rather than config object identity; apply the explicit cap policy in D4. The envelope in D3 must additionally identify measurement semantics and compatible windows. Reject incompatible sources instead of reinterpreting counts."
   :qualification "Configuration construction already validates precision/range/cap/unit/scale/domain. The current documentation correctly warns against array-length-only aggregation. There is no missing compatibility check on any present public aggregation API, because none is implemented."))
 :static-checks-with-no-defect-found
 ((:area :saturation
   :references ((:file "src/metrics/record.lisp" :lines (45 59)))
   :reason "Each accepted observation increments exactly one bin and total once; total<=configured cap<=2^60-1 bounds individual bins below unsigned-64 overflow. Rejected valid samples affect only sticky saturation, not retained maximum. Invalid samples reject before entering mutation.")
  (:area :interrupted-mutation-and-reentry
   :references ((:file "src/metrics/record.lisp" :lines (24 41))
                (:file "src/metrics/record.lisp" :lines (73 81)))
   :reason "Fault precedes mutable histogram writes and is cleared only after their completion. An abnormal exit after admission conservatively leaves fault set; subsequent record/capture rejects until owner reset completes. Dynamic scope unwind releases reentry state without relying on cleanup to set fault. Nested rejected entry does not clear the outer scope. Interruption before writes cannot export a partial mutation.")
  (:area :snapshot-purity
   :references ((:file "src/metrics/snapshot.lisp" :lines (11 18))
                (:file "src/metrics/types.lisp" :lines (50 60)))
   :reason "Capture selects literal read-only mode, allocates independent array storage and copies metadata under the guard. It does not write histogram health/counters, so failed allocation/copy does not poison the source. Read-only slots and the unexported array accessor support the documented public immutability boundary. Caller-provided publication remains necessary.")
  (:area :percentile-rank-arithmetic
   :references ((:file "src/metrics/quantile.lisp" :lines (6 12))
                (:file "src/metrics/quantile.lisp" :lines (40 52)))
   :reason "For count=q*d+r and validated 1<=n<=d<=1e6, q*n+ceil(r*n/d) equals ceil(count*n/d) and lies in 1..count. q*n<=count; r*n<10^12. All intermediates fit the documented supported 64-bit fixnum target. The public API enforces n<=d before using the private helper.")
  (:area :percentile-intervals
   :references ((:file "src/metrics/geometry.lisp" :lines (8 24))
                (:file "src/metrics/quantile.lisp" :lines (17 34)))
   :reason "The inverse bucket bounds match the integer mapping. Regular upper bounds are clipped by configured and accepted maxima. A selected overflow bucket implies at least one accepted value>maximum, so [maximum+1,accepted maximum] is ordered and maximum+1 stays inside the latency domain on this reachable path. For maximum=2^60-1, overflow selection is unreachable from valid samples. Empty and all-zero populations remain distinct."))
 :verification-observations
 (:existing-test-source-read-only t
  :existing-static-coverage "Read tests/metrics support, geometry, quantiles, limits, isolation and allocation sources. They describe deterministic partial-write/read-abort fixtures, owner/reentry checks, immutable copies, synthetic full-cap arithmetic and allocation checks. None was run and no previous qualification result was independently re-established."
  :proposed-later-acceptance-cases
  ("One combined owner entry can record/reset/capture without nested-public-operation rejection."
   "An admitted abort between any two related counter/bin/metadata writes blocks combined capture until bundle recovery."
   "An aborted combined read leaves source counters and health unchanged."
   "Requests continue to count after latency cap; both counter and histogram loss semantics remain visible."
   "Aggregation rejects or explicitly handles total above its bound, duplicate/nested provenance, incompatible windows, missing expected contributors and same-length incompatible configurations.")
  :acceptance-cases-executed nil)
 :limitations
 ("Static source inspection and hand-derived counterexamples only; no compilation, Lisp evaluation, tests, allocation measurement, benchmarks or diagnostic workloads."
  "No runtime proof of arbitrary asynchronous SBCL interruption, safe publication, absence of allocation, emitted code ordering or exhaustive interleavings."
  "No review of the counter/snapshot implementation or merge assigned elsewhere; design recommendations are conditional on adding those features."
  "The private-state contract is assumed: callers do not mutate internal arrays, manufacture inconsistent private structs or rebind private guard state."
  "Line references and source identities apply to the reviewed HEAD. Parallel changes after review require a new scoped comparison.")
 :parallel-work-observed-at-final-status
 (:head-unchanged t
  :tracked-diff-empty t
  :untracked-files
  ("docs/implementazione/metriche-serie.md"
   "src/metrics/merge.lisp"
   "tests/metrics/merge.lisp")
  :read-or-modified-by-this-review nil
  :note "These files appeared during the authorized parallel work. They were deliberately excluded; conclusions apply to the reviewed first increment and are not a review of that merge implementation.")
 :writes
 ("spikes/out/metrics-counters-20261101/independent-histogram-review.lisp"))
