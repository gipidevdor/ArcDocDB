;;;; Independent STATIC review appendix. Data only; do not LOAD.
;;;; No product/test/doc edits, compilation, tests, benchmarks or diagnostics.
(:schema 1
 :kind :independent-static-increment2-final-review
 :date "2026-11-01"
 :workspace "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB"
 :branch "codex/metrics-histograms"
 :base-head "f5cae677e2f78a73dc5c2983fc24a854afee1724"
 :source-state :uncommitted-parallel-work
 :mode :static-only
 :executed (:product-evaluation nil :compilation nil :tests nil :benchmarks nil :diagnostics nil)
 :scope "All metric core files, their owner-scope/copy/reset integration, the increment-2 contract, and package/ASDF wiring. Tests and benchmark files are still being delivered by other agents and are not qualified by this review."
 :source-identities
 ((:file "src/metrics/package.lisp" :git-blob "b905774909f23cc7feb2d7c34cde71ba64cd50b0")
  (:file "src/metrics/types.lisp" :git-blob "c75da0ff4fbeabb78c2d281879320d96b4674e43")
  (:file "src/metrics/geometry.lisp" :git-blob "0296b72a27584238cb5364c2454a573e8533d5f2")
  (:file "src/metrics/build.lisp" :git-blob "50cd7cc335a8f3016c4e1ba041f639c3ff86a72a")
  (:file "src/metrics/record.lisp" :git-blob "91363d11fe77189843557e865fb847663d382666")
  (:file "src/metrics/snapshot.lisp" :git-blob "d62df8c6ffa6cc19ad9ff3e8173379bbf5cb4dcf")
  (:file "src/metrics/quantile.lisp" :git-blob "8e45b9613f63129f611a95155b10a27d2982c257")
  (:file "src/metrics/merge.lisp" :git-blob "445d5ff67f56ca4aaae34d82c46a8fb4f4704fdf")
  (:file "src/metrics/counter-types.lisp" :git-blob "61e82d23cbfc2751addb0405abe6d4392acdb10d")
  (:file "src/metrics/counter-build.lisp" :git-blob "4292c00921e6e719de04b97ba142d3f048e67945")
  (:file "src/metrics/counter-record.lisp" :git-blob "5d1310232dee433bfed5bc6958c6e28383ee9f4d")
  (:file "src/metrics/counter-snapshot.lisp" :git-blob "3f9378483c23d26fd5afe829d4b615782e0ec2e6")
  (:file "src/metrics/counter-aggregate.lisp" :git-blob "9a6d6a4be168da17c45641b98859ca930ba052e0")
  (:file "docs/implementazione/metriche-serie.md" :git-blob "96d1558de408b3e17e61266f0aacef8e20ba5e72")
  (:file "arcdocdb.asd" :git-blob "cb259d52933d902e6e43597abc93fa9580a18b3f"))
 :accepted-contract
 (:capture-api "istantanea-metriche(metrics, fine)"
  :serie-reader "istantanea-metriche-serie(snapshot)"
  :guard "The private request histogram owns the entire partition's existing thread-local reentry/fault scope; child histograms are private and already-entered helpers avoid nested public operations."
  :cap "Request/flush counters and their latency populations share event admission and the same cap. Counters intentionally describe retained event prefixes after rejection, with separate completeness flags. Independent attempted-request throughput is not required by this agreed increment."
  :sticky-admission "The current %contatore-disponibile-p checks both the incomplete bit and remaining capacity. Rejected append/flush families remain closed until reset, even for later zero or smaller increments."
  :provenance "Logical partition identities are unique (serie, worker) pairs assigned by the adapter; original pairs survive aggregation hierarchy."
  :window "Inputs must have matching supplied endpoints. Truthful event/window attribution and safely published, caller-stable input vectors are adapter/caller preconditions."
  :completeness "Completeness concerns submitted-event accounting within the represented accounting period; it does not certify missing producers, uninstrumented operations, true physical clock cuts or global atomicity.")
 :conclusion
 (:confirmed-core-findings 1
  :finding-status :open-at-counter-snapshot-blob-above
  :summary "One local same-owner admission gap remains: mutable start and entry-fault decisions are read before the guard. No further concrete core defect found in current sticky rejection, whole-reset marker lifetime, read-only capture body, aggregate provenance/window comparison or bounded arithmetic."
  :qualification "This is a source review, not runtime verification or permission to begin diagnostics while review/writing agents remain active.")
 :findings
 ((:id :R1
   :priority 2
   :classification :confirmed-static-correctness-defect
   :title "Window validation and fault-recovery selection occur before reentry is blocked"
   :references
   ((:file "src/metrics/counter-snapshot.lisp" :lines (10 19))
    (:file "src/metrics/counter-snapshot.lisp" :lines (26 38))
    (:file "src/metrics/counter-snapshot.lisp" :lines (74 83))
    (:file "src/metrics/record.lisp" :lines (31 41)))
   :evidence "Capture compares fine to mutable inizio before entering its read-only scope. Reset caches the mutable entry fault flag and compares its requested start before entering the reset scope. A same-owner callback before scope entry is not rejected by the guard and can change either value. The outer call then proceeds using stale decisions. Strict > instead of >= does not close this gap."
   :static-interleavings
   ((:case :capture-window
     :steps
     ("Partition start is 0. Capture(metrics, 10) passes its pre-scope fine>=inizio check."
      "Before scope entry, an owner callback successfully resets to 20, then records a request, and returns."
      "Outer capture enters its scope and constructs start=20, end=10 with a nonzero retained request count."
      "The rate reader checks only zero elapsed and therefore can return a negative rate with :ok/T on this public-produced snapshot.")
     :impact "A public capture can violate its declared end>=start invariant and permit misleading rate arithmetic.")
    (:case :strict-reset-start
     :steps
     ("Partition start is 0. Reset(metrics, 10) passes its strict pre-scope check."
      "An owner callback completes reset to 20 before the outer scope begins."
      "Outer reset subsequently stores start=10, moving the start backward despite the strict policy.")
     :impact "The proposed window identity rule is not enforced across same-owner admission reentry.")
    (:case :stale-recovery-policy
     :steps
     ("Outer reset caches faulted=NIL while the partition is healthy."
      "Before outer scope entry, an owner callback starts a queue mutation, changes only part of the queue state, and handles an abnormal exit after it unwinds. The request histogram is now faulted."
      "The outer :reset T scope admits recovery, but its cached faulted=NIL chooses the normal queue-preservation branch."
      "Outer reset clears the partition fault after preserving uncertain queue state instead of forgetting queue cells/knowledge.")
     :impact "The new fault-recovery queue policy can be bypassed and partial queue observation state can survive as healthy state."))
   :action "Establish the thread-local non-reentry scope before reading mutable start or deciding whether reset is recovery. Under that scope, validate the requested window and capture the ORIGINAL entry-fault state before setting any mutation fault marker. Then mark reset mutation faulty, perform all histogram/counter/queue/window writes, and clear the marker last. Capture should validate the mutable bound inside its existing read-only scope. Type-only validation may remain outside."
   :pitfall "Simply moving reset's validation or faulted read into the current mutating macro body is insufficient: the macro sets fault=T before the body, so invalid windows would poison state and every reset would appear to be recovery. Separate guarded admission/prevalidation from the mutation phase, preserving existing reset recovery and read-only failure semantics."
   :confidence :high-from-control-flow
   :runtime-reproduction-performed nil
   :scope-note "This concerns local same-thread reentry between prevalidation and guard entry. It does not require a second worker, mutable shared counters or a globally atomic cross-worker snapshot."))
 :strict-start-assessment
 (:sufficient-for-window-disambiguation t
  :conditions "The strict comparison is made under the owner guard; logical partition IDs are unique; adapter-supplied endpoints/cuts are truthful."
  :reason "Within one partition lifetime each successful reset then gives a strictly greater start, distinguishing successive accounting periods without adding a generation slot. Two cumulative captures within one period still share provenance; aggregate overlap detection rejects double counting them, including nested aggregates."
  :not-implied "Strict start>previous start does not enforce start>=the previous capture's end, monotonically increasing capture endpoints, event timestamps, all-producer inclusion or physical simultaneity. Those remain adapter obligations under the agreed contract."
  :documentation "State that counts are cumulative since construction/last successful reset and that 'exact' rates concern retained counts and supplied time metadata. The known obsolete nondecreasing sentence was already acknowledged by the author and is not a new independent finding."
  :implementation-status "Strict reset > is present in the reviewed blob; R1 still prevents treating it as fully enforced across admission reentry.")
 :queue-recovery-assessment
 (:policy-correct t
  :normal-reset "Preserving sampled current depths and seeding peaks from them is consistent with the documented carry-forward baseline. Queue knowledge is preserved."
  :fault-recovery "Clearing both queue cells and the known mask avoids claiming a partial interrupted observation as retained known state. Unknown queues remain a separate availability status from submitted event counter completeness."
  :remaining-condition "Select normal versus recovery reset using the entry fault state while reentry is already blocked, as required by R1."
  :quality-limitation "Queue :exact and :upper-bound concern submitted/carry-forward samples and arithmetic over them, not an unsampled real-world queue at the injected end or a bound on unseen physical peaks. The current contract explicitly disclaims unsubmitted intermediate states.")
 :static-areas-with-no-further-defect-found
 ((:area :scope-composition
   :references ((:file "src/metrics/counter-record.lisp" :lines (24 103))
                (:file "src/metrics/counter-snapshot.lisp" :lines (13 19)))
   :reason "Every admitted event uses the request histogram guard, including flush/cache/queue operations. Private %registra-latenza/%copia-istogramma/%azzera-istogramma helpers avoid nested public owner-scope entry. The flush child is private and its state is covered by the enclosing request marker.")
  (:area :whole-reset-marker
   :references ((:file "src/metrics/record.lisp" :lines (72 79))
                (:file "src/metrics/counter-snapshot.lisp" :lines (30 39)))
   :reason "The private histogram reset deliberately does not clear the enclosing marker. Thus admitted abnormal exits anywhere in both histogram resets, counter clearing, queue clearing/preservation or window assignment leave the whole partition faulty. Marker clearing occurs only in the outer scope after body completion; R1 concerns admission decisions before that body.")
  (:area :capture-purity
   :references ((:file "src/metrics/snapshot.lisp" :lines (6 15))
                (:file "src/metrics/counter-snapshot.lisp" :lines (13 19)))
   :reason "Once admitted with a valid window, capture uses literal read-only scope mode and independently copies both scalar arrays and histogram arrays. Allocation/copy failure does not mutate source state or its health. Original immutable identity/config objects may be shared safely under the caller publication contract.")
  (:area :rejected-event-accounting
   :references ((:file "src/metrics/counter-record.lisp" :lines (9 19))
                (:file "src/metrics/counter-record.lisp" :lines (24 90)))
   :reason "Capacity is checked by subtraction before addition, and sticky incompleteness now gates future admission. Append/flush rejection marks both affected counters; request rejection marks request loss and error loss only for an error outcome. Associated histogram saturation is sticky. Errors<=requests plus a fitting request increment bounds the accepted error increment. Flush/request population equality is maintained for every successful complete event. Unrelated families remain admissible when only another family's incompleteness is set.")
  (:area :hierarchy-provenance-and-windows
   :references ((:file "src/metrics/counter-aggregate.lisp" :lines (33 62))
                (:file "src/metrics/counter-aggregate.lisp" :lines (85 115)))
   :reason "Endpoint equality is checked at every aggregation level. Flattened original (serie,worker) identities survive hierarchy; value-based hash keys reject duplicate origin pairs across direct inputs and nested aggregates. Original source count is bounded at 4096 before admitting another origin. Serie and worker output metadata are derived from original provenance rather than from lossy intermediate labels.")
  (:area :aggregate-arithmetic-and-completeness
   :references ((:file "src/metrics/counter-aggregate.lisp" :lines (8 28))
                (:file "src/metrics/counter-aggregate.lisp" :lines (67 82))
                (:file "src/metrics/merge.lisp" :lines (44 128)))
   :reason "Scalar and observed queue sums reject over-bound additions using subtraction. Latency merge validates each population and cap, checks total against an independent output cap, sums bins into fresh storage, propagates saturation OR and accepted maximum, and revalidates the result population. Compatibility compares precision, maximum, unit, frequency and domain while allowing different source admission caps. Counter incompleteness is ORed, queue availability is ANDed; unknown queue sums are not fabricated or subjected to irrelevant hidden partial-sum overflow. No arbitrary prefix is selected by merge and inputs remain unchanged on failure.")
  (:area :api-and-load-order
   :references ((:file "src/metrics/package.lisp" :lines (18 25))
                (:file "arcdocdb.asd" :lines (29 33)))
   :reason "Capture now uses istantanea-metriche and the read-only Serie getter remains istantanea-metriche-serie. Structure type/function namespaces can share the capture symbol. Product serial load order defines histogram helpers/merge and counter types/build before their callers. No compilation was performed."))
 :prior-review-disposition
 (:D1 "Addressed by the agreed single partition scope/private-helper design, subject to the specific remaining admission gap R1."
  :D2 "Superseded by the user's explicit coupled-cap accepted-prefix accounting contract; separate attempted throughput counters are not demanded."
  :D3 "Original provenance, matching supplied endpoints, strict start identity and explicit adapter limitations address this component's aggregation scope. No generation slot or global snapshot barrier is demanded."
  :D4 "Addressed by independent aggregate caps, strict total bounds and propagation of incompleteness."
  :D5 "Addressed by semantic configuration comparison, rather than array-length or configuration-object identity.")
 :limitations
 ("Hand-derived source interleavings and arithmetic reasoning only; no Lisp code, fixtures, compilation, test suite, benchmark, fault injection, interrupt or diagnostic was run."
  "No claim of runtime allocation behavior, compiler scheduling guarantees, exhaustive interrupt interleavings, safe publication implementation or database performance."
  "Private array/constructor mutation is outside the public contract; collector input vectors remain stable; source identities are unique logical partitions."
  "Tests and qualification tooling were arriving concurrently and were not reviewed as final artifacts. Transient missing test files or obsolete capture call sites were not promoted into product defects."
  "This appendix records exact source blobs observed during parallel authoring. Later edits require a scoped reread; the reported open status is not an assessment of an unobserved fix.")
 :writes ("spikes/out/metrics-counters-20261101/independent-increment2-final-review.lisp"))
