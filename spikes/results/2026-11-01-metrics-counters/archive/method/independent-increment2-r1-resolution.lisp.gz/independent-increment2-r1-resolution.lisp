;;;; STATIC resolution appendix only. Data; do not LOAD.
;;;; Original open-finding artifact is preserved, not rewritten.
(:schema 1
 :kind :independent-static-r1-resolution
 :date "2026-11-01"
 :workspace "/Users/gpicchiarelli/.codex/worktrees/observability-histograms/ArcDocDB"
 :branch "codex/metrics-histograms"
 :base-head "f5cae677e2f78a73dc5c2983fc24a854afee1724"
 :source-state :uncommitted-parallel-work
 :mode :static-only
 :executed (:product-evaluation nil :macroexpansion nil :compilation nil
            :tests nil :benchmarks nil :diagnostics nil :fault-injection nil)
 :original-finding
 (:id :R1
  :artifact "spikes/out/metrics-counters-20261101/independent-increment2-final-review.lisp"
  :artifact-git-blob "961d3c47aee01fad902b2478a57ae5ab4447dfc8"
  :original-record-snapshot-blob "91363d11fe77189843557e865fb847663d382666"
  :original-counter-snapshot-blob "3f9378483c23d26fd5afe829d4b615782e0ec2e6"
  :preserved t
  :summary "Mutable start validation and reset's original-fault decision were read before the owner guard, admitting stale capture intervals, backwards resets and preservation of faulted queue state.")
 :reviewed-source
 ((:file "src/metrics/record.lisp" :git-blob "5b3a45394e8c283ad9e9383c05c513b1fe4feb72")
  (:file "src/metrics/counter-snapshot.lisp" :git-blob "62eea67f47425098716e95a4eda1d83bc1353ba8"))
 :conclusion
 (:finding :R1
  :status :resolved-by-static-inspection
  :remaining-concrete-concerns 0
  :scope "Reread the two changed product files and all current production call sites of %con-mutazione-istogramma, including the new :prima keyword path. This is a scoped resolution of R1, not a new review of unrelated parallel work."
  :qualification "No runtime qualification, test result or compiler/interruption proof is claimed.")
 :observed-order
 ("Evaluate the validated histogram form once into a private gensym binding."
  "Reject an already-active current-thread scope before any prelude runs."
  "Install the native dynamic current-thread guard binding."
  "Check the existing fault-admission rule, allowing :reset T recovery."
  "Run static :prima forms while the guard is active and before changing the fault marker."
  "For read-only mode, execute the body without writing metric health."
  "For mutation mode, set the marker true, execute the complete body and clear the marker last while preserving all body values.")
 :resolution-evidence
 ((:case :capture-window
   :references ((:file "src/metrics/counter-snapshot.lisp" :lines (10 19)))
   :reason "Only the immutable supplied value's type is checked outside the scope. The comparison fine>=current start now runs inside the read-only guard and before copying. A callback that completed reset before guard entry is reflected in this comparison; a callback attempting reset after entry is rejected by the existing reentry rule. The stale-start route to end<start is therefore closed.")
  (:case :strict-reset-window
   :references ((:file "src/metrics/counter-snapshot.lisp" :lines (26 30))
                (:file "src/metrics/record.lisp" :lines (32 43)))
   :reason "Reset's type-only check remains outside. Its strict requested-start>current-start comparison runs in :prima after TLS binding, before marking any mutation. An intervening earlier callback's reset is visible; later public owner reentry cannot change the start between comparison and assignment.")
  (:case :original-fault-selection
   :references ((:file "src/metrics/counter-snapshot.lisp" :lines (28 38)))
   :reason "The prelude reads the entry fault marker under the guard and saves it only in the lexical FAULTED binding. Because this occurs before the macro writes its mutation marker, healthy and recovery resets remain distinguishable. A fault introduced before entry selects recovery and clears queue cells/known mask; a healthy reset preserves sampled current depths and seeds peaks from them.")
  (:case :precondition-failure
   :references ((:file "src/metrics/record.lisp" :lines (35 43))
                (:file "src/metrics/counter-snapshot.lisp" :lines (28 30)))
   :reason "The strict-start rejection occurs before any metric-state write. On a healthy partition, a failed prelude leaves fault NIL; on a faulted partition admitted for recovery, it leaves fault T. Native scope unwind releases TLS. This avoids poisoning healthy state and avoids falsely recovering faulted state on rejected input.")
  (:case :prelude-reentry-and-abort
   :references ((:file "src/metrics/record.lisp" :lines (33 43)))
   :reason "The active TLS binding already exists throughout the prelude. Nested public owner operations therefore reject before entering their own prelude/body. An abnormal exit during the current state-pure prelude preserves original metric health because no mutation has been admitted; an exit after marker T leaves the partition faulty until successful owner recovery.")
  (:case :whole-reset-and-read-purity
   :references ((:file "src/metrics/record.lisp" :lines (39 43))
                (:file "src/metrics/record.lisp" :lines (74 81))
                (:file "src/metrics/counter-snapshot.lisp" :lines (12 19))
                (:file "src/metrics/counter-snapshot.lisp" :lines (31 39)))
   :reason "The private histogram reset still leaves the enclosing fault marker unchanged. Both histogram resets, scalar clearing, queue handling and window/mask updates remain inside one marked mutation. Capture remains read-only and allocating; an invalid bound or failed copy cannot fault otherwise valid source state.")
  (:case :reader-window-defense
   :references ((:file "src/metrics/counter-snapshot.lisp" :lines (43 49))
                (:file "src/metrics/counter-snapshot.lisp" :lines (77 86))
                (:file "src/metrics/counter-aggregate.lisp" :lines (33 42)))
   :reason "After checking the snapshot type, the shared reader helper now rejects fine<inizio with INVARIANT-VIOLATION/:metrics-window-invariant. Rate calculation obtains its snapshot through that helper before subtracting/dividing; aggregation validates every snapshot through the helper before comparing windows or summing. Zero intervals remain valid and produce :zero-window. This state-pure defensive check supplements the guarded public-capture fix; no negative rate can result from reversed internal window metadata through these public calculation paths.")
  (:case :backward-compatibility-of-existing-calls
   :references ((:file "src/metrics/record.lisp" :lines (24 43)))
   :reason "When :prima is omitted it is NIL and contributes no forms, preserving the previous scope ordering and body multiple-value behavior. The histogram form is still evaluated once, reentry still rejects before cleanup/setup and reset/read-only modes remain literal booleans. No additional guard, shared write or publication protocol was introduced."))
 :prelude-contract
 (:documented-state-purity t
  :references ((:file "src/metrics/record.lisp" :lines (25 30))
               (:file "src/metrics/counter-snapshot.lisp" :lines (28 30)))
  :observed-production-use "The one current production :prima call contains a strict bound check and assignment to a lexical local only; neither writes metric state. It satisfies the documented private macro contract."
  :limitation "The macro does not prove purity of arbitrary future prelude forms. Future uses must preserve the explicit no-metric-state-write precondition, because prelude aborts deliberately do not poison the source. No new concern is reported for the current call.")
 :strict-start-contract
 (:assessment "Strict start plus unique logical partition provenance is sufficient to disambiguate successful reset windows under truthful supplied cuts. The guarded comparison now enforces that rule locally."
  :unchanged-limits "It does not establish start>=a previous capture's end, physical simultaneous cuts, completeness of producer inclusion or truthful event timestamps. These remain outside the agreed component guarantees; no generation slot or global barrier is requested."
  :final-documentation-observed "The current increment-2 document explicitly states that counts are cumulative since construction/last successful reset, WAL observations are diagnostic rather than durable-commit evidence, and metric failure never determines database durability.")
 :later-verification-expectations
 (:requested-by-author
  ("Prelude sees original fault state; mutating body sees fault T."
   "Prelude rejection preserves healthy/faulted state and prevents the body."
   "Same-thread reentry rejects while a prelude is active."
   "Normal reset preserves sampled queue state; fault recovery forgets it."
   "Capture and reset enforce their mutable start comparisons within the guarded scope.")
  :performed-by-reviewer nil
  :note "Author/test-agent plans are not represented as completed tests.")
 :limitations
 ("Only static source reading and control-flow reasoning; no product execution, macroexpansion, tests, compilation, benchmark, interrupt, failure injection or diagnostic."
  "No proof of arbitrary asynchronous machine/compiler behavior, allocation results, safe publication or database behavior."
  "The documented private-prelude state-purity rule and private-array ownership contract are assumed."
  "The original open finding is historical evidence and remains byte-for-byte unchanged; this separate record supplies its static resolution for the exact reviewed blobs."
  "Unrelated files and arriving test work were not requalified. Further changes to the two reviewed files require a new scoped comparison.")
 :writes ("spikes/out/metrics-counters-20261101/independent-increment2-r1-resolution.lisp"))
