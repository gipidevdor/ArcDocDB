;;;; Finite publication receipt: hashes cover all preceding artifacts, not this receipt itself.
(load "spikes/out/metrics-counters-20261101/packet-support.lisp")
(defparameter *session* (merge-pathnames "spikes/out/metrics-counters-20261101/" (truename "./")))
(defparameter *published* (merge-pathnames "spikes/results/2026-11-01-metrics-counters/" (truename "./")))
(defparameter *receipts* (merge-pathnames "receipts/" *published*))
(when (probe-file *receipts*) (error "Exclusive publication receipts already exist."))
(ensure-directories-exist *receipts*)
(defparameter *commands* nil)
(dolist (label '("prepare-v1" "collect" "recovered-closure" "collector-selftest" "report" "final-check" "cleanup"))
  (let* ((directory (merge-pathnames (format nil "receipts/~A/" label) *session*))
         (record (arcdocdb.evidence:read-evidence (merge-pathnames "report.lisp" directory))))
    (assert (eq (if (equal label "collect") :failed :ok) (getf record :status)))
    (assert (eql (if (equal label "collect") 1 0) (getf record :exit-code)))
    (assert (eq :stable (getf record :source-consistency)))
    (multiple-value-bind (rows process) (add-command-record directory label *receipts*)
      (declare (ignore rows)) (push process *commands*))))
(dolist (pair '(("collection-observations/report.lisp" "collection.lisp")
                ("collection-observations/closed-check.log" "closed-check.log")
                ("cleanup-plan.lisp" "cleanup-plan.lisp")
                ("cleanup-owned.lisp" "method/cleanup-owned.lisp")
                ("close-publication.lisp" "method/close-publication.lisp")
                ("packet-support.lisp" "method/packet-support.lisp")))
  (add-compact-file (merge-pathnames (first pair) *session*) *receipts* (second pair)))
(let* ((original (arcdocdb.evidence:read-evidence (merge-pathnames "collection-observations/report.lisp" *session*)))
       (command (arcdocdb.evidence:read-evidence (merge-pathnames "receipts/recovered-closure/report.lisp" *session*)))
       (*read-eval* nil) (eof (gensym "EOF"))
       (audit (with-input-from-string (stream (getf command :stdout))
                (let ((data (read stream nil eof))) (assert (eq eof (read stream nil eof))) data))))
  (assert (eq :failed (getf original :status))) (assert (eq :closed-check (getf original :reason)))
  (assert (eq :published (getf original :phase)))
  (assert (and (eq :ok (getf audit :status)) (eq t (getf audit :closed-inventory))))
  (assert (equal (getf original :processes) (getf audit :processes)))
  (save-data (list :schema-version 1 :kind :independent-collection-recovery :status :ok
                   :original-command-status :failed :original-collection-status :failed
                   :original-failure :closure-checker-runtime-core-mismatch
                   :closed-inventory t :process-metadata-identical t :original-archive-rewritten nil
                   :limits '(:original-command-remains-failed :independent-existing-archive-verification))
             (merge-pathnames "collection-recovery.lisp" *receipts*)))
(let* ((argv '("git" "diff" "--quiet" "4aab6777b828b475803c77810e8e9a24149ac1f2" "--"
                "src" "tests" "arcdocdb.asd" "tools/metrics-counter-bench.lisp")))
  (multiple-value-bind (stdout stderr code)
      (uiop:run-program argv :output :string :error-output :string :ignore-error-status t)
    (assert (and (zerop code) (zerop (length stdout)) (zerop (length stderr))))))
(let* ((files (arcdocdb.ci::ci-files *published* :limit 100000 :max-depth 32))
       (rows (mapcar (lambda (path) (list :path (enough-namestring path *published*)
                                         :bytes (arcdocdb.evidence:file-bytes path)
                                         :sha256 (arcdocdb.evidence:file-sha256 path))) files))
       (bytes (reduce #'+ rows :key (lambda (row) (getf row :bytes)) :initial-value 0))
       (result (list :schema-version 1 :kind :metrics-evidence-closure :status :ok
                     :date-universal-time (get-universal-time)
                     :lisp (lisp-implementation-type) :version (lisp-implementation-version)
                     :os (software-type) :machine (machine-type)
                     :qualified-product-commit "4aab6777b828b475803c77810e8e9a24149ac1f2"
                     :product-test-ASDF-and-counter-driver-diff :empty :C4-followup-separately-verified t :documentation-followup t
                     :commands (nreverse *commands*) :files rows :file-count (length rows)
                     :stored-logical-bytes bytes
                     :limits '(:finite-preceding-artifact-receipt :self-excluded
                               :no-requirement-or-engine-performance-promotion
                               :all-source-command-output-preserved :not-physical-disk-usage))))
  ;; A second read detects a change between inventory and receipt creation.
  (dolist (row rows)
    (let ((path (merge-pathnames (getf row :path) *published*)))
      (assert (= (getf row :bytes) (arcdocdb.evidence:file-bytes path)))
      (assert (string= (getf row :sha256) (arcdocdb.evidence:file-sha256 path)))))
  (save-data result (merge-pathnames "closure.lisp" *published*))
  (format t "~S~%" (list :status :ok :files (length rows) :stored-logical-bytes bytes
                          :receipt (namestring (merge-pathnames "closure.lisp" *published*)))))
